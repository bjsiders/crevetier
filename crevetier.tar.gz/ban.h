/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#ifndef ban_h
#define ban_h

#include "thoctype.h"

typedef struct	ban_data		BAN_DATA;
typedef struct	ban_data		Ban;

#define BAN_SUFFIX			A
#define BAN_PREFIX			B
#define BAN_NEWBIES			C
#define BAN_ALL				D	
#define BAN_PERMIT			E
#define BAN_PERMANENT		F

struct	ban_data
{
    Ban *		next;
    bool		valid;
    sh_int		ban_flags;
    sh_int		level;
    char *		name;
};

#endif /* ban_h */
