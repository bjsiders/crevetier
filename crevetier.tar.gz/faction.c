/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <time.h>
#include "thoc.h"
#include "recycle.h"
#include "interp.h"
#include "tables.h"

Faction *factionList = NULL;

Faction *classDefaultLists[MAX_CLASS];
Faction *raceDefaultLists[MAX_PC_RACE];
Faction *deityDefaultLists[MAX_DEITY];

int		topFactionID;

void writeFaction( Faction *f, FILE *fp );
void processDefaultFaction( char *buf );
void handleClassDefault( int index, char *str );
void handleRaceDefault( int index, char *str );
void handleDeityDefault( int index, char *str );

char *dispositionName( int disp )
{
	switch( disp )
	{
	case DISPOS_PASSIVE: 	return "passive";
	case DISPOS_ALERT:		return "alert";
	case DISPOS_ACTIVE: 	return "active";
	case DISPOS_HOSTILE:	return "hostile";
	case DISPOS_AGGRESSIVE:	return "aggressive";
    case DISPOS_SEARCHING:  return "searching";
	default:				return	"<unknown>";
	}
}

char *factionDescription( long factionStanding )
{
	if ( factionStanding > 0 )
	{
		if ( factionStanding >= FACTION_UNITY )
			return "Unity";
		else
		if ( factionStanding >= FACTION_HARMONY )
			return "Harmony";
		else
		if ( factionStanding >= FACTION_FRIENDLY )
			return "Friendly";
		else
		if ( factionStanding >= FACTION_PLEASANT )
			return "Pleasant";
		else
		if ( factionStanding >= FACTION_AMIABLE )
			return "Amiable";
		else
		if ( factionStanding >= FACTION_WARM )
			return "Warm";
		else
		if ( factionStanding >= FACTION_COOPERATIVE )
			return "Cooperative";
		else
		if ( factionStanding >= FACTION_AMUSEMENT )
			return "Amused";
		else
		if ( factionStanding >= FACTION_TOLERANT )
			return "Tolerant";
		else
		if ( factionStanding >= FACTION_AMBIVALENT )
			return "Ambivalent";
		else
			return "Indifferent";
	}
	else
	if ( factionStanding < 0 )
	{
		if ( factionStanding <= FACTION_HATRED )
			return "Hatred";
		else
		if ( factionStanding <= FACTION_FURY )
			return "Furious";
		else
		if ( factionStanding <= FACTION_AGGRESSIVE )
			return "Aggressive";
		else
		if ( factionStanding <= FACTION_ANGER )
			return "Angry";
		else
		if ( factionStanding <= FACTION_REVULSION )
			return "Revulsion";
		else
		if ( factionStanding <= FACTION_DISGUST )
			return "Disgust";
		else
		if ( factionStanding <= FACTION_DISTASTE )
			return "Distaste";
		else
		if ( factionStanding <= FACTION_DISTRUST )
			return "Distrust";
		else
		if ( factionStanding <= FACTION_SUSPICIOUS )
			return "Suspicious";
		else
		if ( factionStanding <= FACTION_UNCERTAIN )
			return "Uncertain";
		else
			return "Indifferent";
	}

	return "Indifferent";
}

void do_factions( Character *ch, char *argument )
{
	/* Show character all of his factions */
	Faction *f;
	bool found;

	found = FALSE;
	cprintf(ch," == Your Factions ==\r\r");
	for( f = ch->factions ; f != NULL ; f = f->next )
	{
		if ( f->standing != FACTION_MEMBER_OF )
			continue;
		else
		{
			found = TRUE;
			cprintf(ch," * %s\n", f->name );
		}
	}

	if( !found )
		cprintf(ch,"    You belong to no factions.\n\r");

	found = FALSE;
	cprintf(ch,"\n\r == Your Faction Standings ==\n\r");
	for( f = ch->factions ; f != NULL ; f = f->next )
	{
		if ( f->standing == FACTION_MEMBER_OF )
			continue;
		else
		{
			found = TRUE;
			cprintf(ch," * %-26s %s", f->name, factionDescription( f->counter ));
			if ( IS_IMMORTAL(ch) )
				cprintf(ch," %ld", f->counter );
			cprintf(ch,"\n");
		}
	}

	if( !found )
		cprintf(ch,"    You have no faction standing.\n\r");

	return;
}

void save_factions( void )
{
	char	cmd[MAX_STRING_LENGTH];
	FILE *fp;

	snprintf(cmd,sizeof(cmd),"mv %s %s.bak", FACTION_FILE, FACTION_FILE );
	system(cmd);

	if ( (fp = fopen(FACTION_FILE,"w")) == NULL )
	{
		log_bug("Unable to open faction file",0);
		return;
	}

	fprintf(fp,"%d\n", topFactionID);
	writeFaction(factionList, fp);
	fclose(fp);
	return;
}

/* Recursive trick to write 'em out in reverse order so they'll read in
 * as being ordered already.  We just ahve to make sure taht when we 
 * create new factions they are inserted into the list in order.
 */
void writeFaction( Faction *f, FILE *fp )
{
	if ( f->next != NULL )
		writeFaction(f->next,fp);

	fprintf(fp,"%s~ %d\n", f->name, f->factionID);
	return;
}

void load_factions( void )
{
	Faction *f;
	FILE *fp;

	log_string("Loading faction list from file %s", FACTION_FILE );
	if ( (fp=fopen(FACTION_FILE,"rb")) == NULL )
	{
		log_bug("Unable to open faction list",0);	
		return;
	}

	/* Ok, we have the list.  Start reading */
	topFactionID = fread_number(fp);
	for( ; ; )
	{
		char *fName;

		if ( (fName = fread_string(fp)) == NULL )
			break;
	
		f = new_faction( );
		f->name = fName;
		f->standing = f->counter = 0;
		f->factionID = fread_number(fp);
		f->next = factionList;
		factionList = f;
	}	
	fclose(fp);
	log_string("Faction load finished.");
	return;
}

void addFactionToList( Faction **list, Faction *f )
{
	Faction *fi;

	if ( *list == NULL || strcasecmp(f->name,(*list)->name) < 0 )
	{
		f->next = *list;
		*list = f;
	}
	else
	{
		for( fi = *list ; fi != NULL ; fi = fi->next )
		{
			if ( fi->next == NULL )
			{
				fi->next = f;
				f->next = NULL;
				break;
			}
			else
			if ( strcasecmp(f->name,fi->next->name) < 0 )
			{
				f->next = fi->next;
				fi->next = f;
				break;
			}
		}
	}

	return;
}

bool removeFactionFromList( Faction **list, Faction *f )
{
	Faction *fi;

    if ( *list == f )
    {
        *list = f->next;
        f->next = NULL;
		return TRUE;
    }
    else
    for( fi = *list; fi != NULL ; fi = fi->next )
    {
        if ( fi->next == f )
        {
            fi->next = f->next;
            f->next = NULL;
			return TRUE;
        }
    }

	return FALSE;
}

Faction *findFactionByID( Faction *list, int id )
{
	Faction *f;

	for( f = list ; f != NULL ; f = f->next )
		if ( abs(f->factionID) == abs(id) )
			return f;

	return NULL;
}
	
Faction *findFactionInList( Faction *list, char *arg )
{
    Faction *f;

    for( f = list ; f != NULL ; f = f->next )
    {
        if ( LOWER(f->name[0]) == LOWER(arg[0]) && !str_prefix(arg,f->name) )
            return f;
    }

    return NULL;
}

void loadDefaultFactions( void )
{
	FILE *fp;
	char	buf[MAX_STRING_LENGTH];

	if ( (fp = fopen(DEFAULT_FACTION_FILE,"r")) == NULL )
	{
		log_string("Failed to open %s", DEFAULT_FACTION_FILE );
		return;
	}

	/* File is open.  Try to read lines and process them */
	while( fgets(buf,sizeof(buf),fp) != NULL )
	{
		switch( buf[0] )
		{
			default:
				if( !isspace(buf[0]) )
					log_string("Invalid key in %s: %c", DEFAULT_FACTION_FILE, buf[0]);
			case '#':
				continue;
			case 'C': case 'c':
			case 'R': case 'r':
			case 'D': case 'd':
				processDefaultFaction(buf);
				continue;
		}
	}

	/* All done! */
	fclose(fp);
	log_string("Finished loading default factions.");
	return;
}

void processDefaultFaction( char *buf )
{
	char type;
	char *s, *t;
	int count = 0;
	int ind;
	void (*func)( int index, char *str );

			
	type = *buf;
				
	/* move to start of string */
	buf += 2;
	if ( (s=strchr(buf,'=')) == NULL )
	{
		log_string("Line [%s] is missing =",buf);
		return;
	}
	
	/* Ok, set the = to NULL and move on */
	/* Now 'buf' is an NTS */
	*s++ = '\0';

	/* Find index and lookup */
	switch( type )
	{
		case 'C':case 'c': 		
			if ( (ind = class_lookup(buf)) < 0 )
			{
				log_string("No such class %s found for default faction",buf);
				return;
			}
			func = handleClassDefault;
			break;
			
		case 'R':case 'r':
			if( (ind = race_lookup(buf)) < 0 || !race_table[ind].pc_race )
			{
				log_string("No such PC race %s found for default faction",buf);
				return;
			}
			func = handleRaceDefault;
			break;
			
		case 'D':case 'd':
			if ( (ind = deity_lookup(buf)) < 0 )
			{
				log_string("No such deity %s found for default faction",buf);
				return;
			}
			func = handleDeityDefault;
			break;
			
		default:
			log_string("Unknown faction default type %c",type);
			return;
	}

	if( (t = strtok(s,",\n")) == NULL )
	{
		log_string("No separator found in [%s]", buf);
		return;
	}

	/* Ok we've got one.  Start procetsing 'em */
	while( t != NULL && *t != '\n' )
	{
		(*func)( ind, t );
		t = strtok(NULL,",\n");
		++count;
	
	}

	/* All done */
	return;
}

void handleRaceDefault( int index, char *str )
{
	Faction *f, *master;
	long	stand = 0;

	switch( *str )
	{
	case '+':	stand = 5001; break;
	case '-':	stand = -5001; break;
	default:
		log_string("bad faction format: first byte should be +/-, found [%c]",*str);
		return;
	}

	if( (master = factionLookup( ++str )) == NULL )
	{
		log_string("unable to locate faction %s in master list",str);
		return;
	}
					
	f = new_faction();
	f->standing = 0; /* players don't use this, only the counter */
	f->counter = stand;
	f->name = str_dup(master->name);
	f->factionID = abs(master->factionID); /* this one won't get freed */

	addFactionToList( &raceDefaultLists[index], f );
	return;
}

void handleDeityDefault( int index, char *str )
{
	Faction *f, *master;
	long	stand = 0;

	switch( *str )
	{
	case '+':	stand = 5001; break;
	case '-':	stand = -5001; break;
	default:
		log_string("bad faction format: first byte should be +/-, found [%c]",*str);
		return;
	}

	if( (master = factionLookup( ++str )) == NULL )
	{
		log_string("unable to locate faction %s in master list",str);
		return;
	}
					
	f = new_faction();
	f->standing = 0; /* players don't use this, only the counter */
	f->counter = stand;
	f->name = str_dup(master->name);
	f->factionID = abs(master->factionID); /* this one won't get freed */

	addFactionToList( &deityDefaultLists[index], f );
	return;
}

void handleClassDefault( int index, char *str )
{
	Faction *f, *master;
	long	stand = 0;

	switch( *str )
	{
	case '+':	stand = 5001; break;
	case '-':	stand = -5001; break;
	default:
		log_string("bad faction format: first byte should be +/-, found [%c]",*str);
		return;
	}

	if( (master = factionLookup( ++str )) == NULL )
	{
		log_string("unable to locate faction %s in master list",str);
		return;
	}
					
	f = new_faction();
	f->standing = 0; /* players don't use this, only the counter */
	f->counter = stand;
	f->name = str_dup(master->name);
	f->factionID = abs(master->factionID); /* this one won't get freed */

	addFactionToList( &classDefaultLists[index], f );
	return;
}

Faction *cloneFaction( Faction *f )
{
	Faction *new;

	new = new_faction( );
	new->name = str_dup(f->name);
	new->standing = f->standing;
	new->factionID = f->factionID;
	new->counter = f->counter;
	return new;
}

void applyDefaultFactions( Character *ch )
{
	Faction *f;

	for( f = classDefaultLists[ch->class] ; f != NULL ; f = f->next )
		if( !findFaction(ch,f) )
			addFactionToList( &(ch->factions), cloneFaction( f ) );

	for( f = raceDefaultLists[ch->race] ; f != NULL; f = f->next )
		if( !findFaction(ch,f) )
			addFactionToList( &(ch->factions), cloneFaction( f ) );

	for( f = deityDefaultLists[ch->deity] ; f != NULL; f = f->next )
		if( !findFaction(ch,f) )
			addFactionToList( &(ch->factions), cloneFaction( f ) );

	return;
}

bool checkFaction( Character *ch, char *faction_name, int minimum )
{
	Faction *f, *adj;

	if ( (f = factionLookup( faction_name )) == NULL )
		return FALSE;

	if ( (adj = findFaction(ch,f)) == NULL )
		return FALSE;

	return ( adj->counter > minimum );
}

/* Another interface to faction changes */
void applyFaction( Character *ch, char *faction_name, int amount )
{
	Faction *f, *adj;

	if ( (f = factionLookup( faction_name )) == NULL )
		return;

	if ( is_affected(ch,gsn_shapeshifting,AFF_SKILL) && ch->desc )
		ch = ch->desc->original;
	
	if ( (adj = findFaction(ch,f)) == NULL )
    {
        adj = new_faction( );
        adj->name = str_dup(f->name);
        adj->counter = 0;
        adj->factionID = abs(f->factionID);
        addFactionToList( &(ch->factions), adj );
    }

	adj->counter += amount;
    cprintf(ch,"&MYou %s faction with %s!&x", amount < 0 ? "lose" : "gain", f->name );

    if( IS_IMMORTAL(ch) )
        cprintf(ch," (%d)", amount );

    cprintf(ch,"\n\r");
}

void adjustFaction( Character *ch, Character *v, Faction *f, int standing,  bool fQuiet, int percent )
{
	int adj_amount;

	adj_amount = 25 + (v->level * 2/3 );
	adj_amount += ( v->level - ch->level ) * 5;
	adj_amount = percent * adj_amount / 100;
	adj_amount = URANGE(0,v->level,100);

	/* Positive factino changes are adjusted for charisma */

	/* You get negative faction with allied factions */
	if( standing == FACTION_MEMBER_OF )
		adj_amount *= -1;
	else
		adj_amount = get_curr_stat(ch,STAT_CHA) * adj_amount / 100;
		
	/* That's the basics, add any other conditions here */
	f->counter += adj_amount;	

	if ( !fQuiet )
	{
		cprintf(ch,"&MYou %s faction with %s!&x",
			adj_amount < 0 ? "lose" : "gain", f->name );

		if( IS_IMMORTAL(ch) )
			cprintf(ch," (%d)", adj_amount );

		cprintf(ch,"\n\r");
	}

}

void applyFactionFromDeath( Character *ch, Character *dyer, int percent )
{
	Faction *f, *adj;

	if ( !IS_NPC(dyer) || (f=dyer->factions) == NULL )
		return;

	for( ; f != NULL ; f = f->next )
	{
		if ( (adj = findFaction(ch,f)) == NULL )
		{
			adj = new_faction( );
			adj->name = str_dup(f->name);
			adj->counter = 0;
			adj->factionID = abs(f->factionID);
			addFactionToList( &(ch->factions), adj );
		}

		adjustFaction(ch,dyer,adj,f->standing,FALSE, percent);
	}

	return;
}

bool are_allies( Character *c1, Character *c2 )
{
	Faction *f, *find;

	if ( c1->factions == NULL || c2->factions == NULL )
		return FALSE;

	for( f = c1->factions ; f != NULL ; f = f->next )
	{
		if( f->standing != FACTION_MEMBER_OF )
			continue;

		if( (find = findFaction(c2,f)) != NULL && find->standing == FACTION_MEMBER_OF )
			return TRUE;
	}

	return FALSE;
}

bool are_enemies( Character *c1, Character *c2 )
{
	Faction *f, *find;

	if( c1->factions == NULL || c2->factions == NULL )
		return FALSE;

	for( f = c1->factions ; f != NULL ; f = f->next )
	{
		if( (find = findFaction(c2,f)) == NULL )
			continue;

		if( (f->standing == FACTION_MEMBER_OF && find->standing == FACTION_ENEMY_OF) ||
			(f->standing == FACTION_ENEMY_OF && find->standing == FACTION_MEMBER_OF))
			return TRUE;
	}

	return FALSE;
}
