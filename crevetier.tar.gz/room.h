#ifndef room_h
#define room_h

#define MAX_SPAWN   50000
#define MAX_DIR     6

#define MOVE_JUMP       (A)
#define MOVE_CLIMB      (B)
#define MOVE_FALL       (C)

/*
 * Room type.
 */
struct room_index_data
{
    Spawn *                 spawns;
    Room *                  next;
    Character *             people;
    Object *                contents;
    ExtraDescr *      extra_descr;
    Area *                  area;
    Exit *                  exit[6];
    Exit *                  old_exit[6];
    Building *              buildings;
    Resource *              resources;
    int                     version;
    char *                  name;
    char *                  description;
    char *                  owner;
    sh_int                  vnum;
    int                     room_flags;
    sh_int                  light;
    sh_int                  sector_type;
    sh_int                  heal_rate;
    sh_int                  mana_rate;
    Clan *                  clan;
    sh_int                  guild;
    Affect *                affects;
    Track *                 tracking;
    int                     terrain;
};

struct natural_resources
{
    Resource *      next;
    int             resource;
    int             amount;
};

/*  
 * Exit data.   
 */ 
struct exit_data
{   
    Exit *              next;        /* OLC */
    int                 rs_flags;    /* OLC */
    int                 orig_door;    /* OLC */

    union
    {
        Room *          to_room;
        sh_int          vnum;
    } u1;
    int                 exit_info;
    int                 key;
    char *              keyword;
    char *              description;
    Spawn *             spawn;
};

/*
 * Tracking
 */
struct track_data
{
    Track       *next;
    Track       *next_in_room;
    bool        valid;

    Character   *who;
    int         footwear_vnum;
    short       injury_percent;
    short       weight_percent;
    time_t      arrive_time;
    time_t      depart_time;
    short       arrive_dir;
    short       depart_dir;
    long        flags;
};

typedef struct _pick_diff
{
    long        flag;
    int            difficulty;
} pick_difficulty_type;


/*
    A guild house building
 */
struct building_data
{
    Building *      next;
    bool            valid;
    int             type;
    long            flags;
    int             max_structure;
    int             curr_structure;
    int             material;
    int             level;
    int             entrance_room;
    int             available_resources;
    Clan *          clan_owner;
};

/*
    Spawn system
 */
extern    long    topSpawnIndex;
extern    Spawn    *spawnTable;

struct spawn_data
{
    Spawn *     next_in_room;
    Spawn *     contains;
    Spawn *     next_content;
    Spawn *     trigger;
    Object *    pContent;        /* to facilitate ground content spawns */
    int         index;
    char        type;
    int         source;
    int         target;
    int         clockStart;
    int         clockEnd;
    int         frequency;
    int         placeholder;
    int         despawn;
    int         interval;
    int         timer;
    long        misc;
    long        flags;
};

typedef struct
{
    int links[4];
    int exists;
    int vnum;
} Node;

#define MAPSIZE     28
#define MAXDEPTH    (MAPSIZE/2)

extern Node map[MAPSIZE][MAPSIZE];
extern int top_rmap_vnum;
extern int bias;

#define SPAWN_FLAG(s,flag)      (IS_SET((s)->flags,(flag)))
#define SPAWN_READY             (A)
#define SPAWN_ERROR             (B)
#define SPAWN_CONTENT           (C)
#define SPAWN_FORCE             (D)
#define SPAWN_CONTAINER_FALGS   (E)

/*
    For act.
 */
#define TO_ROOM          0
#define TO_NOTVICT       1
#define TO_VICT          2
#define TO_CHAR          3
#define TO_ALL           4
#define TO_RADIUS        5

/*
    Room flags.
 */
#define ROOM_DARK                   (A)
#define ROOM_NO_MOB                 (C)
#define ROOM_INDOORS                (D)

#define ROOM_PRIVATE                (J)
#define ROOM_SAFE                   (K)
#define ROOM_SOLITARY               (L)
#define ROOM_PET_SHOP               (M)
#define ROOM_NO_RECALL              (N)
#define ROOM_IMP_ONLY               (O)
#define ROOM_GODS_ONLY              (P)
#define ROOM_HEROES_ONLY            (Q)
#define ROOM_NEWBIES_ONLY           (R)
#define ROOM_LAW                    (S)
#define ROOM_NOWHERE                (T)
#define ROOM_CLAN_VAULT             (U)
#define ROOM_ZONED                  (V) // zoned for clan halls
#define ROOM_FOG                    (W)
#define ROOM_SILENCE                (X)
#define ROOM_SWAMP_GAS              (Y)
#define ROOM_NOXIOUS                (Z)
#define ROOM_ARENA                  (aa) // pkill arena
#define ROOM_ROAD                   (bb)

/*
    Directions.
 */
#define DIR_NORTH                   0
#define DIR_EAST                    1
#define DIR_SOUTH                   2
#define DIR_WEST                    3
#define DIR_UP                      4
#define DIR_DOWN                    5

/*
    Exit flags.
 */
#define EX_ISDOOR                   (A)
#define EX_CLOSED                   (B)
#define EX_LOCKED                   (C)
#define EX_SIMPLE                   (D)        /* 15% difficulty */

#define EX_PICKPROOF                (F)
#define EX_NOPASS                   (G)
#define EX_EASY                     (H)        /* 30% */
#define EX_HARD                     (I)        /* 75 */
#define EX_INFURIATING              (J)        /* 90 */
#define EX_NOCLOSE                  (K)
#define EX_NOLOCK                   (L)
#define EX_HOLD_PORTAL              (M)
#define EX_HIDDEN                   (N) // don't show on autoexit, etc
#define EX_AVERAGE                  (O)        /* 45% */
#define EX_DIFFICULT                (P)        /* 60 */
#define EX_FALL                     (Q)
#define EX_CLIMB                    (R)
#define EX_SHEER_CLIMB              (S)

/* Flags used for exit parsing type */
#define EX_SHOW_LOOK                0
#define EX_SHOW_AUTO                1
#define EX_SHOW_PROMPT              2

/*
    Sector types.
 */
#define SECT_INSIDE                 0
#define SECT_CITY                   1
#define SECT_FIELD                  2
#define SECT_FOREST                 3
#define SECT_HILLS                  4
#define SECT_MOUNTAIN               5
#define SECT_WATER_SWIM             6
#define SECT_WATER_NOSWIM           7
#define SECT_UNUSED                 8
#define SECT_AIR                    9
#define SECT_DESERT                 10
#define SECT_ICE                    11
#define SECT_ROAD                   12
#define SECT_UNDERGROUND            13
#define SECT_UNDERWATER             14
#define SECT_MAGMA                  15
#define SECT_MAX                    16

#define BUILDING_GENERIC        0
#define BUILDING_BARRACKS       1
#define BUILDING_BLACKSMITH     2
#define BUILDING_WOODSMITH      3
#define BUILDING_MAGELAB        4
#define BUILDING_SANCTUM        5
#define BUILDING_WATCHTOWER     6
#define BUILDING_WALL           7
#define BUILDING_GATEHOUSE      8
#define MAX_BUILDING            9

#define VNUM_WEAPON_ANVIL       40000
#define VNUM_ARMOR_ANVIL        40001

// Building flags
#define BUILDING_UNDER_CONSTRUCTION        (A)
#define BUILDING_CLOSED                    (B)
#define BUILDING_LOCKED                    (C)
#define BUILDING_UPGRADE                   (D)

#define BUILDMAT_WOOD           0
#define BUILDMAT_STONE          1

#define NR_ANTIMONY         30745
#define NR_ARSENIC          30746
#define NR_COPPER           30747
#define NR_IRON             30748
#define NR_TIN              30750
#define NR_LIMESTONE        30749
#define NR_COAL             6517
#define NR_FOREST           32231
#define NR_STONE            32230

#define TERRAIN_COLD            (A)
#define TERRAIN_HOT             (B)
#define TERRAIN_NOXIOUS         (C)

extern Area *ClanHallArea;
extern const int building_table[MAX_BUILDING][2];
extern const char* randomDescriptions[2][10];
extern const char* hallDescriptions[MAX_BUILDING][8];
extern const pick_difficulty_type pick_diff_table[];

/*
    Macros
*/
#define act(format,ch,arg1,arg2,type) act_new((format),(ch),(arg1),(arg2),(type),POS_RESTING,FALSE)

#define exitName(pExit)  ( ( (pExit)->description != NULL && \
                             strcmp((pExit)->description,"(null)") \
                           ) ? (pExit)->description \
                             : !strcmp((pExit)->keyword,"(null)") ? "door" : (pExit)->keyword )


#endif /* room_h */
