/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

// ANSI color

#ifndef _GGG_ANSI_H
#define _GGG_ANSI_H

#define     colorize(x)     replaceANSI((x),FALSE)
#define     decolorize(x)   replaceANSI((x),TRUE)


/* Procedure definitions */
bool has_color( Descriptor *ch );
void stripcolor( const char * arg, char *ret );
void addcolor( const char * arg, char *ret );
void stripColorInline( char *arg );

#define NORM		   "\x1b[0m"
#define UNDERLINE_ON   "\x1b[4m"
#define UNDERLINE_OFF  "\x1b[0;24m"

/* ALL BOLD COLORS */
#define GRAY		"\x1b[1;30m"
#define RED			"\x1b[1;31m"
#define GREEN		"\x1b[1;32m"
#define YELLOW		"\x1b[1;33m"
#define BLUE		"\x1b[1;34m"
#define MAGENTA		"\x1b[1;35m"
#define CYAN		"\x1b[1;36m"
#define WHITE		"\x1b[1;37m"


/* All normal colors */
#define BLACK		"\x1b[0;30m"
#define LRED		"\x1b[0;31m"
#define LGREEN		"\x1b[0;32m"
#define BROWN		"\x1b[0;33m"
#define LBLUE		"\x1b[0;34m"
#define LMAGENTA	"\x1b[0;35m"
#define LCYAN		"\x1b[0;36m"
#define SILVER		"\x1b[0;37m"

/* Background colors */
#define BBLACK		"\x1b[1;40m"
#define BRED		"\x1b[1;41m"
#define BGREEN		"\x1b[1;42m"
#define BORANGE		"\x1b[1;43m"
#define BBLUE		"\x1b[1;44m"
#define BMAGENTA 	"\x1b[1;45m"
#define BCYAN		"\x1b[1;46m"
#define BWHITE		"\x1b[1;47m"

#define ESC_CHAR	'&'
char *replaceANSI( const char *txt, int fStrip );

#endif
