/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  File: bit.c                                                            *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 *                                                                         *
 *  This code was written by Jason Dinkel and inspired by Russ Taylor,     *
 *  and has been used here for OLC - OLC would not be what it is without   *
 *  all the previous coders who released their source code.                *
 *                                                                         *
 ***************************************************************************/
/*
 The code below uses a table lookup system that is based on suggestions
 from Russ Taylor.  There are many routines in handler.c that would benefit
 with the use of tables.  You may consider simplifying your code base by
 implementing a system like below with such functions. -Jason Dinkel
 */



#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "thoc.h"
#include "lookup.h"
#include "tables.h"

struct flag_stat_type
{
    const struct flag_type *structure;
    bool stat;
};

/*****************************************************************************
 Name:		flag_stat_table
 Purpose:	This table catagorizes the tables following the lookup
 		functions below into stats and flags.  Flags can be toggled
 		but stats can only be assigned.  Update this table when a
 		new set of flags is installed.
 ****************************************************************************/
const struct flag_stat_type flag_stat_table[] =
{
/*  {	structure		stat	}, */
    {	area_flags,		FALSE	},
    {   sex_flags,		TRUE	},
    {   exit_flags,		FALSE	},
    {   door_resets,		TRUE	},
    {   room_flags,		FALSE	},
    {   sector_flags,		TRUE	},
    {   savingthrow_flags,  TRUE    },
    {   spell_type_flags,   TRUE    },
    {   starting_weapon_flags,  TRUE    },
    {   spell_target_flags, TRUE    },
    {   aff_where_flags, TRUE },
    {   type_flags,		TRUE	},
    {   forge_flags,		TRUE	},
    {   extra_flags,		FALSE	},
    {   wear_flags,		FALSE	},
    {   furniture_flags,	FALSE   },
    {   portal_flags,		FALSE   },
    {   act_flags,		FALSE	},
    {   affect_flags,		FALSE	},
    {   apply_flags,		TRUE	},
    {   wear_loc_flags,		TRUE	},
    {   wear_loc_strings,	TRUE	},
    {   weapon_flags,		TRUE	},
    {   container_flags,	FALSE	},
	{	resource_flags,		TRUE	},
	{	building_flags,		TRUE	},
	{	building_info_flags, FALSE },
/* ROM specific flags: */

    {   material_type,          TRUE    },
    {   form_flags,             FALSE   },
    {   part_flags,             FALSE   },
    {   ac_type,                TRUE    },
    {   size_flags,             TRUE    },
    {   position_flags,         TRUE    },
    {   off_flags,              FALSE   },
    {   imm_flags,              FALSE   },
    {   dam_flags,              TRUE    },
    {   weapon_class,           TRUE    },
    {   weapon_type_olc,        FALSE   },
    {   0,			0	}
};
    


/*****************************************************************************
 Name:		is_stat( table )
 Purpose:	Returns TRUE if the table is a stat table and FALSE if flag.
 Called by:	flag_value and flag_string.
 Note:		This function is local and used only in bit.c.
 ****************************************************************************/
bool is_stat( const struct flag_type *flag_table )
{
    int flag;

    for (flag = 0; flag_stat_table[flag].structure; flag++)
    {
	if ( flag_stat_table[flag].structure == flag_table
	  && flag_stat_table[flag].stat )
	    return TRUE;
    }
    return FALSE;
}





/*****************************************************************************
 Name:		flag_value( table, flag )
 Purpose:	Returns the value of the flags entered.  Multi-flags accepted.
 Called by:	olc.c and olc_act.c.
 ****************************************************************************/
int flag_value( const struct flag_type *flag_table, char *argument)
{
    char word[MAX_INPUT_LENGTH];
    int  bit;
    int  marked = 0;
    bool found = FALSE;

    if ( is_stat( flag_table ) )
    {
	    one_argument( argument, word );
	    if ( ( bit = flag_lookup( word, flag_table ) ) != NO_FLAG )
	        return bit;
	    else
	        return NO_FLAG;
    }

    /*
     * Accept multiple flags.
     */
    for (; ;)
    {
        argument = one_argument( argument, word );

        if ( word[0] == '\0' )
	    break;

        if ( ( bit = flag_lookup( word, flag_table ) ) != NO_FLAG )
        {
            SET_BIT( marked, bit );
            found = TRUE;
        }
    }

    if ( found )
	return marked;
    else
	return NO_FLAG;
}



/*****************************************************************************
 Name:		flag_string( table, flags/stat )
 Purpose:	Returns string with name(s) of the flags or stat entered.
 Called by:	act_olc.c, olc.c, and olc_save.c.
 ****************************************************************************/
char *flag_string( const struct flag_type *flag_table, int bits )
{
    static char buf[512];
    int  flag;

    buf[0] = '\0';

    for (flag = 0; flag_table[flag].name != NULL && flag_table[flag].name[0] != '\0'; flag++)
    {
	if ( !is_stat( flag_table ) && IS_SET(bits, flag_table[flag].bit) )
	{
	    strcat( buf, " " );
	    strcat( buf, flag_table[flag].name );
	}
	else
	if ( flag_table[flag].bit == bits )
	{
	    strcat( buf, " " );
	    strcat( buf, flag_table[flag].name );
	    break;
	}
    }
    return (buf[0] != '\0') ? buf+1 : "none";
}


const struct flag_type trigger_flags[] =
{
	{ "char-enters",	TRIG_CHAR_ENTERS,		TRUE	},
	{ "char-speaks",	TRIG_CHAR_SPEAKS,		TRUE	},
	{ "char-leaves",	TRIG_CHAR_LEAVES,		TRUE	},
	{ "char-attacks",	TRIG_CHAR_ATTACKS,		TRUE	},
	{ "char-flees",		TRIG_CHAR_FLEES,		TRUE	},
	{ "char-gives-item",	TRIG_CHAR_GIVES,	TRUE	},
	{ "", 0 , 0 },
};

const struct flag_type area_flags[] =
{
    {	"none",			AREA_NONE,		FALSE	},
    {	"changed",		AREA_CHANGED,		TRUE	},
    {	"added",		AREA_ADDED,		TRUE	},
	{	"generated",	AREA_GENERATED,		TRUE },
	{	"no-asave",		AREA_NOASAVE,		TRUE },
	{	"loading",		AREA_LOADING,		FALSE	},
    {	"",			0,			0	}
};

const struct flag_type building_info_flags[] =
{
	{ "under-construction",		BUILDING_UNDER_CONSTRUCTION     , TRUE },
	{ "closed",					BUILDING_CLOSED,				TRUE },
	{ "locked",					BUILDING_LOCKED,				TRUE },
    { "upgrade",				BUILDING_UPGRADE,				TRUE },
	{ "", 0, 0 }
};

const struct flag_type spell_target_flags[] =
{
    { "ignore",                 TAR_IGNORE,             TRUE },
    { "offensive",              TAR_CHAR_OFFENSIVE,     TRUE },
    { "defensive",              TAR_CHAR_DEFENSIVE,     TRUE },
    { "self",                   TAR_CHAR_SELF,          TRUE },
    { "inventory item",         TAR_OBJ_INV,            TRUE },
    { "obj or char defensive",  TAR_OBJ_CHAR_DEF,       TRUE },
    { "obj or char offensive",  TAR_OBJ_CHAR_OFF,       TRUE },
    { "self or pet",            TAR_CHAR_SELF_PET,      TRUE },
    { "pet",                    TAR_PET,                TRUE },
    { "ranged",                 TAR_RANGED,             TRUE },
    { "", 0, 0 },
};

const struct flag_type building_flags[] =
{
 	{ "barracks",	BUILDING_BARRACKS   , TRUE },
 	{ "blacksmith",	BUILDING_BLACKSMITH , TRUE },
 	{ "woodsmith",	BUILDING_WOODSMITH  , TRUE },
 	{ "magelab",	BUILDING_MAGELAB    , TRUE },
 	{ "sanctum",	BUILDING_SANCTUM    , TRUE },
 	{ "watchtower",	BUILDING_WATCHTOWER , TRUE },
 	{ "wall",		BUILDING_WALL       , TRUE },
 	{ "gatehouse",	BUILDING_GATEHOUSE  , TRUE },
	{ "", 0, 0 }
};

const struct flag_type resource_flags[] =
{
	{ "antimony",		NR_ANTIMONY,	TRUE },
	{ "arsenic",		NR_ARSENIC,		TRUE },
	{ "copper",			NR_COPPER,		TRUE },
	{ "iron",			NR_IRON,		TRUE },
	{ "tin",			NR_TIN,			TRUE },
	{ "limestone",		NR_LIMESTONE,	TRUE },
	{ "coal",			NR_COAL,		TRUE },
	{ "wood",			NR_FOREST,		TRUE },
	{ "stone",			NR_STONE,		TRUE },
	{ "", 0, 0 }
};

const struct flag_type sex_flags[] =
{
    {	"male",			SEX_MALE,		TRUE	},
    {	"female",		SEX_FEMALE,		TRUE	},
    {	"neutral",		SEX_NEUTRAL,		TRUE	},
    {   "random",               3,                      TRUE    },   /* ROM */
    {	"none",			SEX_NEUTRAL,		TRUE	},
    {	"",			0,			0	}
};


const struct flag_type ranged_flags[] =
{
	{	"crossbow",		RANGE_CROSSBOW,		TRUE	},
	{	"shortbow",		RANGE_SHORTBOW,		TRUE	},
	{	"longbow",		RANGE_LONGBOW,		TRUE	},
	{	"composite longbow",	RANGE_COMPOSITE_LONGBOW,	TRUE	},
	{	"",	0,	0 }
};

const struct flag_type foundation_flags[] =
{
	{	"woodworking",	TS_WOODWORKING,		TRUE	},
	{	"metalworking",	TS_METALWORKING,	TRUE	},
	{	"leatherworking",	TS_LEATHERWORKING,	TRUE	},
	{	"stoneworking",	TS_STONEWORKING,	TRUE },
	{	"clothworking", TS_CLOTHWORKING, TRUE },
	{	"", 0, 0 }
};

const struct flag_type tradeskill_flags[] =
{
    { "apothecary",     TS_APOTHECARY,         TRUE },
    { "armorsmithing",     TS_ARMORSMITHING,      TRUE },
    { "fletching",     TS_FLETCHING,          TRUE },
    { "jewelcrafting",     TS_JEWELCRAFTING,      TRUE },
    { "tailoring",     TS_TAILORING,          TRUE },
    { "weaponsmithing",     TS_WEAPONSMITHING,     TRUE },
    { "spellcrafting",     TS_SPELLCRAFTING,      TRUE },
	{	"", 0, 0 }
};

const struct flag_type exit_flags[] =
{
    {   "door",			EX_ISDOOR,		TRUE    },
    {	"closed",		EX_CLOSED,		TRUE	},
    {	"locked",		EX_LOCKED,		TRUE	},
    {	"pickproof",	EX_PICKPROOF,	TRUE	},
	{	"simple",		EX_SIMPLE,		TRUE	},
	{	"easy",			EX_EASY,		TRUE	},
	{	"average",		EX_AVERAGE,		TRUE	},
	{	"difficult",	EX_DIFFICULT,	TRUE	},
	{	"hard",			EX_HARD,		TRUE	},
	{	"infuriating",	EX_INFURIATING,	TRUE	},
	{   "hidden",		EX_HIDDEN,		TRUE	},
    {   "fall",         EX_FALL,        TRUE    },
    {   "climb",        EX_CLIMB,       TRUE    },
    {   "holdportal",   EX_HOLD_PORTAL, TRUE    },
    {   "sheer-climb",  EX_SHEER_CLIMB, TRUE    },
    {	"",			0,			0	}
};



const struct flag_type door_resets[] =
{
    {	"open and unlocked",	0,		TRUE	},
    {	"closed and unlocked",	1,		TRUE	},
    {	"closed and locked",	2,		TRUE	},
    {	"",			0,		0	}
};

const struct flag_type quest_flags[] =
{
	{ 	"private",		QUEST_PRIVATE,		TRUE	},
	{	"yank_mob",		QUEST_YANK_MOB,		TRUE	},
	{	"one_timer",	QUEST_ONE_TIMER,	TRUE	},
    {   "consignment",  QUEST_CONSIGNMENT,  TRUE    },
	{	"",				0,					0		}
};

const struct flag_type room_flags[] =
{
    {	"dark",			ROOM_DARK,		TRUE	},
    {	"no_mob",		ROOM_NO_MOB,		TRUE	},
    {	"indoors",		ROOM_INDOORS,		TRUE	},
    {	"private",		ROOM_PRIVATE,		TRUE    },
    {	"safe",			ROOM_SAFE,		TRUE	},
    {	"solitary",		ROOM_SOLITARY,		TRUE	},
    {	"pet_shop",		ROOM_PET_SHOP,		TRUE	},
    {	"no_recall",		ROOM_NO_RECALL,		TRUE	},
    {	"imp_only",		ROOM_IMP_ONLY,		TRUE    },
    {	"gods_only",	        ROOM_GODS_ONLY,		TRUE    },
    {	"heroes_only",		ROOM_HEROES_ONLY,	TRUE	},
    {	"newbies_only",		ROOM_NEWBIES_ONLY,	TRUE	},
    {	"law",			ROOM_LAW,		TRUE	},
    {   "vault",		ROOM_CLAN_VAULT,	TRUE	},
	{	"zoned",		ROOM_ZONED,		TRUE },
    {   "noxious",      ROOM_NOXIOUS,   TRUE },
    {   "swampgas",     ROOM_SWAMP_GAS, TRUE },
    {   "arena",        ROOM_ARENA,     TRUE },
    {   "road",         ROOM_ROAD,      TRUE },
    {	"",			0,			0	}
};



const struct flag_type sector_flags[] =
{
    {	"inside",	SECT_INSIDE,		TRUE	},
    {	"city",		SECT_CITY,		TRUE	},
    {	"field",	SECT_FIELD,		TRUE	},
    {	"forest",	SECT_FOREST,		TRUE	},
    {	"hills",	SECT_HILLS,		TRUE	},
    {	"mountain",	SECT_MOUNTAIN,		TRUE	},
    {	"swim",		SECT_WATER_SWIM,	TRUE	},
    {	"noswim",	SECT_WATER_NOSWIM,	TRUE	},
    {	"air",		SECT_AIR,		TRUE	},
    {	"desert",	SECT_DESERT,		TRUE	},
    {   "ice",		SECT_ICE,		TRUE    },
	{ 	"road",		SECT_ROAD,		TRUE 	},
	{   "underground", SECT_UNDERGROUND, TRUE },
	{   "underwater",  SECT_UNDERWATER, TRUE },
    {   "magma",    SECT_MAGMA, TRUE },
    {	"",		0,			0	}
};



const struct flag_type type_flags[] =
{
    {	"light",		ITEM_LIGHT,		TRUE	},
    {	"scroll",		ITEM_SCROLL,		TRUE	},
    {	"wand",			ITEM_WAND,		TRUE	},
    {	"staff",		ITEM_STAFF,		TRUE	},
	{   "projectile",	ITEM_PROJECTILE,	TRUE	},
    {	"weapon",		ITEM_WEAPON,		TRUE	},
    {	"treasure",		ITEM_TREASURE,		TRUE	},
    {	"armor",		ITEM_ARMOR,		TRUE	},
    {	"potion",		ITEM_POTION,		TRUE	},
    {	"furniture",		ITEM_FURNITURE,		TRUE	},
    {	"trash",		ITEM_TRASH,		TRUE	},
    {	"container",		ITEM_CONTAINER,		TRUE	},
    {	"drink-container",	ITEM_DRINK_CON,		TRUE	},
    {	"key",			ITEM_KEY,		TRUE	},
    {	"food",			ITEM_FOOD,		TRUE	},
    {	"money",		ITEM_MONEY,		TRUE	},
    {	"boat",			ITEM_BOAT,		TRUE	},
    {	"npc corpse",		ITEM_CORPSE_NPC,	TRUE	},
    {	"pc corpse",		ITEM_CORPSE_PC,		FALSE	},
    {	"fountain",		ITEM_FOUNTAIN,		TRUE	},
    {	"pill",			ITEM_PILL,		TRUE	},
    {	"clothing",		ITEM_CLOTHING,		TRUE	},
    {	"protect",		ITEM_PROTECT,		TRUE	},
    {	"map",			ITEM_MAP,		TRUE	},
    {   "spellbook",		ITEM_SPELLBOOK,		TRUE	},
    {   "forge",		ITEM_FORGE,		TRUE	},
    {	"portal",		ITEM_PORTAL,		TRUE	},
    {   "gem",			ITEM_GEM,		TRUE    },
    {   "jewelry",		ITEM_JEWELRY,		TRUE    },
    {   "hide",			ITEM_HIDE,		TRUE	},
    {   "prayer-book",		ITEM_PRAYER_BOOK,	TRUE	},
    {	"arcane-scroll",	ITEM_ARCANE_SCROLL,	TRUE	},
	{ 	"instrument",		ITEM_INSTRUMENT,	TRUE	},
	{	"sheet-music",		ITEM_LYRIC_SHEET,	TRUE	},
	{	"component",		ITEM_COMPONENT,		TRUE	},
	{	"venom-sac",		ITEM_VENOM_SAC,		TRUE	},
	{	"bindstone",		ITEM_BINDSTONE,		TRUE	},
	{	"mobile",			ITEM_MOBILE,		TRUE	},
    {   "shrine",           ITEM_SHRINE,        TRUE    },
    {	"",			0,			0	}
};

const struct flag_type forge_flags[]=
{
    {   "tailoring-kit",	FORGE_TAILOR_KIT,	TRUE	},
    {   "jeweler-bag",		FORGE_JEWELER_BAG,	TRUE	},
    {   "forge",		FORGE_SMITHING_FORGE,	TRUE	},
    {	"kiln",			FORGE_KILN,		TRUE	},
    {   "fletching-kit",	FORGE_FLETCHING_KIT,	TRUE	},
    {   "oven",			FORGE_OVEN,		TRUE	},
    { 	"still",		FORGE_STILL,		TRUE	},
    {   "chemist-lab",		FORGE_CHEMIST_LAB,	TRUE	},
    {	"",			0,			0	}
};

const struct flag_type portal_flags[]=
{
    {	"normal",		GATE_NORMAL_EXIT,	TRUE	},
    {   "nocurse",		GATE_NOCURSE,		TRUE	},
    {   "gowith",		GATE_GOWITH,		TRUE	},
    {   "buggy",		GATE_BUGGY,		TRUE	},
    {   "random",		GATE_RANDOM,		TRUE	},
    {	"",			0,			0	},
};

const struct flag_type furniture_flags[]=
{
    {   "stand-at",		STAND_AT,		TRUE	},
    {   "stand-on",		STAND_ON,		TRUE	},
    {   "stand-in",		STAND_IN,		TRUE	},
    {   "sit-at",		SIT_AT ,		TRUE	},
    {   "sit-on",		SIT_ON,			TRUE	},
    {   "sit-in",		SIT_IN,			TRUE	},
    {   "rest-at",		REST_AT,		TRUE	},
    {   "rest-on",		REST_ON,		TRUE	},
    {   "rest-in",		REST_IN,		TRUE	},
    {   "sleep-at",		SLEEP_AT,		TRUE	},
    {   "sleep-on",		SLEEP_ON,		TRUE	},
    {   "sleep-in",		SLEEP_IN,		TRUE	},
    {   "put-at",		PUT_AT ,		TRUE	},
    {   "put-on",		PUT_ON,			TRUE	},
    {   "put-in",		PUT_IN,			TRUE	},
    {   "put-inside",		PUT_INSIDE,		TRUE	},
    {   "",			0,			0	}
};

const struct flag_type extra_flags[] =
{
    {	"invis",		    ITEM_INVIS,		        TRUE },
    {	"magic",		    ITEM_MAGIC,		        TRUE },
    {	"nodrop",		    ITEM_NODROP,		    TRUE },
    {	"anti-good",		ITEM_ANTI_GOOD,		    TRUE },
    {	"anti-evil",		ITEM_ANTI_EVIL,		    TRUE },
    {	"anti-neutral",		ITEM_ANTI_NEUTRAL,	    TRUE },
    {	"nopurge",		    ITEM_NOPURGE,		    TRUE },
    {	"rot-death",		ITEM_ROT_DEATH,		    TRUE },
    {	"vis-death",		ITEM_VIS_DEATH,		    TRUE },
    {	"keep-condition",	ITEM_KEEP_CONDITION,	TRUE },
    {   "lore",             ITEM_UNIQUE,            TRUE },
    {   "unique",		    ITEM_UNIQUE,		    TRUE },
	{   "extract-on-sale",	ITEM_SELL_EXTRACT,	    TRUE },
    {   "burn-proof",       ITEM_BURN_PROOF,        TRUE }, 
    {   "sticky",           ITEM_STICKY,            TRUE },
    {   "no-rent",		    ITEM_NORENT,		    TRUE },
	{	"no-lore",		    ITEM_NOLORE,		    TRUE },
    {   "no-show",          ITEM_NOSHOW,            TRUE },
    {   "inventory",        ITEM_INVENTORY,         TRUE },
    {	"",			0,			0	}
};



const struct flag_type wear_flags[] =
{
    {	"take",			ITEM_TAKE,		TRUE	},
    {	"finger",		ITEM_WEAR_FINGER,	TRUE	},
    {	"neck",			ITEM_WEAR_NECK,		TRUE	},
    {	"torso",		ITEM_WEAR_BODY,		TRUE	},
    {	"head",			ITEM_WEAR_HEAD,		TRUE	},
    {	"legs",			ITEM_WEAR_LEGS,		TRUE	},
    {	"feet",			ITEM_WEAR_FEET,		TRUE	},
    {	"hands",		ITEM_WEAR_HANDS,	TRUE	},
    {	"arms",			ITEM_WEAR_ARMS,		TRUE	},
    {	"shield",		ITEM_WEAR_SHIELD,	TRUE	},
    {	"back", 		ITEM_WEAR_ABOUT,	TRUE	},
    {	"waist",		ITEM_WEAR_WAIST,	TRUE	},
    {	"wrist",		ITEM_WEAR_WRIST,	TRUE	},
    {	"wield",		ITEM_WIELD,		TRUE	},
    {	"hold",			ITEM_HOLD,		TRUE	},
    {   "ear",			ITEM_WEAR_EAR,		TRUE	},
    {   "face",			ITEM_WEAR_FACE,		TRUE	},
    {   "shoulders",		ITEM_WEAR_SHOULDERS,	TRUE	},
    {   "float",		ITEM_WEAR_FLOAT,		TRUE	},
	{ 	"offhand",		ITEM_WEAR_OFFHAND,		TRUE	},
	{	"ranged",		ITEM_WEAR_RANGED,		TRUE 	},
	{	"instrument",	ITEM_WEAR_INSTRUMENT,	TRUE	},
	{	"no-sac",		ITEM_NO_SAC,			TRUE },
    {	"",			0,			0	}
};




/*
 * Used when adding an affect to tell where it goes.
 * See addaffect and delaffect in act_olc.c
 */
const struct flag_type apply_flags[] =
{
    {	"none",			APPLY_NONE,		TRUE	},
	{	"stamina",		APPLY_STAMINA,	TRUE	},
    {	"strength",		APPLY_STR,		TRUE	},
    {	"dexterity",	APPLY_DEX,		TRUE	},
    {	"intelligence",	APPLY_INT,		TRUE	},
    {	"wisdom",		APPLY_WIS,		TRUE	},
    {	"constitution",	APPLY_CON,		TRUE	},
    {	"mana",			APPLY_MANA,		TRUE	},
    {	"hp",			APPLY_HIT,		TRUE	},
    {	"move",			APPLY_MOVE,		TRUE	},
    {	"ac",			APPLY_AC,		TRUE	},
    {	"hitroll",		APPLY_HITROLL,		TRUE	},
    {	"damroll",		APPLY_DAMROLL,		TRUE	},
    {   "charisma",		APPLY_CHA,		TRUE	},
    {   "fortitude",	APPLY_SAVE_FORTITUDE,	TRUE	},
    {   "willpower",	APPLY_SAVE_WILLPOWER,	TRUE	},
    {	"reflex",		APPLY_SAVE_REFLEX,	TRUE	},
    {   "resist-fire",	APPLY_RES_FIRE,	TRUE	},
    {	"resist-ice",	APPLY_RES_ICE,	TRUE	},
    {	"resist-earth",	APPLY_RES_EARTH,	TRUE	},
    {	"resist-air",	APPLY_RES_AIR,	TRUE	},
    {	"resist-poison",APPLY_RES_POISON,	TRUE	},
    {	"resist-disease",   APPLY_RES_DISEASE,	TRUE	},
    {	"resist-light",	APPLY_RES_LIGHT,		TRUE	},
	{ 	"resist-dark",	APPLY_RES_DARK,			TRUE },
    {	"resist-water",	APPLY_RES_WATER,		TRUE },
    {	"resist-acid",	APPLY_RES_ACID,	TRUE	},
    {	"resist-mental",APPLY_RES_MENTAL,	TRUE	},
    {	"resist-energy",APPLY_RES_ELECTRICITY,	TRUE	},
    {   "resist-spirit",APPLY_RES_SPIRIT,	TRUE	},
	{ 	"resist-sound",	APPLY_RES_SOUND,	TRUE	},
	{	"resist-body",	APPLY_RES_BODY,	TRUE	},
	{	"basehit",		APPLY_BASE_HITS, TRUE	},
    {   "skill",        APPLY_SKILL, TRUE },
    {   "absorb",       APPLY_ABSORB, TRUE },
    {   "stamina",      APPLY_STAMINA, TRUE },
    {   "speed",        APPLY_SPEED, TRUE },
    {   "regen-base",   APPLY_REGEN_BASE,   TRUE },
    {   "regen-hp",     APPLY_REGEN_HP, TRUE },
    {   "regen-stamina",APPLY_REGEN_STAMINA,    TRUE },
    {   "movement-rate",APPLY_MOVE_RATE, TRUE },
    {   "root",         APPLY_ROOT, TRUE },
    {	"",			0,			0	}
};



/*
 * What is seen.
 */
const struct flag_type wear_loc_strings[] =
{
    {	"in the inventory",	WEAR_NONE,	TRUE	},
    {	"as a light",		WEAR_LIGHT,	TRUE	},
    {	"on the left finger",	WEAR_FINGER_L,	TRUE	},
    {	"on the right finger",	WEAR_FINGER_R,	TRUE	},
    {	"around the neck (1)",	WEAR_NECK_1,	TRUE	},
    {	"around the neck (2)",	WEAR_NECK_2,	TRUE	},
    {	"on the torso",   	WEAR_BODY,	TRUE	},
    {	"over the head",	WEAR_HEAD,	TRUE	},
    {	"on the legs",		WEAR_LEGS,	TRUE	},
    {	"on the feet",		WEAR_FEET,	TRUE	},
    {	"on the hands",		WEAR_HANDS,	TRUE	},
    {	"on the arms",		WEAR_ARMS,	TRUE	},
    {	"as a shield",		WEAR_SHIELD,	TRUE	},
    {	"on the back",	        WEAR_ABOUT,	TRUE	},
    {	"around the waist",	WEAR_WAIST,	TRUE	},
    {	"on the left wrist",	WEAR_WRIST_L,	TRUE	},
    {	"on the right wrist",	WEAR_WRIST_R,	TRUE	},
    {	"wielded",		WEAR_WIELD,	TRUE	},
    {	"held in the hands",	WEAR_HOLD,	TRUE	},
    {   "in the left ear",	WEAR_EAR_L,	TRUE	},
    {   "in the right ear",	WEAR_EAR_R,	TRUE	},
    {   "over the face",	WEAR_FACE,	TRUE	},
    {   "on the shoulders",	WEAR_SHOULDERS,	TRUE	},
	{	"wielded offhand",	WEAR_OFFHAND,	TRUE	},
	{	"ranged weapon",	WEAR_RANGED,	TRUE	},
	{	"bard instrument",	WEAR_INSTRUMENT,	TRUE	},
    {	"",			0			}
};


const struct flag_type wear_loc_flags[] =
{
    {	"none",		WEAR_NONE,	TRUE	},
    {	"light",	WEAR_LIGHT,	TRUE	},		/* 1 */
    {	"lfinger",	WEAR_FINGER_L,	TRUE	},
    {	"rfinger",	WEAR_FINGER_R,	TRUE	},
    {	"neck1",	WEAR_NECK_1,	TRUE	},
    {	"neck2",	WEAR_NECK_2,	TRUE	},	/* 5 */
    {	"torso",	WEAR_BODY,	TRUE	},
    {	"head",		WEAR_HEAD,	TRUE	},
    {	"legs",		WEAR_LEGS,	TRUE	},
    {	"feet",		WEAR_FEET,	TRUE	},
    {	"hands",	WEAR_HANDS,	TRUE	},	/* 10 */
    {	"arms",		WEAR_ARMS,	TRUE	},
    {	"shield",	WEAR_SHIELD,	TRUE	},
    {	"back",		WEAR_ABOUT,	TRUE	},
    {	"waist",	WEAR_WAIST,	TRUE	},
    {	"lwrist",	WEAR_WRIST_L,	TRUE	},	/* 15 */
    {	"rwrist",	WEAR_WRIST_R,	TRUE	},
    {	"wielded",	WEAR_WIELD,	TRUE	},
	{	"hold",		WEAR_HOLD,	 TRUE },
	{	"float",	WEAR_FLOAT,	TRUE },
	{	"left-ear",		WEAR_EAR_L,	TRUE },
	{	"right-ear",	WEAR_EAR_R,	TRUE },
    {   "face",     WEAR_FACE,  TRUE    },
    {   "shoulders",    WEAR_SHOULDERS, TRUE    },
    {   "offhand",  WEAR_OFFHAND, TRUE },
	{	"ranged",	WEAR_RANGED, TRUE},
	{	"instrument",	WEAR_INSTRUMENT, TRUE },
    {	"",		0,		0	}	/* 25 */
};



const struct flag_type weapon_flags[] =
{
    {	"hit",		0,	TRUE	},
    {	"slice",	1,	TRUE	},
    {	"stab",		2,	TRUE	},
    {	"slash",	3,	TRUE	},
    {	"whip",		4,	TRUE	},
    {	"claw",		5,	TRUE	},
    {	"blast",	6,	TRUE	},
    {	"pound",	7,	TRUE	},
    {	"crush",	8,	TRUE	},
    {	"grep",		9,	TRUE	},
    {	"bite",		10,	TRUE	},
    {	"pierce",	11,	TRUE	},
    {	"suction",	12,	TRUE	},
    {	"beating",	13,	TRUE	},  /* ROM */
    {	"digestion",	14,	TRUE	},
    {	"charge",	15,	TRUE	},
    {	"slap",		16,	TRUE	},
    {	"punch",	17,     TRUE	},
    {	"wrath",	18,	TRUE	},
    {	"magic",	19,	TRUE	},
    {	"divine-power",	20,	TRUE	},
    {	"cleave",	21,	TRUE	},
    {	"scratch",	22,	TRUE	},
    {	"peck-pierce",  23,	TRUE	},
    {	"peck-bash",	24,	TRUE	},
    {	"chop",		25,	TRUE	},
    {	"sting",	26,	TRUE	},
    {	"smash",	27,	TRUE	},
    {	"sho-bite", 28,	TRUE	},
    {	"fro-bite",	 29,	TRUE	},
    {	"fre-bite", 30,	TRUE    },
    {	"acidic-bite",	31,	TRUE	},
    {	"chomp",	32,	TRUE	},
    {   "drain",        33,	TRUE	},
    {   "thrust", 	34,	TRUE	},
    {   "slime",   	35,	TRUE	},
    {   "shock",    	36,	TRUE	},
    {   "thwack",    	37,	TRUE	},
    {   "flame",       	38,	TRUE	},
    {   "burn",    		39, TRUE	},
    {   "scorch",		40, TRUE	},
    {   "chill",		41, TRUE	},
    {   "freeze",		42, TRUE	},
    {   "quake",    	43, TRUE	},
    {   "trample", 		44, TRUE	},
    {   "torrent",		45, TRUE	},
    {   "drown", 		46, TRUE	},
    {   "suffocate",	47, TRUE	},
	{	"gore",			48, TRUE	},
    {   "cut",          49, TRUE    },
    {   "lash",         50, TRUE    },
    {   "bash",         51, TRUE    },
    {   "carve",        52, TRUE    },
    {   "gash",         53, TRUE    },
    {   "hack",         54, TRUE    },
    {   "jab",          55, TRUE    },
    {   "spear",        56, TRUE    },
    {   "flay",         57, TRUE    },
    {   "scourge",      58, TRUE    },
    {   "thrash",       59, TRUE    },
    {	"",		0,	TRUE	}
};


const struct flag_type container_flags[] =
{
    {	"closeable",		CONT_CLOSEABLE,		TRUE	},
    {	"pickproof",		CONT_PICKPROOF,		TRUE	},
    {	"closed",		CONT_CLOSED,		TRUE	},
    {	"locked",		CONT_LOCKED,		TRUE	},
	{	"quiver",		CONT_QUIVER,		TRUE },
    {	"",			0,		0	}
};






/*****************************************************************************
                      ROM - specific tables:
 ****************************************************************************/


const struct flag_type ac_type[] =
{
    {   "pierce",        AC_PIERCE,            TRUE    },
    {   "bash",          AC_BASH,              TRUE    },
    {   "slash",         AC_SLASH,             TRUE    },
    {   "exotic",        AC_EXOTIC,            TRUE    },
    {   "",              0,                    0       }
};


const struct flag_type size_flags[] =
{
    {   "tiny",          SIZE_TINY,            TRUE    },
    {   "small",         SIZE_SMALL,           TRUE    },
    {   "medium",        SIZE_MEDIUM,          TRUE    },
    {   "large",         SIZE_LARGE,           TRUE    },
    {   "huge",          SIZE_HUGE,            TRUE    },
    {   "giant",         SIZE_GIANT,           TRUE    },
    {   "",              0,                    0       },
};


const struct flag_type weapon_class[] =
{
   { "exotic",		0,	TRUE },
   { "dirk",		WEAPON_DIRK, TRUE },
   { "dagger",  	WEAPON_DAGGER, TRUE },
   { "stilleto",	WEAPON_STILLETO, TRUE },
   { "main-gauche",	WEAPON_MAIN_GAUCHE, TRUE },
   { "knife",		WEAPON_KNIFE, TRUE },
  
   { "rapier",		WEAPON_RAPIER, TRUE },
   { "shortsword",	WEAPON_SHORTSWORD, TRUE },
   { "gladius",		WEAPON_GLADIUS, TRUE },
   { "drusus",		WEAPON_DRUSUS, TRUE },

   { "scimitar",	WEAPON_SCIMITAR, TRUE },
   { "cutlass",		WEAPON_CUTLASS, TRUE },
   { "falchion",	WEAPON_FALCHION, TRUE },
   { "broadsword",	WEAPON_BROADSWORD, TRUE },

   { "longsword",	WEAPON_LONGSWORD, TRUE },
   { "bastard sword",	WEAPON_BASTARD_SWORD, TRUE },
   { "claymore",	WEAPON_CLAYMORE, TRUE },
   { "two-handed sword",WEAPON_2H_SWORD, TRUE },

   { "mace",		WEAPON_MACE, TRUE },
   { "flail",		WEAPON_FLAIL, TRUE },
   { "warhammer",	WEAPON_WARHAMMER, TRUE },

   { "morningstar",	WEAPON_MORNINGSTAR, TRUE },
   { "two-handed hammer",WEAPON_2H_WARHAMMER, TRUE },

   { "hand axe",	WEAPON_THROWING_AXE, TRUE },
   { "battle axe",	WEAPON_BATTLE_AXE, TRUE },
   { "two-handed axe",WEAPON_2H_WARAXE, TRUE },

   { "spear",		WEAPON_SPEAR, TRUE },
   { "javelin",		WEAPON_JAVELIN, TRUE },
   { "harpoon",		WEAPON_HARPOON, TRUE },

   { "crossbow",	WEAPON_CROSSBOW, TRUE },
   { "shortbow",	WEAPON_SHORTBOW, TRUE },
   { "longbow",		WEAPON_LONGBOW, TRUE },
   { "composite bow",   WEAPON_COMPOSITE_LONGBOW, TRUE },

   { "staff",		WEAPON_STAFF, TRUE },

   { "lance",		WEAPON_LANCE, TRUE },
   { "trident",		WEAPON_TRIDENT, TRUE },
   { "halberd",		WEAPON_HALBERD, TRUE },
   { "voulge",		WEAPON_VOULGE, TRUE },
   { "pike",		WEAPON_PIKE, TRUE },
   { "glaive",		WEAPON_GLAIVE, TRUE },
   { "ranseur",		WEAPON_RANSEUR, TRUE },
   { "whip",		WEAPON_WHIP, TRUE },
   { "maul",		WEAPON_MAUL, TRUE },
   { "club",		WEAPON_CLUB, TRUE },
   { "machete",		WEAPON_MACHETE, TRUE },
   { "hatchet",		WEAPON_HATCHET, TRUE },
   { "bardiche",	WEAPON_BARDICHE, TRUE },
   { "pickaxe",		WEAPON_PICK, TRUE },
   { "mallet",		WEAPON_MALLET, TRUE },
   { "sabre",		WEAPON_SABRE,	TRUE },
   { "claw",		WEAPON_CLAW,	TRUE },
   { "sickle",		WEAPON_SICKLE,	TRUE },
   { "scythe",		WEAPON_SCYTHE, TRUE },
   { "quarterstaff",WEAPON_QUARTERSTAFF, TRUE },
   { "katana",		WEAPON_KATANA, TRUE },
   { "sai",			WEAPON_SAI,	TRUE },
   { "wakizashi",	WEAPON_WAKIZASHI, TRUE },
   { "naginata",	WEAPON_NAGINATA, TRUE },
   { "diakyu",		WEAPON_DIAKYU, TRUE },
   { "bo stick",	WEAPON_BO_STICK, TRUE },
   { "tetsubo",		WEAPON_TETSUBO, TRUE },
   { "hook",		WEAPON_HOOK, TRUE },
   { "fang",        WEAPON_FANG, TRUE },
   { "chain",       WEAPON_CHAIN, TRUE },
   { "tail",        WEAPON_TAIL, TRUE },

   { NULL,			0, FALSE }
};

const struct flag_type weapon_type_olc[] =
{
    {   "sharp",         WEAPON_SHARP,         TRUE    },
    {   "two-hands",     WEAPON_TWO_HANDS,     TRUE    },
	{   "one-time-proc", WEAPON_ONE_TIME_PROC, TRUE    },
    {   "declining-proc",WEAPON_DECLINING_PROC,TRUE    },
    {   "",              0,                    0       }
};

const struct flag_type dam_flags[] =
{
 	{ "unknown",		DAM_NONE,			TRUE		},
 	{ "none",			DAM_NONE,			TRUE		},
 	{ "bash",			DAM_BASH,			TRUE		},
 	{ "pierce",			DAM_PIERCE,			TRUE		},
 	{ "slash",			DAM_SLASH,			TRUE		},
 	{ "fire",			DAM_FIRE,			TRUE		},
 	{ "cold",			DAM_COLD,			TRUE		},
 	{ "energy",			DAM_LIGHTNING,		TRUE		},
 	{ "acid",			DAM_ACID,			TRUE		},
 	{ "poison",			DAM_POISON,			TRUE		},
 	{ "earth",			DAM_EARTH,			TRUE		},
 	{ "air",			DAM_AIR,			TRUE		},
 	{ "mental",			DAM_MENTAL,			TRUE		},
 	{ "disease",		DAM_DISEASE,		TRUE		},
	{ "dark",			DAM_DARK,			TRUE		},
 	{ "water",			DAM_WATER,			TRUE		},
 	{ "light",			DAM_LIGHT,			TRUE		},
 	{ "sound",			DAM_SOUND,			TRUE		},
 	{ "spirit",			DAM_SPIRIT,			TRUE		},
	{ "body",			DAM_BODY,			TRUE		},
 	{ "other",			DAM_OTHER,			TRUE		},
	{ "",				0,					FALSE		}
};

const struct flag_type material_type[] =    /* not yet implemented */
{
    {   "none",         0,	    	TRUE    },
    {   "steel",        MAT_STEEL,      TRUE    },
    {   "stone",	MAT_STONE,	TRUE    },
    {   "brass",	MAT_BRASS,	TRUE    },
    {   "bone",	 	MAT_BONE,	TRUE    },
    {   "energy",	MAT_ENERGY,	TRUE    },
    {	"mithril",	MAT_MITHRIL,	TRUE	},
    {	"copper",	MAT_COPPER,	TRUE	},
    {	"silk",		MAT_SILK,	TRUE	},
    {	"marble",	MAT_MARBLE,	TRUE	},
    {	"glass",	MAT_GLASS,	TRUE	},
    {	"water",	MAT_WATER,	TRUE	},
    {	"flesh",	MAT_FLESH,	TRUE	},
    {	"platinum",	MAT_PLATINUM,	TRUE	},
    {	"granite",	MAT_GRANITE,	TRUE	},
    {	"leather",	MAT_LEATHER,	TRUE	},
    {	"cloth",	MAT_CLOTH,	TRUE	},
    {	"gemstone",	MAT_GEMSTONE,	TRUE	},
    {	"gold",		MAT_GOLD,	TRUE	},
    {	"porcelain",	MAT_PORCELAIN,	TRUE	},
    {	"obsidian",	MAT_OBSIDIAN,	TRUE	},
    {	"dragonscale",	MAT_DRAGONSCALE,TRUE	},
    {	"ebony",	MAT_EBONY,	TRUE	},
    {	"bronze",	MAT_BRONZE,	TRUE	},
    {	"wood",		MAT_WOOD,	TRUE	},
    {	"silver",	MAT_SILVER,	TRUE	},
    {	"iron",		MAT_IRON,	TRUE	},
    {	"bloodstone",	MAT_BLOODSTONE,	TRUE	},
    {	"food",		MAT_FOOD,	TRUE	},
    {	"lead",		MAT_LEAD,	TRUE	},
    {	"wax",		MAT_WAX,	TRUE	},
    {   "pewter",	MAT_PEWTER,	TRUE	},
    {   "fur",		MAT_FUR,	TRUE	},
	{	"parchment",	MAT_PARCHMENT,	TRUE },
	{	"hide",		MAT_HIDE,	TRUE },
	{	"clay",		MAT_CLAY,	TRUE },
    {   "scale",    MAT_SCALE,  TRUE },
    {   "organic",  MAT_ORGANIC_M,    TRUE },
    {   NULL,            0,             0       }
};


const struct flag_type position_flags[] =
{
    {   "dead",           POS_DEAD,            FALSE   },
    {   "mortal",         POS_MORTAL,          FALSE   },
    {   "incap",          POS_INCAP,           FALSE   },
    {   "stunned",        POS_STUNNED,         FALSE   },
    {   "sleeping",       POS_SLEEPING,        TRUE    },
    {   "resting",        POS_RESTING,         TRUE    },
    {   "sitting",        POS_SITTING,         TRUE    },
    {   "fighting",       POS_FIGHTING,        FALSE   },
    {   "standing",       POS_STANDING,        TRUE    },
    {   "",              0,                    0       }
};

const struct flag_type resist_flags[] =
{
    { "fire", 	RESIST_FIRE,	TRUE	},
    { "ice",	RESIST_ICE,	TRUE	},
    { "earth",	RESIST_EARTH,	TRUE	},
    { "air",	RESIST_AIR,	TRUE	},
    { "light",	RESIST_LIGHT,	TRUE	},
    { "dark",	RESIST_DARK,	TRUE	},
    { "poison",	RESIST_POISON,	TRUE	},
    { "disease",RESIST_DISEASE,	TRUE	},
    { "mental",	RESIST_MENTAL,	TRUE	},
    { "acid",	RESIST_ACID,	TRUE	},
    { "energy",RESIST_ELECTRICITY,	TRUE	},
    { "spirit",	RESIST_SPIRIT,	TRUE	},
	{ "sound",	RESIST_SOUND,	TRUE	},
	{ "water",	RESIST_WATER,	TRUE	},
	{ "body",	RESIST_BODY,  TRUE },
    { "slashing", RESIST_SLASH, TRUE	},
	{ "piercing", RESIST_PIERCE, 	TRUE	},
	{ "concussion", RESIST_CONCUSSION, TRUE },
    { NULL,	0,		FALSE	}
};

const struct flag_type rank_flags[] =
{
	{ "dissolve",	GCOP_DISSOLVE,	TRUE },
	{ "invite",		GCOP_INVITE,	TRUE },
	{ "password",	GCOP_PASSWORD,	TRUE },
	{ "rank",		GCOP_RANK,		TRUE },
	{ "remove",		GCOP_REMOVE,	TRUE },
	{ "set",		GCOP_SET,		TRUE },
	{ "guildchat",	GCOP_USE_GUILDCHAT,	TRUE },
	{ "allychat",	GCOP_USE_ALLYCHAT,	TRUE },
	{ "convert",	GCOP_CONVERT,		TRUE },
	{ "deposit",	GCOP_DEPOSIT,		TRUE },
	{ "withdraw",	GCOP_WITHDRAW,		TRUE },
	{ "claim",		GCOP_CLAIM,			TRUE },
	{ "build",		GCOP_BUILD,			TRUE },
	{ "demolish",	GCOP_DEMOLISH,		TRUE },
	{ "hall",		GCOP_HALL,			TRUE },
	{ "upgrade",	GCOP_UPGRADE,		TRUE },
	{ NULL,0,FALSE}
};

const struct	flag_type	instrument_types[] =
{
	{ "percussion",		INSTR_PERCUSSION,	TRUE	},
	{ "strings",		INSTR_STRINGS,		TRUE	},
	{ "winds",			INSTR_WINDS,		TRUE	},
	{ NULL,0,FALSE }
};


/*
const struct flag_type pref_flags [] =
{
	{ "automation",	PREF_AUTOMATION,	TRUE },
	{ "combat",		PREF_COMBAT,		TRUE },
	{ "communication",	PREF_COMMUNICATION,	TRUE },
	{ "display",		PREF_DISPLAY,	TRUE },
	{ "equipment",		PREF_EQUIPMENT,	TRUE },
	{ "options",		PREF_OPTIONS,	TRUE },
	{ "prompt",			PREF_PROMPT,	TRUE },
	{ NULL, 0 , FALSE }
};
*/

const struct flag_type spell_flags [] =
{
    { "verbal",         COM_VER,                TRUE },
    { "somatic",        COM_SOM,                TRUE },
    { "material",       COM_MAT,                TRUE },
    { "divine",         COM_DIVINE,             TRUE },
    { "arcane",         COM_ARCANE,             TRUE },
    { "same-deity",     COM_SAME_DEITY,         TRUE },
    { "same-align",     COM_SAME_ALIGN,         TRUE },
    { "not-same-deity", COM_NOT_SAME_DEITY,     TRUE },
    { NULL, 0, FALSE }
};

const struct flag_type aff_where_flags [] =
{
    { "to-affects",         TO_AFFECTS,     TRUE },
    { "to-object",          TO_OBJECT,      TRUE },
    { "to-immune",          TO_IMMUNE,      TRUE },
    { "to-weapon",          TO_WEAPON,      TRUE },
    { "damage-over-time",   DAMAGE_OVER_TIME, TRUE },
    { "saves-bonus",        SAVES_BONUS,    TRUE },
    { "damage-shield",      DAMAGE_SHIELD,  TRUE },
    { NULL, 0, FALSE}
};

const struct flag_type aff_flags [] =
{
    { "spell",          AFF_SPELL,          TRUE },
    { "skill",          AFF_SKILL,          TRUE },
    { "damage-shield",  AFF_DAMAGE_SHIELD,  TRUE },
    { "ability",        AFF_ABIL,           TRUE },
    { "pulse",          AFF_PULSE,          TRUE },
    { "not-same-deity", AFF_NOT_SAME_DEITY, TRUE },
    { "not-opposite-align", AFF_NOT_OPPOSITE_ALIGN,         TRUE },
    { "non-spell",      AFF_NONSPELL,       TRUE },
    { "negative",       AFF_NEGATIVE,       TRUE },
    { "absolute-time",  AFF_ABSOLUTE_TIME,  TRUE },
    { NULL, 0, FALSE }
};

const struct flag_type starting_weapon_flags[] = 
{
    { "thrusting-shortblades",  VNUM_WEAPON_THRUSTING_SHORT,        TRUE },
    { "thrusting-longblades",   VNUM_WEAPON_THRUSTING_LONG,         TRUE },
    { "slashing-shortblades",   VNUM_WEAPON_SLASHING_SHORT,         TRUE },
    { "slashing-longblades",    VNUM_WEAPON_SLASHING_LONG,          TRUE },
    { "one-handed-concussion",  VNUM_WEAPON_1H_CONCUSSION,          TRUE },
    { "two-handed-concussion",  VNUM_WEAPON_2H_CONCUSSION,          TRUE },
    { "axe",                    VNUM_WEAPON_AXE,                    TRUE },
    { "polearm",                VNUM_WEAPON_POLEARM,                TRUE },
    { "staff",                  VNUM_WEAPON_STAFF,                  TRUE },
    { "whip",                   VNUM_WEAPON_WHIP,                   TRUE },
    { "spear",                  VNUM_WEAPON_SPEAR,                  TRUE },
    { NULL, 0 , FALSE}
};

const struct flag_type spell_type_flags[] =
{
    { "buff",                   SPELL_BUFF,     TRUE },
    { "debuff",                 SPELL_DEBUFF,   TRUE },
    { "dot",                    SPELL_DEBUFF,   TRUE },
    { "nuke",                   SPELL_NUKE,     TRUE }, 
    { "combo (nuke+debuff)",    SPELL_COMBO_NUKE,    TRUE },
    { "bolt",                   SPELL_BOLT,     TRUE },
    { NULL, 0, FALSE }

};

const struct flag_type savingthrow_flags[] =
{
    { "fortitude",      SAVE_FORTITUDE, TRUE },
    { "willpower",      SAVE_WILLPOWER, TRUE },
    { "reflex",         SAVE_REFLEX,    TRUE },
    { NULL, 0, FALSE }
};

const struct flag_type note_flags[] =
{
    { "note",           NOTE_NOTE, TRUE },
    { "idea",           NOTE_IDEA, TRUE },
    { "penalty",        NOTE_PENALTY, TRUE },
    { "news",           NOTE_NEWS, TRUE },
    { "change",         NOTE_CHANGES, TRUE },
    { "bug",            NOTE_BUG, TRUE },
    { "appeal",         NOTE_APPEAL, TRUE },
    { "admin note",     NOTE_ADMIN, TRUE },
    { "clan note",      NOTE_CLAN, TRUE },
    { "fix",            NOTE_FIX, TRUE },
    { "todo",           NOTE_TODO, TRUE },
    { "gamepatch",      NOTE_PATCH, TRUE },
    { "system message", NOTE_SYSTEM, TRUE },
    { "world note",     NOTE_WORLD, TRUE },
    { "offline note",   NOTE_OFFLINE, TRUE },
    { NULL, 0, FALSE }
};
