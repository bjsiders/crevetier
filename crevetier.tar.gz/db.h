/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,       *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                       *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael       *
 *  Chastain, Michael Quan, and Mitchell Tse.                   *
 *                                       *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                           *
 *                                       *
 *  Much time and thought has gone into this software and you are       *
 *  benefitting.  We hope that you share your changes too.  What goes       *
 *  around, comes around.                           *
 ***************************************************************************/
 
/***************************************************************************
*    ROM 2.4 is copyright 1993-1998 Russ Taylor               *
*    ROM has been brought to you by the ROM consortium           *
*        Russ Taylor (rtaylor@hypercube.org)                   *
*        Gabrielle Taylor (gtaylor@hypercube.org)               *
*        Brian Moore (zump@rom.org)                       *
*    By using this code, you have agreed to follow the terms of the       *
*    ROM license, in the file Rom24/doc/rom.license               *
***************************************************************************/

#ifndef db_h
#define db_h

/* vals from db.c */
extern bool         fBootDb;
extern int          newmobs;
extern int          newrecipes;
extern int          newobjs;
extern MobIndex *   mob_index_hash[MAX_KEY_HASH];
extern SpellIndex * spell_index_hash[MAX_KEY_HASH];
extern ObjIndex *   obj_index_hash[MAX_KEY_HASH];
extern int          top_mob_index;
extern int          top_spell_vnum;
extern int          top_spell_index;
extern int          top_obj_index;
extern int          top_affect;
extern int          top_ed; 
extern Area *       area_first;


/* from db2.c */
extern int  social_count;
extern int  spell_count;

/* conversion from db.h */
void    convert_mob(MobIndex *mob);
void    convert_obj(ObjIndex *obj);

/* macro for flag swapping */
#define GET_UNSET(flag1,flag2)    (~(flag1)&((flag1)|(flag2)))

/* Magic number for memory allocation */
#define MAGIC_NUM 52571214

/* inserted for OLC */
/* func from db.c */
extern void assign_area_vnum( int vnum );                    /* OLC */



/* from db2.c */
 
void convert_mobile( MobIndex *pMobIndex );            /* OLC ROM */
void convert_objects( void );                                /* OLC ROM */
void convert_object( ObjIndex *pObjIndex );            /* OLC ROM */

#endif /* db_h */
