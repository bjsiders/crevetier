/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "thoc.h"
#include "olc.h"

void do_initialize_gui(Character *ch, char *argument)
{
  char arg[MAX_INPUT_LENGTH],buffer[MAX_STRING_LENGTH];
  int pos;

  if ( IS_NPC(ch) )
    return;
  
  /* We do this so that the player cannot manually start initialization.
     This may change is we want them to be able to. */
  /*if(!IS_SET(ch->gui, GUI_CHECK))
  {
    send_to_char( "Huh?\n\r", ch );
    return;
  }*/

  argument = one_argument(argument,arg);

  /* If do not use an argument tell the state of plugins */
  if (arg[0] == '\0')
  {
    send_to_char("Syntax: guiinit [show|plugin]\n\r",ch);
    send_to_char("plugin: toggle plugin on|off\n\r",ch);
    return;
  }

  if(!strcmp(arg,"show"))
  {
    send_to_char("Plugins:\n\r",ch);

    /* Friends list */
    if(IS_SET(ch->gui, GUI_FRIENDS))
    {
      send_to_char("Friends List: Enabled\n\r",ch);
    }
    else
    {
      send_to_char("Friends List: Disabled\n\r",ch);
    }

    return;
  }

  /* Friends list */
  /* We use an off and on parameter to keep the state consistent with the plugin.
     The plugin sends guiinit friends on/off while the player merely need to type
     guiinit friends to toggle the setting. */
  if(!strcmp(arg,"friends"))
  {
    one_argument(argument,arg);
    
    if(!strcmp(arg,"off"))
    {
      if(IS_SET(ch->gui, GUI_FRIENDS))
      {
        REMOVE_BIT(ch->gui, GUI_FRIENDS);
        send_to_char("Friends List: Disabled\n\r",ch);
      }
    }
    /* This can be called by a player but shouldn't, if they do then fuck em */
    else if(!strcmp(arg,"on"))
    {
      if(!IS_SET(ch->gui, GUI_FRIENDS))
      {
        SET_BIT(ch->gui, GUI_FRIENDS);
        send_to_char("Friends List: Enabled\n\r",ch);
        
        /* Send our name first so the plugin can use it */
        sprintf(buffer,"<FriendsInitName> %s\n\r",ch->name);
        send_to_char(buffer,ch);
        
        /* Send all of the names of our friends */
        for (pos = 0; pos < MAX_FRIENDS; pos++)
        {
          if (ch->pcdata->friends[pos] == NULL)
            break;
          
          sprintf(buffer,"<FriendsInit> %s\n\r",ch->pcdata->friends[pos]);
          send_to_char(buffer,ch);
        }
      }
    }
    else if(arg[0] == '\0')
    {
      if(IS_SET(ch->gui, GUI_FRIENDS))
      {
        REMOVE_BIT(ch->gui, GUI_FRIENDS);
        send_to_char("Friends List: Disabled\n\r",ch);
      }
      else
      {
        send_to_char("You must enable the friends list from ZMud.\n\r",ch);
      }
    }

    return;
  }
}

/* Timer is used so that if they are not using ZMud it wont constantly
   wait for response from the plugins */
void gui_check_update( Character *ch )
{
  if ( --ch->gui_check_timer <= 0 )
  {
    REMOVE_BIT(ch->gui, GUI_CHECK);
  }
}

void do_zgui( Character *ch, char *argument )
{
	TOGGLE_BIT(ch->gui,GUI_USE);
	if( IS_SET(ch->gui,GUI_USE) )
		cprintf(ch,"GUI toggled on.\n\r");
	else
		cprintf(ch,"GUI toggled off.\n\r");
	return;
}
