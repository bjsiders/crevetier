/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/
 
/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#include <sys/time.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <stdarg.h>
#include <time.h>
#include "thoc.h"
#include "recycle.h"
#include "tables.h"
#include "color.h"
#include "interp.h"
#include "options.h"

/* globals from db.c for load_notes */
#if !defined(macintosh)
extern  int     _filbuf         (FILE *);
#endif
extern FILE *                  fpArea;
extern char                    strArea[MAX_INPUT_LENGTH];

/* local procedures */
void load_thread(char *name, Note **list, int type, time_t free_time);
void parse_note(Character *ch, char *argument, int type);
bool hide_note(Character *ch, Note *pnote);

int 	top_note_id = 0;

Note *note_list;
Note *idea_list;
Note *penalty_list;
Note *news_list;
Note *fix_list;
Note *changes_list;
Note *appeal_list;
Note *bug_list;
Note *adminnote_list;
Note *clannote_list;
Note *todo_list;
Note *patch_list;
Note *system_list;
Note *world_list;
Note *offline_list;

long	note_counter;
long	idea_counter;
long	penalty_counter;
long	news_counter;
long	fix_counter;
long	changes_counter;
long	appeal_counter;
long	bug_counter;
long	adminnote_counter;
long	clannote_counter;
long	todo_counter;
long	patch_counter;
long	system_counter;
long	world_counter;
long	offline_counter;

struct spool_type
{
    char	*name;
    char	*plural;
    char	*filename;
    Note	**list;
    long	*counter;
    short	read_level;
    long	write_level;
    int		refresh;
	bool	time_sense;
};

 
const	struct	spool_type	spool_table	[] =
{
    { "note", "notes",  NOTE_FILE, &note_list, &note_counter, 0,	0,	14*24*60*60, FALSE	},
    { "idea", "ideas", 	IDEA_FILE, &idea_list, &idea_counter, 0,	0,	60*60*24*14, FALSE	},
    { "penalty", "penalties",	PENALTY_FILE, &penalty_list,	&penalty_counter, IM,	IM,	0, FALSE	},
    { "news", "news",	NEWS_FILE, &news_list,	&news_counter, 0,	IM,	60*60*24*14, TRUE	},
    { "change", "changes",	CHANGES_FILE, &changes_list,	&changes_counter, 0,	IM,	60*60*24*14, TRUE	},
    { "bug", "bugs",	BUG_FILE, &bug_list,	&bug_counter, IM,	0,	0, FALSE	},
    { "appeal", "appeals",	APPEAL_FILE, &appeal_list,	&appeal_counter, 0,	0, 	60*60*24*14, FALSE	},
    { "admin note", "admin notes",	ADMIN_FILE, &adminnote_list,	&adminnote_counter, IM,	IM,	60*60*24*14, FALSE	},
    { "clan note", "clan notes",	CLAN_FILE, &clannote_list,		&clannote_counter, 0,	0,	60*60*24*14, FALSE	},
    { "fix", "fixes",	FIX_FILE, &fix_list,		&fix_counter, 0,	L1,	60*60*24*14, TRUE	},
	{ "todo", "todos",	TODO_FILE, &todo_list,		&todo_counter, 0,	0,	0, FALSE	},
	{ "gamepatch", "gamepatches", PATCH_FILE, &patch_list,	&patch_counter, 0, L1, 0, TRUE 	},
	{ "system message", "system messages", SYSTEM_MSG_FILE, &system_list, 	&system_counter, IM, ML, 60*60*24*7, FALSE },
	{ "world note", "world notes", WORLD_FILE, &world_list, &world_counter, 1, 1, 60*60*24*14, FALSE },
	{ "offline note", "offline notes", OFFLINE_FILE, &offline_list, &offline_counter, 0, 0, 14*24*60*60, FALSE },
    { "blank", "blank", "blank", NULL,	NULL, 0,0,0,0 }
};
  
void do_spool(Character *ch, char *argument)
{
    int i;

    for ( i=0 ; spool_table[i].list != NULL ; i++ )
	 ch->pcdata->last_reads[i] = current_time;

    cprintf(ch,"All spools caught up.\n\r");
    return;
}
 
int count_spool(Character *ch, Note *spool)
{
    int count = 0;
    Note *pnote;

    for (pnote = spool; pnote != NULL; pnote = pnote->next)
	if (!hide_note(ch,pnote))
	    count++;

    return count;
}

void do_unread(Character *ch, char *argument)
{
    int count;
    bool found = FALSE;
    int i;

    if (IS_NPC(ch))
	return; 

    for ( i=0 ; spool_table[i].list != NULL ; i++ )
    {
        count = count_spool(ch,*spool_table[i].list);
        if ( ch->level >= spool_table[i].read_level &&
             count > 0 )
        {
            if ( !found )
                cprintf(ch," %-22s #Unread\n\r", "Spool" );       
	    	found = TRUE;
	    	cprintf(ch," %-22s &g%d&x\n\r", spool_table[i].plural, count );
		}
    }

    if (!found)
	    send_to_char("You have no unread notes.\n\r",ch);
}

void do_offlinenotes( Character *ch, char *argument )
{
	parse_note(ch,argument,NOTE_OFFLINE);
}

void do_worldnotes(Character *ch, char*argument)
{
	parse_note(ch,argument,NOTE_WORLD);
}

void do_bug(Character *ch, char *argument)
{
    parse_note(ch,argument,NOTE_BUG);
}

void do_appeal(Character *ch, char *argument)
{
    parse_note(ch,argument,NOTE_APPEAL);

}


/*posts are only readable, a post is the general term for any thread*/
/*-1 as a value means to check all the threads for a note with that id*/
void do_post(Character *ch, char *argument)
{
	parse_note(ch, argument, -1);
}

void do_anote(Character *ch, char *argument)
{
    parse_note(ch,argument,NOTE_ADMIN);
}

void do_cnote(Character *ch, char *argument)
{
    parse_note(ch,argument,NOTE_CLAN);
}

void do_system(Character *ch, char *argument)

{
	parse_note(ch,argument,NOTE_SYSTEM);
}


void do_note(Character *ch,char *argument)
{
    parse_note(ch,argument,NOTE_NOTE);
}

void do_idea(Character *ch,char *argument)
{
    parse_note(ch,argument,NOTE_IDEA);
}

void do_penalty(Character *ch,char *argument)
{
    parse_note(ch,argument,NOTE_PENALTY);
}

void do_patch( Character *ch, char *argument )
{
	parse_note(ch,argument,NOTE_PATCH);
}

void do_todo( Character *ch, char *argument )
{
	parse_note(ch,argument,NOTE_TODO);
}

void do_fix(Character *ch,char *argument)
{
    parse_note(ch,argument,NOTE_FIX);
}

void do_news(Character *ch,char *argument)
{
    parse_note(ch,argument,NOTE_NEWS);
}

void do_changes(Character *ch,char *argument)
{
    parse_note(ch,argument,NOTE_CHANGES);
}

void save_notes(int type)
{
    FILE *fp;
    char name[MAX_FILENAME];
    Note *pnote;

	snprintf(name,sizeof(name),"%s%s", getDirectory(BOARD_DIR), spool_table[type].filename );
    pnote = *spool_table[type].list;

    fclose( fpReserve );
    if ( ( fp = fopen( name, "w" ) ) == NULL )
    {
		log_error( name );
    }
    else
    {
		for ( ; pnote != NULL; pnote = pnote->next )
		{
	    	fprintf( fp, "ID      %d\n",  pnote->id );
			fprintf( fp, "Sender  %s~\n", pnote->sender);
	    	fprintf( fp, "Date    %s~\n", pnote->date);
	    	fprintf( fp, "Stamp   %ld\n", (long) pnote->date_stamp);
	    	fprintf( fp, "To      %s~\n", pnote->to_list);
	    	fprintf( fp, "Subject %s~\n", pnote->subject);
	    	fprintf( fp, "Text\n%s~\n",   pnote->text);
		}
		fclose( fp );
		fpReserve = fopen( NULL_FILE, "r" );
   		return;
    }
}

void load_notes(void)
{
    int i;

    for( i=0 ; spool_table[i].list != NULL ; i++ )
        load_thread(spool_table[i].filename,spool_table[i].list, i, spool_table[i].refresh );

}

void load_thread(char *name, Note **list, int type, time_t free_time)
{
    FILE *fp;
    Note *pnotelast;
	char *tmp;
	char	filename[MAX_STRING_LENGTH];

    snprintf(filename,sizeof(filename),"%s%s", getDirectory(BOARD_DIR), name );
 
    if ( ( fp = fopen( filename, "r" ) ) == NULL )
	{
		log_string("Could not open note file %s: %s", filename, strerror(errno) );
		return;
	}
	else
		log_string("[Loading file %s]", filename);
	 
    pnotelast = NULL;
    for ( ; ; )
    {
	Note *pnote;
	char letter;
	 
	do
	{
	    letter = getc( fp );
        if ( feof(fp) )
        {
            fclose( fp );
            return;
         }
    } 

    while ( isspace(letter) )
		;
    ungetc( letter, fp );
 
        pnote           = alloc_perm( sizeof(*pnote) );

		if ( str_cmp( (tmp=fread_word( fp )), "id" ) )
		{
			log_bug("Got [%s], expecting 'id'",tmp);
			break;
		}
 		pnote->id		= fread_number(fp);
		top_note_id = UMAX(pnote->id,top_note_id);

		if ( str_cmp( (tmp=fread_word(fp)), "sender" ) )
		{
			log_bug("Got [%s], expecting 'sender'",tmp);
			break;
		}
       	pnote->sender   = fread_string( fp );
 
        if ( str_cmp( (tmp=fread_word( fp )), "date" ) )
		{
			log_bug("Got [%s], expecting 'date'",tmp);
            break;
		}
        pnote->date     = fread_string( fp );
 
        if ( str_cmp( (tmp=fread_word( fp )), "stamp" ) )
		{
			log_bug("Got [%s], expecting 'stamp'",tmp);
            break;
		}
        pnote->date_stamp = fread_number(fp);
 
        if ( str_cmp( (tmp=fread_word( fp )), "to" ) )
		{
			log_bug("Got [%s], expecting 'to'",tmp);
            break;
		}
        pnote->to_list  = fread_string( fp );
 
        if ( str_cmp( (tmp=fread_word( fp )), "subject" ) )
		{
			log_bug("Got [%s], expecting 'subject'",tmp);
            break;
		}
        pnote->subject  = fread_string( fp );
 
        if ( str_cmp( (tmp=fread_word( fp )), "text" ) )
		{
			log_bug("Got [%s], expecting 'text'",tmp);
            break;
		}
        pnote->text     = fread_string( fp );
 
        if (free_time && pnote->date_stamp < current_time - free_time)
        {
	    	free_note(pnote);
            continue;
        }

		pnote->type = type;
 
        if (*list == NULL)
            *list           = pnote;
        else
            pnotelast->next     = pnote;
 
        pnotelast       = pnote;
    }
 
    strcpy( strArea, NOTE_FILE );
    fpArea = fp;
	log_string("Load_notes: bad key word [%s] for type %s", tmp, spool_table[type].name );
    log_bug( "Load_notes: bad key word.", 0 );
    exit( 1 );
    return;
}

void append_note(Note *pnote)
{
    FILE *fp;
    char *name;
    Note **list;
    Note *last;
	char filename[MAX_STRING_LENGTH];

    list = spool_table[pnote->type].list;
    name = spool_table[pnote->type].filename;

/** Siders 13/July/01 **
    switch(pnote->type)
    {
	default:
	    return;
	case NOTE_NOTE:
	    name = NOTE_FILE;
	    list = &note_list;
	    break;
	case NOTE_IDEA:
	    name = IDEA_FILE;
	    list = &idea_list;
	    break;
	case NOTE_PENALTY:
	    name = PENALTY_FILE;
	    list = &penalty_list;
	    break;
	case NOTE_NEWS:
	     name = NEWS_FILE;
	     list = &news_list;
	     break;
	case NOTE_CHANGES:
	     name = CHANGES_FILE;
	     list = &changes_list;
	     break;
    }
*/
    if (*list == NULL)
	*list = pnote;
    else
    {
	for ( last = *list; last->next != NULL; last = last->next);
	last->next = pnote;
    }

    fclose(fpReserve);
	snprintf(filename,sizeof(filename),"%s%s", getDirectory(BOARD_DIR), name);
    if ( ( fp = fopen(filename, "a" ) ) == NULL )
    {
        log_error(name);
    }
    else
    {
		fprintf( fp, "ID      %d\n",  pnote->id );
        fprintf( fp, "Sender  %s~\n", pnote->sender);
        fprintf( fp, "Date    %s~\n", pnote->date);
        fprintf( fp, "Stamp   %ld\n", (long) pnote->date_stamp);
        fprintf( fp, "To      %s~\n", pnote->to_list);
        fprintf( fp, "Subject %s~\n", pnote->subject);
        fprintf( fp, "Text\n%s~\n", pnote->text);
        fclose( fp );
    }
    fpReserve = fopen( NULL_FILE, "r" );
}

bool is_note_to( Character *ch, Note *pnote )
{
    if ( ch->level == 60 )
	return TRUE;

    if ( is_exact_name( "admin", pnote->to_list ) && ch->level >= 59 )
	return TRUE;

    if ( !str_cmp( ch->name, pnote->sender ) )
	return TRUE;

    if ( is_exact_name( "all", pnote->to_list ) )
	return TRUE;

    if ( IS_IMMORTAL(ch) && 
            (is_exact_name( "immortal", pnote->to_list ) ||
             is_exact_name( "immortals", pnote->to_list ) ||
             is_exact_name( "imm", pnote->to_list ) ||
             is_exact_name( "imms", pnote->to_list )) )
	return TRUE;

    if (ch->clan && is_exact_name(ch->clan->name,pnote->to_list))
	return TRUE;

	if ( (is_exact_name( "builder", pnote->to_list ) ||
		  is_exact_name( "builders", pnote->to_list )) &&
		( (IS_SET(ch->act,PLR_BUILDER) && !IS_NPC(ch)) || IS_IMMORTAL(ch)) )
	return TRUE;

	if ( (is_exact_name( "teamleads", pnote->to_list ) ||
          is_exact_name( "teamlead", pnote->to_list )) &&
		( (IS_SET(ch->act,PLR_TEAM_LEAD) && !IS_NPC(ch)) || IS_IMMORTAL(ch)) )
	return TRUE;

    if (is_exact_name( ch->name, pnote->to_list ) )
	return TRUE;

    return FALSE;
}

char color_note_to( Character *ch, Note *pnote, bool fColor)
{//fColor is true if it's being called for color use
	if(!HAS_COLOROPT( ch, COLOR_NOTE_TO ) && fColor)
		return 'x';

    if ( !str_cmp( ch->name, pnote->sender ) )
	return 'D';

    if (is_exact_name( ch->name, pnote->to_list ) )
	return 'W';

    if ( is_exact_name( "admin", pnote->to_list ) && ch->level >= 59 )
	return 'M';

    if ( IS_IMMORTAL(ch) && is_exact_name( "immortal", pnote->to_list ) )
	return 'G';

    if (ch->clan && is_exact_name(ch->clan->name,pnote->to_list))
	return 'G';

	if ( (is_exact_name( "builder", pnote->to_list ) ||
		  is_exact_name( "builders", pnote->to_list )) &&
		( (IS_SET(ch->act,PLR_BUILDER) && !IS_NPC(ch)) || IS_IMMORTAL(ch)) )
	return 'C';

	if ( (is_exact_name( "teamleads", pnote->to_list ) ||
          is_exact_name( "teamlead", pnote->to_list )) &&
		( (IS_SET(ch->act,PLR_TEAM_LEAD) && !IS_NPC(ch)) || IS_IMMORTAL(ch)) )
	return 'B';

    if ( ch->level == 60 )
	return 'x';

    if ( is_exact_name( "all", pnote->to_list ) )
	return 'x';

    return FALSE;
}

void note_attach( Character *ch, int type )
{
    Note *pnote;

    if ( ch->pnote != NULL )
		return;

    pnote = new_note();

    pnote->next		= NULL;
    pnote->sender	= str_dup( ch->name );
    pnote->date		= str_dup( "" );
    pnote->to_list	= str_dup( "" );
    pnote->subject	= str_dup( "" );
    pnote->text		= str_dup( "" );
    pnote->type		= type;
    ch->pnote		= pnote;
    return;
}



void note_remove( Character *ch, Note *pnote, bool delete)
{
    char to_new[MAX_INPUT_LENGTH];
    char to_one[MAX_INPUT_LENGTH];
    Note *prev;
    Note **list;
    char *to_list;

    if (!delete)
    {
	/* make a new list */
        to_new[0]	= '\0';
        to_list	= pnote->to_list;
        while ( *to_list != '\0' )
        {
    	    to_list	= one_argument( to_list, to_one );
    	    if ( to_one[0] != '\0' && str_cmp( ch->name, to_one ) )
	    {
	        strcat( to_new, " " );
	        strcat( to_new, to_one );
	    }
        }
        /* Just a simple recipient removal? */
       if ( str_cmp( ch->name, pnote->sender ) && to_new[0] != '\0' )
       {
	   free_string( pnote->to_list );
	   pnote->to_list = str_dup( to_new + 1 );
	   return;
       }
    }
    /* nuke the whole note */

    list = spool_table[pnote->type].list;

    /*
     * Remove note from linked list.
     */
    if ( pnote == *list )
    {
	*list = pnote->next;
    }
    else
    {
	for ( prev = *list; prev != NULL; prev = prev->next )
	{
	    if ( prev->next == pnote )
		break;
	}

	if ( prev == NULL )
	{
	    log_bug( "Note_remove: pnote not found.", 0 );
	    return;
	}

	prev->next = pnote->next;
    }

    save_notes(pnote->type);
    free_note(pnote);
    return;
}

bool hide_note (Character *ch, Note *pnote)
{
    time_t last_read;

    if (IS_NPC(ch))
	return TRUE;

    last_read = ch->pcdata->last_reads[pnote->type];
/*
    switch (pnote->type)
    {
	default:
	    return TRUE;
	case NOTE_NOTE:
	    last_read = ch->pcdata->last_note;
	    break;
	case NOTE_IDEA:
	    last_read = ch->pcdata->last_idea;
	    break;
	case NOTE_PENALTY:
	    last_read = ch->pcdata->last_penalty;
	    break;
	case NOTE_NEWS:
	    last_read = ch->pcdata->last_news;
	    break;
	case NOTE_CHANGES:
	    last_read = ch->pcdata->last_changes;
	    break;
    }
  */  
    if (pnote->date_stamp <= last_read)
	return TRUE;

    if (!str_cmp(ch->name,pnote->sender))
	return TRUE;

    if (!is_note_to(ch,pnote))
	return TRUE;

    return FALSE;
}

void update_read(Character *ch, Note *pnote)
{
    time_t stamp;

    if (IS_NPC(ch))
	return;

    stamp = pnote->date_stamp;

    ch->pcdata->last_reads[pnote->type] = UMAX(ch->pcdata->last_reads[pnote->type],stamp);
/*
    switch (pnote->type)
    {
        default:
            return;
        case NOTE_NOTE:
	    ch->pcdata->last_note = UMAX(ch->pcdata->last_note,stamp);
            break;
        case NOTE_IDEA:
	    ch->pcdata->last_idea = UMAX(ch->pcdata->last_idea,stamp);
            break;
        case NOTE_PENALTY:
	    ch->pcdata->last_penalty = UMAX(ch->pcdata->last_penalty,stamp);
            break;
        case NOTE_NEWS:
	    ch->pcdata->last_news = UMAX(ch->pcdata->last_news,stamp);
            break;
        case NOTE_CHANGES:
	    ch->pcdata->last_changes = UMAX(ch->pcdata->last_changes,stamp);
            break;
    }
*/
}


void parse_note( Character *ch, char *argument, int type )
{
    Buffer *buffer;
    char buf[MAX_STRING_LENGTH];
    char arg[MAX_INPUT_LENGTH];
    Note *pnote;
    Note **list;
    char *list_name;
    int anum, i;
	bool found = FALSE;

    if ( IS_NPC(ch) )
		return;

#if defined(__OLC) || defined(__TEST)
	cprintf(ch,"You can't post notes on the OLC and test ports.  They'd just get\n\r"
		"overwritten when the game port saves the note spools.\n\r");
	return;
#endif

	if ( is_affected(ch,gsn_shapeshifting,AFF_SKILL) )
	{
		if ( ch->desc == NULL )
			return;
		else
			ch = ch->desc->original;
	}

    argument = one_argument( argument, arg );
    smash_tilde( argument );

	if(type >= 0)
	{
		list = spool_table[type].list;
		list_name = spool_table[type].plural;
	}
	else
	{
		list = NULL;
		list_name = NULL;
        if(arg[0] != '\0' && !str_prefix(arg, "read"))
        {
			if(argument[0] == '\0')
			{
				cprintf(ch, "Which index number do you wish to look for?\n\r");
				return;
			}
        }
        else if(arg[0] == '\0' || str_prefix(arg, "listtoself"))
	    {
            cprintf( ch, "Syntax: post read <#>\n\r"
                         "        post list\n\r"
                         "        post listtoself\n\r" );
            return;
		}
	}

    if ( arg[0] == '\0' || !str_prefix( arg, "read" ) )
    {
        bool fAll;

        if ( !str_cmp( argument, "all" ) )
        {
            fAll = TRUE;
            anum = 0;
        }
        else if ((argument[0] == '\0' || !str_prefix(argument, "next")) && type >= 0 )
        {
            for ( pnote = *list; pnote != NULL; pnote = pnote->next)
            {
                if (!hide_note(ch,pnote))
                {
                    cprintf( ch, "&c[&x%3d&c]&x&W %s&x: %s\n\r%s\n\rTo: %s\n\r",
                        pnote->id, pnote->sender, pnote->subject, pnote->date, pnote->to_list);

					if ( pnote->date_stamp > boot_time && spool_table[pnote->type].time_sense )
						cprintf(ch, "&R [***] This note was written after the last reboot.  Any references in this\n\r"
  								    " [***] note to recent changes, fixes, etc, may not yet be live in the game.&x\n\r");

                    page_to_char( pnote->text, ch );
                    update_read(ch,pnote);
					ch->pcdata->last_note_read[pnote->type] = pnote->id;
                    return;
                }
            }
	    	sprintf(buf,"You have no unread %s.\n\r",list_name);
	    	send_to_char(buf,ch);
            return;
        }
        else if ( is_number( argument ) )
        {
            fAll = FALSE;
            anum = atoi( argument );
        }
        else
        {
            send_to_char( "Read which number?\n\r", ch );
            return;
        }

		if(type < 0)
		{
			/*scan through each spool looking for the index*/
			for ( i=0 ; spool_table[i].list != NULL ; i++ )
			{
				list = spool_table[i].list;
				list_name = spool_table[i].plural;

				for ( pnote = *list; pnote != NULL; pnote = pnote->next )
				{
					if ( is_note_to( ch, pnote ) && ( pnote->id == anum || fAll ) )
					{
						cprintf( ch, "&RSpool: %s\n\r&x", list_name );
						cprintf( ch, "&c[&x%3d&c]&x&W %s&x: %s\n\r%s\n\rTo: %s\n\r",
							pnote->id, pnote->sender, pnote->subject, pnote->date, pnote->to_list );

						if ( pnote->date_stamp > boot_time && spool_table[pnote->type].time_sense )
							cprintf(ch," ** &RThis note was written after the last reboot.  Any references in this note to\n\r"
									   "recent changes, fixes, etc, may not yet be live in the game.&x\n\r");

						page_to_char( pnote->text, ch );
						update_read(ch,pnote);
						ch->pcdata->last_note_read[pnote->type] = pnote->id;
						return;
					}
				}
			}
			cprintf(ch,"There is no post #%d for you.\n\r",anum );
			return;
		}

        for ( pnote = *list; pnote != NULL; pnote = pnote->next )
        {
            if ( is_note_to( ch, pnote ) && ( pnote->id == anum || fAll ) )
            {
                sprintf( buf, "&c[&x%3d&c]&x&W %s&x: %s\n\r%s\n\rTo: %s\n\r",
					pnote->id, pnote->sender, pnote->subject, pnote->date, pnote->to_list );

                send_to_char( buf, ch );
                if ( pnote->date_stamp > boot_time && spool_table[pnote->type].time_sense )
                    cprintf(ch," ** &RThis note was written after the last reboot.  Any references in this note to\n\r"
                               "recent changes, fixes, etc, may not yet be live in the game.&x\n\r");

                page_to_char( pnote->text, ch );
				update_read(ch,pnote);
				ch->pcdata->last_note_read[pnote->type] = pnote->id;
                return;
            }
        }

		sprintf(buf,"There is no %s #%d for you.\n\r",list_name, anum );
		send_to_char(buf,ch);
        return;
    }

    if ( !str_prefix( arg, "list" ) )
    {
		Buffer *output;

		output = new_buf();
		found = FALSE;
		if(type < 0)
		{
			/*scan through each spool looking for the index*/
			for ( i=0 ; spool_table[i].list != NULL ; i++ )
			{
				list = spool_table[i].list;
				list_name = spool_table[i].plural;
				found = FALSE;

				for ( pnote = *list; pnote != NULL; pnote = pnote->next )
				{
	    			if ( is_note_to( ch, pnote ) )
	    			{
						if(!found)
						{
							bprintf( output, "&RSpool: %s\n\r&x", list_name );
							found = TRUE;
						}
						bprintf( output, "&%c[%3d%s] [%s] %s: %s&x\n\r",
		    				color_note_to(ch, pnote, TRUE), pnote->id,  hide_note(ch,pnote) ? " ": "N",
	    	    			format_date( pnote->date_stamp, "%d/%b/%Y" ),
		    				pnote->sender, pnote->subject );
	    			}
				}
				if(found)
					bprintf(output, "\n\r");
			}
			page_to_char( buf_string( output ), ch );
			free_buf( output );
			return;
		}
		if(list)
		{
			for ( pnote = *list; pnote != NULL; pnote = pnote->next )
			{
	    		if ( is_note_to( ch, pnote ) )
	    		{
					found = TRUE;
					bprintf( output, "&%c[%3d%s] [%s] %s: %s&x\n\r",
		    			color_note_to(ch, pnote, TRUE), pnote->id,  hide_note(ch,pnote) ? " ": "N",
	    	    		format_date( pnote->date_stamp, "%d/%b/%Y" ),
		    			pnote->sender, pnote->subject );
	    		}
			}
			if (!found)
	    		bprintf(output,"There's no %s for you.\n\r",spool_table[type].plural);
		}

		page_to_char( buf_string( output ), ch );
		free_buf( output );
		return;
    }

    if ( !str_prefix( arg, "listtoself" ) )
    {
		Buffer *output;

		output = new_buf();
		found = FALSE;
		if(type < 0)
		{
			/*scan through each spool looking for the index*/
			for ( i=0 ; spool_table[i].list != NULL ; i++ )
			{
				list = spool_table[i].list;
				list_name = spool_table[i].plural;
				found = FALSE;

				for ( pnote = *list; pnote != NULL; pnote = pnote->next )
				{
	    			if ( is_note_to( ch, pnote ) && color_note_to(ch, pnote, FALSE) != 'x')
	    			{//bit of a hack, but unless we color generic notes to all it should work
						if(!found)
						{
							bprintf( output, "&RSpool: %s\n\r&x", list_name );
							found = TRUE;
						}
						bprintf( output, "&%c[%3d%s] [%s] %s: %s&x\n\r",
		    				color_note_to(ch, pnote, TRUE), pnote->id,  hide_note(ch,pnote) ? " ": "N",
	    	    			format_date( pnote->date_stamp, "%d/%b/%Y" ),
		    				pnote->sender, pnote->subject );
	    			}
				}
				if(found)
					bprintf(output, "\n\r");
			}
			page_to_char( buf_string( output ), ch );
			free_buf( output );
			return;
		}
		if(list)
		{
			for ( pnote = *list; pnote != NULL; pnote = pnote->next )
			{
	    		if ( is_note_to( ch, pnote ) && color_note_to(ch, pnote, FALSE) != 'x')
	    		{//bit of a hack, but unless we color generic notes to all it should work
					found = TRUE;
					bprintf( output, "&%c[%3d%s] [%s] %s: %s&x\n\r",
		    			color_note_to(ch, pnote, TRUE), pnote->id,  hide_note(ch,pnote) ? " ": "N",
	    	    		format_date( pnote->date_stamp, "%d/%b/%Y" ),
		    			pnote->sender, pnote->subject );
	    		}
			}
			if (!found)
	    		bprintf(output,"There's no %s for you.\n\r",spool_table[type].plural);
		}

		page_to_char( buf_string( output ), ch );
		free_buf( output );
		return;
    }

	if ( !str_prefix( arg, "reply" ) )
	{
		bool found = FALSE;
		char buf[MAX_STRING_LENGTH];
		pnote = NULL;

		if(ch->pcdata->last_note_read[type] == 0)
		{
			cprintf(ch, "You have to read a message before you can reply to one.\n\r");
			return;
		}

		if(ch->pnote != NULL && ch->pnote->type != type)
		{
			cprintf(ch, "You already have a different note in progress.\n\r");
			return;
		}

		/* Find reply note */
		for( i=0; spool_table[i].list != NULL; i++)
		{
			list = spool_table[i].list;
			list_name = spool_table[i].plural;
			
			for(pnote = *list; pnote != NULL; pnote = pnote->next)
			{
				if(pnote->id == ch->pcdata->last_note_read[type])
				{
					found = TRUE;
					break;
				}
			}

			if(found)
				break;
		}

		if(!found)
		{
			cprintf(ch, "Could not find the message you are trying to reply to.\n\r");
			return;
		}

		note_attach( ch, type );

		free_string(ch->pnote->subject);
		sprintf(buf, "RE: %s",pnote->subject);
		ch->pnote->subject = str_dup( buf );
		
		free_string( ch->pnote->to_list );
		sprintf(buf, "%s %s", pnote->sender, pnote->to_list);
		ch->pnote->to_list = str_dup( buf );

		/* Copy reply message text */
		if(!HAS_OPT(ch, OPT_NOAUTOREPLYTEXT))
		{
			char c;
			const char *ps;
			int length, symbol_length;
			char pd[MAX_STRING_LENGTH];
			char buf[MAX_STRING_LENGTH];
			int dest_pos;
			bool first_char = FALSE;

			memset(pd,0,sizeof(pd));

			length = strlen(pnote->text);
			dest_pos = 0;

			for(ps = pnote->text; length > 0; ps++, length--)
			{
				c = *ps;

				if(first_char == FALSE)
				{
					sprintf(buf, ">%c", c);
					symbol_length = strlen(buf);
					memcpy(pd + dest_pos, buf, symbol_length);
					dest_pos += symbol_length;
					first_char = TRUE;
				}
				else if(c == '\r' && length != 1)
				{
					sprintf(buf, "\r>");
					symbol_length = strlen(buf);
					memcpy(pd + dest_pos, buf, symbol_length);
					dest_pos += symbol_length;
					first_char = TRUE;
				}
				else
				{
					memcpy(pd + dest_pos, &c, 1);
					dest_pos++;
				}
			}

			/* Put an extra line in after the original text */
			strcat(pd, "\n\r");

			if(strlen(pd) >= 4096)
			{
				cprintf(ch, "Reply text is not included because the message will be too long.\n\r");
				return;
			}

			free_string( ch->pnote->text );
			ch->pnote->text = str_dup( pd );
		}
		return;
	}

    if ( !str_prefix( arg, "remove" ) )
    {
        if ( !is_number( argument ) )
        {
            send_to_char( "Note remove which number?\n\r", ch );
            return;
        }

        anum = atoi( argument );
        for ( pnote = *list; pnote != NULL; pnote = pnote->next )
        {
            if ( is_note_to( ch, pnote ) && pnote->id == anum )
            {
				if(strcmp(pnote->sender,ch->name) && IS_IMMORTAL(ch))
				{
					cprintf(ch, "Use delete to remove other people's notes.\n\r");
					return;
				}
                note_remove( ch, pnote, FALSE );
                cprintf(ch,"%s #%d removed.\n\r", spool_table[type].name, anum );
                return;
            }
        }

		cprintf(ch,"There is no %s #%d for you.",list_name, anum);
        return;
    }

    if ( !str_prefix( arg, "delete" ) && get_trust(ch) >= MAX_LEVEL - 1)
    {
        if ( !is_number( argument ) )
        {
            send_to_char( "Note delete which number?\n\r", ch );
            return;
        }

        anum = atoi( argument );
        for ( pnote = *list; pnote != NULL; pnote = pnote->next )
        {
            if ( is_note_to( ch, pnote ) && pnote->id == anum )
            {
				bool isChar;
				Character *victim;
  				Descriptor d;
  				if ((isChar = load_char_obj(&d, pnote->sender)) )
  				{
					victim = d.character;
					d.original = NULL;
                    victim->desc = NULL;
					if(victim->level > ch->level)
					{
						cprintf(ch, "You can't remove the note of someone higher level than yourself.\n\r");
						free_char( victim );
						return;
					}
					free_char( victim );
  				}
                note_remove( ch, pnote,TRUE );
                send_to_char( "Ok.\n\r", ch );
                return;
            }
        }

		cprintf(ch,"There is no %s #%d for you.",list_name, anum);
        return;
    }

    if (!str_prefix(arg,"catchup"))
    {
		ch->pcdata->last_reads[type] = current_time;
		cprintf(ch, "All %s have been marked as read.\n\r",list_name);
		return;
    }

	/* Let teamleads post news */
    if ( ch->level < spool_table[type].write_level )
    {
		if ( !(IS_SET(ch->act,PLR_TEAM_LEAD) && type == NOTE_NEWS) )
		{
			cprintf(ch,"You aren't high enough level to write %s.\n\r",list_name);
			return;
		}
    }

    if ( !str_cmp( arg, "+" ) )
    {
	    note_attach( ch,type );
	    if (ch->pnote->type != type)
	    {
	        send_to_char(
		    "You already have a different note in progress.\n\r",ch);
	        return;
	    }

	    if (strlen(ch->pnote->text)+strlen(argument) >= 4096)
	    {
	        send_to_char( "Note too long.\n\r", ch );
	        return;
	    }

	    buffer = new_buf();

	    if( ch->level < 55 )
	        stripColorInline(argument);

	    add_buf(buffer,ch->pnote->text);
	    add_buf(buffer,argument);
	    add_buf(buffer,"\n\r");
	    free_string( ch->pnote->text );
	    ch->pnote->text = str_dup( buf_string(buffer) );
	    free_buf(buffer);
	    send_to_char( "Ok.\n\r", ch );
	    return;
    }

    if (!str_cmp(arg,"-"))
    {
	int len;
	bool found = FALSE;

	note_attach(ch,type);
        if (ch->pnote->type != type)
        {
            send_to_char(
                "You already have a different note in progress.\n\r",ch);
            return;
        }

	if (ch->pnote->text == NULL || ch->pnote->text[0] == '\0')
	{
	    send_to_char("No lines left to remove.\n\r",ch);
	    return;
	}

	strcpy(buf,ch->pnote->text);

	for (len = strlen(buf); len > 0; len--)
	{
	    if (buf[len] == '\r')
	    {
		if (!found)  /* back it up */
		{
		    if (len > 0)
			len--;
		    found = TRUE;
		}
		else /* found the second one */
		{
		    buf[len + 1] = '\0';
		    free_string(ch->pnote->text);
		    ch->pnote->text = str_dup(buf);
		    return;
		}
	    }
	}
	buf[0] = '\0';
	free_string(ch->pnote->text);
	ch->pnote->text = str_dup(buf);
	return;
    }

    if ( !str_prefix( arg, "subject" ) )
    {
		note_attach( ch, type );
        if (ch->pnote->type != type)
        {
			cprintf(ch,"You already have a different note in progress.\n\r");
            return;
        }

		if( ch->level < 55 )
	    	stripColorInline( argument );

		free_string( ch->pnote->subject );
		ch->pnote->subject = str_dup( argument );
		return;
    }

    if ( !str_prefix( arg, "to" ) )
    {
		note_attach( ch,type );
        if (ch->pnote->type != type)
        {
       		cprintf(ch,"You already have a different note in progress.\n\r");
            return;
        }

		if ( ch->level < 55 )
	    	stripColorInline( argument );

		free_string( ch->pnote->to_list );
		ch->pnote->to_list = str_dup( argument );
		send_to_char( "Ok.\n\r", ch );
		return;
    }

    if ( !str_prefix( arg, "clear" ) )
    {
	if ( ch->pnote != NULL )
	{
	    free_note(ch->pnote);
	    ch->pnote = NULL;
	}

	send_to_char( "Ok.\n\r", ch );
	return;
    }

    if ( !str_prefix( arg, "edit" ) || !str_prefix(arg, "++") )
    {
        if ( ch->pnote == NULL )
        {
            send_to_char( "You have no note in progress.\n\r", ch );
            return;
        }

        if (ch->pnote->type != type)
        {
            send_to_char("You aren't working on that kind of note.\n\r",ch);
            return;
        }

	string_append(ch, &ch->pnote->text );
	return;
    }

    if ( !str_prefix( arg, "show" ) )
    {
	if ( ch->pnote == NULL )
	{
	    send_to_char( "You have no note in progress.\n\r", ch );
	    return;
	}

	if (ch->pnote->type != type)
	{
	    send_to_char("You aren't working on that kind of note.\n\r",ch);
	    return;
	}

	sprintf( buf, "%s: %s\n\rTo: %s\n\r",
	    ch->pnote->sender,
	    ch->pnote->subject,
	    ch->pnote->to_list
	    );
	send_to_char( buf, ch );
	send_to_char( ch->pnote->text, ch );
	return;
    }

    if ( !str_cmp( arg, "move" ) )
    {
        int new_type;

        if ( ch->pnote == NULL )
        {
            cprintf(ch,"You are not working on any notes.\n\r");
            return;
        }

        if ( (new_type = flag_value( note_flags, argument )) == NO_FLAG )
        {
            cprintf(ch,"There is no such note type.\n\r");
            return;
        }

        if ( spool_table[new_type].write_level > ch->level )
        {
            cprintf(ch,"You must be at least level %d to write a %s post.\n\r",
                spool_table[new_type].write_level, spool_table[new_type].name );
            return;
        }

        ch->pnote->type = new_type;
        cprintf(ch,"This note will be posted to the %s spool.\n\r",
            spool_table[ch->pnote->type].name );
        return;
    }

    if ( !str_prefix( arg, "post" ) || !str_prefix(arg, "send"))
    {
	    char *strtime;

	    if ( ch->pnote == NULL )
	    {
	        send_to_char( "You have no note in progress.\n\r", ch );
	        return;
	    }

        if (ch->pnote->type != type)
        {
            send_to_char("You aren't working on that kind of note.\n\r",ch);
            return;
        }

	if (!str_cmp(ch->pnote->to_list,""))
	{
	    send_to_char(
		"You need to provide a recipient (name, all, or immortal).\n\r",
		ch);
	    return;
	}

	if (!str_cmp(ch->pnote->subject,""))
	{
	    send_to_char("You need to provide a subject.\n\r",ch);
	    return;
	}

	/* Add signature if appropriate */
	if(!HAS_OPT(ch, OPT_NOSIGNATURE))
	{
		buffer = new_buf();
		add_buf(buffer,ch->pnote->text);
		add_buf(buffer,"\n\r");
		add_buf(buffer,ch->pcdata->note_signature);
		add_buf(buffer,"\n\r");

		if(buffer->size >= 4096)
		{
			cprintf(ch, "Your signature has not been included because it would make your message too long.\n\r");
		}
		else
		{
			free_string(ch->pnote->text);
			ch->pnote->text = str_dup( buf_string(buffer) );
		}

		free_buf(buffer);
	}

	ch->pnote->next			= NULL;
	strtime				= ctime( &current_time );
	strtime[strlen(strtime)-1]	= '\0';
	ch->pnote->date			= str_dup( strtime );
	ch->pnote->date_stamp		= current_time;
	stripColorInline( ch->pnote->text );

	/* Only immortals can put color into notes */

	cprintf(ch,"Your %s has been posted (#%d).\n\r",spool_table[ch->pnote->type].name,ch->pnote->id);
	sprintf(buf,"%s posted by $N.", spool_table[ch->pnote->type].name);
	wiznet(buf,ch,NULL,WIZ_NOTES,0,get_trust(ch));
	if ( is_exact_name( "all", ch->pnote->to_list ) )
		pnet(buf,ch,NULL,WIZ_NOTES,0,get_trust(ch));

        append_note(ch->pnote);
        ch->pnote = NULL;

	return;
    }

    send_to_char( "You can't do that.\n\r", ch );
    return;
}


void do_signature( Character *ch, char *argument )
{
	char buf[MAX_STRING_LENGTH];

	if ( IS_NPC(ch) )
		return;

	if ( argument[0] == '\0' )
	{
		cprintf(ch, "Syntax: signature <new signature>\n\r");
		cprintf(ch,	"        signature show\n\r");
		cprintf(ch, "        signature clear\n\r");
		return;
	}

	if(!strcmp(argument, "show"))
	{
		if(!strcmp(ch->pcdata->note_signature,""))
			cprintf(ch, "You currently do not have a signature set.\n\r");
		else
			cprintf(ch, "Your message signature is: %s\n\r", ch->pcdata->note_signature ? ch->pcdata->note_signature : "(None)");
		return;
	}

	if(!strcmp(argument, "clear"))
	{
		strcpy(buf, "");
		free_string( ch->pcdata->note_signature );
		ch->pcdata->note_signature = str_dup( buf );
		cprintf(ch, "Message signature cleared.\n\r");
		return;
	}

	smash_tilde( argument );

	if( ch->level < 55 )
		stripColorInline(argument);

	strcpy( buf, argument );
	strcat( buf, "\n\r");
	free_string( ch->pcdata->note_signature );
	ch->pcdata->note_signature = str_dup( buf );
}

