/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include <sys/types.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "thoc.h"
#include "olc.h"
#include "tables.h"
#include "lookup.h"
#include "recycle.h"

void copyMobIndex( MobIndex *new, MobIndex *orig );

MEDIT( medit_show )
{
    MobIndex *pMob;
    char buf[MAX_STRING_LENGTH];

    EDIT_MOB(ch, pMob);

    sprintf( buf, "Name:        [%s]\n\rArea:        [%5d] %s\n\r",
	pMob->player_name,
	!pMob->area ? -1        : pMob->area->vnum,
	!pMob->area ? "No Area" : pMob->area->name );
    send_to_char( buf, ch );

    sprintf( buf, "Act:         [%s]\n\r",
	flag_string( act_flags, pMob->act ) );
    send_to_char( buf, ch );

    sprintf( buf, "Vnum:        [%5d]\n\rSex:         [%s]\n\r",
	pMob->vnum,
	pMob->sex == SEX_MALE    ? "male"   :
	pMob->sex == SEX_FEMALE  ? "female" : 
	pMob->sex == 3           ? "random" : "neutral" );  /* ROM magic number */
    send_to_char( buf, ch );

    sprintf( buf, "Race:        [%s]\n\r",                   /* ROM OLC */
	race_table[pMob->race].name );
    send_to_char( buf, ch );

    cprintf( ch, "Class:       [%s]\n\r", class_table[pMob->class].name);
    sprintf( buf,
	"Level:       [%2d]  Deity: [%s]  Hitroll: [%2d]\n\r",
	pMob->level, (pMob->alignment < 0 || pMob->alignment > MAX_DEITY ) ? "<none>" : deity_table[pMob->alignment].name, pMob->hitroll );
    send_to_char( buf, ch );

/* ROM values: */

    cprintf( ch, "Hit dice:    [%2dd%-3d+%4d]  Damage dice:[%2dd%-3d+%4d]  DamType: [%s]\n\r",
         pMob->hit[DICE_NUMBER],
         pMob->hit[DICE_TYPE],
         pMob->hit[DICE_BONUS],
         pMob->damage[DICE_NUMBER],
         pMob->damage[DICE_TYPE],
         pMob->damage[DICE_BONUS],
		attack_table[pMob->dam_type].name );


	cprintf( ch, "Flat DPS:    [%3.2f]  DPS + Damroll:[%3.2f]  (Ideal range: %3.2f to %3.2f)\n\r",
		getDPS( pMob->damage[DICE_NUMBER], pMob->damage[DICE_TYPE], pMob->level < 5 ? 45 : 32) ,
		getDPS( pMob->damage[DICE_NUMBER], pMob->damage[DICE_TYPE], pMob->level < 5 ? 45 : 32) +
			(float) pMob->damage[DICE_BONUS] / (pMob->level < 5 ? 4.5 : 3.2 ),
		(float) pMob->level / 5,
		(float) pMob->level / 3 );

    sprintf( buf, "Mana dice:   [%2dd%-3d+%4d]\n\r",
	     pMob->mana[DICE_NUMBER],
	     pMob->mana[DICE_TYPE],
	     pMob->mana[DICE_BONUS] );
    send_to_char( buf, ch );

/* ROM values end */

    sprintf( buf, "Affected by: [%s]\n\r",
	flag_string( affect_flags, pMob->affected_by ) );
    send_to_char( buf, ch );

/* ROM values: */

    sprintf( buf, "Armor:       [pierce: %d  bash: %d  slash: %d  magic: %d]\n\r",
	pMob->ac[AC_PIERCE], pMob->ac[AC_BASH],
	pMob->ac[AC_SLASH], pMob->ac[AC_EXOTIC] );
    send_to_char( buf, ch );

    sprintf( buf, "Form:        [%s]\n\r",
	flag_string( form_flags, pMob->form ) );
    send_to_char( buf, ch );

    sprintf( buf, "Parts:       [%s]\n\r",
	flag_string( part_flags, pMob->parts ) );
    send_to_char( buf, ch );

    sprintf( buf, "Off:         [%s]\n\r",
	flag_string( off_flags,  pMob->off_flags ) );
    send_to_char( buf, ch );

    sprintf( buf, "Size:        [%s]  ",
	flag_string( size_flags, pMob->size ) );
    send_to_char( buf, ch );

    sprintf( buf, "Start pos. [%s]  ",
	position_table[pMob->start_pos].name  );
    send_to_char( buf, ch );

    sprintf( buf, "Default pos [%s]\n\r",
	position_table[pMob->default_pos].name  );
    send_to_char( buf, ch );

    sprintf( buf, "Wealth:      [%s]\n\r",
	money_breakdown(pMob->wealth) );
    send_to_char( buf, ch );

/* ROM values end */

	cprintf(ch,"Spec fun:    [%s]\n\r", pMob->spec_fun == NULL ? "none" : spec_string( pMob->spec_fun ) );
	cprintf(ch,"Spawn Echo:  %s\n\r",  pMob->spawn_echo == NULL ? "<none>" : pMob->spawn_echo );
	cprintf(ch,"Attack Echo: %s\n\r", pMob->attack_echo == NULL ? "<default>" : pMob->attack_echo );
	cprintf(ch,"Death Echo:  %s\n\r", pMob->death_echo == NULL ? "<default>" : pMob->death_echo );

    sprintf( buf, "Short descr: %s\n\rLong descr:\n\r%s",
	pMob->short_descr,
	pMob->long_descr );
    send_to_char( buf, ch );

    sprintf( buf, "Description:\n\r%s", pMob->description );
    send_to_char( buf, ch );

    if ( pMob->pShop )
    {
	    Shop *pShop;
	    int iTrade;

	    pShop = pMob->pShop;

	    cprintf( ch, "Shop data for [%5d]:\n\r"
	                  "  Markup for purchaser: %d%%\n\r"
	                  "  Markdown for seller:  %d%%\n\r",
	                pShop->keeper, pShop->profit_buy, pShop->profit_sell );
	    cprintf( ch, "  Hours: %d to %d.\n\r", pShop->open_hour, pShop->close_hour );

	    for ( iTrade = 0; iTrade < MAX_TRADE; iTrade++ )
	    {
	        if ( pShop->buy_type[iTrade] != 0 )
	        {
		        if ( iTrade == 0 ) 
                {
		            cprintf(ch,  "  Number Trades Type\n\r" );
		            cprintf(ch,  "  ------ -----------\n\r" );
		        }

		        cprintf( ch, "  [%4d] %s\n\r", iTrade, flag_string( type_flags, pShop->buy_type[iTrade] ) );
	        }
	    }
    }

	/* Resists */
	{
		int i;

    	cprintf(ch,"== RESISTANCES ==\n\r");
    	for ( i = 0 ; i < MAX_RESIST ; i++ )
		{
			if ( pMob->resists[i] == RESIST_IMMUNE )
	        	cprintf(ch,"%-12s Imm  ",capitalize(resist_flags[i].name), pMob->resists[i] );
			else
        		cprintf(ch,"%-12s %3d  ",capitalize(resist_flags[i].name), pMob->resists[i] );
			if ((i+1) % 4 == 0 )
				cprintf(ch,"\n\r");
		}
	}


	/* Factions! */
	{
		Faction *f;
		bool found = FALSE;

		cprintf(ch,"\n\r == Factions ==\n\r");
		for( f = pMob->factions ; f != NULL ; f = f->next )
		{
			found = TRUE;
			cprintf(ch," * %-20s  %s", f->name, f->standing == FACTION_MEMBER_OF ? "ally" :
				( f->standing == FACTION_ENEMY_OF ? "enemy" : "<unknown>" ) );
			if ( f->aggroPoint != FACTION_AGGRESSIVE )
				cprintf(ch," (Aggro: %d)", f->aggroPoint );
			if ( f->passivePoint != FACTION_FRIENDLY )
				cprintf(ch," (Passive: %d)", f->passivePoint );
			cprintf(ch,"\n\r");
		}

		if( !found )
			cprintf(ch,"    No factions defined for this NPC.\n\r");
	}

	
    return FALSE;
}

MEDIT( medit_create )
{
    MobIndex *pMob, *copy_source;
    Area *pArea;
    int  value;
    int  iHash;
	char arg[MAX_INPUT_LENGTH];

	argument = one_argument( argument, arg );
    value = atoi( arg );

    if ( arg[0] == '\0' || value == 0 )
    {
		send_to_char( "Syntax:  medit create [vnum]\n\r", ch );
		return FALSE;
    }

    pArea = get_vnum_area( value );

    if ( !pArea )
    {
		send_to_char( "MEdit:  That vnum is not assigned an area.\n\r", ch );
		return FALSE;
    }

    if ( !IS_BUILDER( ch, pArea ) )
    {
		send_to_char( "MEdit:  Vnum in an area you cannot build in.\n\r", ch );
		return FALSE;
    }

    if ( get_mob_index( value ) )
    {
		send_to_char( "MEdit:  Mobile vnum already exists.\n\r", ch );
		return FALSE;
    }

    pMob			= new_mob_index();
    pMob->vnum			= value;
    pMob->area			= pArea;
        
    if ( value > top_vnum_mob )
	top_vnum_mob = value;        

    pMob->act			= ACT_IS_NPC;
    iHash			= value % MAX_KEY_HASH;
    pMob->next			= mob_index_hash[iHash];
    mob_index_hash[iHash]	= pMob;
    ch->desc->pEdit		= (void *)pMob;

    send_to_char( "Mobile Created.\n\r", ch );

	if ( *argument == NULL )
    	return TRUE;

	/* Copy? */
	argument = one_argument( argument, arg );
	if ( str_cmp(arg,"from") )
	{
		cprintf(ch,"Invalid copy syntax.  Ignoring.\n\r");
		return TRUE;
	}

	value = atoi( argument );
	if ( value <= 0 )
	{
		cprintf(ch,"Malformed copy, ignoring.\n\r");
		return TRUE;
	}

	if ( (copy_source = get_mob_index( value )) == NULL )
	{
		cprintf(ch,"No such NPC with vnum %d, copy ignored.\n\r", value );
		return TRUE;
	}

	copyMobIndex( pMob, copy_source );
	cprintf(ch,"NPC %d (%s) copied to %d.\n\r",
		value, copy_source->short_descr, pMob->vnum );
	return TRUE;
}



MEDIT( medit_spec )
{
    MobIndex *pMob;

    EDIT_MOB(ch, pMob);

    if ( argument[0] == '\0' )
    {
	send_to_char( "Syntax:  spec [special function]\n\r", ch );
	return FALSE;
    }


    if ( !str_cmp( argument, "none" ) )
    {
        pMob->spec_fun = NULL;

        send_to_char( "Spec removed.\n\r", ch);
        return TRUE;
    }

    if ( spec_lookup( argument ) )
    {
	pMob->spec_fun = spec_lookup( argument );
	send_to_char( "Spec set.\n\r", ch);
	return TRUE;
    }

    send_to_char( "MEdit: No such special function.\n\r", ch );
    return FALSE;
}

MEDIT( medit_resists )
{
	MobIndex *pMob;
	int resist;
	int value;
	char arg[MAX_STRING_LENGTH];

	EDIT_MOB(ch,pMob);

	argument = one_argument( argument, arg );
	if( argument[0] == '\0' || arg[0] == '\0' )
	{
		cprintf(ch,"Syntax:   resist <resist_type> <value>\n\r");
		return FALSE;
	}

    if ( ( resist = flag_value( resist_flags, arg ) ) == NO_FLAG )
	{
		cprintf(ch,"[%s] is not a valid resist type.  Type ? resists to see the types.\n\r",arg);
		return FALSE;
	}

    if ( !str_prefix(argument,"immune") )
    {
        if ( pMob->resists[resist] == RESIST_IMMUNE )
            pMob->resists[resist] = race_table[pMob->race].resists[resist];
        else
            pMob->resists[resist] = RESIST_IMMUNE;

        cprintf(ch,"RESIST %s set to %s.\n\r",
            capitalize(resist_flags[resist].name),
            pMob->resists[resist] == RESIST_IMMUNE ? "IMMUNE" : "NOT IMMUNE" );
        return TRUE;
    }
       
    if ( !is_number( argument ) )
    {
        return medit_resists(ch,"");
    }

	value = atoi(argument);
	if( abs(value) > 100 )
	{
		cprintf(ch,"Valid resist range is -100 to +100\n\r");
		return FALSE;
	}

	pMob->resists[resist] = value;
	cprintf(ch,"RESIST TYPE %s set to %d.\n\r", capitalize(resist_flags[resist].name), value );
	return TRUE;
}
	
MEDIT( medit_deity )
{
	MobIndex *pMob;
	int deity;

	EDIT_MOB(ch,pMob);

	if ( argument[0] == '\0' )
	{
		cprintf(ch,"Syntax:  deity [deity_name]\n\r"
                   "         deity clear\n\r");
		return FALSE;
	}

	if( !str_cmp(argument,"clear") )
	{
		pMob->alignment = -1;
		cprintf(ch,"DEITY setting cleared.\n\r");
		return TRUE;
	}

	if( (deity = deity_lookup(argument)) < 0 )
	{
		cprintf(ch,"NO SUCH DEITY [%s]\n\r", argument);
		return FALSE;
	}

	pMob->alignment = deity;
	cprintf(ch,"DEITY set to [%s].\n\r", deity_table[deity].name);
	return TRUE;
}

MEDIT( medit_align )
{
	return medit_deity(ch,argument);
}



MEDIT( medit_level )
{
    MobIndex *pMob;

    EDIT_MOB(ch, pMob);

    if ( argument[0] == '\0' || !is_number( argument ) )
    {
	send_to_char( "Syntax:  level [number]\n\r", ch );
	return FALSE;
    }

    pMob->level = atoi( argument );

    send_to_char( "Level set.\n\r", ch);
    return TRUE;
}



MEDIT( medit_desc )
{
    MobIndex *pMob;

    EDIT_MOB(ch, pMob);

    if ( argument[0] == '\0' )
    {
	string_append( ch, &pMob->description );
	return TRUE;
    }

    send_to_char( "Syntax:  desc    - line edit\n\r", ch );
    return FALSE;
}




MEDIT( medit_long )
{
    MobIndex *pMob;

    EDIT_MOB(ch, pMob);

    if ( argument[0] == '\0' )
    {
	send_to_char( "Syntax:  long [string]\n\r", ch );
	return FALSE;
    }

    free_string( pMob->long_descr );
    strcat( argument, "\n\r" );
    pMob->long_descr = str_dup( argument );
    pMob->long_descr[0] = UPPER( pMob->long_descr[0]  );

    send_to_char( "Long description set.\n\r", ch);
    return TRUE;
}

MEDIT( medit_attackecho )
{
	MobIndex *pMob;

	EDIT_MOB(ch,pMob);

	if ( argument[0] == '\0' )
	{
		cprintf(ch,"Syntax:  attackecho [message]\n\r");
		return FALSE;
	}

	if( pMob->attack_echo != NULL )
		free_string( pMob->attack_echo );

	if( !str_cmp(argument,"none") )
	{
		cprintf(ch,"Attack mesage cleared.\n\r");
		pMob->attack_echo = NULL;
		return TRUE;
	}

	pMob->attack_echo = str_dup( argument );

	cprintf(ch,"Attack message set to: [%s]\n\r", argument );
	return TRUE;
}

MEDIT( medit_spawnecho )
{
    MobIndex *pMob;

    EDIT_MOB(ch,pMob);

    if ( argument[0] == '\0' )
    {
        cprintf(ch,"Syntax:  spawn [message]\n\r");
        return FALSE;
    }

    if( pMob->spawn_echo != NULL )
        free_string( pMob->spawn_echo );

    if( !str_cmp(argument,"none") )
    {
        cprintf(ch,"Spawn mesage cleared.\n\r");
        pMob->spawn_echo = NULL;
        return TRUE;
    }

    pMob->spawn_echo = str_dup( argument );

    cprintf(ch,"Spawn message set to: [%s]\n\r", argument );
    return TRUE;
}

MEDIT( medit_deathecho )
{
    MobIndex *pMob;

    EDIT_MOB(ch,pMob);

    if ( argument[0] == '\0' )
    {
        cprintf(ch,"Syntax:  deathecho [message]\n\r");
        return FALSE;
    }

    if( pMob->death_echo != NULL )
        free_string( pMob->death_echo );

    if( !str_cmp(argument,"none") )
    {
        cprintf(ch,"Death mesage cleared.\n\r");
        pMob->death_echo = NULL;
        return TRUE;
    }

    pMob->death_echo = str_dup( argument );

    cprintf(ch,"Death message set to: [%s]\n\r", argument );
    return TRUE;
}


MEDIT( medit_short )
{
    MobIndex *pMob;

    EDIT_MOB(ch, pMob);

    if ( argument[0] == '\0' )
    {
	send_to_char( "Syntax:  short [string]\n\r", ch );
	return FALSE;
    }

    free_string( pMob->short_descr );
    pMob->short_descr = str_dup( argument );

    send_to_char( "Short description set.\n\r", ch);
    return TRUE;
}



MEDIT( medit_name )
{
    MobIndex *pMob;

    EDIT_MOB(ch, pMob);

    if ( argument[0] == '\0' )
    {
	send_to_char( "Syntax:  name [string]\n\r", ch );
	return FALSE;
    }

    free_string( pMob->player_name );
    pMob->player_name = str_dup( argument );

    send_to_char( "Name set.\n\r", ch);
    return TRUE;
}




MEDIT( medit_shop )
{
    MobIndex *pMob;
    char command[MAX_INPUT_LENGTH];
    char arg1[MAX_INPUT_LENGTH];

    argument = one_argument( argument, command );
    argument = one_argument( argument, arg1 );

    EDIT_MOB(ch, pMob);

    if ( command[0] == '\0' )
    {
	    cprintf(ch, "Syntax:  shop type [0-4] [item type]\n\r"
                    "         shop type [0-4] clear\n\r"
                    "         shop hours [opening] [closing]\n\r"
	                "         shop profit [buying%] [selling%]\n\r"
	                "         shop delete\n\r" );
	    return FALSE;
    }


    if ( !str_cmp( command, "hours" ) )
    {
        if ( !pMob->pShop )
        {
            cprintf(ch,"There are no shops on this NPC.\n\r");
            return FALSE;
        }

	    if ( arg1[0] == '\0' || !is_number( arg1 )
	    || argument[0] == '\0' || !is_number( argument ) )
	    {
	        cprintf(ch, "Syntax:  shop hours [#opening] [#closing]\n\r" );
	        return FALSE;
	    }
    
	    pMob->pShop->open_hour = atoi( arg1 );
	    pMob->pShop->close_hour = atoi( argument );

	    cprintf(ch, "Shop hours set to open at %d and close at %d.\n\r",
            pMob->pShop->open_hour, pMob->pShop->close_hour );
	    return TRUE;
    }


    if ( !str_cmp( command, "profit" ) )
    {
        if ( !pMob->pShop )
        {
            cprintf(ch,"There is no shop on this NPC.\n\r");
            return FALSE;
        }

	    if ( arg1[0] == '\0' || !is_number( arg1 )
	    || argument[0] == '\0' || !is_number( argument ) )
	    {
	        cprintf( ch,"Syntax:  shop profit [#buying%] [#selling%]\n\r" );
	        return FALSE;
	    }

	    pMob->pShop->profit_buy     = atoi( arg1 );
	    pMob->pShop->profit_sell    = atoi( argument );

	    cprintf(ch, "Shop will buy at %d%% of the value of items.\n\r"
                    "Shop will sell at %d%% markup over value of items.\n\r",
            pMob->pShop->profit_buy, pMob->pShop->profit_sell );
	    return TRUE;
    }


    if ( !str_cmp( command, "type" ) )
    {
	    int value;

	    if ( arg1[0] == '\0' || !is_number( arg1 ) || argument[0] == '\0' )
	    {
	        cprintf(ch,"Syntax:  shop type [#0-4] [item type]\n\r" );
	        return FALSE;
	    }

	    if ( atoi( arg1 ) >= MAX_TRADE )
	    {
	        cprintf( ch, "MEdit:  May sell %d items max.\n\r", MAX_TRADE );
	        return FALSE;
	    }

        if ( !str_cmp(argument,"clear") )
            value = 0;
        else
	    if ( ( value = flag_value( type_flags, argument ) ) == NO_FLAG )
	    {
	        cprintf( ch, "REdit:  That type of item is not known.\n\r" );
	        return FALSE;
	    }

	    if ( !pMob->pShop )
	    {
	        pMob->pShop         = new_shop();
	        pMob->pShop->keeper = pMob->vnum;
	        shop_last->next     = pMob->pShop;
	    }

	    pMob->pShop->buy_type[atoi( arg1 )] = value;

	    cprintf(ch, "Shop type set to %s.\n\r", flag_string(type_flags,value) );
	    return TRUE;
    }


    if ( !str_cmp( command, "delete" ) )
    {
	    int value;
	    
	    if ( arg1[0] == '\0' || !is_number( arg1 ) )
	    {
	        send_to_char( "Syntax:  shop delete [#0-4]\n\r", ch );
	        return FALSE;
	    }

	    value = atoi( argument );
	
	    if ( !pMob->pShop )
	    {
	        send_to_char( "MEdit:  Non-existant shop.\n\r", ch );
	        return FALSE;
	    }

        free_shop( pMob->pShop );
        pMob->pShop = NULL;
	    cprintf(ch,"Shop deleted.  This is NPC is no longer a <Merchant>.\n\r");
	    return TRUE;
    }

    medit_shop( ch, "" );
    return FALSE;
}


/* ROM medit functions: */


MEDIT( medit_sex )          /* Moved out of medit() due to naming conflicts -- Hugin */
{
    MobIndex *pMob;
    int value;

    if ( argument[0] != '\0' )
    {
	EDIT_MOB( ch, pMob );

	if ( ( value = flag_value( sex_flags, argument ) ) != NO_FLAG )
	{
	    pMob->sex = value;

	    send_to_char( "Sex set.\n\r", ch);
	    return TRUE;
	}
    }

    send_to_char( "Syntax: sex [sex]\n\r"
		  "Type '? sex' for a list of flags.\n\r", ch );
    return FALSE;
}


MEDIT( medit_act )          /* Moved out of medit() due to naming conflicts -- Hugin */
{
    MobIndex *pMob;
    int value;

    if ( argument[0] != '\0' )
    {
	EDIT_MOB( ch, pMob );

	if ( ( value = flag_value( act_flags, argument ) ) != NO_FLAG )
	{
	    pMob->act ^= value;
	    SET_BIT( pMob->act, ACT_IS_NPC );

	    send_to_char( "Act flag toggled.\n\r", ch);
	    return TRUE;
	}
    }

    send_to_char( "Syntax: act [flag]\n\r"
		  "Type '? act' for a list of flags.\n\r", ch );
    return FALSE;
}


MEDIT( medit_affect )      /* Moved out of medit() due to naming conflicts -- Hugin */
{
    MobIndex *pMob;
    int value;

    if ( argument[0] != '\0' )
    {
	EDIT_MOB( ch, pMob );

	if ( ( value = flag_value( affect_flags, argument ) ) != NO_FLAG )
	{
	    pMob->affected_by ^= value;

	    send_to_char( "Affect flag toggled.\n\r", ch);
	    return TRUE;
	}
    }

    send_to_char( "Syntax: affect [flag]\n\r"
		  "Type '? affect' for a list of flags.\n\r", ch );
    return FALSE;
}



MEDIT( medit_ac )
{
    MobIndex *pMob;
    char arg[MAX_INPUT_LENGTH];
    int pierce, bash, slash, exotic;

    do   /* So that I can use break and send the syntax in one place */
    {
	if ( argument[0] == '\0' )  break;

	EDIT_MOB(ch, pMob);
	argument = one_argument( argument, arg );

	if ( !is_number( arg ) )  break;
	pierce = atoi( arg );
	argument = one_argument( argument, arg );

	if ( arg[0] != '\0' )
	{
	    if ( !is_number( arg ) )  break;
	    bash = atoi( arg );
	    argument = one_argument( argument, arg );
	}
	else
	    bash = pMob->ac[AC_BASH];

	if ( arg[0] != '\0' )
	{
	    if ( !is_number( arg ) )  break;
	    slash = atoi( arg );
	    argument = one_argument( argument, arg );
	}
	else
	    slash = pMob->ac[AC_SLASH];

	if ( arg[0] != '\0' )
	{
	    if ( !is_number( arg ) )  break;
	    exotic = atoi( arg );
	}
	else
	    exotic = pMob->ac[AC_EXOTIC];

	pMob->ac[AC_PIERCE] = pierce;
	pMob->ac[AC_BASH]   = bash;
	pMob->ac[AC_SLASH]  = slash;
	pMob->ac[AC_EXOTIC] = exotic;
	
	send_to_char( "Ac set.\n\r", ch );
	return TRUE;
    } while ( FALSE );    /* Just do it once.. */

    send_to_char( "Syntax:  ac [ac-pierce [ac-bash [ac-slash [ac-exotic]]]]\n\r"
		  "help MOB_AC  gives a list of reasonable ac-values.\n\r", ch );
    return FALSE;
}

MEDIT( medit_form )
{
    MobIndex *pMob;
    int value;

    if ( argument[0] != '\0' )
    {
	EDIT_MOB( ch, pMob );

	if ( ( value = flag_value( form_flags, argument ) ) != NO_FLAG )
	{
	    pMob->form ^= value;
	    send_to_char( "Form toggled.\n\r", ch );
	    return TRUE;
	}
    }

    send_to_char( "Syntax: form [flags]\n\r"
		  "Type '? form' for a list of flags.\n\r", ch );
    return FALSE;
}


MEDIT( medit_part )
{
    MobIndex *pMob;
    int value;

    if ( argument[0] != '\0' )
    {
	EDIT_MOB( ch, pMob );

	if ( ( value = flag_value( part_flags, argument ) ) != NO_FLAG )
	{
	    pMob->parts ^= value;
	    send_to_char( "Parts toggled.\n\r", ch );
	    return TRUE;
	}
    }

    send_to_char( "Syntax: part [flags]\n\r"
		  "Type '? part' for a list of flags.\n\r", ch );
    return FALSE;
}

MEDIT( medit_imm )    
{
    MobIndex *pMob;
    int resist;  

    if ( argument[0] != '\0' )  
    {
        EDIT_MOB( ch, pMob );

        if ( ( resist = flag_value( resist_flags, argument ) ) == NO_FLAG )
        {         
            cprintf(ch,"[%s] is not a valid resist type.  Type ? resists to see the types.\n\r",argument);
            return FALSE;
        }

        pMob->resists[resist] = RESIST_IMMUNE;
		cprintf(ch,"Resist set to IMMUNE.\n\r");
		return TRUE;
    }    

    send_to_char( "Syntax: imm [flag]\n\rType '? imm' for a list of flags.\n\r", ch );   
    return FALSE;
}

MEDIT( medit_off )
{
    MobIndex *pMob;
    int value;

    if ( argument[0] != '\0' )
    {
	EDIT_MOB( ch, pMob );

	if ( ( value = flag_value( off_flags, argument ) ) != NO_FLAG )
	{
	    pMob->off_flags ^= value;
	    send_to_char( "Offensive behaviour toggled.\n\r", ch );
	    return TRUE;
	}
    }

    send_to_char( "Syntax: off [flags]\n\r"
		  "Type '? off' for a list of flags.\n\r", ch );
    return FALSE;
}

MEDIT( medit_damtype )
{
    MobIndex *pMob;
    int value;

    if ( argument[0] != '\0' )
    {
        EDIT_MOB( ch, pMob );

        if ( ( value = flag_value( weapon_flags, argument ) ) != NO_FLAG )
        {
            pMob->dam_type = value;
            cprintf(ch,"DAM TYPE SET TO '%s'.\n\r", attack_table[pMob->dam_type].name);
            return TRUE;
        }
    }

    send_to_char( "Syntax: damtype [type]\n\r"
                  "Type '? damtype' for a list of damage types.\n\r", ch );
    return FALSE;
}

MEDIT( medit_size )
{
    MobIndex *pMob;
    int value;

    if ( argument[0] != '\0' )
    {
	EDIT_MOB( ch, pMob );

	if ( ( value = flag_value( size_flags, argument ) ) != NO_FLAG )
	{
	    pMob->size = value;
	    send_to_char( "Size set.\n\r", ch );
	    return TRUE;
	}
    }

    send_to_char( "Syntax: size [size]\n\r"
		  "Type '? size' for a list of sizes.\n\r", ch );
    return FALSE;
}

MEDIT( medit_hitdice )
{
    static char syntax[] = "Syntax:  hitdice <number> d <type> + <bonus>\n\r";
    char *num, *type, *bonus, *cp;
    MobIndex *pMob;

    EDIT_MOB( ch, pMob );

    if ( argument[0] == '\0' )
    {
	send_to_char( syntax, ch );
	return FALSE;
    }

    num = cp = argument;

    while ( isdigit( *cp ) ) ++cp;
    while ( *cp != '\0' && !isdigit( *cp ) )  *(cp++) = '\0';

    type = cp;

    while ( isdigit( *cp ) ) ++cp;
    while ( *cp != '\0' && !isdigit( *cp ) ) *(cp++) = '\0';

    bonus = cp;

    while ( isdigit( *cp ) ) ++cp;
    if ( *cp != '\0' ) *cp = '\0';

    if ( ( !is_number( num   ) || atoi( num   ) < 1 )
    ||   ( !is_number( type  ) || atoi( type  ) < 1 ) 
    ||   ( !is_number( bonus ) || atoi( bonus ) < 0 ) )
    {
	send_to_char( syntax, ch );
	return FALSE;
    }

    pMob->hit[DICE_NUMBER] = atoi( num   );
    pMob->hit[DICE_TYPE]   = atoi( type  );
    pMob->hit[DICE_BONUS]  = atoi( bonus );

    send_to_char( "Hitdice set.\n\r", ch );
    return TRUE;
}

MEDIT( medit_manadice )
{
    static char syntax[] = "Syntax:  manadice <number> d <type> + <bonus>\n\r";
    char *num, *type, *bonus, *cp;
    MobIndex *pMob;

    EDIT_MOB( ch, pMob );

    if ( argument[0] == '\0' )
    {
	send_to_char( syntax, ch );
	return FALSE;
    }

    num = cp = argument;

    while ( isdigit( *cp ) ) ++cp;
    while ( *cp != '\0' && !isdigit( *cp ) )  *(cp++) = '\0';

    type = cp;

    while ( isdigit( *cp ) ) ++cp;
    while ( *cp != '\0' && !isdigit( *cp ) ) *(cp++) = '\0';

    bonus = cp;

    while ( isdigit( *cp ) ) ++cp;
    if ( *cp != '\0' ) *cp = '\0';

    if ( !( is_number( num ) && is_number( type ) && is_number( bonus ) ) )
    {
	send_to_char( syntax, ch );
	return FALSE;
    }

    if ( ( !is_number( num   ) || atoi( num   ) < 1 )
    ||   ( !is_number( type  ) || atoi( type  ) < 1 ) 
    ||   ( !is_number( bonus ) || atoi( bonus ) < 0 ) )
    {
	send_to_char( syntax, ch );
	return FALSE;
    }

    pMob->mana[DICE_NUMBER] = atoi( num   );
    pMob->mana[DICE_TYPE]   = atoi( type  );
    pMob->mana[DICE_BONUS]  = atoi( bonus );

    send_to_char( "Manadice set.\n\r", ch );
    return TRUE;
}

MEDIT( medit_damdice )
{
    static char syntax[] = "Syntax:  damdice <number> d <type> + <bonus>\n\r";
    char *num, *type, *bonus, *cp;
    MobIndex *pMob;

    EDIT_MOB( ch, pMob );

    if ( argument[0] == '\0' )
    {
	send_to_char( syntax, ch );
	return FALSE;
    }

    num = cp = argument;

    while ( isdigit( *cp ) ) ++cp;
    while ( *cp != '\0' && !isdigit( *cp ) )  *(cp++) = '\0';

    type = cp;

    while ( isdigit( *cp ) ) ++cp;
    while ( *cp != '\0' && !isdigit( *cp ) ) *(cp++) = '\0';

    bonus = cp;

    while ( isdigit( *cp ) ) ++cp;
    if ( *cp != '\0' ) *cp = '\0';

    if ( !( is_number( num ) && is_number( type ) && is_number( bonus ) ) )
    {
	send_to_char( syntax, ch );
	return FALSE;
    }

    if ( ( !is_number( num   ) || atoi( num   ) < 1 )
    ||   ( !is_number( type  ) || atoi( type  ) < 1 ) 
    ||   ( !is_number( bonus ) || atoi( bonus ) < 0 ) )
    {
	send_to_char( syntax, ch );
	return FALSE;
    }

    pMob->damage[DICE_NUMBER] = atoi( num   );
    pMob->damage[DICE_TYPE]   = atoi( type  );
    pMob->damage[DICE_BONUS]  = atoi( bonus );

    send_to_char( "Damdice set.\n\r", ch );
    return TRUE;
}


MEDIT( medit_class )
{
    MobIndex *pMob;
    int class;

    if ( argument[0] != '\0'
    && ( class = class_lookup( argument ) ) >= 0 )
    {
	EDIT_MOB( ch, pMob );

	pMob->class = class;

	cprintf(ch,"Class set to [%s].\n\r",class_table[pMob->class].name);
	return TRUE;
    }

    if ( argument[0] == '?' )
    {
	char buf[MAX_STRING_LENGTH];

	send_to_char( "Available classes are: ", ch );

	for ( class = 0; class < MAX_CLASS ; class++ )
	{
	    if ( ( class % 3 ) == 0 )
		send_to_char( "\n\r", ch );
	    sprintf( buf, " %-15s", class_table[class].name );
	    send_to_char( buf, ch );
	}

	send_to_char( "\n\r", ch );
	return FALSE;
    }

    send_to_char( "Syntax:  class [class]\n\r"
		  "Type 'class ?' for a list of classes.\n\r", ch );
    return FALSE;
}

MEDIT( medit_race )
{
    MobIndex *pMob;
    int race;

    if ( argument[0] != '\0'
    && ( race = race_lookup( argument ) ) != 0 )
    {
	int i;

	EDIT_MOB( ch, pMob );

	pMob->race = race;
	pMob->off_flags   = race_table[race].off;
	pMob->imm_flags   = race_table[race].imm;
	pMob->form        = race_table[race].form;
	pMob->parts       = race_table[race].parts;

	for( i=0 ; i < MAX_RESIST ; i++ )
		pMob->resists[i] = race_table[race].resists[i];

	send_to_char( "Race set.\n\r", ch );
	return TRUE;
    }

    if ( argument[0] == '?' )
    {
	char buf[MAX_STRING_LENGTH];

	send_to_char( "Available races are:", ch );

	for ( race = 0; race_table[race].name != NULL; race++ )
	{
	    if ( ( race % 3 ) == 0 )
		send_to_char( "\n\r", ch );
	    sprintf( buf, " %-15s", race_table[race].name );
	    send_to_char( buf, ch );
	}

	send_to_char( "\n\r", ch );
	return FALSE;
    }

    send_to_char( "Syntax:  race [race]\n\r"
		  "Type 'race ?' for a list of races.\n\r", ch );
    return FALSE;
}


MEDIT( medit_position )
{
    MobIndex *pMob;
    char arg[MAX_INPUT_LENGTH];
    int value;

    argument = one_argument( argument, arg );

    switch ( arg[0] )
    {
    default:
	break;

    case 'S':
    case 's':
	if ( str_prefix( arg, "start" ) )
	    break;

	if ( ( value = position_lookup( argument ) ) < 0 )
	    break;

	EDIT_MOB( ch, pMob );

	pMob->start_pos = value;
	send_to_char( "Start position set.\n\r", ch );
	return TRUE;

    case 'D':
    case 'd':
	if ( str_prefix( arg, "default" ) )
	    break;

	if ( ( value = position_lookup( argument ) ) < 0 )
	    break;

	EDIT_MOB( ch, pMob );

	pMob->default_pos = value;
	send_to_char( "Default position set.\n\r", ch );
	return TRUE;
    }

    send_to_char( "Syntax:  position [start/default] [position]\n\r"
		  "Type '? position' for a list of positions.\n\r", ch );
    return FALSE;
}


MEDIT( medit_gold )
{
    MobIndex *pMob;

    EDIT_MOB(ch, pMob);

    if ( argument[0] == '\0' || !is_number( argument ) )
    {
	send_to_char( "Syntax:  gold [number]\n\r", ch );
	return FALSE;
    }

    pMob->wealth = atoi( argument );

    send_to_char( "Gold set.\n\r", ch);
    return TRUE;
}

MEDIT( medit_spellaffects )
{
	cprintf(ch,"Syntax:   spellaffect 'spell name'\n\r");

	return TRUE;
}

MEDIT( medit_copy )
{
	MobIndex *pMob, *copy_source;
	int value;

	EDIT_MOB( ch, pMob );

	if ( *argument == '\0' )
	{
		cprintf(ch,"Syntax:  copy <mob vnum to copy>\n\r");
		return TRUE;
	}

    value = atoi( argument );
    if ( value <= 0 )
    {
        cprintf(ch,"The mob vnum you want to copy from has to be a positive integer.\n\r");
        return TRUE;
    }

    if ( (copy_source = get_mob_index( value )) == NULL )
    {
        cprintf(ch,"No such NPC with vnum %d.\n\r", value );
        return TRUE;
    }

    copyMobIndex( pMob, copy_source );
    cprintf(ch,"NPC %d (%s) copied to %d.\n\r",
        value, copy_source->short_descr, pMob->vnum );
    return TRUE;
}

MEDIT( medit_factions )
{
	MobIndex *pMob;
	char	arg[MAX_INPUT_LENGTH];
	int		aggroPoint = FACTION_AGGRESSIVE;
	int		passivePoint = FACTION_FRIENDLY;

	EDIT_MOB(ch, pMob);

	argument = one_argument( argument, arg );
	if ( arg[0] == '\0' )
	{
		cprintf(ch,"Usage:  faction add <ally|enemy> <faction_name> [-a<aggro> -f<friendly>]\n\r"
                   "        faction remove <faction_name>\n\r");
		return FALSE;
	}

    if ( !str_cmp(arg,"remove") || !str_cmp(arg,"delete"))
    {
        Faction *f;

		if( (f = findFactionOnChar( pMob, argument )) == NULL )
		{
			cprintf(ch,"No such faction on this NPC.\n\r");
			return FALSE;
		}

		if ( !removeFactionFromList( &(pMob->factions), f ) )
		{
			cprintf(ch,"No such faction on this NPC.\n\r");
			return FALSE;
		}

		cprintf(ch,"Faction removed.\n\r");
		free_faction(f);
		return TRUE;
	}
	else
    if ( !str_cmp(arg,"create") || !str_cmp(arg,"add") || !str_cmp(arg,"new") )
    {
        Faction *find, *f;
		char arg2[MAX_INPUT_LENGTH];
		long standing;

		argument = one_argument(argument,arg2);
		if( arg2[0] == '\0' )
			return medit_factions(ch,"");

		if( !str_prefix(arg2,"ally") )
			standing = FACTION_MEMBER_OF;
		else
		if( !str_prefix(arg2,"enemy") )
			standing = FACTION_ENEMY_OF;
		else
		{
			cprintf(ch,"Usage error: arg2 must be 'enemy' or 'ally'\n\r");
			return FALSE;
		}

		argument = one_argument( argument, arg );
        if ( (find = factionLookup(arg)) == NULL )
        {
            cprintf(ch,"Such a faction does not exist.\n\r");
            return FALSE;
        }

		do
		{
			argument = one_argument( argument, arg );
			if ( arg[0] == '\0' )
				break;
			if ( *arg != '-' )
			{
				cprintf(ch,"To set Aggressive and Passive points, use -p#### or -a###.\n\r"
						   "For example:  faction add ally 'khavanov guard' -p2000 -a-2000.\n\r"
						   " (Mob is passive at +2000 faction, aggressive at -2000 faction)\n\r" );
				return FALSE;
			}
			switch( arg[1] ) {
				case 'p': case 'P':
					passivePoint = atoi( arg+2 ); break;
				case 'a': case 'A':
					aggroPoint = atoi( arg+2 ); break;
				default:
					cprintf(ch,"Ignoring aggressive/passive points - bad syntax.\n\r");
					break;
			}
		} while ( argument[0] != '\0' );

        f = new_faction();
        f->name = str_dup( find->name ); /* don't need a new string space for this */
		f->standing = standing;
		f->factionID = abs(find->factionID);
		f->aggroPoint = aggroPoint;
		f->passivePoint = passivePoint;
        f->next = pMob->factions;

        pMob->factions = f;

        cprintf(ch,"Faction [%s] added to mob list.\n\r", f->name);
        return TRUE;
    }
	else
		return medit_factions(ch,"");
}

MEDIT( medit_regen )
{
    MobIndex *pMob;

    EDIT_MOB(ch, pMob);

    if ( argument[0] == '\0' || !is_number( argument ) )
    {
        send_to_char( "Syntax:  regen [number]\n\r", ch );
        return FALSE;
    }

    pMob->regen = atoi( argument );

    send_to_char( "Regeneration set.\n\r", ch);
    return TRUE;
}

MEDIT( medit_hitroll )
{
    MobIndex *pMob;

    EDIT_MOB(ch, pMob);

    if ( argument[0] == '\0' || !is_number( argument ) )
    {
	send_to_char( "Syntax:  hitroll [number]\n\r", ch );
	return FALSE;
    }

    pMob->hitroll = atoi( argument );

    send_to_char( "Hitroll set.\n\r", ch);
    return TRUE;
}

void copyMob_Factions( MobIndex *mob, Faction *f )
{
	Faction *new;

	if ( f == NULL )
		return;

	if ( f->next )
		copyMob_Factions( mob, f->next );

	new = new_faction();
	new->name = f->name;
	new->standing = f->standing;
	new->factionID = f->factionID;
	new->aggroPoint = f->aggroPoint;
	new->passivePoint = f->passivePoint;

	new->next = mob->factions;
	mob->factions = new;
}

void copyMobIndex( MobIndex *new, MobIndex *orig )
{
	int i;

	new->player_name		= str_dup( orig->player_name );
	new->short_descr		= str_dup( orig->short_descr );
	new->long_descr			= str_dup( orig->long_descr );
	new->description		= str_dup( orig->description );

	if ( orig->spawn_echo )
		new->spawn_echo			= str_dup( orig->spawn_echo );
	else
		new->spawn_echo			= NULL;

	if ( orig->attack_echo )
		new->attack_echo		= str_dup( orig->attack_echo );
	else
		new->attack_echo		= NULL;

	if ( orig->death_echo )
		new->death_echo			= str_dup( orig->death_echo );
	else
		new->death_echo			= NULL;

	new->race			= orig->race;
	new->class			= orig->class;
	new->act			= orig->act;
	new->alignment		= orig->alignment;
	new->affected_by 	= orig->affected_by;
	new->level			= orig->level;
	new->hitroll		= orig->hitroll;
	new->hit[DICE_NUMBER]	= orig->hit[DICE_NUMBER];
	new->hit[DICE_TYPE]		= orig->hit[DICE_TYPE];
	new->hit[DICE_BONUS]	= orig->hit[DICE_BONUS];

	new->mana[DICE_NUMBER]	= orig->mana[DICE_NUMBER];
	new->mana[DICE_TYPE]	= orig->mana[DICE_TYPE];
	new->mana[DICE_BONUS]	= orig->mana[DICE_BONUS];

	new->damage[DICE_NUMBER]	= orig->damage[DICE_NUMBER];
	new->damage[DICE_TYPE]		= orig->damage[DICE_TYPE];
	new->damage[DICE_BONUS]		= orig->damage[DICE_BONUS];

	new->dam_type		= orig->dam_type;
	for( i=0; i < 4 ; i++ )
		new->ac[i] = orig->ac[i];

	new->off_flags		= orig->off_flags;
	new->imm_flags		= orig->imm_flags;

	new->start_pos		= orig->start_pos;
	new->default_pos	= orig->default_pos;
	new->sex			= orig->sex;
	new->wealth			= orig->wealth;

	new->form			= orig->form;
	new->parts			= orig->parts;
	new->size			= orig->size;

    for( i = 0 ; i < MAX_RESIST ; i++ )
        new->resists[i] = orig->resists[i];

	copyMob_Factions( new, orig->factions );
    return;
}


