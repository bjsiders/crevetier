#ifndef object_h
#define object_h

// Artifacts
struct artifact_data
{
    bool            valid;
    Artifact *      next;
    int             level;    
    int             exp;
    long            flags;
    long            affects[MAX_LEVEL][10];
    bool            class_avail[MAX_CLASS];
};

struct obj_data
{
    Object *            next;
    Object *            next_content;
    Object *            contains;
    Object *            in_obj;
    Object *            on;
    Character *         carried_by;
    ExtraDescr *        extra_descr;
    Affect *            affected;
    ObjIndex *          pIndexData;
    Room *              in_room;
    bool                valid;
    int                 version;
    bool                enchanted;
    char *              owner;
    char *              name;
    char *              short_descr;
    char *              description;
    sh_int              item_type;
    int                 extra_flags;
    int                 wear_flags;
    sh_int              wear_loc;
    sh_int              weight;
    long                cost;
    sh_int              level;
    sh_int              condition;
    sh_int              durability;
    sh_int              quality;
    char *              material;
    sh_int              timer;
    int                 value[10];
    int                 despawn;
    Spawn *             spawn;
    int                 absorb;
    int                 deity;
    char *              crafter;
    Artifact*           artifact;
};

/*
 * Prototype for an object.
 */
struct    obj_index_data
{
    Area *              area;    /* OLC */
    ObjIndex *          next;    
    ExtraDescr *  extra_descr;
    Affect *       affected;
    int                 version;
    bool                new_format;
    char *              name;
    char *              short_descr;
    char *              description;
    sh_int              vnum;
    sh_int              reset_num;
    char *              material;
    sh_int              item_type;
    int                 extra_flags;
    int                 wear_flags;
    sh_int              level;
    sh_int              condition;
    sh_int              durability;
    sh_int              quality;
    sh_int              count;
    sh_int              weight;
    long                cost;
    int                 value[10];
    int                 deity;
    Artifact*           artifact;
};  

struct item_type
{
    int       type;
    char *    name;
};

struct weapon_type
{
    char *    name;
    sh_int    type;
    sh_int    *gsn;
    sh_int    crit_min;
    sh_int    crit_mult;
    sh_int    speed;
    long      dam_type;
};

struct liq_type
{
    char *    liq_name;
    char *    liq_color;
    sh_int    liq_affect[5];
};

/*
    Ranged flags.
*/
#define RANGE_CROSSBOW              (A)
#define RANGE_SHORTBOW              (B)
#define RANGE_LONGBOW               (C)
#define RANGE_COMPOSITE_LONGBOW     (D)

/*
    Item types
*/
#define ITEM_LIGHT                  1
#define ITEM_SCROLL                 2
#define ITEM_WAND                   3
#define ITEM_STAFF                  4
#define ITEM_WEAPON                 5
#define ITEM_TREASURE               8
#define ITEM_ARMOR                  9
#define ITEM_POTION                 10
#define ITEM_CLOTHING               11
#define ITEM_FURNITURE              12
#define ITEM_TRASH                  13
#define ITEM_CONTAINER              15
#define ITEM_DRINK_CON              17
#define ITEM_KEY                    18
#define ITEM_FOOD                   19
#define ITEM_MONEY                  20
#define ITEM_BOAT                   22
#define ITEM_CORPSE_NPC             23
#define ITEM_CORPSE_PC              24
#define ITEM_FOUNTAIN               25
#define ITEM_PILL                   26
#define ITEM_PROTECT                27
#define ITEM_MAP                    28
#define ITEM_PORTAL                 29
#define ITEM_WARP_STONE             30
#define ITEM_ROOM_KEY               31
#define ITEM_GEM                    32
#define ITEM_JEWELRY                33
#define ITEM_SPELLBOOK              35
#define ITEM_COMP_POUCH             36
#define ITEM_COMPONENT              37
#define ITEM_FORGE                  38
#define ITEM_HIDE                   39
#define ITEM_PRAYER_BOOK            40
#define ITEM_ARCANE_SCROLL          41
#define ITEM_INSTRUMENT             42    /* bards */
#define ITEM_LYRIC_SHEET            43
#define ITEM_VENOM_SAC              44
#define ITEM_BINDSTONE              45
#define ITEM_PROJECTILE             46
#define ITEM_MOBILE                 47
#define ITEM_SHRINE                 48

#define INSTR_PERCUSSION            1
#define INSTR_STRINGS               2
#define INSTR_WINDS                 4

/*
    Material flags
*/
#define MAT_STEEL                1
#define MAT_STONE                2
#define MAT_BRASS                3
#define MAT_BONE                 4
#define MAT_ENERGY               5
#define MAT_MITHRIL              6
#define MAT_COPPER               7
#define MAT_SILK                 8
#define MAT_MARBLE               9
#define MAT_GLASS                10
#define MAT_WATER                11
#define MAT_FLESH                12
#define MAT_PLATINUM             13
#define MAT_GRANITE              14
#define MAT_LEATHER              15
#define MAT_CLOTH                16
#define MAT_GEMSTONE             17
#define MAT_GOLD                 18
#define MAT_PORCELAIN            19
#define MAT_OBSIDIAN             20
#define MAT_DRAGONSCALE          21
#define MAT_EBONY                22
#define MAT_BRONZE               23
#define MAT_WOOD                 24
#define MAT_SILVER               25
#define MAT_IRON                 26
#define MAT_BLOODSTONE           27
#define MAT_FOOD                 28
#define MAT_LEAD                 29
#define MAT_WAX                  30
#define MAT_PEWTER               31
#define MAT_FUR                  32
#define MAT_PARCHMENT            33
#define MAT_HIDE                 34
#define MAT_CLAY                 35
#define MAT_SCALE                36
#define MAT_ORGANIC_M            37 // hack!

/* Material properites */
#define MAT_SOLID           (A)
#define MAT_LIQUID          (B)
#define MAT_GAS             (C)
#define MAT_VISCOUS         (D)
#define MAT_METAL           (E)
#define MAT_MINERAL         (F)
#define MAT_ORGANIC         (G)
#define MAT_COMBUSTABLE     (H)
#define MAT_MELTABLE        (I)
#define MAT_FRAGILE         (J)
#define MAT_HARD            (K)
#define MAT_FLEXIBLE        (L)
#define MAT_PRECIOUS        (M)
#define MAT_PROCESSED       (N)
#define MAT_EDIBLE          (O)
#define MAT_NONMATTER       (P) /* "energy", "nothingness", etc */

/* Corpse flags */
#define CORPSE_SKINNED      (A)
#define CORPSE_SACKED       (B)

/*
 * Extra flags.
 * Used in #OBJECTS.
 */
#define ITEM_INVIS              (F)
#define ITEM_MAGIC              (G)
#define ITEM_NODROP             (H)
#define ITEM_ANTI_GOOD          (J)
#define ITEM_ANTI_EVIL          (K)
#define ITEM_ANTI_NEUTRAL       (L)
#define ITEM_INVENTORY          (N)
#define ITEM_NOPURGE            (O)
#define ITEM_ROT_DEATH          (P)
#define ITEM_VIS_DEATH          (Q)
#define ITEM_KEEP_CONDITION     (R)
#define ITEM_NONMETAL           (S)
#define ITEM_MELT_DROP          (U)
#define ITEM_HAD_TIMER          (V)
#define ITEM_SELL_EXTRACT       (W)
#define ITEM_REINFORCED         (X)
#define ITEM_BURN_PROOF         (Y)
#define ITEM_STICKY             (Z)
#define ITEM_UNIQUE             (aa)
#define ITEM_NOSHOW             (bb)
#define ITEM_NORENT             (cc)
#define ITEM_NOLORE             (dd)


/*
 * Wear flags.
 * Used in #OBJECTS.
 */
#define ITEM_TAKE               (A)
#define ITEM_WEAR_FINGER        (B)
#define ITEM_WEAR_NECK          (C)
#define ITEM_WEAR_BODY          (D)
#define ITEM_WEAR_HEAD          (E)
#define ITEM_WEAR_LEGS          (F)
#define ITEM_WEAR_FEET          (G)
#define ITEM_WEAR_HANDS         (H)
#define ITEM_WEAR_ARMS          (I)
#define ITEM_WEAR_SHIELD        (J)
#define ITEM_WEAR_ABOUT         (K)
#define ITEM_WEAR_WAIST         (L)
#define ITEM_WEAR_WRIST         (M)
#define ITEM_WIELD              (N)
#define ITEM_HOLD               (O)
#define ITEM_NO_SAC             (P)
#define ITEM_WEAR_FLOAT         (Q)
#define ITEM_WEAR_EAR           (R)
#define ITEM_WEAR_FACE          (S)
#define ITEM_WEAR_SHOULDERS     (T)
#define ITEM_WEAR_OFFHAND       (U)
#define ITEM_WEAR_RANGED        (V)
#define ITEM_WEAR_INSTRUMENT    (W)

/*
    Weapon classifications
*/
#define WEAPON_EXOTIC               0
#define WEAPON_LONGSWORD            1
#define WEAPON_DAGGER               2
#define WEAPON_SPEAR                3
#define WEAPON_MACE                 4
#define WEAPON_AXE                  5
#define WEAPON_FLAIL                6
#define WEAPON_WHIP                 7
#define WEAPON_POLEARM              8
#define WEAPON_STAFF                9
#define WEAPON_DIRK                 10
#define WEAPON_STILLETO             11
#define WEAPON_MAIN_GAUCHE          12
#define WEAPON_KNIFE                13
#define WEAPON_RAPIER               14
#define WEAPON_SHORTSWORD           15
#define WEAPON_CUTLASS              16
#define WEAPON_FALCHION             17
#define WEAPON_BROADSWORD           18
#define WEAPON_BASTARD_SWORD        19
#define WEAPON_CLAYMORE             20
#define WEAPON_2H_SWORD             21
#define WEAPON_WARHAMMER            22
#define WEAPON_SCIMITAR             23
#define WEAPON_GLADIUS              24
#define WEAPON_DRUSUS               25
#define WEAPON_MORNINGSTAR          26
#define WEAPON_2H_WARHAMMER         27
#define WEAPON_THROWING_AXE         28
#define WEAPON_BATTLE_AXE           29
#define WEAPON_2H_WARAXE            30
#define WEAPON_CROSSBOW             31
#define WEAPON_SHORTBOW             32
#define WEAPON_LONGBOW              33
#define WEAPON_COMPOSITE_LONGBOW    34
#define WEAPON_JAVELIN              35
#define WEAPON_HARPOON              36
#define WEAPON_LANCE                37
#define WEAPON_TRIDENT              38
#define WEAPON_HALBERD              39
#define WEAPON_VOULGE               40
#define WEAPON_PIKE                 41
#define WEAPON_GLAIVE               42
#define WEAPON_RANSEUR              43
#define WEAPON_MAUL                 44
#define WEAPON_CLUB                 45
#define WEAPON_MACHETE              46
#define WEAPON_BARDICHE             47
#define WEAPON_HATCHET              48
#define WEAPON_PICK                 49
#define WEAPON_MALLET               50
#define WEAPON_SABRE                51
#define WEAPON_CLAW                 52
#define WEAPON_SICKLE               53
#define WEAPON_SCYTHE               54
#define WEAPON_QUARTERSTAFF         55
#define WEAPON_KATANA               56
#define WEAPON_SAI                  57
#define WEAPON_WAKIZASHI            58
#define WEAPON_NAGINATA             59
#define WEAPON_DIAKYU               60
#define WEAPON_BO_STICK             61
#define WEAPON_TETSUBO              62
#define WEAPON_HOOK                 63
#define WEAPON_FANG                 64
#define WEAPON_CHAIN                65
#define WEAPON_TAIL                 66

/** weapon types */
#define WEAPON_FLAMING              (A)
#define WEAPON_FROST                (B)
#define WEAPON_VAMPIRIC             (C)
#define WEAPON_SHARP                (D)
#define WEAPON_VORPAL               (E)
#define WEAPON_TWO_HANDS            (F)
#define WEAPON_SHOCKING             (G)
#define WEAPON_POISON               (H)
#define WEAPON_ONE_TIME_PROC        (L)
#define WEAPON_DECLINING_PROC       (M)

/* gate flags */
#define GATE_NORMAL_EXIT            (A)
#define GATE_NOCURSE                (B)
#define GATE_GOWITH                 (C)
#define GATE_BUGGY                  (D)
#define GATE_RANDOM                 (E)

/* furniture flags */
#define STAND_AT                    (A)
#define STAND_ON                    (B)
#define STAND_IN                    (C)
#define SIT_AT                      (D)
#define SIT_ON                      (E)
#define SIT_IN                      (F)
#define REST_AT                     (G)
#define REST_ON                     (H)
#define REST_IN                     (I)
#define SLEEP_AT                    (J)
#define SLEEP_ON                    (K)
#define SLEEP_IN                    (L)
#define PUT_AT                      (M)
#define PUT_ON                      (N)
#define PUT_IN                      (O)
#define PUT_INSIDE                  (P)

/*
 * Values for containers (value[1]).
 * Used in #OBJECTS.
 */
#define CONT_CLOSEABLE              (A)
#define CONT_PICKPROOF              (B)
#define CONT_CLOSED                 (C)
#define CONT_LOCKED                 (D)
#define CONT_PUT_ON                 (E)
#define CONT_QUIVER                 (F)

/*
 * Equpiment wear locations.
 * Used in #RESETS.
 */
#define WEAR_NONE                   -1
#define WEAR_LIGHT                  0
#define WEAR_FINGER_L               1
#define WEAR_FINGER_R               2
#define WEAR_NECK_1                 3
#define WEAR_NECK_2                 4
#define WEAR_BODY                   5
#define WEAR_HEAD                   6
#define WEAR_LEGS                   7
#define WEAR_FEET                   8
#define WEAR_HANDS                  9
#define WEAR_ARMS                   10
#define WEAR_SHIELD                 11
#define WEAR_ABOUT                  12
#define WEAR_WAIST                  13
#define WEAR_WRIST_L                14
#define WEAR_WRIST_R                15
#define WEAR_WIELD                  16
#define WEAR_HOLD                   17
#define WEAR_FLOAT                  18
#define WEAR_EAR_L                  19
#define WEAR_EAR_R                  20
#define WEAR_FACE                   21
#define WEAR_SHOULDERS              22
#define WEAR_OFFHAND                23
#define WEAR_RANGED                 24
#define WEAR_INSTRUMENT             25
#define MAX_WEAR                    26

/*
 * Liquids.
 */
#define LIQ_WATER        0

/*
    Object Macros
*/
#define PROC_ALWAYS                 -20000
#define HAS_PROC(obj)               ((obj)->value[7] > 1)
#define CAN_WEAR(obj, part)         (IS_SET((obj)->wear_flags, (part)))
#define IS_OBJ_STAT(obj, stat)      (IS_SET((obj)->extra_flags, (stat)))
#define IS_WEAPON_STAT(obj,stat)    (IS_SET((obj)->value[4],(stat)))
#define WEIGHT_MULT(obj)            ((obj)->item_type == ITEM_CONTAINER ? (obj)->value[4] : 100)

extern const struct item_type       item_table[];
extern const struct liq_type        liq_table[];

extern const   struct  weapon_type weapon_table    [MAX_WEAPONS];
#endif /* object_h */
