/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.
****************************************************************************/

/** 
 ** The Heirs of Crevetier, based on ArpensMUD
 ** Copyright 2002-2003 Benjamin J. Siders
 ** bjsiders@mac.com
 ** 
 ** Basic banking system with vaults.  Note that code relies on a method of
 ** saving the items in vaults and the banked currency in some manner.  I
 ** leave this implementation up to you.  Further note that this code has been
 ** through one (1) development cycle and is sloppily implemented in spots.
 ** For example, there's no global constant for the maximum number of items you
 ** can store; it's just hard-coded.  Feel free to tidy it up!  Further, the 
 ** system relies on variables and functions that are not part of a standard 
 ** ROM distribution.  Their purpose should be clear from their context.
 ** These also you'll have to divine for yourself or modify to suit your needs.
 ** 
 ** You may use, modify, and redistribute this file to your heart's content
 ** with the following limitations:
 ** 
 ** (1) This header must remain intact.
 ** (2) Any project or individual utilizing this code in whole or part may not 
 **     benefit in a material or financial capacity.  In other words, if you 
 **     wish to use this code in your MUD, no donations, no hardware gifts, 
 **     no services rendered, nothing.
 ** (3) Any project using this code in whole or part, as-is or modified, may
 **     not benefit in a material or financial capacity from redistribution 
 **     of it.  In other words, you got it for free, you distribute it and
 **     any modifications you've made to it for free.
 ** 
 ** I also request but do not require that you send me any changes or improvements
 ** you've made that may interest the mudding community.  Happy gaming!
 ** 
 ** July 17th, 2003
 **/

#include <sys/types.h>
#include <sys/time.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include "thoc.h"
#include "bank.h"

void do_convert( Character *ch, char *argument )
{
    convert_coins(ch, CONVERT_PERSONAL_BANK); 
}

void convert_coins( Character *ch, int conversion_loc )
{
    Character   *banker;
	int i;
    long *coins_bank;

    if(conversion_loc == CONVERT_PERSONAL_BANK)
    {
        coins_bank = ch->pcdata->coins_bank;        
    }
    else if(conversion_loc == CONVERT_GUILD_BANK)
    {
        coins_bank = ch->clan->banked;
    }
    else
    {
        log_bug("convert_coins: Illegal conversion_loc %d", conversion_loc);
        return;
    }

    if ( IS_NPC(ch) )
        return;

    for ( banker = ch->in_room->people ; banker != NULL ; banker = banker->next_in_room )
        if ( IS_NPC(banker) && IS_SET(banker->act,ACT_BANKER) )
            break;

    if ( banker == NULL )
    {
        cprintf(ch,"There's no banker here to convert your coins.\n\r");
        return;
    }

	/* Convert bank money */
    for( i=0 ; i < MAX_CURRENCY - 1 ; i++ )
    {
        if ( coins_bank[i] > 100 )
        {
            coins_bank[i+1] += ( coins_bank[i] / 100 );
            coins_bank[i] %= 100;
        }
    }

 	/* Convert inventory coins */
    if(conversion_loc == CONVERT_PERSONAL_BANK)
    {
        for( i=0 ; i < MAX_CURRENCY - 1 ; i++ )
        {
            if ( ch->coins[i] > 100 )
            {
                ch->coins[i+1] += ( ch->coins[i] / 100 );
                ch->coins[i] %= 100;
            }
        }
	
        cprintf(ch,"All your bank currencies and personal holdings have been traded up.\n\r");
        act("$n converts $s savings to higher currencies.",ch,NULL,NULL,TO_ROOM);
        check_encumbrance( ch );
    }
    else
    {
        cprintf(ch,"All your guilds bank currencies have been traded up.\n\r");
        act("$n converts $s guilds savings to higher currencies.",ch,NULL,NULL,TO_ROOM);
    }

    return;
}

void show_bank( Character *ch )
{
    Object *bank;
    int i;

    cprintf(ch,"Your bank account has the following balance:\n\r");
    for( i=0 ; currency_table[i].name != NULL ; i++ )
        cprintf(ch,"    &%c%-15s&x:   %-10ld\n\r", 
            currency_table[i].color, currency_table[i].name,
            ch->pcdata->coins_bank[i] );

    for ( bank = ch->pcdata->bank ; bank != NULL ; bank = bank->next_content )
        cprintf(ch,"   * %-s\n\r", bank->short_descr);   

    return;
}

void get_bank( Character *ch, int amount, int currency_type, char* obj_name, bool all_coins )
{
    Object *obj;
	Character *banker;

    if ( IS_NPC(ch) )
        return;

    for ( banker = ch->in_room->people ; banker != NULL ; banker = banker->next_in_room )
        if ( IS_NPC(banker) && IS_SET(banker->act,ACT_BANKER) )
            break;

    if ( banker == NULL )
    {
        cprintf(ch,"There's no banker here.\n\r");
        return;
    }

	if( obj_name != NULL )
    {
		if (str_cmp( obj_name, "all" ) && str_prefix( "all.", obj_name ))
		{
			/* get obj bank */
			if( (obj = get_obj_bank(ch, obj_name) ) == NULL )
			{
				cprintf(ch, "You don't have that in the bank.\n\r");
				return;
			}
			else
			{
				obj_from_bank( ch, obj );
				obj_to_char( obj, ch );
				act("You get $P from the bank.",ch,NULL,obj,TO_CHAR);
				act("$n gets $P from the bank.",ch,NULL,obj,TO_ROOM);
			}
		}
		else
		{
			bool found = FALSE;
			Object *obj_next;

			/* get all or get all.<item> bank */
			for( obj = ch->pcdata->bank; obj != NULL; obj = obj_next )
			{
				obj_next = obj->next_content;

				if( (obj_name[3] == '\0' || is_name( &obj_name[4], obj->name ) )
					&& can_see_obj( ch, obj ) )
				{
					found = TRUE;
					obj_from_bank( ch,obj );
					obj_to_char( obj,ch );
					act("You get $P from the bank.",ch,NULL,obj,TO_CHAR);
					act("$n gets $P from the bank.",ch,NULL,obj,TO_ROOM);
				}
			}

			if(!found)
			{
				if( obj_name[3] == '\0' )
					cprintf(ch, "Your bank doesn't have any items in it.\n\r");
				else
					cprintf(ch, "You don't have any in the bank.\n\r");

				return;
			}
		}
	}
	else
	{
		if(currency_type >= 0)
    	{
        	if ( amount < 0 )
        	{
            	cprintf(ch,"You can't withdraw negative money.\n\r");
            	return;
        	}

  	     	get_coins_from_bank(ch,amount,currency_type);
    	}
    	else if ( all_coins )
    	{
			int cur;
			bool found = FALSE;

	        for( cur = 0; currency_table[cur].name != NULL; cur ++ )
			{
				if(ch->pcdata->coins_bank[cur] > 0)
				{
					found = TRUE;
        	    	get_coins_from_bank(ch,ch->pcdata->coins_bank[cur],cur);
				}
			}
	
			if(!found)
			{
				cprintf(ch,"You don't have any money in the bank.\n\r");
				return;
			}
    	}
    	else
    	{
        	cprintf(ch,"Valid currency types are: silver, gold, electrum, platinum, alatinum.\n\r");
        	return;
    	}
	}

    check_encumbrance(ch);
    return;
}

void put_bank( Character *ch, int amount, int currency_type, char *obj_name, bool all_coins )
{
	Character *banker;

    if ( IS_NPC(ch) )
        return;

    for ( banker = ch->in_room->people ; banker != NULL ; banker = banker->next_in_room )
        if ( IS_NPC(banker) && IS_SET(banker->act,ACT_BANKER) )
            break;

    if ( banker == NULL )
    {
        cprintf(ch,"There's no banker here.\n\r");
        return;
    }

	if( obj_name != NULL )
    {
    	Object *obj;

        if ( (obj= get_obj_carry(ch,obj_name,ch) ) == NULL )
        {
            cprintf(ch,"You aren't carrying that.\n\r");
            return;
        }
        else if ( IS_SET(obj->extra_flags,ITEM_NODROP) )
        {
            cprintf(ch,"You can't seem to let go of it.\n\r");
            return;
        }
        else
        {
            Object *tObj;
            int count=0;
    
            /* Count account */
            for ( tObj = ch->pcdata->bank ; tObj!=NULL ; tObj = tObj->next_content )
                ++count;

            if ( ++count > BANK_MAX_ITEMS )
            {
                cprintf(ch,"You cannot deposit any more items.\n\r");
                return;
            }

            obj_from_char( obj );
            obj_to_bank( ch,obj );
            act("You put $P in the bank.",ch,NULL,obj,TO_CHAR);
            act("$n puts $P in the bank.",ch,NULL,obj,TO_ROOM);
            check_encumbrance(ch);
            return;
        }
    }

	if(currency_type >= 0)
    {
        if ( amount <= 0 )
        {
            cprintf(ch,"You can't deposit negative money.\n\r");
            return;
        }

       	put_coins_in_bank(ch,amount,currency_type);
    }
    else if ( all_coins )
    {
		int cur;
        for( cur = 0; currency_table[cur].name != NULL ; cur ++ )
            put_coins_in_bank(ch,ch->coins[cur],cur);
    }
    else
    {
        cprintf(ch,"Valid currency types are: silver, gold, electrum, platinum, alatinum.\n\r");
        return;
    }
    check_encumbrance(ch);
    return;
}

void obj_from_bank( Character *ch, Object *obj )
{
    Object *o;

    if ( ch->pcdata->bank == obj )
    {
        ch->pcdata->bank = obj->next_content;
        return;
    }

    for ( o = ch->pcdata->bank ; o->next_content != obj ; o = o->next_content )
        ;

    if ( o == NULL )
    {
        log_bug("Obj from bank: not found",0);
        return;
    }

    o->next_content = o->next_content->next_content;
}

void obj_to_bank( Character *ch, Object *obj )
{
    obj->next_content = ch->pcdata->bank;
    ch->pcdata->bank = obj;
}

void get_coins_from_bank( Character *ch, int amount, int index )
{
    if ( amount == 0 )
	{
		cprintf(ch, "You successfully withdrew no money from the bank, nice job.\n\r");
        return;
	}

    if ( ch->pcdata->coins_bank[index] < amount )
    {
		if(ch->pcdata->coins_bank[index] == 0)
			cprintf(ch,"You don't have any %s in the bank.\n\r", currency_table[index].name);
		else
        	cprintf(ch,"You only have %d %s in the bank.\n\r",
				ch->pcdata->coins_bank[index], currency_table[index].name );
        return;
    }

    ch->coins[index] += amount;
    ch->pcdata->coins_bank[index] -= amount;
    cprintf(ch,"You withdraw %d %s from the bank.\n\r",
        amount, currency_table[index].name);

	act("$n withdraws some coins from the bank.",ch,NULL,NULL,TO_ROOM);
    return;
}

void put_coins_in_bank( Character *ch, int amount, int index )
{
    if ( amount == 0 )
        return;

    if ( amount > ch->coins[index] )
    {
        cprintf(ch,"You don't have that many coins.\n\r");
        return;
    }

    ch->coins[index] -= amount;
    ch->pcdata->coins_bank[index] += amount;

    cprintf(ch,"You deposit %d %s in the bank.\n\r",
        amount, currency_table[index].name );

	act("$n deposits some coins in the bank.",ch,NULL,NULL,TO_ROOM);
    return;
}

Object *get_obj_bank( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Object *obj;
    int number;
    int count;

    number = number_argument( argument, arg );
    count  = 0;
    for ( obj = ch->pcdata->bank; obj != NULL; obj = obj->next_content )
    {
        if ( is_name( arg, obj->name ) )
        {
            if ( ++count == number )
                return obj;
        }
    }

    return NULL;
}
