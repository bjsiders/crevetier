/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/******************************************************************
 ArpensMUD 3.2, Server II.  Druidic Spell System "Fury" Release 0.2
 Copyright Benjamin J. Siders, Cross-Check MSDG 2001 
 
 The Druid-specific spells from the 'fury' release.  

 All of the "Fury" spells are based on concepts from:
 
 Ultima, EverQuest, Dungeons and Dragons, Advanced Dungeons and Dragons, 
 Earthdawn, Baldur's Gate, Shadows of Amn, Quest for Glory, and untold
 other games we've all played.

 ******************************************************************/

/** System Include Files **/
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/** Custom Header Files **/
#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "tables.h"
#include "recycle.h"

/** External Functions **/
bool    remove_obj      	( Character *ch, int iWear, bool fReplace );
void    wear_obj        	( Character *ch, Object *obj, bool fReplace  );
int     find_door       	( Character *ch, char *argument  );
int 	spell_lookup		( const char *name, bool fDivine  );
int 	skill_lookup		( const char *name  );
extern	char *target_name;


/** Generic Arcane Spells available to all Arcane Casters **/

bool spell_detect_magic( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( IS_AFFECTED(victim, AFF_DETECT_MAGIC) )
    {   
        if (victim == ch)
          send_to_char("You can already sense magical auras.\n\r",ch);  
        else
          act("$N can already detect magic.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(60);
    af.modifier  = 0;
    af.location  = 0;
    af.bitvector = AFF_DETECT_MAGIC;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "Your vision is tinted with a blue aura.\n\r", victim );
    act("$n's eyes glow blue, and then dim.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_lesser_shielding( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(30);
    af.location  = APPLY_AC;
    af.modifier  = 15;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("A transluscent shell flickers into existance around you.",victim,NULL,NULL,TO_CHAR);
    act("A transluscent shell flickers into existance around $n.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_erase( int sn, int level, Character *ch, void *vo,int target )
{
    Object *book = (Object *) vo;
    int i;

    if ( book->item_type != ITEM_SPELLBOOK )
    {
	cprintf(ch,"You failed.\n\r");
	return TRUE;
    }

    for( i=0 ; i<10 ; i++ )
	book->value[i] = 0;

    act("$p has been erased of all spells.",ch,book,NULL,TO_CHAR);
    return TRUE;
}

/*
 * Sets the HOLD_PORTAL flag on a door, which acts as a lock.  It can be
 * picked by a good thief, or blown away by the 'knock' spell.
 */
bool spell_hold_portal( int sn, int level, Character *ch, void *vo, int target)
{
    int door;

    if ( ( door = find_door( ch, target_name ) ) >= 0 )
    {
        /* 'lock door' */
        Room *to_room;
        Exit *pexit;
        Exit *pexit_rev;

        pexit   = ch->in_room->exit[door];
        if ( !IS_SET(pexit->exit_info, EX_CLOSED) )
            { send_to_char( "It's not closed.\n\r",        ch ); return TRUE; }

        SET_BIT(pexit->exit_info, EX_HOLD_PORTAL);
        send_to_char( "*Click*\n\r", ch );
        act( "The $d is magically sealed.", ch, NULL, pexit->keyword, TO_ROOM);
        act( "The $d is magically sealed.", ch, NULL, pexit->keyword, TO_CHAR);

        /* lock the other side */
        if ( ( to_room   = pexit->u1.to_room            ) != NULL
        &&   ( pexit_rev = to_room->exit[rev_dir[door]] ) != 0
        &&   pexit_rev->u1.to_room == ch->in_room )
        {
            SET_BIT( pexit_rev->exit_info, EX_HOLD_PORTAL );
        }
    }
	return TRUE;
}

bool enchant_metal( Character *ch, Object *bar, int old_vnum, int new_vnum );

bool spell_enchant_brass( int sn, int level, Character *ch, void *vo, int target )
{
	Object *obj = (Object *) vo;

	return enchant_metal( ch, obj, 728, 700 );
}

bool spell_enchant_copper( int sn, int level, Character *ch, void *vo, int target )
{
    Object *obj = (Object *) vo;

    return enchant_metal( ch, obj, 729, 701 );
}

bool spell_enchant_silver( int sn, int level, Character *ch, void *vo, int target )
{
    Object *obj = (Object *) vo;

    return enchant_metal( ch, obj, 730, 702 );
}

bool spell_enchant_gold( int sn, int level, Character *ch, void *vo, int target )
{
    Object *obj = (Object *) vo;

    return enchant_metal( ch, obj, 731, 703 );
}

bool spell_enchant_electrum( int sn, int level, Character *ch, void *vo, int target )
{
    Object *obj = (Object *) vo;

    return enchant_metal( ch, obj, 732, 704 );
}

bool spell_enchant_platinum( int sn, int level, Character *ch, void *vo, int target )
{
    Object *obj = (Object *) vo;

    return enchant_metal( ch, obj, 733, 705 );
}

bool spell_enchant_alatinum( int sn, int level, Character *ch, void *vo, int target )
{
    Object *obj = (Object *) vo;

    return enchant_metal( ch, obj, 734, 706 );
}

bool spell_enchant_mithril( int sn, int level, Character *ch, void *vo, int target )
{
    Object *obj = (Object *) vo;

    return enchant_metal( ch, obj, 708, 707 );
}

bool enchant_metal( Character *ch, Object *bar, int old_vnum, int new_vnum )
{
	Object *new;

	if ( bar->pIndexData->vnum != old_vnum )
	{
		cprintf(ch,"That item cannot be enchanted with this spell.\n\r");
		return FALSE;
	}

	if ( (new = create_object(get_obj_index(new_vnum))) == NULL )
	{
		cprintf(ch,"Something is amiss is the world of magic.\n\r");
		return FALSE;
	}

	act("$n enchants $p.",ch,bar,NULL,TO_ROOM);
	act("You enchant $p.",ch,bar,NULL,TO_CHAR);
	new->cost = bar->cost;
	extract_obj( bar );
	obj_to_char( new, ch );
	return FALSE;
}

/* Generic arcane spells
    * shield of elsavier :: abjuration, level 12, 5% absorb
    * shield of rivetier :: abjuration, level 24, 10% absorb
    * shield of zakitier :: abjuration, level 36, 15% absorb
*/
bool spell_shield_of_elsavier( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(18);
    af.location     = APPLY_ABSORB;
    af.modifier     = 5;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );

    cprintf(victim,"A shimmering shield of energy covers your body.\n\r");
    act("A shimmering shield of energy covers $n.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_shield_of_rivetier( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;    

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(18);
    af.location     = APPLY_ABSORB;
    af.modifier     = 10;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );

    cprintf(victim,"A shimmering shield of energy covers your body.\n\r");
    act("A shimmering shield of energy covers $n.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_shield_of_zakitier( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;    

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(18);
    af.location     = APPLY_ABSORB;
    af.modifier     = 15;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );

    cprintf(victim,"A shimmering shield of energy covers your body.\n\r");
    act("A shimmering shield of energy covers $n.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_rock_skin( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = number_range(4,6);
    af.modifier     = 0;      
    af.location     = APPLY_BLADETURN;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your skin thickens and hardens.",victim,NULL,NULL,TO_CHAR);
    act("$n's skin thickens and hardens.",victim,NULL,NULL,TO_ROOM);
    return TRUE; 
}

bool spell_sand_skin( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;     

    af.where        = TO_AFFECTS;
    af.type         = sn; 
    af.level        = level;
    af.duration     = number_range(2,4);
    af.modifier     = 0;
    af.location     = APPLY_BLADETURN;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your skin thickens and hardens.",victim,NULL,NULL,TO_CHAR);
    act("$n's skin thickens and hardens.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_steel_skin( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;     

    af.where        = TO_AFFECTS;
    af.type         = sn; 
    af.level        = level;
    af.duration     = number_range(6,8);
    af.modifier     = 0;
    af.location     = APPLY_BLADETURN;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your skin thickens and hardens.",victim,NULL,NULL,TO_CHAR);
    act("$n's skin thickens and hardens.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_diamond_skin( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;     

    af.where        = TO_AFFECTS;
    af.type         = sn; 
    af.level        = level;
    af.duration     = number_range(8,10);
    af.modifier     = 0;
    af.location     = APPLY_BLADETURN;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your skin thickens and hardens.",victim,NULL,NULL,TO_CHAR);
    act("$n's skin thickens and hardens.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_ethereal_shield( int sn, int level, Character *ch, void *vo, int target )
{
	Object *shield;
	int mult = 1;
	int i;

	if ( (shield = get_eq_char(ch,WEAR_SHIELD)) != NULL )
	{
		act("You are already equipped with a shield.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}
 
	if ( get_obj_index( VNUM_MAGE_SHIELD ) == NULL )
	{
		act("You are unable to create the shield.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

	if ( (shield = create_object( get_obj_index(VNUM_MAGE_SHIELD))) == NULL )
	{
		act("You are unable to create the shield.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

	/* Set shield */
	shield->level = level;
	if ( level < 15 )
		shield->value[5] = mapArmorSlot( gpn_buckler_shields );
	else
	if ( level < 30 )
		shield->value[5] = mapArmorSlot( gpn_small_shields );
	else
	if ( level < 45 )
	{
		shield->value[5] = mapArmorSlot( gpn_medium_shields );
		mult = 2;
	}
	else
	{
		shield->value[5] = mapArmorSlot( gpn_large_shields );
		mult = 2;
	}

	for( i=0 ; i < 4 ; i++ )
		shield->value[i] = level / 2 * mult;

	act("$p wavers into existance in front of $n.",ch,shield,NULL,TO_ROOM);
	act("$p wavers into existance in front of you.",ch,shield,NULL,TO_CHAR);
	shield->timer = level;
	obj_to_char( shield, ch );
	equip_char( ch, shield, WEAR_SHIELD );
	return TRUE;
}


bool spell_summon_container( int sn, int level, Character *ch, void *vo,int target)
{
    Object *container;
 	int skill = get_skill(ch,skill_lookup("conjuration"));

    if ( (container = create_object( get_obj_index( VNUM_BAG_OF_HOLDING ))) == NULL )
    {
        cprintf(ch,"Something is amiss in the world of magic, the container cannot be created.\n\r");
        return TRUE;
    }

	container->level = UMIN(skill,ch->level);
	container->value[4] = URANGE(1,50-skill,50);

    obj_to_char( container, ch );
    act( "You summon forth $p.", ch, container, NULL, TO_CHAR );
    act( "$n summons forth $p.", ch, container, NULL, TO_ROOM );
    return TRUE;
}

bool spell_telekinesis( int sn, int level, Character *ch, void *vo, int target )
{
    Object *obj;
    Affect af;
    bool found = FALSE;

    af.where    = 0;
    af.type     = sn;
    af.location = APPLY_WEIGHT;
    af.duration = minutes(60);
    af.flags    = AFF_SPELL|AFF_OBJ;
    af.misc     = 0;
    af.level    = level;
    af.bitvector = 0;

    for( obj = ch->in_room->contents ; obj != NULL ; obj = obj->next_content )
    {
        if ( !IS_SET(obj->wear_flags,ITEM_TAKE) )
            continue;

        af.modifier = obj->weight * -1;
        affect_to_obj( obj, &af );
        found = TRUE;
    }

    if ( !found )
    {
        act("There is nothing in this room that can be moved.\n\r",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    act("A low humming sound eminates from the nearby objects as they begin to float.\n\r",ch,NULL,NULL,TO_CHAR);
    act("A low humming sound eminates from the nearby objects as they begin to float.\n\r",ch,NULL,NULL,TO_ROOM);
    return TRUE;
}
