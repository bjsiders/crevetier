/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
****************************************************************************/

#ifndef currency_h
#define currency_h

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include "thocdef.h"
#include "thocerror.h"

// Some convenient defines
#define CUR_SILVER          0
#define CUR_GOLD            1
#define CUR_ELECTRUM        2
#define CUR_PLATINUM        3
#define CUR_ALATINUM        4
#define MAX_CURRENCY        5

// Currency type
struct currency_tag
{
    char *          name;
    char            color;
    unsigned long   silver_value;
    int             num_per_pound;
};

// Currency table
extern const struct currency_tag    currency_table[];

// Header files
char *web_money_breakdown      ( int amount );
char *web_money_breakdown_r    ( int amount, char *buf, size_t size );
char *money_breakdown          ( int amount );
char *money_breakdown_r        ( int amount, char *buf, size_t size );
int   get_coin_weight          ( int coin_type, int coin_amount );

#endif /* currency_h */
