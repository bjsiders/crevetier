#ifndef network_h
#define network_h

/*
    One socket connection
*/
struct    descriptor_data
{
    Descriptor *        next;
    Descriptor *        snoop_by;
    Character *         character;
    Character *         original;
    bool                valid;
    char *              host;
    sh_int              descriptor;
    sh_int              connected;
    bool                fcommand;
    char                inbuf[4 * MAX_INPUT_LENGTH];
    char                incomm[MAX_INPUT_LENGTH];
    char                inlast[MAX_INPUT_LENGTH];
    int                 repeat;
    char *              outbuf;
    int                 outsize;
    int                 outtop;
    char *              showstr_head;
    char *              showstr_point;
    void *              pEdit;        /* OLC */
    char **             pString;    /* OLC */
    int                 editor;        /* OLC */
    bool                color;
    time_t              state;
    bool                mxp;   /* player using MXP flag */
};

/*
 * Connected state for a channel.
 */
#define CON_PLAYING                  0
#define CON_GET_NAME                 1
#define CON_GET_OLD_PASSWORD         2
#define CON_CONFIRM_NEW_NAME         3
#define CON_GET_NEW_PASSWORD         4
#define CON_CONFIRM_NEW_PASSWORD     5
#define CON_GET_NEW_RACE             6
#define CON_GET_NEW_SEX              7
#define CON_GET_NEW_CLASS            8
#define CON_GET_ALIGNMENT            9
#define CON_DEFAULT_CHOICE           10
#define CON_GEN_GROUPS               11
#define CON_PICK_WEAPON              12
#define CON_READ_IMOTD               13
#define CON_READ_MOTD                14
#define CON_BREAK_CONNECT            15
#define CON_GET_PATH                 17
#define CON_RIGHT_WAY                18
#define CON_COLOR_ON                 19
#define CON_IMPROVE_STATS            20
#define CON_IMPROVE_HOWMUCH          21
#define CON_LOGIN_MENU               22
#define CON_GET_NEW_NAME             23
#define CON_PICK_SUBRACE             24
#define CON_GUI_CHECK                25
#define CON_PUT_CHAR_IN_WORLD        26
#define CON_POLL                     27
#define CON_POLL_SPECIFY             28
#define CON_NAME_IS_DICTIONARY       29
#define CON_NAME_IS_COPYRIGHTED      30
#define CON_NAME_IS_GOOFY            31
#define CON_LAST_CHANCE              32
#define CON_REFRESH                  33
#define CON_COLOR                    34
#define CON_GET_REWARD               35
#define CON_CREATION                 36

#define MAIN_SCREEN                 0

// Name selection
#define PROMPT                      1

#define REVIEW_NAMING_POLICY        2
#define REVIEW_NP_DICTIONARY        3
#define REVIEW_NP_COPYRIGHTED       4
#define REVIEW_NP_ANACHRONISM       5
#define REVIEW_NP_LAST_CHANCE       6
#define VERIFY_PASSWORD             7

extern const char *con_state[29];

#endif /* network_h */
