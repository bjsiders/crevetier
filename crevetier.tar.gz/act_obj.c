/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#if defined(macintosh)
#include <types.h>
#include <time.h>
#else
#include <sys/types.h>
#include <sys/time.h>
#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "thoc.h"
#include "olc.h"
#include "interp.h"
#include "tables.h"
#include "bank.h"
#include "options.h"

/*
 * Local functions.
 */
#define CD Character
#define OD Object
bool	remove_obj	 (Character *ch, int iWear, bool fReplace );
void	wear_obj	 (Character *ch, Object *obj, bool fReplace );
CD *	find_keeper	 (Character *ch );
void 	obj_to_keeper	 (Object *obj, Character *ch );
OD *	get_obj_keeper	 (Character *ch,Character *keeper,char *argument);
void 	checkImproveTradeSkill( Character *ch, int skill, double chance, bool fSuccess );
bool 	check_container(Character* ch, Object* container);
void 	sell_obj(Character* ch, Object* obj, Character* keeper);

#undef OD
#undef	CD

/* RT part of the corpse looting code */
bool can_loot(Character *ch, Object *obj)
{
    Character *owner, *wch;
    extern bool loot_enabled;

    if (IS_IMMORTAL(ch))
		return TRUE;

	/* Corpse value[7] is TRUE for non clan corpses -
	 temp disable during gamma */

    if ( loot_enabled && (!obj->value[7] || obj->owner == NULL) )
		return TRUE;

	if ( obj->owner == NULL )
		return TRUE;

    owner = NULL;
    for ( wch = char_list; wch != NULL ; wch = wch->next )
        if (!str_cmp(wch->name,obj->owner))
            owner = wch;

    if (owner == NULL)
		return TRUE;

    if (!str_cmp(ch->name,owner->name))
		return TRUE;

    if (!IS_NPC(owner) && HAS_OPT(owner, OPT_CANLOOT))
		return TRUE;

    if (is_same_group(ch,owner))
		return TRUE;

	if ( !IS_NPC(owner) && owner->pcdata->consent != NULL &&
		 !str_cmp( owner->pcdata->consent, ch->name) )
		return TRUE;

    return FALSE;
}


void get_obj( Character *ch, Object *obj, Object *container )
{
    /* variables for AUTOSPLIT */
    Character *gch;
    int members;
    char buffer[100];

    if ( !CAN_WEAR(obj, ITEM_TAKE) )
    {
		send_to_char( "You can't take that.\n\r", ch );
		return;
    }

    if ( has_obj(ch,obj,ch->carrying) && has_unique(obj) && !IS_IMMORTAL(ch) )
    {
        act("You already have $p.",ch,obj,NULL,TO_CHAR);
		return;
    }

    if ( ch->carry_number + get_obj_number( obj ) > can_carry_n( ch ) )
    {
		act( "$d: you can't carry that many items.", ch, NULL, obj->name, TO_CHAR );
		return;
    }

    if ((!obj->in_obj || obj->in_obj->carried_by != ch)
    		&&  (get_carry_weight(ch) + get_obj_weight(obj) > can_carry_w(ch)))
    {
		act( "$d: you can't carry that much weight.", ch, NULL, obj->name, TO_CHAR );
		return;
    }

    if (!can_loot(ch,obj))
    {
		act("Corpse looting is not permitted.",ch,NULL,NULL,TO_CHAR );
		return;
    }

    if (obj->in_room != NULL)
    {
		for (gch = obj->in_room->people; gch != NULL; gch = gch->next_in_room)
	    	if (gch->on == obj)
	    	{
				act("$N appears to be using $p.", ch,obj,gch,TO_CHAR);
				return;
	    	}
    }

    if ( container != NULL )
    {
    	if (container->pIndexData->vnum == OBJ_VNUM_PIT
			&&  !CAN_WEAR(container, ITEM_TAKE)
			&&  !IS_OBJ_STAT(obj,ITEM_HAD_TIMER))
		{
	    	obj->timer = 0;	
		}

		act( "You get $p from $P.", ch, obj, container, TO_CHAR );
		act( "$n gets $p from $P.", ch, obj, container, TO_ROOM );
		REMOVE_BIT(obj->extra_flags,ITEM_HAD_TIMER);
		obj_from_obj( obj );
    }
    else
    {
		act( "You get $p.", ch, obj, container, TO_CHAR );
		act( "$n gets $p.", ch, obj, container, TO_ROOM );
		obj_from_room( obj );
    }

    if ( obj->item_type == ITEM_MONEY)
    {
		int cur;

		for( cur = 0; cur < MAX_CURRENCY ; cur ++ )
			ch->coins[cur] += obj->value[cur];

        if (HAS_AUTOOPT(ch, AUTO_SPLIT))
        { 
			members = 0;
    	  	for (gch = ch->in_room->people; gch != NULL; gch = gch->next_in_room )
    	  	{
            	if (!IS_AFFECTED(gch,AFF_CHARM) && is_same_group( gch, ch ) )
              		members++;
    	  	}

			if ( members > 1 )
	  		{
				int i;

				for( i=0; i < MAX_CURRENCY ; i++ )
				{
					if( obj->value[i] >= members )
					{
	    				sprintf(buffer,"%d %s",obj->value[i],currency_table[i].name);
	    				do_function(ch, &do_split, buffer);	
					}
				}
       		}
		} /* Autosplit */
 
		extract_obj( obj );
    }
    else
    {
		obj_to_char( obj, ch );
    }

    check_encumbrance( ch );
    return;
}


void do_get( Character *ch, char *argument )
{
    char arg1[MAX_INPUT_LENGTH];
    char arg2[MAX_INPUT_LENGTH];
    char arg3[MAX_INPUT_LENGTH];
    Object *obj;
    Object *obj_next;
    Object *container;
    bool found;
	int amount = -1, c = -1;

	if ( is_affected(ch,gsn_shapeshifting,AFF_SKILL) )
	{
		cprintf(ch,"You cannot pick anything up while shapeshifting.\n\r");
		return;
	}

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );

	/* if trying to get coins */
	if ( is_number(arg1) || (!str_cmp(arg1,"all") && !str_cmp(arg2,"coins")) )
	{
		argument = one_argument(argument,arg3);
		if(!str_cmp(arg3,"from"))
			argument = one_argument(argument,arg3);

		if(!str_cmp(arg3,"bank"))
		{
			/* put coins in the bank */
			amount = atoi(arg1);
			c = currency_lookup(arg2);

			if ( !str_cmp(arg1,"all") && !str_cmp(arg2,"coins") )
				get_bank(ch,amount,c,NULL,TRUE);
			else
				get_bank(ch,amount,c,NULL,FALSE);

			return;
		}
	}
    
    if (!str_cmp(arg2,"from"))
		argument = one_argument(argument,arg2);

    /* Get type. */
    if ( arg1[0] == '\0' )
    {
		send_to_char( "Get what?\n\r", ch );
		return;
    }

    if ( arg2[0] == '\0' )
	{
		if ( str_cmp( arg1, "all" ) && str_prefix( "all.", arg1 ) )
		{

	    	obj = get_obj_list( ch, arg1, ch->in_room->contents );
	    	if ( obj == NULL )
	    	{
				act( "I see no $T here.", ch, NULL, arg1, TO_CHAR );
				return;
	    	}

			get_obj( ch, obj, NULL );
		}
		else
		{
	    	/* 'get all' or 'get all.obj' */
	    	found = FALSE;
	    	for ( obj = ch->in_room->contents; obj != NULL; obj = obj_next )
	    	{
				obj_next = obj->next_content;
				if ( ( arg1[3] == '\0' || is_name( &arg1[4], obj->name ) )
				&&   can_see_obj( ch, obj ) )
				{
		    		found = TRUE;
		    		get_obj( ch, obj, NULL );
				}
	    	}

	    	if ( !found ) 
	    	{
				if ( arg1[3] == '\0' )
		    		send_to_char( "I see nothing here.\n\r", ch );
				else
		    		act( "I see no $T here.", ch, NULL, &arg1[4], TO_CHAR );
	    	}
		}
    }
    else
    {
		if ( !str_cmp( arg2, "bank" ) )
		{
			Character *banker;
			/* we look for a banker in case some moron named a container "bank" */
			for( banker = ch->in_room->people; banker != NULL; banker = banker->next_in_room)
			{
				if ( IS_NPC(banker) && IS_SET(banker->act, ACT_BANKER) )
				{
					get_bank(ch,amount,c,arg1,FALSE);
					return;
				}
			}
		}

		/* 'get ... container' */
		if ( !str_cmp( arg2, "all" ) || !str_prefix( "all.", arg2 ) )
		{
	    	send_to_char( "You can't do that.\n\r", ch );
	    	return;
		}
	
		if ( ( container = get_obj_here( ch, arg2 ) ) == NULL )
		{
	    	act( "I see no $T here.", ch, NULL, arg2, TO_CHAR );
	    	return;
		}
	
		switch ( container->item_type )
		{
		default:
	    	send_to_char( "That's not a container.\n\r", ch );
	    	return;
	
		case ITEM_MOBILE:
		case ITEM_CONTAINER:
		case ITEM_CORPSE_NPC:
		case ITEM_FORGE:
	    	break;

		case ITEM_CORPSE_PC:
				if (!can_loot(ch,container))
				{
		    		send_to_char( "You can't do that.\n\r", ch );
		    		return;
				}
		}

		if ( container->item_type == ITEM_FORGE )
		{
			Character *vch;

        	for ( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
            	if ( vch != ch && vch->crafting == container )
            	{
                	cprintf(ch,"Somebody else is using that.\n\r");
                	return;
            	}
		}

		if ( IS_SET(container->value[1], CONT_CLOSED) && container->item_type != ITEM_FORGE )
		{
	    	act( "The $d is closed.", ch, NULL, container->name, TO_CHAR );
	    	return;
		}

		if ( str_cmp( arg1, "all" ) && str_prefix( "all.", arg1 ) )
		{
	    	/* 'get obj container' */
	    	obj = get_obj_list( ch, arg1, container->contains );
	    	if ( obj == NULL )
	    	{
				act( "I see nothing like that in the $T.", ch, NULL, arg2, TO_CHAR );
				return;
	    	}
			get_obj( ch, obj, container );
		}
		else
		{
	    	/* 'get all container' or 'get all.obj container' */
	    	found = FALSE;
	    	for ( obj = container->contains; obj != NULL; obj = obj_next )
	    	{
				obj_next = obj->next_content;
				if ( ( arg1[3] == '\0' || is_name( &arg1[4], obj->name ) )
					&&   can_see_obj( ch, obj ) )
				{
		    		found = TRUE;
		    		if (container->pIndexData->vnum == OBJ_VNUM_PIT
		    			&&  !IS_IMMORTAL(ch))
		    		{
						send_to_char("Don't be so greedy!\n\r",ch);
						return;
		    		}
		    		get_obj( ch, obj, container );
				}
	    	}

	    	if ( !found )
	    	{
				if ( arg1[3] == '\0' )
		    		act( "I see nothing in the $T.", ch, NULL, arg2, TO_CHAR );
				else
		    		act( "I see nothing like that in the $T.", ch, NULL, arg2, TO_CHAR );
	    	}
		}
    }

    check_encumbrance( ch );
    return;
}


void do_stockpile( Character *ch, char *argument )
{
    char arg1[MAX_INPUT_LENGTH];
    char arg2[MAX_INPUT_LENGTH];
	Building *bld;
    Object *obj;
    Object *obj_next;

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );

    if (!str_cmp(arg2,"in") || !str_cmp(arg2,"on"))
	argument = one_argument(argument,arg2);

    if ( arg1[0] == '\0' || arg2[0] == '\0' )
    {
		send_to_char( "Stockpile what in which building?\n\r", ch );
		return;
    }

    if ( ( bld = get_building_room( ch, arg2 ) ) == NULL )
    {
		act( "There's no $T building here.", ch, NULL, arg2, TO_CHAR );
		return;
    }

    if ( bld->curr_structure >= bld->max_structure )
    {
		cprintf(ch,"That building isn't under construction or rennovation, nor is it damaged.\n\r");
		return;
    }

    if ( str_cmp( arg1, "all" ) && str_prefix( "all.", arg1 ) )
    {
		/* 'put obj container' */
		if ( ( obj = get_obj_carry( ch, arg1, ch ) ) == NULL )
		{
	    	send_to_char( "You do not have that item.\n\r", ch );
	    	return;
		}

		switch( bld->material )
		{
			case BUILDMAT_WOOD:
				if ( obj->pIndexData->vnum != NR_FOREST )
				{
					cprintf(ch,"You can only stockpile harvested wood here.\n\r");
					return;
				}
				break;
			case BUILDMAT_STONE:
                if ( obj->pIndexData->vnum != NR_STONE )
                {
                    cprintf(ch,"You can only stockpile stone blocks here.\n\r");
                    return;
                }
                break;
			default:
				cprintf(ch,"This building is bugged!  Report it to an IMM.\n\r");
				return;
		}

		if ( !can_drop_obj( ch, obj ) )
		{
	    	send_to_char( "You can't let go of it.\n\r", ch );
	    	return;
		}

		obj_from_char( obj );
		extract_obj( obj );
		bld->available_resources++;

	   	act("$n stockpiles $p in the construction site.",ch,obj,NULL,TO_ROOM);
	   	act("You stockpile $p in the construction site.",ch,obj,NULL,TO_CHAR);
    }
    else
    {
		int count=0;
		int vnum;

        switch( bld->material )
        {
            case BUILDMAT_WOOD:
                vnum = NR_FOREST; break;
            case BUILDMAT_STONE:
				vnum = NR_STONE; break;
            default:
                cprintf(ch,"This building is bugged!  Report it to an IMM.\n\r");
                return;
        }

		/* 'put all container' or 'put all.obj container' */
		for ( obj = ch->carrying; obj != NULL; obj = obj_next )
		{
	    	obj_next = obj->next_content;
	
	    	if ( ( arg1[3] == '\0' || is_name( &arg1[4], obj->name ) )
			&&	 obj->pIndexData->vnum == vnum 
	    	&&   can_see_obj( ch, obj )
	    	&&   obj->wear_loc == WEAR_NONE
	    	&&   can_drop_obj( ch, obj ) )
	    	{
			
				obj_from_char( obj );
				extract_obj( obj );
				bld->available_resources++;
				++count;
				actprintf(ch,obj,NULL,TO_CHAR,"You stockpile $p in the construction site.");
				actprintf(ch,obj,NULL,TO_ROOM,"$n stockpiles $p in the construction site.");
			}
	    }

		if ( count < 1 )
			act("You aren't carrying any of the right resources.\n\r",ch,NULL,NULL,TO_CHAR);
	}

    check_encumbrance( ch );
    return;
}

void do_put( Character *ch, char *argument )
{
    char arg1[MAX_INPUT_LENGTH];
    char arg2[MAX_INPUT_LENGTH];
    char arg3[MAX_INPUT_LENGTH];
    Object *container;
    Object *obj;
    Object *obj_next;
	Character *banker;
	int amount = -1, c = -1;

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );

	/* if trying to put coins */
	if ( is_number(arg1) || (!str_cmp(arg1,"all") && !str_cmp(arg2,"coins")) )
	{
		argument = one_argument(argument,arg3);
		if(!str_cmp(arg3,"in") || !str_cmp(arg3,"on"))
			argument = one_argument(argument,arg3);

		if(str_cmp(arg3,"bank"))
		{
			cprintf(ch,"You can only put coins in a bank.\n\r");
			return;
		}

		/* put coins in the bank */
		amount = atoi(arg1);
		c = currency_lookup(arg2);
		if ( !str_cmp(arg1,"all") && !str_cmp(arg2,"coins") )
			put_bank(ch,amount,c,NULL,TRUE);
		else
			put_bank(ch,amount,c,NULL,FALSE);
		return;
	}
    
	if (!str_cmp(arg2,"in") || !str_cmp(arg2,"on"))
		argument = one_argument(argument,arg2);

    if ( arg1[0] == '\0' || arg2[0] == '\0' )
    {
		send_to_char( "Put what in what?\n\r", ch );
		return;
    }

    if ( !str_cmp( arg2, "all" ) || !str_prefix( "all.", arg2 ) )
    {
		send_to_char( "You can't do that.\n\r", ch );
		return;
    }

	if ( !str_cmp( arg2, "bank" ) )
	{
		/* we look for a banker in case some moron named a container "bank" */
		for( banker = ch->in_room->people; banker != NULL; banker = banker->next_in_room)
		{
			if ( IS_NPC(banker) && IS_SET(banker->act, ACT_BANKER) )
			{
				put_bank(ch,amount,c,arg1,FALSE);
				return;
			}
		}
	}

    if ( ( container = get_obj_here( ch, arg2 ) ) == NULL )
    {
		act( "I see no $T here.", ch, NULL, arg2, TO_CHAR );
		return;
    }

	switch( container->item_type )
	{
		case ITEM_CONTAINER:
		case ITEM_FORGE:
		case ITEM_MOBILE:
			break;
		default:
			send_to_char( "That's not a container.\n\r", ch );
			return;
    }

	if ( container->item_type == ITEM_FORGE )
	{
		Character *vch;

        for ( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
		{
            if ( vch != ch && vch->crafting == container )
            {
                cprintf(ch,"Somebody else is using that.\n\r");
                return;
            }
		}
	}

    if ( IS_SET(container->value[1], CONT_CLOSED) && container->item_type != ITEM_FORGE )
    {
		act( "The $d is closed.", ch, NULL, container->name, TO_CHAR );
		return;
    }

    if ( str_cmp( arg1, "all" ) && str_prefix( "all.", arg1 ) )
    {
		/* 'put obj container' */
		if ( ( obj = get_obj_carry( ch, arg1, ch ) ) == NULL )
		{
	    	send_to_char( "You do not have that item.\n\r", ch );
	    	return;
		}

		if ( obj == container )
		{
	    	send_to_char( "You can't fold it into itself.\n\r", ch );
	    	return;
		}

		if ( !can_drop_obj( ch, obj ) )
		{
	    	send_to_char( "You can't let go of it.\n\r", ch );
	    	return;
		}

    	if (WEIGHT_MULT(obj) != 100)
    	{
			send_to_char("The nature of magic forbids such a thing.\n\r",ch);
            return;
        }

		if ( container->item_type != ITEM_FORGE && (get_obj_weight( obj ) + get_true_weight( container ) > (container->value[0] * 10)) )
		{
			actprintf(ch,obj,container,TO_CHAR,"$P is too heavily burdened for $p.");
			return;
		}

		if ( container->item_type != ITEM_FORGE && get_obj_weight(obj) > (container->value[3] * 10) )
		{
			actprintf(ch,obj,container,TO_CHAR,"$p is too heavy for $P.");
	    	return;
		}
	
		if (container->pIndexData->vnum == OBJ_VNUM_PIT 
		&&  !CAN_WEAR(container,ITEM_TAKE))
		{
	    	if (obj->timer)
				SET_BIT(obj->extra_flags,ITEM_HAD_TIMER);
	    	else
	        	obj->timer = number_range(100,200);
		}

		if ( container->item_type == ITEM_CONTAINER && 
         IS_SET(container->value[1],CONT_QUIVER) &&
		 obj->item_type != ITEM_PROJECTILE )
		{
			act("$p is a quiver, and $P is not a projectile.",ch,container,obj,TO_CHAR);
			return;
		}
	
		obj_from_char( obj );
		obj_to_obj( obj, container );

		if (IS_SET(container->value[1],CONT_PUT_ON))
		{
	    	act("$n puts $p on $P.",ch,obj,container, TO_ROOM);
	    	act("You put $p on $P.",ch,obj,container, TO_CHAR);
		}
		else
		{
	    	act( "$n puts $p in $P.", ch, obj, container, TO_ROOM );
	    	act( "You put $p in $P.", ch, obj, container, TO_CHAR );
		}
    }
    else
    {
		/* 'put all container' or 'put all.obj container' */
		bool found = FALSE;
		for ( obj = ch->carrying; obj != NULL; obj = obj_next )
		{
	    	obj_next = obj->next_content;

		    if ( ( arg1[3] == '\0' || is_name( &arg1[4], obj->name ) )
	    	&&   can_see_obj( ch, obj )
	    	&&   WEIGHT_MULT(obj) == 100
	    	&&   obj->wear_loc == WEAR_NONE
	    	&&   obj != container
	    	&&   can_drop_obj( ch, obj ))
	    	{
				found = TRUE;

                if ( container->item_type != ITEM_FORGE && 
                    get_obj_weight(obj) > (container->value[3] * 10) )
                {
                    actprintf(ch,obj,container,TO_CHAR,"$p is too heavy for $P.");
                    continue;
                }

                if ( container->item_type != ITEM_FORGE && (get_obj_weight( obj ) + 
                    get_true_weight( container ) > (container->value[0] * 10)) )
                {
                    actprintf(ch,obj,container,TO_CHAR,"$P is too heavily burdened for $p.");
                    break;
                }

	    		if (container->pIndexData->vnum == OBJ_VNUM_PIT
	    		&&  !CAN_WEAR(obj, ITEM_TAKE) )
	 			{
	    	    	if (obj->timer)
						SET_BIT(obj->extra_flags,ITEM_HAD_TIMER);
	    	    	else
	    	    		obj->timer = number_range(100,200);
				}

				obj_from_char( obj );
				obj_to_obj( obj, container );

 		       	if (IS_SET(container->value[1],CONT_PUT_ON))
        		{
            	    act("$n puts $p on $P.",ch,obj,container, TO_ROOM);
            	    act("You put $p on $P.",ch,obj,container, TO_CHAR);
        		}
				else
				{
			    	act( "$n puts $p in $P.", ch, obj, container, TO_ROOM );
			    	act( "You put $p in $P.", ch, obj, container, TO_CHAR );
				}
	    	}
		}

		if(!found)
			cprintf(ch, "You do not have any items matching that name.\n\r");
    }

    check_encumbrance( ch );
    return;
}



void do_drop( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Object *obj;
    Object *obj_next;
    bool found;
	long	coins[MAX_CURRENCY];

	/*char argcopy[MAX_STRING_LENGTH];
    char obj_name[MAX_INPUT_LENGTH];
	Object *container = NULL;
	Character *npc = NULL;
	int currency, quantity;
	bool all_items = FALSE;
	strcpy(argcopy, argument);
	quantity = mult_argument2(argcopy,ch,obj_name,&container,&npc,&currency,&all_items);

	log_string("quantity = %d, obj_name = %s",quantity,obj_name);
	log_string("container = %s, npc = %s, currency = %d, all_items = %s",
		container ? container->short_descr : "None",
		npc ? npc->short_descr : "None",
		currency, all_items ? "yes" : "no" );*/

	memset(coins,0,sizeof(coins));
    argument = one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Drop what?\n\r", ch );
	return;
    }

    if ( is_number( arg ) ) /* trying to drop coins */
    {
		int cur;
		int amount;

		amount   = atoi(arg);
		argument = one_argument( argument, arg );
		if ( (cur = currency_lookup(arg)) < 0 || amount <= 0 )
		{
			cprintf(ch,"To drop coins use: drop <amount> <coin type>\n\r");
			return;
		}

		if ( ch->coins[cur] < amount )
		{
			cprintf(ch,"You don't have that much %s.\n\r", currency_table[cur].name );
			return;
		}	

		ch->coins[cur] -= amount;
		coins[cur] += amount;

		for ( obj = ch->in_room->contents; obj != NULL; obj = obj_next )
		{
	    	obj_next = obj->next_content;

	    	if ( obj->pIndexData->vnum ==  OBJ_VNUM_COINS )
			{
				int i;

				for( i = 0 ; i < MAX_CURRENCY ; i++ )
					coins[i] += obj->value[i];
					
				extract_obj(obj);
				break;
			}
	    }

		obj_to_room( create_money( coins ), ch->in_room );
		act( "$n drops some coins.", ch, NULL, NULL, TO_ROOM );
		cprintf(ch,"You drop %d %s.\n\r", amount, currency_table[cur].name);
		check_encumbrance( ch );
		return;
    }

    if ( str_cmp( arg, "all" ) && str_prefix( "all.", arg ) )
    {
	/* 'drop obj' */
	if ( ( obj = get_obj_carry( ch, arg, ch ) ) == NULL )
	{
	    send_to_char( "You do not have that item.\n\r", ch );
	    return;
	}

	if ( !can_drop_obj( ch, obj ) )
	{
	    send_to_char( "You can't let go of it.\n\r", ch );
	    return;
	}

    drop_obj( ch, obj );

    /* moved into drop_obj

	obj_from_char( obj );
	obj_to_room( obj, ch->in_room );
	act( "$n drops $p.", ch, obj, NULL, TO_ROOM );
	act( "You drop $p.", ch, obj, NULL, TO_CHAR );
	if (IS_OBJ_STAT(obj,ITEM_MELT_DROP))
	{
	    act("$p dissolves into smoke.",ch,obj,NULL,TO_ROOM);
	    act("$p dissolves into smoke.",ch,obj,NULL,TO_CHAR);
	    extract_obj(obj);
	}
    */
    }
    else
    {
	/* 'drop all' or 'drop all.obj' */
	found = FALSE;
	for ( obj = ch->carrying; obj != NULL; obj = obj_next )
	{
	    obj_next = obj->next_content;

	    if ( ( arg[3] == '\0' || is_name( &arg[4], obj->name ) )
	    &&   can_see_obj( ch, obj )
	    &&   obj->wear_loc == WEAR_NONE
	    &&   can_drop_obj( ch, obj ) )
	    {
		found = TRUE;
        drop_obj( ch, obj );

        /*
		obj_from_char( obj );
		obj_to_room( obj, ch->in_room );
		act( "$n drops $p.", ch, obj, NULL, TO_ROOM );
		act( "You drop $p.", ch, obj, NULL, TO_CHAR );
        	if (IS_OBJ_STAT(obj,ITEM_MELT_DROP))
        	{
             	    act("$p dissolves into smoke.",ch,obj,NULL,TO_ROOM);
            	    act("$p dissolves into smoke.",ch,obj,NULL,TO_CHAR);
            	    extract_obj(obj);
        	}
        */
	    }
	}

	if ( !found )
	{
	    if ( arg[3] == '\0' )
		act( "You are not carrying anything.",
		    ch, NULL, arg, TO_CHAR );
	    else
		act( "You are not carrying any $T.",
		    ch, NULL, &arg[4], TO_CHAR );
	}
    }

    check_encumbrance( ch );
    return;
}



void do_give( Character *ch, char *argument )
{
    char arg1 [MAX_INPUT_LENGTH];
    char arg2 [MAX_INPUT_LENGTH];
	char arg3 [MAX_INPUT_LENGTH];
    char buf[MAX_STRING_LENGTH];
    Character *victim;
    Object  *obj;
	int amount = -1;
	int c = 0;

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );
	argument = one_argument( argument, arg3 );

    if ( arg1[0] == '\0' || arg2[0] == '\0' || (is_number(arg1) && arg3[0] == '\0') )
    {
		send_to_char( "Syntax:  give <object> <player>\n\r", ch );
		send_to_char( "To give coins: give <#> <type> <player>\n\r", ch );
		return;
    }

	if ( is_number( arg1 ) )
	{
		amount = atoi(arg1);
		if 	( amount <= 0 || (c=currency_lookup(arg2)) < 0 )
		{
			cprintf(ch,"To give coins, use: give <#> <type> <player>\n\r");
	    	return;
		}
		
		victim = get_char_room( ch, arg3 );
	}
	else
	{
		victim = get_char_room( ch, arg2 );
	}

	if ( victim == NULL )
	{
    	send_to_char( "They aren't here.\n\r", ch );
    	return;
	}

	if ( is_affected(victim,gsn_shapeshifting,AFF_SKILL) )
	{
		act("$N is shapeshifted and cannot accept items.",ch,NULL,victim,TO_CHAR);
		return;
	}	
	
	if ( HAS_OPT(victim, OPT_NOGIVE) )
	{
		act("$N does not want your shiny bauble.",ch,NULL,victim,TO_CHAR);
		return;
	}

	if ( IS_NPC(victim) && IS_SET(victim->act, ACT_BANKER) )
	{
		cprintf(ch, "To deposit %s into the bank use the \"put\" command.\n\r",
			is_number(arg1) ? "coins" : "an item" );
		return;
	}

	/* If its a number we are talking about coins */
    if ( is_number( arg1 ) )
    {
		if( ch->coins[c] < amount )
		{
			cprintf(ch,"You don't have that much %s.\n\r", currency_table[c].name);
			return;
		}

    	if (get_carry_weight(victim) + get_coin_weight(c,amount) > can_carry_w( victim ) )
    	{
			act( "$N can't carry that much weight.", ch, NULL, victim, TO_CHAR );
			return;
    	}

		ch->coins[c] -= amount;
		victim->coins[c] += amount;

		sprintf(buf,"$n gives you %d %s.",amount, currency_table[c].name );
		act( buf, ch, NULL, victim, TO_VICT    );
		act( "$n gives $N some coins.",  ch, NULL, victim, TO_NOTVICT );
		sprintf(buf,"You give $N %d %s.",amount, currency_table[c].name );
		act( buf, ch, NULL, victim, TO_CHAR    );

		check_encumbrance( ch );
		return;
    }

    if ( ( obj = get_obj_carry( ch, arg1, ch ) ) == NULL )
    {
	send_to_char( "You do not have that item.\n\r", ch );
	return;
    }

    if ( obj->wear_loc != WEAR_NONE )
    {
	send_to_char( "You must remove it first.\n\r", ch );
	return;
    }

    if (IS_NPC(victim) && victim->pIndexData->pShop != NULL)
    {
	act("$N tells you 'Sorry, you'll have to sell that.'",
	    ch,NULL,victim,TO_CHAR);
	return;
    }

    if ( has_obj(victim,obj,victim->carrying) && has_unique(obj) && !IS_IMMORTAL(victim) )
    {
	act("$N already has one.",ch,NULL,victim,TO_CHAR);
	return;
    }

    if ( !can_drop_obj( ch, obj ) )
    {
	send_to_char( "You can't let go of it.\n\r", ch );
	return;
    }

    if ( victim->carry_number + get_obj_number( obj ) > can_carry_n( victim ) )
    {
	act( "$N has $S hands full.", ch, NULL, victim, TO_CHAR );
	return;
    }

    if (get_carry_weight(victim) + get_obj_weight(obj) > can_carry_w( victim ) )
    {
	act( "$N can't carry that much weight.", ch, NULL, victim, TO_CHAR );
	return;
    }

    if ( !can_see_obj( victim, obj ) )
    {
	act( "$N can't see it.", ch, NULL, victim, TO_CHAR );
	return;
    }

    obj_from_char( obj );
    obj_to_char( obj, victim );
    act( "$n gives $p to $N.", ch, obj, victim, TO_NOTVICT );
    act( "$n gives you $p.",   ch, obj, victim, TO_VICT    );
    act( "You give $p to $N.", ch, obj, victim, TO_CHAR    );
    check_encumbrance( ch );
    return;
}


/* for poisoning weapons and food/drink */
void do_envenom(Character *ch, char *argument)
{
    Object *obj, *sac;
    int skill;
	char arg[MAX_INPUT_LENGTH];

	argument = one_argument( argument, arg );

	/* Usage */
	if ( arg[0] == '\0' || *argument == '\0' )
	{
		cprintf(ch,"envenom <obj> <poison_source>\n\r");
		return;
	}

    obj =  get_obj_list(ch,arg,ch->carrying);

    if (obj== NULL)
    {
		send_to_char("You don't have that item.\n\r",ch);
		return;
    }

    if ((skill = get_skill(ch,gsn_envenom)) < 1)
    {
		send_to_char("You have no measurable talent with venom handlnig.\n\r",ch);
		return;
    }

	if ( (sac = get_obj_list(ch,argument,ch->carrying)) == NULL )
	{
		cprintf(ch,"You aren't carrying that venom source.\n\r");
		return;
	}

	if ( sac->item_type != ITEM_VENOM_SAC )
	{
		cprintf(ch,"That venom source contains no venom.\n\r");
		return;
	}

    if (obj->item_type == ITEM_WEAPON)
    {
		int sn;

		if (obj->value[3] < 0 || attack_table[obj->value[3]].damage == DAM_BASH)
		{
	    	send_to_char("You can only envenom piercing and slashing weapons.\n\r",ch);
	    	return;
		}

		/* Figure out what type of venom */
		switch( sac->pIndexData->vnum )
		{
			case 1260:	sn = vnum_snake_venom; break;
			case 1261:  sn = vnum_amphibian_venom; break;
			case 1262:  sn = vnum_spider_venom; break;
			case 1263:  sn = vnum_insect_venom; break;
			case 1264:  sn = vnum_lizard_venom; break;
			case 1265:  sn = vnum_plant_venom; break;
			case 1266:  sn = vnum_scorpion_venom; break;
			default:
				cprintf(ch,"The venom source contains an unknown type of venom.\n\r");
				return;
		}

		if ( obj->value[7] > 0 )
		{
			act("$p cannot be envenomed.",ch,obj,NULL,TO_CHAR);
			return;
		}

		obj->value[7] = sn;
		obj->value[8] = UMIN(sac->level,skill);
		obj->value[9] = PROC_ALWAYS;
		SET_BIT( obj->value[4], WEAPON_ONE_TIME_PROC );

		extract_obj( sac );
		act("You coat $p with $P.",ch,obj,sac,TO_CHAR);
		act("$n coats $p with $P.",ch,obj,sac,TO_ROOM);
	
        return;
    }
	else
	{
	    act("You can only envenom weapons.",ch,obj,NULL,TO_CHAR);
	    return;
    }
}

void do_fill( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    char buf[MAX_STRING_LENGTH];
    Object *obj;
    Object *fountain;
    bool found;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Fill what?\n\r", ch );
	return;
    }

    if ( ( obj = get_obj_carry( ch, arg, ch ) ) == NULL )
    {
	send_to_char( "You do not have that item.\n\r", ch );
	return;
    }

    found = FALSE;
    for ( fountain = ch->in_room->contents; fountain != NULL;
	fountain = fountain->next_content )
    {
	if ( fountain->item_type == ITEM_FOUNTAIN )
	{
	    found = TRUE;
	    break;
	}
    }

    if ( !found )
    {
	send_to_char( "There is no fountain here!\n\r", ch );
	return;
    }

    if ( obj->item_type != ITEM_DRINK_CON )
    {
	send_to_char( "You can't fill that.\n\r", ch );
	return;
    }

    if ( obj->value[1] != 0 && obj->value[2] != fountain->value[2] )
    {
	send_to_char( "There is already another liquid in it.\n\r", ch );
	return;
    }

    if ( obj->value[1] >= obj->value[0] )
    {
	send_to_char( "Your container is full.\n\r", ch );
	return;
    }

    sprintf(buf,"You fill $p with %s from $P.",
	liq_table[fountain->value[2]].liq_name);
    act( buf, ch, obj,fountain, TO_CHAR );
    sprintf(buf,"$n fills $p with %s from $P.",
	liq_table[fountain->value[2]].liq_name);
    act(buf,ch,obj,fountain,TO_ROOM);
    obj->value[2] = fountain->value[2];
    obj->value[1] = obj->value[0];
    return;
}

void do_pour (Character *ch, char *argument)
{
    char arg[MAX_STRING_LENGTH],buf[MAX_STRING_LENGTH];
    Object *out, *in;
    Character *vch = NULL;
    int amount;

    argument = one_argument(argument,arg);
    
    if (arg[0] == '\0' || argument[0] == '\0')
    {
	send_to_char("Pour what into what?\n\r",ch);
	return;
    }
    

    if ((out = get_obj_carry(ch,arg, ch)) == NULL)
    {
	send_to_char("You don't have that item.\n\r",ch);
	return;
    }

    if (out->item_type != ITEM_DRINK_CON)
    {
	send_to_char("That's not a drink container.\n\r",ch);
	return;
    }

    if (!str_cmp(argument,"out"))
    {
	if (out->value[1] == 0)
	{
	    send_to_char("It's already empty.\n\r",ch);
	    return;
	}

	out->value[1] = 0;
	out->value[3] = 0;
	sprintf(buf,"You invert $p, spilling %s all over the ground.",
		liq_table[out->value[2]].liq_name);
	act(buf,ch,out,NULL,TO_CHAR);
	
	sprintf(buf,"$n inverts $p, spilling %s all over the ground.",
		liq_table[out->value[2]].liq_name);
	act(buf,ch,out,NULL,TO_ROOM);
	return;
    }

    if ((in = get_obj_here(ch,argument)) == NULL)
    {
	vch = get_char_room(ch,argument);

	if (vch == NULL)
	{
	    send_to_char("Pour into what?\n\r",ch);
	    return;
	}

	in = get_eq_char(vch,WEAR_HOLD);

	if (in == NULL)
	{
	    send_to_char("They aren't holding anything.",ch);
 	    return;
	}
    }

    if (in->item_type != ITEM_DRINK_CON)
    {
	send_to_char("You can only pour into other drink containers.\n\r",ch);
	return;
    }
    
    if (in == out)
    {
	send_to_char("You cannot change the laws of physics!\n\r",ch);
	return;
    }

    if (in->value[1] != 0 && in->value[2] != out->value[2])
    {
	send_to_char("They don't hold the same liquid.\n\r",ch);
	return;
    }

    if (out->value[1] == 0)
    {
	act("There's nothing in $p to pour.",ch,out,NULL,TO_CHAR);
	return;
    }

    if (in->value[1] >= in->value[0])
    {
	act("$p is already filled to the top.",ch,in,NULL,TO_CHAR);
	return;
    }

    amount = UMIN(out->value[1],in->value[0] - in->value[1]);

    in->value[1] += amount;
    out->value[1] -= amount;
    in->value[2] = out->value[2];
    
    if (vch == NULL)
    {
    	sprintf(buf,"You pour %s from $p into $P.",
	    liq_table[out->value[2]].liq_name);
    	act(buf,ch,out,in,TO_CHAR);
    	sprintf(buf,"$n pours %s from $p into $P.",
	    liq_table[out->value[2]].liq_name);
    	act(buf,ch,out,in,TO_ROOM);
    }
    else
    {
        sprintf(buf,"You pour some %s for $N.",
            liq_table[out->value[2]].liq_name);
        act(buf,ch,NULL,vch,TO_CHAR);
	sprintf(buf,"$n pours you some %s.",
	    liq_table[out->value[2]].liq_name);
	act(buf,ch,NULL,vch,TO_VICT);
        sprintf(buf,"$n pours some %s for $N.",
            liq_table[out->value[2]].liq_name);
        act(buf,ch,NULL,vch,TO_NOTVICT);
	
    }
}

void do_drink( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Object *obj;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	for ( obj = ch->in_room->contents; obj; obj = obj->next_content )
	{
	    if ( obj->item_type == ITEM_FOUNTAIN )
		break;
	}

	if ( obj == NULL )
	{
	    send_to_char( "Drink what?\n\r", ch );
	    return;
	}
    }
    else
    {
	if ( ( obj = get_obj_here( ch, arg ) ) == NULL )
	{
	    send_to_char( "You can't find it.\n\r", ch );
	    return;
	}
    }

    if ( !IS_NPC(ch) && ch->pcdata->condition[COND_DRUNK] > 10 )
    {
	send_to_char( "You fail to reach your mouth.  *Hic*\n\r", ch );
	return;
    }

	drink_item( ch, obj, ECHO_ON );
	return;
}

void drink_item( Character *ch, Object *obj, bool fShow )
{
	int liquid, amount;

    switch ( obj->item_type )
    {
    default:
		if ( fShow )
			send_to_char( "You can't drink from that.\n\r", ch );
		return;

    case ITEM_FOUNTAIN:
        if ( ( liquid = obj->value[2] )  < 0 )
        {
            log_bug( "Do_drink: bad liquid number %d.", liquid );
            liquid = obj->value[2] = 0;
        }
	amount = liq_table[liquid].liq_affect[4] * 3;
	break;

    case ITEM_DRINK_CON:
	if ( obj->value[1] <= 0 )
	{
		if ( fShow )
			act("Alas, $p is empty!",ch,obj,NULL,TO_CHAR);
	    return;
	}

	if ( ( liquid = obj->value[2] )  < 0 )
	{
	    log_bug( "Do_drink: bad liquid number %d.", liquid );
	    liquid = obj->value[2] = 0;
	}

        amount = liq_table[liquid].liq_affect[4];
        amount = UMIN(amount, obj->value[1]);
	break;
     }
    if (!IS_NPC(ch) && !IS_IMMORTAL(ch) 
    &&  ch->pcdata->condition[COND_FULL] > 45)
    {
		if ( fShow )
			send_to_char("You're too full to drink more.\n\r",ch);
		return;
    }

    act( "$n drinks $T from $p.", ch, obj, liq_table[liquid].liq_name, TO_ROOM );
	if ( fShow )
    	act( "You drink $T from $p.", ch, obj, liq_table[liquid].liq_name, TO_CHAR );

    gain_condition( ch, COND_DRUNK,
	amount * liq_table[liquid].liq_affect[COND_DRUNK] / 36, TRUE );
    gain_condition( ch, COND_FULL,
	amount * liq_table[liquid].liq_affect[COND_FULL] / 4, TRUE );
    gain_condition( ch, COND_THIRST,
	amount * liq_table[liquid].liq_affect[COND_THIRST] / 10, TRUE );
    gain_condition(ch, COND_HUNGER,
	amount * liq_table[liquid].liq_affect[COND_HUNGER] / 2, TRUE );

	if ( fShow )
	{
    	if ( !IS_NPC(ch) && ch->pcdata->condition[COND_DRUNK]  > 10 )
			send_to_char( "You feel drunk.\n\r", ch );
    	if ( !IS_NPC(ch) && ch->pcdata->condition[COND_FULL]   > 40 )
			send_to_char( "You are full.\n\r", ch );
    	if ( !IS_NPC(ch) && ch->pcdata->condition[COND_THIRST] > 40 )
			send_to_char( "Your thirst is quenched.\n\r", ch );
	}
	
    if ( obj->value[3] != 0 )
    {
	/* The drink was poisoned ! */
	Affect af;

	act( "$n chokes and gags.", ch, NULL, NULL, TO_ROOM );
	send_to_char( "You choke and gag.\n\r", ch );
	af.where     = DAMAGE_OVER_TIME;
	af.type      = vnum_food_poisoning;
	af.level	 = obj->level;
	af.duration  = seconds( UMAX(obj->level, 30) );
	af.location  = UMAX(5,obj->level/5);
	af.modifier  = UMAX(6,obj->level/3);
	af.bitvector = DAM_POISON;
	af.caster_id = 0;
	af.flags	 = AFF_SPELL|AFF_NONSPELL;
    af.misc      = 0;
	affect_join( ch, &af );
    }
	
    if (obj->value[0] > 0)
        obj->value[1] -= amount;

    return;
}



void do_eat( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Object *obj;

    one_argument( argument, arg );
    if ( arg[0] == '\0' )
    {
	send_to_char( "Eat what?\n\r", ch );
	return;
    }

    if ( ( obj = get_obj_carry( ch, arg, ch ) ) == NULL )
    {
	send_to_char( "You do not have that item.\n\r", ch );
	return;
    }

    if ( !IS_IMMORTAL(ch) )
    {
	if ( obj->item_type != ITEM_FOOD && obj->item_type != ITEM_PILL )
	{
	    send_to_char( "That's not edible.\n\r", ch );
	    return;
	}

	if ( !IS_NPC(ch) && ch->pcdata->condition[COND_FULL] > 40 )
	{   
	    send_to_char( "You are too full to eat more.\n\r", ch );
	    return;
	}
    }

	eat_item( ch, obj, ECHO_ON );
	return;
}

void eat_item( Character *ch, Object *obj, bool fEcho )
{
	if ( fEcho )
    	act( "You eat $p.", ch, obj, NULL, TO_CHAR );

	act( "$n eats $p.",  ch, obj, NULL, TO_ROOM );

    switch ( obj->item_type )
    {
    case ITEM_FOOD:
		if ( !IS_NPC(ch) )
		{
	    	int condition;
	
	    	condition = ch->pcdata->condition[COND_HUNGER];
	    	gain_condition( ch, COND_FULL, obj->value[0], TRUE );
	    	gain_condition( ch, COND_HUNGER, obj->value[1], TRUE );
			if ( fEcho )
			{
	    		if ( condition == 0 && ch->pcdata->condition[COND_HUNGER] > 0 )
					send_to_char( "You are no longer hungry.\n\r", ch );
	    		else if ( ch->pcdata->condition[COND_FULL] > 40 )
					send_to_char( "You are full.\n\r", ch );
			}
		}
	
		if ( obj->value[3] != 0 )
		{
	    	/* The food was poisoned! */
	    	Affect af;
	
	    	act( "$n chokes and gags.", ch, 0, 0, TO_ROOM );
	    	send_to_char( "You choke and gag.\n\r", ch );
	
	    	af.where	 = DAMAGE_OVER_TIME;
	    	af.type      = vnum_food_poisoning;
	    	af.level 	 = obj->level;
	    	af.duration  = seconds( UMAX(obj->level,30) );
	    	af.location  = UMAX(5,obj->level /5);
	    	af.modifier  = UMAX(6,obj->level /3);
	    	af.bitvector = DAM_POISON;
			af.caster_id = 0;
			af.flags	 = AFF_SPELL|AFF_NONSPELL;
	    	affect_join( ch, &af );
		}
		break;
	
    case ITEM_PILL:
		obj_cast_spell( obj->value[1], obj->value[0], ch, ch, NULL );
		obj_cast_spell( obj->value[2], obj->value[0], ch, ch, NULL );
		obj_cast_spell( obj->value[3], obj->value[0], ch, ch, NULL );
	break;
    }

    extract_obj( obj );
    return;
}



/*
 * Remove an object.
 */
bool remove_obj( Character *ch, int iWear, bool fReplace )
{
    Object *obj;
	Object *offhand;
	int wear_loc_save;

    if ( ( obj = get_eq_char( ch, iWear ) ) == NULL )
		return TRUE;

    if ( !fReplace )
		return FALSE;

	wear_loc_save = obj->wear_loc;
    unequip_char( ch, obj );
    act( "$n stops using $p.", ch, obj, NULL, TO_ROOM );
    act( "You stop using $p.", ch, obj, NULL, TO_CHAR );

    if ( !fReplace && wear_loc_save == WEAR_WIELD && (offhand=get_eq_char(ch,WEAR_OFFHAND)) != NULL )
    {
		offhand->wear_loc = WEAR_WIELD;
		act("You switch $p to your swordarm.",ch,offhand,NULL,TO_CHAR);
		act("$n switches $p to $s swordarm.",ch,offhand,NULL,TO_ROOM);
	}

	if ( wear_loc_save == WEAR_WIELD )
	{
       	setSkillReuseWait(ch,gsn_hand_to_hand,getWeaponReuse(ch));
		if ( ch->style )
		{
			cprintf(ch,"&RYou cancel the style you had prepared.&x\n\r");
			ch->style = 0;
			clear_style( ch );
		}
	}

    check_encumbrance( ch );
    return TRUE;
}



/*
 * Wear one object.
 * Optional replacement of existing objects.
 * Big repetitive code, ick.
 */
void wear_obj( Character *ch, Object *obj, bool fReplace )
{
    if ( !can_equip(ch,obj) )
		return;

/*
    if ( ch->level < obj->level )
    {
	sprintf( buf, "You must be level %d to use this object.\n\r",
	    obj->level );
	send_to_char( buf, ch );
	act( "$n tries to use $p, but is too inexperienced.",
	    ch, obj, NULL, TO_ROOM );
	return;
    }
*/

    if ( obj->item_type == ITEM_LIGHT )
    {
	if ( !remove_obj( ch, WEAR_LIGHT, fReplace ) )
	    return;
	act( "$n lights $p and holds it.", ch, obj, NULL, TO_ROOM );
	act( "You light $p and hold it.",  ch, obj, NULL, TO_CHAR );
	equip_char( ch, obj, WEAR_LIGHT );
	return;
    }

    if ( CAN_WEAR( obj, ITEM_WEAR_FINGER ) )
    {
	if ( get_eq_char( ch, WEAR_FINGER_L ) != NULL
	&&   get_eq_char( ch, WEAR_FINGER_R ) != NULL
	&&   !remove_obj( ch, WEAR_FINGER_L, fReplace )
	&&   !remove_obj( ch, WEAR_FINGER_R, fReplace ) )
	    return;

	if ( get_eq_char( ch, WEAR_FINGER_L ) == NULL )
	{
	    act( "$n wears $p on $s left finger.",    ch, obj, NULL, TO_ROOM );
	    act( "You wear $p on your left finger.",  ch, obj, NULL, TO_CHAR );
	    equip_char( ch, obj, WEAR_FINGER_L );
	    return;
	}

	if ( get_eq_char( ch, WEAR_FINGER_R ) == NULL )
	{
	    act( "$n wears $p on $s right finger.",   ch, obj, NULL, TO_ROOM );
	    act( "You wear $p on your right finger.", ch, obj, NULL, TO_CHAR );
	    equip_char( ch, obj, WEAR_FINGER_R );
	    return;
	}

	log_bug( "Wear_obj: no free finger.", 0 );
	send_to_char( "You already wear two rings.\n\r", ch );
	return;
    }

    if ( CAN_WEAR( obj, ITEM_WEAR_EAR ) )
    {
        if ( get_eq_char( ch, WEAR_EAR_L ) != NULL
        &&   get_eq_char( ch, WEAR_EAR_R ) != NULL
        &&   !remove_obj( ch, WEAR_EAR_L, fReplace )
        &&   !remove_obj( ch, WEAR_EAR_R, fReplace ) )
            return;

        if ( get_eq_char( ch, WEAR_EAR_L ) == NULL )
        {
            act( "$n wears $p in $s left ear..",    ch, obj, NULL, TO_ROOM );
            act( "You wear $p in your left ear.",  ch, obj, NULL, TO_CHAR );
            equip_char( ch, obj, WEAR_EAR_L );
            return;
        }

        if ( get_eq_char( ch, WEAR_EAR_R ) == NULL )
        {
            act( "$n wears $p in $s right ear.",   ch, obj, NULL, TO_ROOM );
            act( "You wear $p in your right ear.", ch, obj, NULL, TO_CHAR );
            equip_char( ch, obj, WEAR_EAR_R );
            return;
        }

        log_bug( "Wear_obj: no free ear.", 0 );
        send_to_char( "You already wear two earrings.\n\r", ch );
        return;
    }

    if ( CAN_WEAR( obj, ITEM_WEAR_NECK ) )
    {
	if ( get_eq_char( ch, WEAR_NECK_1 ) != NULL
	&&   get_eq_char( ch, WEAR_NECK_2 ) != NULL
	&&   !remove_obj( ch, WEAR_NECK_1, fReplace )
	&&   !remove_obj( ch, WEAR_NECK_2, fReplace ) )
	    return;

	if ( get_eq_char( ch, WEAR_NECK_1 ) == NULL )
	{
	    act( "$n wears $p around $s neck.",   ch, obj, NULL, TO_ROOM );
	    act( "You wear $p around your neck.", ch, obj, NULL, TO_CHAR );
	    equip_char( ch, obj, WEAR_NECK_1 );
	    return;
	}

	if ( get_eq_char( ch, WEAR_NECK_2 ) == NULL )
	{
	    act( "$n wears $p around $s neck.",   ch, obj, NULL, TO_ROOM );
	    act( "You wear $p around your neck.", ch, obj, NULL, TO_CHAR );
	    equip_char( ch, obj, WEAR_NECK_2 );
	    return;
	}

	log_bug( "Wear_obj: no free neck.", 0 );
	send_to_char( "You already wear two neck items.\n\r", ch );
	return;
    }

    if ( CAN_WEAR( obj, ITEM_WEAR_SHOULDERS ) )
    {
        if ( !remove_obj( ch, WEAR_SHOULDERS, fReplace ) )
            return;
        act( "$n wears $p on $s shoulders.",   ch, obj, NULL, TO_ROOM );
        act( "You wear $p on your shoulders.", ch, obj, NULL, TO_CHAR );
        equip_char( ch, obj, WEAR_SHOULDERS );
        return;
    }

    if ( CAN_WEAR( obj, ITEM_WEAR_FACE ) )
    {
        if ( !remove_obj( ch, WEAR_FACE, fReplace ) )
            return;
        act( "$n wears $p over $s face.",   ch, obj, NULL, TO_ROOM );
        act( "You wear $p over your face.", ch, obj, NULL, TO_CHAR );
        equip_char( ch, obj, WEAR_FACE );
        return;
    }

    if ( CAN_WEAR( obj, ITEM_WEAR_BODY ) )
    {
	if ( !remove_obj( ch, WEAR_BODY, fReplace ) )
	    return;
	act( "$n wears $p on $s torso.",   ch, obj, NULL, TO_ROOM );
	act( "You wear $p on your torso.", ch, obj, NULL, TO_CHAR );
	equip_char( ch, obj, WEAR_BODY );
	return;
    }

    if ( CAN_WEAR( obj, ITEM_WEAR_HEAD ) )
    {
	if ( !remove_obj( ch, WEAR_HEAD, fReplace ) )
	    return;
	act( "$n wears $p on $s head.",   ch, obj, NULL, TO_ROOM );
	act( "You wear $p on your head.", ch, obj, NULL, TO_CHAR );
	equip_char( ch, obj, WEAR_HEAD );
	return;
    }

    if ( CAN_WEAR( obj, ITEM_WEAR_LEGS ) )
    {
	if ( !remove_obj( ch, WEAR_LEGS, fReplace ) )
	    return;
	act( "$n wears $p on $s legs.",   ch, obj, NULL, TO_ROOM );
	act( "You wear $p on your legs.", ch, obj, NULL, TO_CHAR );
	equip_char( ch, obj, WEAR_LEGS );
	return;
    }

    if ( CAN_WEAR( obj, ITEM_WEAR_FEET ) )
    {
	if ( !remove_obj( ch, WEAR_FEET, fReplace ) )
	    return;
	act( "$n wears $p on $s feet.",   ch, obj, NULL, TO_ROOM );
	act( "You wear $p on your feet.", ch, obj, NULL, TO_CHAR );
	equip_char( ch, obj, WEAR_FEET );
	return;
    }

	if ( CAN_WEAR( obj, ITEM_WEAR_INSTRUMENT ) )
	{
		if ( !remove_obj( ch, WEAR_INSTRUMENT, fReplace ) )
			return;
		act("$n readies $p for play.",ch,obj,NULL,TO_ROOM);
		act("You ready $p for play.", ch,obj,NULL,TO_CHAR);
		equip_char(ch,obj,WEAR_INSTRUMENT);
		return;
	}

    if ( CAN_WEAR( obj, ITEM_WEAR_HANDS ) )
    {
	if ( !remove_obj( ch, WEAR_HANDS, fReplace ) )
	    return;
	act( "$n wears $p on $s hands.",   ch, obj, NULL, TO_ROOM );
	act( "You wear $p on your hands.", ch, obj, NULL, TO_CHAR );
	equip_char( ch, obj, WEAR_HANDS );
	return;
    }

    if ( CAN_WEAR( obj, ITEM_WEAR_ARMS ) )
    {
	if ( !remove_obj( ch, WEAR_ARMS, fReplace ) )
	    return;
	act( "$n wears $p on $s arms.",   ch, obj, NULL, TO_ROOM );
	act( "You wear $p on your arms.", ch, obj, NULL, TO_CHAR );
	equip_char( ch, obj, WEAR_ARMS );
	return;
    }

    if ( CAN_WEAR( obj, ITEM_WEAR_ABOUT ) )
    {
	if ( !remove_obj( ch, WEAR_ABOUT, fReplace ) )
	    return;
	act( "$n wears $p over $s back.",   ch, obj, NULL, TO_ROOM );
	act( "You wear $p over your back.", ch, obj, NULL, TO_CHAR );
	equip_char( ch, obj, WEAR_ABOUT );
	return;
    }

    if ( CAN_WEAR( obj, ITEM_WEAR_WAIST ) )
    {
	if ( !remove_obj( ch, WEAR_WAIST, fReplace ) )
	    return;
	act( "$n wears $p about $s waist.",   ch, obj, NULL, TO_ROOM );
	act( "You wear $p about your waist.", ch, obj, NULL, TO_CHAR );
	equip_char( ch, obj, WEAR_WAIST );
	return;
    }

    if ( CAN_WEAR( obj, ITEM_WEAR_WRIST ) )
    {
	if ( get_eq_char( ch, WEAR_WRIST_L ) != NULL
	&&   get_eq_char( ch, WEAR_WRIST_R ) != NULL
	&&   !remove_obj( ch, WEAR_WRIST_L, fReplace )
	&&   !remove_obj( ch, WEAR_WRIST_R, fReplace ) )
	    return;

	if ( get_eq_char( ch, WEAR_WRIST_L ) == NULL )
	{
	    act( "$n wears $p around $s left wrist.",
		ch, obj, NULL, TO_ROOM );
	    act( "You wear $p around your left wrist.",
		ch, obj, NULL, TO_CHAR );
	    equip_char( ch, obj, WEAR_WRIST_L );
	    return;
	}

	if ( get_eq_char( ch, WEAR_WRIST_R ) == NULL )
	{
	    act( "$n wears $p around $s right wrist.",
		ch, obj, NULL, TO_ROOM );
	    act( "You wear $p around your right wrist.",
		ch, obj, NULL, TO_CHAR );
	    equip_char( ch, obj, WEAR_WRIST_R );
	    return;
	}

	log_bug( "Wear_obj: no free wrist.", 0 );
	send_to_char( "You already wear two wrist items.\n\r", ch );
	return;
    }

    if ( CAN_WEAR( obj, ITEM_WEAR_SHIELD ) )
    {
		extern int mapArmorSlot( int gpn );
		Object *weapon;

		if ( !remove_obj( ch, WEAR_SHIELD, fReplace ) )
	    	return;

		weapon = get_eq_char(ch,WEAR_WIELD);
		if (weapon != NULL && ch->size < SIZE_LARGE 
		&&  IS_WEAPON_STAT(weapon,WEAPON_TWO_HANDS)
		&&  obj->value[5] != mapArmorSlot(gpn_buckler_shields))
		{
	    	send_to_char("Your hands are tied up with your weapon!\n\r",ch);
	    	return;
		}

		if ( (weapon = get_eq_char(ch,WEAR_OFFHAND)) != NULL  &&
		 	obj->value[5] != mapArmorSlot(gpn_buckler_shields) )
		{
			cprintf(ch,"You can only wear a buckler shield while dual wielding.\n\r",ch);
			return;
		}

		act( "$n wears $p as a shield.", ch, obj, NULL, TO_ROOM );
		act( "You wear $p as a shield.", ch, obj, NULL, TO_CHAR );
		equip_char( ch, obj, WEAR_SHIELD );
		return;
    }

	if ( CAN_WEAR( obj, ITEM_WEAR_RANGED ) )
    {
		if ( !remove_obj( ch, WEAR_RANGED, fReplace ) )
	   	 return;

		act( "$n prepares $p for use.", ch, obj, NULL, TO_ROOM );
		act( "You prepare $p for use.", ch, obj, NULL, TO_CHAR );
		equip_char( ch, obj, WEAR_RANGED );

		return;
    }

	if ( CAN_WEAR( obj, ITEM_WEAR_OFFHAND ) )
    {
		Object *main_weapon, *shield;
		int fMain = FALSE;

		if ( (main_weapon = get_eq_char(ch,WEAR_WIELD)) == NULL )
			fMain = TRUE;

		if ( !remove_obj(ch,fMain ? WEAR_WIELD : WEAR_OFFHAND, fReplace) )
			return;
	
		/*if ( !fMain && main_weapon->weight < obj->weight )
		{
			cprintf(ch,"Your offhand weapon must weigh less than your main weapon.\n\r");
			return;
		}*/

		shield = get_eq_char(ch,WEAR_SHIELD);
//		if ( IS_WEAPON_STAT(obj,WEAPON_TWO_HANDS) )
//		{
			if ( (  !fMain && shield && 
					shield->value[5] != mapArmorSlot(gpn_buckler_shields) &&
					shield->pIndexData->vnum != VNUM_MAGE_SHIELD ) )
			{
				cprintf(ch,"You can't be using a shield with that weapon.\n\r",ch);
				return;
			}
//		}

		if ( !fMain && IS_WEAPON_STAT(main_weapon,WEAPON_TWO_HANDS) )
		{
			cprintf(ch,"Your main weapon requires two hands to use.\n\r");
			return;
		}

		act( "$n wields $p.", ch, obj, NULL, TO_ROOM );
		act( "You wield $p.", ch, obj, NULL, TO_CHAR );
		equip_char( ch, obj, fMain ? WEAR_WIELD : WEAR_OFFHAND );

	/*	sn = get_weapon_sn(ch,fMain? GET_WEAPON_SN : GET_OFFHAND_SN);  
		if ( getWeaponReuse(ch) > 0 )
			setSkillReuseWait(ch,sn,getWeaponReuse(ch));
	*/

		return;
    }


    if ( CAN_WEAR( obj, ITEM_WIELD ) )
    {
		int sn, reuse;
		Object *off, *shield;

		if ( !remove_obj( ch, WEAR_WIELD, fReplace ) )
	    	return;

		shield = get_eq_char(ch,WEAR_SHIELD);
		if (!IS_NPC(ch) && ch->size < SIZE_LARGE 
		&&  IS_WEAPON_STAT(obj,WEAPON_TWO_HANDS)
 		&&  ( (shield && shield->pIndexData->vnum != VNUM_MAGE_SHIELD &&
			  (shield->value[5] != mapArmorSlot(gpn_buckler_shields)) ) ||
              (get_eq_char(ch,WEAR_OFFHAND) != NULL)) )
		{
	    	send_to_char("You need two hands free for that weapon.\n\r",ch);
	    	return;
		}

		/* check for an offhander that's heavier */
		if ( ( off = get_eq_char( ch, WEAR_OFFHAND ) ) != NULL )
		{
			if ( off->weight > obj->weight )
			{
				act("Your offhand weapon, $p, weighs more than $P.",ch,off,obj,TO_CHAR);
				return;
			}
		}

		/* If they change weapons, they have to pay the rest of their longest
		 * current wait, as well as the attack value of the new weapon
		 */
		reuse = getWeaponReuse(ch);

		act( "$n wields $p.", ch, obj, NULL, TO_ROOM );
		act( "You wield $p.", ch, obj, NULL, TO_CHAR );
		equip_char( ch, obj, WEAR_WIELD );

		/* Impose reuse wait */
		sn = get_weapon_sn(ch,GET_WEAPON_SN);
		setSkillReuseWait(ch,sn,reuse+obj->value[5]);
	
		return;
    }

    if ( CAN_WEAR( obj, ITEM_HOLD ) )
    {
	if ( !remove_obj( ch, WEAR_HOLD, fReplace ) )
	    return;
	act( "$n holds $p in $s hand.",   ch, obj, NULL, TO_ROOM );
	act( "You hold $p in your hand.", ch, obj, NULL, TO_CHAR );
	equip_char( ch, obj, WEAR_HOLD );
	return;
    }

    if ( CAN_WEAR(obj,ITEM_WEAR_FLOAT) )
    {
	if (!remove_obj(ch,WEAR_FLOAT, fReplace) )
	    return;
	act("$n releases $p to float next to $m.",ch,obj,NULL,TO_ROOM);
	act("You release $p and it floats next to you.",ch,obj,NULL,TO_CHAR);
	equip_char(ch,obj,WEAR_FLOAT);
	return;
    }

    if ( fReplace )
	send_to_char( "You can't wear, wield, or hold that.\n\r", ch );

    return;
}



void do_wear( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Object *obj;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
		send_to_char( "Wear, wield, or hold what?\n\r", ch );
		return;
    }

    if ( !str_cmp( arg, "all" ) )
    {
		Object *obj_next;

		for ( obj = ch->carrying; obj != NULL; obj = obj_next )
		{
	    	obj_next = obj->next_content;
	    	if ( obj->wear_loc == WEAR_NONE && can_see_obj( ch, obj ) )
			{
				wear_obj( ch, obj, FALSE );
				check_encumbrance( ch );
			}
		}
		return;
    }
    else
    {
		if ( ( obj = get_obj_carry( ch, arg, ch ) ) == NULL )
		{
	    	send_to_char( "You do not have that item.\n\r", ch );
	    	return;
		}

		wear_obj( ch, obj, TRUE );
		check_encumbrance( ch );
    }

    return;
}



void do_remove( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Object *obj;
	int i;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Remove what?\n\r", ch );
	return;
    }
	
	if(str_prefix(argument, "all"))
	{
		if ( ( obj = get_obj_wear( ch, arg ) ) == NULL )
		{
		send_to_char( "You do not have that item.\n\r", ch );
		return;
		}

		remove_obj( ch, obj->wear_loc, TRUE );
	}
	else//Take it all off!
	{
		for(i = 0; i<MAX_WEAR; i++)
			remove_obj( ch, i, TRUE);
	}
    return;
}



void do_sacrifice( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Object *obj;
    int value;
    
    /* variables for AUTOSPLIT */
    Character *gch;
    int members;
    char buffer[100];


    one_argument( argument, arg );

    if ( arg[0] == '\0' || !str_cmp( arg, ch->name ) )
    {
		cprintf(ch,"Sacrifice what?\n\r");
		return;
    }

    obj = get_obj_list( ch, arg, ch->in_room->contents );
    if ( obj == NULL )
    {
		send_to_char( "You can't find it.\n\r", ch );
		return;
    }

    if ( obj->item_type == ITEM_CORPSE_PC )
    {
		if (obj->contains)
        {
	   		cprintf(ch,"You must remove the mortal trappings from it first.\n\r");
	   		return;
        }
    }

    if ( !CAN_WEAR(obj, ITEM_TAKE) || CAN_WEAR(obj, ITEM_NO_SAC))
    {
		act( "$p is not an acceptable sacrifice.", ch, obj, 0, TO_CHAR );
		return;
    }

    if (obj->in_room != NULL)
    {
		for (gch = obj->in_room->people; gch != NULL; gch = gch->next_in_room)
	    	if (gch->on == obj)
	    	{
				act("$N appears to be using $p.", ch,obj,gch,TO_CHAR);
				return;
	    	}
    }
		
    value = UMAX(1,obj->level * 3);

    if (obj->item_type != ITEM_CORPSE_NPC && obj->item_type != ITEM_CORPSE_PC)
    	value = UMIN(value,obj->cost);

    if (value >= 1)
		cprintf(ch,"Your sacrifice is rewarded by the gods with %d silver.\n\r",value);
   
	ch->coins[CUR_SILVER] += value; 
    
    if (HAS_AUTOOPT(ch, AUTO_SPLIT))
    { /* AUTOSPLIT code */
    	members = 0;
		for (gch = ch->in_room->people; gch != NULL; gch = gch->next_in_room )
    	{
    	    if ( is_same_group( gch, ch ) )
            members++;
    	}

		if ( members > 1 && value > 1)
		{
	    	sprintf(buffer,"%d silver",value);
	    	do_function(ch, &do_split, buffer);	
		}
    }

    act( "$n sacrifices $p to $y.", ch, obj, NULL, TO_ROOM );
	act( "You sacrifice $p to $y.", ch, obj, NULL, TO_CHAR );
    wiznet("$N sends up $p as a burnt offering.",
	   ch,obj,WIZ_SACCING,0,0);
    extract_obj( obj );
    return;
}



void do_quaff( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Object *obj;

    cprintf(ch,"Potions are temporarily disabled while we transition the magic system.\n\r");
    return;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Quaff what?\n\r", ch );
	return;
    }

    if ( ( obj = get_obj_carry( ch, arg, ch ) ) == NULL )
    {
	send_to_char( "You do not have that potion.\n\r", ch );
	return;
    }

    if ( obj->item_type != ITEM_POTION )
    {
	send_to_char( "You can quaff only potions.\n\r", ch );
	return;
    }

    if (ch->level < obj->level)
    {
	send_to_char("This liquid is too powerful for you to drink.\n\r",ch);
	return;
    }

    act( "$n quaffs $p.", ch, obj, NULL, TO_ROOM );
    act( "You quaff $p.", ch, obj, NULL ,TO_CHAR );

    obj_cast_spell( obj->value[1], obj->value[0], ch, ch, NULL );
    obj_cast_spell( obj->value[2], obj->value[0], ch, ch, NULL );
    obj_cast_spell( obj->value[3], obj->value[0], ch, ch, NULL );

    extract_obj( obj );
    return;
}



void do_recite( Character *ch, char *argument )
{
    char arg1[MAX_INPUT_LENGTH];
    char arg2[MAX_INPUT_LENGTH];
    Character *victim;
    Object *scroll;
    Object *obj;

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );

    if ( ( scroll = get_obj_carry( ch, arg1, ch ) ) == NULL )
    {
	send_to_char( "You do not have that scroll.\n\r", ch );
	return;
    }

    if ( scroll->item_type != ITEM_SCROLL )
    {
	send_to_char( "You can recite only scrolls.\n\r", ch );
	return;
    }

    if ( ch->level < scroll->level)
    {
	send_to_char(
		"This scroll is too complex for you to comprehend.\n\r",ch);
	return;
    }

    obj = NULL;
    if ( arg2[0] == '\0' )
    {
	victim = ch;
    }
    else
    {
	if ( ( victim = get_char_room ( ch, arg2 ) ) == NULL
	&&   ( obj    = get_obj_here  ( ch, arg2 ) ) == NULL )
	{
	    send_to_char( "You can't find it.\n\r", ch );
	    return;
	}
    }

    act( "$n recites $p.", ch, scroll, NULL, TO_ROOM );
    act( "You recite $p.", ch, scroll, NULL, TO_CHAR );

    if (number_percent() >= 20 + get_skill(ch,gsn_scrolls) * 4/5)
    {
	send_to_char("You mispronounce a syllable.\n\r",ch);
	check_improve(ch,gsn_scrolls,FALSE,2);
    }

    else
    {
    	obj_cast_spell( scroll->value[1], scroll->value[0], ch, victim, obj );
    	obj_cast_spell( scroll->value[2], scroll->value[0], ch, victim, obj );
    	obj_cast_spell( scroll->value[3], scroll->value[0], ch, victim, obj );
	check_improve(ch,gsn_scrolls,TRUE,2);
    }

    extract_obj( scroll );
    return;
}



void do_brandish( Character *ch, char *argument )
{
    Character *vch;
    Character *vch_next;
    Object *staff;
    int sn;

    cprintf(ch,"Staffs are temporarily disabled while we transition the magic system.\n\r");
    return;

    if ( ( staff = get_eq_char( ch, WEAR_HOLD ) ) == NULL )
    {
	send_to_char( "You hold nothing in your hand.\n\r", ch );
	return;
    }

    if ( staff->item_type != ITEM_STAFF )
    {
	send_to_char( "You can brandish only with a staff.\n\r", ch );
	return;
    }

    if ( ( sn = staff->value[3] ) < 0
    ||   sn >= MAX_SKILL
    ||   skill_table[sn].spell_fun == 0 )
    {
	log_bug( "Do_brandish: bad sn %d.", sn );
	return;
    }

    WAIT_STATE( ch, 2 * PULSE_VIOLENCE );

    if ( staff->value[2] > 0 )
    {
	act( "$n brandishes $p.", ch, staff, NULL, TO_ROOM );
	act( "You brandish $p.",  ch, staff, NULL, TO_CHAR );
	if ( ch->level < staff->level 
	||   number_percent() >= 20 + get_skill(ch,gsn_staves) * 4/5)
 	{
	    act ("You fail to invoke $p.",ch,staff,NULL,TO_CHAR);
	    act ("...and nothing happens.",ch,NULL,NULL,TO_ROOM);
	    check_improve(ch,gsn_staves,FALSE,2);
	}
	
	else for ( vch = ch->in_room->people; vch; vch = vch_next )
	{
	    vch_next	= vch->next_in_room;

	    switch ( skill_table[sn].target )
	    {
	    default:
		log_bug( "Do_brandish: bad target for sn %d.", sn );
		return;

	    case TAR_IGNORE:
		if ( vch != ch )
		    continue;
		break;

	    case TAR_CHAR_OFFENSIVE:
		if ( IS_NPC(ch) ? IS_NPC(vch) : !IS_NPC(vch) )
		    continue;
		break;
		
	    case TAR_CHAR_DEFENSIVE:
		if ( IS_NPC(ch) ? !IS_NPC(vch) : IS_NPC(vch) )
		    continue;
		break;

	    case TAR_CHAR_SELF:
		if ( vch != ch )
		    continue;
		break;
	    }

	    obj_cast_spell( staff->value[3], staff->value[0], ch, vch, NULL );
	    check_improve(ch,gsn_staves,TRUE,2);
	}
    }

    if ( --staff->value[2] <= 0 )
    {
	act( "$n's $p blazes bright and is gone.", ch, staff, NULL, TO_ROOM );
	act( "Your $p blazes bright and is gone.", ch, staff, NULL, TO_CHAR );
	extract_obj( staff );
    }

    return;
}



void do_zap( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Character *victim;
    Object *wand;
    Object *obj;

    cprintf(ch,"Wands are temporarily disabled while we transition the magic system.\n\r");
    return;

    one_argument( argument, arg );
    if ( arg[0] == '\0' && ch->fighting == NULL )
    {
	send_to_char( "Zap whom or what?\n\r", ch );
	return;
    }

    if ( ( wand = get_eq_char( ch, WEAR_HOLD ) ) == NULL )
    {
	send_to_char( "You hold nothing in your hand.\n\r", ch );
	return;
    }

    if ( wand->item_type != ITEM_WAND )
    {
	send_to_char( "You can zap only with a wand.\n\r", ch );
	return;
    }

    obj = NULL;
    if ( arg[0] == '\0' )
    {
	if ( ch->fighting != NULL )
	{
	    victim = ch->fighting;
	}
	else
	{
	    send_to_char( "Zap whom or what?\n\r", ch );
	    return;
	}
    }
    else
    {
	if ( ( victim = get_char_room ( ch, arg ) ) == NULL
	&&   ( obj    = get_obj_here  ( ch, arg ) ) == NULL )
	{
	    send_to_char( "You can't find it.\n\r", ch );
	    return;
	}
    }

    WAIT_STATE( ch, 2 * PULSE_VIOLENCE );

    if ( wand->value[2] > 0 )
    {
	if ( victim != NULL )
	{
	    act( "$n zaps $N with $p.", ch, wand, victim, TO_NOTVICT );
	    act( "You zap $N with $p.", ch, wand, victim, TO_CHAR );
	    act( "$n zaps you with $p.",ch, wand, victim, TO_VICT );
	}
	else
	{
	    act( "$n zaps $P with $p.", ch, wand, obj, TO_ROOM );
	    act( "You zap $P with $p.", ch, wand, obj, TO_CHAR );
	}

 	if (ch->level < wand->level 
	||  number_percent() >= 20 + get_skill(ch,gsn_wands) * 4/5) 
	{
	    act( "Your efforts with $p produce only smoke and sparks.",
		 ch,wand,NULL,TO_CHAR);
	    act( "$n's efforts with $p produce only smoke and sparks.",
		 ch,wand,NULL,TO_ROOM);
	    check_improve(ch,gsn_wands,FALSE,2);
	}
	else
	{
	    obj_cast_spell( wand->value[3], wand->value[0], ch, victim, obj );
	    check_improve(ch,gsn_wands,TRUE,2);
	}
    }

    if ( --wand->value[2] <= 0 )
    {
	act( "$n's $p explodes into fragments.", ch, wand, NULL, TO_ROOM );
	act( "Your $p explodes into fragments.", ch, wand, NULL, TO_CHAR );
	extract_obj( wand );
    }

    return;
}



void do_steal( Character *ch, char *argument )
{
    char arg1 [MAX_INPUT_LENGTH];
    char arg2 [MAX_INPUT_LENGTH];
    Character *victim;
    Object *obj;
    int chance, skill, cur;
	int rand_steal_chance[MAX_CURRENCY] = { 60, 50, 40, 30, 20 };
	int targ_steal_chance[MAX_CURRENCY] = {120, 90, 60, 40, 20 };
								/*     Si  Go  El  Pl  Mi   */

	/* Usage:
	 * steal coins <player>
	 * steal <coin_type> <player>
	 * steal <object> <player>
	 */

	if ( (skill = get_skill(ch,gsn_pick_pocket)) < 1 )
	{
		cprintf(ch,"You lack skill in the subtle art of theft.\n\r");
		return;
	}

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );

    if ( arg1[0] == '\0' || arg2[0] == '\0' )
    {
		send_to_char( "Steal what from whom?\n\r", ch );
		return;
    }

    if ( ( victim = get_char_room( ch, arg2 ) ) == NULL )
    {
		send_to_char( "They aren't here.\n\r", ch );
		return;
    }

    if ( victim == ch )
    {
		send_to_char( "Been caught stealing?\n\r", ch );
		return;
    }

    if (is_safe(ch,victim))
		return;

	/* Chance for success depends on what you are doing.
	 * For stealing plain old coins it's 50% modified at base50 plus level diff.
	 * For stealing a specific type it depends on the type.
	 */

	if ( IS_IMMORTAL(victim) )
		goto failure;

	/* Base chance based on skill */
	chance = 50;
	applySkillAdjust( &chance, 50, skill, ch->level );
	chance += applyLevelDifference(ch->level,victim->level);

    if ( !str_cmp( arg1, "coin"  )
    ||   !str_cmp( arg1, "coins" ))
    {
		int which = -1;
		int amount;
		int i;

		/* Failed. */
		if ( number_percent() > chance )
			goto failure;

		/* Determine a random currency using array at beginning */
		for( i = 0 ; i < MAX_CURRENCY ; i++ )
			if ( number_percent() < rand_steal_chance[i] )
			{
				which = i;
				break;
			}

		which = UMAX(which,0);
		amount = victim->coins[which] * number_range(1, ch->level) / MAX_LEVEL;
		if ( amount <= 0 )
		{
	    	send_to_char( "You couldn't get any coins.\n\r", ch );
	    	return;
		}

		ch->coins[which]     	+= amount;
		victim->coins[which]	-= amount;

		cprintf(ch,"Got it!  You stole %d %s coins.\n\r", amount, currency_table[which].name);
		setSkillReuseWait(ch,gsn_pick_pocket,PULSE_PER_SECOND * 30);
		return;
    }

	if ( (cur = currency_lookup( arg1 )) != -1 )
	{
		int amount;

		/* Trying to steal specific type of currency */
		chance = targ_steal_chance[cur] * chance / 100;

		if ( number_percent() > chance )
			goto failure;

		amount = number_range( 0, victim->coins[cur] / 2 );
		if ( amount <= 0 )
		{
			cprintf(ch,"Bummer, you couldn't snag any.\n\r");
			return;
		}

		victim->coins[cur] -= amount;
		ch->coins[cur] += amount;

		cprintf(ch,"Got it!  You stole %d %s coins.\n\r", amount, currency_table[cur].name );
		setSkillReuseWait(ch,gsn_pick_pocket,PULSE_PER_SECOND * 30);
		return;
	}

    if ( ( obj = get_obj_carry( victim, arg1, ch ) ) == NULL )
    {
		act("$N doesn't seem to be carrying anything like that.",ch,NULL,victim,TO_CHAR);
		return;
    }

	if ( number_percent() > chance )
		goto failure;
	
    if ( !can_drop_obj( ch, obj )
    	||   IS_SET(obj->extra_flags, ITEM_INVENTORY)
    	||   obj->level > ch->level )
    {
		send_to_char( "You can't pry it away.\n\r", ch );
		return;
    }

    if ( ch->carry_number + get_obj_number( obj ) > can_carry_n( ch ) )
    {
		send_to_char( "You have your hands full.\n\r", ch );
		return;
    }

    if ( ch->carry_weight + get_obj_weight( obj ) > can_carry_w( ch ) )
    {
		send_to_char( "You can't carry that much weight.\n\r", ch );
		return;
    }

    obj_from_char( obj );
    obj_to_char( obj, ch );
    act("You transfer ownership of $p from $N to yourself.  Well done!",ch,obj,victim,TO_CHAR);
    return;

failure:
	affect_strip(ch,gsn_stealth);
	REMOVE_BIT(ch->affected_by,AFF_SNEAK);

	setSkillReuseWait(ch,gsn_stealth,PULSE_PER_SECOND * 10);
	cprintf(ch,"Your nimble fingers aren't nimble enough this time, you've been caught!\n\r");
	act("$n just tried to steal something from you!",ch,NULL,victim,TO_VICT);
	act("$n just tried to steal something from $N!",ch,NULL,victim,TO_NOTVICT);

	if ( IS_NPC(victim) )
	{
		act("$N becomes hostile and attacks you!",ch,NULL,victim,TO_CHAR);
		one_hit(victim,ch,TYPE_UNDEFINED);
	}
	else
	{
		cprintf(ch,"Your crime has not gone unnoticed, and you are branded a THIEF!\n\r");
		SET_BIT(ch->act,PLR_THIEF);
		save_char_obj(ch);
	}

	setSkillReuseWait(ch,gsn_pick_pocket,PULSE_PER_SECOND*30);
	return;

}



/*
 * Shopping commands.
 */
Character *find_keeper( Character *ch )
{
    /*char buf[MAX_STRING_LENGTH];*/
    Character *keeper;
    Shop *pShop;

    pShop = NULL;
    for ( keeper = ch->in_room->people; keeper; keeper = keeper->next_in_room )
    {
	if ( IS_NPC(keeper) && (pShop = keeper->pIndexData->pShop) != NULL )
	    break;
    }

    if ( pShop == NULL )
    {
	send_to_char( "You can't do that here.\n\r", ch );
	return NULL;
    }

	if(IS_IMMORTAL(ch))
		return keeper;

    /*
     * Undesirables.
     *
    if ( !IS_NPC(ch) && IS_SET(ch->act, PLR_KILLER) )
    {
	do_function(keeper, &do_say, "Killers are not welcome!");
	sprintf(buf, "%s the KILLER is over here!\n\r", ch->name);
	do_function(keeper, &do_yell, buf );
	return NULL;
    }

    if ( !IS_NPC(ch) && IS_SET(ch->act, PLR_THIEF) )
    {
	do_function(keeper, &do_say, "Thieves are not welcome!");
	sprintf(buf, "%s the THIEF is over here!\n\r", ch->name);
	do_function(keeper, &do_yell, buf );
	return NULL;
    }
	*/
    /*
     * Shop hours.
     */
    if ( time_info.hour < pShop->open_hour )
    {
	do_function(keeper, &do_say, "Sorry, I am closed. Come back later.");
	return NULL;
    }
    
    if ( time_info.hour > pShop->close_hour )
    {
	do_function(keeper, &do_say, "Sorry, I am closed. Come back tomorrow.");
	return NULL;
    }

    /*
     * Invisible or hidden people.
     */
    if ( !can_see( keeper, ch ) )
    {
	do_function(keeper, &do_say, "I don't trade with folks I can't see.");
	return NULL;
    }

    return keeper;
}

/* insert an object at the right spot for the keeper */
void obj_to_keeper( Object *obj, Character *ch )
{
    Object *t_obj, *t_obj_next;

    /* see if any duplicates are found */
    for (t_obj = ch->carrying; t_obj != NULL; t_obj = t_obj_next)
    {
	t_obj_next = t_obj->next_content;

	if (obj->pIndexData == t_obj->pIndexData 
	&&  !str_cmp(obj->short_descr,t_obj->short_descr))
	{
	    /* if this is an unlimited item, destroy the new one */
	    if (IS_OBJ_STAT(t_obj,ITEM_INVENTORY))
	    {
		extract_obj(obj);
		return;
	    }
	    obj->cost = t_obj->cost; /* keep it standard */
	    break;
	}
    }

    if (t_obj == NULL)
    {
	obj->next_content = ch->carrying;
	ch->carrying = obj;
    }
    else
    {
	obj->next_content = t_obj->next_content;
	t_obj->next_content = obj;
    }

    obj->carried_by      = ch;
    obj->in_room         = NULL;
    obj->in_obj          = NULL;
    ch->carry_number    += get_obj_number( obj );
    ch->carry_weight    += get_obj_weight( obj );
}

/* get an object from a shopkeeper's list */
Object *get_obj_keeper( Character *ch, Character *keeper, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Object *obj;
    int number;
    int count;
 
    number = number_argument( argument, arg );
    count  = 0;
    for ( obj = keeper->carrying; obj != NULL; obj = obj->next_content )
    {
        if (obj->wear_loc == WEAR_NONE
        &&  can_see_obj( keeper, obj )
	&&  can_see_obj(ch,obj)
        &&  is_name( arg, obj->name ) )
        {
            if ( ++count == number )
                return obj;
	
	    /* skip other objects of the same name */
	    while (obj->next_content != NULL
	    && obj->pIndexData == obj->next_content->pIndexData
	    && !str_cmp(obj->short_descr,obj->next_content->short_descr))
		obj = obj->next_content;
        }
    }
 
    return NULL;
}

int get_cost( Character *keeper, Object *obj, bool fBuy )
{
    Shop *pShop;
    int cost = 0;

    if ( obj == NULL || ( pShop = keeper->pIndexData->pShop ) == NULL )
		return 0;

    if ( fBuy )
    {
		cost = obj->cost * pShop->profit_buy  / 100;
    }
    else
    {
		Object *obj2;
		int itype;

		for ( itype = 0; itype < MAX_TRADE; itype++ )
		{
	    	if ( obj->item_type == pShop->buy_type[itype] )
	    	{
				cost = obj->cost * pShop->profit_sell / 100;
				break;
	    	}
		}

		if (!IS_OBJ_STAT(obj,ITEM_SELL_EXTRACT))
		{
	    	for ( obj2 = keeper->carrying; obj2; obj2 = obj2->next_content )
	    	{
	    		if ( obj->pIndexData == obj2->pIndexData
				&&   !str_cmp(obj->short_descr,obj2->short_descr) )
				{
	 	    		if (IS_OBJ_STAT(obj2,ITEM_INVENTORY))
					{
						cost /= 2;
					}
		    		else
					{
                   		cost = cost * 3 / 4;
					}
				}
	    	}
    	}
	}

   	if ( obj->item_type == ITEM_STAFF || obj->item_type == ITEM_WAND )
   	{
		if (obj->value[1] == 0)
    		cost /= 4;
		else
    		cost = cost * obj->value[2] / obj->value[1];
   	}

	return cost;
}

int get_stack_cost( Character *keeper, Object *obj, bool fBuy, int quantity )
{
    Shop *pShop;
    int cost = 0;
	bool is_inv = FALSE;

    if ( obj == NULL || ( pShop = keeper->pIndexData->pShop ) == NULL )
		return 0;

    if ( fBuy )
    {
		cost = obj->cost * pShop->profit_buy  / 100;
    }
    else
    {
		Object *obj2;
		int itype;

		for ( itype = 0; itype < MAX_TRADE; itype++ )
		{
	    	if ( obj->item_type == pShop->buy_type[itype] )
	    	{
				cost = obj->cost * pShop->profit_sell / 100;
				break;
	    	}
		}

		if (!IS_OBJ_STAT(obj,ITEM_SELL_EXTRACT))
		{
	    	for ( obj2 = keeper->carrying; obj2; obj2 = obj2->next_content )
	    	{
	    		if ( obj->pIndexData == obj2->pIndexData
				&&   !str_cmp(obj->short_descr,obj2->short_descr) )
				{
	 	    		if (IS_OBJ_STAT(obj2,ITEM_INVENTORY))
					{
						is_inv = TRUE;
						break;
					}
				}
	    	}
    	}
	}

   	if ( obj->item_type == ITEM_STAFF || obj->item_type == ITEM_WAND )
   	{
		if (obj->value[1] == 0)
    		cost /= 4;
		else
    		cost = cost * obj->value[2] / obj->value[1];
   	}

	if(quantity > 1)
	{
		if(fBuy || IS_OBJ_STAT(obj, ITEM_SELL_EXTRACT))
		{
			cost = cost * quantity;
		}
		else
		{
            int stack_cost = cost;

			if(is_inv)
			{
				/* If the merchant stocks the item, it always sell for half */
				stack_cost = (cost/2) * quantity;
			}
			else
			{
				/* If the merchant doesn't stokc the item, there are diminishing returns */
				int item_count;
            	for(item_count = 1; item_count < quantity; item_count++)
            	{
                    stack_cost += cost * pow(3,item_count) / pow(4,item_count);
				}
			}

			return stack_cost;
		}
	}
	
	return cost;
}

void do_buy( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    int cost,roll;

	char obj_name[MAX_STRING_LENGTH];
	char argcopy[MAX_STRING_LENGTH];
	Object *container = NULL;
	Character *npc = NULL;
	int currency, quantity;
	bool all_items = FALSE;
	strcpy(argcopy, argument);
	quantity = mult_argument2(argcopy,ch,obj_name,&container,&npc,&currency,&all_items);

    /*
	log_string("quantity = %d, obj_name = %s",quantity,obj_name);
	log_string("container = %s, npc = %s, currency = %d, all_items = %s",
		container ? container->short_descr : "None",
		npc ? npc->short_descr : "None",
		currency, all_items ? "yes" : "no" );*/

    if ( argument[0] == '\0' )
    {
	    cprintf(ch, "Buy what?\n\r" );
	    return;
    }

    if ( IS_SET(ch->in_room->room_flags, ROOM_PET_SHOP) )
    {
	char arg[MAX_INPUT_LENGTH];
	char buf[MAX_STRING_LENGTH];
	Character *pet;
	Room *pRoomIndexNext;
	Room *in_room;

	smash_tilde(argument);

	if ( IS_NPC(ch) )
	    return;

	argument = one_argument(argument,arg);

	/* hack to make new thalos pets work */
	if (ch->in_room->vnum == 9621)
	    pRoomIndexNext = get_room_index(9706);
	else
	    pRoomIndexNext = get_room_index( ch->in_room->vnum + 1 );
	if ( pRoomIndexNext == NULL )
	{
	    log_bug( "Do_buy: bad pet shop at vnum %d.", ch->in_room->vnum );
	    send_to_char( "Sorry, you can't buy that here.\n\r", ch );
	    return;
	}

	in_room     = ch->in_room;
	ch->in_room = pRoomIndexNext;
	pet         = get_char_room( ch, arg );
	ch->in_room = in_room;

	if ( pet == NULL || !IS_SET(pet->act, ACT_PET) )
	{
	    send_to_char( "Sorry, you can't buy that here.\n\r", ch );
	    return;
	}

	if ( ch->pet != NULL )
	{
	    send_to_char("You already own a pet.\n\r",ch);
	    return;
	}

 	cost = 10 * pet->level * pet->level;

	if ( money_total(ch) < cost )
	{
	    send_to_char( "You can't afford it.\n\r", ch );
	    return;
	}

	if ( ch->level < pet->level )
	{
	    send_to_char(
		"You're not powerful enough to master this pet.\n\r", ch );
	    return;
	}

	/* haggle */
	roll = number_percent();
	if (roll < get_skill(ch,gsn_haggle))
	{
	    cost -= cost / 2 * roll / 100;
	    sprintf(buf,"You haggle the price down to %d coins.\n\r",cost);
	    send_to_char(buf,ch);
	    check_improve(ch,gsn_haggle,TRUE,4);
	
	}

	deduct_cost(ch,cost);
	pet			= create_mobile( pet->pIndexData );
	SET_BIT(pet->act, ACT_PET);
	SET_BIT(pet->affected_by, AFF_CHARM);
	pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;

	argument = one_argument( argument, arg );
	if ( arg[0] != '\0' )
	{
	    sprintf( buf, "%s %s", pet->name, arg );
	    free_string( pet->name );
	    pet->name = str_dup( buf );
	}

	sprintf( buf, "%sA neck tag says 'I belong to %s'.\n\r",
	    pet->description, ch->name );
	free_string( pet->description );
	pet->description = str_dup( buf );

	char_to_room( pet, ch->in_room );
	add_follower( pet, ch );
	pet->leader = ch;
	ch->pet = pet;
	send_to_char( "Enjoy your pet.\n\r", ch );
	act( "$n bought $N as a pet.", ch, NULL, pet, TO_ROOM );
	return;
    }
    else
    {
		Object *obj,*t_obj;
		int count = 1;

		if (!npc)
			return;

		obj  = get_obj_keeper( ch,npc,obj_name );
		cost = get_cost( npc, obj, TRUE );

		if (quantity < 1 || quantity > 99)
		{
	    	act("$n tells you 'That's not possible.'",npc,NULL,ch,TO_VICT);
	    	return;
		}

		if ( cost <= 0 || !can_see_obj( ch, obj ) )
		{
	    	act( "$n tells you 'I don't sell that -- try 'list''.",
				npc, NULL, ch, TO_VICT );
	    	return;
		}

		if (!IS_OBJ_STAT(obj,ITEM_INVENTORY))
		{
	    	for (t_obj = obj->next_content;
	     	 	count < quantity && t_obj != NULL; 
	     	 	t_obj = t_obj->next_content) 
	    	{
	    		if (t_obj->pIndexData == obj->pIndexData
	    		&&  !str_cmp(t_obj->short_descr,obj->short_descr))
		    	count++;
	    		else
		    	break;
	    	}
	
	    	if (count < quantity)
	    	{
	    		act("$n tells you 'I don't have that many in stock.",
		    	npc,NULL,ch,TO_VICT);
	    		return;
	    	}
		}
	
		if ( money_total(ch) < (cost * quantity) )
		{
	    	if (quantity > 1)
			act("$n tells you 'You can't afford to buy that many.",
		    	npc,obj,ch,TO_VICT);
	    	else
	    		act( "$n tells you 'You can't afford to buy $p'.",
		    	npc, obj, ch, TO_VICT );
	    	return;
		}
	
	/*	
		if ( obj->level > (ch->level + (ch->level/10+1)) )
		{
	    	act( "$n tells you 'You can't use $p yet'.",
			npc, obj, ch, TO_VICT );
	    	return;
		}
	*/
	
		if (ch->carry_number +  quantity * get_obj_number(obj) > can_carry_n(ch))
		{
	    	send_to_char( "You can't carry that many items.\n\r", ch );
	    	return;
		}
	
		if ( ch->carry_weight + quantity * get_obj_weight(obj) > can_carry_w(ch))
		{
	    	send_to_char( "You can't carry that much weight.\n\r", ch );
	    	return;
		}
	
		/* haggle */
		roll = number_percent();
		if (!IS_OBJ_STAT(obj,ITEM_SELL_EXTRACT) 
		&& roll < get_skill(ch,gsn_haggle))
		{
	    	cost -= obj->cost / 2 * roll / 100;
	    	act("You haggle with $N.",ch,NULL,npc,TO_CHAR);
	    	check_improve(ch,gsn_haggle,TRUE,4);
		}
	
		if (quantity > 1)
		{
	    	sprintf(buf,"$n buys $p[%d].",quantity);
	    	act(buf,ch,obj,NULL,TO_ROOM);
	    	sprintf(buf,"You buy $p[%d] for %s.",quantity,money_breakdown(cost * quantity));
	    	act(buf,ch,obj,NULL,TO_CHAR);
		}
		else
		{
	    	act( "$n buys $p.", ch, obj, NULL, TO_ROOM );
	    	sprintf(buf,"You buy $p for %s.",money_breakdown(cost));
	    	act( buf, ch, obj, NULL, TO_CHAR );
		}
		deduct_cost(ch,cost * quantity);
		coins_to_merchant(npc,cost*quantity);
		/*keeper->gold += cost * number/100;
		npc->silver += cost * quantity - (cost * quantity/100) * 100;*/
	
		for (count = 0; count < quantity; count++)
		{
	    	if ( IS_SET( obj->extra_flags, ITEM_INVENTORY ) )
			{
	    		t_obj = create_object( obj->pIndexData );
				/* If this is an arcane scroll sold from inventory, 
				 * it cannot be copied. */
				if ( t_obj->item_type == ITEM_ARCANE_SCROLL )
					t_obj->value[1] = TRUE;
			}
	    	else
	    	{
				t_obj = obj;
				obj = obj->next_content;
	    		obj_from_char( t_obj );
	    	}
	
	    	if (t_obj->timer > 0 && !IS_OBJ_STAT(t_obj,ITEM_HAD_TIMER))
	    		t_obj->timer = 0;

	    	REMOVE_BIT(t_obj->extra_flags,ITEM_HAD_TIMER);
			/* All bought items are 100% CON, 100% dur, 85% qua */
		
	    	obj_to_char( t_obj, ch );
	    	if (cost < t_obj->cost)
	    		t_obj->cost = cost;
		}
   	}
}



void do_list( Character *ch, char *argument )
{
   	char buf[MAX_STRING_LENGTH];
	Character *keeper;
	Object *obj;
	int cost,count;
	bool found;
	char arg[MAX_INPUT_LENGTH];

	if ( ( keeper = find_keeper( ch ) ) == NULL )
	    return;

    one_argument(argument,arg);

	found = FALSE;
	for ( obj = keeper->carrying; obj; obj = obj->next_content )
	{
		char obj_name[MAX_STRING_LENGTH];
		obj_name[0] = '\0';

	    if ( obj->wear_loc == WEAR_NONE
	    &&   can_see_obj( ch, obj )
	    &&   ( cost = get_cost( keeper, obj, TRUE ) ) > 0 
	    &&   ( arg[0] == '\0'  
 	       ||  is_name(arg,obj->name) ))
	    {
		if ( !found )
		{
		    found = TRUE;
		    cprintf(ch,"[Lv Qty] [AT] %-40s Price\n\r","Item");
		}

		if (IS_OBJ_STAT(obj,ITEM_INVENTORY))
		{
			if( HAS_COLOROPT(ch, COLOR_OBJ_CON) )
				sprintf(obj_name, "&%c%s&x", get_con_color(ch->level,obj->level), obj->short_descr);
			else
				sprintf(obj_name, "%s", obj->short_descr);

		    sprintf(buf,"[%2d -- ] [%s] %-40s %-s\n\r",
				obj->level,obj->item_type != ITEM_ARMOR ? "--" :
		 			(obj->value[5] < 0 || obj->value[5] >= MAX_ARMOR) ? "??" :
					armor_table[obj->value[5]].abbrev,
				obj_name,money_breakdown(cost));
		}
		else
		{
		    count = 1;

		    while (obj->next_content != NULL 
		    && obj->pIndexData == obj->next_content->pIndexData
		    && !str_cmp(obj->short_descr,
			        obj->next_content->short_descr))
		    {
				obj = obj->next_content;
				count++;
		    }

			if( HAS_COLOROPT( ch, COLOR_OBJ_CON ) )
				sprintf(obj_name, "&%c%s&x", get_con_color(ch->level,obj->level), obj->short_descr);
			else
				sprintf(obj_name, "%s", obj->short_descr);

		    sprintf(buf,"[%2d %2d ] [%s] %-40s %-s\n\r",
				obj->level,count,
                obj->item_type != ITEM_ARMOR ? "--" :
					(obj->value[5] < 0 || obj->value[5] >= MAX_ARMOR) ? "??" :
                    armor_table[obj->value[5]].abbrev,
				obj_name,money_breakdown(cost));
		}
		send_to_char( buf, ch );
	    }
	}

	if ( !found )
	    send_to_char( "You can't buy anything here.\n\r", ch );
	return;
}



void do_sell( Character *ch, char *argument )
{
    Object *obj;
	int quantity_count = 0;

    char obj_name[MAX_INPUT_LENGTH];
	Object *container = NULL;
	Character *npc = NULL;
	int currency, quantity;
	bool all_items = FALSE;
	quantity = mult_argument2(argument,ch,obj_name,&container,&npc,&currency,&all_items);

    if ( !all_items && obj_name[0] == '\0' )
    {
		send_to_char( "Sell what?\n\r", ch );
		return;
    }

	if(!npc)
		return;

	if ( container && check_container(ch, container) )
	{
		if(all_items || quantity > 1)
		{
			Object* obj_next;
			for ( obj = container->contains; obj != NULL; obj = obj_next )
			{
				obj_next = obj->next_content;
				if( (all_items || quantity_count < quantity) 
					&& ((all_items && obj_name[0] == '\0') || is_name(obj_name, obj->name))
					&& can_see_obj(ch, obj))
				{
					quantity_count++;
					sell_obj(ch,obj,npc);
				}
			}

			if(quantity_count == 0)
			{
				act( "$n tells you 'You don't have that item'.",
	    			npc, NULL, ch, TO_VICT );
			}
		}
		else
		{
    		if ( ( obj = get_obj_list( ch, obj_name, container->contains ) ) == NULL )
    		{
				act( "$n tells you 'You don't have that item'.",
	    			npc, NULL, ch, TO_VICT );
				return;
			}
			else
			{
				sell_obj(ch,obj,npc);
			}
		}
	}
	else
	{
		if(all_items || quantity > 1)
		{
			Object* obj_next;
			for( obj = ch->carrying; obj != NULL; obj = obj_next)
			{
				obj_next = obj->next_content;
				//log_string("obj = %s quantity count = %d quantity = %d", obj->short_descr, quantity_count, quantity);
				if( (all_items || quantity_count < quantity) 
					&& ((all_items && obj_name[0] == '\0') || is_name(obj_name, obj->name))
					&& can_see_obj(ch, obj) && obj->wear_loc == WEAR_NONE)
				{
					quantity_count++;
					sell_obj(ch,obj,npc);
				}
			}

			if(quantity_count == 0)
			{
				act( "$n tells you 'You don't have that item'.",
	    			npc, NULL, ch, TO_VICT );
			}
		}
		else
		{
    		if ( ( obj = get_obj_carry( ch, obj_name, ch ) ) == NULL )
    		{
				act( "$n tells you 'You don't have that item'.",
	    			npc, NULL, ch, TO_VICT );
				return;
			}
			else
			{
				sell_obj(ch,obj,npc);
			}
		}
    }

    return;
}

void sell_obj(Character* ch, Object* obj, Character* keeper)
{
	char buf[MAX_STRING_LENGTH];
    int cost, i;

    if ( !can_drop_obj( ch, obj ) )
    {
		cprintf(ch, "You can't let go of %s\n\r", obj->short_descr);
		return;
    }

    if (!can_see_obj(keeper,obj))
    {
		act("$n can't see $p.",keeper,obj,ch,TO_VICT);
		return;
    }

	if ( obj->contains != NULL )
	{
		act("You'll want to empty $p out before you sell it.",ch,obj,NULL,TO_CHAR);
		return;
	}

    if ( ( cost = get_cost( keeper, obj, FALSE ) ) <= 0 )
    {
		act( "$n looks uninterested in $p.", keeper, obj, ch, TO_VICT );
		return;
    }

    if ( cost > money_total(keeper) )
    {
		act("$n tells you 'I'm afraid I don't have enough wealth to buy $p.",
	    	keeper,obj,ch,TO_VICT);
		return;
    }

    act( "$n sells $p.", ch, obj, NULL, TO_ROOM );
    sprintf( buf, "You sell $p for %s.",money_breakdown(cost) );
    act( buf, ch, obj, NULL, TO_CHAR );
    coins_to_merchant(ch,cost);
    deduct_cost(keeper,cost);
	for( i = 0; i < MAX_CURRENCY; i++ )
		keeper->coins[i] = UMAX(keeper->coins[i],0);

    if ( obj->item_type == ITEM_TRASH || IS_OBJ_STAT(obj,ITEM_SELL_EXTRACT))
		extract_obj( obj );
    else
    {
		if(obj->in_obj != NULL)
		{
			log_string("obj in obj");
			obj_from_obj( obj );
		}

		obj_from_char( obj );
		if (obj->timer)
	    	SET_BIT(obj->extra_flags,ITEM_HAD_TIMER);
		else
	    	obj->timer = number_range(50,100);
		obj_to_keeper( obj, keeper );
    }

	check_encumbrance( ch );
}

bool check_container(Character* ch, Object* container)
{
	switch ( container->item_type )
	{
	default:
    	send_to_char( "That's not a container.\n\r", ch );
    	return FALSE;
	
	case ITEM_MOBILE:
	case ITEM_CONTAINER:
	case ITEM_CORPSE_NPC:
	case ITEM_FORGE:
    	break;

	case ITEM_CORPSE_PC:
		if (!can_loot(ch,container))
		{
    		send_to_char( "You can't do that.\n\r", ch );
    		return FALSE;
		}
	}

	if ( container->item_type == ITEM_FORGE )
	{
		Character *vch;

       	for ( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
		{
           	if ( vch != ch && vch->crafting == container )
           	{
               	cprintf(ch,"Somebody else is using that.\n\r");
               	return FALSE;
           	}
		}
	}

	if ( IS_SET(container->value[1], CONT_CLOSED) && container->item_type != ITEM_FORGE )
	{
    	act( "The $d is closed.", ch, NULL, container->name, TO_CHAR );
    	return FALSE;
	}

	return TRUE;
}

void do_value( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    char arg[MAX_INPUT_LENGTH];
    Character *keeper;
    Object *obj;
    int cost;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Value what?\n\r", ch );
	return;
    }

    if ( ( keeper = find_keeper( ch ) ) == NULL )
	return;

    if ( ( obj = get_obj_carry( ch, arg, ch ) ) == NULL )
    {
	act( "$n tells you 'You don't have that item'.",
	    keeper, NULL, ch, TO_VICT );
	return;
    }

    if (!can_see_obj(keeper,obj))
    {
        act("$n doesn't see what you are offering.",keeper,NULL,ch,TO_VICT);
        return;
    }

    if ( !can_drop_obj( ch, obj ) )
    {
	send_to_char( "You can't let go of it.\n\r", ch );
	return;
    }

    if ( ( cost = get_cost( keeper, obj, FALSE ) ) <= 0 )
    {
	act( "$n looks uninterested in $p.", keeper, obj, ch, TO_VICT );
	return;
    }

    sprintf( buf, 
	"$n tells you 'I'll give you %s for $p'.", money_breakdown( cost ) );
    act( buf, keeper, obj, ch, TO_VICT );

    return;
}

void do_destro( Character *ch, char *argument )
{
    cprintf(ch,"The destroy command must be typed out in full.\n\r");
    return;
}

void do_destroy( Character *ch, char *argument )
{
    Object *obj;

    if ( *argument == '\0' )
    {
		cprintf(ch,"Destroy what?\n\r");
		return;
    }

    if ( (obj = get_obj_carry(ch,argument,ch)) == NULL )
    {
		cprintf(ch,"You aren't carrying that.\n\r");
		return;
    }
	if(obj->item_type == ITEM_CONTAINER && obj->contains)
	{
		cprintf(ch, "Empty the container before you junk it.\n\r");
		return;
	}

    obj_from_char( obj );
    act("You junk $p.",ch,obj,NULL,TO_CHAR);
    extract_obj( obj );
    return;
}

void do_consent( Character *ch, char *argument )
{
	char who[MAX_INPUT_LENGTH];
	Character *victim;

	if ( *argument == '\0' )
	{
		cprintf(ch,"Usage:  consent <player_name>\n\r" 
                   "        consent nobody\n\r");
		return;
	}

	if ( (victim = get_char_ooc( ch, who )) == NULL )
	{
		cprintf(ch,"No such player visible.\n\r");
		return;
	}

	if ( IS_NPC(ch) || IS_NPC(victim) )
	{
		cprintf(ch,"NPCs can't do that!\n\r");
		return;
	}

	act("You consent $N to loot your corpse.",ch,NULL,victim,TO_CHAR);
	act("$n consents you to loot $s corpse.",ch,NULL,victim,TO_VICT);
	ch->pcdata->consent = victim->name;
	return;
}

void do_skin( Character *ch, char *argument )
{
	Object *corpse;
	Object *hide;
	char 	arg[MAX_INPUT_LENGTH];
	int		chance, vnum;

	argument = one_argument( argument, arg );
	if ( *argument == '\0' || arg[0] == '\0' )
	{
		cprintf(ch,"Usage:  skin <corpse> <tattered|hide|fine>\n\r");
		return;
	}

	if ( (corpse = get_obj_here( ch, arg )) == NULL )
	{
		cprintf(ch,"You can't find that corpse.\n\r");
		return;
	}

	if ( corpse->item_type != ITEM_CORPSE_NPC )
	{
		cprintf(ch,"That's not an NPC corpse.\n\r");
		return;
	}

	if ( IS_SET(corpse->value[0], CORPSE_SKINNED) )
	{
		cprintf(ch,"That corpse has already been skinned.\n\r");
		return;
	}

	if ( !IS_SET(race_table[corpse->value[2]].form,FORM_HAS_HIDE) )
	{
		cprintf(ch,"That creature doesn't have a useful hide.\n\r");
		return;
	}

	/* Ok we can try to skin it, check what type they're trying for */
	if ( !str_prefix(argument,"tattered") )
	{
		chance = 80;
		vnum = VNUM_TATTERED_HIDE;
	}
	else
	if ( !str_prefix(argument,"hide") )
	{
		chance = 60;
		vnum = VNUM_HIDE;
	}
	else
	if ( !str_prefix(argument,"fine") )
	{
		chance = 40;
		vnum = VNUM_FINE_HIDE;
	}
	else
	{
		cprintf(ch,"Valid hide types are: tattered, hide, fine\n\r");
		return;
	}

	chance += get_skill(ch, gsn_tailoring ) / 5;
	
	if ( number_percent() < chance )
	{
		hide = create_hide( corpse, vnum );
		SET_BIT(corpse->value[0], CORPSE_SKINNED);
		act("You skin $p and get $P.",ch,corpse,hide,TO_CHAR);
		act("$n skins $p and gets $P.",ch,corpse,hide,TO_ROOM);
 		if ( get_skill(ch,gsn_leatherworking) < 50 )
        	checkImproveTradeSkill( ch, gsn_leatherworking, 10, TRUE );
		obj_to_char( hide, ch );
	}
	else
	{
		act("You try to skin $p but are unable to produce anything.",ch,corpse,NULL,TO_CHAR);
		act("$n tries to skin $p but is unable to produce anything.",ch,corpse,NULL,TO_ROOM);
		SET_BIT(corpse->value[0], CORPSE_SKINNED);
	}

	return;
}

void do_reinforce( Character *ch, char *argument )
{
	Object *obj;
	Character *smithy;
	char arg[MAX_INPUT_LENGTH];
	int skill, sn;
	extern int mapArmorSlot( int gpn );

	argument = one_argument( argument, arg );
	if ( arg[0] == '\0' )
	{
		cprintf(ch,"Syntax:  reinforce <object> <smithy>\n\r"
               	   "         reinforce <object>\n\r"
				   "         reinforce <object> value\n\r");
		return;
	}

	if ( (obj = get_obj_carry( ch, arg, ch)) == NULL )
	{
		cprintf(ch,"You're not carrying that.\n\r");
		return;
	}

	if ( obj->durability >= 100 )
	{
		act("$p doesn't need any reinforcement.",ch,obj,NULL,TO_CHAR);
		return;
	}

	if ( IS_SET(obj->extra_flags,ITEM_REINFORCED) )
	{
		act("$p cannot be reinforced any further.",ch,obj,NULL,TO_CHAR);
		return;
	}

	if ( *argument )
	{
		int cost;

		if( !str_prefix(argument, "value"))
		{
			for(smithy = ch->in_room->people; smithy!=NULL; smithy = smithy->next_in_room)
			{
				if(IS_SET(smithy->act,ACT_SMITHY))
					break;
			}
			if(smithy==NULL)
				cprintf(ch, "There is no smithy in the room to value the repair.\n\r");
			cost = obj->level * ( 100 - obj->durability ) * 5;
			actprintf(ch,obj,smithy,TO_CHAR,"$N says 'It'll cost %s to reinforce $p.",money_breakdown(cost) );
			return;
		}

		if ( (smithy = get_char_room( ch, argument )) == NULL )
		{
			cprintf(ch,"You don't see a smithy by that name here.\n\r");
			return;
		}

		if ( !IS_NPC(smithy) || !IS_SET(smithy->act,ACT_SMITHY))
		{
			cprintf(ch,"That person isn't an NPC smithy.\n\r");
			return;
		}

		cost = obj->level * ( 100 - obj->durability ) * 5;
		if ( cost > money_total(ch) )
		{
			actprintf(ch,obj,smithy,TO_CHAR,"$N says 'It'll cost %s to reinforce $p.  You don't have enough.",money_breakdown(cost) );
			return;
		}

        deduct_cost(ch,cost);
        coins_to_merchant(smithy,cost);
		obj->durability = UMIN( 100, obj->durability + dice(2,4) );
		act("$N reinforces $p for you.",ch,obj,smithy,TO_CHAR);
		act("$N reinforces something for $n.",ch,obj,smithy,TO_NOTVICT);
		act("You reinforce $p for $n.",ch,obj,smithy,TO_VICT);
		SET_BIT( obj->extra_flags, ITEM_REINFORCED );
		return;
	}

	/* Player */
	switch( obj->item_type )
	{
		case ITEM_WEAPON:
			sn = gsn_weaponsmithing; break;
		case ITEM_JEWELRY:
			sn = gsn_jewelcraft; break;
		case ITEM_CLOTHING:
			sn = gsn_tailoring; break;
		case ITEM_ARMOR:
			/* cloth, leather, studded are tailoring */
			/* shields are all armorsmithing */
			if ( obj->value[5] == mapArmorSlot( gpn_cloth_armor ) || obj->value[5] == mapArmorSlot( gpn_leather_armor ) ||
			     obj->value[5] == mapArmorSlot( gpn_studded_leather_armor ) )
			{
				sn = gsn_tailoring; break;	
			}
			else
			if ( obj->value[5] == mapArmorSlot( gpn_scale_mail_armor ) || obj->value[5] == mapArmorSlot( gpn_chain_mail_armor ) ||
			     obj->value[5] == mapArmorSlot( gpn_plate_mail_armor ) || obj->value[5] == mapArmorSlot( gpn_small_shields ) ||
			     obj->value[5] == mapArmorSlot( gpn_medium_shields )   || obj->value[5] == mapArmorSlot( gpn_large_shields ) ||
				 obj->value[5] == mapArmorSlot( gpn_buckler_shields ) )
			{
				sn = gsn_armorsmithing; break;
			}
			else
			{
				cprintf(ch,"That piece of armor doesn't seem to have a proper type!\n\r");
				return;
			}
			break;

		default:
			cprintf(ch,"This item is of a type that you aren't sure how to reinforce.\n\r");
			return;
	}

	if ( (skill = get_skill( ch, sn )) < 100 )
	{
		cprintf(ch,"You must have at least a 100 skill in %s to reinforce this object.\n\r", skill_table[sn].name );
		return;
	}

	obj->durability = UMIN(100, obj->durability + dice(2,4) );
	act("You reinforce $p.",ch,obj,NULL,TO_CHAR);
	act("$n reinforce $p.",ch,obj,NULL,TO_ROOM);
	SET_BIT( obj->extra_flags, ITEM_REINFORCED );
	return;
}

void do_repair( Character *ch, char *argument )
{
	Object *obj;
	Character *smithy;
	char arg[MAX_INPUT_LENGTH];
	int skill, sn;
	extern int mapArmorSlot( int gpn );

	argument = one_argument( argument, arg );
	if ( arg[0] == '\0' )
	{
		cprintf(ch,"Syntax:  repair <object> <smithy>\n\r"
               	   "         repair <object>\n\r"
				   "         repair <object> value\n\r");
		return;
	}

	if ( (obj = get_obj_carry( ch, arg, ch)) == NULL )
	{
		cprintf(ch,"You're not carrying that.\n\r");
		return;
	}

	if ( obj->condition >= 100 )
	{
		act("$p doesn't need any repairs.",ch,obj,NULL,TO_CHAR);
		return;
	}

	if ( *argument )
	{
		int cost;

		if( !str_prefix(argument, "value"))
		{
			for(smithy = ch->in_room->people; smithy!=NULL; smithy = smithy->next_in_room)
			{
				if(IS_SET(smithy->act,ACT_SMITHY))
					break;
			}
			if(smithy==NULL)
				cprintf(ch, "There is no smithy in the room to value the repair.\n\r");
			cost = obj->level * ( 100 - obj->durability );
			actprintf(ch,obj,smithy,TO_CHAR,"$N says 'It'll cost %s to repair $p.",money_breakdown(cost) );
			return;
		}

		if ( (smithy = get_char_room( ch, argument )) == NULL )
		{
			cprintf(ch,"You don't see a smithy by that name here.\n\r");
			return;
		}

		if ( !IS_NPC(smithy) || !IS_SET(smithy->act,ACT_SMITHY))
		{
			cprintf(ch,"That person isn't an NPC smithy.\n\r");
			return;
		}

		cost = obj->level * ( 100 - obj->durability );
		if ( cost > money_total(ch) )
		{
			actprintf(ch,obj,smithy,TO_CHAR,"$N says 'It'll cost %s to repair $p.  You don't have enough.",money_breakdown(cost) );
			return;
		}

        deduct_cost(ch,cost);
        coins_to_merchant(smithy,cost);
		obj->durability -= calcDurabilityDrop( obj, smithy->level * 2 );
		obj->condition = 100;
		act("$N repairs $p for you.",ch,obj,smithy,TO_CHAR);
		act("$N repairs something for $n.",ch,obj,smithy,TO_NOTVICT);
		act("You repair $p for $n.",ch,obj,smithy,TO_VICT);
		return;
	}

	/* Player */
	switch( obj->item_type )
	{
		case ITEM_WEAPON:
			sn = gsn_weaponsmithing; break;
		case ITEM_JEWELRY:
			sn = gsn_jewelcraft; break;
		case ITEM_CLOTHING:
			sn = gsn_tailoring; break;
		case ITEM_ARMOR:
			/* cloth, leather, studded are tailoring */
			/* shields are all armorsmithing */
			if ( obj->value[5] == mapArmorSlot( gpn_cloth_armor ) || obj->value[5] == mapArmorSlot( gpn_leather_armor ) ||
			     obj->value[5] == mapArmorSlot( gpn_studded_leather_armor ) )
			{
				sn = gsn_tailoring; break;	
			}
			else
			if ( obj->value[5] == mapArmorSlot( gpn_scale_mail_armor ) || obj->value[5] == mapArmorSlot( gpn_chain_mail_armor ) ||
			     obj->value[5] == mapArmorSlot( gpn_plate_mail_armor ) || obj->value[5] == mapArmorSlot( gpn_small_shields ) ||
			     obj->value[5] == mapArmorSlot( gpn_medium_shields )   || obj->value[5] == mapArmorSlot( gpn_large_shields ) ||
				 obj->value[5] == mapArmorSlot( gpn_buckler_shields ) )
			{
				sn = gsn_armorsmithing; break;
			}
			else
			{
				cprintf(ch,"That piece of armor doesn't seem to have a proper type!\n\r");
				return;
			}
			break;

		default:
			cprintf(ch,"This item is of a type that you aren't sure how to repair.\n\r");
			return;
	}

	if ( (skill = get_skill( ch, sn )) < 100 )
	{
		cprintf(ch,"You must have at least a 100 skill in %s to repair this object.\n\r", skill_table[sn].name );
		return;
	}

	obj->durability -= calcDurabilityDrop( obj, skill );
	obj->condition = 100;
	act("You repair $p.",ch,obj,NULL,TO_CHAR);
	act("$n repairs $p.",ch,obj,NULL,TO_ROOM);
	return;
}

// use woodworking skill
void do_cut( Character *ch, char *argument )
{
	int delay;
	char arg[MAX_INPUT_LENGTH];
	Object *obj=NULL, *axe;
	Resource *rsc;
	int i, vnum, amount, max, n;

	switch( ch->in_room->sector_type )
	{
		case SECT_FOREST: 
			break;
		default:
			cprintf(ch,"You can only cut trees down in the forest.\n\r");
			return;
	}

    if ( (n=REUSE_SKILL(ch,gsn_woodworking)) )
    {
        cprintf(ch,"You won't be prepared to cut again for %d more seconds.\n\r",n/PULSE_PER_SECOND);
        return;
    }

	one_argument( argument, arg );
	
	if ( arg[0] == '\0' )	
	{
		cprintf(ch,"Syntax:         cut <wood_type>\n\r"
                   "Valid types:    wood\n\r");
		return;
	}

	if ( (vnum=flag_value( resource_flags, arg)) == NO_FLAG )
	{
		cprintf(ch,"That's not a valid wood.\n\r");
		return;
	}

	// Must have an axe wielded
	if ( (axe = get_eq_char(ch,WEAR_WIELD)) == NULL ||
	     *weapon_table[get_weapon_index(axe->value[0])].gsn != gsn_axe )
	{
		cprintf(ch,"You must be wielding an axe to cut!\n\r");
		return;
	}

	// Now see if this room even has any
	for( rsc = ch->in_room->resources; rsc != NULL ; rsc = rsc->next )
	{
		if ( rsc->resource == vnum )
			break;
	}

	if ( ch->stamina < 1 )
	{
		cprintf(ch,"You're too exhausted.\n\r");
		return;
	}

	if ( rsc == NULL || rsc->amount < 1 )
	{
		cprintf(ch,"You fail to locate any %s here.\n\r",
			flag_string( resource_flags, vnum ) );
		setSkillReuseWait(ch,gsn_woodworking,PULSE_PER_SECOND*4);
		return;
	}

	if ( get_skill(ch,gsn_woodworking) < 50 )
		checkImproveTradeSkill( ch, gsn_woodworking, 10, TRUE );

	// Found some!
	max = ( 500 + get_skill(ch,gsn_woodworking) ) * rsc->amount / 1000;
	amount = number_range(1,max);
	amount = UMIN( ch->stamina, amount );
	rsc->amount -= amount;
	ch->stamina -= amount;

	for( i=0 ; i < amount ; i++ )
		if ( (obj = create_object(get_obj_index(vnum))) != NULL )
			obj_to_room( obj, ch->in_room );

	if ( obj != NULL )
		cprintf(ch,"Success!  You cut:  (%d) %s\n\r", 
										amount, obj->short_descr );

	delay = (12*PULSE_PER_SECOND) - ( get_skill(ch,gsn_woodworking) / 5 );
	setSkillReuseWait(ch,gsn_woodworking,delay);
	return;
}

void do_mine( Character *ch, char *argument )
{
	int delay, skill_sn;
	char arg[MAX_INPUT_LENGTH];
	Object *obj=NULL, *pick;
	Resource *rsc;
	int i, vnum, amount, max, n;

	switch( ch->in_room->sector_type )
	{
		case SECT_MOUNTAIN:
		case SECT_UNDERGROUND: 
        case SECT_HILLS:
			break;
		default:
			cprintf(ch,"You can only mine in mountains, hills or subterranean sectors.\n\r");
			return;
	}

	one_argument( argument, arg );
	
	if ( arg[0] == '\0' )	
	{
		cprintf(ch,"Syntax:         mine <mineral>\n\r"
                   "Valid minerals: arsenic antimony copper\n\r"
                   "                iron limestone coal tin\n\r"
                   "                stone\n\r");
		return;
	}

	if ( (vnum=flag_value( resource_flags, arg)) == NO_FLAG )
	{
		cprintf(ch,"That's not a valid mineral.\n\r");
		return;
	}

	switch( vnum )
	{
		case NR_STONE:
		case NR_LIMESTONE:
		case NR_COAL:
			skill_sn = gsn_stoneworking; break;

		case NR_ARSENIC:
		case NR_ANTIMONY:
		case NR_COPPER:
		case NR_IRON:
		case NR_TIN:
			skill_sn = gsn_metalworking; break;

		default:
			skill_sn = gsn_mining; break;
	}
	
    if ( (n=REUSE_SKILL(ch,skill_sn)) )
    {       
        cprintf(ch,"You won't be prepared to mine again for %d more seconds.\n\r",n/PULSE_PER_SECOND);
        return;
    }
		
	// Must have a pickaxe wielded
	if ( (pick = get_eq_char(ch,WEAR_WIELD)) == NULL ||
		 pick->value[0] != WEAPON_PICK )
	{
		cprintf(ch,"You must be wielding a pickaxe to mine!\n\r");
		return;
	}

	// Now see if this room even has any
	for( rsc = ch->in_room->resources; rsc != NULL ; rsc = rsc->next )
	{
		if ( rsc->resource == vnum )
			break;
	}

    if ( ch->stamina < 1 )
    {
        cprintf(ch,"You're too exhausted.\n\r");
        return;
    }

	if ( rsc == NULL || rsc->amount < 1 )
	{
		cprintf(ch,"You fail to locate any %s here.\n\r",
			flag_string( resource_flags, vnum ) );
		setSkillReuseWait(ch,skill_sn,PULSE_PER_SECOND*4);
		return;
	}

	if ( get_skill(ch,skill_sn) < 50 )
		checkImproveTradeSkill( ch, skill_sn, 10, TRUE );

	// Found some!
	max = ( 500 + get_skill(ch,skill_sn) ) * rsc->amount / 1000;
	amount = number_range(1,max);
	amount = UMIN( ch->stamina, amount );
	rsc->amount -= amount;
	ch->stamina -= amount;

	for( i=0 ; i < amount ; i++ )
		if ( (obj = create_object(get_obj_index(vnum))) != NULL )
			obj_to_room( obj, ch->in_room );

	if ( obj != NULL )
		cprintf(ch,"Success!  You mined:  (%d) %s\n\r", amount, obj->short_descr );

	delay = (12*PULSE_PER_SECOND) - ( get_skill(ch,skill_sn) / 5 );
	setSkillReuseWait(ch,skill_sn,delay);
	return;
}
