/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include <sys/types.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "thoc.h"
#include "tables.h"
#include "lookup.h"
#include "recycle.h"
#include "olc.h"

void copyScriptIndexIndex( ScriptIndex *dest, ScriptIndex *source );

SEDIT( sedit_show )
{
    ScriptIndex *script;

    EDIT_SCRIPT(ch, script);

	cprintf(ch," == Script #%d : %s ==\n\r",
		script->vnum, script->name ? script->name : "a script" );

	cprintf(ch,"Name:               [%s]\n\r", 
			script->name ? script->name : "a script" );
	cprintf(ch,"Priority:           [%d]\n\r", script->priority );
	cprintf(ch,"Trigger:            [%s]\n\r",
		flag_string( trigger_flags, script->trigger ) );
	cprintf(ch, "Direct Object:     [%s]\n\r",
		script->direct_object );

	cprintf(ch,"Script Contents:\n\r");
	if ( script->script == NULL )
		cprintf(ch,"    Not defined yet.\n\r");
	else
		cprintf(ch,script->script);

    return FALSE;
}

SEDIT( sedit_create )
{
    ScriptIndex *script, *copy_source;
    Area *pArea;
    int  value;
    int  iHash;
	char arg[MAX_INPUT_LENGTH];

	argument = one_argument( argument, arg );
    value = atoi( arg );

    if ( arg[0] == '\0' || value == 0 )
    {
		send_to_char( "Syntax:  sedit create [vnum]\n\r", ch );
		return FALSE;
    }

    pArea = get_vnum_area( value );

    if ( !pArea )
    {
		send_to_char( "SEdit:  That vnum is not assigned an area.\n\r", ch );
		return FALSE;
    }

    if ( !IS_BUILDER( ch, pArea ) )
    {
		send_to_char( "SEdit:  Vnum in an area you cannot build in.\n\r", ch );
		return FALSE;
    }

    if ( get_script_index( value ) )
    {
		send_to_char( "SEdit:  Script vnum already exists.\n\r", ch );
		return FALSE;
    }

    script					= new_script_index();
    script->vnum			= value;
    script->area			= pArea;
        
    if ( value > top_vnum_script )
		top_vnum_script = value;        

    iHash					= value % MAX_KEY_HASH;
    script->next			= script_index_hash[iHash];
    script_index_hash[iHash]	= script;
    ch->desc->pEdit		= (void *)script;

    cprintf( ch, "Script Created.\n\r" );

	if ( *argument == NULL )
    	return TRUE;

	/* Copy? */
	argument = one_argument( argument, arg );
	if ( str_cmp(arg,"from") )
	{
		cprintf(ch,"Invalid copy syntax.  Ignoring.\n\r");
		return TRUE;
	}

	value = atoi( argument );
	if ( value <= 0 )
	{
		cprintf(ch,"Malformed copy, ignoring.\n\r");
		return TRUE;
	}

	if ( (copy_source = get_script_index( value )) == NULL )
	{
		cprintf(ch,"No such Script with vnum %d, copy ignored.\n\r", value );
		return TRUE;
	}

	copyScriptIndexIndex( script, copy_source );
	cprintf(ch,"Script %d copied to %d.\n\r",
		value, script->vnum );
	return TRUE;
}

SEDIT( sedit_name )
{
    ScriptIndex *script;

    EDIT_SCRIPT(ch, script);

    if ( argument[0] == '\0' )
    {
    	send_to_char( "Syntax:  name [string]\n\r", ch );
    	return FALSE;   
    }

    free_string( script->name );
    script->name = str_dup( argument );

    cprintf(ch,"Script name set to '%s'.\n\r", script->name );
    return TRUE;
}

SEDIT( sedit_priority )
{
    ScriptIndex *script;

    EDIT_SCRIPT(ch, script);

    if ( argument[0] == '\0' || !is_number( argument ) )
    {
    	send_to_char( "Syntax:  priority [number]\n\r", ch );
    	return FALSE;
    }

    script->priority = atoi( argument );

	cprintf(ch,"Priority set to %d.\n\r", script->priority );
    return TRUE;
}


void copyScriptIndexIndex( ScriptIndex *dest, ScriptIndex *source )
{

}

SEDIT( sedit_trigger )
{
	ScriptIndex *script;
    int value;

    if ( argument[0] != '\0' )
    {
    	EDIT_SCRIPT( ch, script );

    	if ( ( value = flag_value( trigger_flags, argument ) ) != NO_FLAG )
    	{
			TOGGLE_BIT( script->trigger, value );
        	cprintf( ch, "Trigger set to [%s].\n\r",
						flag_string(trigger_flags, script->trigger ) );
        	return TRUE;
    	}
    }

    cprintf( ch, "Syntax: trigger [flag]\n\r"     
                 "Type '? trigger' for a list of triggers.\n\r" );
    return FALSE;
}

SEDIT( sedit_edit )      
{
	ScriptIndex *script;

    EDIT_SCRIPT(ch, script);    

    if ( argument[0] == '\0' )
    {
    	string_append( ch, &script->script );
    	return TRUE;
    }

    cprintf( ch, "Syntax:  edit\n\r" );
    return FALSE;
}

SEDIT( sedit_direct_object )
{
    ScriptIndex *script;

    EDIT_SCRIPT(ch, script);

    if ( argument[0] == '\0' )
    {
        send_to_char( "Syntax:  direct [string]\n\r", ch );   
        return FALSE;
    }

    free_string( script->direct_object );
    script->direct_object = str_dup( argument );

    cprintf(ch,"Script direct object set to '%s'.\n\r", script->direct_object );
    return TRUE;
}
