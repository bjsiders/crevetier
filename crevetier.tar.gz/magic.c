/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

/***************************************************************************
*    ROM 2.4 is copyright 1993-1998 Russ Taylor               *
*    ROM has been brought to you by the ROM consortium           *
*        Russ Taylor (rtaylor@hypercube.org)                   *
*        Gabrielle Taylor (gtaylor@hypercube.org)               *
*        Brian Moore (zump@rom.org)                       *
*    By using this code, you have agreed to follow the terms of the       *
*    ROM license, in the file Rom24/doc/rom.license               *
***************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "tables.h"
#include "recycle.h"
#include "options.h"

#define PROC_NORMAL        1
#define PROC_VENOMS        2

/* imported functions */
void cast_spell( Character *ch, char *argument, long flags );
bool remove_obj( Character *ch, int iWear, bool fReplace );
void wear_obj  ( Character *ch, Object *obj, bool fReplace );
int  find_door ( Character *ch, char *argument );

bool    fProc         = FALSE;
int     spell_level       ( Character *ch, int sn );
bool    handle_mana_cost  ( Character *ch, int mana );
bool    handle_components ( Character *ch, int sn );

/* Called by check_saves_spell with spell sn included */

/* THis function is called by the check_saves_spell macro which
 * takes the first four arguments and fills in the third from
 * the spell function.
 */
bool _saves_spell( Character *ch, Character *victim, long dt, int save_type, int sn )
{
	SpellIndex* pSpellIndex;

	if( (pSpellIndex = get_spell_index(sn)) != NULL)
	{
		return handle_saves_spell(ch,victim,dt,save_type,get_skill(ch,*(pSpellIndex->sgsn)));
	}
	else
	{
		log_bug("_saves_spell: Spell index not found(%d)",sn);
		return TRUE;
	}
}

int spell_skill( int spell_sn )
{
	SpellIndex* pSpellIndex;

    /* Given a spell sn, find the skill it uses */
	if( (pSpellIndex = get_spell_index(spell_sn)) != NULL)
	{
		if ( pSpellIndex->sgsn == NULL )
			return 0;
		else
			return  *(pSpellIndex->sgsn);
	}
	else
	{
		log_bug("spell_skill: Spell index not found(%d)",spell_sn);
		return 0;
	}
}

Affect *get_affect_by_number( Character *ch, int num )
{
    Affect *paf, *paf_last = NULL;
    int count = 1;

    if ( ch->affected == NULL || num < 1 )
        return NULL;

    for ( paf = ch->affected; paf != NULL; paf = paf->next )
    {
        if (paf_last != NULL && paf->type != paf_last->type)
            ++count;

        if ( count == num )
            return paf;

        paf_last = paf;
    }

    return NULL;
}

void do_cancel( Character *ch, char *argument )
{
    Affect *paf;
    char arg[MAX_INPUT_LENGTH];
    int num;
	SpellIndex* pSpellIndex;

    one_argument( argument, arg );
    if ( arg[0] == '\0' || !is_number(arg) )
    {
        cprintf(ch,"Syntax:  cancel <affect#>\n\r");
        return;
    }

    num = atoi(arg);

    if ( (paf = get_affect_by_number( ch, num )) == NULL )
    {
          cprintf(ch,"You don't have that many affects.\n\r");
          return;
    }

	if( (pSpellIndex = get_spell_index(paf->type)) != NULL)
	{
		if ( pSpellIndex->target == TAR_CHAR_OFFENSIVE )
		{
    		cprintf(ch,"You cannot cancel debilitive spell affects.\n\r");
    		return;
		}

		affect_strip( ch, paf->type );
		cprintf(ch,"%s\n\r", pSpellIndex->msg_off);
	}
	else
	{
		log_bug("do_cancel: Spell index not found(%d)",paf->type);
		return;
	}

    return;
}

/**  DAMAGE OVER TIME ENGINE  **/
void heal_dot( Character *victim, Character *ch, Affect *paf )
{
    int heal;

    heal = number_range( abs(paf->modifier), abs(paf->location) );

    if ( ch != NULL &&  ch->in_room != victim->in_room )
        heal /= 2;

    if ( victim->fighting != NULL )
        heal /= 2;

    victim->stat_hit = UMIN(victim->stat_hit+heal,max_stat_hit(victim));

    paf->level--;
    if ( --paf->duration < 0 )
    {
		SpellIndex* pSpellIndex;

		if( (pSpellIndex = get_spell_index(paf->type)) != NULL)
		{
			send_to_char(pSpellIndex->msg_off,victim);
       		send_to_char("\n\r",victim);
       		affect_remove(victim,paf);
		}
		else
		{
			log_bug("heal_dot: Spell index not found(%d)",paf->type);
			return;
		}
    }

    return;
}

void pulse_spell( Character *ch, Affect *paf )
{
    Character *caster;

    if ( ch == NULL || paf == NULL )
        return;

    caster = NULL;

    if ( paf->caster_id <= 0 || (caster = get_char_by_id( paf->caster_id )) == NULL )
        return;

    if ( caster->in_room == ch->in_room && is_same_group(caster,ch) && caster->playing == paf->type )
    {
        paf->duration = seconds(12);
        return;
    }

    /* Let it decay */
}

void dot( Character *ch, Affect *paf )
{
    int dam;
    Character *caster;

    if ( ch == NULL || paf == NULL )
        return;

    caster = NULL;

    if ( paf->location < 0 || paf->modifier < 0 )
    {
        heal_dot(ch,caster,paf);
        return;
    }

    if ( paf->caster_id > 0 )
        caster = get_char_by_id( paf->caster_id );

    /* The fields in Affect for DOT spells are different.
     *
     * af.where = DAMAGE_OVER_TIME
     * af.duration = duration in seconds
     * af.location = Minimum damage
     * af.modifier = Maximum damage
     * af.bitvector = damage type
     */

     dam = number_range(paf->modifier,paf->location);

    if ( caster == NULL )
    {
        caster = ch;
        dam /= 2;
    }
    else
    {
        /* if we know the caster, see if they're in the room with ch */
        /* Damage cut in half if caster isn't in same room */
        if( caster->in_room != ch->in_room || caster == ch )
            dam /= 2;//Dots on yourself, or from someone you killed, will also do 1/2 damage.
    }

    if( caster != ch )
         damage(caster,ch,dam,paf->type,paf->bitvector,DF_SHOW|DF_DOT|DF_SPELL);
    else
        damage(ch,ch,dam,paf->type,paf->bitvector,DF_DOT|DF_SPELL);

    if ( ch == NULL )
        return;

    return;
}

bool handle_components( Character *ch, int sn )
{
    /* Verbal components */
	SpellIndex* pSpellIndex;

	if( (pSpellIndex = get_spell_index(sn)) != NULL)
	{
		if (IS_SET(pSpellIndex->flags,COM_VER))
		{
			char buf[MAX_STRING_LENGTH];
			sprintf(buf,"$n %ss '&Y%s&x.'",class_table[ch->class].group == ARCANE ? "incant" : "sing", pSpellIndex->incantation);
			act(buf,ch,NULL,NULL,TO_ROOM);
			sprintf(buf,"You %s '&Y%s&x.'",class_table[ch->class].group == ARCANE ? "incant" : "sing",pSpellIndex->incantation);
			act(buf,ch,NULL,NULL,TO_CHAR);

            if(class_table[ch->class].group != ARCANE)
			    act("You hear the sound of haunting melodies from $D.",ch,NULL,NULL,TO_RADIUS);
            else
			    act("You hear the sound of arcane chanting from $D.",ch,NULL,NULL,TO_RADIUS);
		}
	}
	else
	{
		log_bug("handle_components: Spell index not found(%d)",sn);
	}

    return TRUE;
}


/*
 * Handle mana cost of spells
 */
bool handle_mana_cost( Character *ch, int mana )
{
    if ( ch->mana < 1 )
    {
        send_to_char("You don't have enough mana.\n\r",ch);
        return FALSE;
    }

    if ( ch->mana >= mana )
    {
        ch->mana -= mana;
        return TRUE;
    }

    if ( ch->mana < mana &&
        (ch->stat_hit - abs( ch->mana - mana )) > 0 )
    {
        ch->mana -= mana;
        ch->stat_hit -= abs(ch->mana);
        ch->mana = 0;
                return TRUE;
        }

        send_to_char("You don't have enough mana.\n\r",ch);
        return FALSE;
}

/* 1 = divine only
 * 0 = arcane only
 * -1 = any
 */
int spell_lookup( const char *name, bool fDivine )
{
    int vnum, nMatch = 0;
	SpellIndex* pSpellIndex;

    for ( vnum = 0; nMatch < top_spell_index; vnum++ )
	{
		if ( ( pSpellIndex = get_spell_index( vnum ) ) != NULL )
		{
			nMatch++;
			
	        if ( fDivine == 1 && !IS_SET(pSpellIndex->flags,COM_DIVINE) )
		        continue;
			else
			if ( fDivine == 0 && !IS_SET(pSpellIndex->flags,COM_ARCANE) )
				continue;

			if ( LOWER(name[0]) == LOWER(pSpellIndex->name[0])
				&&   !str_prefix( name, pSpellIndex->name ) )
				return pSpellIndex->vnum;
		}
	}

    return -1;
}

/*
 * Lookup a skill by name.
 */
int skill_lookup( const char *name )
{
    int sn;

    for ( sn = 0; sn < MAX_SKILL; sn++ )
    {
    if ( skill_table[sn].name == NULL )
        break;
    if ( LOWER(name[0]) == LOWER(skill_table[sn].name[0])
    &&   !str_prefix( name, skill_table[sn].name ) )
        return sn;
    }

    return -1;
}

/*
 * Compute a saving throw.
 */
bool handle_saves_spell( Character *ch, Character *victim, int dam_type, int save_type, int attackBonus )
{
    int land = 50;
    int stat;
    int skill;
    extern    bool fProc;

    if ( class_table[ch->class].group == ARCANE )
    {
        skill = get_skill( ch, gsn_thaumaturgy );
        stat = STAT_INT;
    }
    else
    if ( class_table[ch->class].group == DIVINE )
    {
        skill = get_skill( ch, gsn_theology );
        stat = STAT_WIS;
    }
    else
    if ( !str_cmp(class_table[ch->class].name,"bard") ||
         !str_cmp(class_table[ch->class].name,"paladin") )
    {
        skill = ch->level;
        stat = STAT_CHA;
    }
    else /* For procs, use int for stat, and level for skill */
    {    
        if ( !fProc && !IS_NPC(ch) )
            log_bug("Unknown spellcaster class %s",class_table[ch->class].name);
        skill = ch->level; /*get_skill( ch, gsn_theology );*/
        stat = STAT_INT;
    }

    /* Check for procs */
    switch( fProc )
    {
        case PROC_NORMAL: stat = STAT_INT; skill = ch->level; break;
        case PROC_VENOMS: stat = STAT_DEX; skill = ch->level; break;
    }

    if ( IS_SET(ch->display,DISP_SAVES_DEBUG))
        cprintf(ch," [Saves] Using %s as main stat\n", statnames[stat] );

    /* Victim's should fail more often than save */
    applySkillAdjust( &land, 50,skill, ch->level );

    if ( IS_SET(ch->display,DISP_SAVES_DEBUG))
        cprintf(ch," [Saves] Base %d chance to land spell\n", land );

    land -= calc_save(victim,save_type);
    if ( IS_SET(ch->display,DISP_SAVES_DEBUG))
        cprintf(ch," [Saves] Land = %d (victim has %d saving throw)\n",
            land, calc_save(victim,save_type) );

    land -= get_saves_bonus(victim,dam_type);
    if ( IS_SET(ch->display,DISP_SAVES_DEBUG))
        cprintf(ch," [Saves] Land = %d (victim has %d resists)\n",
            land, get_saves_bonus(victim,dam_type) );

    land += attackBonus;
    if ( IS_SET(ch->display,DISP_SAVES_DEBUG))
        cprintf(ch," [Saves] Land = %d (land bonus %d)\n",
            land, attackBonus );

    land += applyLevelDifference(ch->level,victim->level);
    if ( IS_SET(ch->display,DISP_SAVES_DEBUG))
        cprintf(ch," [Saves] Land = %d (level difference %d)\n",
            land, applyLevelDifference(ch->level,victim->level) );
    land += apply_stat(ch,stat);

    if( IS_SET(ch->display,DISP_SAVES_DEBUG))
        cprintf(ch, "[Saves] Land = %d (apply stat %d)\n",
            land, apply_stat(ch,stat) );

    if ( check_immune(victim,dam_type) )
        return TRUE;

    if ( IS_SET(ch->display,DISP_SAVES_DEBUG))
        cprintf(ch," [Saves] Final chance to land spell: %d\n", land );
    return( number_percent() > land );
}

bool saves_spell( int level, Character *victim, int dam_type )
{
    return ( number_percent( ) < 50 );
}

/* co-routine for dispel magic and cancellation */
bool check_cancel( int level, Affect *af )
{
    int attackRoll, defendRoll;

    attackRoll = level + number_percent( );
    defendRoll = af->level + number_percent( );

    return ( attackRoll > defendRoll );
}

/*
 * The kludgy global is for spells who want more stuff from command line.
 */
char *target_name;

void do_cast( Character *ch, char *argument )
{
    cast_spell( ch, argument, 0 );
}

void do_silentcast( Character *ch, char *argument )
{
    int n;

    if ( IS_NPC(ch) )
    {
        cprintf(ch,"NPCs cannot silentcast.\n\r");
        return;
    }

    if( !ch->pcdata->profs[ gpn_silent_casting ] )
    {
        cprintf(ch,"You do not have this ability.\n\r");
        return;
    }

    if ( (n=REUSE_SKILL(ch,gpn_silent_casting)) )
    {
        cprintf(ch,"You cannot silent cast for %d more seconds.\n\r",n/PULSE_PER_SECOND);
        return;
    }

    cast_spell( ch, argument, SILENTCAST );
}

void do_quickcast( Character *ch, char *argument )
{
    int n;

    if ( IS_NPC(ch) )
    {
        cprintf(ch,"NPCs cannot quickcast.\n\r");
        return;
    }

    if( !HAS_PROF(ch,proficiency_lookup("quick cast")) )
    {
        cprintf(ch,"You do not have this ability.\n\r");
        return;
    }

    if ( (n=REUSE_SKILL(ch,gsn_quick_cast)) )
    {
        cprintf(ch,"You cannot quick cast for %d more seconds.\n\r",n/PULSE_PER_SECOND);
        return;
    }

    cast_spell( ch, argument, QUICKCAST );
    
}

void cast_spell( Character *ch, char *argument, long flags )
{
    char arg1[MAX_INPUT_LENGTH];
    char arg2[MAX_INPUT_LENGTH];
    Character *victim;
    Object *obj;
    Object *book;
    int level, dir, range, misc=0;
    void *vo;
    int mana, sn, target, fDivine, fBard = FALSE, fSkip, n;
    bool fQuick = IS_SET(flags,QUICKCAST) ? TRUE : FALSE;
    bool fPaladin = FALSE;
	SpellIndex* pSpellIndex;
    char *fourth_arg;

    fSkip = IS_IMMORTAL(ch);

    /*
     * Switched NPC's can cast spells, but others can't.
     */
    if ( IS_NPC(ch) && ch->desc == NULL)
        return;

    fDivine = FALSE;

    switch( class_table[ch->class].group )
    {
        case MELEE:
            fPaladin = TRUE; break;
        case STEALTH:
            fBard = TRUE;
        case ARCANE:
            break;
        case DIVINE:
            fDivine = TRUE;
            break;
    }

    if ( !str_cmp(class_table[ch->class].name,"paladin") )
        fDivine = TRUE;

    target_name = one_argument( argument, arg1 );
    fourth_arg = one_argument( target_name, arg2 );

    if ( arg1[0] == '\0' )
    {
        cprintf(ch, "Cast what?\n\r" );
        return;
    }

	/* Check for a slotmapping */
	if ( is_number( arg1 ) )
	{
		int index;

		index = atoi(arg1);
		if ( index < 1 || index > MAX_SPELL_SLOT )
		{
			cprintf(ch,"You must give a slot# between 1 and %d.\n\r",MAX_SPELL_SLOT);
			return;
		}
	
		--index;
		if ( ch->pcdata->spell_slots[index] < 1 )
		{
			cprintf(ch,"You have nothing mapped to that slot.\n\r");
			return;
		}
		sn = ch->pcdata->spell_slots[index];
	}
	else
    if ( !fSkip && (sn=spell_lookup( arg1, -1 )) < 0 )
    {
           cprintf(ch,"No such spell exists.\n\r");
           return;
    }
    else
    if ( (sn = spell_lookup( arg1, fDivine ) ) < 0 )
    {
        cprintf(ch,"No such spell exists.\n\r");
        return;
    }

	if( (pSpellIndex = get_spell_index( sn )) == NULL )
	{
		log_bug("cast_spell: Spell index not found(%d)",sn);
		return;
	}

    if ( !fSkip )
    {
        int main_sn;
        int skill_sn;

        /* For Arcane casters, check spellbooks */
        if ( !fDivine && !fBard )
        {
            if ( ( book = get_eq_char(ch,WEAR_HOLD) ) == NULL ||
                  book->item_type != ITEM_SPELLBOOK )
            {
                send_to_char("You aren't holding your spellbook.\n\r",ch);
                return;
            }
    
            if ( !spell_is_in_book( sn, book ) ) 
            {
                send_to_char("That spell isn't in your spellbook.\n\r",ch);
                return;
            }

            if ( ch->pcdata->spells[sn] < 1 )
            {
                cprintf(ch,"You don't have spell committed to memory.\n\r");
                return;
            }
        }
        else
        {
            if ( ch->pcdata->spells[sn] < 1 )
            {
                cprintf(ch,"You don't know any such spell.\n\r");
                return;
            }
        }

        /* Make sure they have the skill! */
        if ( get_skill(ch, (skill_sn = spell_skill( sn )) ) < pSpellIndex->class_level[ch->class] )
        {
            cprintf(ch,"You must be at least level %d in %s to cast this spell.\n\r",
                pSpellIndex->class_level[ch->class], skill_table[skill_sn].name );
            return;
        }

        if ( !fBard && !fPaladin ) 
        {
            main_sn = fDivine ? gsn_theology : gsn_thaumaturgy;
            if ( (get_skill(ch, main_sn)) < pSpellIndex->class_level[ch->class] )
            {
                cprintf(ch,"Your %s skill must be at least level %d to cast this spell.\n\r",
                    skill_table[main_sn].name, pSpellIndex->class_level[ch->class] );
                return;
            }
        }
        else if ( fBard && skill_sn != gsn_vocal ) /* check for instrument */
        {
            Object *inst;

            if ( (inst = get_eq_char( ch, WEAR_INSTRUMENT)) == NULL )
            {
                cprintf(ch,"You must have the proper instrument type for this spell!\n");
                return;
            }

            /* Wow is this ugly or what */
            if( ( skill_sn == gsn_strings && inst->value[0] != INSTR_STRINGS ) ||
                ( skill_sn == gsn_percussion && inst->value[0] != INSTR_PERCUSSION ) ||
                ( skill_sn == gsn_winds && inst->value[0] != INSTR_WINDS ) )
            {
                cprintf(ch,"You don't have the right type of instrument equipped.\n\r");
                return;
            }
        }
    }


    if ( (n = REUSE_LINE(ch,sn)) && pSpellIndex->series > 0 && !IS_IMMORTAL(ch) )
    {
        cprintf(ch,"You cannot cast this spell again for %d seconds.\n\r",n/PULSE_PER_SECOND);
        return;
    }

    mana = pSpellIndex->base_mana;
    if ( fQuick ) 
        mana  = 3 * mana / 2;

    /*
     * Locate targets.
     */
    victim    = NULL;
    obj        = NULL;
    vo        = NULL;
    target    = TARGET_NONE;
      
    switch ( pSpellIndex->target )
    {
        default:
            log_bug( "cast_spell: bad target for sn %d.", sn );
            return;

        case TAR_IGNORE:
            break;

        case TAR_RANGED:
            if ( arg2[0] == '\0' )
            {
                actprintf(ch,NULL,NULL,TO_CHAR,"Usage:  cast '%s' <direction> <target>", pSpellIndex->name );
                return;
            }

            /* have weapon, find victim */
            switch( arg2[0] )
            {
                case 'n': case 'N': dir = DIR_NORTH;    break;
                case 'e': case 'E': dir = DIR_EAST;     break;
                case 'w': case 'W': dir = DIR_WEST;     break;
                case 's': case 'S': dir = DIR_SOUTH;    break;
                default:
                    cprintf(ch,"You can only cast to the north, south, east, and west.\n\r");
                    return;
            }
    
            range = pSpellIndex->action.generic.range;
            if ( range < 1 || range > 5 )
            {
                act("This spell has an invalid range.",ch,NULL,NULL,TO_CHAR);
                return;
            }

            if ( !ch->in_room->exit[dir] )
            {
                act("There is no exit in that direction.",ch,NULL,NULL,TO_CHAR);
                return;
            }

            if ( (victim = get_char_direction(ch,fourth_arg,dir,range)) == NULL )
            {
                act("There is no such target in that direction.",ch,NULL,NULL,TO_CHAR);
                return;
            }

            if ( is_safe( ch, victim ) )
            {
                act("$N is safe from you.",ch,NULL,victim,TO_CHAR);
                return;
            }

            if ( victim == ch )
            {
                act("You cannot cast a ranged spell at yourself!",ch,NULL,NULL,TO_CHAR);
                return;
            }

            vo = (void *) victim;
            target = TARGET_RANGED;
            misc = dir;
            break;

    case TAR_CHAR_OFFENSIVE:
        if ( arg2[0] == '\0' )
        {
            if ( ( victim = ch->fighting ) == NULL )
            {
                cprintf(ch,"Cast the spell on whom?\n\r");
                return;
            }
        }
        else
        {
            if ( ( victim = get_char_room( ch, target_name ) ) == NULL )
            {
                cprintf(ch,"They aren't here.\n\r");
                return;
            }
        }

        if ( !IS_NPC(ch) )
        {
            if (is_safe(ch,victim) && victim != ch)
            {
                cprintf(ch,"Not on that target.\n\r");
                return; 
            }
        }

        if ( IS_AFFECTED(ch, AFF_CHARM) && ch->master == victim )
        {
            cprintf(ch,"You can't do that on your own follower.\n\r");
            return;
        }

        vo = (void *) victim;
        target = TARGET_CHAR;
        break;

    case TAR_CHAR_DEFENSIVE:
        if ( arg2[0] == '\0' )
        {
            victim = ch;
        }
        else
        {
            if ( ( victim = get_char_room( ch, target_name ) ) == NULL )
            {
                cprintf(ch, "They aren't here.\n\r" );
                return;
            }
        }

        /* Same Deity spells */
        if ( IS_SET(pSpellIndex->flags,COM_SAME_DEITY) && ch->deity != victim->deity && !fSkip )
        {
            act("$y won't grant such a request.",ch,NULL,NULL,TO_CHAR);
            return;
        }

        if ( IS_SET(pSpellIndex->flags,COM_NOT_SAME_DEITY) && ch->deity == victim->deity && !fSkip )
        {
            act("$y won't grant such a request.",ch,NULL,NULL,TO_CHAR);
            return;
        }
   
        /* For same-align spells, they don't work on people who are of a different-aligned
           deity, AND clanned AND not part of your clan.  Loners are not clanmates.
        */ 
        if ( IS_SET(pSpellIndex->flags,COM_SAME_ALIGN) && 
             deity_table[ch->deity].align != deity_table[victim->deity].align && 
             !fSkip && ch->pet != victim &&
             is_clan(victim) && !is_same_clan(ch,victim) )
        {
            act("$y won't grant such a request.",ch,NULL,NULL,TO_CHAR);
            return;
        }
    
        vo = (void *) victim;
        target = TARGET_CHAR;
        break;

    case TAR_PET:
        if ( ( victim = ch->pet ) == NULL )
        {
            cprintf(ch,"You do not have a pet.\n\r");
            return;
        }

        if ( victim->in_room != ch->in_room )
        {
            act("$N is not present.",ch,NULL,victim,TO_CHAR);
            return;
        }

        vo = (void *) victim;
        target = TARGET_CHAR;
        break;

    case TAR_CHAR_SELF_PET:
        if ( arg2[0] != '\0' ) /* look for a pet */
        {
            if ( ( victim = get_char_room( ch, target_name ) ) == NULL )
            {          
                send_to_char( "They aren't here.\n\r", ch );
                return;
            }

            if ( victim != ch->pet && victim != ch )
            {
                cprintf(ch,"This spell can only be cast on yourself or your pet.\n\r");
                return;
            }

            vo = (void *) victim;
            target = TARGET_CHAR;
            break;
        }
        else
        {
            vo = (void *) ch;
            target = TARGET_CHAR;
            break;
        }

    case TAR_CHAR_SELF:
        if  ( arg2[0] != '\0' && !is_name( target_name, ch->name ) )
        {
            cprintf(ch,"You cannot cast this spell on another.\n\r");
            return;
        }

        vo = (void *) ch;
        target = TARGET_CHAR;
        break;

    case TAR_OBJ_INV:
        if ( arg2[0] == '\0' )
        {
            cprintf(ch,"What should the spell be cast upon?\n\r");
            return;
        }

        if ( ( obj = get_obj_carry( ch, target_name, ch ) ) == NULL )
        {
            cprintf(ch,"You are not carrying that.\n\r");
            return;
        }

        vo = (void *) obj;
        target = TARGET_OBJ;
        break;

    case TAR_OBJ_CHAR_OFF:
        if (arg2[0] == '\0')
        {
            if ((victim = ch->fighting) == NULL)
            {
                cprintf(ch,"Cast the spell on whom or what?\n\r");
                return;
            }
    
            target = TARGET_CHAR;
        }
        else if ((victim = get_char_room(ch,target_name)) != NULL)
            target = TARGET_CHAR;

        if (target == TARGET_CHAR) /* check the sanity of the attack */
        {
            if(is_safe_spell(ch,victim,FALSE) && victim != ch)
            {
                cprintf(ch,"Not on that target.\n\r");
                return;
            }

            if ( IS_AFFECTED(ch, AFF_CHARM) && ch->master == victim )
            {
                cprintf(ch,"You can't do that on your own follower.\n\r");
                return;
            }

            if (!IS_NPC(ch))
                check_killer(ch,victim);

            vo = (void *) victim;
        }
        else if ((obj = get_obj_here(ch,target_name)) != NULL)
        {
            vo = (void *) obj;
            target = TARGET_OBJ;
        }
        else
        {
            cprintf(ch,"You don't see that here.\n\r");
            return;
        }
        break; 

    case TAR_OBJ_CHAR_DEF:
        if (arg2[0] == '\0')
        {
            vo = (void *) ch;
            target = TARGET_CHAR;                                                 
        }
        else if ((victim = get_char_room(ch,target_name)) != NULL)
        {
            vo = (void *) victim;
            target = TARGET_CHAR;
        }
        else if ((obj = get_obj_carry(ch,target_name,ch)) != NULL)
        {
            vo = (void *) obj;
            target = TARGET_OBJ;
        }
        else
        {
            cprintf(ch,"You don't see that here.\n\r");
            return;
        }
        break;
    } /* end switch */

    level = ch->level;
  
    if ( !fDivine )
    {
        if( !handle_mana_cost(ch,mana) )
            return;

        if( !handle_components(ch,sn) )
            return;
    }
    else
    {
       char buf[MAX_STRING_LENGTH];

        if ( ch->mana < mana )
        {
            cprintf(ch,"You are short by %d mana.\n\r", mana - ch->mana );
            return;
        }
        ch->mana -= mana;

        if ( IS_SET(pSpellIndex->flags,COM_VER) | IS_SET(flags,SILENTCAST) )
        {
            sprintf(buf,"$n prays '&C%s&x'\n\r",pSpellIndex->incantation);
            act(buf,ch,NULL,NULL,TO_ROOM);
            sprintf(buf,"You pray '&C%s&x'\n\r",pSpellIndex->incantation);
            act(buf,ch,NULL,NULL,TO_CHAR);
        }

        act("You hear the sound of divine chanting from $D.",ch,NULL,NULL,TO_RADIUS);
    }

    {
        int wait, redux;
    wait = pSpellIndex->beats;
    /* For every 5 points of dex over 125, you get a 1/10th second time reduction */
    redux = UMAX(0,(get_curr_stat(ch,STAT_DEX) - 100) / 5);

    redux = UMIN(redux,pSpellIndex->beats/3);
    wait = UMAX(PULSE_PER_SECOND*2,wait-redux);
    if ( fQuick )
        wait = 1;

    WAIT_STATE( ch, UMIN(wait,pSpellIndex->beats) );
    }

    SET_BIT(ch->act,PLR_IS_CASTING);

    ch->casting = new_casting_data();
    ch->casting->spell_sn = sn;
    ch->casting->level = level;
    ch->casting->vo = vo;
    ch->casting->target = target;
    ch->casting->mana = mana;
    ch->casting->flags = flags;
    ch->casting->misc = misc;

    cprintf(ch,"You begin to cast &Y%s&x.\n\r",pSpellIndex->full_name);
    return;
}

void check_spell_aggro( Character *ch )
{
    int sn;
    int target;  
    Character *victim;
	SpellIndex* pSpellIndex;

    sn = ch->casting->spell_sn;
    target = ch->casting->target;
    victim = (Character *) ch->casting->vo;

    //if ( sn == vnum_harmony )
        //return;

	if( (pSpellIndex = get_spell_index( sn )) == NULL )
	{
		log_bug("check_spell_aggro: Spell index not found(%d)",sn);
		return;
	}

    // Mez spells don't set aggro if they succeed
    if ((pSpellIndex->target == TAR_CHAR_OFFENSIVE || (pSpellIndex->target == TAR_OBJ_CHAR_OFF && target == TARGET_CHAR))
    &&   victim != ch
    &&   victim->master != ch)
    {
        Character *vch;
        Character *vch_next;

        for ( vch = ch->in_room->people; vch; vch = vch_next )
        {
            vch_next = vch->next_in_room;
    
            if ( victim == vch && victim->fighting == NULL && !IS_AFFECTED(victim,AFF_MESMERIZE) )
            {    
                if ( victim->daze )
                    set_fighting( victim, ch );
                else
                    one_hit( victim, ch, TYPE_UNDEFINED );
                break;
            }
        }
    }
    
    return;
}

bool verify_target( Character *ch )
{
    Character *victim;
    Object *object;
    void *vo;

    if ( ch->casting == NULL )
        return FALSE;

    victim    = NULL;
    object    = NULL;
    vo        = ch->casting->vo;

    switch ( ch->casting->target )
    {
    default:
        return TRUE;

    case TARGET_CHAR:
    if ( (victim = (Character *) vo) == NULL || victim->in_room != ch->in_room )
    {
        cprintf(ch,"&RYour victim is out of range or invalid.&x\n\r");
        ch->mana += ch->casting->mana;
        return FALSE;
    }
    else
        return TRUE;

    case TARGET_OBJ:
    if ( (object = (Object *) vo) == NULL || object->carried_by != ch )
    {
        cprintf(ch,"&RYou don't have the target object!&x\n\r");
        ch->mana += ch->casting->mana;
        return FALSE;
    }
    else
        return TRUE;
    }
}



/*
 * Cast spells at targets using a magical object.
 */
void obj_cast_spell( int sn, int level, Character *ch, Character *victim, Object *obj )
{
    void *vo;
    int target = TARGET_NONE;

    if ( sn <= 0 )
    return;

    if ( sn >= MAX_SKILL || skill_table[sn].spell_fun == 0 )
    {
    log_bug( "Obj_cast_spell: bad sn %d.", sn );
    return;
    }

    switch ( skill_table[sn].target )
    {
    default:
    log_bug( "Obj_cast_spell: bad target for sn %d.", sn );
    return;

    case TAR_IGNORE:
    vo = NULL;
    break;

    case TAR_CHAR_OFFENSIVE:
    if ( victim == NULL )
        victim = ch->fighting;
    if ( victim == NULL )
    {
        send_to_char( "You can't do that.\n\r", ch );
        return;
    }
    if (is_safe(ch,victim) && ch != victim)
    {
        send_to_char("Something isn't right...\n\r",ch);
        return;
    }
    vo = (void *) victim;
    target = TARGET_CHAR;
    break;

    case TAR_CHAR_DEFENSIVE:
    case TAR_CHAR_SELF:
    if ( victim == NULL )
        victim = ch;
    vo = (void *) victim;
    target = TARGET_CHAR;
    break;

    case TAR_OBJ_INV:
    if ( obj == NULL )
    {
        send_to_char( "You can't do that.\n\r", ch );
        return;
    }
    vo = (void *) obj;
    target = TARGET_OBJ;
    break;

    case TAR_OBJ_CHAR_OFF:
        if ( victim == NULL && obj == NULL)
    {
        if (ch->fighting != NULL)
        victim = ch->fighting;
        else
        {
        send_to_char("You can't do that.\n\r",ch);
        return;
        }
    }

        if (victim != NULL)
        {
        if (is_safe_spell(ch,victim,FALSE) && ch != victim)
        {
            send_to_char("Somehting isn't right...\n\r",ch);
            return;
        }

        vo = (void *) victim;
        target = TARGET_CHAR;
        }
        else
        {
            vo = (void *) obj;
            target = TARGET_OBJ;
        }
        break;


    case TAR_OBJ_CHAR_DEF:
    if (victim == NULL && obj == NULL)
    {
        vo = (void *) ch;
        target = TARGET_CHAR;
    }
    else if (victim != NULL)
    {
        vo = (void *) victim;
        target = TARGET_CHAR;
    }
    else
    {
        vo = (void *) obj;
        target = TARGET_OBJ;
    }
    
    break;
    }

    target_name = "";
    (*skill_table[sn].spell_fun) ( sn, level, ch, vo,target);

    

    if ( (skill_table[sn].target == TAR_CHAR_OFFENSIVE
    ||   (skill_table[sn].target == TAR_OBJ_CHAR_OFF && target == TARGET_CHAR))
    &&   victim != ch
    &&   victim->master != ch )
    {
    Character *vch;
    Character *vch_next;

    for ( vch = ch->in_room->people; vch; vch = vch_next )
    {
        vch_next = vch->next_in_room;
        if ( victim == vch && victim->fighting == NULL )
        {
        check_killer(victim,ch);
        one_hit( victim, ch, TYPE_UNDEFINED );
        break;
        }
    }
    }

    return;
}

bool enchant_weapon( Object *obj, int set_hitroll, int set_damroll, int sn, int level )
{
    Affect *paf; 
    int hit_bonus;
	int dam_bonus;
    bool hit_bonus_found = FALSE;
	bool dam_bonus_found = FALSE;

    /* this means they have no bonus */
    dam_bonus = hit_bonus = 0;

    /* Find total AC bonus */
    if (!obj->enchanted)
    {
        for ( paf = obj->pIndexData->affected; paf != NULL; paf = paf->next )
        {
            if ( paf->location == APPLY_HITROLL )
            {
                hit_bonus = UMAX(hit_bonus,paf->modifier);
                hit_bonus_found = TRUE;
            }

            if ( paf->location == APPLY_DAMROLL )
            {
                dam_bonus = UMAX(dam_bonus,paf->modifier);
                dam_bonus_found = TRUE;
            }
        }
    }
 
    for ( paf = obj->affected; paf != NULL; paf = paf->next )
    {
        if ( paf->location == APPLY_HITROLL )
        {
            hit_bonus = UMAX(hit_bonus,paf->modifier);
            hit_bonus_found = TRUE;
        }

		if ( paf->location == APPLY_DAMROLL )
        {
            dam_bonus = UMAX(dam_bonus,paf->modifier);
            dam_bonus_found = TRUE;
        }
    }

    if ( hit_bonus > set_hitroll && dam_bonus > set_damroll )
        return FALSE;

    /* okay copy the index affects to the item now */
    if (!obj->enchanted)
    {
        Affect *af_new;
        obj->enchanted = TRUE;

        for (paf = obj->pIndexData->affected; paf != NULL; paf = paf->next) 
        {
            af_new = new_affect();
    
            af_new->next = obj->affected;
            obj->affected = af_new;

            af_new->where    = paf->where;
            af_new->type     = UMAX(0,paf->type);
            af_new->level    = paf->level;
            af_new->duration    = paf->duration;
            af_new->location    = paf->location;
            af_new->modifier    = paf->modifier;
            af_new->bitvector    = paf->bitvector;
			af_new->flags		= (paf->flags|AFF_SPELL);
			af_new->misc		= paf->misc;
        }
    }

    /* now add the enchantments */ 
    if (obj->level < LEVEL_HERO)
        obj->level = UMIN(LEVEL_HERO - 1,obj->level + 1);

    /* replace any existing hitroll affects */
    if (hit_bonus_found)
    {
        for ( paf = obj->affected; paf != NULL; paf = paf->next)
        {
            if ( paf->location == APPLY_HITROLL)
            {
                paf->type = sn;
                paf->modifier = set_hitroll;
                paf->level = UMAX(paf->level,level);
            }
        }
    }
    else /* add a new affect */
    {
         paf = new_affect();

        paf->where    = TO_OBJECT;
        paf->type    = sn;
        paf->level    = level;
        paf->duration    = DUR_PERMANENT;
        paf->location    = APPLY_HITROLL;
        paf->modifier    =  set_hitroll;
        paf->bitvector  = 0;
        paf->next    = obj->affected;
		paf->flags	= AFF_SPELL;
		paf->misc	= 0;

        obj->affected    = paf;
    }

    /* replace any existing armor class affects */
    if (dam_bonus_found)
    {
        for ( paf = obj->affected; paf != NULL; paf = paf->next)
        {
            if ( paf->location == APPLY_DAMROLL)
            {
                paf->type = sn;
                paf->modifier = set_damroll;
                paf->level = UMAX(paf->level,level);
            }
        }
    }
    else /* add a new affect */
    {
         paf = new_affect();

        paf->where    = TO_OBJECT;
        paf->type    = sn;
        paf->level    = level;
        paf->duration    = DUR_PERMANENT;
        paf->location    = APPLY_DAMROLL;
        paf->modifier    =  set_damroll;
        paf->bitvector  = 0;
        paf->next    = obj->affected;
        paf->flags  = AFF_SPELL;
        paf->misc   = 0;

        obj->affected    = paf;
    }

    return TRUE;
}

/*
 * This fucntion will replace any existing AC bonus
 * with the new bonus, and increase the item's absorbtion
 */
bool enchant_armor( Object *obj, int set_ac, int set_absorb, int sn, int level )
{
    Affect *paf; 
    int ac_bonus;
    bool ac_found = FALSE;

    /* this means they have no bonus */
    ac_bonus = 0;

    /* Find total AC bonus */
    if (!obj->enchanted)
    {
        for ( paf = obj->pIndexData->affected; paf != NULL; paf = paf->next )
        {
            if ( paf->location == APPLY_AC )
            {
                ac_bonus = UMAX(ac_bonus,paf->modifier);
                ac_found = TRUE;
             }
        }
    }
 
    for ( paf = obj->affected; paf != NULL; paf = paf->next )
    {
        if ( paf->location == APPLY_AC )
          {
            ac_bonus = UMAX(ac_bonus,paf->modifier);
            ac_found = TRUE;
        }
    }

    if ( ac_bonus > set_ac )
        return FALSE;

    /* okay copy the index affects to the item now */
    if (!obj->enchanted)
    {
        Affect *af_new;
        obj->enchanted = TRUE;

        for (paf = obj->pIndexData->affected; paf != NULL; paf = paf->next) 
        {
            af_new = new_affect();
    
            af_new->next = obj->affected;
            obj->affected = af_new;

            af_new->where    = paf->where;
            af_new->type     = UMAX(0,paf->type);
            af_new->level    = paf->level;
            af_new->duration    = paf->duration;
            af_new->location    = paf->location;
            af_new->modifier    = paf->modifier;
            af_new->bitvector    = paf->bitvector;
			af_new->flags		= (paf->flags|AFF_SPELL);
			af_new->misc		= paf->misc;
        }
    }

    /* now add the enchantments */ 
    if (obj->level < LEVEL_HERO)
        obj->level = UMIN(LEVEL_HERO - 1,obj->level + 1);

    /* replace any existing armor class affects */
    if (ac_found)
    {
        for ( paf = obj->affected; paf != NULL; paf = paf->next)
        {
            if ( paf->location == APPLY_AC)
            {
                paf->type = sn;
                paf->modifier = set_ac;;
                paf->level = UMAX(paf->level,level);
            }
        }
    }
    else /* add a new affect */
    {
         paf = new_affect();

        paf->where    = TO_OBJECT;
        paf->type    = sn;
        paf->level    = level;
        paf->duration    = DUR_PERMANENT;
        paf->location    = APPLY_AC;
        paf->modifier    =  set_ac;
        paf->bitvector  = 0;
        paf->next    = obj->affected;
		paf->flags	= AFF_SPELL;
		paf->misc	= 0;

        obj->affected    = paf;
    }

    obj->absorb = UMAX(set_absorb,obj->absorb);
    return TRUE;
}

/* Weapons casting spells
 */
void processSpecialWeapon( Object *wield, Character *ch, Character *victim )
{
    void *vo;
    extern bool fProc;
	SpellIndex* pSpellIndex;

    if ( !HAS_PROC(wield))
    {
        log_bug("processSpecialWeapon: wielded weapon has no special procedure",0);
        return;
    }

	if ( (pSpellIndex = get_spell_index( wield->value[7] )) == NULL )
	{
		log_bug("processSpecialWeapon: Spell index not found(%d)",wield->value[7]);
		return;
	}

    /* Now we just need to set up whether the spell casts on 'ch' or 'victim' 
     */
	switch( pSpellIndex->target )
   {
           case TAR_CHAR_DEFENSIVE:
           case TAR_CHAR_SELF:
           case TAR_OBJ_CHAR_DEF:
            vo = (void *) ch;
            break;
           case TAR_CHAR_OFFENSIVE:
           case TAR_OBJ_CHAR_OFF:
            vo = (void *) victim;
            break;
           default:
            log_bug("processSpecialWeapon: invalid target type for spell",0);
            return;
   }

	if ( pSpellIndex->spell_fun == NULL )
	{
		log_bug("Weapon procs: no function pointer for %d %s", pSpellIndex->vnum, pSpellIndex->name );
		return;
	}

    /* Ugh!  This is such a kludgey hack */
    fProc = PROC_NORMAL;
    if ( *(pSpellIndex->sgsn) == gsn_envenom )
        fProc = PROC_VENOMS;
       (*(pSpellIndex->spell_fun))(wield->value[7],ch->level,ch,vo,TARGET_CHAR);
    fProc = FALSE;

    /* Check for single-hitters */
    if ( IS_SET( wield->value[4], WEAPON_ONE_TIME_PROC ) )
    {
        REMOVE_BIT( wield->value[4], WEAPON_ONE_TIME_PROC );
        wield->value[7] = 0;
        wield->value[8] = 0;
        wield->value[9] = 0;
    }
    
    /* Check for decliners */
    if ( IS_SET( wield->value[4], WEAPON_DECLINING_PROC ) )
    {
        if ( --wield->value[8] <= 0 )
        {
            REMOVE_BIT(wield->value[4], WEAPON_ONE_TIME_PROC);
            wield->value[7] = 0;
            wield->value[8] = 0;
            wield->value[9] = 0;
        }
    }
       return;
}


int calcSpellDamage( Character *ch, int sn, int low, int high )
{
    int skill_sn;
    int bonus;
    int    statBonus;
    int stat, amt;
	SpellIndex* pSpellIndex;

	if( (pSpellIndex = get_spell_index( sn )) == NULL)
	{
		log_bug("calcSpellDamage: Spell index not found(%d)",sn);
		return 0;
	}

    skill_sn = get_skill(ch,*(pSpellIndex->sgsn));
    skill_sn = UMAX(skill_sn,1);

    /* Calculate bonus to low damage.
     * Bonus can increase damage floor significantly.
     * The floor can be brought up to 75% of the ceiling.
     * The ceiling can be increased a little, too.
     */
    bonus = (high - low) * 75 / 100;
    bonus = skill_sn * bonus / ch->level;
    low += bonus;

    high += (bonus/2);

    /* Figure out casting stat */
    switch( class_table[ch->class].group )
    {
        case ARCANE:    stat = STAT_INT; break;
        case DIVINE:    stat = STAT_WIS; break;
        default:
            stat = STAT_CHA; break;
    }

    statBonus = 100 + ( (get_curr_stat(ch,stat)-100)/2);

    /* Now check for crit casting */
    bonus = 0;
    if ( HAS_PROF(ch,gpn_critical_casting))
    {
        int chance = 10;
        int roll;

        chance = skill_sn / 5;

        if ( (roll = number_percent()) < chance )
        {
            /* Bonus % = double difference between roll and chance */
            bonus = skill_sn + (chance - roll) * 5;

            act("Your soul delights as you summon forth the power for a critical strike!",ch,NULL,NULL,TO_CHAR);
            act("$n delights as $e summons forth the power for a critical strike!",ch,NULL,NULL,TO_ROOM);
        }
    }
    
    amt = number_range( low,  high );
    /* Figure in casting stat */
    amt = statBonus * amt / 100;

    return amt + bonus;
}

int calcHealAmount( Character *ch, int sn, int low, int high )
{
    int skill_sn;
    int bonus;
	SpellIndex* pSpellIndex;

	if( (pSpellIndex = get_spell_index( sn )) == NULL)
	{
		log_bug("calcHealAmount: Spell index not found(%d)",sn);
		return 0;
	}

    skill_sn = get_skill(ch,*(pSpellIndex->sgsn));
    skill_sn = UMAX(skill_sn,1);

    bonus = (high - low) * 80 / 100;
    bonus = skill_sn * bonus / ch->level;
    low += bonus;

    return  number_range(low,high);
}

int spell_food_poisoning(int sn, int level, Character *ch, void *vo, int target)
{
    return TRUE;
}

int spell_natural_venom(int sn, int level, Character *ch, void *vo, int target )
{
    Affect af;
    Character *victim = (Character *) vo;

    if ( check_saves_spell(ch,victim,DAM_POISON,SAVE_FORTITUDE) )
    {
        act("You resist the venom!",victim,NULL,NULL,TO_CHAR);
        act("$N resists the venom!",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where         = DAMAGE_OVER_TIME;
    af.type          = sn;
    af.duration     = seconds(30+ch->level);
    af.location        = UMAX(ch->level/3,6);
    af.modifier     = UMAX(ch->level/4,3);
    af.caster_id    = ch->id;
    af.bitvector    = DAM_POISON;
    af.flags        = AFF_NONSPELL;
	af.level		= ch->level;
    spellAffectToChar(victim,&af);

    act( "You shiver and convulse as the venom courses through your veins.", victim,NULL,NULL,TO_CHAR);
    act( "$n shivers and convulses as venom courses through $s veins.", victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

void do_erase( Character *ch, char *argument )
{
    int i;
    int which;
    int count = 0;
    Object *book;
    char    arg[MAX_INPUT_LENGTH];

    if ( IS_NPC(ch) && class_table[ch->class].group != ARCANE )
    {
        cprintf(ch,"Only Arcane casters know how to fanagle a spellbook.\n\r");
        return;
    }

    argument = one_argument( argument, arg );

    if ( arg[0] == '\0' || *argument == '\0' )
    {
        cprintf(ch,"Syntax:  erase <book> <spell#>\n\r");
        return;
    }

    if ( !is_number( argument ) )
    {
        cprintf(ch,"The spell# must be numeric.\n\r");
        return;
    }

    which = atoi( argument );
    if ( which < 1 || which > 20 )
    {
        cprintf(ch,"Range is 1-20.\n\r");
        return;
    }

    if ( ( book = get_obj_carry( ch, arg, ch )) == NULL )
    {
        cprintf(ch,"You aren't carrying anything like that.\n\r");
        return;
    }

    if ( book->item_type != ITEM_SPELLBOOK )
    {
        act("$p is not a spellbook.",ch,book,NULL,TO_CHAR);
        return;
    }

    for( i = 0 ; i < 10 ; i++ )
    {
        if ( get10Bits(book->value[i]) > 0 )
        {
            if ( ++count == which )
            {
                book->value[i] = set10Bits( book->value[0], 0 );
                actprintf(ch,book,NULL,TO_CHAR,"You erase the %d%s section of $p.",
                    which, which == 1 ? "st" : which == 2 ? "nd" : which == 3 ? "rd" : "th" );    
                return;
            }
        }
    }

	for( i = 0 ; i < 10 ; i++ )
	{
		if ( get20Bits(book->value[i]) > 0 )
		{
            if ( ++count == which )
            {
                book->value[i] = set20Bits( book->value[0], 0 );
                actprintf(ch,book,NULL,TO_CHAR,"You erase the %d%s section of $p.",
                    which, which == 1 ? "st" : which == 2 ? "nd" : which == 3 ? "rd" : "th" );
                return;
            }
        }
    }

    cprintf(ch,"There aren't that many sections.\n\r");
    return;
}

void do_concentrate( Character *ch, char *argument )
{
    int n;
    Affect af;

    if ( IS_NPC(ch) )
    {
        cprintf(ch,"You do not have this ability.\n\r");
        return;
    }

    if ( !HAS_PROF(ch,gpn_concentration) )
    {
        cprintf(ch,"You do not have the Concentration ability.\n\r");
        return;
    }

    if ( (n=REUSE_SKILL(ch,gsn_concentration)) )
    {
        cprintf(ch,"You use Concentration for %d more second%s.\n\r",
            n/PULSE_PER_SECOND,
            (n/PULSE_PER_SECOND)==1?"":"s");
        return;
    }

    af.where     = TO_AFFECTS;
    af.caster_id = ch->id;
    af.type      = gsn_concentration;
    af.level     = ch->level;
    af.duration  = seconds( 30 );
    af.location  = 0;
    af.modifier  = 0;
    af.bitvector = 0;
    af.flags     = AFF_SKILL;
    af.misc      = 0;
    skillAffectToChar( ch, &af );
    act("You focus your mind on your spellcasting.",ch,NULL,NULL,TO_CHAR);
    act("$n's eyes narrow as $e focuses.",ch,NULL,NULL,TO_ROOM);
    setSkillReuseWait( ch, gsn_concentration, PULSE_PER_SECOND * 60 * 30 );
    return;
}


void do_mapspells( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
	int spell, index;
	SpellIndex* pSpellIndex;

    argument = one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
        cprintf(ch,"Syntax:   mapspell '<spell_name>' <slot#>\n\r"
                   "          mapspell clear <slot#>\n\r"
                   "          mapspell clear all\n\r"
                   "          mapspell [show|list]\n\r");
        return;
    }

	if ( !str_cmp(arg,"show") || !str_cmp(arg,"list") )
	{
		int i;
		
		cprintf(ch," == Spell Slot Mappings ==\n\r");
		for( i=0; i<MAX_SPELL_SLOT; i++ )
		{
			pSpellIndex = get_spell_index(ch->pcdata->spell_slots[i]);

			cprintf(ch,"[%2d] %s\n\r", i+1,
				ch->pcdata->spell_slots[i] > 0 ? (pSpellIndex ? pSpellIndex->full_name : "(null)") : 
						"<not used>" );
		}

		return;
	}

	if ( *argument == '\0' )
	{
		do_mapspells(ch,"");
		return;
	}

	if ( !str_cmp(arg,"clear") )
	{
		int index;

		if ( !str_cmp(argument,"all") )
		{
			int i;

			for( i=0 ; i<MAX_SPELL_SLOT; i++ )
				ch->pcdata->spell_slots[i] = 0;

			cprintf(ch,"All spell slots cleared.\n\r");
			return;
		}

		index = atoi(argument);
		if( index < 1 || index > MAX_SPELL_SLOT )
		{
			cprintf(ch,"Slot # must be between 0 and %d.\n\r", MAX_SPELL_SLOT );
			return;
		}

		--index;
		ch->pcdata->spell_slots[index] = 0;
		cprintf(ch,"Slot #%d cleared.\n\r", ++index);
		return;
	}

	/* Add new spell */
	if ( (spell = spell_lookup(arg,-1)) < 0 )
	{
		cprintf(ch,"No such spell called '%s'.\n\r", arg );
		return;
	}

	if( (pSpellIndex = get_spell_index(spell)) == NULL )
	{
		log_bug("do_mapspells: Spell index not found(%d)",spell);
		return;
	}

	if ( pSpellIndex->class_level[ch->class] < 0 ||
	     pSpellIndex->class_level[ch->class] > 51 )
	{
		cprintf(ch,"Your class cannot cast '%s'.\n\r", pSpellIndex->full_name );
		return;
	}

	index = atoi(argument);
	if ( index < 1 || index > MAX_SPELL_SLOT )
	{
		cprintf(ch,"Slot # must be between 0 and %d.\n\r", MAX_SPELL_SLOT );
		return;
	}
	--index;
 
	ch->pcdata->spell_slots[index] = spell;
	cprintf(ch,"Spell '%s' mapped to slot #%d.\n\r",pSpellIndex->full_name, index+1 );
	return;
}

bool gate( Character *ch, int vnum )
{
    Room *r;
    Character *victim, *next_in_room;

    if ( (r = get_room_index( vnum )) == NULL )
    {
        cprintf(ch,"Your spell fails.\n\r");
        return FALSE;
    }

    for ( victim = ch->in_room->people ; victim ; victim = next_in_room )
    {
        next_in_room = victim->next_in_room;

        if ( victim->fighting != NULL || !is_same_group(ch,victim) )
            continue;

        act("$n is swallowed by the black gate, and then it closes with a blinding flash!",victim,NULL,NULL,TO_ROOM);
        char_from_room(victim);
        char_to_room(victim,r);
        act("A thunderous explosion ricochets across the clearing as $n materializes.",victim,NULL,NULL,TO_ROOM);
        do_look(victim,"auto");
    }

    return TRUE;
}

// Generic spell driver
bool spell_generic_driver( int sn, int level, Character *ch, void *vo, int target)
{
    SpellIndex *sp = get_spell_index( sn );

    if ( sp == NULL )
    {
        log_bug("SpellIndex %d not found", sn );
        cprintf(ch,"The spell could not be cast due to an internal game failure.\n\r");
        return FALSE;
    }

    // Check type
    switch( sp->spell_type )
    {
        case SPELL_BOLT:    return spell_generic_bolt(sp,sn,level,ch,vo,target);
        case SPELL_BUFF:    return spell_generic_buff(sp,sn,level,ch,vo,target); 
        case SPELL_DEBUFF:  return spell_generic_debuff(sp,sn,level,ch,vo,target);
        case SPELL_NUKE:    return spell_generic_nuke(sp,sn,level,ch,vo,target);
        case SPELL_COMBO_NUKE:
                            return spell_generic_combo(sp,sn,level,ch,vo,target);
        case SPELL_UNKNOWN:
        default:
            cprintf(ch,"The spell could not be cast due to a game bug.\n\r");
            log_bug("SpellIndex %d has bad type", sn );
            return FALSE;
    }

    // Shouldn't be possible to get here
    return FALSE;
}

bool spell_generic_buff( SpellIndex *sp, int sn, int level, Character *ch, void * vo, int target)
{
    Character *victim = (Character *) vo;
    int i;

    // Add all valid spell affects
    for( i=0 ; i<5 ; i++ )
        if ( sp->action.generic.affects[i].type > 0 )
            spellAffectToChar( victim, &sp->action.generic.affects[i] );

    if ( sp->action.generic.okRoomEcho != NULL )
        act( sp->action.generic.okRoomEcho, victim, NULL, NULL, TO_ROOM );
    if (  sp->action.generic.okVictimEcho != NULL )
        act( sp->action.generic.okVictimEcho, victim, NULL, NULL, TO_CHAR );
    return TRUE;
}

bool spell_generic_debuff( SpellIndex *sp, int sn, int level, Character *ch, void * vo, int target)
{
    Character *victim = (Character *) vo;
    int i;

    if ( check_saves_spell( ch, victim, sp->action.generic.damType,
                                        sp->action.generic.saveType ) )
    {
        if ( IS_SET(ch->display, DISP_SHOW_SAVES) )
            act("&M$N makes a saving throw!&x", ch, NULL, victim, TO_CHAR);
        if ( IS_SET(victim->display, DISP_SHOW_SAVES) )
            act("&MYou make a saving throw!&x", victim, NULL, NULL, TO_CHAR);

        if ( sp->action.generic.failRoomEcho != NULL )
            act( sp->action.generic.failRoomEcho, victim, NULL, NULL, TO_ROOM );
        if (  sp->action.generic.failVictimEcho != NULL )
            act( sp->action.generic.failVictimEcho, victim, NULL, NULL, TO_CHAR );
        return TRUE;
    }

    // Add all valid spell affects
    for( i=0 ; i<5 ; i++ )
        if ( sp->action.generic.affects[i].type > 0 )
            spellAffectToChar( victim, &sp->action.generic.affects[i] );

    if ( sp->action.generic.okRoomEcho != NULL )
        act( sp->action.generic.okRoomEcho, victim, NULL, NULL, TO_ROOM );
    if (  sp->action.generic.okVictimEcho != NULL )
        act( sp->action.generic.okVictimEcho, victim, NULL, NULL, TO_CHAR );
    return TRUE;
}

bool spell_generic_nuke( SpellIndex *sp, int sn, int level, Character *ch, void * vo, int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage( ch, sp->vnum, sp->action.generic.lowDamage,
                                         sp->action.generic.highDamage );

    if ( check_saves_spell( ch, victim, sp->action.generic.damType,
                                        sp->action.generic.saveType ) )
    {
        if ( IS_SET(ch->display, DISP_SHOW_SAVES) )
            act("&M$N makes a saving throw!&x", ch, NULL, victim, TO_CHAR);
        if ( IS_SET(victim->display, DISP_SHOW_SAVES) )
            act("&MYou make a saving throw!&x", victim, NULL, NULL, TO_CHAR);
        dam /= 2;
    }

    damage( ch, victim, dam, sp->vnum, sp->action.generic.damType, DF_SHOW | DF_SPELL );
    return TRUE;
}

// Nuke/debuff combinations - slightly more intermixed logic
bool spell_generic_combo( SpellIndex *sp, int sn, int level, Character *ch, void * vo, int target)
{
    Character *victim = (Character *) vo;
    int   dam, i;

    dam = calcSpellDamage(ch,sp->vnum,sp->action.generic.lowDamage,
                                sp->action.generic.highDamage );

    if ( check_saves_spell(ch, victim, sp->action.generic.damType,
                                       sp->action.generic.saveType ) )
    {
        if ( IS_SET(ch->display, DISP_SHOW_SAVES) )
            act("&M$N makes a saving throw!&x", ch, NULL, victim, TO_CHAR);
        if ( IS_SET(victim->display, DISP_SHOW_SAVES) )
            act("&MYou make a saving throw!&x", victim, NULL, NULL, TO_CHAR);
        dam /= 2;
    }
    else
    {
        // Add all valid spell affects
        for( i=0 ; i<5 ; i++ )
            if ( sp->action.generic.affects[i].type > 0 )
                spellAffectToChar( victim, &sp->action.generic.affects[i] );

        if ( sp->action.generic.okRoomEcho != NULL )
            act( sp->action.generic.okRoomEcho, victim, NULL, NULL, TO_ROOM );
        if (  sp->action.generic.okVictimEcho != NULL )
            act( sp->action.generic.okVictimEcho, victim, NULL, NULL, TO_CHAR );
    }

    damage( ch, victim, dam, sp->vnum, sp->action.generic.damType, DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_generic_bolt( SpellIndex *sp, int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Room *room, *save, *lastRoom;
    Exit *pexit, *pback;
    int dir, range, i;
    int skill, tohit;
    int dam;
    bool fMiss;

    if ( ch->casting == NULL )
    {
        cprintf(ch,"&R[**]&x Error: the game doesn't think you're casting.\n\r");
        return FALSE;
    }

    dir   = ch->casting->misc;
    skill = get_skill(ch,*(sp->sgsn));
    range = sp->action.generic.range;

	if ( !validateTarget( ch, victim, dir, range ) )
	{
		cprintf(ch,"&R*** Your target is no longer in range or line-of-sight.&x\n\r");
		return FALSE;
	}

	actprintf(ch,NULL,victim,TO_CHAR,"You conjure forth and unleash a %s at $N!",sp->msg_damage);
	actprintf(ch,NULL,NULL,TO_ROOM,"$n conjures forth and unleashes a %s!",sp->msg_damage);

	// Show projectile flying in intermediate rooms
    save        = ch->in_room;
    lastRoom    = ch->in_room;
    pexit       = save->exit[dir];
    room        = pexit->u1.to_room;
    ch->in_room = room;

    for( i=0 ; i < range ; i++ )
    {
        if( char_is_in_room(ch->in_room,victim) )
            break;

        if( (pexit = room->exit[dir]) == NULL )
            break;

        actprintf(ch,NULL,NULL,TO_ROOM,"A %s flies past you going from %s to %s.",
            sp->msg_damage, dir_name[rev_dir[dir]], dir_name[dir] );

        lastRoom = room;
        if ( (room = pexit->u1.to_room) == NULL )
            break;

        if ( (pback = room->exit[rev_dir[dir]]) == NULL )
            break;

        if ( pback->u1.to_room != lastRoom )
            break;

        if ( room == lastRoom )
            break;

        ch->in_room = room;
    }

    ch->in_room = save;

	// Hit target.  Bolts only miss if your opponent is above your skill level
    // or in combat.

    // Chance to hit a guy in a fight is slim anyway
    fMiss = FALSE;
    if ( victim->fighting != NULL )
    {
        int n = countAttackers(victim) + 1;

        if ( number_percent() > 100 / n )
            fMiss = TRUE;
    }
    else
    // If victim is higher level than your bolt skill, roll a to-hit
    if ( !victim->level > skill )
    {   
        // Tohit = skill + 1d10 + dex bonus
        // Defend = level + 1d10
        tohit = skill + dice(1,10) + (get_curr_stat(ch,STAT_DEX) - 100)/10; // +10 bonus at 200 dex

        if ( tohit < victim->level + dice(1,10) )
            fMiss = TRUE;
    }

    if ( fMiss )
    {
        actprintf(victim,NULL,NULL,TO_ROOM,"A %s, incoming from the %s, just misses $n.",
            sp->msg_damage, dir_name[rev_dir[dir]]);
        actprintf(victim,NULL,NULL,TO_CHAR,"A %s, incoming from the %s, just misses you.",
            sp->msg_damage, dir_name[rev_dir[dir]]);
        damage( ch, victim, 0, sp->vnum, sp->action.generic.damType, DF_SHOW | DF_RANGED | DF_SPELL ); 
        return TRUE;
    }

    // Calculate damage
    dam = calcSpellDamage( ch, sp->vnum, sp->action.generic.lowDamage,
                                         sp->action.generic.highDamage );

    if ( check_saves_spell( ch, victim, sp->action.generic.damType,
                                        sp->action.generic.saveType ) )
    {
        if ( IS_SET(ch->display, DISP_SHOW_SAVES) )
            act("&M$N makes a saving throw!&x", ch, NULL, victim, TO_CHAR);
        if ( IS_SET(victim->display, DISP_SHOW_SAVES) )
            act("&MYou make a saving throw!&x", victim, NULL, NULL, TO_CHAR);
        dam /= 2;
    }

    // Handle damage
    actprintf(victim,NULL,NULL,TO_ROOM,"A %s, incoming from the %s, impacts $n.",
        sp->msg_damage, dir_name[rev_dir[dir]]);
    actprintf(victim,NULL,NULL,TO_CHAR,"A %s, incoming from the %s, impacts you!",
        sp->msg_damage, dir_name[rev_dir[dir]]);

    damage( ch, victim, dam, sp->vnum, sp->action.generic.damType, DF_SHOW | DF_RANGED | DF_SPELL );

	// For NPCs, set up pursuit pathing if that shot didn't kill 'em
    if ( IS_NPC(victim) && victim->in_room != NULL && victim->pursuit.index == 0 )
    {
        // Queue 'em up, this part sucks
        // Start in the room the victim is in and go backwards.
        Room *room;
        Exit *pexit;
        int total;

        if ( (room = ch->in_room) == NULL )
        {
            log_bug("could not find room that ranged victim is in");
            return TRUE;
        }

        if ( (pexit = room->exit[dir]) == NULL )
        {
            log_bug("could not find exit in ranged victim's room");
            return TRUE;
        }

        victim->pursuit.array[victim->pursuit.index++] = room->vnum;
        // Go one room back towards the shooter
        if ( (room = pexit->u1.to_room) == NULL )
        {
            log_bug("could not back up 1 room");
            return TRUE;
        }

        total = 0;
        while( room != victim->in_room && total++ <= range && victim->pursuit.index < MAX_STACK )
        {
            victim->pursuit.array[victim->pursuit.index++] = room->vnum;
            if ( (pexit = room->exit[dir]) == NULL )
            {
                log_bug("could not find exit in ranged victim's room");
                return TRUE;
            }

            if ( (room = pexit->u1.to_room) == NULL )
            {
                log_bug("could not find exit in ranged victim's room");
                return TRUE;
            }
        }
    }

    return TRUE;
}
