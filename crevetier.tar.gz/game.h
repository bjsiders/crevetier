#ifndef game_h
#define game_h

#define MAX_USAGE     4

typedef struct timezone_tag
{
    char    *zone_description;
    char    *zone_environment;
} TimeZone;

typedef struct
{
    int        periods;
    int        logons;
} Usage;

struct game_info
{
    int            version;

    /* Stat tracking.  Tracks hourly, daily, weekly, and monthly averages */
    Usage          usage[MAX_USAGE];

    /* Track record for most players logged on simultaneously */
    int            mostPlayersEver;
    time_t         mostPlayersWhen;

    /* Track # of newbies, deletions, and current characters */
    int            totalNewbies;
    int            totalDeleted;
    int            totalCurrent;

    int            numberOfSubrace[ 30 ]; /* This is a guess */
    int            numberOfClass[ MAX_CLASS ];
};

/*
    Help table types.
 */
struct    help_data
{
    Help *    next;
    sh_int    level;
    char *    keyword;
    char *    text;
    bool      delete;
    char *    file;
    char *    author;
    char *    email;
    time_t    update;
    long      flags;
};

/*
    Last logins
 */
#define LOGIN_HISTORY        30
struct last_login
{
    char        name[32];
    int         level;
    time_t      login;
    time_t      logout;
    char        host[128];
};

/*
    Extra description data for a room or object.
 */
struct extra_descr_data
{
    ExtraDescr *      next;
    bool                    valid;
    char *                  keyword;
    char *                  description;
};

#if defined(__ARPENS) || defined(__TEST)
#define PULSE_PER_SECOND        10
#else
#define PULSE_PER_SECOND        4
#endif

#define PULSE_REUSE_UPDATE      ( 1 * PULSE_PER_SECOND)
#define PULSE_MELEE_UPDATE      (12 * PULSE_PER_SECOND)
#define PULSE_SPAWN             (10 * PULSE_PER_SECOND)
#define PULSE_REGEN             ( 6 * PULSE_PER_SECOND)
#define PULSE_VIOLENCE          (PULSE_PER_SECOND/PULSE_PER_SECOND)
#define PULSE_MOBILE            ( 4 * PULSE_PER_SECOND)
#define PULSE_MUSIC             ( 6 * PULSE_PER_SECOND)
#define PULSE_AFFECT_UPDATE     ( 6 * PULSE_PER_SECOND)
#define PULSE_TICK              (60 * PULSE_PER_SECOND)
#define PULSE_AREA              (60 * PULSE_PER_SECOND)
#define PULSE_GUI_CHECK         ( 5 * PULSE_PER_SECOND)
#define PULSE_RESOURCE          (60 * PULSE_PER_SECOND * 60 * 6)

#define USE_HOURLY    0
#define USE_DAILY     1
#define USE_WEEKLY    2
#define USE_MONTHLY   3
#define MAX_USAGE     4

#define LOGIN_HISTORY        30

/* dice */
#define DICE_NUMBER          0
#define DICE_TYPE            1
#define DICE_BONUS           2

/*
 * GUI flags
 */
#define GUI_CHECK           (A)
#define GUI_FRIENDS         (B)
#define GUI_RECEIVING_TELL  (C)
#define GUI_USE             (D)

/*
    Globals
*/
extern struct last_login    lastLoginTable[LOGIN_HISTORY];
extern int                  lastLoginIndex;
extern int                  global_port;
extern int                  global_control;
extern char*                game_version;
extern char*                print_version;
extern char*                globalSaving;

extern       struct game_info       GameInfo;

#endif /* game_h */
