/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,	   *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *									   *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael	   *
 *  Chastain, Michael Quan, and Mitchell Tse.				   *
 *									   *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc	   *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.						   *
 *									   *
 *  Much time and thought has gone into this software and you are	   *
 *  benefitting.  We hope that you share your changes too.  What goes	   *
 *  around, comes around.						   *
 ***************************************************************************/
 
/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@efn.org)				   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#ifndef tables_h
#define tables_h

#define MAX_ARMOR	11
#define MAX_DEITY   17

/*
 * This structure is used in bit.c to lookup flags and stats.
 */
struct flag_type
{
    char *  name;
    int     bit;
    bool    settable;
};

/*
 * Attribute bonus structures.
 */
struct    str_app_type
{
    sh_int    tohit;
    sh_int    todam;
    sh_int    carry;
    sh_int    wield;
};

struct    int_app_type
{
    sh_int    learn;
};

struct    wis_app_type
{
    sh_int    practice;
};

struct    dex_app_type
{
    sh_int    defensive;
};

struct    con_app_type
{
    sh_int    hitp;
    sh_int    shock;
};

struct level_data
{
	long		tnl;		/* to next level amt */
	int			spm;		/* skill point multiplier */
};

struct armor_type
{
    char	*name;
    int		absorb;
	sh_int		*pgpn;
	char	*abbrev;
};

struct title_type
{
    char	*name;
};

struct circle_type
{
    char	*name;
};

struct option_type
{
	char 	*name;
	long	flag;
};

struct display_type
{
    char	*name;
    long	flag;
    bool	is_toggle;
};

struct society_type
{
    char	*name;
};

struct trigger_type
{
	char *name;
};

struct deity_type
{
    char *name;
    char *role;
    int  align;
};

struct position_type
{
    char *name;
    char *short_name;
};

struct sex_type
{
    char *name;
};

struct size_type
{
    char *name;
};

struct dam_flag_conv
{
	int 	dam_type;
	int		resist;
    long    imm_flags;
};

extern const struct str_app_type    str_app[26];
extern const struct int_app_type    int_app[26];
extern const struct wis_app_type    wis_app[26];
extern const struct dex_app_type    dex_app[26];
extern const struct con_app_type    con_app[26];

/* game tables */
extern  const   char*   usage_name[];
extern  const   char*   rolename[];
extern  const   char*   specTitle[];
extern  const   struct  dam_flag_conv   damage_flag_convert[];
extern  const   struct  armor_type  armor_table[MAX_ARMOR+1];
extern  const   char*   statnames[6];
extern  const   struct  level_data      exp_to_level[61];
extern  const   int     eck[61];
extern  const   struct  position_type   position_table[];
extern  const   struct  sex_type    sex_table[];
extern  const   struct  size_type   size_table[];
extern  const   struct  title_type  title_table[];
extern  const   struct  circle_type circle_table[];
extern  const   struct  option_type     option_table[];
extern  const   struct  deity_type  deity_table[];
extern  const   struct  trigger_type    trigger_table[];

/* flag tables */
extern  const   struct  flag_type   quest_flags[];
extern  const   struct  flag_type   act_flags[];
extern  const   struct  flag_type   plr_flags[];
extern  const   struct  flag_type   affect_flags[];
extern  const   struct  flag_type   off_flags[];
extern  const   struct  flag_type   imm_flags[];
extern  const   struct  flag_type   form_flags[];
extern  const   struct  flag_type   part_flags[];
extern  const   struct  flag_type   comm_flags[];
extern  const   struct  flag_type   extra_flags[];
extern  const   struct  flag_type   wear_flags[];
extern  const   struct  flag_type   weapon_flags[];
extern  const   struct  flag_type   forge_flags[];
extern  const   struct  flag_type   container_flags[];
extern  const   struct  flag_type   portal_flags[];
extern  const   struct  flag_type   room_flags[];
extern  const   struct  flag_type   exit_flags[];
extern  const   struct  flag_type   portal_flags[];
extern  const   struct  flag_type   furniture_flags[];
extern  const   struct  flag_type   cmd_flags[];
extern  const   struct  flag_type   wizcmd_flags[];

extern const struct flag_type building_info_flags[];
extern const struct flag_type building_flags[];
extern const struct flag_type resource_flags[];
extern const struct flag_type rank_flags[];
extern const struct flag_type trigger_flags[];
extern const struct flag_type area_flags[];
extern const struct flag_type sex_flags[];
extern const struct flag_type ranged_flags[];
extern const struct flag_type foundation_flags[];
extern const struct flag_type tradeskill_flags[];
extern const struct flag_type exit_flags[];
extern const struct flag_type door_resets[];
extern const struct flag_type room_flags[];
extern const struct flag_type score_flags[];
extern const struct flag_type instrument_types[];
extern const struct flag_type sector_flags[];
extern const struct flag_type type_flags[];
extern const struct flag_type extra_flags[];
extern const struct flag_type wear_flags[];
extern const struct flag_type act_flags[];
extern const struct flag_type affect_flags[];
extern const struct flag_type apply_flags[];
extern const struct flag_type wear_loc_strings[];
extern const struct flag_type wear_loc_flags[];
extern const struct flag_type weapon_flags[];
extern const struct flag_type container_flags[];
extern const struct flag_type liquid_flags[];
extern const struct flag_type material_type[];
extern const struct flag_type form_flags[];
extern const struct flag_type part_flags[];
extern const struct flag_type ac_type[];
extern const struct flag_type size_flags[];
extern const struct flag_type off_flags[];
extern const struct flag_type imm_flags[];
extern const struct flag_type res_flags[];
extern const struct flag_type vuln_flags[];
extern const struct flag_type dam_flags[];
extern const struct flag_type pref_flags [];
extern const struct flag_type spell_flags [];
extern const struct flag_type position_flags[];
extern const struct flag_type weapon_class[];
extern const struct flag_type weapon_type_olc[];
extern const struct flag_type resist_flags[];
extern const struct flag_type spell_target_flags[];
extern const struct flag_type aff_where_flags[];
extern const struct flag_type aff_flags[];
extern const struct flag_type starting_weapon_flags[];
extern const struct flag_type spell_type_flags[];
extern const struct flag_type savingthrow_flags[];
extern const struct flag_type note_flags[];

#endif
