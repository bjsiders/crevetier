/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#include <sys/time.h>
#endif

#include <dlfcn.h>

#include "thoc.h"
#include "db.h"
#include "lookup.h"
#include "olc.h"
#include "tables.h"
#include "recycle.h"

/* values for db2.c */
struct		social_type	social_table		[MAX_SOCIALS];
int		social_count;
int		spell_count;

/* snarf a socials file */
void load_socials( FILE *fp)
{
    for ( ; ; ) 
    {
    	struct social_type social;
    	char *temp;
        /* clear social */
	social.char_no_arg = NULL;
	social.others_no_arg = NULL;
	social.char_found = NULL;
	social.others_found = NULL;
	social.vict_found = NULL; 
	social.char_not_found = NULL;
	social.char_auto = NULL;
	social.others_auto = NULL;

    	temp = fread_word(fp);
    	if (!strcmp(temp,"#0"))
	    return;  /* done */
#if defined(social_debug) 
	else 
	    fprintf(stderr,"%s\n\r",temp);
#endif

    	strcpy(social.name,temp);
    	fread_to_eol(fp);

	temp = fread_string_eol(fp);
	if (!strcmp(temp,"$"))
	     social.char_no_arg = NULL;
	else if (!strcmp(temp,"#"))
	{
	     social_table[social_count] = social;
	     social_count++;
	     continue; 
	}
        else
	    social.char_no_arg = temp;

        temp = fread_string_eol(fp);
        if (!strcmp(temp,"$"))
             social.others_no_arg = NULL;
        else if (!strcmp(temp,"#"))
        {
	     social_table[social_count] = social;
             social_count++;
             continue;
        }
        else
	    social.others_no_arg = temp;

        temp = fread_string_eol(fp);
        if (!strcmp(temp,"$"))
             social.char_found = NULL;
        else if (!strcmp(temp,"#"))
        {
	     social_table[social_count] = social;
             social_count++;
             continue;
        }
       	else
	    social.char_found = temp;

        temp = fread_string_eol(fp);
        if (!strcmp(temp,"$"))
             social.others_found = NULL;
        else if (!strcmp(temp,"#"))
        {
	     social_table[social_count] = social;
             social_count++;
             continue;
        }
        else
	    social.others_found = temp; 

        temp = fread_string_eol(fp);
        if (!strcmp(temp,"$"))
             social.vict_found = NULL;
        else if (!strcmp(temp,"#"))
        {
	     social_table[social_count] = social;
             social_count++;
             continue;
        }
        else
	    social.vict_found = temp;

        temp = fread_string_eol(fp);
        if (!strcmp(temp,"$"))
             social.char_not_found = NULL;
        else if (!strcmp(temp,"#"))
        {
	     social_table[social_count] = social;
             social_count++;
             continue;
        }
        else
	    social.char_not_found = temp;

        temp = fread_string_eol(fp);
        if (!strcmp(temp,"$"))
             social.char_auto = NULL;
        else if (!strcmp(temp,"#"))
        {
	     social_table[social_count] = social;
             social_count++;
             continue;
        }
        else
	    social.char_auto = temp;
         
        temp = fread_string_eol(fp);
        if (!strcmp(temp,"$"))
             social.others_auto = NULL;
        else if (!strcmp(temp,"#"))
        {
             social_table[social_count] = social;
             social_count++;
             continue;
        }
        else
	    social.others_auto = temp; 
	
	social_table[social_count] = social;
    	social_count++;
   }
   return;
}

void load_recipes( FILE *fp )
{
    Recipe *pRecIndex;
	int i;

    if ( !area_last )   /* OLC */
    {
        log_bug( "Load_recipes: no #AREA seen yet.", 0 );
        exit( 1 );
    }

 
    for ( ; ; )
    {
        sh_int vnum;
        char letter;
        int iHash;
 
        letter                          = fread_letter( fp );
        if ( letter != '#' )
        {
            log_bug( "Load_recipess: # not found.", 0 );
            exit( 1 );
        }
 
        vnum                            = fread_number( fp );
        if ( vnum == 0 )
            break;
 
        unsetenv("THOC_BOOTUP");
        fBootDb = FALSE;
        if ( get_recipe_index( vnum ) != NULL )
        {
            log_bug( "Load_recipes: vnum %d duplicated.", vnum );
            exit( 1 );
        }
        fBootDb = TRUE;
        setenv("THOC_BOOTUP","TRUE",0);
 
        pRecIndex                       = alloc_perm( sizeof(*pRecIndex) );
        pRecIndex->vnum                 = vnum;
        pRecIndex->area                 = area_last;               /* OLC */
		newrecipes++;

		pRecIndex->name					= fread_string(fp);
		if ( (pRecIndex->trade_skill			= skill_lookup( fread_string(fp) )) < 0 )
		{
			log_bug("Invalid trade skill found",0);
			pRecIndex->trade_skill = 0;
		}

		pRecIndex->foundation_skills	= fread_flag(fp);
		pRecIndex->result_vnum			= fread_number(fp);
		pRecIndex->fail_vnum			= fread_number(fp);
		pRecIndex->difficulty			= fread_number(fp);
		pRecIndex->trivial				= fread_number(fp);

		for( i=0 ; i<MAX_INGREDIENT ; i++ )
			pRecIndex->components[i] = fread_number(fp);

        iHash                   = vnum % MAX_KEY_HASH;
        pRecIndex->next         = recipe_index_hash[iHash];
        recipe_index_hash[iHash]   = pRecIndex;
        top_recipe_index++;
        top_vnum_recipe = top_vnum_recipe < vnum ? vnum : top_vnum_recipe;  /* OLC */
        assign_area_vnum( vnum );                                  /* OLC */
    }
 
    return;
}

void fread_spell_affects( FILE *fp, SpellIndex *pSpellIndex )
{
    int i;

    for(i=0;i<5;i++)
    {
        pSpellIndex->action.generic.affects[i].type         = pSpellIndex->vnum;
        pSpellIndex->action.generic.affects[i].where        = fread_number( fp );
        pSpellIndex->action.generic.affects[i].location     = fread_number( fp );
        pSpellIndex->action.generic.affects[i].modifier     = fread_number( fp );
        pSpellIndex->action.generic.affects[i].duration     = fread_number( fp );

        if ( pSpellIndex->action.generic.affects[i].location == APPLY_SKILL )
            pSpellIndex->action.generic.affects[i].misc     = skill_lookup( fread_word( fp ) );
        else
            pSpellIndex->action.generic.affects[i].misc     = fread_number( fp );

        pSpellIndex->action.generic.affects[i].flags        = fread_flag( fp );
        pSpellIndex->action.generic.affects[i].bitvector    = fread_flag( fp );
        pSpellIndex->description                            = fread_string( fp );

        if ( !str_cmp(pSpellIndex->description,"none") )
        {
            free_string( pSpellIndex->description );
            pSpellIndex->description = NULL;
        }
    }
}

/*
 * Snarf a spell list
 */
void load_spells( FILE *fp, char *filename )
{
	SpellFun 	*funcPtr;
	int			skill_sn;
	SpellIndex *pSpellIndex, *psi, *psi_next;
    int i;

    if ( !fBootDb )
        for(i=0;i<MAX_KEY_HASH;i++)
        {
            for( psi = spell_index_hash[i] ; psi != NULL ; psi = psi_next )
            {
                psi_next = psi->next;
                GC_FREE( psi );
            }
            spell_index_hash[i] = NULL;
        }
        
	for( ; ; )
	{
        sh_int vnum;
        char letter;
		int class_counter, iHash;
 
        letter = fread_letter( fp );

        if ( letter != '#' )
        {
            log_bug( "Load_spells: # not found.", 0 );
            exit( 1 );
        }
 
        vnum = fread_number( fp );
		if ( vnum == -1 )
			break;

        unsetenv("THOC_BOOTUP");
        fBootDb = FALSE;
		if ( get_spell_index( vnum ) != NULL )
        {
            log_bug( "Load_spells: vnum %d duplicated.", vnum );
            exit( 1 );
        }

        fBootDb = TRUE;
        setenv("THOC_BOOTUP","TRUE",0);
 
        pSpellIndex 		      	= (SpellIndex *) GC_MALLOC( sizeof(SpellIndex) );

		pSpellIndex->vnum			= vnum;
        pSpellIndex->name 		  	= fread_string( fp );
        pSpellIndex->full_name 		= fread_string( fp );
        pSpellIndex->short_descr    = fread_string( fp );
        pSpellIndex->description    = fread_string( fp );

		/* Read in gsn, skill, then spell fun */
        /* Read in skill and map to skill table */
        skill_sn = skill_lookup( fread_string( fp ) );
        if ( skill_sn < 1 )
        {
            log_bug( "Load_spells: no skill found for spell '%s'", pSpellIndex->name );
            pSpellIndex->sgsn = NULL;
        }
        else
            pSpellIndex->sgsn = skill_table[skill_sn].pgsn;

		// Read (and ignore) the gsn
		fread_string( fp );

		// The gsns will be assigned independently, and not looked up here at all.
	
        /* Finally, map the function */
        pSpellIndex->func_name = fread_string( fp );
        if ( !str_cmp(pSpellIndex->func_name,"generic") )
            pSpellIndex->spell_fun = spell_generic_driver;
        else   
        if ( ( funcPtr = (SpellFun *) dlsym( libspells, pSpellIndex->func_name ) ) == NULL )
            log_bug("No function found for %s",pSpellIndex->func_name);
        else {
			log_string("Function found for %s",pSpellIndex->func_name);
            pSpellIndex->spell_fun = funcPtr;
		}

        pSpellIndex->base_mana		= fread_number( fp );
        pSpellIndex->series		    = fread_number( fp );
        pSpellIndex->series_rank 	= fread_number( fp );

		for(class_counter = 0; class_counter < MAX_CLASS; class_counter++)
        	pSpellIndex->class_level[class_counter] = fread_number( fp );

        pSpellIndex->target   		= fread_number( fp );
        pSpellIndex->beats 	  		= fread_number( fp );
        pSpellIndex->recast   		= fread_number( fp );
        pSpellIndex->msg_damage		= fread_string( fp );
        pSpellIndex->incantation 	= fread_string( fp );
        pSpellIndex->gesture 		= fread_string( fp );
        pSpellIndex->msg_off 		= fread_string( fp );
        pSpellIndex->msg_obj 		= fread_string( fp );
		pSpellIndex->flags 			= fread_flag( fp );	
       
        //fread_spell_affects( fp, pSpellIndex ); 
        pSpellIndex->spell_type     = flag_value( spell_type_flags, fread_string(fp) );

        switch( pSpellIndex->spell_type )
        {
        case SPELL_BUFF:
            fread_spell_affects( fp, pSpellIndex );
            pSpellIndex->action.generic.okRoomEcho = fread_string( fp );
            pSpellIndex->action.generic.okVictimEcho = fread_string( fp );

            checkForNull( pSpellIndex->action.generic.okRoomEcho );
            checkForNull( pSpellIndex->action.generic.okVictimEcho );
            break;
    
        case SPELL_DEBUFF:
            fread_spell_affects( fp, pSpellIndex );
            pSpellIndex->action.generic.okRoomEcho = fread_string( fp );
            pSpellIndex->action.generic.okVictimEcho = fread_string( fp );
            pSpellIndex->action.generic.failRoomEcho = fread_string( fp );
            pSpellIndex->action.generic.failVictimEcho = fread_string( fp );
            pSpellIndex->action.generic.damType = flag_value( dam_flags, fread_string(fp) );
            pSpellIndex->action.generic.saveType = flag_value( savingthrow_flags, fread_string(fp) );

            checkForNull( pSpellIndex->action.generic.okRoomEcho );
            checkForNull( pSpellIndex->action.generic.okVictimEcho );
            checkForNull( pSpellIndex->action.generic.failRoomEcho );
            checkForNull( pSpellIndex->action.generic.failVictimEcho );

            break;
   
        case SPELL_BOLT:
            pSpellIndex->action.generic.damType = flag_value( dam_flags, fread_string(fp) );
            pSpellIndex->action.generic.saveType = flag_value( savingthrow_flags, fread_string(fp) );
            pSpellIndex->action.generic.lowDamage = fread_number( fp );
            pSpellIndex->action.generic.highDamage = fread_number( fp );
            pSpellIndex->action.generic.range = fread_number( fp );
            break;
 
        case SPELL_NUKE:
            pSpellIndex->action.generic.damType = flag_value( dam_flags, fread_string(fp) );
            pSpellIndex->action.generic.saveType = flag_value( savingthrow_flags, fread_string(fp) );
            pSpellIndex->action.generic.lowDamage = fread_number( fp );
            pSpellIndex->action.generic.highDamage = fread_number( fp );
            break;
    
        case SPELL_COMBO_NUKE:
            fread_spell_affects( fp, pSpellIndex );
            pSpellIndex->action.generic.okRoomEcho = fread_string( fp );
            pSpellIndex->action.generic.okVictimEcho = fread_string( fp );
            pSpellIndex->action.generic.failRoomEcho = fread_string( fp );
            pSpellIndex->action.generic.failVictimEcho = fread_string( fp );
            pSpellIndex->action.generic.damType = flag_value( dam_flags, fread_string(fp) );
            pSpellIndex->action.generic.saveType = flag_value( savingthrow_flags, fread_string(fp) );
            pSpellIndex->action.generic.lowDamage = fread_number( fp );
            pSpellIndex->action.generic.highDamage = fread_number( fp );

            checkForNull( pSpellIndex->action.generic.okRoomEcho );
            checkForNull( pSpellIndex->action.generic.okVictimEcho );
            checkForNull( pSpellIndex->action.generic.failRoomEcho );
            checkForNull( pSpellIndex->action.generic.failVictimEcho );

            break;
    
        default:
			break;
        }

        pSpellIndex->filename       = str_dup( filename );
		spell_count++;

		iHash = vnum % MAX_KEY_HASH;
		pSpellIndex->next = spell_index_hash[iHash];
		spell_index_hash[iHash] = pSpellIndex;
		top_spell_index++;
        top_spell_vnum = UMAX(vnum,top_spell_vnum);
	}

	return;
}

/*
 * Snarf a mob section.  new style
 */
void load_mobiles( FILE *fp )
{
    MobIndex *pMobIndex;
	int i;

    if ( !area_last )   /* OLC */
    {
        log_bug( "Load_mobiles: no #AREA seen yet.", 0 );
        exit( 1 );
    }

 
    for ( ; ; )
    {
        sh_int vnum;
        char letter;
        int iHash;
 
        letter                          = fread_letter( fp );
        if ( letter != '#' )
        {
            log_bug( "Load_mobiles: # not found.", 0 );
            exit( 1 );
        }
 
        vnum                            = fread_number( fp );
        if ( vnum == 0 )
            break;
 
        unsetenv("THOC_BOOTUP");
        fBootDb = FALSE;
        if ( get_mob_index( vnum ) != NULL )
        {
            log_bug( "Load_mobiles: vnum %d duplicated.", vnum );
            exit( 1 );
        }
        fBootDb = TRUE;
        setenv("THOC_BOOTUP","TRUE",0);
 
        pMobIndex                       = alloc_perm( sizeof(*pMobIndex) );
        pMobIndex->vnum                 = vnum;
        pMobIndex->area                 = area_last;               /* OLC */
		pMobIndex->new_format		= TRUE;
		newmobs++;
		pMobIndex->version				= fread_number( fp );
        pMobIndex->player_name          = fread_string( fp );
        pMobIndex->short_descr          = fread_string( fp );
        pMobIndex->long_descr           = fread_string( fp );
        pMobIndex->description          = fread_string( fp );
		pMobIndex->spawn_echo			= fread_string( fp );
		if ( !str_cmp(pMobIndex->spawn_echo,"(null)"))
				pMobIndex->spawn_echo = NULL;

		pMobIndex->attack_echo			= fread_string( fp );
		pMobIndex->death_echo			= fread_string( fp );

		if( strlen(pMobIndex->attack_echo) < 5 )
		{
			free_string(pMobIndex->attack_echo);
			pMobIndex->attack_echo = NULL;
		}

        if( strlen(pMobIndex->death_echo) < 5 )
        {
            free_string(pMobIndex->death_echo);
            pMobIndex->death_echo = NULL;
        }

		if ( pMobIndex->spawn_echo != NULL && strlen(pMobIndex->spawn_echo ) < 5 )
		{
			free_string(pMobIndex->spawn_echo);
			pMobIndex->spawn_echo = NULL;
		}

	pMobIndex->race		 	= race_lookup(fread_string( fp ));
	{
		char *tmp;

  		pMobIndex->class		= class_lookup(tmp=fread_string( fp ));
		if (!strcmp(tmp,"wizard"))
			pMobIndex->class = class_lookup("mage");
		else if (!strcmp(tmp,"sorcerer"))
			pMobIndex->class = class_lookup("necromancer");
		else if (!strcmp(tmp,"arcanist"))
			pMobIndex->class = class_lookup("enchanter");
        pMobIndex->class = URANGE(0,pMobIndex->class,15); 

	}

        pMobIndex->long_descr[0]        = UPPER(pMobIndex->long_descr[0]);
        pMobIndex->description[0]       = UPPER(pMobIndex->description[0]);
 
        pMobIndex->act                  = fread_flag( fp ) | ACT_IS_NPC
					| race_table[pMobIndex->race].act;

		if ( pMobIndex->version < 2 )
		{
			REMOVE_BIT( pMobIndex->act, bb );
			REMOVE_BIT( pMobIndex->act, K );
		}

        pMobIndex->affected_by          = fread_flag( fp )
					| race_table[pMobIndex->race].aff;
        pMobIndex->pShop                = NULL;
        pMobIndex->alignment            = fread_number( fp );
        pMobIndex->group                = fread_number( fp );

        pMobIndex->level                = fread_number( fp );
        pMobIndex->hitroll              = fread_number( fp );  

	/* read hit dice */
        pMobIndex->hit[DICE_NUMBER]     = fread_number( fp );  
        /* 'd'          */                fread_letter( fp ); 
        pMobIndex->hit[DICE_TYPE]   	= fread_number( fp );
        /* '+'          */                fread_letter( fp );   
        pMobIndex->hit[DICE_BONUS]      = fread_number( fp ); 

 	/* read mana dice */
	pMobIndex->mana[DICE_NUMBER]	= fread_number( fp );
					  fread_letter( fp );
	pMobIndex->mana[DICE_TYPE]	= fread_number( fp );
					  fread_letter( fp );
	pMobIndex->mana[DICE_BONUS]	= fread_number( fp );

	/* read damage dice */
	pMobIndex->damage[DICE_NUMBER]	= fread_number( fp );
					  fread_letter( fp );
	pMobIndex->damage[DICE_TYPE]	= fread_number( fp );
					  fread_letter( fp );
	pMobIndex->damage[DICE_BONUS]	= fread_number( fp );
	pMobIndex->dam_type		= attack_lookup(fread_word(fp));

	/* read armor class */
	pMobIndex->ac[AC_PIERCE]	= fread_number( fp );
	pMobIndex->ac[AC_BASH]		= fread_number( fp );
	pMobIndex->ac[AC_SLASH]		= fread_number( fp );
	pMobIndex->ac[AC_EXOTIC]	= fread_number( fp );

	/* Convert AC.  We basically need to invert it.  If we subtract
 	 * 100 from it and then reverse the sign, it's about right
	*/

	/* read flags and add in data from the race table */
	pMobIndex->off_flags		= fread_flag( fp ) 
					| race_table[pMobIndex->race].off;
	pMobIndex->imm_flags		= fread_flag( fp )
					| race_table[pMobIndex->race].imm;

    // Eat resist/vuln flags
    fread_flag(fp);
    fread_flag(fp);

	/* vital statistics */
	pMobIndex->start_pos		= position_lookup(fread_word(fp));
	pMobIndex->default_pos		= position_lookup(fread_word(fp));
	pMobIndex->sex			= sex_lookup(fread_word(fp));

	pMobIndex->wealth		= fread_number( fp );

	pMobIndex->form			= fread_flag( fp );

	if ( pMobIndex->version < 3 )
		pMobIndex->form |= race_table[pMobIndex->race].form;

	pMobIndex->parts		= fread_flag( fp );
					/*| race_table[pMobIndex->race].parts;*/

	/* size */
	pMobIndex->size			= size_lookup(fread_word(fp));

	for( i = 0 ; i < MAX_RESIST ; i++ )
		pMobIndex->resists[i] = fread_number(fp);

	/* check for factions */
	for( ; ; )
	{
		letter = fread_letter(fp);
		if( letter == 'F') /* got one */
		{
			Faction *f, *master;
			int id, standing;

			standing = fread_number(fp);
			id =  fread_number(fp);
			if ( (master = findFactionByID( factionList, id)) == NULL )
			{
				log_bug("Invalid faction id %d",id);
				continue;
			}

			f = cloneFaction( master );
			f->standing = standing;
			if ( (f->aggroPoint = fread_number(fp)) == 0 )
				f->aggroPoint = FACTION_AGGRESSIVE;
			if ( (f->passivePoint = fread_number(fp)) == 0 )
				f->passivePoint = FACTION_FRIENDLY; 

			f->next = pMobIndex->factions;
			pMobIndex->factions = f;
		}
		else
		{
			ungetc(letter,fp);
			break;
		}
	}
	pMobIndex->material		= str_dup(fread_word( fp ));
 
	for ( ; ; )
        {
            letter = fread_letter( fp );

            if (letter == 'F')
            {
		char *word;
		long vector;

                word                    = fread_word(fp);
		vector			= fread_flag(fp);

		if (!str_prefix(word,"act"))
		    REMOVE_BIT(pMobIndex->act,vector);
                else if (!str_prefix(word,"aff"))
		    REMOVE_BIT(pMobIndex->affected_by,vector);
		else if (!str_prefix(word,"off"))
		    REMOVE_BIT(pMobIndex->off_flags,vector);
		else if (!str_prefix(word,"imm"))
		    REMOVE_BIT(pMobIndex->imm_flags,vector);
		else if (!str_prefix(word,"for"))
		    REMOVE_BIT(pMobIndex->form,vector);
		else if (!str_prefix(word,"par"))
		    REMOVE_BIT(pMobIndex->parts,vector);
		else
		{
		    log_bug("Flag remove: flag not found.",0);
		    exit(1);
		}
	     }
	     else
	     {
		ungetc(letter,fp);
		break;
	     }
	}

        iHash                   = vnum % MAX_KEY_HASH;
        pMobIndex->next         = mob_index_hash[iHash];
        mob_index_hash[iHash]   = pMobIndex;
        top_mob_index++;
        top_vnum_mob = top_vnum_mob < vnum ? vnum : top_vnum_mob;  /* OLC */
        assign_area_vnum( vnum );                                  /* OLC */
        kill_table[URANGE(0, pMobIndex->level, MAX_LEVEL-1)].number++;
    }
 
    return;
}

/*
 * Snarf an obj section. new style
 */
void load_objects( FILE *fp )
{
    ObjIndex *pObjIndex;

    if ( !area_last )   /* OLC */
    {
        log_bug( "Load_objects: no #AREA seen yet.", 0 );
        exit( 1 );
    }
 
    for ( ; ; )
    {
        sh_int vnum;
        char letter;
        int iHash;

        letter                          = fread_letter( fp );

        if ( letter != '#' )
        {
            log_bug( "Load_objects: # not found.", 0 );
            exit( 1 );
        }

        vnum                            = fread_number( fp );
 	
        if ( vnum == 0 )
            break;
 
        unsetenv("THOC_BOOTUP");
        fBootDb = FALSE;
        if ( get_obj_index( vnum ) != NULL )
        {
            log_bug( "Load_objects: vnum %d duplicated.", vnum );
            exit( 1 );
        }
        fBootDb = TRUE;
        setenv("THOC_BOOTUP","TRUE",0);
 
        pObjIndex                       = alloc_perm( sizeof(*pObjIndex) );
        pObjIndex->vnum                 = vnum;
        pObjIndex->area                 = area_last;            /* OLC */
        pObjIndex->new_format           = TRUE;
	pObjIndex->reset_num		= 0;
	newobjs++;
		pObjIndex->version				= fread_number( fp );
        pObjIndex->name                 = fread_string( fp );
        pObjIndex->short_descr          = fread_string( fp );
        pObjIndex->description          = fread_string( fp );
        pObjIndex->material		= str_dup(fread_string( fp ));
 
        pObjIndex->item_type            = item_lookup(fread_word( fp ));
        pObjIndex->extra_flags          = fread_flag( fp );
        pObjIndex->wear_flags           = fread_flag( fp );

	switch(pObjIndex->item_type)
	{

	case ITEM_FORGE:
	{
	    
	    pObjIndex->value[0]		= fread_number(fp);
	    pObjIndex->value[1]		= fread_number(fp);
	    pObjIndex->value[2]		= skill_lookup( fread_word(fp) );
            pObjIndex->value[3]         = flag_value( forge_flags, fread_word(fp) );
            pObjIndex->value[4]             = fread_number( fp );
            pObjIndex->value[5]             = fread_number( fp );
            pObjIndex->value[6]             = fread_number( fp );
            pObjIndex->value[7]             = fread_number( fp );
            pObjIndex->value[8]             = fread_number( fp );
            pObjIndex->value[9]             = fread_number( fp );

	    pObjIndex->value[3] = UMAX(pObjIndex->value[3] ,0);
	    break;
	}

	case ITEM_LYRIC_SHEET:
	case ITEM_PRAYER_BOOK:
	case ITEM_ARCANE_SCROLL:

		if ( pObjIndex->item_type == ITEM_PRAYER_BOOK )
	    	pObjIndex->value[0] 	= spell_lookup(fread_word(fp),1);
		else
	    	pObjIndex->value[0] 	= spell_lookup(fread_word(fp),0);

	    pObjIndex->value[1]		= fread_number(fp);
	    pObjIndex->value[2]		= fread_number(fp);
	    pObjIndex->value[3]		= fread_number(fp);
	    pObjIndex->value[4]		= fread_number(fp);
	    pObjIndex->value[5]		= fread_number(fp);
	    pObjIndex->value[6]		= fread_number(fp);
	    pObjIndex->value[7]		= fread_number(fp);
	    pObjIndex->value[8]		= fread_number(fp);
	    pObjIndex->value[9]		= fread_number(fp);
	    break;

        case ITEM_SPELLBOOK:
	{
	    int i;
		int sn;

	    for (i=0;i<10;i++)
		{
			sn = spell_lookup(fread_word(fp),0);
			pObjIndex->value[i] = UMAX(0,sn);
		}
	}
	    break;
	case ITEM_WEAPON:
	    pObjIndex->value[0]		= weapon_type(fread_word(fp));
	    pObjIndex->value[1]		= fread_number(fp);
	    pObjIndex->value[2]		= fread_number(fp);
	    pObjIndex->value[3]		= attack_lookup(fread_word(fp));
	    pObjIndex->value[4]		= fread_flag(fp);
        pObjIndex->value[5]             = fread_number( fp );
        pObjIndex->value[6]             = fread_number( fp );
        pObjIndex->value[7]             = spell_lookup( fread_word( fp ), -1 );
        pObjIndex->value[8]             = fread_number( fp );
        pObjIndex->value[9]             = fread_number( fp );

	    break;

	case ITEM_MOBILE:
	case ITEM_CONTAINER:
	    pObjIndex->value[0]		= fread_number(fp);
	    pObjIndex->value[1]		= fread_flag(fp);
	    pObjIndex->value[2]		= fread_number(fp);
	    pObjIndex->value[3]		= fread_number(fp);
	    pObjIndex->value[4]		= fread_number(fp);
        pObjIndex->value[5]             = fread_number( fp );
        pObjIndex->value[6]             = fread_number( fp );
        pObjIndex->value[7]             = fread_number( fp );
        pObjIndex->value[8]             = fread_number( fp );
        pObjIndex->value[9]             = fread_number( fp );

	    break;
        case ITEM_DRINK_CON:
	case ITEM_FOUNTAIN:
            pObjIndex->value[0]         = fread_number(fp);
            pObjIndex->value[1]         = fread_number(fp);
            pObjIndex->value[2]         = liq_lookup(fread_word(fp));
            pObjIndex->value[3]         = fread_number(fp);
            pObjIndex->value[4]         = fread_number(fp);
        pObjIndex->value[5]             = fread_number( fp );
        pObjIndex->value[6]             = fread_number( fp );
        pObjIndex->value[7]             = fread_number( fp );
        pObjIndex->value[8]             = fread_number( fp );
        pObjIndex->value[9]             = fread_number( fp );

            break;
	case ITEM_WAND:
	case ITEM_STAFF:
	    pObjIndex->value[0]		= fread_number(fp);
	    pObjIndex->value[1]		= fread_number(fp);
	    pObjIndex->value[2]		= fread_number(fp);
	    pObjIndex->value[3]		= skill_lookup(fread_word(fp));
	    pObjIndex->value[4]		= fread_number(fp);
        pObjIndex->value[5]             = fread_number( fp );
        pObjIndex->value[6]             = fread_number( fp );
        pObjIndex->value[7]             = fread_number( fp );
        pObjIndex->value[8]             = fread_number( fp );
        pObjIndex->value[9]             = fread_number( fp );

	    break;
	case ITEM_POTION:
	case ITEM_PILL:
	case ITEM_SCROLL:
 	    pObjIndex->value[0]		= fread_number(fp);
	    pObjIndex->value[1]		= spell_lookup(fread_word(fp),-1);
	    pObjIndex->value[2]		= spell_lookup(fread_word(fp),-1);
	    pObjIndex->value[3]		= spell_lookup(fread_word(fp),-1);
	    pObjIndex->value[4]		= spell_lookup(fread_word(fp),-1);
        pObjIndex->value[5]             = fread_number( fp );
        pObjIndex->value[6]             = fread_number( fp );
        pObjIndex->value[7]             = fread_number( fp );
        pObjIndex->value[8]             = fread_number( fp );
        pObjIndex->value[9]             = fread_number( fp );

	    break;
	default:
            pObjIndex->value[0]             = fread_flag( fp );
            pObjIndex->value[1]             = fread_flag( fp );
            pObjIndex->value[2]             = fread_flag( fp );
            pObjIndex->value[3]             = fread_flag( fp );
	    pObjIndex->value[4]		    = fread_flag( fp );
        pObjIndex->value[5]             = fread_flag( fp );
        pObjIndex->value[6]             = fread_flag( fp );
        pObjIndex->value[7]             = fread_flag( fp );
        pObjIndex->value[8]             = fread_flag( fp );
        /*if ( pObjIndex->item_type != ITEM_ARMOR )*/
		pObjIndex->value[9]             = fread_flag( fp );

	    break;
	}

	pObjIndex->level		= fread_number( fp );
        pObjIndex->weight               = fread_number( fp );
        pObjIndex->cost                 = fread_number( fp ); 

        /* condition */

		/* Cond/dur/qua */
		pObjIndex->condition	= fread_number( fp );
		pObjIndex->durability	= fread_number( fp );
		pObjIndex->quality		= fread_number( fp );

		pObjIndex->deity		= deity_lookup( fread_string( fp ) );	
		pObjIndex->deity		= UMAX(0,pObjIndex->deity);

        for ( ; ; )
        {
            char letter;
 
            letter = fread_letter( fp );
 
            if ( letter == 'A' )
            {
                Affect *paf;
 
                paf                     = alloc_perm( sizeof(*paf) );
				paf->where		= TO_OBJECT;
                paf->type               = -1;
                paf->level              = pObjIndex->level;
                paf->duration           = -1;
                paf->location           = fread_number( fp );
                paf->modifier           = fread_number( fp );
				paf->misc				= skill_lookup( fread_word( fp ) );
                paf->bitvector          = 0;
                paf->next               = pObjIndex->affected;
                pObjIndex->affected     = paf;
                top_affect++;
            }

	    	else if (letter == 'F')
            {
                Affect *paf;
 
                paf                     = alloc_perm( sizeof(*paf) );
				letter 			= fread_letter(fp);
				switch (letter)
	 			{
					case 'A':
                    	paf->where          = TO_AFFECTS;
		    			break;
					case 'I':
		    			paf->where		= TO_IMMUNE;
		    			break;
					case 'R':
		    			paf->where		= TO_RESIST;
		    			break;
					case 'V':
		    			paf->where		= TO_VULN;
		    			break;
					default:
            	    	log_bug( "Load_objects: Bad where on flag set.", 0 );
            	   		exit( 1 );
				}
                paf->type               = -1;
                paf->level              = pObjIndex->level;
                paf->duration           = -1;
                paf->location           = fread_number(fp);
                paf->modifier           = fread_number(fp);
                paf->bitvector          = fread_flag(fp);
                paf->next               = pObjIndex->affected;
                pObjIndex->affected     = paf;
                top_affect++;
            }
 
            else if ( letter == 'E' )
            {
                ExtraDescr *ed;
 
                ed                      = alloc_perm( sizeof(*ed) );
                ed->keyword             = fread_string( fp );
                ed->description         = fread_string( fp );
                ed->next                = pObjIndex->extra_descr;
                pObjIndex->extra_descr  = ed;
                top_ed++;
            }
 
            else
            {
                ungetc( letter, fp );
                break;
            }
        }

        iHash                   = vnum % MAX_KEY_HASH;
        pObjIndex->next         = obj_index_hash[iHash];
        obj_index_hash[iHash]   = pObjIndex;
        top_obj_index++;
        top_vnum_obj = top_vnum_obj < vnum ? vnum : top_vnum_obj;   /* OLC */
        assign_area_vnum( vnum );                                   /* OLC */
	
    }
 
    return;
}

// Load timezone file
void load_timezones( void )
{
    FILE *fp;
    char buf[MAX_INPUT_LENGTH];
    char *pCode, *pDesc;
    int index=0;

    if ( (fp = fopen( TIMEZONE_FILE, "r")) == NULL )
    {
        log_error("Could not open %s", TIMEZONE_FILE );
        return;
    }

    /* Create timezone table */
    tzTable = (TimeZone *) alloc_perm( sizeof(TimeZone) * 300 );

    while( fgets(buf,sizeof(buf),fp) )
    {
        pCode = buf;
        pDesc = strchr( buf, '|' );
        *pDesc = '\0';
        ++pDesc;
        *(pDesc + strlen(pDesc) - 1) = '\0';
        tzTable[index].zone_description = str_dup( pDesc );
        tzTable[index].zone_environment = str_dup( pCode );
        index++;
    }

    top_timezone = index-1;
    tzTable[index].zone_description = NULL;
    tzTable[index].zone_environment = NULL;

    fclose(fp);
    return;
}

