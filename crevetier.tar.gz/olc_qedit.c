/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include <sys/types.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "thoc.h"
#include "olc.h"
#include "tables.h"
#include "lookup.h"
#include "recycle.h"

QEDIT( qedit_require )
{
	Quest *pQuest;
	int index;
	ObjIndex *obj;
	char arg[MAX_INPUT_LENGTH];

	EDIT_QUEST(ch,pQuest);

	argument = one_argument( argument, arg );
	if ( arg[0] == '\0' || *argument == '\0' )
	{
		cprintf(ch,"Usage: require <#> <vnum>\n\r");
		return FALSE;
	}

	if ( (index=atoi(arg)) < 1 || index > 10 )
	{
		cprintf(ch,"Rquired # must be between 1 and 10 inclusive.\n\r");
		return FALSE;
	}

	--index; /* C offsets start at 0 */
	if ( atoi(argument) < 0 )
	{
		cprintf(ch,"Required vnum must be positive.\n\r");
		return FALSE;
	}

	obj = get_obj_index( pQuest->required[index] = atoi(argument) );

	cprintf(ch,"Required slot #%d set to vnum %d.\n\r",
		index+1, pQuest->required[index] );
	if ( obj == NULL)
		cprintf(ch,"Warning: no object has been assigned to this vnum yet.\n\r");
	else
		cprintf(ch,"Required #%d is %s.\n\r", index+1, obj->short_descr );

	return TRUE;
}


QEDIT( qedit_deity )
{
	int deity;
	Quest *pQuest;
	int i;

	EDIT_QUEST(ch,pQuest);

	if ( !strcmp(argument,"all") )
	{
		for ( i = 0 ; deity_table[i].name != NULL ; i++ )
			pQuest->deity_avail[i] = TRUE;
		cprintf(ch,"Quest enabled for ALL deities.\n\r");
		return TRUE;
	}

	if ( !strcmp(argument,"none"))
	{
		for( i = 0 ; deity_table[i].name != NULL ; i++ )
			pQuest->deity_avail[i] = FALSE;
		cprintf(ch,"Quest disabled for ALL deities.\n\r");
		return TRUE;
	}

	if ( (deity = deity_lookup(argument)) < 0 )
	{
		cprintf(ch,"[%s] is not a valid deity.\n\r",argument);
		return FALSE;
	}

	pQuest->deity_avail[deity] = !pQuest->deity_avail[deity];
	cprintf(ch,"Quest is now %sabled for %s.\n\r",
		pQuest->deity_avail[deity] ? "en" : "dis", deity_table[deity].name );
	return TRUE;
}

QEDIT( qedit_class )
{
	int class;
	Quest *pQuest;
	int i;

	EDIT_QUEST(ch,pQuest);

	if ( !strcmp(argument,"all") )
	{
		for ( i = 0 ; i < MAX_CLASS ; i++ )
			pQuest->class_avail[i] = TRUE;
		cprintf(ch,"Quest enabled for ALL classes.\n\r");
		return TRUE;
	}

	if ( !strcmp(argument,"none"))
	{
		for( i = 0 ; i < MAX_CLASS ; i++ )
			pQuest->class_avail[i] = FALSE;
		cprintf(ch,"Quest disabled for ALL classes.\n\r");
		return TRUE;
	}

	if ( (class = class_lookup(argument)) < 0 )
	{
		cprintf(ch,"[%s] is not a valid class.\n\r",argument);
		return FALSE;
	}

	pQuest->class_avail[class] = !pQuest->class_avail[class];
	cprintf(ch,"Quest is now %sabled for %s.\n\r",
		pQuest->class_avail[class] ? "en" : "dis", class_table[class].name );
	return TRUE;
}

QEDIT( qedit_race )
{
	int race;
	Quest *pQuest;
	int i;

	EDIT_QUEST(ch,pQuest);

	if ( !strcmp(argument,"all") )
	{
		for ( i = 1 ; race_table[i].pc_race ; i++ )
			pQuest->race_avail[i] = TRUE;
		cprintf(ch,"Quest enabled for ALL races.\n\r");
		return TRUE;
	}

	if ( !strcmp(argument,"none"))
	{
		for( i = 1 ; race_table[i].pc_race ; i++ )
			pQuest->race_avail[i] = FALSE;
		cprintf(ch,"Quest disabled for ALL races.\n\r");
		return TRUE;
	}

	if ( (race = race_lookup(argument)) < 0 || !race_table[race].pc_race )
	{
		cprintf(ch,"[%s] is not a valid PC race.\n\r",argument);
		return FALSE;
	}

	pQuest->race_avail[race] = !pQuest->race_avail[race];
	cprintf(ch,"Quest is now %sabled for %s.\n\r",
		pQuest->race_avail[race] ? "en" : "dis", race_table[race].name );
	return TRUE;
}

	
QEDIT( qedit_show )
{
	int i;
	bool fAll, fNone;
	char	tmpString[MAX_STRING_LENGTH];
	Quest *pQuest;
	ObjIndex *result = NULL;

	EDIT_QUEST(ch,pQuest);
	if ( pQuest->reward_vnum > 0 )
		result = get_obj_index( pQuest->reward_vnum );

	cprintf(ch,"Vnum:         [%d]\n\r", pQuest->vnum );
	cprintf(ch,"Name/Journal: [%s]\n\r", pQuest->name );
	cprintf(ch,"Keyword:      [%s]\n\r", pQuest->keyword );
	cprintf(ch,"Short:        [The mob says '%s']\n\r", pQuest->short_descr );
	cprintf(ch,"Long:         [The mob says '%s']\n\r", pQuest->long_descr );
	cprintf(ch,"Flags:        [%s] (%s)\n\r", flag_string( quest_flags, pQuest->flags ), print_flags( pQuest->flags ) );
	cprintf(ch,"Greeting:     [%s]\n\r", pQuest->hint );
	cprintf(ch,"Farewell:     [%s]\n\r", pQuest->goodbye );


	cprintf(ch,"Requirements:\n");
    for( i=0 ; i < MAX_INGREDIENT ; i++ )
    {
        ObjIndex *obj = NULL;

        if ( pQuest->required[i] > 0 )
            obj = get_obj_index( pQuest->required[i] );

        cprintf(ch," * Component %2d   [%d:%s]\n\r",
            i+1, pQuest->required[i], obj !=NULL ? obj->short_descr : "null object" );
    }
	cprintf(ch," * Min Level:           [%d]\n", pQuest->min_level );
	cprintf(ch," * Max Level:           [%d]\n", pQuest->max_level );
	/* Handle race requirement */
	fAll = TRUE;
	fNone = TRUE;
	tmpString[0] = 0;
	for( i=1 ; race_table[i].pc_race ; i++ )
		if ( !pQuest->race_avail[i] )
			fAll = FALSE;
		else
		{
			fNone = FALSE;
			strcat(tmpString," ");
			strcat(tmpString,race_table[i].name);
		}
	cprintf(ch," * Race Must Be:      [%s]\n", fAll ? " -- any -- " : fNone ? " -- NONE -- " : tmpString );

	fAll = TRUE;
	fNone = TRUE;
	tmpString[0] = 0;
	for( i=0 ; i < MAX_CLASS ; i++ )
		if ( !pQuest->class_avail[i] )
			fAll = FALSE;
		else
		{
			fNone = FALSE;
			strcat(tmpString," ");
			strcat(tmpString,class_table[i].name);
		}
	cprintf(ch," * Class Must Be:     [%s]\n", fAll ? " -- any -- " : fNone ? " -- NONE -- " : tmpString );

	fAll = TRUE;
	fNone = TRUE;
	tmpString[0] = 0;
	for( i=0 ; deity_table[i].name != NULL ; i++ )
		if ( !pQuest->deity_avail[i] )
			fAll = FALSE;
		else
		{
			fNone = FALSE;
			strcat(tmpString," ");
			strcat(tmpString,deity_table[i].name);
		}
	cprintf(ch," * Deity Must Be:    [%s]\n", fAll ? " -- any -- " : fNone ? " -- NONE -- " : tmpString );
	for( i=0; i < MAX_QUEST_FACTION ; i++ )
	{
		if ( pQuest->faction_avail[i].faction != NULL )
			cprintf(ch," * Requires at least %d faction rating with %s.\n\r", pQuest->faction_avail[i].amount, pQuest->faction_avail[i].faction);
	}

	cprintf(ch," == REWARDS ==\n\r");
	cprintf(ch," * Object               [%d:%s]\n", result != NULL ? result->vnum : 0, 
												result != NULL ? result->short_descr : "none" );
	for( i=0 ; i < MAX_CURRENCY ; i++ )
		cprintf(ch," * %-20s [%d]\n", currency_table[i].name, pQuest->reward_coins[i] );

	cprintf(ch," * Experience:          [%d]\n", pQuest->reward_experience );

	for( i=0; i < MAX_QUEST_FACTION ; i++ )
	{
		if ( pQuest->faction_hits[i].faction != NULL )
			cprintf(ch," * Adjusts faction with %s by %+d\n\r", pQuest->faction_hits[i].faction, pQuest->faction_hits[i].amount );
	}
	return TRUE;
}

QEDIT( qedit_coins )
{
	char	arg[MAX_STRING_LENGTH];
	int		coin;
	int		amount;
	Quest *pQuest;
	
	EDIT_QUEST(ch,pQuest);

	argument = one_argument( argument, arg );
	if ( *argument == '\0' || arg[0] == '\0' )
	{
		cprintf(ch,"Syntax:  coins [type] [amount]\n\r");
		return FALSE;
	}

	if ( (coin = currency_lookup( arg )) < 0 )
	{
		cprintf(ch,"No such currency [%s].\n\r", arg );
		return FALSE;
	}

	if( (amount = atoi(argument)) < 0 )
	{
		cprintf(ch,"Amount must be at least 0.\n\r");
		return FALSE;
	}

	pQuest->reward_coins[coin] = amount;
	cprintf(ch,"Quest now yields %d %s coin%s.\n\r",
		amount, currency_table[coin].name,
		amount == 1 ? "" : "s" );
	return TRUE;
}

QEDIT( qedit_reward )
{
	Quest *pQuest;
	ObjIndex *obj;
	int vnum;

	EDIT_QUEST(ch,pQuest);

	if ( (vnum = atoi(argument)) < 0 )
	{
		cprintf(ch,"Vnum must be positive.\n\r");
		return FALSE;
	}

	obj = get_obj_index( vnum );

	cprintf(ch,"Object reward vnum set to %d.\n\r",vnum);
	if ( obj == NULL )
		cprintf(ch,"Warning: no object has this vnum.\n\r");
	else
		cprintf(ch,"Result object is %s.\n\r", obj->short_descr);

	pQuest->reward_vnum = vnum;
	return TRUE;
}

QEDIT( qedit_experience )
{
	Quest *pQuest;
	int exp;

	EDIT_QUEST(ch,pQuest);

	if ( (exp = atoi(argument)) < 0 )
	{
		cprintf(ch,"Experience reward must be at least 0.\n\r");
		return FALSE;
	}

	pQuest->reward_experience = exp;
	cprintf(ch,"Experience reward set to %d.\n\r", exp );
	return TRUE;
}

QEDIT( qedit_maxlevel )
{
	Quest *pQuest;
	int mlevel;

	EDIT_QUEST(ch,pQuest);

	if ( (mlevel = atoi(argument)) > 51 || mlevel < pQuest->min_level )
	{
		cprintf(ch,"Maximum level must be between %d (max level) and 51.\n\r", pQuest->max_level );
		return FALSE;
	}

	pQuest->max_level = mlevel;
	cprintf(ch,"Maximum level set to %d.\n\r", mlevel );
	return TRUE;
}

QEDIT( qedit_minlevel )
{
	Quest *pQuest;
	int mlevel;

	EDIT_QUEST(ch,pQuest);

	if ( (mlevel = atoi(argument)) < 0 || mlevel > pQuest->max_level )
	{
		cprintf(ch,"Minimum level must be between 0 and %d (max level).\n\r", pQuest->max_level );
		return FALSE;
	}

	pQuest->min_level = mlevel;
	cprintf(ch,"Minimum level set to %d.\n\r", mlevel );
	return TRUE;
}

QEDIT( qedit_create )
{
    Quest *pQuest;
    Area *pArea;
    int  value;
    int  iHash;

    value = atoi( argument );
    if ( argument[0] == '\0' || value == 0 )
    {
		send_to_char( "Syntax:  qedit create [vnum]\n\r", ch );
		return FALSE;
    }

    pArea = get_vnum_area( value );

    if ( !pArea )
    {
		send_to_char( "QEdit:  That vnum is not assigned an area.\n\r", ch );
		return FALSE;
    }

    if ( !IS_BUILDER( ch, pArea ) )
    {
		send_to_char( "QEdit:  Vnum in an area you cannot build in.\n\r", ch );
		return FALSE;
    }

    if ( get_quest_index( value ) )
    {
		send_to_char( "QEdit:  Mobile vnum already exists.\n\r", ch );
		return FALSE;
    }

    pQuest	= new_quest_index();
    pQuest->vnum			= value;
    pQuest->area			= pArea;
        
    if ( value > top_vnum_quest )
		top_vnum_quest = value;        

    iHash			= value % MAX_KEY_HASH;
    pQuest->next_index			= quest_index_hash[iHash];
    quest_index_hash[iHash]	= pQuest;
    ch->desc->pEdit		= (void *)pQuest;

    send_to_char( "Quest Created.\n\r", ch );
    return TRUE;
}

QEDIT( qedit_short_descr )
{
	Quest *pQuest;

	EDIT_QUEST(ch, pQuest);

    if ( argument[0] == '\0' )
    {
		send_to_char( "Syntax:  short [string]\n\r", ch );
		return FALSE;
    }

    free_string( pQuest->short_descr );
    pQuest->short_descr = str_dup( argument );

    cprintf( ch, "Short description set to [%s].\n\r", pQuest->short_descr );
    return TRUE;
}

QEDIT( qedit_greeting )
{
	Quest *pQuest;

	EDIT_QUEST(ch, pQuest);

    if ( argument[0] == '\0' )
    {
		send_to_char( "Syntax:  greeting [string]\n\r", ch );
		return FALSE;
    }

    free_string( pQuest->hint );
    pQuest->hint = str_dup( argument );

    cprintf( ch, "Greeting set to [%s].\n\r", pQuest->hint );
    return TRUE;
}

QEDIT( qedit_farewell )
{
	Quest *pQuest;

	EDIT_QUEST(ch, pQuest);

    if ( argument[0] == '\0' )
    {
		send_to_char( "Syntax:  farewell [string]\n\r", ch );
		return FALSE;
    }

    free_string( pQuest->goodbye );
    pQuest->goodbye = str_dup( argument );

    cprintf( ch, "Farewell set to [%s].\n\r", pQuest->goodbye );
    return TRUE;
}

QEDIT( qedit_long_descr )
{
	Quest *pQuest;

	EDIT_QUEST(ch, pQuest);

    if ( argument[0] == '\0' )
    {
		send_to_char( "Syntax:  long [string]\n\r", ch );
		return FALSE;
    }

    free_string( pQuest->long_descr );
    pQuest->long_descr = str_dup( argument );

    cprintf( ch, "Long description set to [%s].\n\r", pQuest->long_descr );
    return TRUE;
}

QEDIT( qedit_keyword )
{
	Quest *pQuest;

	EDIT_QUEST(ch, pQuest);

    if ( argument[0] == '\0' )
    {
		send_to_char( "Syntax:  keyword [string]\n\r", ch );
		return FALSE;
    }

    free_string( pQuest->keyword );
    pQuest->keyword = str_dup( argument );

    cprintf( ch, "Keyword set to [%s].\n\r", pQuest->keyword );
    return TRUE;
}

QEDIT( qedit_name )
{
	Quest *pQuest;

	EDIT_QUEST(ch, pQuest);

    if ( argument[0] == '\0' )
    {
		send_to_char( "Syntax:  name [string]\n\r", ch );
		return FALSE;
    }

    free_string( pQuest->name );
    pQuest->name = str_dup( argument );

    cprintf( ch, "Name set to [%s].\n\r", pQuest->name );
    return TRUE;
}

QEDIT( qedit_flags )          /* Moved out of medit() due to naming conflicts -- Hugin */
{
    Quest *pQuest;
    int value;    

    if ( argument[0] != '\0' )
    { 
    	EDIT_QUEST( ch, pQuest );

    	if ( ( value = flag_value( quest_flags, argument ) ) != NO_FLAG )
    	{
        	pQuest->flags ^= value;
	
        	send_to_char( "Quest flag toggled.\n\r", ch);
        	return TRUE;
    	}
    }

    send_to_char( "Syntax:     flags [flag]\n\r"
				  "Flags are:  private one_timer\n\r", ch );
    return FALSE;
}

QEDIT( qedit_faction )
{
	Quest *pQuest;
	char arg[MAX_STRING_LENGTH];
	char arg2[MAX_STRING_LENGTH];
	bool fReq, fHit;

	if ( *argument == '\0' )
	{
		cprintf(ch,"Syntax  :  faction <hit|require> '<faction name>' <amount or 'delete'>\n\r"
			   "Eaxmples:\n\r"
               "  > faction require 'khavanov g' 5000 (require at least 5K khavanov guard faction)\n\r"
               "  > faction hit 'blackf' -50 (lose 50 faction with blackfang gnolls)\n\r"
			   "  > faction hit 'bjarma' delete (remove faction hit to bjarma kaan from quest)\n\r"
               "  > faction req blackf delete (remove minimum faction with blackfang from quest)\n\r"
			   "\n\r(See 'help factionrank' for details on faction numbers and rank names)\n\r");
		return FALSE;
	}

	EDIT_QUEST( ch, pQuest );

	argument = one_argument( argument, arg );

	fReq = !str_prefix(arg,"require");
	fHit = !str_prefix(arg,"hit");
	if ( fReq || fHit )
	{
		Faction *f;
		int i;

		argument = one_argument( argument, arg2 );
		if ( (f = factionLookup( arg2 )) == NULL )
		{
			cprintf(ch,"Such a faction does not exist.\n\r");
			return FALSE;
		}

		if ( !str_cmp(argument,"delete"))
		{
			for( i=0; i < MAX_QUEST_FACTION; i++ )
			{
				if ( !str_cmp( pQuest->faction_hits[i].faction,f->name) && fHit )
				{
					cprintf(ch,"Removing faction hit for %s.\n\r", f->name);
					pQuest->faction_hits[i].faction = NULL;
					pQuest->faction_hits[i].amount  = 0;
					return TRUE;
				}
				else
				if ( !str_cmp( pQuest->faction_avail[i].faction,f->name) && fReq )
				{
					cprintf(ch,"Removing faction requirement for %s.\n\r", f->name);
					pQuest->faction_avail[i].faction = NULL;
					pQuest->faction_avail[i].amount  = 0;
					return TRUE;
				}
			}
			cprintf(ch,"Unable to find a %s for faction %s.\n\r", fHit ? "hit" : "requirement", f->name );
			return FALSE;
		}
		else
		if ( is_number(argument) )
		{
			int amount = atoi(argument);

			if ( amount == 0 )
			{
				cprintf(ch,"Amount has to be non-zero.\n\r");
				return FALSE;
			}

			for( i=0 ; i<MAX_QUEST_FACTION ; i++ )
			{
				if ( fHit && pQuest->faction_hits[i].faction == NULL )
				{
					pQuest->faction_hits[i].faction = f->name;
					pQuest->faction_hits[i].amount  = amount;
					cprintf(ch," * Faction adjustment of %+d added for %s.\n\r", amount, f->name );
					return TRUE;
				}
				else
				if ( fReq && pQuest->faction_avail[i].faction == NULL )
				{
					pQuest->faction_avail[i].faction = f->name;
					pQuest->faction_avail[i].amount  = amount;
					cprintf(ch," * Faction requirement of at least %d added for %s.\n\r", amount, f->name );
					return TRUE;
				}
			}
			cprintf(ch,"No room to add that faction %s!\n\r", fHit ? "hit" : "requirement" );
			return FALSE;
		}
		else
			/* syntax error */
			return qedit_faction( ch, "" );
	}
	else
		return qedit_faction(ch,"");
}
