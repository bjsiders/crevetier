/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

#include "thoc.h"
#include "interp.h"
#include "recycle.h"
#include "olc.h"
#include "lookup.h"
#include "spawn.h"
#include "bank.h"

long default_flags =  GCOP_DISSOLVE | GCOP_INVITE | GCOP_PASSWORD | GCOP_UPGRADE |
                      GCOP_RANK | GCOP_REMOVE | GCOP_SET | GCOP_USE_GUILDCHAT |
 				      GCOP_USE_ALLYCHAT | GCOP_DEPOSIT | GCOP_WITHDRAW | GCOP_CONVERT |
					  GCOP_CLAIM | GCOP_BUILD | GCOP_DEMOLISH | GCOP_HALL;

/* Guild cost in electrum coins */
void checkImproveTradeSkill( Character *ch, int skill, double chance, bool fSuccess );
int createBuilding( int type, Clan *clan, Room *room );

#define COST_NEW_GUILD	(1 * 100 * 100)

void toggleRankBit( Clan *clan, int rank, long bit )
{
	rank--;

	TOGGLE_BIT(clan->ranks[rank].flags,bit);
	return;
}

void setRankTitle( Clan *clan, int rank, char *argument )
{
	rank--;

	if ( clan->ranks[rank].name )
		free_string( clan->ranks[rank].name );

	clan->ranks[rank].name = str_dup( argument );
	return;
}

void disband_clan( Clan *c )
{
	Descriptor *d;
	Clan *loner, *vc;
	char	buf[MAX_STRING_LENGTH];
	Character *ch;

	if ( c == NULL )
	{
		log_bug("NULL clan in disband_clan",0);
		return;
	}

	loner = clan_lookup("loner");
	for( d = descriptor_list ; d ; d = d->next )
	{
		if ( (ch = d->character) == NULL || d->connected != CON_PLAYING )
			continue;

		if ( ch->clan == c )
		{
			ch->clan = loner;
			setRank( ch, 9 );
			cprintf(ch," **** You are now a Loner ****\n\r");
			if ( ch->in_room->clan == c ) 
			{
				act("$n vanishes suddenly!",ch,NULL,NULL,TO_ROOM);
				char_from_room( ch );
				char_to_room( ch, get_room_index( ch->clan->hall ) );
				act("$n materializes before you.",ch,NULL,NULL,TO_ROOM);
				do_look(ch,"auto");
			}
		}
	}

	if ( clan_table == c )
		clan_table = c->next;
	else
	{
		for( vc = clan_table ; vc != NULL ; vc = vc->next )
			if ( vc->next == c )
				break;

		if ( !vc )
			log_bug("Unable to remove clan from clan_table.",0);
		else
			vc->next = c->next;
	}

	free_clan( c );
	sprintf(buf," *** Clan %s has been dissolved. ***",c->name);
	wiznet(buf,NULL,NULL,WIZ_GUILDS,0,0);
	pnet(buf,NULL,NULL,WIZ_GUILDS,0,0);
	save_clans( );
	return;
}

/*
 * There's a peculiar kind of kind of bug with this kind of return.
 * A 'bool' here is just a 'short int' hidden by a typedef, which
 * means a maximum value of 256 unsigned or so.  Anyway, the IS_SET
 * macro doesn't return 1 or 0, it returns a true or false value.
 * 1 is true, but so a billion.  If the flag in question is a big
 * flag, the binary-and will produce a true value (positive integer)
 * that's too big for a short int to hold, and thus when we try to
 * return that value through a 'bool' it, gets truncated to a 0.
 * For this reason, we should always use 'TRUE' and 'FALSE' when
 * returning from a bool fuction.
 */	
bool clan_is_independent( Clan *clan )
{
	if ( clan == NULL )
		return TRUE;
	else
		return IS_SET(clan->flags,CLAN_IS_INDEPENDENT) ? TRUE : FALSE;
}

void set_clan( Character *ch, const char *clan_name )
{
	Clan *c;

	for( c = clan_table; c ; c = c->next )
	{
		if ( c->name[0] == clan_name[0]&& !strcmp(c->name,clan_name) )
		{
			ch->clan = c;
			return;
		}
	}

	ch->clan = NULL;
	return;
}

// Put link to page site in
char *get_clan_name_for_web( Character *clanner, Character *viewer )
{
    static char format[128];

    if ( clanner->clan == NULL )
        return "";
    else
    {
        if ( !clan_is_independent(clanner->clan) )
            snprintf(format+strlen(format),sizeof(format)-strlen(format),":%d",getRank(clanner));

        snprintf(format,sizeof(format),"&lt;%s&gt; ", clanner->clan->name);
        return format;
	}
}

char *get_clan_name( Character *clanner, Character *viewer )
{
	static char	format[128];

	if ( clanner->clan == NULL )
		return "";
	else
	{
		char buf[16];

		buf[0] = '\0';
		if ( !clan_is_independent(clanner->clan) )
			snprintf(buf,sizeof(buf),":%d",getRank(clanner));

		snprintf(format,sizeof(format),"<%s%s> ",clanner->clan->name, buf);
		return format;
	}
}

void create_guild( Character *ch )
{
	char	buf[MAX_STRING_LENGTH];
	Clan 	*guild;
	int i;

	if ( IS_NPC(ch) )
	{
		cprintf(ch,"Bug: NPCs can't make guilds!\n\r");
		log_bug("create_guild: NPC trying to make a guild",0);
	}

	guild = new_clan( );
	guild->name = str_dup(ch->pcdata->pGuild->name);
	guild->total_players = GUILD_START_SIZE;
	guild->founded = current_time;
	guild->founder = ch->name;
	ch->pcdata->guild_rank = 0;
	guild->next = clan_table;
	clan_table = guild;

	/* Set up ranks */
	guild->ranks[0].name = str_dup("Guild Leader");
	guild->ranks[0].flags = default_flags;
	guild->password = strdup("password");

	for( i = 1; i < MAX_GUILD_RANK ; i++ )
	{
		guild->ranks[i].flags =  GCOP_USE_GUILDCHAT;
		setRankTitle( guild, i+1, "untitled rank" );
	}

    for ( i=0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
    {
		Character *gch;

        if ( (gch = ch->pgroup->members[i]) == NULL || gch == ch )
        	continue;

        if ( is_same_group( gch, ch ) )
			setRank(gch,9);
    }

	log_string("guild '%s' created %s by %s\n", 
		guild->name, format_date( current_time, "%H:%M on %A, %d/%b/%Y" ),
		ch->name );
	save_clans( );
    sprintf(buf," New clan!  %s has been created.",guild->name);
    wiznet(buf,NULL,NULL,WIZ_GUILDS,0,0);
	pnet(buf,NULL,NULL,WIZ_GUILDS,0,0);
	return;
}

int gc_lookup( const char *verb )
{
	int i;

	for( i = 0 ; guild_command_table[i].name != NULL ; i++ )
	{
		if ( guild_command_table[i].name[0] == verb[0] &&
			 !str_prefix(verb,guild_command_table[i].name) )
			return i;
	}

	return -1;
}

void do_guildcommand( Character *ch, char *argument )
{
	char	verb[MAX_INPUT_LENGTH];
	char	subj[MAX_INPUT_LENGTH];
	int		gc;

	argument = one_argument_cs( argument, verb );
	argument = one_argument_cs( argument, subj );

	if ( verb[0] == '\0' || (gc = gc_lookup(verb)) < 0 )	
		do_help(ch,"guildcommand");
	else			
	{
		if ( guild_command_table[gc].officer_permissions > 0 &&
			 !has_permission(ch,guild_command_table[gc].officer_permissions) )
		{
			cprintf(ch,"You don't have permission to use that guild command.\n\r");
			return;
		}

		(*guild_command_table[gc].gc_fun)(ch,subj,argument);
	}

	return;
}


void gc_create( Character *ch, char *verb, char *argument )
{
	Character *vch;	
	int count=0;
	Character *regis;

	for ( regis = ch->in_room->people ; regis ; regis = regis->next_in_room )
		if ( IS_NPC(regis) && IS_SET(regis->act,ACT_REGISTRAR) )
			break;

	if ( regis == NULL )
	{
		cprintf(ch,"You must find a guild registrar to start a clan!\n\r");
		return;
	}

	if ( ch->clan != 0 && !clan_is_independent( ch->clan ) )
	{
		act("$N tells you 'You are already in a clan!'",ch,NULL,regis,TO_CHAR);
		return;
	}

	if ( money_total(ch) < COST_NEW_GUILD )
	{
		act("$N tells you 'It costs 1 electrum to start a clan.'",ch,NULL,regis,TO_CHAR);
		return;
	}

	if ( (clan_lookup( verb )) != NULL )
	{
		act("$N tells you 'I already have such a clan registered.'",ch,NULL,regis,TO_CHAR);
		return;
	}

	if ( IS_NPC(ch) )
	{
		cprintf(ch,"NPCs cannot make clans.\n\r");
		return;
   	}

	if ( ch->pcdata->pGuild != NULL )
	{
		act("$N tells you 'You are already trying to form a clan.'",ch,NULL,regis,TO_CHAR);
		return;
	}

	for( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
		if ( is_same_group(ch,vch) && (vch->clan == 0 || clan_is_independent(vch->clan)) )
			++count;

	if ( count < GUILD_START_SIZE )
	{
		actprintf(ch,NULL,regis,TO_CHAR,"$N tells you 'You must have %d people grouped with you first who aren't in player clans.'",GUILD_START_SIZE);
		return;
	}

	if ( strlen(verb) > 24 || strlen(verb) < 2 )
	{
		act("$N tells you 'Your clan name must be between 2 and 24 letters long.'",ch,NULL,regis,TO_CHAR);
		return;
	}

	/* Scrub for illegal characters in clan name */
	/* Legal characters are upper and lower case letters and
	 * the space.
	 */
	{
		char *p = verb;

		while( *p )
		{
			if ( !isalpha(*p) && *p != ' ' )
			{
				act("$N tells you 'Names may may only use alphabet characters and the space.'",
					ch, NULL, regis, TO_CHAR );
				return;
			}
			++p;
		}
	}

    deduct_cost(ch,COST_NEW_GUILD);
	ch->pcdata->pGuild = new_make_guild( );
	ch->pcdata->pGuild->name = str_dup( verb );
	ch->pcdata->pGuild->leader = ch;
	ch->pcdata->pGuild->approve[0] = 1; /* Obviously the creator approves */

	cprintf(ch,"You are attempting to create a clan called '%s'\n\r",ch->pcdata->pGuild->name);
	for( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
	{
		if ( is_same_group(ch,vch) && ch->clan == 0 && vch != ch )
		{
			cprintf(vch,"%s wishes to create a clan called '%s' and you will be in it.\n\r",
				ch->name, ch->pcdata->pGuild->name );
			cprintf(vch,"If you agree to make the clan type: gc approve\n\r");
			cprintf(vch,"If you do NOT wish to make the clan, type: gc refuse\n\r");
		}
	}

	cprintf(ch,"The people in your group have been notified to type: gc approve to\n\r");
	cprintf(ch,"approve the clan.  Once they have all done so, your clan will be created\n\r");
	cprintf(ch,"and you will be the leader.  Type: &cgc refuse&x to cancel.\n\r");
	return;
}

void gc_approve( Character *ch, char *verb, char *argument) 
{ 
	Character *save, *vch;
	int i;

	if ( ch->pcdata->pGuild )
	{
		cprintf(ch,"You're already trying to make a new guild, it has your approval!\n\r");
		return;
	}

	/*
	 * Search for somebody in your group trying to make a guild
	 */
	for( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
		if ( vch != ch && !IS_NPC(vch) && is_same_group(ch,vch) && vch->pcdata->pGuild != NULL )
			break;

	if ( !vch )
	{
		cprintf(ch,"Nobody in your group is trying to create a guild!\n\r");
		return;
	}

	save = vch;

	/*
 	 * now check for approval
	 */
	for( i = 0; i < GUILD_START_SIZE; i++ )
	{
		if ( save->pcdata->pGuild->approve[i] == 0 )
		{
			save->pcdata->pGuild->approve[i] = 1;
			break;
		}
	}

	for( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
		if ( is_same_group(vch,ch) && !IS_NPC(vch) )
			cprintf(vch,"%s has approved the new guild!\n\r", ch->name );

	for ( i = 0 ; i < GUILD_START_SIZE ; i++ )
		if ( save->pcdata->pGuild->approve[i] == 0 )
			return;

	create_guild( save );
	for ( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
	{
		if ( !is_same_group(vch,ch) )
			continue;
		
		cprintf(vch,"The guild has been created!\n\r");
		vch->clan = clan_lookup( save->pcdata->pGuild->name );
	}
	free_make_guild( save->pcdata->pGuild );
	save->pcdata->pGuild = NULL;
	return;
}


void gc_refuse( Character *ch, char *verb, char *argument ) 
{ 
	Character *vch;

	for( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
		if ( is_same_group(vch,ch) && !IS_NPC(vch) && vch->pcdata->pGuild )
			break;

	if ( !vch )
	{
		cprintf(ch,"Nobody in your group is attempting to make a guild!\n\r");
		return;
	}

	free_make_guild( vch->pcdata->pGuild );
	vch->pcdata->pGuild = NULL;

	/* Cancel guild creation attempt */
	for( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
		if ( is_same_group(vch,ch) && !IS_NPC(vch) && vch != ch )
			cprintf(vch,"%s has refused to create the guild!\n\r",ch->name);

	cprintf(ch,"You refuse to create the guild, and your group is notified.\n\r");
	return;
}

void gc_convert( Character *ch, char *verb, char *argument ) 
{
	if ( ch->clan == NULL || IS_NPC(ch) )
	{
		cprintf(ch,"You are not in a clan.\n\r");
		return;
	}
    
    convert_coins( ch, CONVERT_GUILD_BANK ); 
}

void gc_deposit( Character *ch, char *verb, char *argument ) 
{ 
	int cur;
	int amt;
	Character *banker;

	if ( ch->clan == NULL || IS_NPC(ch) )
	{
		cprintf(ch,"You are not in a clan.\n\r");
		return;
	}

	if ( verb[0] == '\0' || argument[0] == '\0' )
	{
		cprintf(ch,"gc deposit <type> <amount>\n\r");
		return;
	}

	if ( (cur = currency_lookup( verb )) < 0 )
	{
		cprintf(ch,"There is no such currency type called %s.\n\r", verb );
		return;
	}

	if ( (amt = atoi(argument)) < 0 || amt > ch->coins[cur] )
	{
		cprintf(ch,"You only have %d %s to work with.\n\r",ch->coins[cur],currency_table[cur].name);
		return;
	}

	for( banker = ch->in_room->people ; banker ; banker = banker->next_in_room )
		if ( IS_NPC(banker) && IS_SET(banker->act,ACT_BANKER) )
			break;

	if ( !banker )
	{
		cprintf(ch,"There is no banker here.\n\r");
		return;
	}

	ch->coins[cur] -= amt;
	ch->clan->banked[cur] += amt;
	cprintf(ch,"You deposit %d %s into your clan bank account.\n\r",amt,currency_table[cur].name);
	clan_info(ch->clan,ch,"$N has deposited %d %s into the clan bank account.",amt,currency_table[cur].name);
	act("$n deposits some coins.",ch,NULL,NULL,TO_ROOM);
	return;
}

void gc_dissolv(  Character *ch, char *verb, char *argument )
{
	cprintf(ch,"If you wish to dissolve the clan you must type 'gc dissolve' in full.\n\r");
	return;
}

void gc_dissolve( Character *ch, char *verb, char *argument ) 
{ 
	/* Syntax: gc dissolve <password> */
	if ( verb[0] == '\0' || strcmp(verb,ch->clan->password) )
	{
		cprintf(ch,"You did not enter the clan password correctly.\n\r");
		return;
	}

	clan_info(ch->clan,ch,"$N has disbanded the clan!");
	disband_clan( ch->clan );
	return;
}

void gc_info( Character *ch, char *verb, char *argument ) 
{
	int i; 
	Clan *clan;

	if ( ch->clan == NULL )
	{
		cprintf(ch,"You aren't in a clan.\n\r");
		return;
	}

	if ( clan_is_independent( ch->clan ) )
	{
		cprintf(ch,"You are not in an organized clan.\n\r");
		/*cprintf(ch,"%d guild points have been earned by clan %s.\n\r",ch->clan->guild_points);
		cprintf(ch,"There are currently %d players in clan %s.\n\r",ch->clan->total_players);*/
		return;
	}

	clan = ch->clan;
	cprintf(ch," == Guild Record for Clan %s ==\n\r", clan->name );
	cprintf(ch,"Founder: %s  Creation Date: %s  Members: %d  Guild Points: %d\n\r",
		clan->founder,  format_date( clan->founded, "%d/%b/%Y" ) ,
		clan->total_players, clan->guild_points );
	for( i = 0 ; i < MAX_GUILD_RANK ; i++ )
		cprintf(ch,"Rank %d : %s : %s\n\r",i+1,clan->ranks[i].name,flag_string( rank_flags, clan->ranks[i].flags));

	cprintf(ch,"\n\r");
	return;
}

void gc_invite( Character *ch, char *verb, char *argument ) 
{ 
	Character *victim;

	if ( verb[0] == '\0' )
	{
		cprintf(ch,"Usage; gc invite <character>\n\r");
		return;
	}

	if ( (victim =get_char_ooc(ch,verb)) == NULL )
	{
		cprintf(ch,"That character is not on-line.\n\r");
		return;
	}

	if ( IS_NPC(victim) )
	{
		cprintf(ch,"You cannot invite NPCs.\n\r");
		return;
	}

	if ( victim == ch )
	{
		cprintf(ch,"You're already in your clan!\n\r");
		return;
	}

	if ( victim->pcdata->clan_invite )
	{
		cprintf(ch,"%s is fielding an offer from another clan.\n\r", victim->name );
		cprintf(victim,"%s tried to invite you to join %s, but you're fielding an offer from %s.\n\r",
			ch->name, ch->clan->name, victim->pcdata->clan_invite->name );
		return;
	}

	if ( victim->clan == ch->clan )
	{
		cprintf(ch,"That person is already in your clan.\n\r");
		return;
	}

	victim->pcdata->clan_invite = ch->clan;
	cprintf(victim,"%s has invited you to become a member of %s.\n\rType gc join or gc decline to accept or decline.\n\r",ch->name,ch->clan->name);
	cprintf(ch,"You invite %s to join your clan.\n\r", victim->name );
	return;
}

void gc_decline( Character *ch, char *verb, char *argument )
{
	if ( ch->pcdata->clan_invite == NULL )
	{
		cprintf(ch,"You aren't fielding any offers right now.\n\r");
		return;
	}

	clan_info(ch->pcdata->clan_invite,ch,"$N has declined to join the clan.");
	cprintf(ch,"You decline the offer to join %s.\n\r", ch->pcdata->clan_invite->name );
	ch->pcdata->clan_invite = NULL;
	return;
}

void gc_join( Character *ch, char *verb, char *argument ) 
{ 
	char	buf[MAX_STRING_LENGTH];

	if ( IS_NPC(ch) )
	{
		cprintf(ch,"You're an NPC, you can't join clans!\n\r");
		return;
	}

	if ( ch->pcdata->clan_invite == NULL )
	{
		cprintf(ch,"You aren't fielding any offers right now.\n\r");
		return;
	}

	ch->clan = ch->pcdata->clan_invite;
	ch->pcdata->clan_invite = NULL;
	cprintf(ch,"You have joined %s!\n\r", ch->clan->name );
	setRank(ch,9);
	clan_info(ch->clan,ch,"$N has joined the clan.");
	ch->clan->total_players++;
	snprintf(buf,sizeof(buf),"$N has joined clan %s!",ch->clan->name);
	wiznet(buf,ch,NULL,WIZ_GUILDS,0,0);
	pnet(buf,ch,NULL,WIZ_GUILDS,0,get_trust(ch));
	return;
}

void gc_password( Character *ch, char *verb, char *argument ) 
{
	char *p;

	/* Usage: gc password <old> <new> */
	if ( verb[0] == '\0' || argument[0] == '\0' )
	{
		cprintf(ch,"Usage: gc password <old> <new>\n\r");
		return;
	}

	if ( strcmp(verb,ch->clan->password) )
	{
		cprintf(ch,"You did not enter the old password correctly.\n\r");
		return;
	}

	if ( strlen(argument) < 8 )
	{
		cprintf(ch,"Your new password must be at least 8 characters long.\n\r");
		return;	
	}	

	p = argument;
	while ( *p != 0 )
	{
		if ( *p == '~' )
		{
			cprintf(ch,"You cannot put a tilde into your password.\n\r");
			return;
		}
		++p;
	}

	ch->clan->password = strdup( argument );
	cprintf(ch,"Clan password changed to '%s'.\n\r", ch->clan->password );
	return;
}

char *getRankName( Character *ch )
{
	if ( ch->clan == NULL || IS_NPC(ch) )
		return "Untitled Rank";
	else
	if ( clan_is_independent( ch->clan ) )
		return "Independent";
	else
		return ch->clan->ranks[ch->pcdata->guild_rank].name;
}

int getRank( Character *ch )
{
	if ( IS_NPC(ch) )
		return MAX_GUILD_RANK;
	else
		return ch->pcdata->guild_rank + 1;
}

void gc_rank( Character *ch, char *verb, char *argument )
{
	int new_rank;
    Character *victim = NULL;
    bool victim_online, rank_failed = FALSE;
	
    if ( verb[0] == '\0' || argument[0] == '\0' || !is_number(argument) )
    {
    	cprintf(ch,"Usage: gc rank <player> <#1-9>\n\r");
    	return;
    }    	

    victim_online = get_any_char(ch, verb, &victim);
    if(victim == NULL)
    {
        return;
    }

    if ( IS_NPC(ch) || IS_NPC(victim) )
    {
    	cprintf(ch,"This command cannot be performed on or by an NPC.\n\r");
        rank_failed = TRUE;
    }
    	    
    if ( !is_same_clan(victim,ch) && !rank_failed)
    {
    	cprintf(ch,"%s is not in your clan.\n\r",victim->name );
        rank_failed = TRUE;
    }
    
    if ( !has_permission(ch,GCOP_RANK) && !rank_failed)
    {
    	cprintf(ch,"You do not have permission to change ranks.\n\r");
        rank_failed = TRUE;
    }
    
    if ( victim->pcdata->guild_rank  <= ch->pcdata->guild_rank && !rank_failed)
    {
    	cprintf(ch,"You can only change ranks of lower-ranking officers.\n\r");
        rank_failed = TRUE;
    }    	

    if ( (new_rank = atoi( argument )) < getRank(ch) && !rank_failed)
	{
		cprintf(ch,"You cannot rank somebody higher than yourself.\n\r");
        rank_failed = TRUE;
	}

	if ( new_rank > 10 && !rank_failed)
	{
		cprintf(ch,"You cannot set a rank lower than 10.\n\r");
        rank_failed = TRUE;
	}

    if(!rank_failed)
    {
        setRank(victim,new_rank);
        cprintf(ch,"You have changed %s's rank to %d (%s).\n\r", victim->name, 
            getRank(victim), getRankName(victim) );

        if(victim_online)
        {
            cprintf(victim,"Your rank has been changed to %d (%s).\n\r",getRank(victim), 
                getRankName(victim) );
        }

	    clan_info(victim->clan,victim,"$N has been set to rank %d (%s).",getRank(victim),
            getRankName(victim) );
    }

    if(!victim_online)
    {
        do_quit(victim,"");
    }

    return;
}

void gc_remove( Character *ch, char *verb, char *argument ) 
{ 
	char	buf[MAX_STRING_LENGTH];
	Character *victim = NULL;
    bool victim_online, remove_failed = FALSE, fSelf = FALSE;
	
	if ( verb[0] == '\0' )
	{
		cprintf(ch,"Usage: gc remove <character|self>\n\r");
		return;
	}

	if ( ch->clan == NULL )
	{
		cprintf(ch,"You aren't in a clan.\n\r");
		return;
	}

	if ( !strcmp(verb,"self") )
	{
		victim = ch;
		fSelf = TRUE;
        victim_online = TRUE;
		if ( clan_is_independent( ch->clan ) )
		{
			cprintf(ch,"You can't remove yourself from independent clans.\n\r");
			return;
		}
	}
	else
    {
        victim_online = get_any_char(ch, verb, &victim);
        if(victim == NULL)
        {
            return;
        }
    }

	if ( !fSelf && victim != ch && !has_permission(ch,GCOP_REMOVE) )
	{
		cprintf(ch,"Your rank doesn't have permission to remove others.\n\r");
        remove_failed = TRUE;
	}

	if ( IS_NPC(victim) && !remove_failed)
	{
		cprintf(ch,"You can't remove NPCs.\n\r");
        remove_failed = TRUE;
	}

	if ( victim->clan != ch->clan && !remove_failed)
	{
		cprintf(ch,"You cannot remove people who aren't in your clan.\n\r");
        remove_failed = TRUE;
	}

	if ( !fSelf && victim != ch && victim->pcdata->guild_rank < ch->pcdata->guild_rank 
        && !remove_failed)
	{
		cprintf(ch,"You can only remove lower-ranking members.\n\r");
        remove_failed = TRUE;
	}

    if(!remove_failed)
    {
	    if ( victim->in_room->clan == ch->clan)
	    {
            if(victim_online)
            {
		        act("$n vanishes suddenly!",victim,NULL,NULL,TO_ROOM);
		        char_from_room(victim);
		        char_to_room( victim, get_room_index( 3001 ) );
		        act("$n materializes suddenly before you.",victim,NULL,NULL,TO_ROOM);
		        do_look(victim,"auto");
            }
            else
            {
                victim->in_room = get_room_index( 3001 );
            }
	    }

        if(victim_online)
        {
	        act("You have been removed from your clan!",victim,NULL,NULL,TO_CHAR);
        }

	    clan_info(ch->clan,victim,"$N has been removed from the clan.");
	    sprintf(buf,"%s has been removed from clan %s!",victim->name, victim->clan->name);
	    wiznet(buf,ch,NULL,WIZ_GUILDS,0,0);
	    pnet(buf,ch,NULL,WIZ_GUILDS,0,get_trust(ch));
	    ch->clan->total_players--;
	    victim->clan = clan_lookup("loner");
    }

    if(!victim_online)
    {
        do_quit(victim,"");
    }

    return;
}

void gc_set( Character *ch, char *verb, char *argument ) 
{ 
	long bit;
	int rank;
	char	param[MAX_INPUT_LENGTH];
	
	if ( verb == NULL || argument == NULL )
	{
		cprintf(ch,"Usage: gc set <Rank #1-9> <parameter> [value]\n\r"
			   "  Parameters:  title %s\n\r"
			   "  Value: only used to set rank titles\n\r", show_bit_list( rank_flags ) ); 
		return;
	}
		
	argument = one_argument( argument, param );
  	if ( !is_number( verb ) )
  	{
  		gc_set(ch,NULL,NULL);
  		return;
  	}
  	
  	rank = atoi( verb );
	/* Remember that rank 1 is index 0! */

	if ( rank < 1 || rank > MAX_GUILD_RANK )
	{
		cprintf(ch,"Valid range for rank is 1 to %d.\n\r", MAX_GUILD_RANK );
		return;
	}

	/* Drop rank by 1 for indexing */
	if ( !strcmp( param, "title" ) )
	{
		if ( argument[0] == '\0' )
		{
			cprintf(ch,"To change rank titles type: gc set <rank#> title '<title string>'\n\r");
			return;
		}

		setRankTitle( ch->clan, rank, argument );
		cprintf(ch,"The rank title for rank %d is changed to %s.\n\r",rank,ch->clan->ranks[rank-1].name);
		save_clans( );
		return;
	}

    if ( rank <= getRank(ch) )
    {
        cprintf(ch,"You may only change permissions on ranks lower than yours.\n\r");
        return;  
    }
  	if ( (bit = flag_lookup( param, rank_flags )) < 0 )
  	{
  		cprintf(ch,"No such officer bit '%s'.\n\r", param );
		cprintf(ch,"Valid officer bits: %s\n\r", show_bit_list( rank_flags ) );
  		return;
  	}

	toggleRankBit( ch->clan, rank, bit );
  	cprintf(ch,"Officer %s permission toggled for rank %d.\n\r",flag_string( rank_flags, bit ), rank );
	save_clans( );
  	return;
}

void gc_top( Character *ch, char *verb, char *argument ) { }

void gc_withdraw( Character *ch, char *verb, char *argument ) 
{ 
	int amt, cur;
    Character *banker;

    if ( !ch->clan )
    {
        cprintf(ch,"You aren't in a clan.\n\r");
        return;
    }

    if (  verb[0] == '\0' || argument[0] == '\0' )
    {
        cprintf(ch,"Usage: gc withdraw <type> <amount>\n\r");
		return;
	}

	if ( (cur = currency_lookup(verb)) < 0 )
	{
		cprintf(ch,"There is no such currency type.\n\r");
		return;
	}
 
	if ( (amt = atoi(argument)) < 0 || amt > ch->clan->banked[cur] )
	{
		cprintf(ch,"There's only %d %s in your clan account.\n\r",amt,currency_table[cur].name );
		return;
	}

	for( banker = ch->in_room->people ; banker ; banker = banker->next_in_room )
		if ( IS_NPC(banker) && IS_SET(banker->act,ACT_BANKER))
			break;

	if ( !banker )
	{
		cprintf(ch,"There's no banker nearby.\n\r");
		return;
	}

	ch->coins[cur] += amt;
	ch->clan->banked[cur] -= amt;
	cprintf(ch,"You withdraw %d %s from your clan bank account.\n\r", amt, currency_table[cur].name );
	act("$n withdraws some coins.",ch,NULL,NULL,TO_ROOM);
	clan_info(ch->clan,ch,"$N withdraws %d %s from the clan bank account.",amt,currency_table[cur].name );
	return;
}

void load_clans( void )
{
    FILE *fp;
	char	str[128];

	snprintf(str,sizeof(str),"%s", GUILD_FILE );
    if ( ( fp = fopen( str, "r" ) ) == NULL )
	{
		log_error("load_Clans");
        return;
	}

    for ( ; ; )
    {
        Clan *clan;
		int i;

        if ( feof(fp) )
        {
            fclose( fp );
            return;
        }
   
        clan = new_clan();

    	clan->name = fread_string( fp );
		clan->password = fread_string( fp );
		if ( !strcmp( clan->name, "#$" ) )
		{
			free_clan( clan );
			return;
		}
    	clan->guild_points = fread_number( fp );
    	clan->total_players = fread_number( fp );
    	for( i = 0; i < MAX_CURRENCY; i++ )
        	clan->banked[i] = fread_number( fp );
    	clan->hall = fread_number( fp );
    	clan->flags = fread_flag( fp );
    	clan->founded = fread_number( fp );
    	clan->founder = fread_string( fp );
    	for( i = 0 ; i < MAX_GUILD_RANK; i++ )
    	{
        	clan->ranks[i].name = fread_string( fp );
        	clan->ranks[i].flags = fread_flag( fp );
    	}
		fread_to_eol( fp );

		// Set all flags for rank 1
		if ( !clan_is_independent(clan) )
			clan->ranks[0].flags |= default_flags;

		clan->next = clan_table;
		clan_table = clan;
    }
}

void save_clans( void )
{
    char strsave[MAX_INPUT_LENGTH];
    FILE *fp;

#if !defined(__ARPENS)
	return;
#endif

    fclose( fpReserve );
    sprintf( strsave, "%s",GUILD_FILE);
    if ( ( fp = fopen( strsave, "w" ) ) == NULL )
    {
        log_bug( "load_clans_file: fopen", 0 );
        log_error( strsave );
    }
    else
    {
		Clan *c;

		for ( c = clan_table ; c ; c = c->next )
			fwrite_guild( fp, c );
    }
    fclose( fp );
    rename(TEMP_FILE,strsave);
    fpReserve = fopen( NULL_FILE, "r" );
    return;
}

void fwrite_guild( FILE *fp, Clan *clan )
{
	int i;

	fprintf(fp,"%s~\n", clan->name );
	fprintf(fp,"%s~\n", clan->password );
	fprintf(fp,"%ld %d ", clan->guild_points,clan->total_players);
	for( i = 0; i < MAX_CURRENCY; i++ )
		fprintf(fp,"%ld ",clan->banked[i]);	
	fprintf(fp,"%d %s %ld %s~\n", clan->hall, print_flags( clan->flags), (long) clan->founded, clan->founder );
	for( i = 0 ; i < MAX_GUILD_RANK; i++ )
		fprintf(fp,"%s~ %s\n", clan->ranks[i].name,
						print_flags(clan->ranks[i].flags) );
}


bool has_permission( Character *ch, long bit )
{
	if( ch->clan == NULL )
		return FALSE;

	if (IS_NPC(ch))
		return FALSE;
	else
		return (IS_SET(ch->clan->ranks[ch->pcdata->guild_rank].flags,bit) ? 1 : 0 );
}

void gc_who( Character *ch, char *verb, char *argument )
{
	FILE *fp;
	char filename[MAX_STRING_LENGTH];
	Buffer *buffer;
	char buf[128];
	int p, col = 0;

	if ( clan_is_independent(ch->clan) )
	{
		cprintf(ch,"You're not in a clan!\n\r");
		return;
	}

	fclose(fpReserve);

	snprintf(filename,sizeof(filename),"%s/roster/%s.roster",
		DATA_DIR, ch->clan->name );

	// Translate whitespace to underscores
	for( p=0 ; filename[p] != '\0' ; p++ )
		if ( filename[p] == ' ' )
			filename[p] = '_';

	if ( (fp = fopen(filename,"r")) == NULL )
	{
		cprintf(ch,"Couldn't open the roster file %s: %s\n\r",
			filename, strerror(errno) );
		return;
	}

	buffer = new_buf();

	bprintf(buffer," == Guild Roster for Clan %s ==\n\r",ch->clan->name);
	// open and read
	while( fgets(buf,sizeof(buf),fp) != NULL )
	{
		stripCRLF(buf);
		bprintf(buffer, "R%-15s", buf);
	
		if (++col % 5 == 0)
			bprintf(buffer, "\n\r");
	}

	if (col % 5 != 0)
		bprintf(buffer, "\n\r");

	page_to_char(buf_string(buffer),ch);
	free_buf(buffer);

	fclose( fp );
	fpReserve = fopen(NULL_FILE,"r");
}

void gc_balance( Character *ch, char *verb, char *argument )
{
	Character *banker;
	int i;

	if ( !ch->clan || clan_is_independent(ch->clan) )
	{
		cprintf(ch,"You have no clan account to view.\n\r");
		return;
	}

	for( banker = ch->in_room->people ; banker ; banker = banker->next_in_room )
		if ( IS_NPC(banker) && IS_SET(banker->act,ACT_BANKER))
			break;
 
	if ( !banker )
	{
		cprintf(ch,"There's no banker here.\n\r");
		return;
	}

	cprintf(ch," Clan Bank Balance for <%s>\n\r",ch->clan->name);
	for( i = 0; i < MAX_CURRENCY ; i++ )
		cprintf(ch," &%c%-12s&x : %ld\n\r",	currency_table[i].color,
											currency_table[i].name,
											ch->clan->banked[i] );

	return;
}

void do_grename( Character *ch, char *argument )
{
	char	oldname[MAX_INPUT_LENGTH];
	char	newname[MAX_INPUT_LENGTH];
	Clan	*clan;

	argument = one_argument_cs( argument, oldname );
	argument = one_argument_cs( argument, newname );
 
	if ( oldname[0] == '\0' || newname[0] == '\0' )
	{
		cprintf(ch,"grename <old> <new>\n\r");
		return;
	}

	if ( (clan = clan_lookup( oldname )) == NULL )
	{
		cprintf(ch,"No clan found called '%s'.\n\r", oldname );
		return;
	}

	free_string( clan->name );
	clan->name = str_dup( newname );
	cprintf(ch,"Clan renamed to %s.\n\r", newname );
#if !defined(__OLC)
	save_clans( );
#endif

	return;
}	

// Buildings
void gc_build( Character *ch, char *verb, char *argument )
{
	char arg[MAX_STRING_LENGTH];
	Building *bld;
	int	material;
	int	bld_type;
	int attempts;
	int skill;
	int i;

	if ( verb[0] == '\0' )
	{
		cprintf(ch,"Syntax:   build new <building_type> <wood|stone> // Start new construction\n\r"
                   "          build <building_name>                  // Help with existing building\n\r");
		return;
	}

	// Check build deadline
	if ( IS_NPC(ch) )
	{
		cprintf(ch,"NPCs cannot build.\n\r");
		return;
	}

	if ( ch->pcdata->build_daymonth &&
		 !str_cmp(ch->pcdata->build_daymonth,format_date(current_time,"%d%m")))
	{
		cprintf(ch,"You can only contribute to a construction project once per day.\n\r");
		return;
	}

	// New
	if ( !str_cmp(verb,"new") )
	{
		Room *r;

		// Make sure this clan isn't working on a new building
		for(i=50000;i<60000;i++)
		{
			if ( (r = get_room_index(i)) != NULL && r->clan == ch->clan )
				for( bld = r->buildings; bld != NULL; bld = bld->next )
				{
					if ( IS_SET(bld->flags,BUILDING_UNDER_CONSTRUCTION) )
					{
						cprintf(ch,"Your clan is already working on a building.\n\r");
						return;
					}
				}
		}

		argument = one_argument( argument, arg );
		if ( !IS_SET(ch->in_room->room_flags,ROOM_ZONED) )
		{
			cprintf(ch,"This room is not zoned for construction.\n\r");
			return;
		}

        if ( ch->in_room->clan == NULL )
        {
            cprintf(ch,"You must claim this land for your clan before you can build on it.\n\r");
            return;
        }

		if ( ch->in_room->clan != ch->clan )
		{
			cprintf(ch,"Another clan already has claimed this land.\n\r");
			return;
		}

		// what kind of building?
		if ( arg[0] == '\0' )
		{
			gc_build(ch,"","");
			return;
		}

		if ( (bld_type = flag_value( building_flags, arg )) == NO_FLAG )
		{
			cprintf(ch,"Valid building types are: barracks smithy, etc\n\r");
			return;
		}

		// Temporary until the other buildings are done
		if ( bld_type != BUILDING_BARRACKS )
		{
			cprintf(ch,"For the time being, only a barracks can be constructed.\n\r");
			return;
		}

		// material should be wood or stone
		if ( argument[0] == '\0' )
		{
			gc_build(ch,"","");
			return;
		}

		if ( !str_cmp(argument,"wood") )
			material = BUILDMAT_WOOD;
		else
		if ( !str_cmp(argument,"stone") )
			material = BUILDMAT_STONE;
		else
		{
			cprintf(ch,"Valid materials are wood or stone.\n\r");
			return;
		}

		// Create building
		bld = new_building();
		bld->material = material;
		bld->flags = BUILDING_UNDER_CONSTRUCTION;
		bld->curr_structure = 1;
		bld->max_structure = building_table[bld_type][material];
		bld->next = ch->in_room->buildings;
		bld->clan_owner = ch->clan;
		bld->type = bld_type;
		bld->entrance_room = -1;
		bld->level = 1;
		bld->available_resources = 0;
		ch->in_room->buildings = bld;

		act("You break ground on a new structure!",ch,NULL,NULL,TO_CHAR);
		act("$n breaks groud on a new structure!",ch,NULL,NULL,TO_ROOM);
		write_building_file( );
		return;
	}

	if( (bld = get_building_room(ch,verb)) == NULL )
	{
		cprintf(ch,"You don't see that building here.\n\r");
		return;
	}

	if ( bld->curr_structure >= bld->max_structure )
	{
		cprintf(ch,"This building is completed and undamaged.\n\r");
		return;
	}

	// Ok now try to contribute
	if ( bld->available_resources < 1 )
	{
		cprintf(ch,"This structure has no resources available for building!\n\r");
		return;
	}

	// Check skill 
	switch( bld->material )
	{
		case BUILDMAT_WOOD:		skill = gsn_woodworking; break;
		case BUILDMAT_STONE:	skill = gsn_stoneworking; break;
		default:
			cprintf(ch,"Your building is bugged!  Let the IMMs know.\n\r");
			return;
	}

	// How many tries will we get to finish it?
	attempts = UMIN( get_skill(ch,skill), bld->available_resources );

	// Curved for levels under 25 to prevent abuse.
	// Level 10 and below cannot build.
	// Level 10-20 get level * 5 points.
	// Level 20-25 get level * 8 points at most.
	if ( ch->level < 10 )
	{
		cprintf(ch,"You must be at least level 10 to build clan structures.\n\r");
		return;
	}

	if ( ch->level < 20 )
		attempts = UMIN( attempts, ch->level*5 );
	else
	if ( ch->level < 25 )
		attempts = UMIN( attempts, ch->level*8 );
	
	actprintf(ch,NULL,NULL,TO_ROOM,"$n rolls up $s sleeves and starts working on building the %s.",flag_string(building_flags,bld->type));
	actprintf(ch,NULL,NULL,TO_CHAR,"You roll up your sleeves and start working on building the %s.",flag_string(building_flags,bld->type));

	for( i=0; i < attempts; i++ )
	{
		bld->curr_structure++;
		bld->available_resources--;

		// Check improve for people with low-med skill
		if ( get_skill(ch,skill) < 150 )
			checkImproveTradeSkill( ch, skill, 10, TRUE );

		if ( bld->curr_structure >= bld->max_structure )
		{
			// done!
			break;
		}
	}

	if ( bld->curr_structure >= bld->max_structure && 
		 IS_SET(bld->flags,BUILDING_UNDER_CONSTRUCTION) )
	{
		REMOVE_BIT(bld->flags,BUILDING_UNDER_CONSTRUCTION);
		bld->entrance_room = createBuilding( bld->type, ch->clan, ch->in_room );
		actprintf(ch,NULL,NULL,TO_ROOM,"The %s has been completed!",
			flag_string( building_flags, bld->type ) );
		write_building_file( );
	}

	// Upgrades
	if ( bld->curr_structure >= bld->max_structure &&
		IS_SET(bld->flags,BUILDING_UPGRADE) )
	{
		extern void upgradeBuilding( Building *bld );

		REMOVE_BIT(bld->flags,BUILDING_UPGRADE);
		upgradeBuilding( bld );
		actprintf(ch,NULL,NULL,TO_ROOM,"The %s upgrade has been completed!",
			flag_string( building_flags, bld->type ) );
		write_building_file( );
		saveAreaFile( ClanHallArea );
	}

	// Now log 'em off for 1 minute per # of attempts
	ch->pcdata->build_deadline = current_time + ( 60 * i );

	// Put today's day/month in to check later
	if ( ch->pcdata->build_daymonth != NULL )
		free_string(ch->pcdata->build_daymonth);

	ch->pcdata->build_daymonth = str_dup( format_date(current_time,"%d%m") );

	cprintf(ch,"*** Your character will be busy working for %d minutes.\n\r"
               "You may play another character during that time if you like.\n\r",i);
	save_char_obj(ch);
	do_quit(ch,"");
	write_building_file( );
	return;
}

void gc_claim( Character *ch, char *verb, char *argument )
{
	if ( clan_is_independent(ch->clan) )
	{
		cprintf(ch,"Independent clans cannot claim land.\n\r");
		return;
	}

	if ( !IS_SET(ch->in_room->room_flags,ROOM_ZONED) )
	{
		cprintf(ch,"This room is not zoned for construction.\n\r");
		return;
	}

	if ( ch->in_room->clan != NULL && ch->in_room->buildings != NULL )
	{
		cprintf(ch,"This land has been built on by another clan already.\n\r");
		return;
	}

	ch->in_room->clan = ch->clan;
	cprintf(ch,"You claim lordship over this land for the clan %s.\n\r",
		ch->clan->name);
	clan_info(ch->clan,ch,"$N has claimed lordship over part of %s.\n\r",
		ch->in_room->area->name );
}

int next_clanhall_vnum( void )
{
	int i;

	for( i=40000 ;i<50000; i++ )
		if ( get_room_index(i) == NULL )
			return i;

	return -1;
}

int newSmithy( Clan *clan, Room *exit_room )
{
	Room *weaponry, *armory;
	char tmp[4096];
	int iHash;
    //Object *wAnvil, *aAnvil;
    //Spawn *spawn;

	// Find lowest available vnums between 40000 and 49999 for clan halls

	// Foyer
	weaponry = new_room_index( );
	weaponry->vnum = next_clanhall_vnum( );
	weaponry->sector_type = SECT_INSIDE;
	weaponry->room_flags = ROOM_INDOORS;
	weaponry->clan = clan;
	snprintf(tmp,sizeof(tmp),"The Weaponry of the clan %s",clan->name);
	weaponry->name = str_dup(tmp);
	weaponry->heal_rate = 0;
	weaponry->mana_rate = 0;
	weaponry->guild = -1;
	snprintf(tmp,sizeof(tmp),hallDescriptions[BUILDING_BLACKSMITH][0],clan->name);
	weaponry->description = str_dup( tmp );
	weaponry->area = ClanHallArea;

    if ( weaponry->vnum > top_vnum_room )
        top_vnum_room = weaponry->vnum;

    iHash           = weaponry->vnum % MAX_KEY_HASH;
    weaponry->next     = room_index_hash[iHash];
    room_index_hash[iHash]  = weaponry;

    // Make weapon anvil
    //wAnvil = createAnvil( "weaponsmithing", 1 );
    //spawn               = get_new_spawn( );
    //spawn->type         = 'O';
    //spawn->source       = wAnvil->pIndexData->vnum;
    //spawn->target       = weaponry->vnum;
    //spawn->interval     = 1;
    //spawn->frequency    = 100;
    //spawn->placeholder  = 0;
    //spawn->despawn      = 0;
    //spawnToRoom( weaponry, spawn );

	// Hp Regen room
	armory = new_room_index( );
    armory->vnum = next_clanhall_vnum( );
    armory->sector_type = SECT_INSIDE;
    armory->room_flags = ROOM_INDOORS;
    armory->clan = clan;
    snprintf(tmp,sizeof(tmp),"The Armory of the clan %s",clan->name);
    armory->name = str_dup(tmp);
    armory->heal_rate = 0;
    armory->mana_rate = 0;
    armory->guild = -1;
    snprintf(tmp,sizeof(tmp),hallDescriptions[BUILDING_BLACKSMITH][1],clan->name);
    armory->description = str_dup( tmp );
	armory->area = ClanHallArea;

    if ( armory->vnum > top_vnum_room )
        top_vnum_room = armory->vnum;

    iHash           = armory->vnum % MAX_KEY_HASH;
    armory->next     = room_index_hash[iHash];
    room_index_hash[iHash]  = armory;

	weaponry->exit[DIR_EAST] = new_exit();
	weaponry->exit[DIR_EAST]->u1.to_room = armory;
	weaponry->exit[DIR_EAST]->orig_door = DIR_EAST;

    weaponry->exit[DIR_SOUTH] = new_exit();
    weaponry->exit[DIR_SOUTH]->u1.to_room = exit_room;
    weaponry->exit[DIR_SOUTH]->orig_door = DIR_SOUTH;

    armory->exit[DIR_WEST] = new_exit();
    armory->exit[DIR_WEST]->u1.to_room = weaponry;
    armory->exit[DIR_WEST]->orig_door = DIR_WEST;

	saveAreaFile( ClanHallArea );
	return weaponry->vnum;
}

int newBarracks( Clan *clan, Room *exit_room )
{
	Room *foyer, *hp_regen, *mana_regen, *both;
	char tmp[4096];
	int iHash;

	// Find lowest available vnums between 40000 and 49999 for clan halls

	// Foyer
	foyer = new_room_index( );
	foyer->vnum = next_clanhall_vnum( );
	foyer->sector_type = SECT_INSIDE;
	foyer->room_flags = ROOM_INDOORS;
	foyer->clan = clan;
	snprintf(tmp,sizeof(tmp),"The Barracks Foyer of the clan %s",clan->name);
	foyer->name = str_dup(tmp);
	foyer->heal_rate = 0;
	foyer->mana_rate = 0;
	foyer->guild = -1;
	snprintf(tmp,sizeof(tmp),hallDescriptions[BUILDING_BARRACKS][0],clan->name);
	foyer->description = str_dup( tmp );
	foyer->area = ClanHallArea;

    if ( foyer->vnum > top_vnum_room )
        top_vnum_room = foyer->vnum;

    iHash           = foyer->vnum % MAX_KEY_HASH;
    foyer->next     = room_index_hash[iHash];
    room_index_hash[iHash]  = foyer;

	// Hp Regen room
	hp_regen = new_room_index( );
    hp_regen->vnum = next_clanhall_vnum( );
    hp_regen->sector_type = SECT_INSIDE;
    hp_regen->room_flags = ROOM_INDOORS;
    hp_regen->clan = clan;
    snprintf(tmp,sizeof(tmp),"The Medical Ward in the Barracks of the clan %s",clan->name);
    hp_regen->name = str_dup(tmp);
    hp_regen->heal_rate = 125;
    hp_regen->mana_rate = 0;
    hp_regen->guild = -1;
    snprintf(tmp,sizeof(tmp),hallDescriptions[BUILDING_BARRACKS][1],clan->name);
    hp_regen->description = str_dup( tmp );
	hp_regen->area = ClanHallArea;

    if ( hp_regen->vnum > top_vnum_room )
        top_vnum_room = hp_regen->vnum;

    iHash           = hp_regen->vnum % MAX_KEY_HASH;
    hp_regen->next     = room_index_hash[iHash];
    room_index_hash[iHash]  = hp_regen;

	// Mana regen room
    mana_regen = new_room_index( );
    mana_regen->vnum = next_clanhall_vnum( );
    mana_regen->sector_type = SECT_INSIDE;
    mana_regen->room_flags = ROOM_INDOORS;
    mana_regen->clan = clan;
    snprintf(tmp,sizeof(tmp),"The Meditation Chamber in the Barracks of the clan %s",clan->name);
    mana_regen->name = str_dup(tmp);
    mana_regen->heal_rate = 0;
    mana_regen->mana_rate = 125;
    mana_regen->guild = -1;
    snprintf(tmp,sizeof(tmp),hallDescriptions[BUILDING_BARRACKS][2],clan->name);
    mana_regen->description = str_dup( tmp );
	mana_regen->area = ClanHallArea;

    if ( mana_regen->vnum > top_vnum_room )
        top_vnum_room = mana_regen->vnum;

    iHash           = mana_regen->vnum % MAX_KEY_HASH;
    mana_regen->next     = room_index_hash[iHash];
    room_index_hash[iHash]  = mana_regen;

	// combo room
    both = new_room_index( );
    both->vnum = next_clanhall_vnum( );
    both->sector_type = SECT_INSIDE;
    both->room_flags = ROOM_INDOORS;
    both->clan = clan;
    snprintf(tmp,sizeof(tmp),"The Common Room in the Barracks of the clan %s",clan->name);
    both->name = str_dup(tmp);
    both->heal_rate = 110;
    both->mana_rate = 110;
    both->guild = -1;
    snprintf(tmp,sizeof(tmp),hallDescriptions[BUILDING_BARRACKS][3],clan->name);
    both->description = str_dup( tmp );
	both->area = ClanHallArea;

    if ( both->vnum > top_vnum_room )
        top_vnum_room = both->vnum;

    iHash           = both->vnum % MAX_KEY_HASH;
    both->next     = room_index_hash[iHash];
    room_index_hash[iHash]  = both;

	// Exits

	foyer->exit[DIR_EAST] = new_exit();
	foyer->exit[DIR_EAST]->u1.to_room = hp_regen;
	foyer->exit[DIR_EAST]->orig_door = DIR_EAST;

    foyer->exit[DIR_SOUTH] = new_exit();
    foyer->exit[DIR_SOUTH]->u1.to_room = mana_regen;
    foyer->exit[DIR_SOUTH]->orig_door = DIR_SOUTH;

	foyer->exit[DIR_NORTH] = new_exit();
	foyer->exit[DIR_NORTH]->u1.to_room = exit_room;
	foyer->exit[DIR_NORTH]->orig_door = DIR_NORTH;

    hp_regen->exit[DIR_WEST] = new_exit();
    hp_regen->exit[DIR_WEST]->u1.to_room = foyer;
    hp_regen->exit[DIR_WEST]->orig_door = DIR_WEST;

    hp_regen->exit[DIR_SOUTH] = new_exit();
    hp_regen->exit[DIR_SOUTH]->u1.to_room = both;
    hp_regen->exit[DIR_SOUTH]->orig_door = DIR_SOUTH;

    mana_regen->exit[DIR_EAST] = new_exit();
    mana_regen->exit[DIR_EAST]->u1.to_room = both;
    mana_regen->exit[DIR_EAST]->orig_door = DIR_EAST;

    mana_regen->exit[DIR_NORTH] = new_exit();
    mana_regen->exit[DIR_NORTH]->u1.to_room = foyer;
    mana_regen->exit[DIR_NORTH]->orig_door = DIR_NORTH;

    both->exit[DIR_WEST] = new_exit();
    both->exit[DIR_WEST]->u1.to_room = mana_regen;
    both->exit[DIR_WEST]->orig_door = DIR_WEST;

    both->exit[DIR_NORTH] = new_exit();
    both->exit[DIR_NORTH]->u1.to_room = hp_regen;
    both->exit[DIR_NORTH]->orig_door = DIR_NORTH;

	saveAreaFile( ClanHallArea );
	return foyer->vnum;
}
	
// Creates a new building of the given type and returns the starting vnum
// of its foyer.  Auto-saves rooms to appropriat area file.
int createBuilding( int type, Clan *clan, Room *exit_room )
{
	
	switch( type )
	{
		case BUILDING_BARRACKS:
			return newBarracks( clan, exit_room );
		case BUILDING_BLACKSMITH:
			//return newSmithy( clan, exit_room );
		default:
			log_bug("Bad building type %d",type);
			return 0;
	}
}

void gc_demolish( Character *ch, char *verb, char *subject )
{
	Building *bld;
	Object *obj;
	int vnum, i;

    if ( verb[0] == '\0' )
    {
        cprintf(ch,"Which building do you want to demolish?\n\r");
        return;
    }

	if ( (bld = get_building_room(ch,verb)) == NULL )
	{
		cprintf(ch,"You don't see that building here.\n\r");
		return;
	}

	if ( bld->clan_owner != ch->clan )
	{
		cprintf(ch,"That building doesn't belong to your clan.\n\r");
		return;
	}

	// Demolish it!
	act("$n demolishes a building!",ch,NULL,NULL,TO_ROOM);
	act("You demolish the building!",ch,NULL,NULL,TO_CHAR);

	switch( bld->material )
	{
		case BUILDMAT_WOOD:
			vnum = NR_FOREST; break;
		case BUILDMAT_STONE:
			vnum = NR_STONE; break;
		default:
			cprintf(ch,"You can't demolish it.\n\r"); return;
	}

	for( i=0 ; i < bld->curr_structure ; i++ )
	{
		if ( number_percent() < 25 )
		{
			obj = create_object( get_obj_index(vnum) );
			obj_to_room( obj, ch->in_room );
		}
	}

    for( i=0 ; i < bld->available_resources ; i++ )
    {
        obj = create_object( get_obj_index(vnum) );
        obj_to_room( obj, ch->in_room );
    }

	building_from_room( bld, &(ch->in_room->buildings) );
	return;
}

void gc_hall( Character *ch, char *verb, char *subject )
{
	int i;
	Room *r;
	Building *bld;
	int count = 0;
	Buffer *buf;

	buf = new_buf();

	cprintf(ch,"== Clan Hall Summary ==\n\r");
	cprintf(ch,"   %-12s %-11s %-s\n\r", "Building", "Hitpoints", "Location" );
    for ( i=0; i<100000; i++ )
    {
        if ( (r=get_room_index(i)) == NULL || r->buildings == NULL ||
			r->clan != ch->clan )
            continue;

        for( bld = r->buildings; bld != NULL; bld = bld->next )
        {
            ++count;

            bprintf(buf," * Lv%2d %-12s %5d/%5d %s %s\n\r",
				bld->level, capitalize( flag_string( building_flags, bld->type ) ),
				bld->curr_structure, bld->max_structure, r->name,
                IS_SET(bld->flags,BUILDING_UNDER_CONSTRUCTION) ? "(under construction)" : "");
			switch( bld->type )
			{
				case BUILDING_BARRACKS:
					bprintf(buf,"     HP Regen: %d   Mana Regen: %d   Combo: %d\n\r",
						125+(bld->level*3),125+(bld->level*3),110+(bld->level*2));
				break;
				default:
					break;
			}
        }
    }

	if ( !count )
		bprintf(buf,"   (Your clan owns no structures)\n\r");
	else
		bprintf(buf,"\n\r Your clan has %d building%s.\n\r",
			count, count == 1 ? "" : "s" );

	page_to_char( buf_string( buf ), ch );
	free_buf(buf);
	return;
}

void gc_upgrade( Character *ch, char *verb, char *subject )
{
	Building *bld;

	// Just takes building name argument
	if ( *verb == '\0' )
	{
		cprintf(ch,"Syntax:  gc upgrade <building>\n\r");
		return;
	}

	if ( (bld = get_building_room(ch,verb)) == NULL )
	{
		cprintf(ch,"There is no such structure here.\n\r");
		return;
	}

	if ( bld->clan_owner != ch->clan )
	{
		cprintf(ch,"That structure doesn't belong to your clan.\n\r");
		return;
	}

	if ( bld->level >= 50 )
	{
		cprintf(ch,"That building can be upgraded no further.\n\r");
		return;
	}

	if ( IS_SET(bld->flags,BUILDING_UNDER_CONSTRUCTION) )
	{
		cprintf(ch,"You can't upgrade it until you're done building it.\n\r");
		return;
	}

	if ( IS_SET(bld->flags,BUILDING_UPGRADE) )
	{
		cprintf(ch,"It's already being ugpraded.\n\r");
		return;
	}

	// Set flags
	SET_BIT(bld->flags,BUILDING_UPGRADE);
	bld->max_structure += ((bld->level+1)*100);
	cprintf(ch,"You begin rennovations on your %s.\n\r",
		flag_string(building_flags,bld->type) );
	actprintf(ch,NULL,NULL,TO_ROOM,"$n begins rennovations on $s clan's %s.",
		flag_string(building_flags,bld->type) );
	write_building_file( );
	return;
}

