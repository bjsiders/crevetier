/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include "thoc.h"
#include "options.h"
#include "interp.h"

const struct flag_type option_flags[] =
{
    { "noreveal",           OPT_NOREVEAL,           TRUE },
    { "noreveal-clanmates", OPT_NOREVEAL_CLANMATES, TRUE },
    { "noreveal-groupmates",OPT_NOREVEAL_GROUPMATES,TRUE },
    { "nogive",             OPT_NOGIVE,             TRUE },
    { "noautoreplytext",    OPT_NOAUTOREPLYTEXT,    TRUE },
    { "nosignature",        OPT_NOSIGNATURE,        TRUE },
    { "nowake",             OPT_NOWAKE,             TRUE },
    { "can-loot",           OPT_CANLOOT,            TRUE },
    { "nosummon",           OPT_NOSUMMON,           TRUE },
    { "nofollow",           OPT_NOFOLLOW,           TRUE },

    { "color",              COLOR_TOGGLE,           TRUE },
    { "color-mobs-by-con",  COLOR_MOB_CON,          TRUE },
    { "color-objs-by-con",  COLOR_OBJ_CON,          TRUE },
    { "color-notes-by-to",  COLOR_NOTE_TO,          TRUE },
    { "color-spells",       COLOR_SPELLS,           TRUE },

    { "autoeat",            AUTO_EAT,               TRUE },
    { "autodrink",          AUTO_DRINK,             TRUE },
    { "autoassist",         AUTO_ASSIST,            TRUE },
    { "autoexit",           AUTO_EXIT,              TRUE },
    { "autoloot",           AUTO_LOOT,              TRUE },
    { "autosac",            AUTO_SAC,               TRUE },
    { "autogold",           AUTO_GOLD,              TRUE },
    { "autosplit",          AUTO_SPLIT,             TRUE },
    { "autolookincorpse",   AUTO_LOOKINCORPSE,      TRUE },
    { "autoswitchstyles",   AUTO_SWITCHSTYLES,      TRUE },

    { "tradeskill-debugging",DISP_TRADESKILL_DEBUG, TRUE },
    { "combat-debugging",   DISP_COMBAT_DEBUG,      TRUE },
    { "regen-debugging",    DISP_REGEN_DEBUG,       TRUE }, 
    { "xp-debugging",       DISP_XP_DEBUG,          TRUE },
    { "saves-debugging",    DISP_SAVES_DEBUG,       TRUE },
    { "no-who-titles",      DISP_WHO_NOTITLES,      TRUE },
    { "no-who-guilds",      DISP_WHO_NOGUILDS,      TRUE },
    { "no-who-surnames",    DISP_WHO_NOSURNAMES,    TRUE },
    { "no-emote-marks",     DISP_NO_EMOTE_MARKS,    TRUE },
    { "full-equipment",     DISP_FULL_EQUIPMENT,    TRUE },
    { "show-autosaves",     DISP_SHOW_AUTOSAVES,    TRUE },
    { "append-condition",   DISP_APPEND_CONDITION,  TRUE },
    { "no-battle-prompt",   DISP_NO_BATTLE_PROMPT,  TRUE },
    { "alert-reuse-timers", DISP_ALERT_REUSE,       TRUE },
    { "show-all-skill-lev", DISP_SHOW_ALL_SKILL_LEVELS,   TRUE },
    { "show-when-full-stats",DISP_SHOW_WHEN_FULL,   TRUE },
    { "show-hunger-thirst", DISP_SHOW_HUNGER,       TRUE },
    { "return-at-tick",     DISP_CARRIAGE_RETURN,   TRUE },
    { "show-autoeat",       DISP_AUTOEAT,           TRUE },
    { "show-subraces",      DISP_SHOW_SUBRACES,     TRUE },
    { "no-ignore-message",  DISP_SUPPRESS_IGNORES,  TRUE },
    { "show-obj-cond",      DISP_SHOW_OBJ_COND,     TRUE },
    { "monitor-group-cond", DISP_MONITOR_GROUP,     TRUE },
    { "show-saving-throws", DISP_SHOW_SAVES,        TRUE },
    { "show-aggression",    DISP_SHOW_AGGRESSION,   TRUE },
    { "holylight",          DISP_HOLYLIGHT,         TRUE },

	{ "score-bank",         SCORE_OPT_SHOW_BANK,    TRUE },
	{ "score-xp",	        SCORE_OPT_SHOW_XP,	    TRUE },
	{ "score-resists",      SCORE_OPT_SHOW_RESISTS, TRUE },
    { "score-affects",      SCORE_OPT_SHOW_AFFECTS, TRUE },

    { "brief",              COMM_OPT_BRIEF,         TRUE },
    { "combine",            COMM_OPT_COMBINE,       TRUE },
    { "compact",            COMM_OPT_COMPACT,       TRUE },
    { "prompt",             COMM_OPT_PROMPT,        TRUE },
    { "beeptell",           COMM_OPT_BEEPTELL,      TRUE },

    { NULL, 0, FALSE }
};

struct option_flag_info
{
    int category;
    char *on_msg;
    char *off_msg;
};

const struct flag_type option_category_flags[] =
{
    { "General Options",    OPT_TYPE_OPTION,    FALSE },
    { "Color Options",      OPT_TYPE_COLOR,     FALSE },
    { "Automation Options", OPT_TYPE_AUTO,      FALSE },
    { "Display Options",    OPT_TYPE_DISPLAY,   FALSE },
    { "Communication Options", OPT_TYPE_COMM,   FALSE },
    { "Score Options",      OPT_TYPE_SCORE,     FALSE },
    { NULL, 0, FALSE }
};

const struct option_flag_info option_flag_info_table[] =
{
    { OPT_TYPE_OPTION,  "You will no longer reveal hidden characters.", 
                        "You will now reveal hidden characters"  },   /* noreveal */
    { OPT_TYPE_OPTION,  "You will no longer reveal hidden guild members.", 
                        "You will now reveal hidden guild members."  },   /* noreveal-clanmates */
    { OPT_TYPE_OPTION,  "You will no longer reveal hidden group members.", 
                        "You will now reveal hidden group members."  },   /* noreveal-groupmates */
    { OPT_TYPE_OPTION,  "Players are no longer able to give you items.", 
                        "You are now able to receive items from players."  },   /* nogive */
    { OPT_TYPE_OPTION,  "The body of replied messages will no longer be included in replies.", 
                        "The body of replied message will now be included in replies."  },/* noautoreplytext */
    { OPT_TYPE_OPTION,  "Your signautre will no longer be added to the end of posted messages.", 
                        "Your signature will now be added tothe end of posted messages."  },   /* nosignature */
    { OPT_TYPE_OPTION,  "You can no longer be woken from your sleep.", 
                        "You can now be woken from your sleep."  },   /* nowake */
    { OPT_TYPE_OPTION,  "Your corpse may now be looted.", 
                        "Your corpse is now safe from looters."  },   /* can_loot */
    { OPT_TYPE_OPTION,  "You are now immune to summoning.", 
                        "You are no longer immune to summon."  },   /* nosummon */
    { OPT_TYPE_OPTION,  "You no longer accept followers.", 
                        "You now accept followers."  },   /* nofollow */

    { OPT_TYPE_COLOR,   "Color has been turned on.", 
                        "Color has been turned off."  },   /* color */
    { OPT_TYPE_COLOR,   "Mobs will now be colored by their relative level.", 
                        "Mobs will no longer be colored by their relative level."  },   /* color-mobs-by-con */
    { OPT_TYPE_COLOR,   "Objects will now be colored by their relative level.", 
                        "Objects will no longer be colored by their relative level."  },   /* color-objs-by-con */
    { OPT_TYPE_COLOR,   "Notes to and from you will now be color coded.", 
                        "Notes to and from you will no longer be color coded."  },   /* color-notes-by-to */
    { OPT_TYPE_COLOR,   "Spells you can't use will now be color coded in listings.", 
                        "Spells you can't use will no longer be color coded in listings."},/* color-spells */

    { OPT_TYPE_AUTO,    "You will now automatically eat when you are hungry.", 
                        "You will no longer automatically eat when you are hungry."  },   /* autoeat */
    { OPT_TYPE_AUTO,    "You will now automatically drink when you are thirsty.", 
                        "You will no longer automatically drink when you are thirsty."  },   /* autodrink */
    { OPT_TYPE_AUTO,    "You will now assist when needed.", 
                        "You will no longer automatically assist."  },   /* autoassist */
    { OPT_TYPE_AUTO,    "Exits will now appear when you look in a room.", 
                        "Exits will no longer appear when you look in a room."  },   /* autoexit */
    { OPT_TYPE_AUTO,    "You will now automatically loot a mob when it dies.", 
                        "You will no longer automatically loot a mob when it dies."  },   /* autoloot */
    { OPT_TYPE_AUTO,    "You will now automatically sacrifice the corpses of your victims.", 
                        "You will no longer automatically sacrifice the corpses of your victims."  },   /* autosac */
    { OPT_TYPE_AUTO,    "You will now automatically loot currency from your victims." ,
                        "You will no longer loot currency from your victims."  },   /* autogold */
    { OPT_TYPE_AUTO,    "Looted currency will now be split among your group members.", 
                        "Looted currency will no longer be split among your group members."  },   /* autosplit */
    { OPT_TYPE_AUTO,    "You will now look in corpses when a mob dies.", 
                        "You will no longer look in corpses when a mob dies."  },   /* autolookincorpse */
    { OPT_TYPE_AUTO,    "Styles will now switch even with one selected.", 
                        "Styles will not switch with one selected."  },   /* autoswitchstyles */

    { OPT_TYPE_DISPLAY, "You will now see tradeskill debugging information.",   
                        "You will no longer see tradeskill debugging information." }, /* tradeskill-debugging */
    { OPT_TYPE_DISPLAY, "You will now see combat debugging information.",
                        "You will no longer see combat debugging information."  },   /* combat-debugging */
    { OPT_TYPE_DISPLAY, "You will now see regeneration debugging information.",   
                        "You will no longer see regeneration debugging information."  },   /* regen-debugging */
    { OPT_TYPE_DISPLAY, "You will now see experience debugging information.",   
                        "You will no longer see experience debugging information."  },   /* xp-debugging */
    { OPT_TYPE_DISPLAY, "You will now see saves debugging information.",   
                        "You will no longer see saves debugging information."  },   /* saves-debugging */
    { OPT_TYPE_DISPLAY, "You will no longer see titles in the who list.", 
                        "You will now see titles in the who list."  },   /* no-who-titles */
    { OPT_TYPE_DISPLAY, "You will no longer see guild names in the who list.",
                        "You will now see guild names in the who list."  },   /* no-who-guilds */
    { OPT_TYPE_DISPLAY, "You will no longer see surnames in the who list.",   
                        "You will now see surnames in the who list."  },   /* no-who-surnames */
    { OPT_TYPE_DISPLAY, "You will no longer see a mark denoting emotes.",   
                        "You will now see a mark before emotes."  },   /* no-emote-marks */
    { OPT_TYPE_DISPLAY, "You will now see your full equipment listing.",   
                        "You will now only see equipped slots."  },   /* full-equipment */
    { OPT_TYPE_DISPLAY, "You will now see when your character is autosaved.",   
                        "You will no longer see when your character is autosaved."  },   /* show-autosaves */
    { OPT_TYPE_DISPLAY, "You will now see the condition of what you are attacking after its name.",   
                        "You will no longer see the condition of what you are attacking after its name."  },   /* append-condition */
    { OPT_TYPE_DISPLAY, "You will now see the battle prompt when attacking.",   
                        "You will no longer see the battle prompt when attacking."  },   /* no-battle-prompt */
    { OPT_TYPE_DISPLAY, "You will now be informed when you can use your skills again.",   
                        "You will no longer be informed when you can use your skills again."  },   /* alert-reuse-timers */
    { OPT_TYPE_DISPLAY, "You will now see all skills when you check your abilities.",   
                        "You will now only see your current skills when you check your abilities."  },   /* show-all-skill-levels */
    { OPT_TYPE_DISPLAY, "You will now be informed when your stats are full.",   
                        "You will no longer be informed when your stats are full."  },   /* show-when-full-stats */
    { OPT_TYPE_DISPLAY, "You will now be informed when you are hungry or thirsty.",   
                        "You will no longer be informed when you are hungry or thirsty."  },   /* show-hunger-thirst */
    { OPT_TYPE_DISPLAY, "You will now see a carriage return when a tick cycle passes.",   
                        "You will no longer see a carriage return when a tick cycle passes."  },   /* carriage-return-at-tick */
    { OPT_TYPE_DISPLAY, "You will now be informed when you automatically eat or drink.",   
                        "You will no longer be informed when you automatically eat or drink."  },   /* show-autoeat */
    { OPT_TYPE_DISPLAY, "You will now see subraces in the who list.",   
                        "You will now see races in the who list."  },   /* show-subraces */
    { OPT_TYPE_DISPLAY, "You will no longer see ignore messages.",   
                        "You will now see ignore messages."  },   /* no-ignore-message */
    { OPT_TYPE_DISPLAY, "You will now see object conditions.",
                        "You will no longer see object conditions." }, /* show-obj-cond */ 
    { OPT_TYPE_DISPLAY, "You will now monitor your groups condition.",   
                        "You will no longer monitor your groups condition."  },   /* monitor-group-condition */
    { OPT_TYPE_DISPLAY, "You will now be told when you (or your victims) make a saving throw.",
                        "You will no longer be told when you (or your victims) make a saving throw." },
    { OPT_TYPE_DISPLAY, "You will see the aggression status of NPCs now.",
                        "You will no longer see the aggression status of NPCs." },
    { OPT_TYPE_DISPLAY, "You will now be able to see all with holylight.",
                        "You will no longer be able to see everything with holylight." },
    { OPT_TYPE_SCORE,   "You will now see your bank holdings in your score.",   
                        "You will no longer see your bank holdings in your score."  },   /* score-bank */
    { OPT_TYPE_SCORE,   "You will now see your experience in your score.",   
                        "You will no longer see your experience in your score."  },   /* score-xp */
    { OPT_TYPE_SCORE,   "You will now see your resists in your score.",   
                        "You will no longer see your resists in your score."  },   /* score-resists */
    { OPT_TYPE_SCORE,   "You will now see your current affects in your score.",
                        "You will no longer see your current affects in your score." }, /* "score-affects" */

    { OPT_TYPE_COMM,    "Automatic room decriptions and player titles will now be suppressed.", 
                        "Automatic room decriptions and player titles will now be seen." }, /* brief */ 
    { OPT_TYPE_COMM,    "Like items will now be grouped together when viewing your inventory.", 
                        "All items will be listed individually when viewing your inventory.", }, /* combine */
    { OPT_TYPE_COMM,    "Carriage returns between actions and rounds of combat will be supressed.", 
                        "Carriage returns between actions and rounds of combat will now be seen.", }, /* compact */
    { OPT_TYPE_COMM,    "You will now see your prompt.", 
                        "You will no longer see your prompt.", }, /* prompt */
    { OPT_TYPE_COMM,    "Tells will now beep when they are received.", 
                        "Tells received will no longer beep.", }, /* beeptell */

    { -1,                 NULL,   NULL  }   
};

void do_options( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    long value;
    int option_type, option_index;
    bool turned_on = FALSE;

    if ( IS_NPC(ch) )
    {
        cprintf(ch,"You have no options.\n\r");
        return;
    }

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
        long category = 0;
        int i = 0;
        Buffer *output;
        output = new_buf();

        for (category = option_category_flags[i].bit; option_category_flags[i].name != NULL; i++,
            category = option_category_flags[i].bit)
        {
            int option, col = 0;
            bprintf(output, "  &W==&x &R%s&x &W==&x\n\r", option_category_flags[i].name);

            for(option = 0; option_flags[option].name != NULL; option++)
            { 
                if (!IS_IMMORTAL(ch) && option_flags[option].bit == DISP_HOLYLIGHT &&
                    category == OPT_TYPE_DISPLAY)
                    continue;

                if (category != option_flag_info_table[option].category)
                    continue;

                if( col % 3 == 0 )
                    bprintf(output,"%-20s", option_flags[option].name);
                else
                    bprintf(output,"    %-20s", option_flags[option].name);

                if( option_flag_info_table[option].category == OPT_TYPE_OPTION )
                     bprintf(output, " [%s]", HAS_OPT(ch,option_flags[option].bit) ?  "&GX&x" : " "); 
                else if( option_flag_info_table[option].category == OPT_TYPE_COLOR ) 
                     bprintf(output, " [%s]", HAS_COLOROPT(ch,option_flags[option].bit) ?  "&GX&x" : " " ); 
                else if( option_flag_info_table[option].category == OPT_TYPE_AUTO )
                     bprintf(output, " [%s]", HAS_AUTOOPT(ch,option_flags[option].bit) ?  "&GX&x" : " " ); 
                else if( option_flag_info_table[option].category == OPT_TYPE_DISPLAY )
                     bprintf(output, " [%s]", HAS_DISPOPT(ch,option_flags[option].bit) ?  "&GX&x" : " " ); 
                else if( option_flag_info_table[option].category == OPT_TYPE_SCORE )
                     bprintf(output, " [%s]", HAS_SCOREOPT(ch,option_flags[option].bit) ?  "&GX&x" : " " ); 
                else if( option_flag_info_table[option].category == OPT_TYPE_COMM )
                     bprintf(output, " [%s]", HAS_COMMOPT(ch,option_flags[option].bit) ?  "&GX&x" : " " ); 

                if ( ++col % 3 == 0)
                {
                    bprintf(output,"\n\r");
                }
            }
            
            bprintf(output,"\n\r\n\r");
        }

        page_to_char( buf_string( output ), ch );
        free_buf( output );
        return;
    }
    else
    if ( ( value = flag_value( option_flags, arg ) ) == NO_FLAG ||
            (!IS_IMMORTAL(ch) && !str_prefix(arg, "holylight")) )
    {
        cprintf(ch,"No such option flag '%s'.\n\r", arg );
        return;
    }

    /* Kind of ghetto but made more sense than adding another parameter
       to all flags */
    option_index = option_lookup(arg);

    if(option_index < 0)
    {
        log_bug("do_option: option index < 0");
        return;
    }

    option_type = option_flag_info_table[option_index].category;
    
    if (option_type == OPT_TYPE_OPTION)
    {
        TOGGLE_BIT( ch->pcdata->options, value );
        if(HAS_OPT(ch, value))
            turned_on = TRUE;
    }
    else if (option_type == OPT_TYPE_COLOR)
    {
        TOGGLE_BIT( ch->pcdata->color_options, value );
        if(HAS_COLOROPT(ch, value))
            turned_on = TRUE;
    }
    else if (option_type == OPT_TYPE_AUTO)
    {
        TOGGLE_BIT( ch->pcdata->auto_options, value );
        if(HAS_AUTOOPT(ch, value))
            turned_on = TRUE;
    }
    else if (option_type == OPT_TYPE_DISPLAY)
    {
        TOGGLE_BIT( ch->display, value );
        if(HAS_DISPOPT(ch, value))
            turned_on = TRUE;
    }
    else if (option_type == OPT_TYPE_SCORE)
    {
        TOGGLE_BIT( ch->pcdata->score_options, value );
        if(HAS_SCOREOPT(ch, value))
            turned_on = TRUE;
    }
    else if (option_type == OPT_TYPE_COMM)
    {
        TOGGLE_BIT( ch->pcdata->comm_options, value );
        if(HAS_COMMOPT(ch, value))
            turned_on = TRUE;
    }

    if(turned_on)
        cprintf(ch, "%s\n\r", option_flag_info_table[option_index].on_msg); 
    else
        cprintf(ch, "%s\n\r", option_flag_info_table[option_index].off_msg); 

    if( option_type == OPT_TYPE_OPTION && option_flags[option_index].bit == OPT_NOFOLLOW)
    {
        if( HAS_OPT(ch, OPT_NOFOLLOW) )
            die_follower( ch );
    }

    /* If they changed their color setting, set the descriptor color bit too */
    if( option_type == OPT_TYPE_COLOR && option_flags[option_index].bit == COLOR_TOGGLE)
    {
        ch->desc->color = HAS_COLOROPT(ch, COLOR_TOGGLE);
    }
 
    return;
}

int option_lookup( const char *name)
{
   int option;

   for ( option = 0; option_flags[option].name != NULL; option++)
   {
        if (LOWER(name[0]) == LOWER(option_flags[option].name[0])
        &&  !str_prefix( name,option_flags[option].name))
            return option;
   }

   return -1;
}
