/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> 
#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "tables.h"
#include "recycle.h"

extern	int spell_skill( int spell_sn );

/*
 * Usage:
 *   scribe <spell> from <source> to <destination>
 *
 * Source and destination can be a spellbook or scroll
 */
void do_scribe( Character *ch, char *argument )
{
	Object *obj;
	int	sn;
	int i;
	char	arg[MAX_INPUT_LENGTH];

    if ( class_table[ch->class].group != ARCANE )
	{
		cprintf(ch,"Huh?\n\r");
		return;
	}

	argument = one_argument( argument, arg );

	/* Make sure syntax is right */
	if ( arg[0] == '\0' )
	{
		cprintf(ch,"Syntax: scribe <spell> [destination]\n\r"
                   " * If destination is omitted, the 'held' book is used.\n\r");
		return;
	}

	if ( *argument == '\0' )
	{
		/* get held */
		if ( (obj = get_eq_char( ch, WEAR_HOLD )) == NULL || obj->item_type != ITEM_SPELLBOOK )
		{
			cprintf(ch,"If you don't specify a book in inventory, your held spellbook is used.\n\r"
                       "Except, you're not holding one.\n\r");
			return;
		}
	}
	else
	if ( (obj = get_obj_carry(ch,argument,ch)) == NULL )
	{
		cprintf(ch,"You're not carrying any such object.\n\r");
		return;
	}
	
	/* Find spell */
	if ( ( sn = spell_lookup( arg, 0 ) ) < 1 )
	{
		cprintf(ch,"The spell you want to copy doesn't exist.\n\r");
		return;
	}

	if ( !ch->pcdata->spells[sn] )
	{
		cprintf(ch,"You can't copy a spell that you don't know.\n\r");
		return;
	}

	/* Now make sure the destination object has room for the spell */
	switch( obj->item_type )
	{
		case ITEM_SPELLBOOK:
		{
			SpellIndex* pSpellIndex = get_spell_index( sn );

			if(!pSpellIndex)
			{
				log_bug("do_scribe: Spell index not found(%d)",sn);
				return;
			}

			for( i = 0 ; i < 10 ; i++ )
			{
				if ( get10Bits(obj->value[i]) <= 0 )
				{
					obj->value[i] = set10Bits(obj->value[i],sn);
					actprintf(ch,NULL,obj,TO_CHAR,"You scribe the spell to $P (slot %d).",i+1);
					WAIT_STATE(ch,pSpellIndex->class_level[ch->class]);
					return;
				}
			}

            for( i = 0 ; i < 10 ; i++ )
            {
                if ( get20Bits(obj->value[i]) <= 0 )
                {
                    obj->value[i] = set20Bits(obj->value[i],sn);
                    actprintf(ch,NULL,obj,TO_CHAR,"You scribe the spell to $P (slot %d).",i+11);
                    WAIT_STATE(ch,pSpellIndex->class_level[ch->class]);
                    return; 
                }
            }

			act("$p has no room for a new spell.",ch,obj,NULL,TO_CHAR);
			return;
		}

		default:
			cprintf(ch,"The destination object is not a spellbook.\n\r");
			return;
	}

	/* shouldn't ever get to this point */
	return;
}

void do_copy( Character *ch, char *argument )
{
	Object *sobj, *dobj;
	char arg[MAX_INPUT_LENGTH];
	SpellIndex* pSpellIndex;

    if ( class_table[ch->class].group != ARCANE )   
    {   
        cprintf(ch,"Huh?\n\r");
        return;
    }	

	argument = one_argument( argument, arg );

	if ( arg[0] == '\0' || *argument == '\0' )
	{
		cprintf(ch,"Syntax:  copy <source> <destination>\n\r");
		return;
	}

	if ( (sobj = get_obj_carry(ch,arg,ch)) == NULL )
	{
		cprintf(ch,"You aren't carrying that source scroll.\n\r");
		return;
	}
	else
	if ( sobj->item_type != ITEM_ARCANE_SCROLL )
	{
		act("$p isn't an arcane scroll.",ch,sobj,NULL,TO_CHAR);
		return;
	}

	if ( (dobj = get_obj_carry(ch,arg,ch)) == NULL )
	{
		cprintf(ch,"You aren't carrying that destination scroll.\n\r");
		return;
	}
	else
	if ( dobj->item_type != ITEM_ARCANE_SCROLL )
	{
		act("$p isn't an arcane scroll.",ch,dobj,NULL,TO_CHAR);
		return;
	}
	else
	if ( dobj->value[0] > 0 )
	{
		act("$p contains a spell already!",ch,dobj,NULL,TO_CHAR);
		return;
	}

	/* Check fail chance */
	if ( sobj->value[1] )
	{
		cprintf(ch,"$p cannot be replicated.",ch,sobj,NULL,TO_CHAR);
		return;	
	}

	act("$n tries to copy a spell.",ch,NULL,NULL,TO_ROOM);
	if ( number_percent() < sobj->value[2] )
	{
		act("$p bursts into flame, blackens, and burns away to ashes!",ch,sobj,NULL,TO_CHAR);
		act("$p bursts into flame, blackens, and burns away to ashes!",ch,sobj,NULL,TO_ROOM);
		extract_obj( sobj );
	}

	/* copy */
	dobj->value[0] = sobj->value[0];
 
	/* Adjust difficulties - scrolls have a half-life, basically */
	sobj->value[2] += (( 100 - sobj->value[2] ) / 2);

	/* Dest gets the same treatment, unless it's at 0, in which case it starts at 50 */
	if ( dobj->value[2] <= 0 )
		dobj->value[2] = 0;
	else
		dobj->value[2] += (( 100 - dobj->value[2] ) / 2);

	pSpellIndex = get_spell_index(sobj->value[0]);

	actprintf(ch,sobj,dobj,TO_CHAR,"You copy %s from $p to $P.",pSpellIndex ? pSpellIndex->name : "(null)");
	actprintf(ch,sobj,dobj,TO_ROOM,"$n copies a spell from $p to $P.");
	return;
}
