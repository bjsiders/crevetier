/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "thoc.h"
#include "recycle.h"
#include "interp.h"
#include "tables.h"
#include "styles.h"

void npc_ai_combat( Character *ch )
{
    Character *victim = ch->fighting;

    if ( !victim )
        return;

    // Check for a kick
    if ( skill_table[gsn_kick].skill_level[ch->class] > 0 &&
         IS_SET(ch->off_flags,OFF_KICK) && canUseSkill(ch,gsn_kick) )
        do_kick(ch,"");

    // Check for a bash
    if ( skill_table[gsn_bash].skill_level[ch->class] > 0 &&
         IS_SET(ch->off_flags,OFF_BASH) && canUseSkill(ch,gsn_bash) &&
         victim->daze == 0 && victim->stun_timer == 0 )
        do_bash(ch,"");

    // Berserk!
    if ( skill_table[gsn_berserk].skill_level[ch->class] > 0 &&
         IS_SET(ch->off_flags,OFF_BERSERK) && canUseSkill(ch,gsn_berserk) &&
         number_percent() < 75 )
        do_berserk(ch,"");

    if ( skill_table[gsn_trip].skill_level[ch->class] > 0 &&
         IS_SET(ch->off_flags,OFF_TRIP) && canUseSkill(ch,gsn_trip) &&
         number_percent() < 75 )
        do_trip(ch,"");

    return;
}

