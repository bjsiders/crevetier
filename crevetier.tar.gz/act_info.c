/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/**************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#include <sys/time.h>
#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include <stdarg.h>
#include <errno.h>
#include <unistd.h>

#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "recycle.h"
#include "tables.h"
#include "lookup.h"
#include "olc.h"
#include "color.h"
#include "journal.h"
#include "options.h"
#include "race.h"
#include "object.h"

char *getRankName( Character *ch );
void obj_info_to_char( Object *obj, Character *ch, int sn );
void affects_to_char( Affect *paf, Character *showTo );
int style_lookup( const char *name, int weapon_sn );
void equipment_to_char( Character *ch, Character *victim );
int weaponProfAdj( Character *ch, int fDual );

#define TOGGLE_BIT(var, bit)    ((var) ^= (bit))

extern	char *	dam_type_name[];

char *	const	where_name	[] =
{
    "<used as light>     ",	/* 1 */
    "<worn on finger>    ",	/* 2 */
    "<worn on finger>    ",	/* 3 */
    "<worn around neck>  ",	/* 4 */
    "<worn around neck>  ",	/* 5 */
    "<worn on torso>     ",	/* 6 */
    "<worn on head>      ",	/* 7 */
    "<worn on legs>      ",	/* 8 */
    "<worn on feet>      ",	/* 9 */
    "<worn on hands>     ",	/* 10 */
    "<worn on arms>      ",	/* 11 */
    "<worn as shield>    ",	/* 12 */
    "<worn on back>      ",	/* 13 */
    "<worn about waist>  ",	/* 14 */
    "<worn around wrist> ",	/* 15 */
    "<worn around wrist> ",	/* 16 */
    "<wielded>           ",	/* 17 */
    "<held>              ",	/* 18 */
    "<floating nearby>   ",	/* 19 */
    "<worn in ear>       ",	/* 20 */
    "<worn in ear>       ",	/* 21 */
    "<worn over face>    ",	/* 22 */
    "<worn on shoulders> ",     /* 23 */
	"<wielded offhand>   ", /* 24 */
	"<ranged weapon>     ", /* 25 */
	"<instrument>        ", /* 26 */
};

int const where_order [] =
{
	1,		/* 1  */
 	2,		/* 2  */
	3,		/* 3  */
	4,		/* 4  */
	5,		/* 5  */
	20,		/* 6  */
	21,		/* 7  */
	22,		/* 8  */
	7,		/* 9  */
    23,		/* 10 */
	6,		/* 11 */
	8,		/* 12 */
	9,		/* 13 */
	10,		/* 14 */
	11,		/* 15 */
	12,		/* 16 */
	13,		/* 17 */
	14,		/* 18 */
	15,		/* 19 */
	16,		/* 20 */
	17,		/* 21 */
	24,		/* 22 */
	25,		/* 23 */
	18,		/* 24 */
	19,		/* 25 */
	26,		/* 26 */
};

void formatAffectDescriptionFile( FILE *showTo, Affect *paf )
{
	bool fParen = TRUE;

	/* Most of these are easy */
	switch( paf->where )
	{
		case DAMAGE_OVER_TIME:
			fprintf(showTo,"* %d-%d %s-based damage over time ",
                paf->modifier < paf->location ? paf->modifier : paf->location,
                paf->location > paf->modifier ? paf->location : paf->modifier,
				dam_type_name[paf->bitvector] );
			return;
		case DAMAGE_SHIELD:
			fprintf(showTo,"* %d-%d %s-based damage shield ",
                paf->modifier < paf->location ? paf->modifier : paf->location,
                paf->location > paf->modifier ? paf->location : paf->modifier,
                dam_type_name[paf->bitvector] );
			return;
		case TO_IMMUNE:
			fprintf(showTo,"* adds immunity to %s ",
				flag_string( imm_flags, paf->bitvector ) );
			return;
	}

	switch( paf->location )
	{
		case APPLY_SPEED:
			fprintf(showTo,"* modifies %s by %d%% ",
            	affect_loc_name( paf->location, paf->misc ),
            	(paf->modifier - 100) * -1 );
			break;
		case APPLY_BLADETURN:
			fprintf(showTo,"* bladeturn absorbs %d attack%s",
				(int)paf->duration, paf->duration == 1 ? "" : "s");
			break;
		case APPLY_ROOT:
			fprintf(showTo,"* immobilization ");
			break;
		case APPLY_CONVERT_HP_TO_MANA:
			fprintf(showTo,"* converts %d hp to mana ",
				paf->modifier );
			break;
        default:
			if ( paf->location != 0 )
            	fprintf(showTo,"* modifies %s%s by %+d ",
                    IS_SET(paf->flags,AFF_OBJ) ? "object " : "",
                	affect_loc_name( paf->location, paf->misc ), paf->modifier);
			else
				fParen = FALSE;
			break;
	}

	if ( paf->where == TO_AFFECTS && paf->bitvector != 0 )
	{
		switch( fParen )
		{
		case TRUE:
    		fprintf(showTo,"(adds %s affect) ", flag_string( affect_flags, paf->bitvector ) );
			break;
		case FALSE:
			fprintf(showTo,"* adds %s affect ",  flag_string( affect_flags, paf->bitvector ) );
			break;
		}
	}

	/* Special affects */
	if ( IS_SET( paf->flags, AFF_SPELL ) )
	{
		if ( paf->type == vnum_treeform )
			fprintf(showTo,"* invisibility, enhanced regeneration in forests ");
		else
		if ( paf->type == vnum_detect_animals || paf->type == vnum_detect_animals_d )
			fprintf(showTo,"* adds detect_animals affect ");
		else
		if ( paf->type == vnum_detect_plants )
			fprintf(showTo,"* adds detect_plants affect ");
		else
		if ( paf->type == vnum_detect_humanoids || paf->type == vnum_detect_humanoids_d )
			fprintf(showTo,"* adds detect_humanoids affect ");
		else
		if ( paf->type == vnum_detect_summoned || paf->type == vnum_detect_summoned_d )
			fprintf(showTo,"* adds detect_summoned affect ");
	}
	else
	if ( IS_SET( paf->flags, AFF_SKILL ) )
	{
		if ( paf->type == gsn_concentration )
			fprintf(showTo,"* adds immunity from spell interruption ");
	}

	return;
}

void formatAffectDescription( Character *showTo, Affect *paf )
{
	bool fParen = TRUE;

	/* Most of these are easy */
	switch( paf->where )
	{
		case DAMAGE_OVER_TIME:
			cprintf(showTo,"* %d-%d %s-based damage over time ",
                paf->modifier < paf->location ? paf->modifier : paf->location,
                paf->location > paf->modifier ? paf->location : paf->modifier,
				dam_type_name[paf->bitvector] );
			return;
		case DAMAGE_SHIELD:
			cprintf(showTo,"* %d-%d %s-based damage shield ",
                paf->modifier < paf->location ? paf->modifier : paf->location,
                paf->location > paf->modifier ? paf->location : paf->modifier,
                dam_type_name[paf->bitvector] );
			return;
		case TO_IMMUNE:
			cprintf(showTo,"* adds immunity to %s ",
				flag_string( imm_flags, paf->bitvector ) );
			return;
	}

	switch( paf->location )
	{
		case APPLY_SPEED:
			cprintf(showTo,"* modifies %s by %d%% ",
            	affect_loc_name( paf->location, paf->misc ),
            	(paf->modifier - 100) * -1 );
			break;
		case APPLY_BLADETURN:
			cprintf(showTo,"* bladeturn absorbs %d attack%s",
				paf->duration, paf->duration == 1 ? "" : "s");
			break;
		case APPLY_ROOT:
			cprintf(showTo,"* immobilization ");
			break;
		case APPLY_CONVERT_HP_TO_MANA:
			cprintf(showTo,"* converts %d hp to mana ",
				paf->modifier );
			break;
        case APPLY_WEIGHT:
            cprintf(showTo," * modifies %s%s by %+d.%d ",
                IS_SET(paf->flags,AFF_OBJ) ? "object " : "",
             	affect_loc_name( paf->location, paf->misc ), 
                paf->modifier / 10,
                paf->modifier % 10);
            break;
        default:
			if ( paf->location != 0 )
            	cprintf(showTo,"* modifies %s%s by %+d ",
                    IS_SET(paf->flags,AFF_OBJ) ? "object " : "",
                	affect_loc_name( paf->location, paf->misc ), paf->modifier);
			else
				fParen = FALSE;
			break;
	}

	if ( paf->where == TO_AFFECTS && paf->bitvector != 0 )
	{
		switch( fParen )
		{
		case TRUE:
    		cprintf(showTo,"(adds %s affect) ", flag_string( affect_flags, paf->bitvector ) );
			break;
		case FALSE:
			cprintf(showTo,"* adds %s affect ",  flag_string( affect_flags, paf->bitvector ) );
			break;
		}
	}

	/* Special affects */
	if ( IS_SET( paf->flags, AFF_SPELL ) )
	{
		if ( paf->type == vnum_treeform )
			cprintf(showTo,"* invisibility, enhanced regeneration in forests ");
		else
		if ( paf->type == vnum_detect_animals || paf->type == vnum_detect_animals_d )
			cprintf(showTo,"* adds detect_animals affect ");
		else
		if ( paf->type == vnum_detect_plants )
			cprintf(showTo,"* adds detect_plants affect ");
		else
		if ( paf->type == vnum_detect_humanoids || paf->type == vnum_detect_humanoids_d )
			cprintf(showTo,"* adds detect_humanoids affect ");
		else
		if ( paf->type == vnum_detect_summoned || paf->type == vnum_detect_summoned_d )
			cprintf(showTo,"* adds detect_summoned affect ");
	}
	else
	if ( IS_SET( paf->flags, AFF_SKILL ) )
	{
		if ( paf->type == gsn_concentration )
			cprintf(showTo,"* adds immunity from spell interruption ");
	}

	return;
}

/* for  keeping track of the player count */
int max_on = 0;

/*
 * Local functions.
 */
char *	format_obj_to_char	( Object *obj, Character *ch, bool fShort );
void	show_list_to_char	( Object *list, Character *ch,
				    bool fShort, bool fShowNothing );
void	show_list_with_values_to_char  (Object *list, Character *ch, Character *keeper,
					bool fShort, bool fShowNothing );
void	show_char_to_char_0	 ( Character *victim, Character *ch );
void	show_char_to_char_1	 ( Character *victim, Character *ch );
void	show_char_to_char	 ( Character *list, Character *ch );
bool	check_blind		 ( Character *ch );


char *format_obj_to_char( Object *obj, Character *ch, bool fShort )
{
    static char buf[MAX_STRING_LENGTH];

    buf[0] = '\0';

    if ( obj == NULL )
	    return "- - nothing - -";

    if ( !fShort && IS_SET(obj->extra_flags,ITEM_NOSHOW))
        return buf;

    if ((fShort && (obj->short_descr == NULL || obj->short_descr[0] == '\0')) ||
        (obj->description == NULL || obj->description[0] == '\0'))
	    return buf;

    if ( IS_SET(ch->wiznet,WIZ_DISPVNUM) ) 
    {
	    char tmp[100];
	    snprintf(tmp,sizeof(tmp),"&c[&x%d&c]&x ",obj->pIndexData->vnum );
	    strcat(buf,tmp);
    }

	if ( IS_SET(ch->display,DISP_SHOW_OBJ_COND) )
	{
		char *cond;

		switch( obj->condition )
		{
		case 100: case 99: case 98:  cond = "  "; break;
		case 97: case 96: case 95:   cond = "&W.&x "; break;
		case 94: case 93: case 92:   cond = "&Go&x "; break;
		case 91: case 90: case 89:   cond = "&Y*&x "; break;
		default:                     cond = "&R!&x "; break;
		}

		strcat(buf,cond);
	}
	
    if ( obj->item_type == ITEM_SHRINE )
        strcat( buf, "<Shrine> ");
    if ( IS_OBJ_STAT(obj, ITEM_INVIS) )
        strcat( buf, "(Invis) ");
    if ( IS_AFFECTED(ch, AFF_DETECT_MAGIC ) && IS_OBJ_STAT(obj, ITEM_MAGIC) )
        strcat( buf, "(&CMagical&x) ");

	if ( HAS_COLOROPT(ch, COLOR_OBJ_CON) )
	{
		char conbuf[10];

		memset(conbuf,0,sizeof(conbuf));
		snprintf(conbuf,sizeof(conbuf),"&%c",get_con_color(ch->level,obj->level));
		strcat(buf,conbuf);
	}

    if ( fShort )
    {
	if ( obj->short_descr != NULL )
	    strcat( buf, obj->short_descr );
    }
    else
    {
	if ( obj->description != NULL)
	    strcat( buf, obj->description );
    }

	strcat(buf,"&x");
    return buf;
}



/*
 * Show a list to a character.
 * Can coalesce duplicated items.
 */
void show_list_to_char( Object *list, Character *ch, bool fShort, bool fShowNothing )
{
    char buf[MAX_STRING_LENGTH];
    Buffer *output;
    char **prgpstrShow;
    int *prgnShow;
    char *pstrShow;
    Object *obj;
    int nShow;
    int iShow;
    int count;
    bool fCombine;

    if ( ch->desc == NULL )
		return;

    /*
     * Alloc space for output lines.
     */
    output = new_buf();

    count = 0;
    for ( obj = list; obj != NULL; obj = obj->next_content )
	count++;
    prgpstrShow	= alloc_mem( count * sizeof(char *) );
    prgnShow    = alloc_mem( count * sizeof(int)    );
    nShow	= 0;

    /*
     * Format the list of objects.
     */
    for ( obj = list; obj != NULL; obj = obj->next_content )
    { 
		if ( obj->wear_loc == WEAR_NONE && can_see_obj( ch, obj )) 
		{
	    	pstrShow = format_obj_to_char( obj, ch, fShort );

		    fCombine = FALSE;

		    if ( IS_NPC(ch) || HAS_COMMOPT(ch, COMM_OPT_COMBINE) )
	    	{
				/*
		 		 * Look for duplicates, case sensitive.
		 		 * Matches tend to be near end so run loop backwords.
		 		 */
				for ( iShow = nShow - 1; iShow >= 0; iShow-- )
				{
		    		if ( !strcmp( prgpstrShow[iShow], pstrShow ) )
		    		{
						prgnShow[iShow]++;
						fCombine = TRUE;
						break;
		    		}
				}
	    	}

		    /*
	    	 * Couldn't combine, or didn't want to.
	     	 */
	    	if ( !fCombine )
	    	{
				prgpstrShow [nShow] = str_dup( pstrShow );
				prgnShow    [nShow] = 1;
				nShow++;
	    	}
		}
    }

    /*
     * Output the formatted list.
     */
    for ( iShow = 0; iShow < nShow; iShow++ )
    {
		if (prgpstrShow[iShow][0] == '\0')
		{
	    	free_string(prgpstrShow[iShow]);
	    	continue;
		}

		if ( IS_NPC(ch) || HAS_COMMOPT(ch, COMM_OPT_COMBINE) )
		{
	    	if ( prgnShow[iShow] != 1 )
	    	{
				sprintf( buf, "(%2d) %-40s\n\r", prgnShow[iShow], prgpstrShow[iShow] );
				/*add_buf(output,buf);*/
	    	}
	    	else
	    	{
				/*add_buf(output,"     ");*/
				sprintf( buf, "     %-40s\n\r", prgpstrShow[iShow] );
	    	}
		}
		else
			sprintf( buf, "     %-40s\n\r", prgpstrShow[iShow] );
				
		/*add_buf(output,prgpstrShow[iShow]);
		add_buf(output,"\n\r");*/
		add_buf(output, buf);
		free_string( prgpstrShow[iShow] );
    }

    if ( fShowNothing && nShow == 0 )
    {
		if ( IS_NPC(ch) || HAS_COMMOPT(ch, COMM_OPT_COMBINE) )
	    	send_to_char( "     ", ch );
		
		send_to_char( "Nothing.\n\r", ch );
    }
    
	page_to_char(buf_string(output),ch);

    /*
     * Clean up.
     */
    free_buf(output);
    free_mem( prgpstrShow, count * sizeof(char *) );
    free_mem( prgnShow,    count * sizeof(int)    );

    return;
}

void show_list_with_values_to_char( Object *list, Character *ch, Character *keeper, bool fShort, bool fShowNothing )
{
    char buf[MAX_STRING_LENGTH];
	char single_format_string[MAX_STRING_LENGTH];
	char stack_format_string[MAX_STRING_LENGTH];
	char string_cost[MAX_STRING_LENGTH];
	char string_stack_cost[MAX_STRING_LENGTH];
    Buffer *output;
    Object *obj;
    int nShow = 0, iShow, count = 0, single_cost_len = 0, stack_cost_len = 0;
	int cost = 0, stack_cost = 0;
    bool fCombine;

    if ( ch->desc == NULL )
		return;

    for ( obj = list; obj != NULL; obj = obj->next_content )
		count++;

	if( count > 0)
	{
		int i;
		Object *obj_list[count];
		int obj_count[count];

    	output = new_buf();

		for(i=0; i < count; i++)
		{
			obj_list[i] = NULL;
			obj_count[i] = 0;
		}

    	/*
     	 * Format the list of objects.
     	 */
    	for ( obj = list; obj != NULL; obj = obj->next_content )
    	{ 
			if ( obj->wear_loc == WEAR_NONE && can_see_obj( ch, obj )) 
			{
		    	fCombine = FALSE;

			    if ( IS_NPC(ch) || HAS_COMMOPT(ch, COMM_OPT_COMBINE) )
		    	{
					/*
		 			 * Look for duplicates, case sensitive.
		 			 * Matches tend to be near end so run loop backwords.
		 			 */
					for ( iShow = nShow - 1; iShow >= 0; iShow-- )
					{
						if( obj_list[iShow]->pIndexData->vnum == obj->pIndexData->vnum )
		    			{
							obj_count[iShow]++;
							fCombine = TRUE;
							break;
		    			}
					}
	    		}

			    /*
	    		 * Couldn't combine, or didn't want to.
	     		 */
	    		if ( !fCombine )
	    		{
					obj_list	[nShow] = obj;
					obj_count	[nShow] = 1;
					nShow++;
	    		}
			}
    	}

		/* Find longest number of coin types */
    	for ( iShow = 0; iShow < nShow; iShow++ )
		{
			if(obj_list[iShow] == NULL)
				break;

			if( ( cost = get_cost( keeper, obj_list[iShow], FALSE ) ) < 0 )
				continue;	

			strcpy(string_cost,money_breakdown(cost));
			stripColorInline(string_cost);
			if(strlen(string_cost) > single_cost_len)
				single_cost_len = strlen(string_cost);

			/* Get stack value */
			if(obj_count[iShow] > 1)
				stack_cost = get_stack_cost( keeper, obj_list[iShow], FALSE, obj_count[iShow] );
			else
				stack_cost = cost;

			if(obj_count[iShow] > 1) 
			{
				strcpy(string_stack_cost,money_breakdown(stack_cost));
				stripColorInline(string_stack_cost);
				if(strlen(string_stack_cost) > stack_cost_len)
					stack_cost_len = strlen(string_stack_cost);
			}
		}

		sprintf(single_format_string,"     %%-%ds [%%-%ds]\n\r",
			40,single_cost_len);
		sprintf(stack_format_string,"(%%2d) %%-%ds [%%-%ds] [%%-%ds]\n\r",
			40,single_cost_len, stack_cost_len);

		/*
    	 * Output the formatted list.
     	 */
		if(single_cost_len < 4)
			single_cost_len = 4;

		if(stack_cost_len > 0)
		{
			if(stack_cost_len < 5)
				stack_cost_len = 5;
			sprintf(buf, "[%-*s] [%-*s]      Item\n\r", single_cost_len,"Indv",stack_cost_len,"Stack");
		}
		else
			sprintf(buf, "[%-*s] Item\n\r", single_cost_len,"Indv");

		add_buf(output,buf);

    	for ( iShow = 0; iShow < nShow; iShow++ )
    	{
			long cost, stack_cost;
			if(obj_list[iShow] == NULL)
			{
				break;
			}

			/* Cost of 1 item */
			cost = get_cost( keeper, obj_list[iShow], FALSE );

			/* Get stack value */
			if(obj_count[iShow] > 1)
				stack_cost = get_stack_cost( keeper, obj_list[iShow], FALSE, obj_count[iShow] );
			else
				stack_cost = cost;

			stripColorInline(strcpy(string_cost,money_breakdown(cost)));

			if ( IS_NPC(ch) || HAS_COMMOPT(ch, COMM_OPT_COMBINE) )
			{
				if ( obj_count[iShow] > 1)
	    		{
					stripColorInline(strcpy(string_stack_cost,money_breakdown(stack_cost)));
					if(stack_cost_len > 0)
						sprintf( buf, "[%-*s] [%-*s] (%2d) %-40s\n\r", 
	    					single_cost_len, string_cost, stack_cost_len, string_stack_cost, 
							obj_count[iShow], format_obj_to_char( obj_list[iShow], ch, fShort ) );
					else
						sprintf( buf, "[%-*s] (%2d) %-40s\n\r", 
	    					single_cost_len, string_cost, obj_count[iShow], 
							format_obj_to_char( obj_list[iShow], ch, fShort ) );
	    		}
	    		else
	    		{
					if(stack_cost_len > 0)
						sprintf( buf, "[%-*s] [%-*s]      %-40s\n\r", single_cost_len, string_cost, 
							stack_cost_len, "", 
							format_obj_to_char( obj_list[iShow], ch, fShort ) ); 
					else
						sprintf( buf, "[%-*s] %-40s\n\r", single_cost_len, string_cost,
							format_obj_to_char( obj_list[iShow], ch, fShort ) ); 
	    		}
			}
			else
			{
				if(stack_cost_len > 0)
					sprintf( buf, "[%-*s] [%-*s]      %-40s\n\r", single_cost_len, string_cost, 
						stack_cost_len, "", 
						format_obj_to_char( obj_list[iShow], ch, fShort ) ); 
				else
					sprintf( buf, "[%-*s] %-40s\n\r", single_cost_len, string_cost,
						format_obj_to_char( obj_list[iShow], ch, fShort ) ); 
			}
				
			add_buf(output, buf);
    	}

		if ( fShowNothing && nShow == 0 )
		{
			if ( IS_NPC(ch) || HAS_COMMOPT(ch, COMM_OPT_COMBINE) )
	    		send_to_char( "     ", ch );
		
			send_to_char( "Nothing.\n\r", ch );
    	}
    
		page_to_char(buf_string(output),ch);

    	free_buf(output);
	}

    return;
}



void show_char_to_char_0( Character *victim, Character *ch )
{
    char buf[MAX_STRING_LENGTH],message[MAX_STRING_LENGTH];

    buf[0] = '\0';

    if ( IS_NPC(victim) && IS_SET(ch->wiznet,WIZ_DISPVNUM) )
    {
	char tmp[100];

	snprintf(tmp,sizeof(tmp),"&c[&x%d&c]&x ", victim->pIndexData->vnum );
	strcat(buf,tmp);
    }

    if ( IS_SET(victim->comm,COMM_AFK	  )   ) strcat( buf, "[&cAway&x] "	     );
	if ( is_affected(victim,gsn_stealth,AFF_SKILL)) strcat(buf,"(Stealth) "  );
    if ( IS_AFFECTED(victim, AFF_INVISIBLE)   ) strcat( buf, "(Invis) "      );
    if ( victim->invis_level >= LEVEL_HERO    ) strcat( buf, "(Wizi) "	     );
    if ( IS_AFFECTED(victim, AFF_CHARM)       ) strcat( buf, "(Charmed) "    );
    if ( IS_AFFECTED(victim, AFF_PASS_DOOR)   ) strcat( buf, "(Translucent) ");
    if ( IS_AFFECTED(victim, AFF_FAERIE_FIRE) ) strcat( buf, "(&MPink Aura&x) "  );
    if ( IS_EVIL(victim)
    &&   IS_AFFECTED(ch, AFF_DETECT_EVIL)     ) strcat( buf, "(&RRed Aura&x) "   );
    if ( IS_GOOD(victim)
    &&   IS_AFFECTED(ch, AFF_DETECT_GOOD)     ) strcat( buf, "(&YGolden Aura&x) ");
	if ( (is_affected(ch,vnum_detect_summoned,AFF_SPELL)||is_affected(ch,vnum_detect_summoned_d,AFF_SPELL)) && 
  		 IS_SET( victim->form, FORM_SUMMONED ) ) strcat(buf, "(&RSummoned&x) " );
	if ( (is_affected(ch,vnum_detect_animals,AFF_SPELL)||is_affected(ch,vnum_detect_animals_d,AFF_SPELL)) && 
  		 IS_SET( victim->form, FORM_ANIMAL ) ) strcat(buf, "(&rAnimal&x) " );
	if ( is_affected(ch,vnum_detect_plants,AFF_SPELL) && 
  		 IS_SET( victim->form, FORM_PLANT ) ) strcat(buf, "(&gPlant&x) " );
	if ( (is_affected(ch,vnum_detect_humanoids,AFF_SPELL)||is_affected(ch,vnum_detect_humanoids_d,AFF_SPELL)) && 
  		 IS_SET( victim->form, FORM_HUMANOID ) ) strcat(buf, "(Humanoid) " );
    if ( IS_AFFECTED(victim,AFF_MESMERIZE)) strcat(buf,"(Mesmerized) " );

	if ( IS_NPC(victim) )
	{
		if ( IS_SET(victim->act,ACT_TRAIN) )	strcat(buf, "<Trainer> ");
		if ( IS_SET(victim->act,ACT_BANKER) )	strcat(buf, "<Banker> ");
		if ( IS_SET(victim->act,ACT_TELEPORTER) ) strcat(buf, "<Teleporter> ");
		if ( victim->pIndexData->pShop != NULL )		strcat(buf, "<Merchant> ");
		if ( IS_SET(victim->act,ACT_GUARD) )	strcat(buf, "<Guard> ");
		if ( IS_SET(victim->act,ACT_IS_HEALER) )	strcat(buf, "<Healer> ");
		if ( IS_SET(victim->act,ACT_REGISTRAR) ) strcat(buf,"<Registrar> ");
		if ( IS_SET(victim->act,ACT_SMITHY) ) strcat(buf,"<Smithy> ");
	}

	if ( HAS_COLOROPT(ch, COLOR_MOB_CON) )
	{
		char conBuf[5];

		snprintf(conBuf,sizeof(conBuf),"&%c", get_con_color(ch->level,victim->level) );
		strcat(buf,conBuf);
	}
		
    if ( victim->position == victim->start_pos && victim->long_descr[0] != '\0' )
    {
	strcat( buf, victim->long_descr );
	strcat( buf, "&x");
	send_to_char( buf, ch );
	return;
    }

    strcat( buf, PERS( victim, ch ) );
    if ( !IS_NPC(victim) && !HAS_COMMOPT(ch, COMM_OPT_BRIEF) && 
         victim->position == POS_STANDING && ch->on == NULL )
	{
		char *tmp = decolorize( victim->pcdata->title );
		strcat( buf, tmp );
	}

    switch ( victim->position )
    {
    case POS_DEAD:     strcat( buf, " is DEAD!!" );              break;
    case POS_MORTAL:   strcat( buf, " is mortally wounded." );   break;
    case POS_INCAP:    strcat( buf, " is incapacitated." );      break;
    case POS_STUNNED:  strcat( buf, " is lying here stunned." ); break;
    case POS_SLEEPING: 
	if (victim->on != NULL)
	{
	    if (IS_SET(victim->on->value[2],SLEEP_AT))
  	    {
		sprintf(message," is sleeping at %s.",
		    victim->on->short_descr);
		strcat(buf,message);
	    }
	    else if (IS_SET(victim->on->value[2],SLEEP_ON))
	    {
		sprintf(message," is sleeping on %s.",
		    victim->on->short_descr); 
		strcat(buf,message);
	    }
	    else
	    {
		sprintf(message, " is sleeping in %s.",
		    victim->on->short_descr);
		strcat(buf,message);
	    }
	}
	else 
	    strcat(buf," is sleeping here.");
	break;
    case POS_RESTING:  
        if (victim->on != NULL)
	{
            if (IS_SET(victim->on->value[2],REST_AT))
            {
                sprintf(message," is resting at %s.",
                    victim->on->short_descr);
                strcat(buf,message);
            }
            else if (IS_SET(victim->on->value[2],REST_ON))
            {
                sprintf(message," is resting on %s.",
                    victim->on->short_descr);
                strcat(buf,message);
            }
            else 
            {
                sprintf(message, " is resting in %s.",
                    victim->on->short_descr);
                strcat(buf,message);
            }
	}
        else
	    strcat( buf, " is resting here." );       
	break;
    case POS_SITTING:  
        if (victim->on != NULL)
        {
            if (IS_SET(victim->on->value[2],SIT_AT))
            {
                sprintf(message," is sitting at %s.",
                    victim->on->short_descr);
                strcat(buf,message);
            }
            else if (IS_SET(victim->on->value[2],SIT_ON))
            {
                sprintf(message," is sitting on %s.",
                    victim->on->short_descr);
                strcat(buf,message);
            }
            else
            {
                sprintf(message, " is sitting in %s.",
                    victim->on->short_descr);
                strcat(buf,message);
            }
        }
        else
	    strcat(buf, " is sitting here.");
	break;
    case POS_STANDING: 
	if (victim->on != NULL)
	{
	    if (IS_SET(victim->on->value[2],STAND_AT))
	    {
		sprintf(message," is standing at %s.",
		    victim->on->short_descr);
		strcat(buf,message);
	    }
	    else if (IS_SET(victim->on->value[2],STAND_ON))
	    {
		sprintf(message," is standing on %s.",
		   victim->on->short_descr);
		strcat(buf,message);
	    }
	    else
	    {
		sprintf(message," is standing in %s.",
		    victim->on->short_descr);
		strcat(buf,message);
	    }
	}
	else
	    strcat( buf, " is here." );               
	break;
    case POS_FIGHTING:
		strcat( buf, " is here, fighting " );
		if ( victim->fighting == NULL )
	    	strcat( buf, "thin air??" );
		else if ( victim->fighting == ch )
	    	strcat( buf, "YOU!" );
		else if ( victim->in_room == victim->fighting->in_room )
		{
	    	strcat( buf, PERS( victim->fighting, ch ) );
	    	strcat( buf, "." );
		}
		else
	    	strcat( buf, "someone who left??" );
		break;
    }

	act(buf,ch,NULL,NULL,TO_CHAR);

    if ( IS_SET(ch->display,DISP_SHOW_AGGRESSION) && IS_NPC(victim) )
    {
        // if the NPC is not aggressive, we don't really care about its disposition
        if ( !is_aggressive( victim, ch, FALSE ) )
            act("$N is not aggressive towards you.",ch,NULL,victim,TO_CHAR);
        else
        {
            if ( why_aggressive( victim, ch ) != NULL )
                actprintf(ch,NULL,victim,TO_CHAR,"$N is %s, because $E %s.",
                    dispositionName( get_melee_disposition(victim,ch) ),
                    why_aggressive( victim, ch ) );
            else
                act("$N is aggressive for unknown reasons.",ch,NULL,victim,TO_CHAR);
        }
    }

    return;
}



void show_char_to_char_1( Character *victim, Character *ch )
{
    char buf[MAX_STRING_LENGTH];
    int percent;

    if ( can_see( victim, ch ) )
    {
	if (ch == victim)
	    act( "$n looks at $mself.",ch,NULL,NULL,TO_ROOM);
	else
	{
	    act( "$n looks at you.", ch, NULL, victim, TO_VICT    );
	    act( "$n looks at $N.",  ch, NULL, victim, TO_NOTVICT );
	}
    }

    if ( victim->description[0] != '\0' )
    {
		send_to_char( victim->description, ch );
    }
    else
    {
		act( "You see nothing special about $M.", ch, NULL, victim, TO_CHAR );
    }

    if ( victim->max_stat_hit > 0 )
		percent = ( 100 * victim->stat_hit ) / max_stat_hit(victim);
    else
		percent = -1;

    strcpy( buf, PERS(victim, ch) );

    if (percent >= 100) 
	strcat( buf, " is in excellent condition.\n\r");
    else if (percent >= 90) 
	strcat( buf, " has a few scratches.\n\r");
    else if (percent >= 75) 
	strcat( buf," has some small wounds and bruises.\n\r");
    else if (percent >=  50) 
	strcat( buf, " has quite a few wounds.\n\r");
    else if (percent >= 30)
	strcat( buf, " has some big nasty wounds and scratches.\n\r");
    else if (percent >= 15)
	strcat ( buf, " looks pretty hurt.\n\r");
    else if (percent >= 0 )
	strcat (buf, " is in awful condition.\n\r");
    else
	strcat(buf, " is bleeding to death.\n\r");

    buf[2] = UPPER(buf[2]);
    send_to_char( buf, ch );

	equipment_to_char(ch,victim);
    return;
}


void do_peek( Character *ch, char *argument )
{
    Character *victim;
    char arg[MAX_INPUT_LENGTH];

    if ( !HAS_PROF(ch,gsn_case) )
    {
        cprintf(ch,"You do not have the Case ability.\n\r");
        return;
    }

    one_argument( argument, arg );
    if( (victim=get_char_room(ch,argument)) == NULL )
    {
	    cprintf(ch,"You don't see that person here.\n\r");
	    return;
    }

    if ( victim != ch && !IS_NPC(ch)
         && ( IS_IMMORTAL(ch) || ch->level + dice(1,10) > victim->level + dice(1,10) ) )
    {
        int i;

        act("You peek at $N's inventory:\n\r", ch, NULL, victim, TO_CHAR );
        show_list_to_char( victim->carrying, ch, TRUE, TRUE );
        cprintf(ch,"\n\r");
        for( i=0; i<MAX_CURRENCY; i++ )
            cprintf(ch,"%-12s: %d\n\r", currency_table[i].name, victim->coins[i] );
            
        // ALertness and IMMs
        if ( (HAS_PROF(victim,gpn_alertness) &&
                victim->level + dice(1,10) > ch->level + dice(1,10)) || IS_IMMORTAL(victim) )
            act("$n checks out your inventory.",ch,NULL,victim,TO_VICT);
    }
    else
        act("You can't see the inventory without being obvious.",ch,NULL,victim,TO_CHAR);
}

void show_char_to_char( Character *list, Character *ch )
{
    Character *rch;

    for ( rch = list; rch != NULL; rch = rch->next_in_room )
    {
	if ( rch == ch )
	    continue;

	if ( get_trust(ch) < rch->invis_level)
	    continue;

	if ( can_see( ch, rch ) )
	{
	    show_char_to_char_0( rch, ch );
	}
	else if ( room_is_dark( ch->in_room )
	&&        IS_AFFECTED(rch, AFF_INFRARED ) )
	{
	    send_to_char( "You see glowing red eyes watching YOU!\n\r", ch );
	}
    }

    return;
} 



bool check_blind( Character *ch )
{

    if (!IS_NPC(ch) && IS_SET(ch->display,DISP_HOLYLIGHT))
	return TRUE;

    if ( IS_AFFECTED(ch, AFF_BLIND) )
    { 
	send_to_char( "You can't see a thing!\n\r", ch ); 
	return FALSE; 
    }

    return TRUE;
}

/* changes your scroll */
void do_scroll(Character *ch, char *argument)
{
    char arg[MAX_INPUT_LENGTH];
    char buf[100];
    int lines;

    one_argument(argument,arg);
    
    if (arg[0] == '\0')
    {
	if (ch->lines == 0)
	    send_to_char("You do not page long messages.\n\r",ch);
	else
	{
	    sprintf(buf,"You currently display %d lines per page.\n\r",
		    ch->lines + 2);
	    send_to_char(buf,ch);
	}
	return;
    }

    if (!is_number(arg))
    {
	send_to_char("You must provide a number.\n\r",ch);
	return;
    }

    lines = atoi(arg);

    if (lines == 0)
    {
        send_to_char("Paging disabled.\n\r",ch);
        ch->lines = 0;
        return;
    }

    if (lines < 10 || lines > 100)
    {
	send_to_char("You must provide a reasonable number.\n\r",ch);
	return;
    }

    sprintf(buf,"Scroll set to %d lines.\n\r",lines);
    send_to_char(buf,ch);
    ch->lines = lines - 2;
}

/* RT does socials */
void do_socials(Character *ch, char *argument)
{
    char buf[MAX_STRING_LENGTH];
    int iSocial;
    int col;
     
    col = 0;
   
    for (iSocial = 0; social_table[iSocial].name[0] != '\0'; iSocial++)
    {
	sprintf(buf,"%-12s",social_table[iSocial].name);
	send_to_char(buf,ch);
	if (++col % 6 == 0)
	    send_to_char("\n\r",ch);
    }

    if ( col % 6 != 0)
	send_to_char("\n\r",ch);
    return;
}

void do_release(Character *ch, char *argument)
{
    if ( ch->pet == NULL )
    {
        cprintf( ch, "You do not control a pet to release.\n\r" );
        return;
    }
 
    stop_follower(ch->pet, TRUE);
} 
 
/* RT Commands to replace news, motd, imotd, etc from ROM */

void do_motd(Character *ch, char *argument)
{
    do_function(ch, &do_help, "motd");
}

void do_imotd(Character *ch, char *argument)
{  
    do_function(ch, &do_help, "imotd");
}

void do_rules(Character *ch, char *argument)
{
    do_function(ch, &do_help, "rules");
}

void do_story(Character *ch, char *argument)
{
    do_function(ch, &do_help, "story");
}

void do_wizlist(Character *ch, char *argument)
{
    do_function(ch, &do_help, "wizlist");
}

void do_prompt(Character *ch, char *argument)
{
   char buf[MAX_STRING_LENGTH];
 
   if ( argument[0] == '\0' )
   {
	if (HAS_COMMOPT(ch, COMM_OPT_PROMPT))
   	{
       cprintf(ch,"Your current prompt is: %s\n\r",ch->prompt);
       return;
    }
   }
 
   if( !strcmp( argument, "all" ) )
      strcpy( buf, "<%bbase %hhits %mmana %sstam %vmoves> ");
   else
   {
      if ( strlen(argument) > 50 )
         argument[50] = '\0';
      strcpy( buf, argument );
      smash_tilde( buf );
      if (str_suffix("%c",buf))
	strcat(buf," ");
	
   }
 
   free_string( ch->prompt );
   ch->prompt = str_dup( buf );
   sprintf(buf,"Prompt set to %s\n\r",ch->prompt );
   send_to_char(buf,ch);
   return;
}

void do_look( Character *ch, char *argument )
{
    char buf  [MAX_STRING_LENGTH];
    char arg1 [MAX_INPUT_LENGTH];
    char arg2 [MAX_INPUT_LENGTH];
    char arg3 [MAX_INPUT_LENGTH];
    Exit *pexit;
    Character *victim;
    Object *obj;
    char *pdesc;
    int door;
    int number,count;
	bool fRandom = FALSE;
	Room	*room;
	Building *bld;

    if ( ch->desc == NULL )
	return;

    if ( ch->position < POS_SLEEPING )
    {
	send_to_char( "You can't see anything but stars!\n\r", ch );
	return;
    }

    if ( ch->position == POS_SLEEPING )
    {
	send_to_char( "You can't see anything, you're sleeping!\n\r", ch );
	return;
    }

    if ( !check_blind( ch ) )
	return;

    if ( !IS_NPC(ch)
    &&   !IS_SET(ch->display, DISP_HOLYLIGHT)
    &&   room_is_dark( ch->in_room ) )
    {
	send_to_char( "It is pitch black ... \n\r", ch );
	show_char_to_char( ch->in_room->people, ch );
	return;
    }

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );
    number = number_argument(arg1,arg3);
    count = 0;

    if ( arg1[0] == '\0' || !str_cmp( arg1, "auto" ) )
    {
		/* 'look' or 'look auto' */
		if ( IS_IMMORTAL(ch) )
	    	cprintf(ch,"%s &c[&x%d&c]&x - ", ch->in_room->area->name, ch->in_room->area->vnum );

		/* Check for hallucination */
		fRandom = (is_affected(ch,vnum_minor_hallucination,AFF_SPELL) ||
                   is_affected(ch,vnum_major_hallucination,AFF_SPELL) ||
                   is_affected(ch,vnum_scorpion_venom,AFF_SPELL));
		room = fRandom ? get_random_room(ch) : ch->in_room;

		cprintf(ch,"&c%s&x",room->name);

		if (IS_IMMORTAL(ch) && IS_SET(ch->wiznet,WIZ_DISPVNUM) )
	    	cprintf(ch," &c[&x%d&c]&x",room->vnum);

		send_to_char( "\n\r", ch );

		if ( arg1[0] == '\0' || ( !IS_NPC(ch) && !HAS_COMMOPT(ch, COMM_OPT_BRIEF) ) )
		{
	    	cprintf(ch, "  ");
	    	cprintf(ch, room->description);
		}

		if ( room->buildings != NULL )
		{
			Building *bld;

			cprintf(ch,"\n\r");
			for( bld = room->buildings; bld != NULL ; bld = bld->next )
			{
                if ( clan_is_independent( bld->clan_owner ) )
                    cprintf(ch,"There is a public %s %shere.\n\r",
                        flag_string( building_flags, bld->type ),
                        IS_SET(bld->flags,BUILDING_UNDER_CONSTRUCTION) ? "under construction " :
                            IS_SET(bld->flags,BUILDING_UPGRADE) ? "under rennovation " : "");
                else
				    cprintf(ch,"There is a %s %shere, bearing the emblem of the clan %s.\n\r",
					    flag_string( building_flags, bld->type ), 
					    IS_SET(bld->flags,BUILDING_UNDER_CONSTRUCTION) ? "under construction " : 
						    IS_SET(bld->flags,BUILDING_UPGRADE) ? "under rennovation " : "",
					    bld->clan_owner->name );
			}
		}	

    	if ( !IS_NPC(ch) && HAS_AUTOOPT(ch, AUTO_EXIT) )
		{
            char exit_string[MAX_STRING_LENGTH];
	    	cprintf(ch,"\n\r");
            create_exit_string(ch, EX_SHOW_AUTO, exit_string);
		}
	
		show_list_to_char( ch->in_room->contents, ch, FALSE, FALSE );
		show_char_to_char( ch->in_room->people,   ch );
		return;
    }

	// 'look building'
	if ( (bld = get_building_room(ch,arg1)) != NULL )
	{
        // show stats on hall
        cprintf(ch,"The %s of clan %s is a level %d %s structure with %d/%d structure.\n\r",
            flag_string( building_flags, bld->type ), bld->clan_owner->name,
            bld->level, bld->material == BUILDMAT_WOOD ? "wood" : "stone",
            bld->curr_structure, bld->max_structure );
        if ( bld->available_resources > 0 )
            cprintf(ch,"This building is %s, and has %d %s available for building.\n\r",
                IS_SET(bld->flags,BUILDING_UNDER_CONSTRUCTION) ? "under construction" :
                    IS_SET(bld->flags,BUILDING_UPGRADE) ? "being rennovated" : "overstocked",
                bld->available_resources, bld->material == BUILDMAT_WOOD ? "wood" : "stone" );
		return;
	}

    if ( !str_cmp( arg1, "i" ) || !str_cmp(arg1, "in")  || !str_cmp(arg1,"on"))
    {
	/* 'look in' */
	if ( arg2[0] == '\0' )
	{
	    send_to_char( "Look in what?\n\r", ch );
	    return;
	}

	if ( ( obj = get_obj_here( ch, arg2 ) ) == NULL )
	{
	    send_to_char( "You do not see that here.\n\r", ch );
	    return;
	}

	switch ( obj->item_type )
	{
	default:
	    send_to_char( "That is not a container.\n\r", ch );
	    break;

	case ITEM_DRINK_CON:
	    if ( obj->value[1] <= 0 )
	    {
		send_to_char( "It is empty.\n\r", ch );
		break;
	    }

	    sprintf( buf, "It's %sfilled with a %s liquid.\n\r",
		obj->value[1] <     obj->value[0] / 4
		    ? "less than half-" :
		obj->value[1] < 3 * obj->value[0] / 4
		    ? "about half-"     : "more than half-",
		liq_table[obj->value[2]].liq_color
		);

	    send_to_char( buf, ch );
	    break;

	case ITEM_CONTAINER:
	case ITEM_CORPSE_NPC:
	case ITEM_CORPSE_PC:
	    if ( IS_SET(obj->value[1], CONT_CLOSED) )
	    {
		send_to_char( "It is closed.\n\r", ch );
		break;
	    }

	case ITEM_MOBILE:
	case ITEM_FORGE:
	    act( "$p holds:", ch, obj, NULL, TO_CHAR );
	    show_list_to_char( obj->contains, ch, TRUE, TRUE );
	    break;
	}
	return;
    }

    if ( ( victim = get_char_room( ch, arg1 ) ) != NULL )
    {
	show_char_to_char_1( victim, ch );
	return;
    }

    for ( obj = ch->carrying; obj != NULL; obj = obj->next_content )
    {
	if ( can_see_obj( ch, obj ) )
	{  /* player can see object */
	    pdesc = get_extra_descr( arg3, obj->extra_descr );
	    if ( pdesc != NULL )
	    {
	    	if (++count == number)
	    	{
		    send_to_char( pdesc, ch );
		    return;
	    	}
	    	else continue;
	    }

 	    pdesc = get_extra_descr( arg3, obj->pIndexData->extra_descr );
 	    if ( pdesc != NULL )
	    {
 	    	if (++count == number)
 	    	{	
		    send_to_char( pdesc, ch );
		    return;
	     	}
		else continue;
	    }

	    if ( is_name( arg3, obj->name ) )
 	    {
	    	if (++count == number)
	    	{
	    	    send_to_char( obj->description, ch );
	    	    send_to_char( "\n\r",ch);
		    return;
		  }
	    }
	  }
    }

    for ( obj = ch->in_room->contents; obj != NULL; obj = obj->next_content )
    {
	if ( can_see_obj( ch, obj ) )
	{
	    pdesc = get_extra_descr( arg3, obj->extra_descr );
	    if ( pdesc != NULL )
	    	if (++count == number)
	    	{
		    send_to_char( pdesc, ch );
		    return;
	    	}

	    pdesc = get_extra_descr( arg3, obj->pIndexData->extra_descr );
	    if ( pdesc != NULL )
	    	if (++count == number)
	    	{
		    send_to_char( pdesc, ch );
		    return;
	    	}

	    if ( is_name( arg3, obj->name ) )
		if (++count == number)
		{
		    send_to_char( obj->description, ch );
		    send_to_char("\n\r",ch);
		    return;
		}
	}
    }

    pdesc = get_extra_descr(arg3,ch->in_room->extra_descr);
    if (pdesc != NULL)
    {
	if (++count == number)
	{
	    send_to_char(pdesc,ch);
	    return;
	}
    }
    
    if (count > 0 && count != number)
    {
    	if (count == 1)
    	    sprintf(buf,"You only see one %s here.\n\r",arg3);
    	else
    	    sprintf(buf,"You only see %d of those here.\n\r",count);
    	
    	send_to_char(buf,ch);
    	return;
    }

         if ( !str_cmp( arg1, "n" ) || !str_cmp( arg1, "north" ) ) door = 0;
    else if ( !str_cmp( arg1, "e" ) || !str_cmp( arg1, "east"  ) ) door = 1;
    else if ( !str_cmp( arg1, "s" ) || !str_cmp( arg1, "south" ) ) door = 2;
    else if ( !str_cmp( arg1, "w" ) || !str_cmp( arg1, "west"  ) ) door = 3;
    else if ( !str_cmp( arg1, "u" ) || !str_cmp( arg1, "up"    ) ) door = 4;
    else if ( !str_cmp( arg1, "d" ) || !str_cmp( arg1, "down"  ) ) door = 5;
    else
    {
	send_to_char( "You do not see that here.\n\r", ch );
	return;
    }

    /* 'look direction' */
    if ( ( pexit = ch->in_room->exit[door] ) == NULL )
    {
	send_to_char( "Nothing special there.\n\r", ch );
	return;
    }

    if ( IS_SET(pexit->exit_info, EX_CLOSED) )
    {
         act( "The $T is closed.", ch, NULL, exitName(pexit), TO_CHAR );
    } 
    else 
    {
        Room *temp_room;

        temp_room = ch->in_room;
        ch->in_room = ch->in_room->exit[door]->u1.to_room;
        if (ch->in_room != NULL) 
            do_look (ch,"auto");
        else 
            log_bug("NULL in do_look.",0);
        ch->in_room = temp_room;
    }


    return;
}

void do_examine( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    char arg[MAX_INPUT_LENGTH];
    Object *obj;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Examine what?\n\r", ch );
	return;
    }

    do_function(ch, &do_look, arg );

    if ( ( obj = get_obj_here( ch, arg ) ) != NULL )
    {
	switch ( obj->item_type )
	{
	default:
	    break;
	
	case ITEM_MONEY:
	    if (obj->value[0] == 0)
	    {
	        if (obj->value[1] == 0)
		    sprintf(buf,"Odd...there's no coins in the pile.\n\r");
		else if (obj->value[1] == 1)
		    sprintf(buf,"Wow. One gold coin.\n\r");
		else
		    sprintf(buf,"There are %d gold coins in the pile.\n\r",
			obj->value[1]);
	    }
	    else if (obj->value[1] == 0)
	    {
		if (obj->value[0] == 1)
		    sprintf(buf,"Wow. One silver coin.\n\r");
		else
		    sprintf(buf,"There are %d silver coins in the pile.\n\r",
			obj->value[0]);
	    }
	    else
		sprintf(buf,
		    "There are %d gold and %d silver coins in the pile.\n\r",
		    obj->value[1],obj->value[0]);
	    send_to_char(buf,ch);
	    break;

	case ITEM_DRINK_CON:
	case ITEM_CONTAINER:
	case ITEM_FORGE:
	case ITEM_CORPSE_NPC:
	case ITEM_CORPSE_PC:
	    sprintf(buf,"in %s",argument);
	    do_function(ch, &do_look, buf );
	}
    }

    return;
}


/*
 * Thanks to Zrin for auto-exit part.
 */
void do_exits( Character *ch, char *argument )
{
    char exit_string[MAX_STRING_LENGTH];
    create_exit_string(ch, EX_SHOW_LOOK,exit_string);
}

void create_exit_string( Character *ch, int show_type, char* exit_string )
{
    extern char * const dir_name[];
    char buf[MAX_STRING_LENGTH];
	char df[MAX_STRING_LENGTH];
    Exit *pexit;
    bool found;
    bool fAuto = FALSE, fPrompt = FALSE, fRandom = FALSE;
    int door;
	bool fHidden;
    const char *promptdir_name[] = {"N","E","S","W","U","D"};

    buf[0] = '\0';

    if( show_type == EX_SHOW_AUTO )
        fAuto = TRUE;
    else if( show_type == EX_SHOW_PROMPT )
        fPrompt = TRUE;

	fRandom = (is_affected(ch,vnum_minor_hallucination,AFF_SPELL) || is_affected(ch,vnum_major_hallucination,AFF_SPELL) || is_affected(ch,vnum_scorpion_venom,AFF_SPELL));

    if ( !check_blind( ch ) )
	    return;

    if(!fPrompt)
    {
        if (fAuto)
		    sprintf(buf,"[&gExits&x: &W");
        else if (IS_IMMORTAL(ch))
		    sprintf(buf,"Obvious exits from room %d:\n\r",ch->in_room->vnum);
        else
		    sprintf(buf,"Obvious exits:\n\r");
    }

    found = FALSE;
    for ( door = 0; door <= 5; door++ )
    {
		bool fClosed = FALSE, fLocked = FALSE;

		if ( fRandom && number_percent() < 25 )
		{
			strcat(buf, " ");
    
            if(fPrompt)
                strcat(buf, promptdir_name[door]);
            else
			    strcat(buf, dir_name[door] );
		}
		else
		if ( ( ( pexit = ch->in_room->exit[door] ) != NULL &&
	 			 pexit->u1.to_room != NULL && can_see_room(ch,pexit->u1.to_room) ))
		{
			// Check for hidden doors - closed and hidden doors don't show up
			// Open hidden doors are displayed normally.
			fHidden = FALSE;
			if ( IS_SET(pexit->exit_info, EX_HIDDEN) && IS_SET(pexit->exit_info, EX_CLOSED) )
			{
				if(IS_IMMORTAL(ch))
					fHidden = TRUE;
				else
					continue;
			}

	    	found = TRUE;

			if ( IS_SET(pexit->exit_info, EX_CLOSED))
				fClosed = TRUE;
			if ( IS_SET(pexit->exit_info, EX_LOCKED) && get_skill(ch,gsn_open_lock) > 0 )
				fLocked = TRUE;

	    	if ( fAuto )
	    	{
				strcat( buf, " " );
				/* Format door */
				sprintf(df,"%s%s%s",
					fHidden ? "{" : (fLocked ? "<" : ( fClosed ? "(" : "" )),
					dir_name[door],
					fHidden ? "}" : (fLocked ? ">" : ( fClosed ? ")" : "" )) );
				strcat( buf, df );
	    	}
	    	else if ( fPrompt )
	    	{
				/* Format door */
				sprintf(df,"%s%s%s",
					fHidden ? "{" : (fLocked ? "<" : ( fClosed ? "(" : "" )),
					promptdir_name[door],
					fHidden ? "}" : (fLocked ? ">" : ( fClosed ? ")" : "" )) );
				strcat( buf, df );
	    	}
	    	else
	    	{
				sprintf( buf + strlen(buf), "%-5s - %s",
		    		capitalize( dir_name[door] ),
		    		(room_is_dark( pexit->u1.to_room ) ? "Too dark to tell"
							: pexit->u1.to_room->name)
		    		);
				if ( IS_IMMORTAL(ch))
		    		sprintf(buf + strlen(buf)," (room %d)\n\r",pexit->u1.to_room->vnum);
				else
		    		sprintf(buf + strlen(buf), "\n\r");
	    	}
		}
    }

    if ( !found && !fPrompt)
	    strcat( buf, fAuto ? " none&x" : "None&x.\n\r" );

    if ( fAuto )
	    strcat( buf, "&x]\n\r" );

    if ( !fPrompt )
        send_to_char( buf, ch );
    else
        strcpy(exit_string, buf);

    return;
}

void do_score( Character *ch, char *argument )
{
	Character *shift = ch;
    int nowStat[MAX_STATS], natStat[MAX_STATS];
    char colStat[MAX_STATS][3];
	char	tmp[16];
    int i;
    int total_seconds, this_session;
	char	blanks[80];
	int len;
	char sex[32], race[32], class[32], subrace[32];
    char arg[MAX_INPUT_LENGTH];

    argument = one_argument( argument, arg );

	if ( is_affected(ch,gsn_shapeshifting,AFF_SKILL) && ch->desc )
		ch = ch->desc->original;
			
	memset(blanks,' ',sizeof(blanks));

    /* Prepare color codes for display */
    for( i=0 ; i<MAX_STATS ;i++ )
    {
		nowStat[i] = get_curr_stat(shift,i);
		natStat[i] = shift->perm_stat[i];
		strcpy(colStat[i],"&x");
		if ( nowStat[i] > shift->perm_stat[i] )
	   		strcpy(colStat[i],"&G");
 		else
		if ( nowStat[i] < shift->perm_stat[i] )
	   		strcpy(colStat[i],"&R" );
    }
  
    total_seconds = ch->played + (int)(current_time - ch->logon);
    this_session = (int)(current_time - ch->logon);
 
    cprintf(ch,"\n\r&W------ &5 Character Record&x&W ---------------------------------------------------&x\n\r");

	/* Copy data to create capitalized versions */
	strcpy(sex,sex_table[ch->sex].name); 
	sex[0] = UPPER(sex[0]);
	strcpy(race,race_table[ch->race].name);
	race[0] = UPPER(race[0]);
	strcpy(class,class_table[ch->class].name);
	class[0] = UPPER(class[0]);

	if ( !IS_NPC(ch) )
	{
		strcpy(subrace,subrace_table[ch->pcdata->subrace].name);
		subrace[0] = UPPER(subrace[0]);
	}
	else
		subrace[0] = '\0';

    len = cprintf(ch,"&W|&x %s%s%s, Lv %d %s%s%s %s %s, created %s.",
		ch->name,
		IS_NPC(ch) ? "" : (ch->pcdata->surname != NULL ? " " : ""), 
                  IS_NPC(ch) ? "" : (ch->pcdata->surname != NULL ? ch->pcdata->surname : ""),
		ch->level, sex, 
			IS_NPC(ch) ? "" : (subrace_table[ch->pcdata->subrace].race_index != NULL ? " " : ""), 
			IS_NPC(ch) ? "" : (subrace_table[ch->pcdata->subrace].race_index != NULL ? subrace : ""), 
		race, class, format_date( ch->created, "%d/%b/%Y" ) );

	cprintf(ch,"%.*s&W|&x\n\r", 75-len, blanks );
    len = cprintf(ch,"&W|&x You've played for %d:%02d hours, %d:%02d in this session.",
		total_seconds / 3600, total_seconds % 3600 / 60,
		this_session / 3600, this_session % 3600 / 60 );
	cprintf(ch,"%.*s&W|&x\n\r", 75-len,blanks );
    cprintf(ch,"&W----------------------------------------------------------------------------&x\n\r");

	snprintf(tmp,sizeof(tmp),"(%+d)",shift->mod_stat[STAT_STR]);
    cprintf(ch,"&W|&x Str: %3d %s%6s&x &W|&x Base: %s%5d&x/%5d &W|&x Reflex:    %s%3d&x &W|&x AC Slash:   %3d&x   &W|&x\n\r",
		nowStat[STAT_STR], 
		colStat[STAT_STR],
		shift->mod_stat[STAT_STR] == 0 ? "" : tmp,
		ratio_color(shift->base_hit,shift->max_base_hit,FALSE),
		shift->base_hit,
		shift->max_base_hit, 
		shift->saves[SAVE_REFLEX] < 0 ? "&R" : (shift->saves[SAVE_REFLEX] > 0 ? "&G" : ""), 
		calc_save(shift,SAVE_REFLEX), 
        GET_AC(shift,AC_SLASH) );

	snprintf(tmp,sizeof(tmp),"(%+d)",shift->mod_stat[STAT_DEX]);
    cprintf(ch,"&W|&x Dex: %3d&x %s%6s&x &W|&x Stat: %s%5d&x/%5d &W|&x Fortitude: %s%3d&x &W|&x AC Pierce:  %3d&x   &W|&x\n\r",
		nowStat[STAT_DEX], 
		colStat[STAT_DEX],
		shift->mod_stat[STAT_DEX] == 0 ? "" : tmp,
		ratio_color(shift->stat_hit,max_stat_hit(shift),FALSE),
		shift->stat_hit, 
		max_stat_hit(shift), 
		shift->saves[SAVE_FORTITUDE] < 0 ? "&R" : (shift->saves[SAVE_FORTITUDE] > 0 ? "&G" : ""), calc_save(shift,SAVE_FORTITUDE),
		GET_AC(shift,AC_PIERCE) );

	snprintf(tmp,sizeof(tmp),"(%+d)",shift->mod_stat[STAT_CON]);
    cprintf(ch,"&W|&x Con: %3d&x %s%6s&x &W|&x Move: %s%5d&x/%5d &W|&x Willpower: %s%3d&x &W|&x AC Bludg.:  %3d&x   &W|&x\n\r",
		nowStat[STAT_CON], 
		colStat[STAT_CON],
		shift->mod_stat[STAT_CON] == 0 ? "" : tmp,
		ratio_color(shift->move,shift->max_move,FALSE),
		shift->move, 
		shift->max_move, 
		shift->saves[SAVE_WILLPOWER] < 0 ? "&R" : (shift->saves[SAVE_WILLPOWER] > 0 ? "&G" : ""), calc_save(shift,SAVE_WILLPOWER),
		GET_AC(shift,AC_BASH)  );

	snprintf(tmp,sizeof(tmp),"(%+d)",shift->mod_stat[STAT_INT]);
    cprintf(ch,"&W|&x Int: %3d&x %s%6s&x &W|&x Stam: %s%5d&x/%5d &W| -------------- |&x AC Other:   %3d&x   &W|&x\n\r",
		nowStat[STAT_INT], 
		colStat[STAT_INT],
		shift->mod_stat[STAT_INT] == 0 ? "" : tmp,
		ratio_color(shift->stamina,max_stamina(shift),FALSE),
		shift->stamina, 
		max_stamina(shift),  
		GET_AC(shift,AC_EXOTIC) );

	snprintf(tmp,sizeof(tmp),"(%+d)",shift->mod_stat[STAT_WIS]);
    cprintf(ch,"&W|&x Wis: %3d&x %s%6s&x &W|&x Mana: %s%5d&x/%5d &W|&x Wt:  &%c%3d.%d&x lbs &W| ----------------- |&x\n\r",
		nowStat[STAT_WIS], 
		colStat[STAT_WIS],
		shift->mod_stat[STAT_WIS] == 0 ? "" : tmp,
		ratio_color(shift->mana,max_mana(shift),TRUE),
		shift->mana, 
		max_mana(shift), 
        get_carry_weight(shift) > can_carry_w(shift) ? 'r' : 'x', get_carry_weight(shift)/10, get_carry_weight(shift)%10 );

	snprintf(tmp,sizeof(tmp),"(%+d)",shift->mod_stat[STAT_CHA]);
    cprintf(ch,"&W|&x Cha: %3d&x %s%6s&x &W|&x          %8s &W|&x Max: %5d lbs &W|&x Deity: % 9s  &W|&x\n\r",
        nowStat[STAT_CHA],
		colStat[STAT_CHA],
		shift->mod_stat[STAT_CHA] == 0 ? "" : tmp,
	    ""        , can_carry_w(shift)/10, deity_table[ch->deity].name );

    cprintf(ch,"&W----------------------------------------------------------------------------&x\n\r");

    len = cprintf(ch,"&W|&x Mithril : &r%5d&x &W|&x Attack:    %3d &W|&x Group Leader: %s",
        ch->coins[CUR_ALATINUM], 
        attack_roll(shift,GET_WEAPON_SN) * weaponProfAdj(ch,FALSE) / 100,
        (shift->pgroup == NULL || shift->pgroup->members[0] == NULL) ? "<unknown>" : 
            (shift->pgroup->members[0] == shift ? "self" : shift->pgroup->members[0]->name) );
	cprintf(ch,"%.*s&W|&x\n\r", 75-len, blanks );
    len = cprintf(ch,"&W|&x Platinum: &W%5d&x &W|&x Damroll:   %3d &W|&x Clan        : %s",
        ch->coins[CUR_PLATINUM], GET_DAMROLL(shift), ch->clan ? ch->clan->name : "none" );
	cprintf(ch,"%.*s&W|&x\n\r", 75-len, blanks );
    len = cprintf(ch,"&W|&x Electrum: &c%5d&x &W| -------------- |&x Clan Rank   : %s (%d)",
        ch->coins[CUR_ELECTRUM], ch->clan ? getRankName(ch) : "none", ch->clan ? getRank(ch) : 0 );
	cprintf(ch,"%.*s&W|&x\n\r", 75-len, blanks );
    len = cprintf(ch,"&W|&x Gold    : &y%5d&x &W|&x Train: %7d &W|&x Guild Points: %d",
        ch->coins[CUR_GOLD], ch->train, !IS_NPC(ch) ? ch->pcdata->guild_points : 0 );
	cprintf(ch,"%.*s&W|&x\n\r",75-len, blanks );
    len = cprintf(ch,"&W|&x Silver  : &s%5d&x &W|&x Skill: %7d &W|&x Last Death  : %s",
        ch->coins[CUR_SILVER], ch->practice, !IS_NPC(ch) ? ( ch->pcdata->last_pdeath <= 0 ? "never" : format_date( ch->pcdata->last_pdeath, "%d/%b/%Y" )) : "N/A"    );
	cprintf(ch,"%.*s&W|&x\n\r", 75-len, blanks );
    cprintf(ch,"&W----------------------------------------------------------------------------&x\n\r");

    /* NPC's don't have banks */
    if( !IS_NPC(ch) && HAS_SCOREOPT(ch,SCORE_OPT_SHOW_BANK))
    {
    len = cprintf(ch,"&W|&x Bank Coins      &W|&x Bank Items");
	cprintf(ch,"%.*s&W|&x\n\r", 75-len, blanks );

	for( i=0; i < 5; i++ )
	{
		char buf[MAX_STRING_LENGTH];
		int count = 0;
		Object *obj;

		sprintf(buf, "None");
		for( obj = ch->pcdata->bank; obj != NULL; obj = obj->next_content,count++ )
		{
			if(count == i)
				sprintf(buf, "%s", obj->short_descr);
		}

		switch(i)
		{
		case 0:
    		len = cprintf(ch,"&W|&x Mithril : &r%5d&x &W|&x Item 1: %s", 
				ch->pcdata->coins_bank[CUR_ALATINUM], buf );
			cprintf(ch,"%.*s&W|&x\n\r", 75-len, blanks );
			break;
	
		case 1:
    		len = cprintf(ch,"&W|&x Platinum: &W%5d&x &W|&x Item 2: %s", 
				ch->pcdata->coins_bank[CUR_PLATINUM], buf );
			cprintf(ch,"%.*s&W|&x\n\r", 75-len, blanks );
			break;

		case 2:
    		len = cprintf(ch,"&W|&x Electrum: &c%5d&x &W|&x Item 3: %s", 
				ch->pcdata->coins_bank[CUR_ELECTRUM], buf );
			cprintf(ch,"%.*s&W|&x\n\r", 75-len, blanks );
			break;

		case 3:
    		len = cprintf(ch,"&W|&x Gold    : &y%5d&x &W|&x Item 4: %s", 
				ch->pcdata->coins_bank[CUR_GOLD], buf );
			cprintf(ch,"%.*s&W|&x\n\r", 75-len, blanks );
			break;
	
		case 4:
    		len = cprintf(ch,"&W|&x Silver  : &s%5d&x &W|&x Item 5: %s", 
				ch->pcdata->coins_bank[CUR_SILVER], buf );
			cprintf(ch,"%.*s&W|&x\n\r", 75-len, blanks );
			break;
		}
	}
    cprintf(ch,"&W----------------------------------------------------------------------------&x\n\r");
    }
 
    if( IS_NPC(ch) || HAS_SCOREOPT(ch,SCORE_OPT_SHOW_RESISTS))
    {
        int i;
	    cprintf(ch,
            "&W|&x Resistances                                                              &W|&x\n\r&W|&x");

        for ( i = 0 ; i < (IS_NPC(ch) ? MAX_RESIST : MAX_PC_RESISTS) ; i++ )
        {
            if ( i % 3 == 0 && i > 0) 
                cprintf(ch,"  &W|&x\n\r&W|&x");

            if ( ch->resists[i].immune )
                cprintf(ch," %-10s &BImm&x (---)   ", capitalize(resist_flags[i].name) );
            else
                cprintf(ch," %-10s &%c%3d&x (+%2d)   ",
                    capitalize(resist_flags[i].name),
                    ch->resists[i].mod == 0 ? 'x' : ( ch->resists[i].mod < 0 ? 'R' : 'G' ),
                    ch->resists[i].value+ch->resists[i].mod,
                    ch->resists[i].mod);
        }

        /* Cap off resistances */
        if ( i % 3 == 0 )
            cprintf(ch,"  &W|&x\n\r");
        else if(i % 3 == 1)
            cprintf(ch,"                                                  &W|&x\n\r");
        else if(i % 3 == 2)
            cprintf(ch,"                          &W|&x\n\r");
        
    cprintf(ch,"&W----------------------------------------------------------------------------&x\n\r");
    }

    if( IS_NPC(ch) || HAS_SCOREOPT(ch,SCORE_OPT_SHOW_AFFECTS))
    {
        Affect *paf, *paf_last = NULL;
        char buf[MAX_STRING_LENGTH];

	    cprintf(ch,
            "&W|&x Affected By                                                              &W|&x\n\r&W|&x");

        if ( ch->affected != NULL )
        {
            int col = 0;

            for ( paf = ch->affected; paf != NULL; paf = paf->next )
            {
                SpellIndex* pSpellIndex = NULL;
                pSpellIndex = get_spell_index(paf->type);

                if (paf_last != NULL && paf->type == paf_last->type)
                    continue;
                else
                {
                    char duration[64];

                    if ( col % 2 == 0 && col > 0)
                    {
                        cprintf(ch,"  &W|&x\n\r&W|&x");
                    }
    
                    if ( IS_SET( paf->flags,AFF_PULSE ) )
                        sprintf(duration,"pulse");
                    else    
                        switch( paf->duration )
                        {
                        case DUR_PERMANENT: sprintf(duration,"perm"); break;
                        case DUR_SPECIAL:   sprintf(duration,"special"); break;
                        default:
                            if ( IS_SET(paf->flags,AFF_ABSOLUTE_TIME) )
                            {
                                if ( paf->duration < 60 )
                                    snprintf(duration,sizeof(duration),"%ds",(int)paf->duration);
                                else
                                    snprintf(duration,sizeof(duration),"%dm",(int)paf->duration / 60);
                            }
                            else
                            if ( paf->location == APPLY_BLADETURN )
                                sprintf(duration,"special");
                            else
                            if ( paf->duration - current_time < 60 )
                                sprintf(duration,"%ds", (int)UMAX(0,paf->duration - current_time));
                            else
                                sprintf(duration,"%dm", (int)(paf->duration - current_time) / 60);
                    }

                    sprintf( buf, " %-25s (%s)",
                        IS_SPELL(paf) ? pSpellIndex ? pSpellIndex->full_name : "(?)" : 
                            (IS_SKILL(paf) ? skill_table[paf->type].name : "(?)"),
                        duration );
                }

                cprintf(ch, "%-36s", buf);
                col++;
                paf_last = paf;
            }

            /* Cap off affects */
            if ( col % 2 == 0 )
                cprintf(ch,"  &W|&x\n\r");
            else if(col % 2 == 1)
                cprintf(ch,"                                      &W|&x\n\r");
        }
        else 
            cprintf(ch," No affects                                                               &W|&x\n\r");

    cprintf(ch,"&W----------------------------------------------------------------------------&x\n\r");
    }

    if( IS_NPC(ch) || HAS_SCOREOPT(ch,SCORE_OPT_SHOW_XP))
    {
    cprintf(ch,"&W|&x Experience Progress:   %6d/%6d %s &W|&x\n\r",
		ch->exp, exp_to_level[ch->level].tnl, exp_graph(ch,33) );

	if ( ch->level >= 20 && !IS_NPC(ch) )
	{
	 	cprintf(ch,"&W|&x Alternate Advancement: %6d/%6d %s &W|&x\n\r", 
			ch->pcdata->spec_exp, 
			exp_to_level[ch->pcdata->spec_level].tnl,
			alt_graph(ch,33) );
		cprintf(ch,"&W|&x Exp Split: %d%%  Alt Split: %d%%  Specialization Points: %-17d &W|&x\n\r",
			100 - ch->pcdata->split, ch->pcdata->split, ch->pcdata->spec_points );
  	}
    cprintf(ch,"&W----------------------------------------------------------------------------&x\n\r");
    }

	if ( IS_IMMORTAL(ch) && !IS_NPC(ch) )
	{
	    cprintf(ch,
            "&W|&x Administrative Settings                                                  &W|&x\n\r");
		cprintf(ch,"&W|&x   Holylight:  %-3s    OLC Security:  %-36d &W|&x\n\r",
			IS_SET( ch->display, DISP_HOLYLIGHT ) ? "on" : "off", ch->pcdata->security );
    cprintf(ch,"&W----------------------------------------------------------------------------&x\n\r");
	}

	if ( shift->intercepting )
		act(" * You are intercepting for $N",ch,NULL,shift->intercepting,TO_CHAR);

    if ( ch->class == csn_ranger )
    {
        if ( IS_NPC(ch) || ch->pcdata->class_info.ranger.species_enemy <= 0 )
            cprintf(ch," * You have not declared a species enemy\n\r");
        else
            cprintf(ch," * Species Enemy: %s\n\r",
                race_table[ch->pcdata->class_info.ranger.species_enemy].name);
    }

    return;
}


void do_affects(Character *ch, char *argument )
{
	if ( *argument != '\0' && !str_prefix(argument,"pet") )
	{
		if ( ch->pet == NULL )
		{
			cprintf(ch,"You don't have a pet.\n\r");
			return;
		}
		act(" ** Affects on $N **",ch,NULL,ch->pet,TO_CHAR);
		affects_to_char( ch->pet->affected, ch );
		return;
	}
	else
	if ( *argument != '\0' )
	{
		Character *victim;

		if ( !IS_AWAKE(ch) )
		{
			cprintf(ch,"You can't do that while asleep.\n\r");
			return;
		}

		if ( !IS_AFFECTED(ch,AFF_DETECT_MAGIC) )
		{
			cprintf(ch,"You cannot detect affects on others without a 'detect magic' affect.\n\r");
			return;
		}

		if ( (victim = get_char_room(ch,argument)) == NULL )
		{
			cprintf(ch,"Nobody is here matching that description.\n\r");
			return;
		}

		act(" ** Affects on $N **",ch,NULL,victim,TO_CHAR);
		if ( !IS_IMMORTAL(ch) )
			act("$n scans you for affects.",ch,NULL,victim,TO_VICT);
		affects_to_char( victim->affected, ch );
		return;
	}

	affects_to_char( ch->affected, ch );
	return;
}

void affects_to_char( Affect *list, Character *showTo )
{
    Affect *paf, *paf_last = NULL;
    char buf[MAX_STRING_LENGTH];
    int count = 1;

	cprintf( showTo, " == Affected By == \n\r" );
    if ( list != NULL )
    {
		for ( paf = list; paf != NULL; paf = paf->next )
		{
			SpellIndex* pSpellIndex = NULL;
			pSpellIndex = get_spell_index(paf->type);

			if (paf_last != NULL && paf->type == paf_last->type)
		    	sprintf( buf, "%12s", "" );
	    	else
			{
				char duration[64];
				char snbuf[64];
	
				if ( IS_SET( paf->flags,AFF_PULSE ) )
					sprintf(duration,"pulse spell");
				else	
				switch( paf->duration )
				{
					case DUR_PERMANENT:	sprintf(duration,"permanent affect"); break;
					case DUR_SPECIAL:   sprintf(duration,"special duration"); break;
					default:
                        if ( IS_SET(paf->flags,AFF_ABSOLUTE_TIME) )
                        {
                            if ( paf->duration < 60 )
                                snprintf(duration,sizeof(duration),"%ld second%s",
                                    paf->duration, paf->duration == 1 ? "" : "s" );
                            else
                                snprintf(duration,sizeof(duration),"%ld minute%s",
                                    paf->duration / 60, paf->duration / 60 == 1 ? "" : "s" );
                        }
                        else
						if ( paf->location == APPLY_BLADETURN )
							sprintf(duration,"special duration");
						else
						if ( paf->duration - current_time < 60 )
							sprintf(duration,"%d second%s", (int)UMAX(0,paf->duration - current_time),
								(int)UMAX(0,paf->duration - current_time) == 1 ? "" : "s" );
						else
							sprintf(duration,"%d minute%s", (int)(paf->duration - current_time) / 60,
								(int)(paf->duration - current_time) / 60 == 1 ? "" : "s" );
				}

				if ( IS_IMMORTAL(showTo) )
					sprintf( snbuf, "Vnum: %d", paf->type );

	    		sprintf( buf, "%2d. %s: %s (%s) %s\n\r%12s",
	 	    		count++, IS_SPELL(paf) ? 
						(IS_SET(paf->flags,AFF_NONSPELL) ? "Affect" : "Spell") : 
						(skill_table[paf->type].type == SKILL_FALSE ? "Affect" : "Skill"),
							IS_SPELL(paf) ? pSpellIndex ? pSpellIndex->full_name : "(null)" : 
					(IS_SKILL(paf) ? skill_table[paf->type].name : "<unknown affect>"),
		    		duration, IS_IMMORTAL(showTo) ? snbuf : "", "" );
			}

	    	send_to_char( buf, showTo );
			formatAffectDescription( showTo, paf );
	    	send_to_char( "\n\r", showTo );
	    	paf_last = paf;
		}
    }
    else 
		cprintf(showTo,"  (no spell affects)\n\r");

    return;
}

char *	const	day_name	[] =
{
    "Monday", "Tuesday", "Wednesday", "Thursday", "Friday",
    "Saturday", "Sunday"
};

char *	const	month_name	[] =
{
    "January", "February", "March", "April","May", "June", "July",
    "August", "September", "October", "November", "December"
};

int const days_per_month [] =
{
    31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 
};

void do_time( Character *ch, char *argument )
{
    char *suf;
    int day;
    struct timeval now_time;
    time_t ntime;   
    int tzindex = -1;

    if ( !IS_NPC(ch) && ch->pcdata->tzindex > 0 && ch->pcdata->tzindex < top_timezone )
    {
        tzindex = ch->pcdata->tzindex;
        setenv( "TZ",  tzTable[tzindex].zone_environment, 1 );
    }

    gettimeofday( &now_time, NULL );
    ntime = (time_t) now_time.tv_sec;

    day     = time_info.day + 1;

         if ( day > 4 && day <  20 ) suf = "th";
    else if ( day % 10 ==  1       ) suf = "st";
    else if ( day % 10 ==  2       ) suf = "nd";
    else if ( day % 10 ==  3       ) suf = "rd";
    else                             suf = "th";

    cprintf( ch, "\n\rIt is %d:%02d o'clock %s on %s, %s %d%s.\n\r",
		(time_info.hour % 12 == 0) ? 12 : time_info.hour %12,
		time_info.quarterhour * 15, time_info.hour >= 12 ? "pm" : "am",
		day_name[day % 7], month_name[time_info.month], day, suf);
    cprintf(ch,"\n\rThe last restart was at %s.\n\r",
		format_date( boot_time, "%H:%M on %A, %d/%b/%Y" ) );

    // If they have a timezone set...
    if ( tzindex >= 0 )
    {
        cprintf(ch,"Your Locale: %s\n\r", tzTable[tzindex].zone_description );
        cprintf(ch,"Earth time: %s.\n\r",
		    format_date( ntime, "%A, %d %b, %Y, %H:%M" ) );
        setenv( "TZ", "CST6CDT", 1 );
    }

    gettimeofday( &now_time, NULL );
    ntime = (time_t) now_time.tv_sec;
    cprintf(ch,"\n\rServer Locale: USA (Central)\n\r");
    cprintf(ch,"Server time: %s.\n\r",
        format_date( ntime, "%A, %d %b, %Y, %H:%M" ) );

    return;
}



void do_weather( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];

    static char * const sky_look[4] =
    {
	"cloudless",
	"cloudy",
	"rainy",
	"lit by flashes of lightning"
    };

    if ( !IS_OUTSIDE(ch) )
    {
	send_to_char( "You can't see the weather indoors.\n\r", ch );
	return;
    }

    sprintf( buf, "The sky is %s and %s.\n\r",
	sky_look[weather_info.sky],
	weather_info.change >= 0
	? "a warm southerly breeze blows"
	: "a cold northern gust blows"
	);
    send_to_char( buf, ch );
    return;
}

void log_help_fail( Character *ch, char *argument )
{
    append_file( HELPLOG_FILE, argument );
	return;
}

void show_missing( Character *ch )
{
	FILE *fp;
	Buffer *output;
	char	buffer[513];

	if ( (fp = fopen( HELPLOG_FILE, "r" )) == NULL )
	{
		cprintf(ch,"Unable to open %s: %s\n\r", HELPLOG_FILE, strerror(errno) );
		return;
	}

	output = new_buf();

    while( fgets( buffer, 512, fp ) != NULL )
		bprintf( output, "%s", buffer );

	page_to_char(buf_string(output),ch);
	free_buf( output );
	return;
}

void do_help( Character *ch, char *argument )
{
    Help *pHelp;
    Buffer *output;
    bool found = FALSE;
    char argall[MAX_INPUT_LENGTH],argone[MAX_INPUT_LENGTH];
    int level;
	bool fStore = TRUE;
    output = new_buf();

    if ( argument[0] == '\0' )
		argument = "summary";
	else
	if ( !strcmp(argument,"missing") && IS_IMMORTAL(ch) )
	{
		show_missing( ch );
		free_buf( output );
		return;
	}
	else
	if ( !strcmp(argument,"newhelps") )
	{
		cprintf(ch,"== Help Files Changed in the Last 7 Days ==\n\r");

		/* Find all helps that have changed in the last 48 hours */
	    for ( pHelp = help_first; pHelp != NULL; pHelp = pHelp->next )
			if ( (pHelp->update + 60*60*24*7) > current_time )
				cprintf(ch,"* %s\n\r",pHelp->keyword);

		return;
	}
	else
	{
		if ( spell_lookup(argument,-1) >= 1 )
		{
			cprintf(ch,
"&B*******************************************************************&x\n\r"
"&B***&x Note: If you are trying to find help files on spells, they are not\n\r"
"&B***&x generally available from in-game.  We are working on documenting them\n\r"
"&B***&x all on the web site and many are available there already.  Check out:\n\r"
"&B***&x http://www.crevetier.com/ -> GAME -> MAGIC\n\r"
"&B***&x If you were NOT searching for a spell, you can disregard this notice.\n\r"
"&B*******************************************************************&x\n\r\n\r");
			fStore = FALSE;
		}
		else
		if ( style_lookup(argument,-1) >= 0 )
		{
            cprintf(ch,
"&g*******************************************************************&x\n\r"
"&g***&x Note: If you are trying to find help files on styles, they are not\n\r"
"&g***&x generally available from in-game.  We are working on documenting them\n\r"
"&g***&x all on the web site and many are available there already.  Check out:\n\r"
"&g***&x http://www.crevetier.com/ -> GAME -> COMBAT\n\r"
"&g***&x If you were NOT searching for a style, you can disregard this notice.\n\r"
"&g*******************************************************************&x\n\r");
			fStore = FALSE;
		}
	}

    /* this parts handles help a b so that it returns help 'a b' */
    argall[0] = '\0';
    while (argument[0] != '\0' )
    {
		argument = one_argument(argument,argone);
		if (argall[0] != '\0')
	    	strcat(argall," ");
		strcat(argall,argone);
    }

    for ( pHelp = help_first; pHelp != NULL; pHelp = pHelp->next )
    {
    	level = (pHelp->level < 0) ? -1 * pHelp->level - 1 : pHelp->level;

		if (level > get_trust( ch ) )
	    	continue;

		if ( is_name( argall, pHelp->keyword ) )
		{
	    	/* add seperator if found */
	    	if (found)
				add_buf(output, "\n\r============================================================\n\r\n\r");
	    	if ( pHelp->level >= 0 && str_cmp( argall, "imotd" ) )
	    	{
				add_buf(output,pHelp->keyword);
                bprintf(output, " (Last modified on %s)",format_date( pHelp->update, "%b %d, %Y" )); 
				add_buf(output,"\n\r");
	    	}

	    	/*
	     	* Strip leading '.' to allow initial blanks.
	     	*/
	    	if ( pHelp->text[0] == '.' )
				add_buf(output,pHelp->text+1);
	    	else
				add_buf(output,pHelp->text);

			if ( IS_IMMORTAL(ch) )
				bprintf(output,"[Source file: %s]\n\r", pHelp->file );

	    	found = TRUE;
	    	/* small hack :) */
	    	if (ch->desc != NULL && ch->desc->connected != CON_PLAYING 
	    		&&  		    ch->desc->connected != CON_GEN_GROUPS)
			break;
		}
    }

    if (!found)
	{
    	cprintf(ch, "No help on the word: %s\n\r", argall );
		if ( fStore )
			log_help_fail( ch, argall );
	}
    else
		page_to_char(buf_string(output),ch);

    free_buf(output);
}

void who_entry( Character *wch, Character *ch, Buffer *output, bool bUseGui )
{
	char *clan_out;
	const char *class;
	char class_string[128];
	char gui_class_string[128];
	const char *race_string;
	char incog[50], wizi[50];
	char buf[MAX_STRING_LENGTH];

    /* work out the printing */
    class = class_table[wch->class].who_name;

    if ( IS_SET(ch->display,DISP_SHOW_SUBRACES) )
        race_string = wch->pcdata->subrace <= 0 ? "" : subrace_table[wch->pcdata->subrace].who_name;
    else
        race_string = pc_race_table[wch->race].who_name;

    sprintf(class_string,"%2d %s %s",wch->level, race_string, class );

    if ( IS_IMMORTAL(wch) )
    {
    	switch ( wch->pcdata->imm_role )
   		{
        	default: break;
            {
            	case IMM_ROLE_CODER:     sprintf(class_string,"    Coder    "); break;
            	case IMM_ROLE_ADMIN:     sprintf(class_string,"    Admin    "); break;
            	case IMM_ROLE_BUILDER:   sprintf(class_string,"   Builder   "); break;
            	case IMM_ROLE_AMBIENCE:  sprintf(class_string,"  Ambience   "); break;
            	case IMM_ROLE_DEVELOPER: sprintf(class_string,"  Developer  "); break;
            }
        }
	}

    if ( wch->incog_level )
    	sprintf(incog,"(&WIncog&x@&g%d&x) ",wch->incog_level);

    if ( wch->invis_level )
    	sprintf(wizi,"(&WWizi&x@&g%d&x) ",wch->invis_level);

    if (HAS_DISPOPT(ch, DISP_WHO_NOGUILDS))
        clan_out = "";
    else
	    clan_out = get_clan_name( wch, ch );

    /*
     * Format it up.
     */
	if(IS_SET(ch->gui,GUI_FRIENDS) && bUseGui)
	{
		struct stat charstat;
		char fingerinfo[MAX_STRING_LENGTH];
		snprintf(fingerinfo,sizeof(fingerinfo),"%s%s",getDirectory(PLAYER_DIR),capitalize(wch->name));

        /* Format regular character info how we want it */
        if(!IS_IMMORTAL(wch))
        {
            sprintf(gui_class_string, "%s lvl %d race %s subrace %s",
                capitalize(class_table[wch->class].name),
                wch->level,
                pc_race_table[wch->race].who_name,
                wch->pcdata->subrace <= 0 ? "None" : subrace_table[wch->pcdata->subrace].name );
        }

		sprintf( buf, "<FriendsWhois>%s %s clan %sname %s incog %d wizi %d builder %c teamlead %c away %c title%s lastlogin %s \n\r",
			IS_IMMORTAL(wch) ? "imm" : "class",
			IS_IMMORTAL(wch) ? class_string : gui_class_string,
			clan_out,
            wch->name,
			wch->incog_level ? wch->incog_level : 0,
			wch->invis_level ? wch->invis_level : 0,
			(IS_IMMORTAL(ch) && IS_SET(wch->act, PLR_BUILDER)) ? 'y' : 'n',
			IS_SET(wch->act, PLR_TEAM_LEAD) ? 'y' : 'n',
            IS_SET(wch->comm, COMM_AFK) ? 'y' : 'n',
            IS_NPC(wch) ? "" : (!IS_SET(ch->display,DISP_WHO_NOTITLES) ? wch->pcdata->title : ""),
			stat( fingerinfo, &charstat) < 0 ? "Unknown" : format_date( charstat.st_mtime, "%H:%M on %A, %d/%b/%Y") );

			add_buf(output,buf);
	}
	else
	{
		char *title = decolorize( wch->pcdata->title );

    	sprintf( buf, "%s[%s]%s%s%s%s%s%s%s%s\n\r",
			(IS_IMMORTAL(ch) && IS_SET(wch->act, PLR_BUILDER)) ? "&BB&x" : (IS_IMMORTAL(ch) ? " " : ""),
        	class_string,
			IS_SET(wch->act, PLR_TEAM_LEAD) ? "&R*&x" : " ",
        	wch->incog_level >= LEVEL_HERO ? incog : "",
        	wch->invis_level >= LEVEL_HERO ? wizi : "",
			clan_out,
        	IS_SET(wch->comm, COMM_AFK) ? "[&cAway&x] " : "",
        	wch->name, IS_NPC(wch) ? "" :  
	    		(!IS_SET(ch->display,DISP_WHO_NOSURNAMES) ? 
				(wch->pcdata->surname != NULL ? wch->pcdata->surname : "") : "" ),
        	IS_NPC(wch) ? "" : (!IS_SET(ch->display,DISP_WHO_NOTITLES) ? title : "") );
	}

	add_buf(output,buf);
}

/* whois command */
void do_whois (Character *ch, char *argument)
{
    char arg[MAX_INPUT_LENGTH];
    Buffer *output;
    Descriptor *d;
    bool found = FALSE;
	int i;

    one_argument(argument,arg);
  
    if (arg[0] == '\0')
    {
		send_to_char("You must provide a name.\n\r",ch);
		return;
    }

    output = new_buf();

	for( i = 60 ; i > 0 ; i-- )
	{
        switch( i )
        {
        	case 60:
             	add_buf(output,"\n\r&5ADMINISTRATION&x\n\r");
             	add_buf(output,    "--------------\n\r");  break;
        	case 51:
             	add_buf(output,"\n\r&5PLAYERS&x\n\r");
             	add_buf(output,      "-------\n\r");  break;
        }

    	for (d = descriptor_list; d != NULL; d = d->next)
    	{
			Character *wch;
	
	 		if (d->connected != CON_PLAYING || !can_see(ch,d->character))
		    	continue;
		
			wch = ( d->original != NULL ) ? d->original : d->character;

			if ( wch->level != i )
				continue;
	
 			if (!can_see(ch,wch) && IS_IMMORTAL(wch) )
		    	continue;
	
			if (!str_prefix(arg,wch->name))
			{
		    	found = TRUE;
		
				who_entry( wch, ch, output, TRUE );	    
   			}
		}
	}

   	if (!found)
    {
		send_to_char("No one of that name is playing.\n\r",ch);
		return;
    }

    page_to_char(buf_string(output),ch);
    free_buf(output);
}


/*
 * New 'who' command originally by Alander of Rivers of Mud.
 */
void do_who( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    char buf2[MAX_STRING_LENGTH];
    Buffer *output;
    Descriptor *d;
    int iClass;
    int iRace;
    int iLevelLower;
    int iLevelUpper;
    int nNumber;
    int nMatch;
    bool rgfClass[MAX_CLASS];
    bool rgfRace[MAX_PC_RACE];
    bool fClassRestrict = FALSE;
/*
    bool fClanRestrict = FALSE;
    bool fClan = FALSE;
*/
    bool fRaceRestrict = FALSE;
    bool fImmortalOnly = FALSE;
    int  level_loop;
    char	incog[80], wizi[80];

    wizi[0] = incog[0] = '\0';
    /*
     * Set default arguments.
     */
    iLevelLower    = 0;
    iLevelUpper    = MAX_LEVEL;
    for ( iClass = 0; iClass < MAX_CLASS; iClass++ )
        rgfClass[iClass] = FALSE;
    for ( iRace = 0; iRace < MAX_PC_RACE; iRace++ )
        rgfRace[iRace] = FALSE;
 
    /*
     * Parse arguments.
     */
    nNumber = 0;
    for ( ;; )
    {
        char arg[MAX_STRING_LENGTH];
 
        argument = one_argument( argument, arg );
        if ( arg[0] == '\0' )
            break;

        if ( is_number( arg ) )
        {
            switch ( ++nNumber )
            {
            case 1: iLevelLower = atoi( arg ); break;
            case 2: iLevelUpper = atoi( arg ); break;
            default:
                send_to_char( "Only two level numbers allowed.\n\r", ch );
                return;
            }
        }
        else
        {
 
            /*
             * Look for classes to turn on.
             */
            if (!str_prefix(arg,"immortals"))
            {
                fImmortalOnly = TRUE;
            }
            else
            {
                iClass = class_lookup(arg);
                if (iClass == -1)
                {
                    iRace = race_lookup(arg);
 
                    if (iRace == 0 || iRace >= MAX_PC_RACE)
		    		{
						/********
						if (!str_prefix(arg,"clan"))
			    			fClan = TRUE;
						else
		    			{
			    			iClan = clan_lookup(arg);
			    			if (iClan)
			    			{
								fClanRestrict = TRUE;
			   					rgfClan[iClan] = TRUE;
			    			}
			    			else
			    			{
                   			send_to_char( "That's not a valid race, class, or clan.\n\r", ch);
                   			return;
			    			}
            			}
						*******/
		    		}
            else
            {
            	fRaceRestrict = TRUE;
            	rgfRace[iRace] = TRUE;
            }
                }
                else
                {
                    fClassRestrict = TRUE;
                    rgfClass[iClass] = TRUE;
                }
            }
        }
    }
 
    /*
     * Now show matching chars.
     */
    nMatch = 0;
    buf[0] = '\0';
    output = new_buf();

	for ( level_loop = 60 ; level_loop > 0 ; level_loop-- )
	{
        switch( level_loop )
        {
        case 60:
             add_buf(output,"\n\r&5ADMINISTRATION&x\n\r");
             add_buf(output,    "--------------\n\r");  break;
        case 51:
             add_buf(output,"\n\r&5PLAYERS&x\n\r");
             add_buf(output,      "-------\n\r");  break;
        }

    	for ( d = descriptor_list; d != NULL; d = d->next )
    	{
        	Character *wch;

			/*
			 * Check for match against restrictions.
			 * Don't use trust as that exposes trusted mortals.
		 	 */
   	     
			if ( d->connected != CON_PLAYING )
				continue;

			wch = ( d->original != NULL ) ? d->original : d->character;
			if ( wch == NULL || wch->level != level_loop )
				continue;

			if ( /*!can_see( ch, wch ) && */IS_IMMORTAL(wch) && 
				((wch->invis_level > ch->level) || (wch->incog_level > ch->level && ch->in_room != d->character->in_room)))
            	continue;
 
        	if ( wch->level < iLevelLower
        	||   wch->level > iLevelUpper
        	|| ( fImmortalOnly  && wch->level < LEVEL_IMMORTAL )
        	|| ( fClassRestrict && !rgfClass[wch->class] )
        	|| ( fRaceRestrict && !rgfRace[wch->race])
 			/*|| ( fClan && !is_clan(wch))
			|| ( fClanRestrict && !rgfClan[wch->clan])*/
        	|| ( wch->level != level_loop ) )
            	continue;

        	nMatch++;
	
			who_entry( wch, ch, output, FALSE ); 
    	}
 	}
    sprintf( buf2, "\n\rPlayers found: %d\n\r", nMatch );
    add_buf(output,buf2);
    page_to_char( buf_string(output), ch );
    free_buf(output);
    return;
}

int count_characters( void )
{
	int count=0;
	Descriptor *d;

    for ( d = descriptor_list; d != NULL; d = d->next )
        if ( d->connected == CON_PLAYING )
	        count++;

	return count;
}

void do_count ( Character *ch, char *argument )
{
    int count, realcount;
    Descriptor *d;
    char buf[MAX_STRING_LENGTH];

    count = realcount = 0;

    for ( d = descriptor_list; d != NULL; d = d->next )
        if ( d->connected == CON_PLAYING )
		{
			realcount++;
			if ( d->character && /*can_see(ch,d->character)*/!(IS_IMMORTAL(d->character) && 
				((d->character->invis_level > ch->level) || (d->character->incog_level > ch->level && ch->in_room != d->character->in_room))))
	    		count++;
		}
			

    max_on = UMAX(realcount,max_on);

    if (max_on == count)
        sprintf(buf,"There are %d characters on, the most so far today.\n\r",
	    count);
    else
	sprintf(buf,"There are %d characters on, the most on today was %d.\n\r",
	    count,max_on);

    send_to_char(buf,ch);
	cprintf(ch,"All-time record: %d players at %s.\n\r",
        GameInfo.mostPlayersEver,
        format_date( GameInfo.mostPlayersWhen, "%H:%M on %A, %d/%b/%Y" ) );

	if ( max_on > GameInfo.mostPlayersEver )
	{
		GameInfo.mostPlayersEver = max_on;
		GameInfo.mostPlayersWhen = current_time;
		save_game_info( );
		cprintf(ch,"&R ** It's a new record! **&x\n\r");
	}

}

void do_inventory( Character *ch, char *argument )
{
	Character *keeper;
	Shop *pShop = NULL;
	bool found_keeper = FALSE;

    send_to_char( "You are carrying:\n\r", ch );

	for ( keeper = ch->in_room->people; keeper; keeper = keeper->next_in_room )
	{
		if ( IS_NPC(keeper) && (pShop = keeper->pIndexData->pShop) != NULL )
		{
			found_keeper = TRUE;
			break;
		}
	}

	if ( !found_keeper )
    	show_list_to_char( ch->carrying, ch, TRUE, TRUE );
	else
    	show_list_with_values_to_char( ch->carrying, ch, keeper, TRUE, TRUE );
    return;
}



void do_equipment( Character *ch, char *argument )
{
	equipment_to_char( ch, ch );
}

void equipment_to_char( Character *ch, Character *victim )
{
    Object *obj;
    int iWear;
    bool found;
	const int *array;

	if ( ch == victim )
    	send_to_char( "You are using:\n\r", ch );
	else
		act("$N is using:", ch, NULL, victim, TO_CHAR );

    found = FALSE;

	if ( IS_NPC(ch) )
		array = where_order;
	else
		array = ch->pcdata->eq_list_order;

    for ( iWear = 0; iWear < MAX_WEAR; iWear++ )
    {
		if ( array[iWear] < 0 )
			continue;

		if ( ( obj = get_eq_char( victim, (array[iWear]-1) ) ) == NULL && !IS_SET(ch->display,DISP_FULL_EQUIPMENT) )
	    	continue;

		if ( obj == NULL )
		{
			if ( !IS_NPC(victim) )
			{
				send_to_char( where_name[(array[iWear]-1)], ch );
	    		cprintf(ch," - - nothing - -\n\r");
			}
		}
		else
		if ( can_see_obj( ch, obj ) )
		{
			send_to_char( where_name[(array[iWear]-1)], ch );
	    	send_to_char( format_obj_to_char( obj, ch, TRUE ), ch );
	    	send_to_char( "\n\r", ch );
		}
		else
		{
	    	send_to_char( "something.\n\r", ch );
		}
		found = TRUE;
    }

    if ( !found )
		send_to_char( "Nothing.\n\r", ch );

    return;
}



void do_compare( Character *ch, char *argument )
{
    char arg1[MAX_INPUT_LENGTH];
    char arg2[MAX_INPUT_LENGTH];
    Object *obj1;
    Object *obj2;
    int value1;
    int value2;
    char *msg;

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );
    if ( arg1[0] == '\0' )
    {
	send_to_char( "Compare what to what?\n\r", ch );
	return;
    }

    if ( ( obj1 = get_obj_carry( ch, arg1, ch ) ) == NULL )
    {
	send_to_char( "You do not have that item.\n\r", ch );
	return;
    }

    if (arg2[0] == '\0')
    {
	for (obj2 = ch->carrying; obj2 != NULL; obj2 = obj2->next_content)
	{
	    if (obj2->wear_loc != WEAR_NONE
	    &&  can_see_obj(ch,obj2)
	    &&  obj1->item_type == obj2->item_type
	    &&  (obj1->wear_flags & obj2->wear_flags & ~ITEM_TAKE) != 0 )
		break;
	}

	if (obj2 == NULL)
	{
	    send_to_char("You aren't wearing anything comparable.\n\r",ch);
	    return;
	}
    } 

    else if ( (obj2 = get_obj_carry(ch,arg2,ch) ) == NULL )
    {
	send_to_char("You do not have that item.\n\r",ch);
	return;
    }

    msg		= NULL;
    value1	= 0;
    value2	= 0;

    if ( obj1 == obj2 )
    {
	msg = "You compare $p to itself.  It looks about the same.";
    }
    else if ( obj1->item_type != obj2->item_type )
    {
	msg = "You can't compare $p and $P.";
    }
    else
    {
	switch ( obj1->item_type )
	{
	default:
	    msg = "You can't compare $p and $P.";
	    break;

	case ITEM_ARMOR:
	    value1 = obj1->value[0] + obj1->value[1] + obj1->value[2];
	    value2 = obj2->value[0] + obj2->value[1] + obj2->value[2];
	    break;

	case ITEM_WEAPON:
	    if (obj1->pIndexData->new_format)
		value1 = (1 + obj1->value[2]) * obj1->value[1];
	    else
	    	value1 = obj1->value[1] + obj1->value[2];

	    if (obj2->pIndexData->new_format)
		value2 = (1 + obj2->value[2]) * obj2->value[1];
	    else
	    	value2 = obj2->value[1] + obj2->value[2];
	    break;
	}
    }

    if ( msg == NULL )
    {
	     if ( value1 == value2 ) msg = "$p and $P look about the same.";
	else if ( value1  > value2 ) msg = "$p looks better than $P.";
	else                         msg = "$p looks worse than $P.";
    }

    act( msg, ch, obj1, obj2, TO_CHAR );
    return;
}



void do_credits( Character *ch, char *argument )
{
    do_function(ch, &do_help, "diku" ); return;
}



void do_where( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    char arg[MAX_INPUT_LENGTH];
    Character *victim;
    Descriptor *d;
    bool found;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Players near you:\n\r", ch );
	found = FALSE;
	for ( d = descriptor_list; d; d = d->next )
	{
	    if ( d->connected == CON_PLAYING
	    && ( victim = d->character ) != NULL
	    &&   !IS_NPC(victim)
	    &&   victim->in_room != NULL
	    &&   !IS_SET(victim->in_room->room_flags,ROOM_NOWHERE)
 	    &&   (is_room_owner(ch,victim->in_room) 
	    ||    !room_is_private(victim->in_room))
	    &&   victim->in_room->area == ch->in_room->area
	    &&   can_see( ch, victim ) )
	    {
		found = TRUE;
		sprintf( buf, "%-28s %s\n\r",
		    victim->name, victim->in_room->name );
		send_to_char( buf, ch );
	    }
	}
	if ( !found )
	    send_to_char( "None\n\r", ch );
    }
    else
    {
	found = FALSE;
	for ( victim = char_list; victim != NULL; victim = victim->next )
	{
	    if ( victim->in_room != NULL
	    &&   victim->in_room->area == ch->in_room->area
	    &&   !IS_AFFECTED(victim, AFF_SNEAK)
	    &&   can_see( ch, victim )
	    &&   is_name( arg, victim->name ) )
	    {
		found = TRUE;
		sprintf( buf, "%-28s %s\n\r",
		    PERS(victim, ch), victim->in_room->name );
		send_to_char( buf, ch );
		break;
	    }
	}
	if ( !found )
	    act( "You didn't find any $T.", ch, NULL, arg, TO_CHAR );
    }

    return;
}




void do_consider( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Character *victim;
    char msg[MAX_STRING_LENGTH];

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Consider killing whom?\n\r", ch );
	return;
    }

    if ( ( victim = get_char_room( ch, arg ) ) == NULL )
    {
	send_to_char( "They're not here.\n\r", ch );
	return;
    }

    if (is_safe(ch,victim))
    {
		act("You can't attack $N anyway.",ch,NULL,victim,TO_CHAR);
		return;
    }

	snprintf(msg,sizeof(msg),"You size up $N - that would be %s",con_msg(ch,victim) );
    act( msg, ch, NULL, victim, TO_CHAR );
	act("$n sizes you up.",ch,NULL,victim,TO_VICT);
    return;
}



void set_title( Character *ch, char *title )
{
    char buf[MAX_STRING_LENGTH];

    if ( IS_NPC(ch) )
    {
	log_bug( "Set_title: NPC.", 0 );
	return;
    }

    if ( title[0] != '.' && title[0] != ',' && title[0] != '!' && title[0] != '?' )
    {
	buf[0] = ' ';
	strcpy( buf+1, title );
    }
    else
    {
	strcpy( buf, title );
    }

    free_string( ch->pcdata->title );
    ch->pcdata->title = str_dup( buf );
    return;
}


/* Color not allowed in titles! */
void do_title( Character *ch, char *argument )
{
	char buf[MAX_STRING_LENGTH];

    if ( IS_NPC(ch) )
	return;

    if ( argument[0] == '\0' )
    {
		cprintf(ch, "Syntax: title <new title>\n\r");
		cprintf(ch, "        title show\n\r");
		cprintf(ch, "        title clear\n\r"); 
		/*send_to_char( "Change your title to what?\n\r", ch );*/
		return;
    }

	if(!strcmp(argument,"show"))
	{
		if(!strcmp(ch->pcdata->title,""))
			cprintf(ch, "You currently do not have a title set.\n\r");
		else
			cprintf(ch, "Your title is:%s\n\r", ch->pcdata->title ? ch->pcdata->title : "(None)");
		return;
	}

	if(!strcmp(argument,"clear"))
	{
		strcpy(buf, "");
		free_string( ch->pcdata->title );
		ch->pcdata->title = str_dup( buf );
		cprintf(ch, "Title cleared.\n\r");
		return;
	}

    if ( strlen(argument) > 45 )
	argument[45] = '\0';

    smash_tilde( argument );
 
    if ( ch->level < 55 )
        stripColorInline( argument );

    set_title( ch, argument );
    send_to_char( "Ok.\n\r", ch );
}



void do_description( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];

	if ( !strcmp(argument,"clear") )
	{
        buf[0] = '\0';
	    free_string(ch->description);
	    ch->description = str_dup(buf);
	    send_to_char("Description cleared.\n\r",ch);
	    return;
	}

    if ( argument[0] != '\0' )
    {
	buf[0] = '\0';
	smash_tilde( argument );

    	if (argument[0] == '-')
    	{
            int len;
            bool found = FALSE;
 
            if (ch->description == NULL || ch->description[0] == '\0')
            {
                send_to_char("No lines left to remove.\n\r",ch);
                return;
            }
	
  	    strcpy(buf,ch->description);
 
            for (len = strlen(buf); len > 0; len--)
            {
                if (buf[len] == '\r')
                {
                    if (!found)  /* back it up */
                    {
                        if (len > 0)
                            len--;
                        found = TRUE;
                    }
                    else /* found the second one */
                    {
                        buf[len + 1] = '\0';
			free_string(ch->description);
			ch->description = str_dup(buf);
			send_to_char( "Your description is:\n\r", ch );
			send_to_char( ch->description ? ch->description : 
			    "(None).\n\r", ch );
                        return;
                    }
                }
            }
            buf[0] = '\0';
	    free_string(ch->description);
	    ch->description = str_dup(buf);
	    send_to_char("Description cleared.\n\r",ch);
	    return;
        }
	if ( argument[0] == '+' )
	{
	    if ( ch->description != NULL )
		strcat( buf, ch->description );
	    argument++;
	    while ( isspace(*argument) )
		argument++;
	}

        if ( strlen(buf) >= 1024)
	{
	    send_to_char( "Description too long.\n\r", ch );
	    return;
	}

	strcat( buf, argument );
	strcat( buf, "\n\r" );
	free_string( ch->description );
	ch->description = str_dup( buf );
    }

    send_to_char( "Your description is:\n\r", ch );
    send_to_char( ch->description ? ch->description : "(None).\n\r", ch );
    return;
}



void do_report( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
  
    cprintf( ch, "You say 'I have %s%3d&x%% base, %s%3d&x%% stat, %s%3d&x%% mana, %s%3d&x%% stamina, %s%3d&x%% moves.'\n\r",
      ratio_color(ch->base_hit,ch->max_base_hit,FALSE), ch->max_base_hit == 0 ? 100 : (ch->base_hit*100/ch->max_base_hit),
      ratio_color(ch->stat_hit,max_stat_hit(ch),FALSE), max_stat_hit(ch) == 0 ? 100 : (ch->stat_hit*100/max_stat_hit(ch)),
      ratio_color(ch->mana,max_mana(ch),TRUE), max_mana(ch) == 0 ? 100 : (ch->mana*100/max_mana(ch)),
      ratio_color(ch->stamina,max_stamina(ch),FALSE), max_stamina(ch) == 0 ? 100 : (ch->stamina*100/max_stamina(ch)),
      ratio_color(ch->move,ch->max_move,FALSE), ch->max_move == 0 ? 100 : (ch->move*100/ch->max_move) );

    snprintf( buf, sizeof(buf),
          "$n says 'I have %s%3d&x%% base, %s%3d&x%% stat, %s%3d&x%% mana, %s%3d&x%% stamina, %s%3d&x%% moves.'\n\r",
      ratio_color(ch->base_hit,ch->max_base_hit,FALSE), ch->max_base_hit == 0 ? 100 : (ch->base_hit*100/ch->max_base_hit),
      ratio_color(ch->stat_hit,max_stat_hit(ch),FALSE), max_stat_hit(ch) == 0 ? 100 : (ch->stat_hit*100/max_stat_hit(ch)),
      ratio_color(ch->mana,max_mana(ch),TRUE), max_mana(ch) == 0 ? 100 : (ch->mana*100/max_mana(ch)),
      ratio_color(ch->stamina,max_stamina(ch),FALSE), max_stamina(ch) == 0 ? 100 : (ch->stamina*100/max_stamina(ch)),
      ratio_color(ch->move,ch->max_move,FALSE), ch->max_move == 0 ? 100 : (ch->move*100/ch->max_move) );


    act( buf, ch, NULL, NULL, TO_ROOM );

    return;
}

void do_practice( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    int sn = 0;

    if ( IS_NPC(ch) )
	return;

    if ( argument[0] == '\0' )
    {
		int col;

		col = 0;
		cprintf(ch,"&B[&xTrade Skills&B]&x\n\r");
		cprintf(ch,"  * Foundation Skills\n\r");
		for ( sn = 0; sn < MAX_SKILL; sn++ )
		{
			if ( skill_table[sn].name == NULL )
				break;
			else
			if ( (skill_table[sn].type != SKILL_FOUNDATION) ||
		     	ch->level < skill_table[sn].skill_level[ch->class] ||
				skill_table[sn].skill_level[ch->class] == 0 ||
		     	ch->pcdata->learned[sn] < 1 )
				continue;
	
			cprintf(ch,"%-22s %4d  ", skill_table[sn].name, ch->pcdata->learned[sn] );
			if ( ++col % 2 == 0 )
				cprintf(ch,"\n\r");
		}

		cprintf(ch,"  * Specializations\n\r");
		for ( sn = 0; sn < MAX_SKILL; sn++ )
		{
			if ( skill_table[sn].name == NULL )
				break;
			else
			if ( (skill_table[sn].type != SKILL_TRADE) ||
		     	ch->level < skill_table[sn].skill_level[ch->class] ||
				skill_table[sn].skill_level[ch->class] == 0 ||
		     	ch->pcdata->learned[sn] < 1 )
				continue;
	
			cprintf(ch,"%-22s %4d  ", skill_table[sn].name, ch->pcdata->learned[sn] );
			if ( ++col % 2 == 0 )
				cprintf(ch,"\n\r");
		}

		cprintf(ch,"\n\rTrade Points: %d/%d\n\r", calcTotalTradePoints(ch), CRAFTING_CAP );
		cprintf(ch,"\n\r&B[&xGeneral Skills&B]&x\n\r");

		col    = 0;
		for ( sn = 0; sn < MAX_SKILL; sn++ )
		{
	    	if ( skill_table[sn].name == NULL )
				break;

			if ( skill_table[sn].type == SKILL_TRADE ||
				 skill_table[sn].type == SKILL_FOUNDATION ||
				 skill_table[sn].type == SKILL_FALSE )
				continue;

	    	if ( ch->level < skill_table[sn].skill_level[ch->class] 
	      		|| ch->pcdata->learned[sn] < 1 /* skill is not known */
				|| skill_table[sn].skill_level[ch->class] == 0 )
				continue;
	
	    	sprintf( buf, "%-22s %3d  ",
			skill_table[sn].name, ch->pcdata->learned[sn] );
	    	send_to_char( buf, ch );
	    	if ( ++col % 2 == 0 )
			send_to_char( "\n\r", ch );
		}

	    send_to_char( "\n\r", ch );

		sprintf( buf, "You have %d skill points available.\n\r", ch->practice );
		send_to_char( buf, ch );
    }
    else
    {
	Character *mob;

	if ( !IS_AWAKE(ch) )
	{
	    send_to_char( "In your dreams, or what?\n\r", ch );
	    return;
	}

	for ( mob = ch->in_room->people; mob != NULL; mob = mob->next_in_room )
	{
	    if ( IS_NPC(mob) && IS_SET(mob->act, ACT_TRAIN) )
		break;
	}

	if ( mob == NULL )
	{
	    send_to_char( "You must locate a trainer.\n\r", ch );
	    return;
	}

	if ( (sn = skill_lookup(argument)) < 0 )
	{
		cprintf(ch,"You don't have that skill.\n\r");
		return;
	}
	else
	if ( IS_NPC(ch) )
	{
	    cprintf(ch,"NPCs cannot use the 'practice' command.\n\r");
	    return;
	}
	else
	if ( skill_table[sn].type == SKILL_TRADE || skill_table[sn].type == SKILL_FOUNDATION )
	{
		cprintf(ch,"Trade skills cannot be practiced.\n\r");
		return;
	}
	else
	if ( ch->level < skill_table[sn].skill_level[ch->class] )
 	{
	    if( skill_table[sn].skill_level[ch->class] < 1 ||
	        skill_table[sn].skill_level[ch->class] > 51 )
	        cprintf(ch,"Your class cannot use that skill.\n\r");
	    else
	        cprintf(ch,"You don't get that skill until level %d.\n\r",
			skill_table[sn].skill_level[ch->class] );
	    return;
	}
	else
	if ( ch->pcdata->learned[sn] < 1 )
	{
	    cprintf(ch,"You don't know that skill.\n\r");
	    return;
	}
	else
	if ( skill_table[sn].skill_level[ch->class] == 0 )
	{
	    cprintf(ch,"Your class %s doesn't get that skill '%s'.\n\r",
		class_table[ch->class].name, skill_table[sn].name );
	    return;
	}
	else
	if ( ch->pcdata->learned[sn] >= ch->level )
	{
	    cprintf(ch,"You may only practice this skill up to your level (%d).\n\r", ch->level );
	    return;
	}

	/* Check cost */
	{
	int cost;

	cost = ch->pcdata->learned[sn] + 1;

	/* Race-specific stuff */
	if ( ch->pcdata->subrace == gsn_kevjordhur && skill_table[sn].type == SKILL_WEAPON )
		cost--;
	else
	if ( ch->pcdata->subrace == gsn_abrainon && sn == gsn_axe )
		cost -= 2;
	else
	if ( ch->pcdata->subrace == gsn_elashod && 
			   (sn == gsn_longbow || sn == gsn_shortbow || sn == gsn_composite_longbow) )
		cost -= 2;
	else
	if ( ch->pcdata->subrace == gsn_halfelf && 
			   (sn == gsn_longbow || sn == gsn_shortbow || sn == gsn_composite_longbow) )
		cost -= 1;
	else
	if ( ch->pcdata->subrace == gsn_halfling &&
			( sn == gsn_open_lock || sn == gsn_stealth || sn == gsn_pick_pocket ) )
		cost -= 1;

	if ( cost > ch->practice )
	{
	    cprintf(ch,"It takes %d skill points to train this skill, you're short by %d.\n\r", cost, cost-ch->practice);
	    return;
	}

	ch->practice-=cost;
	ch->pcdata->learned[sn]++; 
	}
	act( "You practice $T.", ch, NULL, skill_table[sn].name, TO_CHAR );
	act( "$n practices $T.", ch, NULL, skill_table[sn].name, TO_ROOM );
    }
    return;
}



/*
 * 'Wimpy' originally by Dionysos.
 */
void do_wimpy( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    int wimpy;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
		wimpy = max_stat_hit(ch) / 5;
    else
		wimpy = atoi( arg );

    if ( wimpy < 0 )
    {
		send_to_char( "Your courage exceeds your wisdom.\n\r", ch );
		return;
    }

    if ( wimpy > max_stat_hit(ch) / 2 )
    {
		send_to_char( "Such cowardice ill becomes you.\n\r", ch );
		return;
    }

    ch->wimpy	= wimpy;
    cprintf( ch , "Wimpy set to %d hit points.\n\r", wimpy );
    return;
}



void do_password( Character *ch, char *argument )
{
    char arg1[MAX_INPUT_LENGTH];
    char arg2[MAX_INPUT_LENGTH];
    char *pArg;
    char *pwdnew;
    char *p;
    char cEnd;

    if ( IS_NPC(ch) )
	return;

    /*
     * Can't use one_argument here because it smashes case.
     * So we just steal all its code.  Bleagh.
     */
    pArg = arg1;
    while ( isspace(*argument) )
	argument++;

    cEnd = ' ';
    if ( *argument == '\'' || *argument == '"' )
	cEnd = *argument++;

    while ( *argument != '\0' )
    {
	if ( *argument == cEnd )
	{
	    argument++;
	    break;
	}
	*pArg++ = *argument++;
    }
    *pArg = '\0';

    pArg = arg2;
    while ( isspace(*argument) )
	argument++;

    cEnd = ' ';
    if ( *argument == '\'' || *argument == '"' )
	cEnd = *argument++;

    while ( *argument != '\0' )
    {
	if ( *argument == cEnd )
	{
	    argument++;
	    break;
	}
	*pArg++ = *argument++;
    }
    *pArg = '\0';

    if ( arg1[0] == '\0' || arg2[0] == '\0' )
    {
	send_to_char( "Syntax: password <old> <new>.\n\r", ch );
	return;
    }

    if ( strcmp( crypt( arg1, ch->pcdata->pwd ), ch->pcdata->pwd ) )
    {
	WAIT_STATE( ch, 40 );
	send_to_char( "Wrong password.  Wait 10 seconds.\n\r", ch );
	return;
    }

    if ( strlen(arg2) < 5 )
    {
	send_to_char(
	    "New password must be at least five characters long.\n\r", ch );
	return;
    }

    /*
     * No tilde allowed because of player file format.
     */
    pwdnew = crypt( arg2, ch->name );
    for ( p = pwdnew; *p != '\0'; p++ )
    {
	if ( *p == '~' )
	{
	    send_to_char(
		"New password not acceptable, try again.\n\r", ch );
	    return;
	}
    }

    free_string( ch->pcdata->pwd );
    ch->pcdata->pwd = str_dup( pwdnew );
    save_char_obj( ch );
    send_to_char( "Ok.\n\r", ch );
    return;
}

void do_port( Character *ch, char *argument)
{
    extern int global_port;
    cprintf(ch,"%d\n\r",global_port);
}

void do_readSheetMusic( Character *ch, Object *book )
{
    SpellIndex* pSpellIndex;

	if ( strcmp(class_table[ch->class].name,"bard") )
    {
		cprintf(ch,"Only bards can use sheet music.\n\r");
		return;
    }

	pSpellIndex = get_spell_index(book->value[0]);
	if(!pSpellIndex)
	{
		log_bug("do_readSheetMusic: Spell not found(%)",book->value[0]);
		return;
	}

    if ( pSpellIndex->class_level[ch->class] <= 0 )
    {
		cprintf(ch,"You cannot learn this song.\n\r");
		return;
    }

    if ( pSpellIndex->class_level[ch->class] > ch->level )
    {
		cprintf(ch,"You must be level %d to learn this song.\n\r",
			pSpellIndex->class_level[ch->class] );
		return; 
    }

    if ( ch->pcdata->spells[book->value[0]] > 0 )
    {
		cprintf(ch,"You already know that song.\n\r");
		return;
    }

    /* Their class can learn it and they're high enough level.
     * And they don't have it already 
     */
    ch->pcdata->spells[book->value[0]] = 1;
    act("You learn $T from $p.",ch,book,pSpellIndex->full_name,TO_CHAR);
    extract_obj(book);
}

void do_readArcaneScroll( Character *ch, Object *book )
{
	int sn;
	extern int spell_skill( int spell_sn );
	SpellIndex* pSpellIndex;

    if ( class_table[ch->class].group != ARCANE )
    {
	cprintf(ch,"Only arcane casters can memorize scrolls.\n\r");
	return;
    }

	pSpellIndex = get_spell_index(book->value[0]);
	if(!pSpellIndex)
	{
		log_bug("do_readArcaneScroll: Spell not found(%)",book->value[0]);
		return;
	}

    if ( pSpellIndex->class_level[ch->class] <= 0 )
    {
		cprintf(ch,"You cannot learn this spell.\n\r");
		return;
    }

	sn = spell_skill( book->value[0] );
	if ( sn < 1 )
	{
		cprintf(ch,"This spell has been disabled for the time being.\n\r");
		cprintf(ch,"See an IMM if you have any questions.\n\r");
		return;
	}

    if ( pSpellIndex->class_level[ch->class] > get_skill(ch,sn) )
    {
		cprintf(ch,"You must be level %d in %s to learn this spell.\n\r",
			pSpellIndex->class_level[ch->class], skill_table[sn].name );
		return; 
    }

    if ( ch->pcdata->spells[book->value[0]] > 0 )
    {
		cprintf(ch,"You already know that spell.\n\r");
		return;
    }

    /* Their class can learn it and they're high enough level.
     * And they don't have it already 
     */
    ch->pcdata->spells[book->value[0]] = 1;
    act("You learn $T from $p.",ch,book,pSpellIndex->full_name,TO_CHAR);
    extract_obj(book);
}

void do_readPrayerBook( Character *ch, Object *book )
{
	int sn = book->value[0];
	SpellIndex* pSpellIndex;

    if ( class_table[ch->class].group != DIVINE &&
	     ch->class != class_lookup("paladin") )
    {
		cprintf(ch,"Only divine casters can use prayer books.\n\r");
		return;
    }

	pSpellIndex = get_spell_index(book->value[0]);
	if(!pSpellIndex)
	{
		log_bug("do_readPrayerBook: Spell not found(%)",book->value[0]);
		return;
	}

    if ( pSpellIndex->class_level[ch->class] <= 0 )
    {
		cprintf(ch,"You cannot learn this spell.\n\r");
		return;
    }

    if ( get_skill(ch, spell_skill( sn )) < pSpellIndex->class_level[ch->class] )
	{
		cprintf(ch,"You must be trained to %d in %s in order to learn this spell.\n\r",
			pSpellIndex->class_level[ch->class], skill_table[spell_skill(sn)].name );
		return;
	}

    if ( str_cmp(class_table[ch->class].name,"paladin") && get_skill(ch,gsn_theology) < pSpellIndex->class_level[ch->class] )
    {
		cprintf(ch,"You must be trained to %d in Theology to learn this spell.\n\r",
			pSpellIndex->class_level[ch->class] );
		return; 
    }

    if ( ch->pcdata->spells[book->value[0]] > 0 )
    {
		cprintf(ch,"You already know that spell.\n\r");
		return;
    }

    /* Their class can learn it and they're high enough level.
     * And they don't have it already 
     */
    ch->pcdata->spells[book->value[0]] = 1;
    act("You learn $T from $p.",ch,book,pSpellIndex->full_name,TO_CHAR);
    extract_obj(book);
}

void do_read( Character *ch, char *argument )
{
	Object *book;
    int sn, i, count, thaum_skill;
    char arg[MAX_INPUT_LENGTH];
    bool found = FALSE;
	char *suffix, spell_color;

    one_argument(argument,arg);

    if ( arg[0] == '\0' )
    {
	    if ( (book=get_eq_char(ch,WEAR_HOLD)) == NULL )
	    {
            send_to_char("Read what?\n\r",ch);
            return;
	    }
    }
	else
    if ( (book = get_obj_carry(ch,arg,ch)) == NULL )
    {
        send_to_char("You are not carrying that.\n\r",ch);
        return;
    }

	if ( book->item_type == ITEM_PRAYER_BOOK )
	{
	    do_readPrayerBook(ch,book);
	    return;
	}

	if( book->item_type == ITEM_LYRIC_SHEET )
	{
		do_readSheetMusic(ch,book);
		return;
	}

	if( book->item_type == ITEM_ARCANE_SCROLL )
	{
		do_readArcaneScroll(ch,book);
		return;
	}

    if ( book->item_type != ITEM_SPELLBOOK )
    {
        send_to_char("That's not a spellbook.\n\r",ch);
        return;
    }

  	if ( class_table[ch->class].group != ARCANE )
   	{
	    cprintf(ch,"You can't understand the writing.\n\r");
	    return;
	}

    switch( number_range(0,5) )
    {
        default: act("$n thumbs through $p.",ch,book,NULL,TO_ROOM);break;
        case 1:  act("$n leafs through $p.",ch,book,NULL,TO_ROOM);break;
        case 2:  act("$n flips through $p.",ch,book,NULL,TO_ROOM);break;
        case 3:  act("$n reads through $p.",ch,book,NULL,TO_ROOM);break;
        case 4:  act("$n pages through $p.",ch,book,NULL,TO_ROOM);break;
		case 5:  act("$n looks through $p.",ch,book,NULL,TO_ROOM); break;
    }

	act("You read the contents of $P:",ch,NULL,book,TO_CHAR);

    /* Read */
	count = 0;

	thaum_skill = get_skill(ch,gsn_thaumaturgy);

    for ( i=0 ; i<10 ; i++ )
    {
		SpellIndex* pSpellIndex;
		sn = get10Bits( book->value[i] );

	    if ( sn <= 0 )
			continue;

		pSpellIndex = get_spell_index(sn);
		if(!pSpellIndex)
		{
			log_bug("do_read: Spell not found(%)",sn);
			continue;
		}

		switch ( pSpellIndex->class_level[ch->class] )
	    {
	    	case 1: case 21: case 31: case 41: case 51: suffix = "st"; break;
	    	case 2: case 22: case 32: case 42: case 52: suffix = "nd"; break;
	    	case 3:	case 23: case 33: case 43: case 53: suffix = "rd"; break;
	    	default:	suffix = "th"; break;
	    }

		spell_color = 'W';
		if( ( thaum_skill < pSpellIndex->class_level[ch->class] ||
		      get_skill(ch,(*(pSpellIndex->sgsn))) < pSpellIndex->class_level[ch->class] )
			&& HAS_COLOROPT(ch, COLOR_SPELLS) )
		{
			spell_color = 'r';
		}

        cprintf(ch,"%2d. &%c%-22s&x  &G%d%s&x Circle %s costs &W%d&x mana to cast.\n\r",
			++count, spell_color, pSpellIndex->full_name, pSpellIndex->class_level[ch->class],
			suffix, school_bit_name(sn), pSpellIndex->base_mana );

        found = TRUE;
    }

	for ( i=0 ; i<10 ; i++ )
    {
		SpellIndex* pSpellIndex;

		sn = get20Bits( book->value[i] );

	    if ( sn <= 0 )
			continue;

		pSpellIndex = get_spell_index(sn);
		if(!pSpellIndex)
		{
			log_bug("do_read: Spell not found(%)",sn);
			continue;
		}

		switch ( pSpellIndex->class_level[ch->class] )
	    {
	    	case 1: case 21: case 31: case 41: case 51: suffix = "st"; break;
	    	case 2: case 22: case 32: case 42: case 52: suffix = "nd"; break;
	    	case 3:	case 23: case 33: case 43: case 53: suffix = "rd"; break;
	    	default:	suffix = "th"; break;
	    }

		spell_color = 'W';
		if( ( thaum_skill < pSpellIndex->class_level[ch->class] ||
		      get_skill(ch,(*(pSpellIndex->sgsn))) < pSpellIndex->class_level[ch->class] )
			&& HAS_COLOROPT(ch, COLOR_SPELLS) )
		{
			spell_color = 'r';
		}

        cprintf(ch,"%2d. &%c%-22s&x  &G%d%s&x Circle %s costs &W%d&x mana to cast.\n\r",
			++count, spell_color, pSpellIndex->full_name, pSpellIndex->class_level[ch->class],
			suffix, school_bit_name(sn), pSpellIndex->base_mana );

        found = TRUE;
    }

    if (!found)
            send_to_char("This spellbook is empty.\n\r",ch);

    return;
}

void customizeEqOrder( Character *ch, char *argument )
{
	char arg[MAX_INPUT_LENGTH];
	int 	slot;
	int		wearloc;
	int		i;

	if( argument[0] == '\0' )
	{
		cprintf(ch,"Usage:  custom eqorder show\n\r"
                   "        custom eqorder <slot#> <wear_location>\n\r");
		return;
	}

	argument = one_argument( argument, arg );

	if ( !str_cmp(arg,"show") )
	{
		cprintf(ch," == Equipment Wear Location Ordering ==\n");
		for( i = 0 ; i < MAX_WEAR ; i++ )
		{
			if ( ch->pcdata->eq_list_order[i] < 0 )
				cprintf(ch," Slot #%2d: %s\n\r", i+1, " <not shown> ");
			else
				cprintf(ch," Slot #%2d: %s\n\r", i+1, wear_loc_flags[ch->pcdata->eq_list_order[i]] );
		}
		return;
	}

	if ( !is_number(arg) || *argument == '\0' )
	{
		customizeEqOrder(ch,"");
		return;
	}

	slot = atoi(arg);
	if ( slot < 1 || slot > MAX_WEAR )
	{
		cprintf(ch,"Range for slot is 1 to %d.\n\r", MAX_WEAR );
		return;
	}

	if( !str_cmp(argument,"none"))
	{
		ch->pcdata->eq_list_order[slot-1] = -1;
		cprintf(ch,"Nothing will be displayed in slot %d.\n\r",slot);
		return;
	}

	if ( (wearloc = flag_value( wear_loc_flags, argument )) == NO_FLAG )
	{
		cprintf(ch,"%s is not a valid wear location flag.\n\r", argument );
		return;
	}

	/* Ok we have the slot and the flag.  Now we need to find its index in the table. */
	for( i = 0 ; wear_loc_flags[i].settable ; i++ )
	{
		if ( wear_loc_flags[i].bit == wearloc )
		{
			ch->pcdata->eq_list_order[slot-1] = i;
			cprintf(ch,"Slot #%d set to %s.\n\r", slot, flag_string(wear_loc_flags,wearloc) );
			return;
		}
	}

	cprintf(ch,"Unable to complete this command - there is a data error with the wear_loc_flags table.\n\r");
	return;
}

void customizeChannels( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    int i;
    int chan;

    argument = one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
		cprintf(ch,"== Settings ==\n\r");
		for( i=0 ; i < MAX_CHANNELS ; i++ )
 		{
	    	if ( channel_table[i].minimum_level > ch->level )
			continue;
	    	cprintf(ch,"%-15s &%c%c&w\n\r",
			channel_table[i].name,
			ch->pcdata->customChannelColor[i],
			ch->pcdata->customChannelColor[i] );
		}
		cprintf(ch,"\n\r");
		cprintf(ch,"%-15s &%c%c&w\n\r",
			"Say", ch->pcdata->customSayColor, ch->pcdata->customSayColor );
		cprintf(ch,"%-15s &%c%c&w\n\r",
			"Tell", ch->pcdata->customTellColor, ch->pcdata->customTellColor );
		cprintf(ch,"%-15s &%c%c&w\n\r",
			"GroupTell", ch->pcdata->customGTellColor, ch->pcdata->customGTellColor );
		cprintf(ch,"%-15s &%c%c&w\n\r",
			"RoundTable", ch->pcdata->customRoundTableColor, ch->pcdata->customRoundTableColor );
		cprintf(ch,"%-15s &%c%c&w\n\r",
			"RTSub", ch->pcdata->customRTSubColor, ch->pcdata->customRTSubColor );
		return;
    }

    if ( !str_prefix( arg, "reset" ) || !str_prefix( arg, "default" ) )
    {
		resetCustomColorData(ch);
		cprintf(ch,"Channel colors set to defaults.\n\r");
		return;
    }

    if ( (chan = channel_lookup(arg) ) < 0 )
    {
		cprintf(ch,"No such channel.\n\r");
		return;
    }

    if ( argument[0] == '\0' || !isalpha(argument[0]) )
    {
		do_custom(ch,"");
		return;
    }
   
    ch->pcdata->customChannelColor[chan] = argument[0]; 
    cprintf(ch,"Channel color code set to '%c'.\n\r", *argument);
    return;
}

void do_custom( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];

    argument = one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
		cprintf(ch,"Usage:  custom channel <channel_name> <color_code>\n\r"
                   "        custom eqorder <show>\n\r"
	 			   "        custom eqorder <slot#> <wear_loc>\n\r"
				   "        custom say <say_color_code>\n\r"
				   "        custom tells <tell_color_code>\n\r"
                   "        custom gtells <gtell_color_code>\n\r"
                   "        custom roundtable <rt_color_code>\n\r"
                   "        custom rtsub <rtsub_color_code>\n\r");
		return;
    }

    if ( !str_prefix( arg, "channel" ) )
    {
		customizeChannels(ch,argument);
		return;
    }
	else
	if ( !str_prefix( arg, "eqorder" ) )
	{
		customizeEqOrder(ch,argument);
		return;
	}
	if ( !str_prefix( arg, "say" ) )
	{
		ch->pcdata->customSayColor = *argument;
		cprintf(ch,"Custom say color set to character '%c'.\n\r", *argument );
		return;
	}
	else
	if( !str_prefix( arg, "tells") )
	{
		ch->pcdata->customTellColor = *argument;
		cprintf(ch,"Custom tell color set to character '%c'.\n\r", *argument );
	}
	else
	if( !str_prefix( arg, "gtells") )
	{
		ch->pcdata->customGTellColor = *argument;
		cprintf(ch,"Custom gtell color set to character '%c'.\n\r", *argument );
	} 
	else
	if( !str_prefix( arg, "roundtable") )
	{
		ch->pcdata->customRoundTableColor = *argument;
		cprintf(ch,"Custom round table color set to character '%c'.\n\r", *argument );
	} 
	else
	if( !str_prefix( arg, "rtsub") )
	{
		ch->pcdata->customRTSubColor = *argument;
		cprintf(ch,"Custom rtsub color set to character '%c'.\n\r", *argument );
	} 

    return;
}

void do_nobattleprompt( Character *ch, char *argument )
{
    TOGGLE_BIT(ch->display,DISP_NO_BATTLE_PROMPT);
    if ( !IS_SET(ch->display,DISP_NO_BATTLE_PROMPT) )
        cprintf(ch,"You will see full battle prompts.\n\r");
    else
        cprintf(ch,"You will not see battle prompts.\n\r");
}

void do_monitorgroupcondition( Character *ch, char *argument )
{
    TOGGLE_BIT(ch->display,DISP_MONITOR_GROUP);
    if ( IS_SET(ch->display,DISP_MONITOR_GROUP) )
        cprintf(ch,"You will see your group's hp.\n\r");
    else
        cprintf(ch,"You will not see your group's hp.\n\r");
}

void do_appendcondition( Character *ch, char *argument )
{
    TOGGLE_BIT(ch->display,DISP_SHOW_AUTOSAVES);
    if ( !IS_SET(ch->display,DISP_SHOW_AUTOSAVES) )
        cprintf(ch,"Conditions will NOT be shown in damage messages.\n\r");
    else
        cprintf(ch,"Conditions will be shown in damage messages.\n\r");
}

void do_autosave( Character *ch, char *argument )
{
    TOGGLE_BIT(ch->display,DISP_SHOW_AUTOSAVES);
    if ( !IS_SET(ch->display,DISP_SHOW_AUTOSAVES) )
        cprintf(ch,"You will not be told when the game autosaves this character.\n\r");
    else
        cprintf(ch,"You will be told when the game autosaves this character.\n\r");
}

void do_notitles( Character *ch, char *argument )
{
    TOGGLE_BIT(ch->display,DISP_WHO_NOTITLES);
    if ( !IS_SET(ch->display,DISP_WHO_NOTITLES) )
	cprintf(ch,"You will now see titles on the who list.\n\r");
    else
	cprintf(ch,"You will not see titles on the who list.\n\r");
}

void do_noguilds( Character *ch, char *argument )
{
    TOGGLE_BIT(ch->display,DISP_WHO_NOGUILDS);
    if ( !IS_SET(ch->display,DISP_WHO_NOGUILDS) )
        cprintf(ch,"You will now see guilds on the who list.\n\r");
    else
        cprintf(ch,"You will not see guilds on the who list.\n\r");
}

void do_nosurnames( Character *ch, char *argument )
{
    TOGGLE_BIT(ch->display,DISP_WHO_NOSURNAMES);
    if ( !IS_SET(ch->display,DISP_WHO_NOSURNAMES) )
        cprintf(ch,"You will now see surnames on the who list.\n\r");
    else
        cprintf(ch,"You will not see surnames on the who list.\n\r");
}

void do_noemotemarks( Character *ch, char *argument )
{
    TOGGLE_BIT(ch->display,DISP_NO_EMOTE_MARKS);
    if ( !IS_SET(ch->display,DISP_NO_EMOTE_MARKS) )
        cprintf(ch,"You will now see a * in front of emotes.\n\r");
    else
        cprintf(ch,"You will not see a * in front of emotes.\n\r");
}

void do_surname( Character *ch, char *argument )
{


}

void clan_info( Clan * clan, Character *ch,  const char *msg, ... )
{
    Descriptor *d;
	char	buf[MAX_STRING_LENGTH];
	va_list	ap;

	if ( clan == NULL )
	{
		log_bug("NULL clan in clan_info",0);
		return;
	}

	snprintf(buf,sizeof(buf),"&W%s&x Info :: ",clan->name);
	va_start( ap, msg );
	vsnprintf(buf+strlen(buf),sizeof(buf)-strlen(buf),msg,ap);

    for ( d = descriptor_list ; d != NULL ; d = d->next )
    {
		if (  d->connected == CON_PLAYING 
           	&& d->character != NULL
           	&& d->character->clan == clan 
           	&& !IS_SET(d->character->comm,COMM_NOCLANINFO)
	   	&& d->character != ch )
		{
	    	act(buf,d->character,NULL,ch,TO_CHAR);
 		}
    }
	va_end( ap );
	return;
}

void do_fullequip( Character *ch, char *argument )
{
    TOGGLE_BIT(ch->display,DISP_FULL_EQUIPMENT);
    if ( !IS_SET(ch->display,DISP_FULL_EQUIPMENT) )
        cprintf(ch,"You will now see all equipment slots in 'equipment'.\n\r");
    else
        cprintf(ch,"You will not see all equipment slots in 'equipment'.\n\r");
}

void do_worth( Character *ch, char *argument )
{
	int i;
    char arg[MAX_INPUT_LENGTH];

    if ( IS_NPC(ch) )
		return;

    argument = one_argument(argument, arg);

    if( arg[0] == '\0' )
    {
	    for( i=0 ; currency_table[i].name != NULL ; i++ )
		    cprintf(ch,"%s: %d   ", capitalize(currency_table[i].name), ch->coins[i] );
	    cprintf(ch,"\n\r");

	    cprintf(ch," Last Level: %s\n\r", 
		    ch->pcdata->date_last_level <= 0 ? "never" 
			    : format_date( ch->pcdata->date_last_level, "%d/%b/%Y" ) );

	    cprintf(ch," Experience Progress:\n\r");
        cprintf(ch,"%s %d%%\n\r", exp_graph(ch,UMAX(10,ch->pcdata->worth_columns)), 
            ch->exp * 100 / exp_to_level[ch->level].tnl );
    }
    else if ( !str_prefix(arg,"xpwidth") )
    {
        int width;

        one_argument(argument, arg);

        if ( arg[0] == '\0' )
        {
            cprintf(ch, "Syntax:  worth [xpwidth <width>]\n\r"); 
            return;
        }

        if ( (width = atoi(arg)) < 10 || width > 120 )
        {
            cprintf(ch,"Valid column width range is 10 to 120.\n\r");
            return;
        }

        ch->pcdata->worth_columns = width;
        cprintf(ch,"Your XP bar will be %d columns wide in the 'worth' command.\n\r",width);
        if ( width > 80 )
        {
            cprintf(ch,"This value is larger than the standard terminal width and may\n\r"
               "not look good on some terminals.\n\r"); 
        }

        return;
    }
    else
    {
       cprintf(ch, "Syntax:  worth [xpwidth <width>]\n\r"); 
    }

    return;
}

#undef SYNTAX
#define SYNTAX \
    "Usage:     display                  <-- View display settingsn\r"\
    "           display <option> [value] <-- To toggle/set"

void do_lore( Character *ch, char *argument )
{
    Object *obj;
    char arg[MAX_INPUT_LENGTH];

    argument = one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	cprintf(ch,"Usage: lore <item in inventory>\n\r"
		   "       lore shop <item in shop>\n\r");
	return;
    }

    if ( !strcmp(arg,"shop") )
    {
	Character *keeper;
	extern Character *find_keeper( Character *ch );
	extern Object *get_obj_keeper( Character *ch, Character *keeper, char *argument );

	if ( *argument == '\0' )
	{
	    do_lore(ch,"");
	    return;
	}

        if ( (keeper = find_keeper( ch )) == NULL )
            return;

        if ( (obj = get_obj_keeper( ch,keeper,argument )) == NULL )
		{
			act("$E isn't selling anything like that.",ch,NULL,keeper,TO_CHAR);
			return;
		}

        if ( !can_see_obj( ch, obj ) )
        {
            act( "$n tells you 'I don't sell that -- try 'list''.",
                keeper, NULL, ch, TO_VICT );
            ch->reply = keeper;
            return;
        }
    }
    else
    if ( !str_cmp( arg,"room") )
    {
        if ( (obj = get_obj_here(ch,argument)) == NULL )
        {
            cprintf(ch,"Nothing like that in the room.\n\r");
            return;
        }
    }
    else
    if ( (obj = get_obj_carry(ch,arg,ch)) == NULL )
    {
        if ( (obj = get_obj_here(ch,arg)) == NULL )
        {
            cprintf(ch,"You don't see anything like that in your inventory or environment.\n\r");
            return;
        }

        cprintf(ch,"A matching item was found in the room.\n\r");
    }
        
    obj_info_to_char( obj, ch, gsn_lore );
    return;
}

void do_audit( Character *ch, char *argument )
{
	/* Audit an area - puts objects on-line for perusal */
	ObjIndex *pObj;
	Area *pArea;
	int i;
	char file[MAX_STRING_LENGTH];
	FILE *fp, *fp2;
	/*void obj_info_to_file( Object *obj, FILE *fp );*/
	void obj_info_to_file2( int vnum, FILE *fp );


	snprintf(file,sizeof(file),"%s/index.html", WEB_DIR );
	if ( (fp2 = fopen(file, "w")) == NULL )
	{
		cprintf(ch,"Could not open index file %s: %s\n\r", file, strerror(errno) );
		return;
	}

	fprintf(fp2,"<html><head><title>THOC Object Audit Page</title></head><body><ul>\n");

    for( pArea = area_first; pArea; pArea = pArea->next )
	{
		/* Get file name */
		snprintf( file, sizeof(file), "%s/audit-%d.html", WEB_DIR, pArea->vnum );
		if ( (fp = fopen( file, "w" )) == NULL )
		{
			cprintf(ch,"Unable to open audit HTML file %s: %s\n\r", file, strerror(errno) );
			fclose(fp2);
			return;
		}

		fprintf(fp2,"<li><a href=audit-%d.html>%s</a> [<a href=%d-spawn.html>Spawns</a>]</li>\n", pArea->vnum, pArea->name, pArea->vnum );	

		fprintf(fp,"<html>\n");
		fprintf(fp,"<h2>Object List for Area #%d</h2>\n",pArea->vnum);
		for( i = pArea->lvnum ; i <= pArea->uvnum ; i++ )
		{
			fprintf(fp,"<hr>\n");
			if ( (pObj = get_obj_index( i )) == NULL )
				fprintf(fp,"NO OBJECT WITH VNUM %d\n", i );
			else
			{
			/* Version 2
				Object *obj;
	
				if ( (obj = create_object( pObj, 0 )) == NULL )
					fprintf(fp,"ERROR CREATING OBJECT WITH VNUM %d\n", i );
				else
				obj_info_to_file( obj, fp );
				free_obj(obj);
			*/
				obj_info_to_file2( i, fp );
			}
		}
		fprintf(fp,"\n</html>");
		fclose( fp );
	}

	fprintf( fp2, "</ul></body></html>\n");
	fclose( fp2 );
}

void obj_info_to_file2( int vnum, FILE *fp )
{
	ObjIndex *pObj;
    Affect *paf;
    int cnt;
	void show_obj_values_to_file( FILE *fp, ObjIndex *obj );


	if ( (pObj = get_obj_index( vnum )) == NULL )
	{
		fprintf(fp, "<hr><h2>Vnum %d not used</h2>\n", vnum );
		return;
	}

	fprintf( fp, "<h2><h1>#%d</h1><pre>\n", vnum );
    fprintf( fp, "Name:        [%s]\nArea:        [%5d] %s\n",
		pObj->name, !pObj->area ? -1        : pObj->area->vnum, !pObj->area ? "No Area" : pObj->area->name );

    fprintf( fp, "Vnum:        [%5d]\nType:        [%s]\n", pObj->vnum, flag_string( type_flags, pObj->item_type ) );
    fprintf( fp , "Level:       [%5d]\n", pObj->level );
    fprintf( fp , "Wear flags:  [%s]\n", flag_string( wear_flags, pObj->wear_flags ) );
    fprintf( fp , "Extra flags: [%s]\n", flag_string( extra_flags, pObj->extra_flags ) );
    fprintf( fp , "Material:    [%s]\n",                /* ROM */ pObj->material );
    fprintf( fp, "Condition:   [%3d]\n",  pObj->condition );
	fprintf( fp, "Durability:  [%3d]\n",	pObj->durability );
	fprintf( fp, "Quality:     [%3d]\n",  pObj->quality );
    fprintf( fp, "Weight:      [%d.%d stones]\nCost:        [%s]\n", pObj->weight/10,pObj->weight%10, web_money_breakdown(pObj->cost) );

    if ( pObj->extra_descr )
    {
		ExtraDescr *ed;

		fprintf(fp, "Ex desc kwd: " );

		for ( ed = pObj->extra_descr; ed; ed = ed->next )
			fprintf( fp, "[%s] ", ed->keyword );
		fprintf( fp, "\n");
    }

    fprintf( fp , "Short desc:  %s\nLong desc:\n     %s\n", pObj->short_descr, pObj->description );

    for ( cnt = 0, paf = pObj->affected; paf; paf = paf->next )
    {
		if ( cnt == 0 )
		{
	    	fprintf( fp,  "Number Modifier Affects\n" );
	    	fprintf( fp,  "------ -------- -------\n" );
		}
		fprintf( fp , "[%4d] %-8d %s\n", cnt, paf->modifier, affect_loc_name( paf->location, paf->misc  ) );
		cnt++;
    }

    show_obj_values_to_file( fp, pObj );

	fprintf(fp,"</pre>\n");
    return;
}


	
void obj_info_to_file( Object *obj, FILE *fp )
{
	bool fSpec = FALSE;
	int crit;
    Affect *paf;
	SpellIndex* pSpellIndex;

	fprintf(fp,"Keywords: [%s]  Short: [%s]\nLong: [%s]\n",
			obj->name, obj->short_descr, obj->description );
	fprintf(fp,"Wear Flags: [%s]  ", flag_string( wear_flags, obj->wear_flags ));
	fprintf(fp,"Extra Flags: [%s]\n\r", flag_string( extra_flags, obj->extra_flags ));
	fprintf(fp,"VNUM: [%d]   Cost: [%s]   Timer: [%d]\n",
			obj->pIndexData->vnum, web_money_breakdown( obj->cost ), obj->timer );
	fprintf(fp,"\n");

    fprintf(fp,"%s is type %s, weighs %d.%d stones, level %d.\n",
        obj->short_descr, item_name(obj->item_type), obj->weight / 10, obj->weight % 10, obj->level );

    switch( obj->item_type )
    {
	case ITEM_CONTAINER:
            fprintf(fp,"Capacity: %d#  Maximum weight: %d#  flags: %s\n",
                obj->value[0], obj->value[3], flag_string(container_flags,obj->value[1]));
	    if (obj->value[4] != 100)
                fprintf(fp,"Weight multiplier: %d%%\n", obj->value[4]);

        if ( IS_SET( obj->value[1], CONT_LOCKED ) )
            fprintf(fp,"Lock level: %d\n", obj->value[5] );

	    break;

	case ITEM_PROJECTILE: 
		fprintf(fp,"Can be fired from: %s\n\r", flag_string( ranged_flags, obj->value[0] ) );
		fprintf(fp,"Damage:            %dd%d\n\r", obj->value[1], obj->value[2] );

		if ( obj->value[7] > 0 )
		{
			pSpellIndex = get_spell_index(obj->value[7]);
			fprintf(fp,"Weapon has special affect '%s'.\n", pSpellIndex ? pSpellIndex->full_name : "(null)");
		}

		break;

	case ITEM_WEAPON: {
		float modDPS;

        fprintf(fp,"Weapon type is %s, and uses the %s skill.\n",
			 weapon_name(obj->value[0]),
			 skill_table[ *weapon_table[get_weapon_index(obj->value[0])].gsn  ].name );
		modDPS = getDPS(obj->value[1],obj->value[2],obj->value[5]);
		modDPS = (float) modForCondition( obj, (int) (modDPS*100) ) / 100.0;

        fprintf(fp,"Damage:  %dd%d   Speed: %d.%d seconds\n"
                   "Dam/Sec: %3.2f   Effective Dam/Sec: %3.2f\n",
                obj->value[1],obj->value[2], obj->value[5]/10,obj->value[5]%10,
				getDPS(obj->value[1],obj->value[2],obj->value[5]), modDPS );

	    if ( obj->value[7] > 0 )
		{
			pSpellIndex = get_spell_index(obj->value[7]);
			fprintf(fp,"Weapon has special affect '%s'.\n\r",
				pSpellIndex ? pSpellIndex->full_name : "(null)");
		}

		crit = 100 - weapon_table[get_weapon_index(obj->value[0])].crit_min;

		fprintf(fp,"Critical Hits: %d%%   Multiplier: x%d\n",
			crit,
			weapon_table[get_weapon_index(obj->value[0])].crit_mult );

		if ( IS_SET(obj->wear_flags,ITEM_WEAR_OFFHAND) )
			fprintf(fp,"This weapon can be equipped in your offhand slot.\n");
		if ( IS_WEAPON_STAT(obj,WEAPON_TWO_HANDS) )
			fprintf(fp,"This weapon requires two hands to use.\n");

        if ( obj->value[6] > 0 )
            fprintf(fp,"Range: %d rooms\n\r", obj->value[6] );

	    break;
	}

	case ITEM_ARMOR: {
		int ac0, ac1, ac2, ac3;

            fprintf(fp, "Armor Class:  %d pierce, %d bludgeon, %d slash, %d other\n",
                (ac0=obj->value[0]), (ac1=obj->value[1]), (ac2=obj->value[2]), (ac3=obj->value[3]));

			ac0 = modForCondition( obj, ac0 );
			ac1 = modForCondition( obj, ac1 );
			ac2 = modForCondition( obj, ac2 );
			ac3 = modForCondition( obj, ac3 );

			fprintf(fp, "Effective AC: %d pierce, %d bludgeon, %d slash, %d other\n",
				ac0, ac1, ac2, ac3 );

			fprintf(fp, "Armor Type: %s   Absorb Rate: %d%% (%d%% + %d%%)\n",
				armor_table[obj->value[5]].name, armor_table[obj->value[5]].absorb + obj->absorb,
				armor_table[obj->value[5]].absorb, obj->absorb);

            break;
	}

	case ITEM_PRAYER_BOOK:
	    if ( obj->value[0] <= 0 )
		   	fprintf(fp,"The book contains only gibberish.\n");
	    else
		{
	        pSpellIndex = get_spell_index(obj->value[0]);
			fprintf( fp," Contains the spell '%s'.\n\r",
				pSpellIndex ? pSpellIndex->name : "(null)");
		}
	    break;

	case ITEM_INSTRUMENT:
		fprintf(fp," Instrument Type: %s\n", flag_string( instrument_types, obj->value[0] ) );
			break;

	case ITEM_LYRIC_SHEET:
		if ( obj->value[0] <= 0 )
			fprintf(fp,"The lyrics are meaningless.\n");
		else
		{
			pSpellIndex = get_spell_index(obj->value[0]);

			if(!pSpellIndex)
			{
				log_bug("obj_info_to_file: Lyric sheet spell not found(%d)",obj->value[0]);
			}
			else
			{
				fprintf(fp, " Contains the song '%s'.\n",  
					pSpellIndex->name );
				fprintf(fp, " Instrument: %s   Level: (varies by class)\n",
					instrument_name(obj->value[0]) );
			}
		}
		break;

	case ITEM_ARCANE_SCROLL:
		if ( obj->value[0] <= 0 )
			fprintf(fp,"The scroll contains only gibberish.\n");
		else
		{
			pSpellIndex = get_spell_index(obj->value[0]);

			if(!pSpellIndex)
			{
				log_bug("obj_info_to_char: Arcane scroll spell not found(%d)",obj->value[0]);
			}
			else
			{
				fprintf(fp, " Contains the spell '%s'.\n",  
					pSpellIndex->name );
				fprintf(fp, " School: %s   Level: (varies by class)",
					school_bit_name(obj->value[0]) );
				fprintf(fp, " This scroll can%s be copied.\n", obj->value[1] ? " not" : "");
				if ( obj->value[1] )
					fprintf(fp," This scroll has a %d%% chance of being destroyed in a copy attempt.\n", obj->value[2] );
			}
		}
		break;

	case ITEM_FORGE:
            fprintf(fp, "It is a %s used with the %s skill.\n",
		flag_string( forge_flags, obj->value[3] ),
	   	skill_table[obj->value[2]].name );
	    break;

	default:
	    break;
    }

    if (!obj->enchanted)
    for ( paf = obj->pIndexData->affected; paf != NULL; paf = paf->next )
    {
        if ( paf->location != APPLY_NONE && paf->modifier != 0 )
        {
            formatAffectDescriptionFile( fp, paf );
            fprintf(fp,"\n\r");
        }
    }

    for ( paf = obj->affected; paf != NULL; paf = paf->next )
    {
        if ( paf->location != APPLY_NONE && paf->modifier != 0 )
        {
            formatAffectDescriptionFile( fp, paf );
            fprintf(fp,"\n\r");
        }
    }

	fprintf(fp,"Special Properties:");
	if ( IS_SET(obj->extra_flags,ITEM_UNIQUE) )
		fprintf(fp," LORE"), fSpec = TRUE;

    if ( IS_SET(obj->extra_flags,ITEM_STICKY) )
        fprintf(fp," STICKY"), fSpec = TRUE;

	if ( obj->deity > 0 )
		fprintf(fp," %s-only", deity_table[obj->deity].name), fSpec = TRUE;

	if ( !fSpec )
		fprintf(fp," none");

	fprintf(fp,"\n");

	fprintf(fp,"Condition:   %3d%%\n"
               "Durability:  %3d%%\n"
               "Quality:     %3d%%\n",
		obj->condition, obj->durability, obj->quality );

	if ( obj->crafter != NULL )
		fprintf(fp,"This object was crafted by %s.\n\r", obj->crafter );
    return;
}

void obj_info_to_char( Object *obj, Character *ch, int sn )
{
	bool fSpec = FALSE;
	int crit;
    Affect *paf;
	bool fImm = IS_IMMORTAL(ch);
	SpellIndex* pSpellIndex;

	if ( fImm )
	{
		cprintf(ch,"Keywords: [%s]  Short: [%s]\n\rLong: [%s]\n\r",
			obj->name, obj->short_descr, obj->description );
		cprintf(ch,"Wear Flags: [%s]  ", flag_string( wear_flags, obj->wear_flags ) );
		cprintf(ch,"Extra Flags: [%s]\n\r", flag_string( extra_flags, obj->extra_flags ) );
		cprintf(ch,"VNUM: [%d]   Cost: [%s]   Timer: [%d]\n\r",
			obj->pIndexData->vnum, money_breakdown( obj->cost ), obj->timer );
		cprintf(ch,"\n\r");
	}

    cprintf(ch,"&%c%s&x is type '%s'.  Weight %d.%d stones, level %d.\n\r",
        HAS_COLOROPT(ch, COLOR_OBJ_CON) ? get_con_color(ch->level,obj->level) : 'x',
        obj->name, item_name(obj->item_type), obj->weight / 10, obj->weight % 10, obj->level );

    switch( obj->item_type )
    {
	case ITEM_CONTAINER:
        cprintf(ch,"Capacity: %d#  Maximum weight: %d#  flags: %s\n\r",
                obj->value[0], obj->value[3], flag_string(container_flags,obj->value[1]));
	    if (obj->value[4] != 100)
            cprintf(ch,"Weight multiplier: %d%%\n\r", obj->value[4]);
        if ( IS_SET( obj->value[1], CONT_LOCKED ) && get_skill(ch,gsn_open_lock) > 1 )
            cprintf(ch,"Lock level: %d\n", obj->value[5] );

	    break;

    case ITEM_PROJECTILE:
        cprintf(ch,"Can be fired from: %s\n\r", flag_string( ranged_flags, obj->value[0] ) );
        cprintf(ch,"Damage:            %dd%d\n\r", obj->value[1], obj->value[2] );

        if ( obj->value[7] > 0 )
		{
			pSpellIndex = get_spell_index(obj->value[7]);
			cprintf(ch,"Weapon has special affect '%s'.\n", pSpellIndex ? pSpellIndex->full_name : "(null)");
		}
        break;

	case ITEM_WEAPON: {
		float modDPS;

        cprintf(ch,"Weapon type is %s, and uses the %s skill.\n\r",
			 weapon_name(obj->value[0]),
			 skill_table[ *weapon_table[get_weapon_index(obj->value[0])].gsn  ].name );
		/*modDPS = getDPS(obj->value[1],obj->value[2],obj->value[5]) + (GET_DAMROLL(ch) / (obj->value[5]/10));*/
		modDPS = getDPS(obj->value[1],obj->value[2],obj->value[5]);// + (GET_DAMROLL(ch) / (obj->value[5]/10));
		modDPS = (float) modForCondition( obj, (int) (modDPS*100) ) / 100.0;

        cprintf(ch,"Damage:  %dd%d   Speed: %d.%d seconds\n\r"
                   "Dam/Sec: %3.2f   Effective Dam/Sec: %3.2f\n\r",
                obj->value[1],obj->value[2], obj->value[5]/10,obj->value[5]%10,
				getDPS(obj->value[1],obj->value[2],obj->value[5]), modDPS );

	    if ( obj->value[7] > 0 )
		{
			pSpellIndex = get_spell_index(obj->value[7]);
			cprintf(ch,"Weapon has special affect '%s'.\n\r",
				pSpellIndex ? pSpellIndex->full_name : "(null)");
		}

		crit = 100 - weapon_table[get_weapon_index(obj->value[0])].crit_min;
		if ( HAS_PROF(ch,gpn_improved_critical) )
			crit = 150 * crit / 100;

		cprintf(ch,"Critical Hits: %d%%   Multiplier: x%d\n\r",
			crit,
			weapon_table[get_weapon_index(obj->value[0])].crit_mult );

		if ( IS_SET(obj->wear_flags,ITEM_WEAR_OFFHAND) )
			cprintf(ch,"This weapon can be equipped in your offhand slot.\n\r");
		if ( IS_WEAPON_STAT(obj,WEAPON_TWO_HANDS) )
			cprintf(ch,"This weapon requires two hands to use.\n\r");

        if ( obj->value[6] > 0 )
            cprintf(ch,"Range: %d rooms\n\r", obj->value[6] );

	    break;
	}

	case ITEM_ARMOR: {
		int ac0, ac1, ac2, ac3;

            cprintf( ch, "Armor Class:  %d pierce, %d bludgeon, %d slash, %d other\n\r",
                (ac0=obj->value[0]), (ac1=obj->value[1]), (ac2=obj->value[2]), (ac3=obj->value[3]));

			ac0 = modForCondition( obj, ac0 );
			ac1 = modForCondition( obj, ac1 );
			ac2 = modForCondition( obj, ac2 );
			ac3 = modForCondition( obj, ac3 );

			cprintf( ch, "Effective AC: %d pierce, %d bludgeon, %d slash, %d other\n\r",
				ac0, ac1, ac2, ac3 );

			cprintf( ch, "Armor Type: %s\n\rAbsorb Rate: %d%% (Base %d%% + Obj Bonus %d%% + Char Bonus %d%%)\n\r",
				armor_table[obj->value[5]].name, armor_table[obj->value[5]].absorb + obj->absorb + ch->absorb,
				armor_table[obj->value[5]].absorb, obj->absorb, ch->absorb);

            break;
	}

	case ITEM_PRAYER_BOOK:
	    if ( obj->value[0] <= 0 )
	   		cprintf(ch,"The book contains only gibberish.\n\r");
	    else
		{
	        pSpellIndex = get_spell_index(obj->value[0]);
			cprintf( ch," Contains the spell '%s'.\n\r",
				pSpellIndex ? pSpellIndex->name : "(null)");
		}
	    break;

	case ITEM_INSTRUMENT:
		cprintf(ch," Instrument Type: %s\n\r", flag_string( instrument_types, obj->value[0] ) );
			break;

	case ITEM_LYRIC_SHEET:
		if ( obj->value[0] <= 0 )
			cprintf(ch,"The lyrics are meaningless.\n\r");
		else
		{
			int lvl;
			pSpellIndex = get_spell_index(obj->value[0]);

			if(!pSpellIndex)
			{
				log_bug("obj_info_to_char: Lyric sheet spell not found(%d)",obj->value[0]);
			}
			else
			{
				lvl = pSpellIndex->class_level[ch->class];

				cprintf( ch, " Contains the song '%s'.\n\r",  
					pSpellIndex->name );
				cprintf( ch, " Instrument: %s   Level: ",
					instrument_name(obj->value[0]) );
				if( lvl < 1 || lvl >= LEVEL_IMMORTAL )
					cprintf(ch,"<not available to your class>\n\r");
				else
					cprintf(ch,"%d\n\r", lvl );
			}
		}
		break;

	case ITEM_ARCANE_SCROLL:
		if ( obj->value[0] <= 0 )
			cprintf(ch,"The scroll contains only gibberish.\n\r");
		else
		{
			int lvl;
			pSpellIndex = get_spell_index(obj->value[0]);

			if(!pSpellIndex)
			{
				log_bug("obj_info_to_char: Arcane scroll spell not found(%d)",obj->value[0]);
			}
			else
			{
				lvl = pSpellIndex->class_level[ch->class];

				cprintf( ch, " Contains the spell '%s'.\n\r",  
					pSpellIndex->name );
				cprintf( ch, " School: %s   Level: ",
					school_bit_name(obj->value[0]) );
				if( lvl < 1 || lvl >= LEVEL_IMMORTAL )
					cprintf(ch,"<not available to your class>\n\r");
				else
					cprintf(ch,"%d\n\r", lvl );
				
				cprintf(ch, " This scroll can%s be copied.\n\r", obj->value[1] ? " &rnot&x" : "");
				
				if ( obj->value[1] )
					cprintf(ch," This scroll has a %d%% chance of being destroyed in a copy attempt.\n\r", obj->value[2] );
			}
		}
		break;

	case ITEM_FORGE:
            cprintf(ch, "It is a %s used with the %s skill.\n\r",
		flag_string( forge_flags, obj->value[3] ),
	   	skill_table[obj->value[2]].name );
	    break;

	default:
	    break;
    }

    if (!obj->enchanted)
    for ( paf = obj->pIndexData->affected; paf != NULL; paf = paf->next )
    {
        if ( paf->location != APPLY_NONE && paf->modifier != 0 )
        {
			formatAffectDescription( ch, paf );
			cprintf(ch,"\n\r");
        }
    }

    for ( paf = obj->affected; paf != NULL; paf = paf->next )
    {
        if ( paf->location != APPLY_NONE && paf->modifier != 0 )
        {
			formatAffectDescription( ch, paf );
            if ( IS_SET(paf->flags,AFF_OBJ) && paf->duration > 0 )
            {
                char duration[128];

                switch( paf->duration )
                {
                    case DUR_PERMANENT: sprintf(duration,"permanent affect"); break;
                    case DUR_SPECIAL:   sprintf(duration,"special duration"); break;
                    default:
                        if ( IS_SET(paf->flags,AFF_ABSOLUTE_TIME) )
                        {
                            if ( paf->duration < 60 )
                                snprintf(duration,sizeof(duration),"%d second%s",
                                    (int)paf->duration, paf->duration == 1 ? "" : "s" );
                            else
                                snprintf(duration,sizeof(duration),"%d minute%s",
                                    (int)paf->duration / 60, paf->duration / 60 == 1 ? "" : "s" );
                        }
                        else
                        if ( paf->location == APPLY_BLADETURN )
                            sprintf(duration,"special duration");
                        else
                        if ( paf->duration - current_time < 60 )
                            sprintf(duration,"%d second%s", (int)UMAX(0,paf->duration - current_time),
                                (int)UMAX(0,paf->duration - current_time) == 1 ? "" : "s" );
                        else
                            sprintf(duration,"%d minute%s", (int)(paf->duration - current_time) / 60,
                                (int)(paf->duration - current_time) / 60 == 1 ? "" : "s" );
                }
                cprintf(ch,"(%s)", duration);
            }
			cprintf(ch,"\n\r");
        }
    }

	cprintf(ch,"Special Properties:");
	if ( IS_SET(obj->extra_flags,ITEM_UNIQUE) )
		cprintf(ch," LORE"), fSpec = TRUE;

	if ( obj->deity > 0 )
		cprintf(ch," %s-only", deity_table[obj->deity].name), fSpec = TRUE;

	if ( !fSpec )
		cprintf(ch," none");

	cprintf(ch,"\n\r");

	cprintf(ch,"Condition:   %3d%%\n\r"
               "Durability:  %3d%%\n\r"
               "Quality:     %3d%%\n\r",
		obj->condition, obj->durability, obj->quality );

	if ( obj->crafter != NULL )
		cprintf(ch,"This object was crafted by %s.\n\r", obj->crafter );
    return;
}

void do_resist( Character *ch, char *argument )
{
    extern void show_resist( Character *ch, Character *showTo );

	if ( argument[0] == '\0' )
	{
		show_resist(ch,ch);
		return;
	}
	else
	if ( !str_cmp(argument,"pet") )
	{
		if ( ch->pet == NULL )
		{
			cprintf(ch,"You don't have a pet.\n\r");
			return;
		}
	
		show_resist( ch->pet, ch );
		return;
	}
	
	cprintf(ch,"Syntax:   resists [pet]\n\r");
	return;
}

void do_bestiary( Character *ch, char *argument )
{
	Character *victim;
	char arg[MAX_INPUT_LENGTH];
    extern void show_resist( Character *ch, Character *showTo );

	one_argument( argument, arg );

	if ( argument[0] == '\0' )
	{
		cprintf(ch,"Syntax:  bestiary <character>\n\r");
		return;
	}

	if ( (victim = get_char_room(ch,arg)) == NULL )
	{
		cprintf(ch,"You don't see that character here.\n\r");
		return;
	}

	if ( !HAS_PROF(ch,gpn_bestiary) )
	{
		cprintf(ch,"You don't have that ability.\n\r");
		return;
	}

	if ( !IS_NPC(victim) )
	{
		act("$N isn't an NPC.",ch,NULL,victim,TO_CHAR);
		return;
	}

    if ( ch->level > victim->level )
    cprintf(ch,"Level: %d\n\r", victim->level );
    cprintf(ch,"Race: %s\n\r", race_table[victim->race].name);
    cprintf(ch,"Size: %s\n\r", size_table[victim->size].name);
    if ( IS_SET( victim->form, FORM_POISON ) )
        cprintf(ch,"* This NPC is poisonous\n\r");
	show_resist(victim,ch);
	return;
}

void show_resist( Character *ch, Character *showTo )
{
    int i;

	if ( ch != showTo )
    	act(" * Resistances for $N",showTo,NULL,ch,TO_CHAR);
	else
		act(" * My Resistances:",ch,NULL,NULL,TO_CHAR);

	/*log_string("i goes to %d", IS_NPC(ch) ? MAX_RESIST : MAX_PC_RESISTS );*/

    for ( i = 0 ; i < (IS_NPC(ch) ? MAX_RESIST : MAX_PC_RESISTS) ; i++ )
	{
		if ( i % 3 == 0 ) 
			cprintf(showTo,"\n\r");

		if ( ch->resists[i].immune )
			cprintf(showTo,"%-10s &BImm&x (---)    ", capitalize(resist_flags[i].name) );
		else
        	cprintf(showTo,"%-10s &%c%3d&x (+%2d)    ",
				capitalize(resist_flags[i].name),
				ch->resists[i].mod == 0 ? 'x' : ( ch->resists[i].mod < 0 ? 'R' : 'G' ),
				ch->resists[i].value+ch->resists[i].mod,
	 			ch->resists[i].mod);
	}
	cprintf(showTo,"\n\r");
    return;
}

void do_expsplit( Character *ch, char *argument )
{
    if ( IS_NPC(ch) )
	{
		cprintf(ch,"You can't specialize.\n\r");
		return;
	}
	else
	if ( *argument == '\0' )
	{
		cprintf(ch,"Usage: expsplit <percent to go to spec exp>\n\r");
		return;
	}
	else
	if ( atoi(argument) > ch->level * 2 || atoi(argument) < 0 || atoi(argument) > 100 )
	{
		cprintf(ch,"Range is 0 to %d.\n\r", UMIN(ch->level * 2,100) );
		return;
	}

    ch->pcdata->split = atoi(argument);
 	cprintf(ch,"%d %% of your experience will go towards Specialization.\n\r",
		ch->pcdata->split);
	return;
}

void do_reuse( Character *ch, char *argument )
{
	Reuse_wait *r;
	SpellIndex* pSpellIndex;

	if ( IS_NPC(ch) )
	{
		cprintf(ch,"You're an NPC you don't have to wait.\n\r");
		return;
	}

	cprintf(ch,"You have the following skills/spells in a reuse delay:\n\r\n\r");

	for( r = ch->reuse_wait ; r ; r = r->next )
	{
		pSpellIndex = NULL;
		if(r->type == AFF_SPELL)
		{
			pSpellIndex = get_spell_index(r->gsn);
		}

		cprintf(ch,"%-10s %-22s %d seconds\n\r",
			r->type == AFF_SKILL ? ( skill_table[r->gsn].type == SKILL_FALSE ? "Command" : "Skill") : 
				(r->type == AFF_SPELL ? "Spell" : "Ability"),
			r->type == AFF_SKILL ? skill_table[r->gsn].name : 
				(r->type == AFF_SPELL ? ( pSpellIndex ? pSpellIndex->name : "(null)" ) : 
					prof_table[r->gsn].name),
			r->timer / PULSE_PER_SECOND );
	}

    // Combat timer
    if ( ch->pcdata->combat_timer > 0 )
        cprintf(ch,"Combat Timer: %d seconds\n\r", ch->pcdata->combat_timer * PULSE_REGEN / PULSE_PER_SECOND );

    // Stun timer
    if ( ch->stun_timer > current_time )
        cprintf(ch,"Stun Timer:   %d second%s\n\r", current_time - ch->stun_timer, current_time - ch->stun_timer == 1 ? "" : "s" );        

	return;
}

/*
	Syntax:		ask <npc> quests
				ask <npc> <specific quest>
				ask <npc> check <quest>
				ask <npc> complete <quest>
 */

Quest *findQuestOnNPC( Character *npc, char *argument )
{
	Quest *n;

	if ( npc->quests == NULL )
		return NULL;

	for( n = npc->quests ; n != NULL ; n = n->next )
		if ( !str_prefix( argument, n->keyword ) )
			return n;

	return NULL;
}

/* Prototypes */
bool checkQuestItems( Character *ch, Quest *q );
void do_askQuests( Character *ch, Character *npc );
bool do_checkQuest( Character *ch, Character *npc, Quest *q );
bool do_completeQuest( Character *ch, Character *npc, Quest *q );

void do_ask( Character *ch, char *argument )
{
	char npcName[MAX_INPUT_LENGTH];
	char arg1[MAX_INPUT_LENGTH];
	Character	*npc;
	Quest		*q;

	argument = one_argument( argument, npcName );
	
	if ( npcName[0] == '\0' || *argument == '\0' )
	{
		cprintf(ch,"ask <npc> quests\n\r"
                   "ask <npc> <quest_name\n\r"
                   "ask <npc> check <quest_name>\n\r"
                   "ask <npc> complete <quest_name>\n\r");
		return;
	}
	
	if ( (npc = get_char_room(ch,npcName)) == NULL )
	{
		cprintf(ch,"There's nobody like '%s' here.\n", npcName );
		return;
	}
	
	if ( !IS_NPC(npc) )
	{
		act("$N isn't an NPC.",ch,NULL,npc,TO_CHAR);
		return;
	}

	act("$n asks $N about a quest.",ch,NULL,npc,TO_NOTVICT);		
	
	/* check second command */
	argument = one_argument( argument, arg1 );
	
	if ( !str_prefix(arg1,"quests") )
	{
		do_askQuests(ch,npc);
		return;
	}
	else
	if ( !str_prefix(arg1,"check") )
	{
		Quest *q;
		
		if ( *argument == '\0' || (q = findQuestOnNPC(npc,argument)) == NULL )
		{
			act("$N doesn't know which quest you're checking on.",ch,NULL,npc,TO_CHAR);
			return;
		}
		
		if ( do_checkQuest(ch,npc,q)) /* check with silent mode off */
			act("$N nods in approval.",ch,NULL,npc,TO_CHAR);
		
		return;
	}
	else
	if( !str_prefix(arg1,"complete") || !str_prefix(arg1,"finish"))
	{
		Quest *q;
		
		if( *argument == '\0' || (q = findQuestOnNPC(npc,argument)) == NULL )
		{
			act("$N doesn't know which quest you're trying to complete.",ch,NULL,npc,TO_CHAR);
			return;
		}
		
		if ( !do_checkQuest(ch,npc,q) ) 
			return;		
		
		do_completeQuest(ch,npc,q);
		return;
	}
	
	/* ok they're asking about a specific quest */
	if ( (q = findQuestOnNPC( npc, arg1 )) == NULL )
	{
		act("$N doesn't respond.",ch,NULL,npc,TO_CHAR);
		return;
	}
	
	act("$n says '$t'.",npc,q->long_descr,NULL,TO_ROOM);
	act("You say '$t'.",npc,q->long_descr,NULL,TO_CHAR);
	return;
}

/* List all public quests */
void do_askQuests(Character *ch, Character *npc )
{
	Quest *q;

	char c;
    const char * ps;
    char pd[MAX_STRING_LENGTH];
	int length;
	int href_length;
    char buf[MAX_STRING_LENGTH];
	int dest_pos;

	if ( npc->quests == NULL )
	{
		act("$n doesn't appear to have anything to say.",npc,NULL,NULL,TO_ROOM);
		return;
	}
	
	for( q = npc->quests ; q != NULL ; q = q->next )	
    {
		if ( !IS_SET(q->flags,QUEST_PRIVATE) && qualifiesForQuest(ch,q) )
		{
			memset(pd,0,sizeof(pd));

			/* If using mxp make the keyword a hyperlink */
			length = strlen(q->short_descr);;
			dest_pos = 0;

			for(ps = q->short_descr; length > 0; ps++, length--)
			{
				c = *ps;

				if(c == '[')
				{
					char npcname[MAX_STRING_LENGTH];
				    one_argument(npc->name, npcname);
	
					sprintf(buf, "\x03send href=\"ask %s %s\"\x04[",npcname, q->keyword);
					href_length = strlen(buf); 
					memcpy(pd + dest_pos, buf, href_length); 
					dest_pos += href_length;
				}
				else if(c == ']')
				{
					sprintf(buf,"]\x03/send\x04");
					href_length = strlen(buf);
					memcpy(pd + dest_pos, buf, href_length);
					dest_pos += href_length;
				}
				else
				{
					memcpy(pd + dest_pos, &c, 1);
					dest_pos++;
				}
			}
			
			act("$n says '$t'", npc, pd,NULL,TO_ROOM);
		}
    }
			
	return;
}

void extractQuestItems( Character *ch, Quest *q )
{
    bool checkList[MAX_INGREDIENT];
    int i;
    Object *pObj, *pNext;

    /* initialize data */
    for ( i=0 ; i<MAX_INGREDIENT ; i++ )
    {
        checkList[i] = 0;
        if ( q->required[i] <= 0 )
            checkList[i] = TRUE;
    }

    for ( pObj = ch->carrying ; pObj != NULL ; pObj = pNext )
    {
		pNext = pObj->next_content;
        for ( i =0 ; i < MAX_INGREDIENT ; i++ )
        {
            if ( q->required[i] == pObj->pIndexData->vnum &&
                 checkList[i] == FALSE )
				/*&& IS_SET(pObj->extra_flags,ITEM_RESERVED_QUEST) )*/
            {
				/* This item is for the quest */
				obj_from_char( pObj );
				extract_obj( pObj );
				checkList[i] = TRUE;
                break;
            }
        }
    }
    return;
}

bool checkQuestItems( Character *ch, Quest *q )
{
    bool checkList[MAX_INGREDIENT];
    int i;
    Object *pObj;

    /* initialize data */
    for ( i=0 ; i<MAX_INGREDIENT ; i++ )
    {
        checkList[i] = 0;
        if ( q->required[i] <= 0 )
            checkList[i] = TRUE;
    }

    for ( pObj = ch->carrying ; pObj != NULL ; pObj = pObj->next_content )
    {
        bool found;

        found = FALSE;
        for ( i =0 ; i < MAX_INGREDIENT ; i++ )
        {
            if ( q->required[i] == pObj->pIndexData->vnum &&
                 checkList[i] == FALSE )
				/*&& IS_SET(pObj->extra_flags,ITEM_RESERVED_QUEST) )*/
            {
                checkList[i] = found = TRUE;
                break;
            }
        }
    }

    for ( i=0 ; i<MAX_INGREDIENT ; i++ )
        if ( !checkList[i] )
            return FALSE;

    return TRUE;
}

bool qualifiesForQuest( Character *ch, Quest *q )
{
    int i;

    if( IS_IMMORTAL(ch) )
        return TRUE;

	/* Verify that the character meets requirements */
	if ( ch->level > q->max_level && !IS_SET(q->flags,QUEST_ONE_TIMER) )
		return FALSE;
	
	if ( ch->level < q->min_level )
		return FALSE;
	
	if ( !q->class_avail[ch->class] )
		return FALSE;
	
	if ( !q->race_avail[ch->race] )
		return FALSE;
	
	if ( !q->deity_avail[ch->deity] )
		return FALSE;

	if ( doneQuest(ch,q) && IS_SET(q->flags,QUEST_ONE_TIMER) )
		return FALSE;

    // Check faction
    for( i = 0 ; i < MAX_QUEST_FACTION ; i++ )
        if ( q->faction_avail[i].faction != NULL )
            if ( !checkFaction( ch, q->faction_avail[i].faction, q->faction_avail[i].amount ) )
                return FALSE;

	return TRUE;
}

bool do_checkQuest(Character *ch, Character *npc, Quest *q )
{
	int i;

	/* Verify that the character meets requirements */
	/* You can only do a repeatable quest once if you're over level. */
	if ( ch->level > q->max_level )
	{
		if ( !IS_SET(q->flags,QUEST_ONE_TIMER) && doneQuest(ch,q) )
		{
			cprintf(ch,"Your level is too high.\n\r");
			return FALSE;
		}
	}
	
	if ( ch->level < q->min_level )
	{
		 cprintf(ch,"Your level is too low.\n\r");
		return FALSE;
	}
	
	if ( !q->class_avail[ch->class] )
	{
		 cprintf(ch,"This quest is class-specific.\n\r");
		return FALSE;
	}
	
	if ( !q->race_avail[ch->race] )
	{
		 cprintf(ch,"This quest is race-specific.\n\r");	
		return FALSE;
	}
	
	if ( !q->deity_avail[ch->deity] )
	{
		 cprintf(ch,"This quest is deity-specific.\n\r");
		return FALSE;
	}

	if ( doneQuest(ch,q) && IS_SET(q->flags,QUEST_ONE_TIMER) )
	{
		 cprintf(ch,"This quest can only be completed once.\n\r");
		return FALSE;
	}

	if ( !checkQuestItems(ch,q) )
	{
		 cprintf(ch,"You are missing at least one item required to complete the quest.\n\r");
		return FALSE;
	}

	for( i = 0 ; i < MAX_QUEST_FACTION ; i++ )
	{
		if ( q->faction_avail[i].faction != NULL )
		{
			if ( !checkFaction( ch, q->faction_avail[i].faction, q->faction_avail[i].amount ) )
			{
				cprintf(ch,"Your faction standing with %s is too low.\n\r", q->faction_avail[i].faction );
				return FALSE;
			}
		}
	}
	return TRUE;
}

bool do_completeQuest( Character *ch, Character *npc, Quest *q )
{
	int i;

	if ( !do_checkQuest(ch,npc,q) )
		return FALSE;

	cprintf(ch," &Y*** You have completed a quest: %s ***&x\n\r", q->name );

	/* Quest rewards */
	if ( get_obj_index( q->reward_vnum ) != NULL )
	{
		Object *o;

		o = create_object( get_obj_index( q->reward_vnum ) );
		obj_to_char( o, ch );
		act("You receive $p!", ch, o, NULL, TO_CHAR );
	}

	for( i = 0 ; i < MAX_CURRENCY ; i++ )
	{
		if ( q->reward_coins[i] > 0 )
		{
			ch->coins[i] += q->reward_coins[i];
			cprintf(ch,"You receive %d %s coin%s!\n\r", q->reward_coins[i], currency_table[i].name, q->reward_coins[i] == 1 ? "" : "s" );
		}
	}

	if ( q->reward_experience > 0 )
	{
		cprintf(ch,"You gain %d experience points!\n\r", q->reward_experience );
		gain_exp(ch, q->reward_experience, TRUE );
	}

	for( i=0 ; i < MAX_QUEST_FACTION ; i++ )
		if ( q->faction_hits[i].faction != NULL )
			applyFaction(ch,q->faction_hits[i].faction,q->faction_hits[i].amount);

	act(q->goodbye,npc,NULL,ch,TO_VICT);
	if ( IS_SET(q->flags,QUEST_YANK_MOB))
		extract_char( npc, TRUE );

	extractQuestItems( ch, q );
	if ( !doneQuest( ch, q ) )
		questToJournal( q, ch->pcdata->journal );
	return TRUE;
}
	
/* Last Login Stuff */
struct last_login	lastLoginTable[LOGIN_HISTORY];
int					lastLoginIndex = 0;

void initLastLogin( void )
{
	memset(lastLoginTable,0,sizeof(lastLoginTable));
	lastLoginIndex=0;
	return;
}

void addToLastLogin( Character *ch )
{
	int i;

	/* We record the last few people who CONNECTED, not the last 10 who
	 * logged off. 
	 */
	if ( IS_NPC(ch) || ch->desc == NULL )
		return;

	strcpy( lastLoginTable[lastLoginIndex].name, ch->name );
	lastLoginTable[lastLoginIndex].level = ch->level;
	lastLoginTable[lastLoginIndex].login = current_time;
	lastLoginTable[lastLoginIndex].logout = 0;
	strcpy( lastLoginTable[lastLoginIndex].host, ch->desc->host );

	/* go through and remove any old ones */
	for( i = 0 ; i < LOGIN_HISTORY ; i++ )
		if( !strcasecmp(lastLoginTable[i].name,ch->name) && i != lastLoginIndex && lastLoginTable[i].logout <= 0 )
			lastLoginTable[i].logout = current_time;

	if ( ++lastLoginIndex >= LOGIN_HISTORY )
		lastLoginIndex = 0;
}

void updateLastLogin( Character *ch )
{
	int i;

	if( IS_NPC(ch) )
		return;

	for( i = 0 ; i < LOGIN_HISTORY ; i++ )
		if ( !str_cmp(ch->name,lastLoginTable[i].name) && lastLoginTable[i].logout <= 0 )
		{
			lastLoginTable[i].logout = current_time;
			break;
		}

	return;
}

void do_lastlogin( Character *ch, char *argumenet )
{
	extern void showLastLoginRange( Character *ch, int low, int high );

	cprintf(ch," == Recent Logins ==\n\r");

	/* have to do two lists */
	showLastLoginRange( ch, lastLoginIndex, LOGIN_HISTORY );
	showLastLoginRange( ch, 0, lastLoginIndex );
	return;
}

void showLastLoginRange( Character *ch, int low, int high )
{
	int i;

	for( i = low ; i < high ; i++ )
	{
		if ( lastLoginTable[i].name[0] == 0 )
			continue;

		/* Morts can't see IMMs */
		if ( !IS_IMMORTAL(ch) && lastLoginTable[i].level >= LEVEL_IMMORTAL )
			continue;

		/* IMMs can't see higher level IMMS */
		if ( IS_IMMORTAL(ch) && lastLoginTable[i].level > ch->level )
			continue;

		cprintf(ch,"%-12s %s ",
			lastLoginTable[i].name,
 			format_date( lastLoginTable[i].login, "%b %d %H:%M" ) );
		cprintf(ch,"- %-5s %s\n\r",
			lastLoginTable[i].logout == 0 ? "?" : 
				format_date( lastLoginTable[i].logout, "%H:%M" ),
			IS_SET(ch->wiznet,WIZ_SITES) ? lastLoginTable[i].host : "" );
	}
	return;
}

void do_sum( Character *ch, char *argument )
{
	int num1, num2;
	char arg[MAX_INPUT_LENGTH];
	int total=0, i;
 
	argument = one_argument( argument, arg );
 
	if ( arg[0] == '\0' || *argument == '\0' )
	{
		cprintf(ch,"Usage:   sum <low#> <high#>\n\r");
		return;
	}

	num1 = atoi(arg);
	num2 = atoi(argument);
	if ( num1 < 0 || num2 < 0 || num1 > 100 || num2 > 100 || num1 >= num2 )
	{
		cprintf(ch,"Valid range is 0-100.  Second number must be higher than first.\n\r");
		return;
	}
 
	for( i = num1 ; i <= num2 ; i++ )
		total += i;
 
	cprintf(ch,"The sum of the numbers from %d to %d inclusive is: %d.\n\r", num1, num2, total );
	return;
} 

void do_timezone( Character *ch, char *argument )
{
    int i;
    char arg[MAX_STRING_LENGTH];

    if ( IS_NPC(ch) )
    {
        cprintf(ch,"NPCs don't live in real world time zones.\n\r");
        return;
    }

    argument = one_argument( argument, arg );
    if ( arg[0] == '\0' )
    {
        cprintf(ch,"Syntax:    timezone <list|set|clear> [tz#]\n\r");
        if ( ch->pcdata->tzindex < 0 )
            cprintf(ch,"You have not set your timezone yet.\n\r");
        else
            cprintf(ch,"Your timezone is set to: %s\n\r",
                tzTable[ch->pcdata->tzindex].zone_description );
        return;
    }

    if ( !str_cmp(arg,"clear") )
    {
        ch->pcdata->tzindex = -1;
        cprintf(ch,"Timezone setting cleared.\n\r");
        return;
    }
    else
    if ( !str_cmp(arg,"list") )
    {
        Buffer *buf;

        buf = new_buf();
        for( i=0 ; i<300 ; i++ )
            if ( tzTable[i].zone_description == NULL )
                break;
            else
                bprintf(buf,"[#%3d] %s\n\r", i, tzTable[i].zone_description);

        page_to_char( buf_string( buf ), ch );
        free_buf(buf);
    }
    else
    if ( !str_cmp(arg,"set") )
    {
        if ( argument[0] == '\0' || !is_number(argument) 
          || atoi(argument)<0 || atoi(argument)>top_timezone )
        {
            do_timezone(ch,"");
            return;
        }

        ch->pcdata->tzindex = atoi(argument);
        cprintf(ch,"Timezone set to %s.\n\r", tzTable[ch->pcdata->tzindex].zone_description);
        return;
    }
    else
        do_timezone(ch,"");
        
}

void checkRoomForQuests( Character *ch )
{
    Character *fch;

    /* Check for quests */
    for ( fch = ch->in_room->people ; fch != NULL ; fch = fch->next_in_room )
    {
        Quest *q;

        for( q = fch->quests ; q != NULL ; q = q->next )
        {
            if ( qualifiesForQuest(ch,q) && !IS_SET(q->flags,QUEST_PRIVATE) )
                act(q->hint,fch,NULL,ch,TO_VICT);
        }
    }
}

void do_email( Character *ch, char *argument )
{
    if ( argument[0] == '\0' )
    {
        cprintf(ch,"Syntax:  email <address>\n\r");
        if ( ch->pcdata->email == NULL || ch->pcdata->email[0] == '\0' )
            cprintf(ch,"Currently set to: none\n\r");
        else
            cprintf(ch,"Currently set to: %s\n\r", ch->pcdata->email );
        return;
    }

    if ( ch->pcdata->email == NULL || ch->pcdata->email[0] == '\0' )
        free_string( ch->pcdata->email );

    ch->pcdata->email = str_dup( argument );
    cprintf(ch,"Your email address is set to %s.\n\r",ch->pcdata->email);
    return;
}

        
