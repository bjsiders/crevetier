#ifndef area_h
#define area_h

/*
 * Area flags.
 */
#define AREA_NONE           0
#define AREA_CHANGED        1    /* Area has been modified. */
#define AREA_ADDED          2    /* Area has been added to. */
#define AREA_LOADING        4    /* Used for counting in db.c */
#define AREA_GENERATED      8    // random wilderness
#define AREA_NOASAVE        16    // clan halls - don't overwrite on OLC

/* New area_data for OLC */
struct area_data
{
    Area *              next;
    char *              name;
    char *              credits;
    int                 age;
    int                 nplayer;
    bool                empty;
    bool                shown;
    char *              filename;
    char *              builders;
    int                 security;
    int                 lvnum;
    int                 uvnum;
    int                 vnum;
    int                 area_flags;
    int                 llevel;
    int                 ulevel;
    int                 exp_mod;
    bool                hide_area;
    ExtraDescr *  echoes;
};

#endif /* area_h */
