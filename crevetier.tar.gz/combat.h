#ifndef combat_h
#define combat_h

#define MAX_WEAPONS         100
#define MAX_DAMAGE_MESSAGE  61

/*
    Hit locations
 */
struct hitloc
{
    int hitloc;
    int chance;
};

struct attack_type
{
    char *    name;            /* name */
    char *    noun1st;
    char *    noun;            /* message */
    int       damage;            /* damage class */
};

/*
 * A kill structure (indexed by level).
 */
struct    kill_data
{
    sh_int        number;
    sh_int        killed;
};

/*
 * For firing
 */

struct firing_data
{
    Firing *        next;
    bool            valid;
    Character *     victim;
    int             direction;
    int             range;
    Object *        ammo;
};

/* damage classes */
#define DAM_NONE                0
#define DAM_BASH                1
#define DAM_PIERCE              2
#define DAM_SLASH               3
#define DAM_FIRE                4
#define DAM_COLD                5
#define DAM_LIGHTNING           6
#define DAM_ACID                7
#define DAM_POISON              8
#define DAM_EARTH               9
#define DAM_AIR                 10
#define DAM_MENTAL              11
#define DAM_DISEASE             12
#define DAM_WATER               13
#define DAM_LIGHT               14
#define DAM_SOUND               15
#define DAM_SPIRIT              16
#define DAM_DARK                17
#define DAM_BODY                18
#define DAM_OTHER               19

/* AC types */
#define AC_PIERCE            0
#define AC_BASH              1
#define AC_SLASH             2
#define AC_EXOTIC            3

/*
    Damage Flags
 */
#define DF_SHOW         (A)
#define DF_DUAL         (B)
#define DF_CRIT         (C)
#define DF_SPELL        (D)
#define DF_DOT          (E)
#define DF_RANGED       (F)
#define DF_NOTIMERS     (G)
#define DF_TURNABLE     (H) // bladeturns can absorb it
#define DF_BASEHITS     (I) // damage goes 100% to base hits

/*
 * Combat flags
 */
#define CF_MY_HITS                  (A)   // show when i land a hit
#define CF_MY_MISSES                (B)   // show when i miss
#define CF_MY_AVOIDED               (C)   // show when i parry/dodge/block
#define CF_GET_HIT                  (D)   // show when i get hit
#define CF_GET_MISSED               (E)   // show when i am missed
#define CF_GET_AVOIDED              (F)   // show when somebody parry/dodge/blocks me
#define CF_OTH_HIT                  (G)   // show when a 3rd party is hit
#define CF_OTH_MISS                 (H)   // show when a 3rd party is missed
#define CF_OTH_AVOIDED              (I)   // show when a 3rd party avoids

/*
 * Types of attacks.
 * Must be non-overlapping with spell/skill types,
 * but may be arbitrary beyond that.
 */
#define TYPE_DAMAGE_SHIELD          -3
#define TYPE_DOT                    -2
#define TYPE_UNDEFINED              -1
#define TYPE_DOUBLE_STRIKE          -4
#define TYPE_HIT                    1000

extern const struct hitloc          hitloc_table[];
extern const struct attack_type     attack_table[];
extern KillInfo                     kill_table[];


#endif /* combat_h */
