/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#if defined(macintosh)
#include <types.h>
#include <time.h>
#else
#include <sys/types.h>
#include <sys/time.h>
#endif
#include <stdio.h>
#include <string.h>
#include "thoc.h"
#include "interp.h"
#include "lookup.h"
#include "tables.h"
#include "options.h"

char *	const	dir_name	[]		=
{
    "north", "east", "south", "west", "up", "down"
};

char	* const	extended_dir_name[]	=
{
	"the north", "the east", "the south", "the west", "above", "below"
};

char	* const scan_dir_name[] =
{
	"to the north of", "to the east of", "to the south of", "to the west of", "above", "below"
};

const	sh_int	rev_dir		[]		=
{
    2, 3, 0, 1, 5, 4
};

const	sh_int	movement_loss	[SECT_MAX]	=
{
    1, 2, 2, 3, 4, 6, 4, 1, 6, 10, 6
};



/*
 * Local functions.
 */
int	find_door	( Character *ch, char *arg );
bool	has_key	( Character *ch, int key );
void report_train_bonuses(Character *ch, int stat);


int move_char(  Character *ch, int door, bool follow )
{
    return move_char_flagged(ch,door,follow,0);
}

int move_char_flagged( Character *ch, int door, bool follow, long move_flags )
{
    Character *fch;
    Character *fch_next;
    Room *in_room;
    Room *to_room;
    Exit *pexit;

    if ( door < 0 || door > 5 )
    {
	log_bug( "Do_move: bad door %d.", door );
	return FALSE;
    }

	/* check for a root */
	if ( find_affect_type(ch,APPLY_ROOT) != NULL )
	{
		cprintf(ch,"You are rooted in place and cannot move!\n\r");
		return FALSE;
	}

    if ( IS_AFFECTED(ch,AFF_MESMERIZE) )
    {
        cprintf(ch,"You are mesmerized and cannot move!\n\r");
        return FALSE;
    }

    in_room = ch->in_room;
    if ( ( pexit   = in_room->exit[door] ) == NULL
    ||   ( to_room = pexit->u1.to_room   ) == NULL 
    ||	 !can_see_room(ch,pexit->u1.to_room))
    {
	send_to_char( "Alas, you cannot go that way.\n\r", ch );
	return FALSE;
    }

    if (IS_SET(pexit->exit_info, EX_CLOSED)
    &&  (!IS_AFFECTED(ch, AFF_PASS_DOOR) || IS_SET(pexit->exit_info,EX_NOPASS))
    &&   !IS_IMMORTAL(ch))
    {
	    act( "The $d is closed.", ch, NULL,  exitName(pexit), TO_CHAR );
	    return FALSE;
    }

    // Check climb first - if climb bit is set, we ignore fall bits
    if ( IS_SET(pexit->exit_info, EX_CLIMB) && !IS_AFFECTED(ch,AFF_FLYING) &&
        !IS_IMMORTAL(ch) && !IS_SET(move_flags,MOVE_CLIMB))
    {
        act("It's steep, you'll have to climb it.", ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }
    else
    if ( IS_SET(pexit->exit_info, EX_FALL) && !IS_AFFECTED(ch,AFF_FLYING) &&
         !IS_IMMORTAL(ch) && !IS_SET(move_flags,MOVE_JUMP))
    {
        act( "It's a long fall, you'll have to jump down.", ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( IS_AFFECTED(ch, AFF_CHARM)
    &&   ch->master != NULL
    &&   in_room == ch->master->in_room )
    {
	send_to_char( "What?  And leave your beloved master?\n\r", ch );
	return FALSE;
    }

    if ( !is_room_owner(ch,to_room) && room_is_private( to_room ) )
    {
	send_to_char( "That room is private right now.\n\r", ch );
	return FALSE;
    }

    if ( !IS_NPC(ch) )
    {
		int move;

		if ( in_room->sector_type == SECT_AIR
		||   to_room->sector_type == SECT_AIR )
		{
	    	if ( !IS_AFFECTED(ch, AFF_FLYING) && !IS_IMMORTAL(ch))
	    	{
				send_to_char( "You can't fly.\n\r", ch );
				return FALSE;
	    	}
		}
        else
        if ( to_room->sector_type == SECT_MAGMA )
        {
            if ( !IS_AFFECTED(ch,AFF_FLYING) && !IS_IMMORTAL(ch) && 
                  in_room->sector_type != SECT_MAGMA )
            {
                cprintf(ch,"You must be levitating to enter a magma flow.\n\r");
                return FALSE;
            }
        }
        else
		if (( in_room->sector_type == SECT_WATER_NOSWIM
		||    to_room->sector_type == SECT_WATER_NOSWIM )
  		&&    !IS_AFFECTED(ch,AFF_FLYING))
		{
	    	Object *obj;
	    	bool found;

	    	/*
	     	* Look for a boat.
	     	*/
	    	found = FALSE;

	    	if (IS_IMMORTAL(ch))
				found = TRUE;

	    	for ( obj = ch->carrying; obj != NULL; obj = obj->next_content )
	    	{
				if ( obj->item_type == ITEM_BOAT )
				{
		    		found = TRUE;
		    		break;
				}
	    	}
	    	if ( !found )
	    	{
				send_to_char( "You need a boat to go there.\n\r", ch );
				return FALSE;
	    	}
		}

		move = movement_loss[UMIN(SECT_MAX-1, in_room->sector_type)]
	     	+ movement_loss[UMIN(SECT_MAX-1, to_room->sector_type)]
	     ;

        move /= 2;  /* i.e. the average */


		/* conditional effects */
		if (IS_AFFECTED(ch,AFF_FLYING) || IS_AFFECTED(ch,AFF_HASTE))
	    	move /= 2;

		if ( !IS_NPC(ch) && ch->pcdata->subrace == gsn_abrainon )
			move = 1;

		if (IS_AFFECTED(ch,AFF_SLOW))
	    	move *= 2;

		if ( ch->move < move )
		{
	    	send_to_char( "You are too exhausted.\n\r", ch );
	    	return FALSE;
		}

		{
			int wait = PULSE_PER_SECOND / 5;

			if ( IS_AFFECTED(ch,AFF_SNEAK) )
				wait = PULSE_PER_SECOND;

			/* Look for a snare */
			wait += find_snare( ch );

			WAIT_STATE( ch, wait );
			ch->move -= move;
    	}
	}

    for ( fch=ch->in_room->people ; fch != NULL ; fch=fch->next_in_room )
    {
		if ( IS_AFFECTED(ch,AFF_SNEAK) && IS_IMMORTAL(fch) )
	    	act("$n sneaks $t.",ch,dir_name[door],fch,TO_VICT);
		else
		if ( !IS_AFFECTED(ch,AFF_SNEAK) && ch->invis_level < LEVEL_HERO)
	    	actprintf(ch,dir_name[door],fch,TO_VICT,"$n %s $t.",
                IS_SET(move_flags,MOVE_CLIMB) ? "climbs" :
                IS_SET(move_flags,MOVE_JUMP) ? "jumps" : "leaves");
    }

	addTrackingData( ch, ch->in_room, door, T_DEPART );
	char_from_room( ch );
    char_to_room( ch, to_room );
	addTrackingData( ch, to_room, rev_dir[door], T_ARRIVE );

	/*check_reveal( ch );*/
    for ( fch=ch->in_room->people ; fch != NULL ; fch=fch->next_in_room )
    {
        if ( IS_AFFECTED(ch,AFF_SNEAK) && IS_IMMORTAL(fch) )
            act("$n sneaks in.",ch,dir_name[door],fch,TO_VICT);
        else
        if ( !IS_AFFECTED(ch,AFF_SNEAK) && ch->invis_level < LEVEL_HERO)
            actprintf(ch,dir_name[door],fch,TO_VICT,"$n %s.",
                IS_SET(move_flags,MOVE_JUMP) ? "falls in!" : "has arrived");
    }

    do_function(ch, &do_look, "auto" );
	check_reveal( ch );

    if ( is_affected(ch,vnum_treeform,AFF_SPELL) )
    {
		affect_strip(ch,vnum_treeform);
		act("&GYour treeform wavers and collapses&x.",ch,NULL,NULL,TO_CHAR);
    }

	/* Check for quests */
	for ( fch = to_room->people ; fch != NULL ; fch = fch->next_in_room )
	{
		Quest *q;

		for( q = fch->quests ; q != NULL ; q = q->next )
		{
			if ( qualifiesForQuest(ch,q) && !IS_SET(q->flags,QUEST_PRIVATE) )
				act(q->hint,fch,NULL,ch,TO_VICT);
		}
	}

    if (in_room == to_room) /* no circular follows */
		return TRUE;

    for ( fch = in_room->people; fch != NULL; fch = fch_next )
    {
		fch_next = fch->next_in_room;

	if ( fch->master == ch && IS_AFFECTED(fch,AFF_CHARM) 
	&&   fch->position < POS_STANDING)
	    do_function(fch, &do_stand, "");

	if ( fch->master == ch && fch->position == POS_STANDING 
	&&   can_see_room(fch,to_room))
	{

	    if (IS_SET(ch->in_room->room_flags,ROOM_LAW)
	    &&  (IS_NPC(fch) && IS_SET(fch->act,ACT_AGGRESSIVE)))
	    {
		act("You can't bring $N into the city.",
		    ch,NULL,fch,TO_CHAR);
		act("You aren't allowed in the city.",
		    fch,NULL,NULL,TO_CHAR);
		continue;
	    }

	    act( "You follow $N.", fch, NULL, ch, TO_CHAR );
	    move_char( fch, door, TRUE );
	}
    }

    return TRUE;
}



void do_north( Character *ch, char *argument )
{
    move_char( ch, DIR_NORTH, FALSE );
    return;
}



void do_east( Character *ch, char *argument )
{
    move_char( ch, DIR_EAST, FALSE );
    return;
}



void do_south( Character *ch, char *argument )
{
    move_char( ch, DIR_SOUTH, FALSE );
    return;
}



void do_west( Character *ch, char *argument )
{
    move_char( ch, DIR_WEST, FALSE );
    return;
}



void do_up( Character *ch, char *argument )
{
    move_char( ch, DIR_UP, FALSE );
    return;
}



void do_down( Character *ch, char *argument )
{
    move_char( ch, DIR_DOWN, FALSE );
    return;
}



int find_door( Character *ch, char *arg )
{
    Exit *pexit;
    int door;

	 if ( !str_cmp( arg, "n" ) || !str_cmp( arg, "north" ) ) door = 0;
    else if ( !str_cmp( arg, "e" ) || !str_cmp( arg, "east"  ) ) door = 1;
    else if ( !str_cmp( arg, "s" ) || !str_cmp( arg, "south" ) ) door = 2;
    else if ( !str_cmp( arg, "w" ) || !str_cmp( arg, "west"  ) ) door = 3;
    else if ( !str_cmp( arg, "u" ) || !str_cmp( arg, "up"    ) ) door = 4;
    else if ( !str_cmp( arg, "d" ) || !str_cmp( arg, "down"  ) ) door = 5;
    else
    {
	for ( door = 0; door <= 5; door++ )
	{
	    if ( ( pexit = ch->in_room->exit[door] ) != NULL
	    &&   IS_SET(pexit->exit_info, EX_ISDOOR)
	    &&   pexit->keyword != NULL
	    &&   is_name( arg, pexit->keyword ) )
		return door;
	}
	act( "I see no $T here.", ch, NULL, arg, TO_CHAR );
	return -1;
    }

    if ( ( pexit = ch->in_room->exit[door] ) == NULL )
    {
	act( "I see no door $T here.", ch, NULL, arg, TO_CHAR );
	return -1;
    }

    if ( !IS_SET(pexit->exit_info, EX_ISDOOR) )
    {
	send_to_char( "You can't do that.\n\r", ch );
	return -1;
    }

    return door;
}



void do_open( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Object *obj;
    int door;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Open what?\n\r", ch );
	return;
    }

	/* Look for a cardinal direction and skip straigh to doors */
	if ( !str_cmp(arg,"north") || !str_cmp(arg,"south") || !str_cmp(arg,"east") ||
		 !str_cmp(arg,"west") || !str_cmp(arg,"up") || !str_cmp(arg,"down") )
		goto cardinal_direction;

	/* Check if there's a container */
    if ( ( obj = get_obj_here( ch, arg ) ) != NULL )
    {
 		/* open portal */
		if (obj->item_type == ITEM_PORTAL)
		{
	    	if (!IS_SET(obj->value[1], EX_ISDOOR))
	    	{
				send_to_char("You can't do that.\n\r",ch);
				return;
	    	}

	    	if (!IS_SET(obj->value[1], EX_CLOSED))
	    	{
				send_to_char("It's already open.\n\r",ch);
				return;
	    	}

	    	if (IS_SET(obj->value[1], EX_LOCKED))
	    	{
				send_to_char("It's locked.\n\r",ch);
				return;
	    	}

	    	REMOVE_BIT(obj->value[1], EX_CLOSED);
	    	act("You open $p.",ch,obj,NULL,TO_CHAR);
	    	act("$n opens $p.",ch,obj,NULL,TO_ROOM);
	    	return;
 		}

		/* 'open object' */
		if ( obj->item_type != ITEM_CONTAINER)
	    {
			send_to_char( "That's not a container.\n\r", ch ); 
			return; 
		}

		if ( !IS_SET(obj->value[1], CONT_CLOSED) )
	    {
			send_to_char( "It's already open.\n\r",      ch );
			return;
		}

		if ( !IS_SET(obj->value[1], CONT_CLOSEABLE) )
	    {
			send_to_char( "You can't do that.\n\r",      ch );
			return; 
		}

		if ( IS_SET(obj->value[1], CONT_LOCKED) )
	    { 
			send_to_char( "It's locked.\n\r",            ch ); 
			return;
		}

		REMOVE_BIT(obj->value[1], CONT_CLOSED);
		act("You open $p.",ch,obj,NULL,TO_CHAR);
		act( "$n opens $p.", ch, obj, NULL, TO_ROOM );
		return;
    }

cardinal_direction:
    if ( ( door = find_door( ch, arg ) ) >= 0 )
    {
		/* 'open door' */
		Room *to_room;
		Exit *pexit;
		Exit *pexit_rev;

		pexit = ch->in_room->exit[door];
		if ( !IS_SET(pexit->exit_info, EX_CLOSED) )
	    { send_to_char( "It's already open.\n\r",      ch ); return; }
		if (  IS_SET(pexit->exit_info, EX_LOCKED) )
	    { send_to_char( "It's locked.\n\r",            ch ); return; }
		if ( IS_SET(pexit->exit_info, EX_HOLD_PORTAL) )
	    { send_to_char( "Something is holding it closed.\n\r", ch ); return; }

		REMOVE_BIT(pexit->exit_info, EX_CLOSED);
		act( "$n opens the $d.", ch, NULL, exitName(pexit), TO_ROOM );
		send_to_char( "Ok.\n\r", ch );
		SET_BIT(pexit->spawn->flags,SPAWN_READY);

		/* open the other side */
		if ( ( to_room   = pexit->u1.to_room            ) != NULL
		&&   ( pexit_rev = to_room->exit[rev_dir[door]] ) != NULL
		&&   pexit_rev->u1.to_room == ch->in_room )
	{
	    Character *rch;

	    REMOVE_BIT( pexit_rev->exit_info, EX_CLOSED );
		SET_BIT(pexit_rev->spawn->flags,SPAWN_READY);
	    for ( rch = to_room->people; rch != NULL; rch = rch->next_in_room )
		act( "The $d opens.", rch, NULL, exitName(pexit_rev), TO_CHAR );
	}
    }

    return;
}



void do_close( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Object *obj;
    int door;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Close what?\n\r", ch );
	return;
    }

    if ( ( obj = get_obj_here( ch, arg ) ) != NULL )
    {
	/* portal stuff */
	if (obj->item_type == ITEM_PORTAL)
	{

	    if (!IS_SET(obj->value[1],EX_ISDOOR)
	    ||   IS_SET(obj->value[1],EX_NOCLOSE))
	    {
		send_to_char("You can't do that.\n\r",ch);
		return;
	    }

	    if (IS_SET(obj->value[1],EX_CLOSED))
	    {
		send_to_char("It's already closed.\n\r",ch);
		return;
	    }

	    SET_BIT(obj->value[1],EX_CLOSED);
	    act("You close $p.",ch,obj,NULL,TO_CHAR);
	    act("$n closes $p.",ch,obj,NULL,TO_ROOM);
	    return;
	}

	/* 'close object' */
	if ( obj->item_type != ITEM_CONTAINER )
	    { send_to_char( "That's not a container.\n\r", ch ); return; }
	if ( IS_SET(obj->value[1], CONT_CLOSED) )
	    { send_to_char( "It's already closed.\n\r",    ch ); return; }
	if ( !IS_SET(obj->value[1], CONT_CLOSEABLE) )
	    { send_to_char( "You can't do that.\n\r",      ch ); return; }

	SET_BIT(obj->value[1], CONT_CLOSED);
	act("You close $p.",ch,obj,NULL,TO_CHAR);
	act( "$n closes $p.", ch, obj, NULL, TO_ROOM );
	return;
    }

    if ( ( door = find_door( ch, arg ) ) >= 0 )
    {
	/* 'close door' */
	Room *to_room;
	Exit *pexit;
	Exit *pexit_rev;

	pexit	= ch->in_room->exit[door];
	if ( IS_SET(pexit->exit_info, EX_CLOSED) )
	    { send_to_char( "It's already closed.\n\r",    ch ); return; }

	SET_BIT(pexit->exit_info, EX_CLOSED);
	act( "$n closes the $d.", ch, NULL, exitName(pexit), TO_ROOM );
	send_to_char( "Ok.\n\r", ch );

	/* close the other side */
	if ( ( to_room   = pexit->u1.to_room            ) != NULL
	&&   ( pexit_rev = to_room->exit[rev_dir[door]] ) != 0
	&&   pexit_rev->u1.to_room == ch->in_room )
	{
	    Character *rch;

	    SET_BIT( pexit_rev->exit_info, EX_CLOSED );
	    for ( rch = to_room->people; rch != NULL; rch = rch->next_in_room )
		act( "The $d closes.", rch, NULL, exitName(pexit_rev), TO_CHAR );
	}
    }

    return;
}



bool has_key( Character *ch, int key )
{
    Object *obj;

    for ( obj = ch->carrying; obj != NULL; obj = obj->next_content )
    {
	if ( obj->pIndexData->vnum == key )
	    return TRUE;
    }

    return FALSE;
}



void do_lock( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Object *obj;
    int door;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Lock what?\n\r", ch );
	return;
    }

    if ( ( obj = get_obj_here( ch, arg ) ) != NULL )
    {
	/* portal stuff */
	if (obj->item_type == ITEM_PORTAL)
	{
	    if (!IS_SET(obj->value[1],EX_ISDOOR)
	    ||  IS_SET(obj->value[1],EX_NOCLOSE))
	    {
		send_to_char("You can't do that.\n\r",ch);
		return;
	    }
	    if (!IS_SET(obj->value[1],EX_CLOSED))
	    {
		send_to_char("It's not closed.\n\r",ch);
	 	return;
	    }

	    if (obj->value[4] < 0 || IS_SET(obj->value[1],EX_NOLOCK))
	    {
		send_to_char("It can't be locked.\n\r",ch);
		return;
	    }

	    if (!has_key(ch,obj->value[4]))
	    {
		send_to_char("You lack the key.\n\r",ch);
		return;
	    }

	    if (IS_SET(obj->value[1],EX_LOCKED))
	    {
		send_to_char("It's already locked.\n\r",ch);
		return;
	    }

	    SET_BIT(obj->value[1],EX_LOCKED);
	    act("You lock $p.",ch,obj,NULL,TO_CHAR);
	    act("$n locks $p.",ch,obj,NULL,TO_ROOM);
	    return;
	}

	/* 'lock object' */
	if ( obj->item_type != ITEM_CONTAINER )
	    { send_to_char( "That's not a container.\n\r", ch ); return; }
	if ( !IS_SET(obj->value[1], CONT_CLOSED) )
	    { send_to_char( "It's not closed.\n\r",        ch ); return; }
	if ( obj->value[2] < 0 )
	    { send_to_char( "It can't be locked.\n\r",     ch ); return; }
	if ( !has_key( ch, obj->value[2] ) )
	    { send_to_char( "You lack the key.\n\r",       ch ); return; }
	if ( IS_SET(obj->value[1], CONT_LOCKED) )
	    { send_to_char( "It's already locked.\n\r",    ch ); return; }

	SET_BIT(obj->value[1], CONT_LOCKED);
	act("You lock $p.",ch,obj,NULL,TO_CHAR);
	act( "$n locks $p.", ch, obj, NULL, TO_ROOM );
	return;
    }

    if ( ( door = find_door( ch, arg ) ) >= 0 )
    {
	/* 'lock door' */
	Room *to_room;
	Exit *pexit;
	Exit *pexit_rev;

	pexit	= ch->in_room->exit[door];
	if ( !IS_SET(pexit->exit_info, EX_CLOSED) )
	    { send_to_char( "It's not closed.\n\r",        ch ); return; }
	if ( pexit->key < 0 )
	    { send_to_char( "It can't be locked.\n\r",     ch ); return; }
	if ( !has_key( ch, pexit->key) )
	    { send_to_char( "You lack the key.\n\r",       ch ); return; }
	if ( IS_SET(pexit->exit_info, EX_LOCKED) )
	    { send_to_char( "It's already locked.\n\r",    ch ); return; }

	SET_BIT(pexit->exit_info, EX_LOCKED);
	send_to_char( "*Click*\n\r", ch );
	act( "$n locks the $d.", ch, NULL, exitName(pexit), TO_ROOM );

	/* lock the other side */
	if ( ( to_room   = pexit->u1.to_room            ) != NULL
	&&   ( pexit_rev = to_room->exit[rev_dir[door]] ) != 0
	&&   pexit_rev->u1.to_room == ch->in_room )
	{
	    SET_BIT( pexit_rev->exit_info, EX_LOCKED );
	}
    }

    return;
}



void do_unlock( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Object *obj;
    int door;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
		send_to_char( "Unlock what?\n\r", ch );
		return;
    }

    if ( ( obj = get_obj_here( ch, arg ) ) != NULL )
    {
 		/* portal stuff */
		if (obj->item_type == ITEM_PORTAL)
		{
	    	if (!IS_SET(obj->value[1],EX_ISDOOR))
	    	{
				act("You can't unlock $p.",ch,obj,NULL,TO_CHAR);
				return;
	    	}

	    	if (!IS_SET(obj->value[1],EX_CLOSED))
	    	{
				act("$p is not closed.\n\r",ch,obj,NULL,TO_CHAR);
				return;
	    	}

	    	if (obj->value[4] < 0)
	    	{
				act("$p can't be unlocked.\n\r",ch,obj,NULL,TO_CHAR);
				return;
	    	}

	    	if (!has_key(ch,obj->value[4]))
	    	{
				act("You lack the key to $p.\n\r",ch,obj,NULL,TO_CHAR);
				return;
	    	}

	    	if (!IS_SET(obj->value[1],EX_LOCKED))
	    	{
				act("$p is already unlocked.\n\r",ch,obj,NULL,TO_CHAR);
				return;
	    	}

	    	REMOVE_BIT(obj->value[1],EX_LOCKED);
	    	act("You unlock $p.",ch,obj,NULL,TO_CHAR);
	    	act("$n unlocks $p.",ch,obj,NULL,TO_ROOM);
	    	return;
		}

		/* 'unlock object' */
		if ( obj->item_type != ITEM_CONTAINER )
	    {
            act("$p is not a container.",ch,obj,NULL,TO_CHAR); 
            return; 
        }

		if ( !IS_SET(obj->value[1], CONT_CLOSED) )
	    { 
            act( "$p is not closed.",ch,obj,NULL,TO_CHAR); 
            return; 
        }

		if ( obj->value[2] < 0 )
	    { 
            act( "$p can't be unlocked.\n\r",ch,obj,NULL,TO_CHAR);
            return; 
        }

		if ( !has_key( ch, obj->value[2] ) )
	    { 
            act( "You lack the key to $p.\n\r",ch,obj,NULL,TO_CHAR);
            return; 
        }

		if ( !IS_SET(obj->value[1], CONT_LOCKED) )
	    { 
            act( "$p is already unlocked.\n\r",ch,obj,NULL,TO_CHAR);
            return; 
        }

		REMOVE_BIT(obj->value[1], CONT_LOCKED);
		act("You unlock $p.",ch,obj,NULL,TO_CHAR);
		act( "$n unlocks $p.", ch, obj, NULL, TO_ROOM );
		return;
    }

    if ( ( door = find_door( ch, arg ) ) >= 0 )
    {
		/* 'unlock door' */
		Room *to_room;
		Exit *pexit;
		Exit *pexit_rev;
	
		pexit = ch->in_room->exit[door];
		if ( !IS_SET(pexit->exit_info, EX_CLOSED) )
	    	{ send_to_char( "It's not closed.\n\r",        ch ); return; }
		if ( pexit->key < 0 )
	    	{ send_to_char( "It can't be unlocked.\n\r",   ch ); return; }
		if ( !has_key( ch, pexit->key) )
	    	{ send_to_char( "You lack the key.\n\r",       ch ); return; }
		if ( !IS_SET(pexit->exit_info, EX_LOCKED) )
	    	{ send_to_char( "It's already unlocked.\n\r",  ch ); return; }
	
		REMOVE_BIT(pexit->exit_info, EX_LOCKED);
		send_to_char( "*Click*\n\r", ch );
		act( "$n unlocks the $d.", ch, NULL, exitName(pexit), TO_ROOM );
	
		/* unlock the other side */
		if ( ( to_room   = pexit->u1.to_room            ) != NULL
		&&   ( pexit_rev = to_room->exit[rev_dir[door]] ) != NULL
		&&   pexit_rev->u1.to_room == ch->in_room )
		{
	    	REMOVE_BIT( pexit_rev->exit_info, EX_LOCKED );
		}
   	}
	
   	return;
}



void do_pick( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Character *gch;
    Object *obj;
    int door;
	int chance, skill;
	int i;

	if( REUSE_SKILL(ch,gsn_open_lock) )
	{
		cprintf(ch,"Not yet, it takes awhile to prepare!\n\r");
		return;
	}

	if ( (skill = get_skill(ch,gsn_open_lock)) < 1 )
	{
		cprintf(ch,"You'd have more luck breaking the lock than picking it.\n\r");
		return;
	}

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
		send_to_char( "Pick what?\n\r", ch );
		return;
    }

    /* look for guards */
    for ( gch = ch->in_room->people; gch; gch = gch->next_in_room )
    {
		if ( IS_NPC(gch) && IS_SET(gch->act,ACT_GUARD) && IS_AWAKE(gch) && skill < gch->level )
		{
	    	act( "$N is standing too close to the lock.", ch, NULL, gch, TO_CHAR );
	    	return;
		}
    }

	/* Chance = 50% modifed by skill ratio */
	chance = 50;
	applySkillAdjust( &chance, 100, skill, ch->level );

    if ( ( obj = get_obj_here( ch, arg ) ) != NULL )
    {
		/* portal stuff */
		if (obj->item_type == ITEM_PORTAL)
		{
	    	if (!IS_SET(obj->value[1],EX_ISDOOR))
	    	{	
				send_to_char("You can't do that.\n\r",ch);
				return;
	    	}
	
	    	if (!IS_SET(obj->value[1],EX_CLOSED))
	    	{
				send_to_char("It's not closed.\n\r",ch);
				return;
	    	}
	
	    	if (obj->value[4] < 0)
	    	{
				send_to_char("It can't be unlocked.\n\r",ch);
				return;
	    	}
	
	    	if (IS_SET(obj->value[1],EX_PICKPROOF))
			{
				cprintf(ch,"This lock cannot be picked.\n\r");
				return;
			}
	
			chance += applyLevelDifference(ch->level,obj->level);
			for( i = 0 ; pick_diff_table[i].flag ; i++ )
			{
				if ( IS_SET(obj->value[1], pick_diff_table[i].flag ) )
				{
					chance -= pick_diff_table[i].difficulty;
					break;
				}
			}
	
			if ( number_percent() > chance )
				goto failed;
	
	    	REMOVE_BIT(obj->value[1],EX_LOCKED);
	    	act("You pick the lock on $p.",ch,obj,NULL,TO_CHAR);
	    	act("$n picks the lock on $p.",ch,obj,NULL,TO_ROOM);
			setSkillReuseWait(ch,gsn_open_lock,PULSE_PER_SECOND*60);
	    	return;
		}
	
		/* 'pick object' */
		if ( obj->item_type != ITEM_CONTAINER )
	    	{ send_to_char( "That's not a container.\n\r", ch ); return; }
		if ( !IS_SET(obj->value[1], CONT_CLOSED) )
	    	{ send_to_char( "It's not closed.\n\r",        ch ); return; }
		if ( obj->value[2] < 0 )
	    	{ send_to_char( "It can't be unlocked.\n\r",   ch ); return; }
		if ( !IS_SET(obj->value[1], CONT_LOCKED) )
	    	{ send_to_char( "It's already unlocked.\n\r",  ch ); return; }
	
		if ( IS_SET(obj->value[1], CONT_PICKPROOF) )
		{
			cprintf(ch,"This lock cannot be picked.\n\r");
			return;
		}

		chance += applyLevelDifference(ch->level,obj->level);	
		if ( number_percent() > chance )
			goto failed;

		REMOVE_BIT(obj->value[1], CONT_LOCKED);
       	act("You pick the lock on $p.",ch,obj,NULL,TO_CHAR);
       	act("$n picks the lock on $p.",ch,obj,NULL,TO_ROOM);
		setSkillReuseWait(ch,gsn_open_lock,PULSE_PER_SECOND*60);
		return;
    }
	
    if ( ( door = find_door( ch, arg ) ) >= 0 )
    {
		/* 'pick door' */
		Room *to_room;
		Exit *pexit;
		Exit *pexit_rev;

		pexit = ch->in_room->exit[door];
		if ( !IS_SET(pexit->exit_info, EX_CLOSED) && !IS_IMMORTAL(ch))
	    	{ send_to_char( "It's not closed.\n\r",        ch ); return; }
		if ( pexit->key < 0 && !IS_IMMORTAL(ch))
	    	{ send_to_char( "It can't be picked.\n\r",     ch ); return; }
		if ( !IS_SET(pexit->exit_info, EX_LOCKED) )
	    	{ send_to_char( "It's already unlocked.\n\r",  ch ); return; }

		if ( IS_SET(pexit->exit_info, EX_PICKPROOF) && !IS_IMMORTAL(ch))
		{
			cprintf(ch,"This lock cannot be picked.\n\r");
			return;
		}

		for( i = 0 ; pick_diff_table[i].flag ; i++ )
       	{
           	if ( IS_SET(pexit->exit_info, pick_diff_table[i].flag ))
           	{
               	chance -= pick_diff_table[i].difficulty;
               	break;
           	}
        }

		if ( number_percent() > chance )
			goto failed;
	
		REMOVE_BIT(pexit->exit_info, EX_LOCKED);
		send_to_char( "*Click*\n\r", ch );
		act( "$n picks the $d.", ch, NULL, exitName(pexit), TO_ROOM );
		setSkillReuseWait(ch,gsn_open_lock,PULSE_PER_SECOND*60);

		/* pick the other side */
		if ( ( to_room   = pexit->u1.to_room            ) != NULL
		&&   ( pexit_rev = to_room->exit[rev_dir[door]] ) != NULL
		&&   pexit_rev->u1.to_room == ch->in_room )
		{
	    	REMOVE_BIT( pexit_rev->exit_info, EX_LOCKED );
		}
    }

    return;

failed:
	cprintf(ch,"You failed.\n\r");
	if ( chance < 1 )
		cprintf(ch,"This lock is too difficult for you.\n\r");
	else
	if ( chance < 25 )
		cprintf(ch,"This lock is fairly difficult for you.\n\r");
	else
	if ( chance < 50 )
		cprintf(ch,"This lock is moderately difficult for you.\n\r");
	else
	if ( chance < 75 )
		cprintf(ch,"This lock is a bit of a challenge.\n\r");
	else
		cprintf(ch,"You ought to be able to pick this lock easily.\n\r");
	setSkillReuseWait(ch,gsn_open_lock,PULSE_PER_SECOND*60);
	return;
}




void do_stand( Character *ch, char *argument )
{
    Object *obj = NULL;

    if (argument[0] != '\0')
    {
	if (ch->position == POS_FIGHTING)
	{
	    send_to_char("Maybe you should finish fighting first?\n\r",ch);
	    return;
	}
	obj = get_obj_list(ch,argument,ch->in_room->contents);
	if (obj == NULL)
	{
	    send_to_char("You don't see that here.\n\r",ch);
	    return;
	}
	if (obj->item_type != ITEM_FURNITURE
	||  (!IS_SET(obj->value[2],STAND_AT)
	&&   !IS_SET(obj->value[2],STAND_ON)
	&&   !IS_SET(obj->value[2],STAND_IN)))
	{
	    send_to_char("You can't seem to find a place to stand.\n\r",ch);
	    return;
	}
	if (ch->on != obj && count_users(obj) >= obj->value[0])
	{
	    act_new("There's no room to stand on $p.",
		ch,obj,NULL,TO_CHAR,POS_DEAD,FALSE);
	    return;
	}

	if ( con_diff(ch->level,obj->level) < -2 )
	{
		cprintf(ch,"This object is too powerful for you to stand on.\n\r");
		return;
	}

	if ( obj->deity && (obj->deity != ch->deity) )
	{
		cprintf(ch,"Only followers of %s may stand on this item, and you %s %s.\n\r", 
			deity_table[obj->deity].name,
			ch->deity == 0 ? "are" : "follow",
			deity_table[ch->deity].name );
		return;
	}

 	ch->on = obj;
    }
    
    switch ( ch->position )
    {
    case POS_SLEEPING:
	if ( IS_AFFECTED(ch, AFF_SLEEP) )
	    { send_to_char( "You can't wake up!\n\r", ch ); return; }
	
	if (obj == NULL)
	{
	    send_to_char( "You wake and stand up.\n\r", ch );
	    act( "$n wakes and stands up.", ch, NULL, NULL, TO_ROOM );
		if ( ch->on != NULL && IS_SET(ch->on->wear_flags,ITEM_TAKE) )
			get_obj( ch, ch->on, NULL );
	    ch->on = NULL;
	}
	else if (IS_SET(obj->value[2],STAND_AT))
	{
	   act_new("You wake and stand at $p.",ch,obj,NULL,TO_CHAR,POS_DEAD,FALSE);
	   act("$n wakes and stands at $p.",ch,obj,NULL,TO_ROOM);
	}
	else if (IS_SET(obj->value[2],STAND_ON))
	{
	    act_new("You wake and stand on $p.",ch,obj,NULL,TO_CHAR,POS_DEAD,FALSE);
	    act("$n wakes and stands on $p.",ch,obj,NULL,TO_ROOM);
	}
	else 
	{
	    act_new("You wake and stand in $p.",ch,obj,NULL,TO_CHAR,POS_DEAD,FALSE);
	    act("$n wakes and stands in $p.",ch,obj,NULL,TO_ROOM);
	}
	ch->position = POS_STANDING;
	do_function(ch, &do_look, "auto");
	break;

    case POS_RESTING: case POS_SITTING:
	if (obj == NULL)
	{
	    send_to_char( "You stand up.\n\r", ch );
	    act( "$n stands up.", ch, NULL, NULL, TO_ROOM );
	    ch->on = NULL;
	}
	else if (IS_SET(obj->value[2],STAND_AT))
	{
	    act("You stand at $p.",ch,obj,NULL,TO_CHAR);
	    act("$n stands at $p.",ch,obj,NULL,TO_ROOM);
	}
	else if (IS_SET(obj->value[2],STAND_ON))
	{
	    act("You stand on $p.",ch,obj,NULL,TO_CHAR);
	    act("$n stands on $p.",ch,obj,NULL,TO_ROOM);
	}
	else
	{
	    act("You stand in $p.",ch,obj,NULL,TO_CHAR);
	    act("$n stands on $p.",ch,obj,NULL,TO_ROOM);
	}
	ch->position = POS_STANDING;
	break;

    case POS_STANDING:
	send_to_char( "You are already standing.\n\r", ch );
	break;

    case POS_FIGHTING:
	send_to_char( "You are already fighting!\n\r", ch );
	break;
    }

    return;
}



void do_rest( Character *ch, char *argument )
{
    Object *obj = NULL;

    if (ch->position == POS_FIGHTING)
    {
	send_to_char("You are already fighting!\n\r",ch);
	return;
    }

    /* okay, now that we know we can rest, find an object to rest on */
    if (argument[0] != '\0')
    {
	obj = get_obj_list(ch,argument,ch->in_room->contents);
	if (obj == NULL)
	{
	    send_to_char("You don't see that here.\n\r",ch);
	    return;
	}
    }
    else obj = ch->on;

    if (obj != NULL)
    {
        if (obj->item_type != ITEM_FURNITURE
    	||  (!IS_SET(obj->value[2],REST_ON)
    	&&   !IS_SET(obj->value[2],REST_IN)
    	&&   !IS_SET(obj->value[2],REST_AT)))
    	{
	    send_to_char("You can't rest on that.\n\r",ch);
	    return;
    	}

        if (obj != NULL && ch->on != obj && count_users(obj) >= obj->value[0])
        {
	    act_new("There's no more room on $p.",ch,obj,NULL,TO_CHAR,POS_DEAD,FALSE);
	    return;
    	}
		
		if ( con_diff(ch->level,obj->level) < -2 )
		{
			cprintf(ch,"This object is too powerful for you to rest on.\n\r");
			return;
		}

		if ( obj->deity && (obj->deity != ch->deity) )
		{
			cprintf(ch,"Only followers of %s may rest on this item, and you %s %s.\n\r", 
				deity_table[obj->deity].name,
				ch->deity == 0 ? "are" : "follow",
				deity_table[ch->deity].name );
			return;
		}



	ch->on = obj;
    }

    switch ( ch->position )
    {
    case POS_SLEEPING:
	if (IS_AFFECTED(ch,AFF_SLEEP))
	{
	    send_to_char("You can't wake up!\n\r",ch);
	    return;
	}

	if (obj == NULL)
	{
	    send_to_char( "You wake up and start resting.\n\r", ch );
	    act ("$n wakes up and starts resting.",ch,NULL,NULL,TO_ROOM);
	}
	else if (IS_SET(obj->value[2],REST_AT))
	{
	    act_new("You wake up and rest at $p.",
		    ch,obj,NULL,TO_CHAR,POS_SLEEPING,FALSE);
	    act("$n wakes up and rests at $p.",ch,obj,NULL,TO_ROOM);
	}
        else if (IS_SET(obj->value[2],REST_ON))
        {
            act_new("You wake up and rest on $p.",
                    ch,obj,NULL,TO_CHAR,POS_SLEEPING,FALSE);
            act("$n wakes up and rests on $p.",ch,obj,NULL,TO_ROOM);
        }
        else
        {
            act_new("You wake up and rest in $p.",
                    ch,obj,NULL,TO_CHAR,POS_SLEEPING,FALSE);
            act("$n wakes up and rests in $p.",ch,obj,NULL,TO_ROOM);
        }
	ch->position = POS_RESTING;
	break;

    case POS_RESTING:
	send_to_char( "You are already resting.\n\r", ch );
	break;

    case POS_STANDING:
	if (obj == NULL)
	{
	    send_to_char( "You rest.\n\r", ch );
	    act( "$n sits down and rests.", ch, NULL, NULL, TO_ROOM );
	}
        else if (IS_SET(obj->value[2],REST_AT))
        {
	    act("You sit down at $p and rest.",ch,obj,NULL,TO_CHAR);
	    act("$n sits down at $p and rests.",ch,obj,NULL,TO_ROOM);
        }
        else if (IS_SET(obj->value[2],REST_ON))
        {
	    act("You sit on $p and rest.",ch,obj,NULL,TO_CHAR);
	    act("$n sits on $p and rests.",ch,obj,NULL,TO_ROOM);
        }
        else
        {
	    act("You rest in $p.",ch,obj,NULL,TO_CHAR);
	    act("$n rests in $p.",ch,obj,NULL,TO_ROOM);
        }
	ch->position = POS_RESTING;
	break;

    case POS_SITTING:
	if (obj == NULL)
	{
	    send_to_char("You rest.\n\r",ch);
	    act("$n rests.",ch,NULL,NULL,TO_ROOM);
	}
        else if (IS_SET(obj->value[2],REST_AT))
        {
	    act("You rest at $p.",ch,obj,NULL,TO_CHAR);
	    act("$n rests at $p.",ch,obj,NULL,TO_ROOM);
        }
        else if (IS_SET(obj->value[2],REST_ON))
        {
	    act("You rest on $p.",ch,obj,NULL,TO_CHAR);
	    act("$n rests on $p.",ch,obj,NULL,TO_ROOM);
        }
        else
        {
	    act("You rest in $p.",ch,obj,NULL,TO_CHAR);
	    act("$n rests in $p.",ch,obj,NULL,TO_ROOM);
	}
	ch->position = POS_RESTING;
	break;
    }


    return;
}


void do_sit (Character *ch, char *argument )
{
    Object *obj = NULL;

    if (ch->position == POS_FIGHTING)
    {
	send_to_char("Maybe you should finish this fight first?\n\r",ch);
	return;
    }

    /* okay, now that we know we can sit, find an object to sit on */
    if (argument[0] != '\0')
    {
	obj = get_obj_list(ch,argument,ch->in_room->contents);
	if (obj == NULL)
	{
	    send_to_char("You don't see that here.\n\r",ch);
	    return;
	}
    }
    else obj = ch->on;

    if (obj != NULL)                                                              
    {
	if (obj->item_type != ITEM_FURNITURE
	||  (!IS_SET(obj->value[2],SIT_ON)
	&&   !IS_SET(obj->value[2],SIT_IN)
	&&   !IS_SET(obj->value[2],SIT_AT)))
	{
	    send_to_char("You can't sit on that.\n\r",ch);
	    return;
	}

	if (obj != NULL && ch->on != obj && count_users(obj) >= obj->value[0])
	{
	    act_new("There's no more room on $p.",ch,obj,NULL,TO_CHAR,POS_DEAD,FALSE);
	    return;
	}

	if ( con_diff(ch->level,obj->level) < -2 )
	{
		cprintf(ch,"This object is too powerful for you to sit on.\n\r");
		return;
	}

	if ( obj->deity && (obj->deity != ch->deity) )
	{
		cprintf(ch,"Only followers of %s may sit on this item, and you %s %s.\n\r", 
			deity_table[obj->deity].name,
			ch->deity == 0 ? "are" : "follow",
			deity_table[ch->deity].name );
		return;
	}

	ch->on = obj;
    }
    switch (ch->position)
    {
	case POS_SLEEPING:
	    if (IS_AFFECTED(ch,AFF_SLEEP))
	    {
		send_to_char("You can't wake up!\n\r",ch);
		return;
	    }

            if (obj == NULL)
            {
            	send_to_char( "You wake and sit up.\n\r", ch );
            	act( "$n wakes and sits up.", ch, NULL, NULL, TO_ROOM );
            }
            else if (IS_SET(obj->value[2],SIT_AT))
            {
            	act_new("You wake and sit at $p.",ch,obj,NULL,TO_CHAR,POS_DEAD,FALSE);
            	act("$n wakes and sits at $p.",ch,obj,NULL,TO_ROOM);
            }
            else if (IS_SET(obj->value[2],SIT_ON))
            {
            	act_new("You wake and sit on $p.",ch,obj,NULL,TO_CHAR,POS_DEAD,FALSE);
            	act("$n wakes and sits at $p.",ch,obj,NULL,TO_ROOM);
            }
            else
            {
            	act_new("You wake and sit in $p.",ch,obj,NULL,TO_CHAR,POS_DEAD,FALSE);
            	act("$n wakes and sits in $p.",ch,obj,NULL,TO_ROOM);
            }

	    ch->position = POS_SITTING;
	    break;
	case POS_RESTING:
	    if (obj == NULL)
		send_to_char("You stop resting.\n\r",ch);
	    else if (IS_SET(obj->value[2],SIT_AT))
	    {
		act("You sit at $p.",ch,obj,NULL,TO_CHAR);
		act("$n sits at $p.",ch,obj,NULL,TO_ROOM);
	    }

	    else if (IS_SET(obj->value[2],SIT_ON))
	    {
		act("You sit on $p.",ch,obj,NULL,TO_CHAR);
		act("$n sits on $p.",ch,obj,NULL,TO_ROOM);
	    }
	    ch->position = POS_SITTING;
	    break;
	case POS_SITTING:
	    send_to_char("You are already sitting down.\n\r",ch);
	    break;
	case POS_STANDING:
	    if (obj == NULL)
    	    {
		send_to_char("You sit down.\n\r",ch);
    	        act("$n sits down on the ground.",ch,NULL,NULL,TO_ROOM);
	    }
	    else if (IS_SET(obj->value[2],SIT_AT))
	    {
		act("You sit down at $p.",ch,obj,NULL,TO_CHAR);
		act("$n sits down at $p.",ch,obj,NULL,TO_ROOM);
	    }
	    else if (IS_SET(obj->value[2],SIT_ON))
	    {
		act("You sit on $p.",ch,obj,NULL,TO_CHAR);
		act("$n sits on $p.",ch,obj,NULL,TO_ROOM);
	    }
	    else
	    {
		act("You sit down in $p.",ch,obj,NULL,TO_CHAR);
		act("$n sits down in $p.",ch,obj,NULL,TO_ROOM);
	    }
    	    ch->position = POS_SITTING;
    	    break;
    }
    return;
}


void do_sleep( Character *ch, char *argument )
{
    Object *obj = NULL;

    switch ( ch->position )
    {
    case POS_SLEEPING:
	send_to_char( "You are already sleeping.\n\r", ch );
	break;

    case POS_RESTING:
    case POS_SITTING:
    case POS_STANDING: 
	if (argument[0] == '\0' && ch->on == NULL)
	{
	    send_to_char( "You go to sleep.\n\r", ch );
	    act( "$n goes to sleep.", ch, NULL, NULL, TO_ROOM );
	    ch->position = POS_SLEEPING;
	}
	else  /* find an object and sleep on it */
	{
	    if (argument[0] == '\0')
		obj = ch->on;
	    else
	    	obj = get_obj_list( ch, argument,  ch->in_room->contents );

	    if (obj == NULL)
	    {
		send_to_char("You don't see that here.\n\r",ch);
		return;
	    }
	    if (obj->item_type != ITEM_FURNITURE
	    ||  (!IS_SET(obj->value[2],SLEEP_ON) 
	    &&   !IS_SET(obj->value[2],SLEEP_IN)
	    &&	 !IS_SET(obj->value[2],SLEEP_AT)))
	    {
		send_to_char("You can't sleep on that!\n\r",ch);
		return;
	    }

	    if (ch->on != obj && count_users(obj) >= obj->value[0])
	    {
		act_new("There is no room on $p for you.",
		    ch,obj,NULL,TO_CHAR,POS_DEAD,FALSE);
		return;
	    }

		if ( con_diff(ch->level,obj->level) < -2 )
		{
			cprintf(ch,"This object is too powerful for you to sleep on.\n\r");
			return;
		}

		if ( obj->deity && (obj->deity != ch->deity) )
		{
			cprintf(ch,"Only followers of %s may sleep on this item, and you %s %s.\n\r", 
				deity_table[obj->deity].name,
				ch->deity == 0 ? "are" : "follow",
				deity_table[ch->deity].name );
			return;
		}

	    ch->on = obj;
	    if (IS_SET(obj->value[2],SLEEP_AT))
	    {
		act("You go to sleep at $p.",ch,obj,NULL,TO_CHAR);
		act("$n goes to sleep at $p.",ch,obj,NULL,TO_ROOM);
	    }
	    else if (IS_SET(obj->value[2],SLEEP_ON))
	    {
	        act("You go to sleep on $p.",ch,obj,NULL,TO_CHAR);
	        act("$n goes to sleep on $p.",ch,obj,NULL,TO_ROOM);
	    }
	    else
	    {
		act("You go to sleep in $p.",ch,obj,NULL,TO_CHAR);
		act("$n goes to sleep in $p.",ch,obj,NULL,TO_ROOM);
	    }
	    ch->position = POS_SLEEPING;
	}
	break;

    case POS_FIGHTING:
	send_to_char( "You are already fighting!\n\r", ch );
	break;
    }

    return;
}



void do_wake( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Character *victim;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
	{ do_function(ch, &do_stand, ""); return; }

    if ( !IS_AWAKE(ch) )
	{ send_to_char( "You are asleep yourself!\n\r",       ch ); return; }

    if ( ( victim = get_char_room( ch, arg ) ) == NULL )
	{ send_to_char( "They aren't here.\n\r",              ch ); return; }

    if ( IS_AWAKE(victim) )
	{ act( "$N is already awake.", ch, NULL, victim, TO_CHAR ); return; }

	if ( HAS_OPT(victim, OPT_NOWAKE) )
	{ act( "$N does not want to be waken.", ch, NULL, victim, TO_CHAR); return; }

    if ( IS_AFFECTED(victim, AFF_SLEEP) || isIgnoring( victim, !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name ))
	{ act( "You can't wake $M!",   ch, NULL, victim, TO_CHAR );  return; }

    act_new( "$n wakes you.", ch, NULL, victim, TO_VICT,POS_SLEEPING ,FALSE);
    do_function(victim, &do_stand, "");
    return;
}



/*
 * Once you are hiding you can automatically sneak.
 */
void do_sneak( Character *ch, char *argument )
{
	Affect af;

	if ( get_skill(ch,gsn_stealth) < 1 ) 
	{
		cprintf(ch,"You don't know how to sneak.\n\r");
		return;
	}

    if ( REUSE_SKILL(ch,gsn_stealth) )
    {
        cprintf(ch,"You are not prepared yet.\n\r");
        return;
    }

	/* Sneak is automatic.  Once you are hiding you can automatically
	 * sneak.  Whether or not you get revealed depends on how well you
	 * sneak.  Your skill is checked against people's levels when you	
	 * move from room to room.  Non-aggressive mobs will not reveal you.
	 * GUARD mobs, charmies, and other players will.  The chance to reveal
	 * a stealther is 50%, modified by stealth skill and level.  If stealth
	 * is equal to your level you will never be revealed by people your
	 * level or lower.
	 */ 
    send_to_char( "You begin to move silently.\n\r", ch );
	
	af.where     = TO_AFFECTS;
	af.type      = gsn_stealth;
	af.level     = ch->level; 
	af.duration  = DUR_PERMANENT;
	af.location  = APPLY_NONE;
	af.modifier  = 0;
	af.bitvector = AFF_SNEAK;
	af.flags     = AFF_SKILL;
	skillAffectToChar( ch, &af );

    setSkillReuseWait(ch,gsn_stealth,PULSE_PER_SECOND * 10);
    return;
}

void visible( Character *ch, char *argument, bool fEcho )
{
    skill_affect_strip ( ch, gsn_stealth			);
	      affect_strip ( ch, gsn_invis				);
          affect_strip ( ch, vnum_camouflage         );

    REMOVE_BIT   ( ch->affected_by, AFF_INVISIBLE	);
    REMOVE_BIT   ( ch->affected_by, AFF_SNEAK		);
	if ( fEcho )
    	send_to_char( "Ok.\n\r", ch );
    return;
}

void do_visible( Character *ch, char *argument )
{
    visible(ch,argument,TRUE); 
}

void do_recall( Character *ch, char *argument )
{
    Room *location;
	int n;
	int vnum;

    if (IS_NPC(ch) && !IS_SET(ch->act,ACT_PET))
    {
		send_to_char("Only players can recall.\n\r",ch);
		return;
    }

	if ( !IS_NPC(ch) )
		vnum = ch->pcdata->recall_vnum;
	else
	if ( ch->master != NULL && !IS_NPC(ch->master) )
		vnum = ch->master->pcdata->recall_vnum;
	else
		vnum = ROOM_VNUM_TEMPLE;
		
	if ( (n=REUSE_SKILL(ch,gsn_recall)) )
	{
		cprintf(ch,"You've been in combat; you cannot recall for %d more seconds.\n\r",n/PULSE_PER_SECOND);
		return;
	}
 
    act( "$n prays for transportation!", ch, 0, 0, TO_ROOM );

    if ( ( location = get_room_index( vnum ) ) == NULL )
    {
		send_to_char( "You are completely lost.\n\r", ch );
		return;
    }

    if ( ch->in_room == location )
	return;

    if ( !IS_IMMORTAL(ch) && (IS_SET(ch->in_room->room_flags, ROOM_NO_RECALL)
    ||   IS_AFFECTED(ch, AFF_CURSE)))
    {
	cprintf(ch,"%s cannot hear your prayer.\n\r",capitalize(deity_table[ch->deity].name) );
	return;
    }

    ch->move /= 2;
    act( "$n disappears.", ch, NULL, NULL, TO_ROOM );
    char_from_room( ch );
    char_to_room( ch, location );
    act( "$n appears in the room.", ch, NULL, NULL, TO_ROOM );
    do_function(ch, &do_look, "auto" );
    
    if (ch->pet != NULL)
		do_function(ch->pet, &do_recall, "");

    return;
}



void do_train( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    Character *mob;
    sh_int stat = - 1;
    char *pOutput = NULL;
    int cost;

    if ( IS_NPC(ch) )
	return;

    /*
     * Check for trainer.
     */
    for ( mob = ch->in_room->people; mob; mob = mob->next_in_room )
    {
	if ( IS_NPC(mob) && IS_SET(mob->act, ACT_TRAIN) )
	    break;
    }

    if ( mob == NULL )
    {
	send_to_char( "You can't do that here.\n\r", ch );
	return;
    }

    if ( argument[0] == '\0' )
    {
	sprintf( buf, "You have %d training sessions.\n\r", ch->train );
	send_to_char( buf, ch );
	argument = "foo";
    }

    cost = 1;

    if ( !str_cmp( argument, "str" ) )
    {
	if ( class_table[ch->class].attr_prime == STAT_STR )
	    cost    = 1;
	stat        = STAT_STR;
	pOutput     = "strength";
    }

    else if ( !str_cmp( argument, "int" ) )
    {
	if ( class_table[ch->class].attr_prime == STAT_INT )
	    cost    = 1;
	stat	    = STAT_INT;
	pOutput     = "intelligence";
    }

    else if ( !str_cmp( argument, "wis" ) )
    {
	if ( class_table[ch->class].attr_prime == STAT_WIS )
	    cost    = 1;
	stat	    = STAT_WIS;
	pOutput     = "wisdom";
    }

    else if ( !str_cmp( argument, "dex" ) )
    {
	if ( class_table[ch->class].attr_prime == STAT_DEX )
	    cost    = 1;
	stat  	    = STAT_DEX;
	pOutput     = "dexterity";
    }

    else if ( !str_cmp( argument, "con" ) )
    {
	if ( class_table[ch->class].attr_prime == STAT_CON )
	    cost    = 1;
	stat	    = STAT_CON;
	pOutput     = "constitution";
    }

	else if ( !str_cmp( argument, "cha" ) )
	{
		/* bards, paladins only */
		if ( !strcmp("bard",class_table[ch->class].name) ||
			 !strcmp("paladin",class_table[ch->class].name) )
		{
			if ( class_table[ch->class].attr_prime == STAT_CHA )
				cost = 1;
			stat 		= STAT_CHA;
			pOutput		= "charisma";
		}
		else
		{
			cprintf(ch,"Only bards and paladins may train Charisma.\n\r");
			return;
		}
	}

/*
    else if ( !str_cmp(argument, "hp" ) )
	cost = 1;

    dlse if ( !str_cmp(argument, "mana" ) )
	cost = 1;
*/
    else
    {
	strcpy( buf, "You can train:" );
	if ( ch->perm_stat[STAT_STR] < get_max_train(ch,STAT_STR)) 
	    strcat( buf, " str" );
	if ( ch->perm_stat[STAT_INT] < get_max_train(ch,STAT_INT))  
	    strcat( buf, " int" );
	if ( ch->perm_stat[STAT_WIS] < get_max_train(ch,STAT_WIS)) 
	    strcat( buf, " wis" );
	if ( ch->perm_stat[STAT_DEX] < get_max_train(ch,STAT_DEX))  
	    strcat( buf, " dex" );
	if ( ch->perm_stat[STAT_CON] < get_max_train(ch,STAT_CON))  
	    strcat( buf, " con" );
	if ( ch->perm_stat[STAT_CHA] < get_max_train(ch,STAT_CHA) &&
		( !strcmp("bard",class_table[ch->class].name) ||
             !strcmp("paladin",class_table[ch->class].name)) )
		strcat( buf, " cha" );
	if ( buf[strlen(buf)-1] != ':' )
	{
	    strcat( buf, ".\n\r" );
	    send_to_char( buf, ch );
	}
	else
	    cprintf(ch, "You have nothing left to train\n\r");

	return;
    }


    if ( ch->perm_stat[stat]  >= get_max_train(ch,stat) )
    {
	act( "Your $T is already at maximum.", ch, NULL, pOutput, TO_CHAR );
	return;
    }

    if ( cost > ch->train )
    {
	send_to_char( "You don't have enough training sessions.\n\r", ch );
	return;
    }

    ch->train		-= cost;
  
    act( "Your $T increases!", ch, NULL, pOutput, TO_CHAR );
    act( "$n's $T increases!", ch, NULL, pOutput, TO_ROOM );
	report_train_bonuses(ch,stat);
    ch->perm_stat[stat]	+= 1;
    return;
}

void report_train_bonuses(Character *ch, int stat)
{
	long old_value = 0, new_value = 0;

	if(IS_NPC(ch))
		return;

	if(stat == STAT_STR)
	{
		int old_damroll = 0, new_damroll = 0;

		/* Carry weight */
		old_value = (ch->perm_stat[stat] + ch->level)/10;
		new_value = ((ch->perm_stat[stat]+1) + ch->level)/10;
		if(new_value > old_value)
		{
			cprintf(ch, "You can now carry %d more pound%s.\n\r", new_value - old_value, 
				(new_value - old_value) > 1 ? "s" : "");
		}

		/* Dam roll */
		if ( HAS_PROF(ch, gpn_weapon_finesse) )
		{
			old_value = (ch->perm_stat[stat] + ch->perm_stat[STAT_DEX]) / 2;
			new_value = ((ch->perm_stat[stat]+1) + ch->perm_stat[STAT_DEX]) / 2;
		}
		else
		{
			old_value = ch->perm_stat[stat];
			new_value = ch->perm_stat[stat] + 1;
		}

		old_damroll = ch->damroll + UMAX(0,((old_value-100)/5 * class_table[ch->class].thac0));
		new_damroll = ch->damroll + UMAX(0,((new_value-100)/5 * class_table[ch->class].thac0));

		if(new_damroll > old_damroll)
		{
			cprintf(ch, "Your base damage roll has increased by %d.\n\r", new_damroll - old_damroll);
		}

		/* Hit roll */
		/* A chars base hit roll is always 0, this is here incase we change that 
		if( !HAS_PROF(ch, gpn_weapon_finesse) && ch->hitroll > 0)
		{
			old_value = ( 100 + ((ch->perm_stat[stat]-100)/2) ) * ch->hitroll / 100;
			new_value = ( 100 + (((ch->perm_stat[stat]+1)-100)/2) ) * ch->hitroll / 100;

			if(new_value > old_value)
			{
				cprintf(ch, "Your base hitroll has increased by %d.\n\r", new_value - old_value);
			}
		}*/

		/* Stamina */
		old_value = (long) ( 100 + ((ch->perm_stat[stat]-100)/2) ) * ch->max_stamina / 100;
		new_value = (long) ( 100 + (((ch->perm_stat[stat]+1)-100)/2) ) * ch->max_stamina / 100;
	 	old_value = UMIN(old_value,30000);
		new_value = UMIN(new_value,30000);

		if(new_value > old_value)
		{
			cprintf(ch, "Your base stamina has increased by %d.\n\r", new_value - old_value);
		}
	
		return;
	}

	if(stat == STAT_DEX)
	{
		int old_damroll = 0, new_damroll = 0;

		/* Dam roll */
		if ( HAS_PROF(ch, gpn_weapon_finesse) )
		{
			old_value = (ch->perm_stat[STAT_STR] + ch->perm_stat[stat]) / 2;
			new_value = (ch->perm_stat[STAT_STR] + (ch->perm_stat[stat]+1)) / 2;

			old_damroll = ch->damroll + UMAX(0,((old_value-100)/5 * class_table[ch->class].thac0));
			new_damroll = ch->damroll + UMAX(0,((new_value-100)/5 * class_table[ch->class].thac0));
			if(new_damroll > old_damroll)
			{
				cprintf(ch, "Your base damage roll has increased by %d.\n\r", new_damroll - old_damroll);
			}
		}

		/* Save reflex */
		old_value = ( ch->level + (ch->perm_stat[stat]-100)/2);
		new_value = ( ch->level + ((ch->perm_stat[stat]+1)-100)/2);

		if(new_value > old_value)
		{
			cprintf(ch, "Your base reflex saves have increased by %d.\n\r", new_value - old_value);
		}
		
		/* AC */
		if( *class_table[ch->class].csn == csn_thief ||
			*class_table[ch->class].csn == csn_assassin )
		{
			old_value = 2 * ( (ch->perm_stat[stat]-100)/2 );
			new_value = 2 * ( ((ch->perm_stat[stat]+1)-100)/2 );
		}
		else if( *class_table[ch->class].csn == csn_monk )
		{
			old_value = ( (ch->level  * ch->perm_stat[stat] / 25) + (ch->perm_stat[stat]-100)/2);
			new_value = ( (ch->level  * (ch->perm_stat[stat]+1) / 25) + ((ch->perm_stat[stat]+1)-100)/2);
		}
		else
		{
			old_value = ( (ch->perm_stat[stat]-100)/2);
			new_value = ( ((ch->perm_stat[stat]+1)-100)/2);
		}

		if(new_value > old_value)
		{
			cprintf(ch, "Your base armor class has increased by %d.\n\r", new_value - old_value);
		}

		return;
	}

	if(stat == STAT_CON)
	{
		/* Save reflex */
		old_value = ( ch->level + (ch->perm_stat[stat]-100)/2);
		new_value = ( ch->level + ((ch->perm_stat[stat]+1)-100)/2);

		if(new_value > old_value)
		{
			cprintf(ch, "Your base fortitude saves have increased by %d.\n\r", new_value - old_value);
		}

		/* Stat hits */
		old_value = (long) (100 + ((ch->perm_stat[stat]-100)/2)) * ch->max_stat_hit / 100;
		new_value = (long) (100 + (((ch->perm_stat[stat]+1)-100)/2)) * ch->max_stat_hit / 100;
		old_value = UMIN(old_value, 30000);
		new_value = UMIN(new_value, 30000);

		if(new_value > old_value)
		{
			cprintf(ch, "Your base stat hit points have increased by %d.\n\r", new_value - old_value);	
		}

		return;
	}

	if(stat == STAT_INT)
	{
		if ( class_table[ch->class].fMana && class_table[ch->class].group == ARCANE )
		{
			old_value = (long) (100 + ((ch->perm_stat[stat]-100)/2)) * ch->max_mana / 100;
			new_value = (long) (100 + (((ch->perm_stat[stat]+1)-100)/2)) * ch->max_mana / 100;
		}

		old_value = UMIN(old_value, 30000);
		new_value = UMIN(new_value, 30000);

		if(new_value > old_value)
		{
			cprintf(ch, "Your base mana has increased by %d.\n\r", new_value - old_value);	
		}

		return;
	}

	if(stat == STAT_WIS)
	{
		/* Save reflex */
		old_value = ( ch->level + (ch->perm_stat[stat]-100)/2);
		new_value = ( ch->level + ((ch->perm_stat[stat]+1)-100)/2);

		if(new_value > old_value)
		{
			cprintf(ch, "Your base willpower saves have increased by %d.\n\r", new_value - old_value);
		}

		/* Mana */
		if ( class_table[ch->class].fMana && class_table[ch->class].group != ARCANE 
			&& str_cmp(class_table[ch->class].name,"bard") )
		{
			old_value = (long) (100 + ((ch->perm_stat[stat]-100)/2)) * ch->max_mana / 100;
			new_value = (long) (100 + (((ch->perm_stat[stat]+1)-100)/2)) * ch->max_mana / 100;

			old_value = UMIN(old_value, 30000);
			new_value = UMIN(new_value, 30000);

			if(new_value > old_value)
			{
				cprintf(ch, "Your base mana has increased by %d.\n\r", new_value - old_value);	
			}
		}

		return;
	}

	if(stat == STAT_CHA)
	{
		if ( class_table[ch->class].fMana && !str_cmp(class_table[ch->class].name,"bard") )
		{
			old_value = (long) (100 + ((ch->perm_stat[stat]-100)/2)) * ch->max_mana / 100;
			new_value = (long) (100 + (((ch->perm_stat[stat]+1)-100)/2)) * ch->max_mana / 100;

			old_value = UMIN(old_value, 30000);
			new_value = UMIN(new_value, 30000);

			if(new_value > old_value)
			{
				cprintf(ch, "Your base mana has increased by %d.\n\r", new_value - old_value);	
			}
		}

		return;
	}

}

void do_joi( Character *ch, char *argument )
{
    cprintf(ch,"This command must be spelled out in full.\n\r");
    return;
}

void check_reveal( Character *ch )
{
	Character *wch;
	int base;

	if ( !IS_AFFECTED(ch,AFF_SNEAK) && !is_affected(ch,gsn_stealth,AFF_SKILL) )
		return;

	base = get_skill(ch,gsn_stealth);
	base = ( base * 100 ) / ch->level;
	base += ch->level;

	for ( wch = ch->in_room->people ; wch ; wch = wch->next_in_room )
	{
		int level;

		if ( wch == ch || IS_IMMORTAL(wch) || 
			!IS_AWAKE(wch) || is_affected(wch,gsn_stealth,AFF_SKILL) )
			continue;

		if ( IS_SET( wch->in_room->room_flags, ROOM_DARK ) && !IS_AFFECTED(ch,AFF_DARK_VISION) )
			continue;

		if ( !IS_NPC(wch) && ( HAS_OPT(wch,OPT_NOREVEAL) ||
				(HAS_OPT(wch,OPT_NOREVEAL_CLANMATES) && is_same_clan(ch,wch)) || 
				(HAS_OPT(wch,OPT_NOREVEAL_GROUPMATES) && is_same_group(ch,wch))) )
			continue;
		
		if ( IS_NPC(wch) && !IS_SET(wch->act,ACT_GUARD) && !IS_SET(wch->act,ACT_AGGRESSIVE)
				&& wch->master == NULL && get_melee_disposition(wch,ch) < DISPOS_ACTIVE )
			continue;

		level = (wch->fighting == NULL ? wch->level : wch->level / 2);
		if ( number_percent() > base - level )
		{
			visible(ch,"",ECHO_OFF);
			act("$n reveals $N!",wch,NULL,ch,TO_NOTVICT);
			act("You are revealed by $N!\n\r",ch,NULL,wch,TO_CHAR);
			act("You reveal $N!",wch,NULL,ch,TO_CHAR);
			setSkillReuseWait(ch,gsn_stealth,PULSE_PER_SECOND * 10);
			break;
		}
	}
	return;
}

void do_bind( Character *ch, char *argument )
{
	Object *stone;

	if ( IS_NPC(ch) )
	{
		cprintf(ch,"NPCs cannot bind.\n\r");
		return;
	}

	if ( *argument || !str_cmp(argument,"show") )
	{
		Room *r;

		r = get_room_index( ch->pcdata->recall_vnum );
		cprintf(ch,"You are bound in %s\n\r", r == NULL ? "nowhere" : r->name );
		return;
	}

	for ( stone = ch->in_room->contents ; stone != NULL ; stone = stone->next_content )
		if ( stone->item_type == ITEM_BINDSTONE )
			break;

	if ( stone == NULL )
	{
		cprintf(ch,"There is no bindstone here!\n\r");
		return;
	}
 
	ch->pcdata->recall_vnum = ch->in_room->vnum;
	do_bind(ch,"show");
	return;
}

void do_push( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Object *obj;
    int door, weight, delay, wait, redux;
 	Room *in_room, *to_room;
	Exit *pexit;

    argument = one_argument( argument, arg );

    if ( arg[0] == '\0' || *argument == '\0' )
    {
        cprintf(ch,"Syntax:  push <item> <direction>\n\r");
        return;
    }

    if ( (obj = get_obj_here(ch,arg)) == NULL )
    {
        cprintf(ch,"You don't see that vehicle here.\n\r");
        return;
    }
 
    if ( obj->item_type != ITEM_MOBILE )
    {
        cprintf(ch,"You can only push a mobile vehicle.\n\r");
        return;
    }
 
    switch( *argument )
    {
        case 'n': case 'N':
            door = DIR_NORTH; break;
        case 'e': case 'E':
            door = DIR_EAST; break;
        case 's': case 'S':
            door = DIR_SOUTH; break;
        case 'w': case 'W':
            door = DIR_WEST; break;
        default:
            cprintf(ch,"Direction must be north, south, east, or west.\n\r");
            return;
    }

    // Make sure that's an exit over there
    in_room = ch->in_room;
    if ( ( pexit   = in_room->exit[door] ) == NULL ||
         ( to_room = pexit->u1.to_room   ) == NULL ||
         !can_see_room(ch,pexit->u1.to_room))
    {
    	cprintf( ch, "Alas, you cannot go that way.\n\r" );
    	return;
    }
 
    if (  IS_SET(pexit->exit_info, EX_CLOSED) &&
          (!IS_AFFECTED(ch, AFF_PASS_DOOR) || IS_SET(pexit->exit_info,EX_NOPASS)) &&
          !IS_IMMORTAL(ch) )
    {
    	act( "The $d is closed.", ch, NULL, exitName(pexit), TO_CHAR );
    	return;
    }
 
    if ( IS_AFFECTED(ch, AFF_CHARM) &&
         ch->master != NULL &&
         in_room == ch->master->in_room )
    {
    	cprintf( ch, "What?  And leave your beloved master?\n\r" );
    	return;
    }
    
    if ( !is_room_owner(ch,to_room) && room_is_private( to_room ) )
    {
    	send_to_char( "That room is private right now.\n\r", ch );
    	return;
    }
    
	// Cannot push into air or water
	switch( to_room->sector_type )
	{
 		case SECT_WATER_SWIM:
 		case SECT_WATER_NOSWIM:
 		case SECT_UNDERWATER:
			cprintf(ch,"You cannot move a vehicle over that type of terrain.\n\r");
			return;
	}

	if( ch->stamina < 10 )
	{
		act("You're too exhausted.",ch,NULL,NULL,TO_CHAR);
		return;
	}

	ch->stamina -= 10;
	act("$n pushes $p $T.",ch,obj,dir_name[door],TO_ROOM);
	act("You push $p $T.",ch,obj,dir_name[door],TO_CHAR);
	obj_from_room( obj );
	obj_to_room( obj, to_room );
	move_char( ch, door, FALSE );

	// The more loaded-down it is, the harder it is to push.
	// Default is 2 seconds for the cart plus .20 seconds per
	// hundred pounds of weight beyond the cart's natural 
	// weight.
	weight = (get_obj_weight( obj ) - obj->weight)/10;
	delay = weight / 50;
	delay = UMAX(delay,0);

	// But that's not all!  Strong people push better.
	// If your strength is over 120, you get a .2 second deduction
	// per 10 points of strength over 120.

	redux = get_curr_stat(ch,STAT_STR) - 120;
	redux = (redux/10) * 2;
	redux = UMAX(redux,0);
	
	wait = (PULSE_PER_SECOND*2) + delay - redux;
	wait = UMAX(5,wait);

	WAIT_STATE(ch,wait);
}

void do_pledge( Character *ch, char *argument )
{
    Object *shrine;
    char arg[MAX_INPUT_LENGTH];

    argument = one_argument( argument, arg ); 
    if ( arg[0] == '\0' )
    {
        cprintf(ch,"Syntax:  pledge <shrine> [renounce]\n\r");
        return;
    }

    if ( (shrine = get_obj_here(ch,arg)) == NULL )
    {
        cprintf(ch,"There is no such shrine here.\n\r");
        return;
    }

    if ( shrine->item_type != ITEM_SHRINE )
    {
        act("$p isn't a shrine.",ch,shrine,NULL,TO_CHAR);
        return;
    }

    if ( argument[0] == '\0' )
    {
        if ( ch->deity == shrine->deity )
            cprintf(ch,"You already follow that deity.\n\r");
        else
            cprintf(ch,"You pledge yourself to %s.\n\r", deity_table[shrine->deity].name);
        ch->deity = shrine->deity;
        return;
    }

    if ( str_cmp(argument,"renounce") )
    {
        cprintf(ch,"To turn agnostic, you must type in full: pledge <shrine> renounce \n\r");
        return;
    }

    if ( shrine->deity != ch->deity )
    {
        cprintf(ch,"You may only renounce your faith at the shrine of %s.\n\r", deity_table[ch->deity].name);
        return;
    }

    ch->deity = deity_lookup("agnostic");
    act("$n renounces $s faith!",ch,NULL,NULL,TO_ROOM);
    act("You renounce your faith, and refuse to believe or disbelieve.",ch,NULL,NULL,TO_CHAR);
    return;
}

void do_climb( Character *ch, char *argument )
{
    Exit *pexit;
    int door;
    char arg[MAX_INPUT_LENGTH];

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
        cprintf(ch,"Syntax:  climb <dir>\n\r");
        return;
    }

         if ( !str_prefix( arg, "north" ) ) door = 0;
    else if ( !str_prefix( arg, "east"  ) ) door = 1;
    else if ( !str_prefix( arg, "south" ) ) door = 2;
    else if ( !str_prefix( arg, "west"  ) ) door = 3;
    else if ( !str_prefix( arg, "up"    ) ) door = 4;
    else if ( !str_prefix( arg, "down"  ) ) door = 5;
    else
    {
        cprintf(ch,"That's not a direction.\n\r");
        return;
    }

    if ( ( pexit = ch->in_room->exit[door] ) == NULL )
    {
        cprintf(ch,"There is no exit in that direction.\n\r");
        return;
    }

    // Climbing rules.
    // 1. Those with climb can scale a CLIMB exit in 1 second, no fall check.
    // 2. Those w/o climb take 3 seconds, and must make a STR check or fall.
    if ( IS_SET(pexit->exit_info, EX_CLIMB) )
    {
        if ( HAS_PROF(ch,gsn_climb) )
            WAIT_STATE(ch,PULSE_PER_SECOND);
        else
        {
            WAIT_STATE(ch,PULSE_PER_SECOND*3);

            // Check for a fall
            if ( get_curr_stat(ch,STAT_STR) + dice(1,20) < get_carry_weight(ch) + dice(1,20) )
            {
                // Fall until the down exit isn't a CLIMB or FALL exit anymore
                characterFalls(ch);
                return;
            }
        }

        move_char_flagged(ch,door,FALSE,MOVE_CLIMB);
        return;
    }

    // Sheer surfaces can only be attempted by climbers.
    // Strength check vs weight worn or fall.
    if ( IS_SET(pexit->exit_info, EX_SHEER_CLIMB) )
    {
        if ( !HAS_PROF(ch,gsn_climb) )
        {
            act("You must have the climbing ability to scale a sheer surface.",ch,NULL,NULL,TO_CHAR);
            return;
        }

        if ( get_curr_stat(ch,STAT_STR) + dice(1,20) < get_carry_weight(ch) + dice(1,20) )
        {
            characterFalls(ch);
            return;
        }

        move_char_flagged(ch,door,FALSE,MOVE_CLIMB);
        WAIT_STATE(ch,PULSE_PER_SECOND*6);
        return;
    }

    act( "You can't climb $T.", ch, NULL, dir_name[door], TO_CHAR );
    return;
}

void do_jump( Character *ch, char *argument )
{
    Exit *pexit;
    int door;
    char arg[MAX_INPUT_LENGTH];

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
        cprintf(ch,"Syntax:  jump <dir>\n\r");
        return;
    }

         if ( !str_prefix( arg, "north" ) ) door = 0;
    else if ( !str_prefix( arg, "east"  ) ) door = 1;
    else if ( !str_prefix( arg, "south" ) ) door = 2;
    else if ( !str_prefix( arg, "west"  ) ) door = 3;
    else if ( !str_prefix( arg, "up"    ) ) door = 4;
    else if ( !str_prefix( arg, "down"  ) ) door = 5;
    else
    {
        cprintf(ch,"That's not a direction.\n\r");
        return;
    }

    if ( ( pexit = ch->in_room->exit[door] ) == NULL )
    {
        cprintf(ch,"There is no exit in that direction.\n\r");
        return;
    }

    if ( !IS_SET(pexit->exit_info, EX_FALL) )
    {
         act( "You can't jump $T.", ch, NULL, dir_name[door], TO_CHAR );
        return;
    }

    characterFalls(ch);
    return;
}

void pet_to_group( Character *caster, Character *pet )
{
    // Add the pet to the caster's group if you can
    if ( !char_to_group( pet, caster->pgroup ) )
    {
        cprintf(caster,"%R** Your pet could not be added to your group. **&x\n\r)");
        return;
    }
}
