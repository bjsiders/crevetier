#ifndef character_h
#define character_h

#include "thoctype.h"
#include "class.h"
#include "currency.h"
#include "notes.h"
#include "resist.h"
#include "skills.h"
#include "stack.h"

/*
    Character-related defines
*/
#define MAX_STATS       6
#define STAT_STR        0
#define STAT_DEX        1
#define STAT_CON        2
#define STAT_INT        3
#define STAT_WIS        4
#define STAT_CHA        5

#define MAX_LEVEL       60
#define MAX_FRIENDS     10
#define MAX_ALIAS       25
#define MAX_SPELL_SLOT  10
#define MAX_WEAR        26

#define LEVEL_HERO      (MAX_LEVEL - 9)
#define LEVEL_IMMORTAL  (MAX_LEVEL - 8)
#define IMPLEMENTOR     MAX_LEVEL

/*
    Administrator jobs
*/
#define IMM_ROLE_DEVELOPER          0
#define IMM_ROLE_CODER              1
#define IMM_ROLE_ADMIN              2
#define IMM_ROLE_BUILDER            3
#define IMM_ROLE_AMBIENCE           4

/*
    Needed in order to define char_data
*/
#define DEPRACTICE          0
#define DETRAIN             1
#define DEGAIN              2

/*
    Main character structure
*/
struct char_data
{
    Character *         next;
    Character *         next_in_room;
    Character *         next_dispos;
    Character *         master;
    Character *         pet;
    Character *         leader;
    Character *         fighting;
    Character *         reply;
    Character *         range_vict;
    Character *         shapeshifted;
    NPCMemory *         memory;
    SPEC_FUN *          spec_fun;
    MobIndex *          pIndexData;
    Descriptor *        desc;
    Affect *            affected;
    Note *              pnote;
    Object *            carrying;
    Object *            on;
    Object *            crafting;
    Room *              in_room;
    Room *              was_in_room;
    Area *              zone;
    PCData *            pcdata;
    NewbieData *        gen_data;
    Group *             pgroup;
    Group *             invite;
    Melee *             melee_list;
    Casting *           casting;
    Firing *            firing;
    Recipe *            recipe_crafting;
    Quest *             quests;
    Script *            scripts;
    Building *          in_building;

    /* Styles */
    short               last_style;
    Character *         last_style_victim;
    short               last_defend;
    Character *         last_defend_attacker;
    /* end styles */

    bool                valid;
    char *              name;
    time_t              created;
    long                id;
    sh_int              version;
    char *              short_descr;
    char *              long_descr;
    char *              description;
    char *              prompt;
    sh_int              group;
    Clan *              clan;
    Clan *              wizclan;
    sh_int              sex;
    sh_int              class;
    sh_int              race;
    sh_int              level;
    sh_int              trust;
    int                 played;
    int                 lines;  /* for the pager */
    time_t              logon;
    int                 breath_timer;
    sh_int              timer;
    sh_int              gui_check_timer;
    sh_int              wait;
    sh_int              daze;
    int                 stat_hit;
    int                 max_stat_hit;
    int                 base_hit;
    int                 max_base_hit; 
    int                 stamina;
    int                 max_stamina;
    sh_int              mana;
    sh_int              max_mana;
    sh_int              move;
    sh_int              max_move;
    long                coins[MAX_CURRENCY];
    long                exp;
    long                act;
    long                display;
    long                comm; /* RT added to pad the vector */
    long                wiznet; /* wiz stuff */
    long                imm_flags;
    long                res_flags;
    long                vuln_flags;
    long                gui;
    sh_int              invis_level;
    sh_int              incog_level;
    long                affected_by;
    sh_int              position;
    sh_int              practice;
    sh_int              train;
    sh_int              carry_weight;
    sh_int              carry_number;
    sh_int              saving_throw;
    sh_int              hitroll;
    sh_int              damroll;
    sh_int              armor[4];
    sh_int              wimpy;
    sh_int              perm_stat[MAX_STATS];
    sh_int              mod_stat[MAX_STATS];
    long                form;
    long                parts;
    sh_int              size;
    char*               material;
    long                off_flags;
    sh_int              damage[3];
    sh_int              dam_type;
    sh_int              start_pos;
    sh_int              default_pos;
    int                 saves[3];
    int                 deity;
    Spawn *             spawn;
    int                 despawn;
    int                 regen;
    Resist              resists[MAX_RESIST];
    int                 absorb;
    int                 postcurve_hitadj;
    Faction *           factions;
    Stack               pathing;    // NPC chasing people
    Stack               pursuit;    // NPC pursuing ranged/etc
    int                 playing;
    Reuse_wait *        reuse_wait;
    int                 style;
    Character *         guarding;
    Character *         intercepting;
    long                stun_timer;
    int                 attack_speed;    /* NPCs only */
    time_t              mez_timer;
};

/*
    Mob index for OLC and creating new instances.
 */
struct mob_index_data
{
    Area *          area; /* OLC */
    MobIndex *      next;
    SPEC_FUN *      spec_fun;
    Shop *          pShop;
    Affect *        affects;
    int             version;
    Quest *         quests;
    Script *        scripts;
    sh_int          vnum;
    sh_int          group;
    bool            new_format;
    sh_int          count;
    sh_int          killed;
    char *          player_name;
    char *          short_descr;
    char *          long_descr;
    char *          description;
    long            act;
    long            affected_by;
    sh_int          alignment;
    sh_int          level;
    sh_int          hitroll;
    sh_int          hit[3];
    sh_int          mana[3];
    sh_int          damage[3];
    sh_int          ac[4];
    sh_int          dam_type;
    long            off_flags;
    long            imm_flags;
    long            res_flags;
    long            vuln_flags;
    sh_int          start_pos;
    sh_int          default_pos;
    sh_int          sex;
    sh_int          race;
    sh_int          class;
    long            wealth;
    long            form;
    long            parts;
    sh_int          size;
    char *          material;
    int             regen;
    Faction *       factions;
    int             resists[MAX_RESIST];    
    char *          attack_echo;
    char *          death_echo;
    char *          spawn_echo;
};

/*
    Player-character specific data.
*/
struct pc_data
{
    time_t              date_last_level;
    int                 deaths;
    int                 kills;
    long                lost_xp;
    long                pnet;
    long                last_note_read[MAX_NOTES];
    short               start_stat[MAX_STATS];
    short               subrace;
    long                options;
    long                score_options;
    long                auto_options;
    long                color_options;
    long                comm_options;
    long                guild_points;
    time_t              last_pdeath;
    int                 guild_rank;
    struct make_guild * pGuild;
    long                spec_exp;
    short               spec_level;
    short               split;
    short               spec_points;
    int                 security;    /* OLC */ /* Builder security */
    PCData *            next;
    Buffer *            buffer;
    bool                valid;
    char *              pwd;
    char *              bamfin;
    char *              bamfout;
    char *              title;
    char *              note_signature;
    time_t              last_reads[MAX_NOTES];
    time_t              last_note;
    time_t              last_idea;
    time_t              last_penalty;
    time_t              last_news;
    time_t              last_changes;
    int                 perm_base_hit;
    int                 perm_stat_hit;
    int                 perm_stamina;
    sh_int              perm_mana;
    sh_int              perm_move;
    sh_int              true_sex;
    int                 last_level;
    sh_int              condition[4];
    sh_int              skill_mod[MAX_SKILL];
    sh_int              learned[MAX_SKILL];
    sh_int              specialized[MAX_WEAPONS];
    sh_int              last_learned[MAX_SKILL];
    sh_int              profs[MAX_PROFICIENCY];
    sh_int              spells[MAX_SPELL];
    bool                group_known[MAX_GROUP];
    Clan *              clan_invite;
    bool                confirm_delete;
    char *              alias[MAX_ALIAS];
    char *              alias_sub[MAX_ALIAS];
    Object *            bank;
    long                coins_bank[MAX_CURRENCY];
    sh_int              imm_role;
    char                customChannelColor[MAX_CHANNELS];
    char                customSayColor;
    char                customTellColor;
    char                customGTellColor;
    char                customRoundTableColor;
    char                customRTSubColor;
    char *              surname;
    long                clan_flags;
    long                bounty;
    short               worth_columns;
    RtPointers          rtptrs;
    char *              friends[MAX_FRIENDS];
    int                 last_basegain;
    int                 last_statgain;
    int                 last_managain;
    int                 last_movegain;
    int                 last_stamgain;
    int                 last_primegain;
    int                 last_secondgain;
    int                 last_traingain;
    int                 last_skillgain;
    int                 combat_timer;
    int                 eq_list_order[MAX_WEAR];
    char *              consent;
    Journal *           journal;
    int                 recall_vnum;
    long                olc_flags;
    long                pref_flags;
    char *              host;
    Ignore *            ignore_list;
    int                 spell_slots[MAX_SPELL_SLOT];
    time_t              build_deadline;
    char *              build_daymonth;    // used to find the next day you can build
    time_t              deprac[2];
    int                 tzindex;
    char *              email;
    union
    {
        RangerData      ranger;
    } class_info;
};

/*
    Newbie creation data
*/
struct gen_data
{
    NewbieData *next;
    bool        valid;
    int         sex;
    int         race;
    int         class;
    int         subrace;
    int         deity;
    int         weapon_sn;
    char        name[32];
    char        password[32];
    int         state;
    DoFun*      state_func;
    sh_int      stat;
};

/*
    NPC Shopkeepers
 */
#define MAX_TRADE     5

struct shop_data
{
    Shop *    next;                 /* Next shop in list           */
    sh_int    keeper;               /* Vnum of shop keeper mob     */
    sh_int    buy_type [MAX_TRADE]; /* Item types shop will buy    */
    sh_int    profit_buy;           /* Cost multiplier for buying  */
    sh_int    profit_sell;          /* Cost multiplier for selling */
    sh_int    open_hour;            /* First opening hour          */
    sh_int    close_hour;           /* First closing hour          */
};

/*
    Groups of players.
 */
#define MAX_PLAYERS_IN_GROUP    8
#define MAX_PLAYER_IN_GROUP     MAX_PLAYERS_IN_GROUP

struct pgroup_type
{
    Group      *next;
    bool       valid;
    Character  *members[MAX_PLAYERS_IN_GROUP];
};

/*
    Melee damage tracking for 'hate' lists
*/
#define DISPOS_PASSIVE        0
#define DISPOS_ALERT          1
#define DISPOS_ACTIVE         2
#define DISPOS_HOSTILE        3
#define DISPOS_AGGRESSIVE     4
#define DISPOS_SEARCHING      5

struct melee_type
{
    Melee     *next;
    bool      valid;
    Group     *group;
    long      damage;
    short     timer;
    int       disposition;
};

/* memory settings */
#define MEM_CUSTOMER            A
#define MEM_SELLER              B
#define MEM_HOSTILE             C
#define MEM_AFRAID              D

/* memory for mobs */
struct mem_data
{
    NPCMemory *          next;
    bool                valid;
    int                 id;
    int                 reaction;
    time_t              when;
};

/*
    Functions dealing with characters
*/
bool knowsRecipe( Character *ch, Recipe *rec );
bool doneQuest( Character *ch, Quest *q );

/*
    ACT Flags
*/
#define ACT_IS_NPC              (A)        /* Auto set for mobs    */
#define ACT_SENTINEL            (B)        /* Stays in one room    */
#define ACT_SCAVENGER           (C)        /* Picks up objects    */
#define ACT_BANKER              (D)
#define ACT_GUARD               (E)
#define ACT_AGGRESSIVE          (F)            /* Attacks PC's        */
#define ACT_STAY_AREA           (G)        /* Won't leave area    */
#define ACT_WIMPY               (H)
#define ACT_PET                 (I)        /* Auto set for pets    */
#define ACT_TRAIN               (J)        /* Can train PC's    */
#define ACT_YELL                (K)     /* will yell for help */
#define ACT_REGISTRAR           (L)
#define ACT_MOUNT               (M)
#define ACT_NOEXP               (N)
#define ACT_NOALIGN             (U)
#define ACT_NOPURGE             (V)
#define ACT_OUTDOORS            (W)
#define ACT_INDOORS             (Y)
#define ACT_NOCLASS             (Z)
#define ACT_IS_HEALER           (aa)
#define ACT_TELEPORTER          (bb)
#define ACT_UPDATE_ALWAYS       (cc)
#define ACT_SMITHY              (dd)

/*
    PLR Flags
*/
#define PLR_IS_NPC                  (A)
#define PLR_IS_CASTING              (B)
#define PLR_IS_CRAFTING             (I)
#define PLR_TEAM_LEAD               (J)
#define PLR_NONCLAN                 (K)
#define PLR_IS_PLAYING              (L)
#define PLR_IS_FIRING               (S)
#define PLR_PERMIT                  (U)
#define PLR_LOG                     (W)
#define PLR_DENY                    (X)
#define PLR_FREEZE                  (Y)
#define PLR_THIEF                   (Z)
#define PLR_KILLER                  (aa)
#define PLR_BUILDER                 (bb)
#define PLR_AUTOSKIN                (dd)


/*
    Alignments
*/
#define ALIGN_GOOD          0
#define ALIGN_EVIL          1
#define ALIGN_NEUTRAL       2

/*
    Gender defines
*/
#define SEX_NEUTRAL              0
#define SEX_MALE                 1
#define SEX_FEMALE               2

/*
    Hunger/Thirst
*/
#define COND_DRUNK                  0
#define COND_FULL                   1
#define COND_THIRST                 2
#define COND_HUNGER                 3

/*
    Positions
*/
#define POS_DEAD                    0
#define POS_MORTAL                  1
#define POS_INCAP                   2
#define POS_STUNNED                 3
#define POS_SLEEPING                4
#define POS_RESTING                 5
#define POS_SITTING                 6
#define POS_FIGHTING                7
#define POS_STANDING                8


/*
    Character macros
*/
#define applyLevelDifference(L1,L2) ((((L1)-(L2))*((L1)-(L2)))*((L2)>(L1))?-1:1)
#define REUSE_ABIL(ch,sn)           (check_reuse_wait(ch,sn,AFF_ABIL))
#define REUSE_SKILL(ch,sn)          (check_reuse_wait(ch,sn,AFF_SKILL))
#define REUSE_SPELL(ch,sn)          (check_reuse_wait(ch,sn,AFF_SPELL))
#define REUSE_LINE(ch,sn)           (check_reuse_line(ch,sn))
#define money_total(ch)             _money_total(ch)
#define apply_stat(ch,stat)         ((get_curr_stat((ch),(stat)) - 100) / 2)
#define IS_NPC(ch)                  (IS_SET((ch)->act, ACT_IS_NPC))
#define IS_IMMORTAL(ch)             (get_trust(ch) >= LEVEL_IMMORTAL)
#define IS_HERO(ch)                 (get_trust(ch) >= LEVEL_HERO)
#define IS_TRUSTED(ch,level)        (get_trust((ch)) >= (level))
#define IS_AFFECTED(ch, sn)         (IS_SET((ch)->affected_by, (sn)))
#define GET_AGE(ch)                 ((int)(17 + ((ch)->played + current_time - (ch)->logon )/72000))
#define is_leader(ch, group)        ((group)->members[0] == (ch))
#define IS_GOOD(ch)                 (deity_table[IS_NPC(ch)?ch->pIndexData->alignment:ch->deity].align == ALIGN_GOOD)
#define IS_EVIL(ch)                 (deity_table[IS_NPC(ch)?ch->pIndexData->alignment:ch->deity].align == ALIGN_EVIL)
#define IS_NEUTRAL(ch)              (!IS_GOOD(ch) && !IS_EVIL(ch))
#define IS_AWAKE(ch)                (ch->position > POS_SLEEPING)
#define GET_AC(ch,type)             get_ac(ch,type)
#define HAS_DISP(ch,disp)           (IS_NPC(ch)?FALSE:IS_SET((ch)->pcdata->display,(disp)))
#define HAS_PROF(ch,psn)            (psn>MAX_PROFICIENCY?FALSE:(IS_NPC(ch)?TRUE:ch->pcdata->profs[(psn)]))
#define GET_HITROLL(ch)             ((ch)->hitroll)
#define GET_DAMROLL(ch)             get_damroll(ch)
#define IS_OUTSIDE(ch)              (!IS_SET((ch)->in_room->room_flags,ROOM_INDOORS))
#define WAIT_STATE(ch, npulse)      ((ch)->wait = UMAX((ch)->wait, (npulse)))
#define DAZE_STATE(ch, npulse)      (dazeState(ch,npulse))
#define get_carry_weight(ch)        ((ch)->carry_weight + _coin_weight(ch))
#define get_char_world(ch,arg)      (find_character((ch),(arg),FALSE))
#define get_char_ooc(ch,arg)        (find_character((ch),(arg),TRUE))
#define PERS(ch, looker)            pers(ch,looker)
#define PERS_OOC(ch,looker)         pers_ooc(ch,looker)

#endif /* character_h */
