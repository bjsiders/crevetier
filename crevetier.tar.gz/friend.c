/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "thoc.h"

void do_friend(Character *ch, char *argument)
{
  Character *rch;
  char arg[MAX_INPUT_LENGTH],buf[MAX_STRING_LENGTH];
  int pos;
  bool friend_found = FALSE;
  
  smash_tilde(argument);
  
  if (ch->desc == NULL)
    rch = ch;
  else
    rch = ch->desc->original ? ch->desc->original : ch;
  
  /* NPC's can't have friends, poor bastards */
  if (IS_NPC(rch))
    return;
  
  argument = one_argument(argument,arg);

  /* Friend with no arguments lists the players current friends */
  if (arg[0] == '\0')
  {
    if (rch->pcdata->friends[0] == NULL)
    {
      send_to_char("You have no friends.\n\r",ch);
      return;
    }
    
    send_to_char("Your current friends are:\n\r",ch);
    
    for (pos = 0; pos < MAX_FRIENDS; pos++)
    {
      if (rch->pcdata->friends[pos] == NULL)
        break;
      
      sprintf(buf,"    %s\n\r",rch->pcdata->friends[pos]);
      send_to_char(buf,ch);
    }
    return;
  }
  
  /* Capitalize the name */
  arg[0] = UPPER(arg[0]);

  /* See if this person is already defined as a friend, if so remove them as a friend */
  for (pos = 0; pos < MAX_FRIENDS; pos++)
  {
    if (rch->pcdata->friends[pos] == NULL)
      break;
    
    /* If a matching friend was already found, bump the other friends up in the list */
    if (friend_found)
    {
      rch->pcdata->friends[pos-1]	= rch->pcdata->friends[pos];
      rch->pcdata->friends[pos]	= NULL;
      continue;
    }
    
    /* If match found, remove friend */
    if(!strcmp(arg,rch->pcdata->friends[pos]))
    {
      send_to_char("Friend removed.\n\r",ch);
      free_string(rch->pcdata->friends[pos]);
      rch->pcdata->friends[pos] = NULL;
      friend_found = TRUE;
    }
  }
  
  /* If we have removed the friend we are done, so return */ 
  if (friend_found)
    return;
  
  if (pos >= MAX_FRIENDS)
  {
    send_to_char("Sorry, you have reached your maximum number of friends.\n\r",ch);
    return;
  }
  
  /* Make a new friend */
  rch->pcdata->friends[pos]		= str_dup(arg);
  if(IS_SET(ch->gui,GUI_FRIENDS))
	sprintf(buf,"<FriendsAddSuccess>%s has been added as your friend.\n\r",arg);
  else
    sprintf(buf,"%s has been added as your friend.\n\r",arg);
  send_to_char(buf,ch);

}
