#ifndef npc_ai_h
#define npc_ai_h

#define DECLARE_SPEC_FUN( fun )     SPEC_FUN  fun

struct spec_type
{
    char *         name;            // special function name
    SPEC_FUN *     function;        // the function
};

struct script_type
{
    Script *        next;
    ScriptIndex *   pIndexData;
    bool            valid;
    char*           name;
    int             priority;
    long            trigger;
    char *          direct_object;
    Character *     trigger_char;
    Object *        trigger_obj;
    char *          script;
};

struct script_index_type
{
    int             vnum;
    Area *          area;
    ScriptIndex *   next;
    char *          name;
    int             priority;
    long            trigger;
    char *          direct_object;
    char *          script;
    int             count;
};

/*
    Script-related defines
*/
#define TRIG_CHAR_ENTERS            (A)
#define TRIG_CHAR_SPEAKS            (B)
#define TRIG_CHAR_LEAVES            (C)
#define TRIG_CHAR_ATTACKS           (D)
#define TRIG_CHAR_FLEES             (E)
#define TRIG_CHAR_GIVES             (F)

extern const struct spec_type       spec_table[];

#endif /* npc_ai_h */
