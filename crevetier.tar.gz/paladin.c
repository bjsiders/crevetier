/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/** System Include Files **/
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/** Custom Header Files **/
#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "tables.h"
#include "recycle.h"

bool paladin_postcurve(int sn,int level,Character *ch,Character *victim,int dur,int amount)
{
    Affect af;   

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(dur);
    af.location  = APPLY_HITROLL;
    af.modifier  = amount;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your accuracy is improved by divine assistance.",victim,NULL,NULL,TO_CHAR);
	act("$n's accuracy is improved by divine assistance.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_eye_of_raselvier(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;

	return paladin_postcurve(sn,level,ch,victim,5,3);
}

bool spell_eye_of_reselvier(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_postcurve(sn,level,ch,victim,8,6);
}

bool spell_eye_of_riselvier(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_postcurve(sn,level,ch,victim,11,10);
}

bool spell_eye_of_roselvier(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_postcurve(sn,level,ch,victim,14,15);
}

bool spell_eye_of_ruselvier(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_postcurve(sn,level,ch,victim,19,21);
}

bool spell_eye_of_ryselvier(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_postcurve(sn,level,ch,victim,24,28);
}

bool paladin_ac(int sn,int level,Character *ch,Character *victim,int dur,int amt)
{
    Affect af;    

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(dur);
    af.location     = APPLY_AC;
    af.modifier     = amt;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are protected by a divine aura.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N is protected by divine aura.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_aura_of_protection(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_ac(sn,level,ch,victim,9,22);
}

bool spell_aura_of_deflection(int sn,int level,Character *ch,void *vo,int target) 
{
    Character *victim = (Character *) vo;

    return paladin_ac(sn,level,ch,victim,15,37);
}  

bool spell_aura_of_safety(int sn,int level,Character *ch,void *vo,int target) 
{
    Character *victim = (Character *) vo;

    return paladin_ac(sn,level,ch,victim,22,55);
}  

bool spell_aura_of_defense(int sn,int level,Character *ch,void *vo,int target) 
{
    Character *victim = (Character *) vo;

    return paladin_ac(sn,level,ch,victim,30,75);
}  

bool spell_aura_of_invincibility(int sn,int level,Character *ch,void *vo,int target) 
{
    Character *victim = (Character *) vo;

    return paladin_ac(sn,level,ch,victim,39,97);
}  

bool spell_aura_of_salvation(int sn,int level,Character *ch,void *vo,int target) 
{
    Character *victim = (Character *) vo;

    return paladin_ac(sn,level,ch,victim,59,122);
}  

bool paladin_damroll(int sn,int level,Character *ch,Character *victim,int dur,int amount)
{
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(dur);
    af.location  = APPLY_DAMROLL;
    af.modifier  = amount;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your enemies will suffer greater punishment at your strike.",victim,NULL,NULL,TO_CHAR);
	act("$n surges with heightened power!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_battle_lust(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_damroll(sn,level,ch,victim,5,2);
}

bool spell_battle_fervor(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_damroll(sn,level,ch,victim,8,4);
}

bool spell_battle_vigor(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_damroll(sn,level,ch,victim,12,8);
}

bool spell_battle_anger(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_damroll(sn,level,ch,victim,16,15);
}

bool spell_battle_fury(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_damroll(sn,level,ch,victim,20,25);
}

bool spell_battle_zeal(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_damroll(sn,level,ch,victim,25,40);
}

bool paladin_weapon_sk(int sn,int level,Character *ch,Character *victim,int dur,int amount)
{
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(dur);
    af.location  = APPLY_SKILL;
    af.modifier  = amount;
	af.misc		 = get_weapon_sn( victim,GET_WEAPON_SN );
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your skill with your weapon is enhanced by the gods!",victim,NULL,NULL,TO_CHAR);
    act("$n swings $s weapon with newfound talent.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_blade_of_amitre(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_weapon_sk(sn,level,ch,victim,6,1);
}

bool spell_blade_of_emitre(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_weapon_sk(sn,level,ch,victim,9,2);  
}

bool spell_blade_of_imitre(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_weapon_sk(sn,level,ch,victim,12,3);
}

bool spell_blade_of_omitre(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_weapon_sk(sn,level,ch,victim,16,4);
}

bool spell_blade_of_umitre(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_weapon_sk(sn,level,ch,victim,21,5);
}

bool paladin_defense_sk(int sn,int level,Character *ch,Character *victim,int dur,int amount)
{
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(dur);
    af.location  = APPLY_SKILL;
    af.modifier  = amount;
    af.misc      = gsn_parry;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
	if ( get_skill(victim,gsn_parry) >= 1 )
    	spellAffectToChar( victim, &af );

	af.misc		= gsn_dodge;
	if ( get_skill(victim,gsn_dodge) >= 1 )
		spellAffectToChar( victim, &af );

    act("Your defensive abilities are augmented by the gods!",victim,NULL,NULL,TO_CHAR);
	if ( victim != ch )
		act("$N's defensive abilities are augmented.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_ossas_defense(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_defense_sk(sn,level,ch,victim,7,1);
}

bool spell_osses_defense(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_defense_sk(sn,level,ch,victim,10,2);
}

bool spell_ossis_defense(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_defense_sk(sn,level,ch,victim,14,3);
}

bool spell_ossos_defense(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_defense_sk(sn,level,ch,victim,18,4);
}

bool spell_ossus_defense(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    return paladin_defense_sk(sn,level,ch,victim,22,5);
}
