#ifndef defines_h
#define defines_h

/*
    Establish definition of boolean values.
    This is more consistant with C ideas of boolean truth than
    0/1.
*/
 
#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE (!FALSE)
#endif

/*
    Used in functions that may or may not echo feedback to the
    player, but whose side affects are desired.
*/
#define ECHO_ON     TRUE
#define ECHO_OFF    FALSE

/*
    Memory managment macros, we use Boehm's garbage collector.
*/
#define free(x)          GC_FREE(x)
#define calloc(x,y)      GC_MALLOC((x)*(y))
#define malloc(x)        GC_MALLOC(x)

/*
    Generic utility macros for scalar, string, and vector crunching.
*/
#define UMIN(a, b)              ((a) < (b) ? (a) : (b))
#define UMAX(a, b)              ((a) > (b) ? (a) : (b))
#define URANGE(a, b, c)         ((b) < (a) ? (a) : ((b) > (c) ? (c) : (b)))
#define LOWER(c)                ((c) >= 'A' && (c) <= 'Z' ? (c)+'a'-'A' : (c))
#define UPPER(c)                ((c) >= 'a' && (c) <= 'z' ? (c)+'A'-'a' : (c))
#define IS_VOWEL(c)             (LOWER(c) == 'a' || LOWER(c) == 'e' || LOWER(c) == 'i' || LOWER(c) == 'o' || LOWER(c) == 'u')
#define IS_SET(flag, bit)       ((flag) & (bit))
#define SET_BIT(var, bit)       ((var) |= (bit))
#define REMOVE_BIT(var, bit)    ((var) &= ~(bit))
#define TOGGLE_BIT(var, bit)    ((var) ^= (bit))

/*
    String and memory management parameters.
*/
#define MAX_KEY_HASH        1024
#define MAX_STRING_LENGTH   4608
#define MAX_INPUT_LENGTH    256
#define MAX_FILENAME        256
#define MAX_BUFFER_SIZE     (2<<15) 
#define PAGELEN             22
#define MAGIC_NUM           52571214
#define MAX_STRING          4413120
#define MAX_MEM_LIST        11
#define MSL MAX_STRING_LENGTH
#define MIL MAX_INPUT_LENGTH

/*
    File and directory parameters
*/
#define getDirectory(x)         (getenv(#x) != NULL ? getenv(#x) : x)
#define NULL_FILE           "/dev/null"
#define GAME_DIR            "/mud/crevetier/"
#define PLAYER_DIR          GAME_DIR "player/"
#define DATA_DIR            GAME_DIR "data/"
#define SPELL_DIR           GAME_DIR "spells/"
#define AREA_DIR            GAME_DIR "world/"
#define LOG_DIR             GAME_DIR "log/"
#define BOARD_DIR           GAME_DIR "board/"
#define TMP_DIR             GAME_DIR "tmp/"
#define WEB_DIR             "/var/www/crevetier/new3/admin/audits/"
#define HELP_DIR            GAME_DIR "helps/"
#define BIN_DIR             GAME_DIR "bin/"
#define LIB_DIR             GAME_DIR "lib/"

/*
    Data validation
*/
#define IS_VALID(data)          ((data) != NULL && (data)->valid)
#define VALIDATE(data)          ((data)->valid = TRUE)
#define INVALIDATE(data)        ((data)->valid = FALSE)

/*
    Array definition macros
*/
#define MAX_CLASS           16

/*
 * Data files used by the server.
 *
 * AREA_LIST contains a list of areas to boot.
 * All files are read in completely at bootup.
 * Most output files (bug, idea, typo, shutdown) are append-only.
 *
 * The NULL_FILE is held open so that we have a stream handle in reserve,
 *   so players can go ahead and telnet to all the other descriptors.
 * Then we close it whenever we need to open a file (e.g. a save file).
 */

#define GAME_DIR        "/mud/crevetier/"
#define PLAYER_DIR      GAME_DIR "player/"
#define DATA_DIR        GAME_DIR "data/"
#define SPELL_DIR       GAME_DIR "spells/"
#define AREA_DIR        GAME_DIR "world/"
#define LOG_DIR         GAME_DIR "log/"
#define BOARD_DIR       GAME_DIR "board/"
#define TMP_DIR         GAME_DIR "tmp/"
#define WEB_DIR         "/var/www/crevetier/new3/admin/audits/"
#define HELP_DIR        GAME_DIR "helps/"
#define BIN_DIR         GAME_DIR "bin/"
#define LIB_DIR         GAME_DIR "lib/"

#if defined(unix)

#if defined(__TEST)
#undef  SPELL_DIR
#define SPELL_DIR       GAME_DIR "spells/test/"
#define PID_FILE        getFileName( DATA_DIR, "arpens-test.pid" )
#define BIN_IMAGE       getFileName( BIN_DIR, "arpenstest" )
#define BIN_NAME        "ArpensTEST"
#define SERVICE_NAME    "arpens-test"
#define SHLIB_DIR       LIB_DIR "test/"
#define RACE_FILE       getFileName( DATA_DIR, "race-avail-test.dat" )
#elif defined(__ARPENS)
#define PID_FILE        getFileName( DATA_DIR, "arpens-game.pid" )
#define BIN_IMAGE       getFileName( BIN_DIR, "arpens" )
#define BIN_NAME        "ArpensMUD"
#define SERVICE_NAME    "arpens-game"
#define SHLIB_DIR       LIB_DIR "game/"
#define RACE_FILE       getFileName( DATA_DIR, "race-avail.dat" )
#elif defined(__OLC)
#undef  SPELL_DIR
#define SPELL_DIR       GAME_DIR "spells/olc/"
#define PID_FILE        getFileName( DATA_DIR, "arpens-olc.pid" )
#define BIN_IMAGE       getFileName( BIN_DIR, "arpensolc" )
#define BIN_NAME        "ArpensOLC"
#define SERVICE_NAME    "arpens-olc"
#define SHLIB_DIR       LIB_DIR "olc/"
#define RACE_FILE       getFileName( DATA_DIR, "race-avail-olc.dat" )
#else
#define PID_FILE        getFileName( DATA_DIR, "arpens-broken.pid" )
#define BIN_IMAGE       getFileName( BIN_DIR, "arpensbroken" )
#define BIN_NAME        "ArpensBroken"
#define SERVICE_NAME    "arpens-samp"
#define SHLIB_DIR       LIB_DIR "samp/"
#define RACE_FILE       getFileName( DATA_DIR, "race-avail-broken.dat" )
#endif

#define LIBSPELLS       getFileName( SHLIB_DIR, "libspells.so" )
#define TIMEZONE_FILE   getFileName( DATA_DIR,  "timezones.txt" )

#if defined(__TEST)
#define LOAD_FILE       getFileName( DATA_DIR, "load-test.dat" )
#define RESOURCE_FILE   getFileName( DATA_DIR, "resource-test.dat" )
#define BUILDING_FILE   getFileName( DATA_DIR, "buildings-test.dat" )
#elif defined(__OLC)
#define LOAD_FILE       getFileName( DATA_DIR, "load-olc.dat" )
#define RESOURCE_FILE   getFileName( DATA_DIR, "resource-olc.dat" )
#define BUILDING_FILE   getFileName( DATA_DIR, "buildings-olc.dat" )
#elif defined(__ARPENS)
#define LOAD_FILE       getFileName( DATA_DIR, "load.dat" )
#define RESOURCE_FILE   getFileName( DATA_DIR, "resource.dat" )
#define BUILDING_FILE   getFileName( DATA_DIR, "buildings.dat" )
#else
#define LOAD_FILE       getFileName( DATA_DIR, "load-other.dat")
#define RESOURCE_FILE   getFileName( DATA_DIR, "resource-other.dat" )
#define BUILDING_FILE   getFileName( DATA_DIR, "buildings-other.dat" )
#endif

#define HELP_INDEX_FILE getFileName( HELP_DIR, "helps.idx" )
#define ARPENS_FILE     getFileName( DATA_DIR, "arpens.dat" )
#define VAULT_FILE      getFileName( DATA_DIR, "vaults.save" )
#define VAULT_LIST      getFileName( DATA_DIR, "vault.lst" )
#define GUILD_FILE      getFileName( DATA_DIR, "clans.dat" )
#define PROMPT_FILE     getFileName( DATA_DIR, "prompts.pub" )
#define EQORDER_FILE    getFileName( DATA_DIR, "eqorder.pub" )
#define CHANNEL_FILE    getFileName( LOG_DIR,  "channels.log" )
#define DEFAULT_FACTION_FILE    getFileName( DATA_DIR, "faction.def" )
#define TEMP_FILE       getFileName( TMP_DIR, ".romtmp" )
#define NULL_FILE       "/dev/null"        /* To reserve one stream */
#endif

#define FACTION_FILE    getFileName( DATA_DIR, "factions.dat" )
#define REFRESH_FILE    getFileName( DATA_DIR, "refresh.dat" )

#define AREA_LIST       getFileName( DATA_DIR,  "area.lst"  ) /* List of are as*/
#define SPELL_LIST      getFileName( DATA_DIR,  "spells.lst") /* List of sp ells*/
#define TYPO_FILE       getFileName( BOARD_DIR, "typo.txt"  ) /* For 'typo'*/
#define HELPLOG_FILE    getFileName( DATA_DIR,  "help.log"  ) /* failed helps */
#define POLL_FILE       getFileName( DATA_DIR,  "poll.txt"  ) /* polling */
#define NOTE_FILE       "notes.not"
#define IDEA_FILE       "ideas.not"
#define SYSTEM_MSG_FILE "sysmsg.not"
#define PENALTY_FILE    "penal.not"
#define ADMIN_FILE      "admin.not"
#define BUG_FILE        "bug.not"
#define CLAN_FILE       "clans.not"
#define FIX_FILE        "fix.not"
#define TODO_FILE       "todo.not"
#define PATCH_FILE      "patch.not"
#define APPEAL_FILE     "appeal.not"
#define NEWS_FILE       "news.not"
#define CHANGES_FILE    "chang.not"
#define WORLD_FILE      "world.not"
#define OFFLINE_FILE    "offline.not"
#define SHUTDOWN_FILE   getFileName( TMP_DIR,   ".shutdown"  )
#define BAN_FILE        getFileName( DATA_DIR,  "ban.txt"    )
#define MUSIC_FILE      getFileName( DATA_DIR,  "music.txt"  )
#define BACKUP_DIR      AREA_DIR "oldversions/"

/* strings */

#define MXP_BEG "\x03"    /* becomes < */
#define MXP_END "\x04"    /* becomes > */
#define MXP_AMP "\x05"    /* becomes & */

/* characters */

#define MXP_BEGc '\x03'    /* becomes < */
#define MXP_ENDc '\x04'    /* becomes > */
#define MXP_AMPc '\x05'    /* becomes & */

/* constructs an MXP tag with < and > around it */

#define MXPTAG(arg) MXP_BEG arg MXP_END

#define ESC "\x1B"  /* esc character */

#define MXPMODE(arg) ESC "[" #arg "z"

#endif /* defines_h */
