/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/**************************************************************************
 *  File: olc_save.c                                                       *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 *                                                                         *
 *  This code was freely distributed with the The Isles 1.1 source code,   *
 *  and has been used here for OLC - OLC would not be what it is without   *
 *  all the previous coders who released their source code.                *
 *                                                                         *
 ***************************************************************************/

/* OLC_SAVE.C
 * This takes care of saving all the .are information.
 * Notes:
 * -If a good syntax checker is used for setting vnum ranges of areas
 *  then it would become possible to just cycle through vnums instead
 *  of using the iHash stuff and checking that the room or reset or
 *  mob etc is part of that area.
 */

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include "thoc.h"
#include "olc.h"
#include "tables.h"
#include "lookup.h"
#include "db.h"

#define VERSION(x)		(x)

/*
 *  Verbose writes reset data in plain english into the comments
 *  section of the resets.  It makes areas considerably larger but
 *  may aid in debugging.
 */

/*
#define VERBOSE 
*/
void save_spells( Character *ch );
void save_spell( FILE *fp, SpellIndex *spell );

void check_ranged_weapon( ObjIndex *pObj )
{
	int *gsn;
	int range;

	gsn = weapon_table[get_weapon_index(pObj->value[0])].gsn;

	if ( gsn == &gsn_crossbow || gsn == &gsn_shortbow )
		range = 2;
	else
	if ( gsn == &gsn_longbow )
		range = 3;
	else
	if ( gsn == &gsn_composite_longbow )
		range = 4;
	else
		range = 0;

	pObj->value[6] = range;
}

 /* Check for special flags */
void check_twohandedness( ObjIndex *pObj )
{
    if ( weapon_table[get_weapon_index(pObj->value[0])].gsn ==  
            &gsn_1h_concussion )
        REMOVE_BIT( pObj->value[4], WEAPON_TWO_HANDS );
    else
    if ( weapon_table[get_weapon_index(pObj->value[0])].gsn ==  &gsn_2h_concussion ||
         pObj->value[0] == WEAPON_2H_SWORD ||
         pObj->value[0] == WEAPON_2H_WARAXE || 
         pObj->value[0] == WEAPON_2H_WARHAMMER )
	SET_BIT( pObj->value[4], WEAPON_TWO_HANDS );
}

long fixFlags( long vector )
{
	long new = 0;

	if ( vector & (A) )
		new |= (A);
	if ( vector & (B) )
		new |= (T);
	if ( vector & (C) )
		new |= (B);
	if ( vector & (D) )
		new |= (C);
	if ( vector & (E) )
		new |= (D);
	if ( vector & (F) )
		new |= (E);
	if ( vector & (G) )
		new |= (F);
	if ( vector & (H) )
		new |= (G);
	if ( vector & (I) )
		new |= (H);
	if ( vector & (J) )
		new |= (I);
	if ( vector & (K) )
		new |= (N);
	if ( vector & (L) )
		new |= (O);
	if ( vector & (M) )
		new |= (L);
	if ( vector & (N) )
		new |= (L);
	if ( vector & (O) )
		new |= (I);
	if ( vector & (P) )
		new |= (T);
	if ( vector & (Q) )
		new |= (P);
	if ( vector & (R) )
		new |= (K);
	if ( vector & (S) )
		new |= (Q);
	if ( vector & (T) )
		new |= (S);

	return new;
}
	
void save_recipes( FILE *fp, Area *a );
void save_recipe( FILE *fp, Recipe *pRec );
void save_quest( FILE *fp, Quest *pQ );
void save_quests( FILE *fp, Area *a );
void save_scripts( FILE *fp, Area *a );
void save_script( FILE *fp, ScriptIndex *script );

/* Siders 12/July/01 - Backs up filename as:
 * filename.YYMMDD-HHMMSS in /mud/kd9/area/oldversions
 */
void backup( char *area )
{
    char backup_name[80];
	char area_name[80];
    char *p;
    struct tm	*time_tm;
    char time_str[20];

    time_tm = localtime( &current_time );
    strftime(time_str,sizeof(time_str),"%Y%m%d-%H%M%S",time_tm);
    p = area + strlen(area);

    while ( *p != '/' && p > area )
        --p;

    if ( p > area )
       ++p;

    snprintf(backup_name,sizeof(backup_name),"%s%s.%s", getDirectory(BACKUP_DIR), p, time_str );
    snprintf(area_name,sizeof(area_name),"%s%s", getDirectory(AREA_DIR), area );

    if ( rename( area_name, backup_name ) < 0 )
    {
	log_string("Unable to backup %s to %s: %s",area_name,backup_name,strerror(errno));
	return;
    }
}

/*****************************************************************************
 Name:		fix_string
 Purpose:	Returns a string without \r and ~.
 ****************************************************************************/
char *fix_string( const char *str )
{
    static char strfix[MAX_STRING_LENGTH*10];
    int i;
    int o;

    strfix[0]='\0';

    if ( str == NULL || *str == '\0' )
        return '\0';

    for ( o = i = 0; str[i+o] != '\0'; i++ )
    {
        if (str[i+o] == '\r' || str[i+o] == '~')
            o++;
        strfix[i] = str[i+o];
    }
    strfix[i] = '\0';
    return strfix;
}



/*****************************************************************************
 Name:		save_area_list
 Purpose:	Saves the listing of files to be loaded at startup.
 Called by:	do_asave(olc_save.c).
 ****************************************************************************/
void save_area_list()
{
    FILE *fp;
    Area *pArea;

    backup( AREA_LIST );
    if ( ( fp = fopen( AREA_LIST, "w" ) ) == NULL )
    {
	log_bug( "Save_area_list: fopen", 0 );
	log_error( "area.lst" );
    }
    else
    {
	/*
	 * Add any help files that need to be loaded at
	 * startup to this section.
	 */
	/*fprintf( fp, "help.are\n" );*/
	fprintf( fp, "social.are\n" );
	/*fprintf( fp, "clan.are\n" );*/

	for( pArea = area_first; pArea; pArea = pArea->next )
	{
	    fprintf( fp, "%s\n", pArea->filename );
	}

	fprintf( fp, "$\n" );
	fclose( fp );
    }

    return;
}


/*
 * ROM OLC
 * Used in save_mobile and save_object below.  Writes
 * flags on the form fread_flag reads.
 * 
 * buf[] must hold at least 32+1 characters.
 *
 * -- Hugin
 */
char *fwrite_flag( long flags, char buf[] )
{
    char offset;
    char *cp;

    buf[0] = '\0';

    if ( flags == 0 )
    {
	strcpy( buf, "0" );
	return buf;
    }

    /* 32 -- number of bits in a long */

    for ( offset = 0, cp = buf; offset < 32; offset++ )
	if ( flags & ( (long)1 << offset ) )
	{
	    if ( offset <= 'Z' - 'A' )
		*(cp++) = 'A' + offset;
	    else
		*(cp++) = 'a' + offset - ( 'Z' - 'A' + 1 );
	}

    *cp = '\0';

    return buf;
}




/*****************************************************************************
 Name:		save_mobile
 Purpose:	Save one mobile to file, new format -- Hugin
 Called by:	save_mobiles (below).
 ****************************************************************************/
void save_mobile( FILE *fp, MobIndex *pMobIndex )
{
	int i;
    sh_int race = pMobIndex->race;
    char buf[MAX_STRING_LENGTH];

    fprintf( fp, "#%d %d\n",         pMobIndex->vnum, VERSION(3) );
    fprintf( fp, "%s~\n",         pMobIndex->player_name );
    fprintf( fp, "%s~\n",         pMobIndex->short_descr );
    fprintf( fp, "%s~\n",         fix_string( pMobIndex->long_descr ) );
    fprintf( fp, "%s~\n",         fix_string( pMobIndex->description) );

	if ( pMobIndex->spawn_echo == NULL )
		fprintf(fp, "~\n");
	else
		fprintf(fp, "%s~\n", fix_string( pMobIndex->spawn_echo ) );

	if ( pMobIndex->attack_echo == NULL )
		fprintf(fp, "~\n");
	else
		fprintf( fp, "%s~\n",			fix_string( pMobIndex->attack_echo ) );

    if ( pMobIndex->death_echo == NULL )
        fprintf(fp, "~\n");
    else
		fprintf( fp, "%s~\n",			fix_string( pMobIndex->death_echo ) );

    fprintf( fp, "%s~\n",         race_table[race].name );
    fprintf( fp, "%s~\n",	  		class_table[ UMAX(0,pMobIndex->class) ].name );
    fprintf( fp, "%s ",	          fwrite_flag( pMobIndex->act,         buf ) );
    fprintf( fp, "%s ",	          fwrite_flag( pMobIndex->affected_by, buf ) );
    fprintf( fp, "%d 0\n",        URANGE(0,pMobIndex->alignment,MAX_DEITY) );
    fprintf( fp, "%d ",	          UMAX(pMobIndex->level,1) );
    fprintf( fp, "%d ",	          pMobIndex->hitroll );
    fprintf( fp, "%dd%d+%d ",     pMobIndex->hit[DICE_NUMBER], 
	     	     	          pMobIndex->hit[DICE_TYPE], 
	     	     	          pMobIndex->hit[DICE_BONUS] );
    fprintf( fp, "%dd%d+%d ",     pMobIndex->mana[DICE_NUMBER], 
	     	     	          pMobIndex->mana[DICE_TYPE], 
	     	     	          pMobIndex->mana[DICE_BONUS] );
    fprintf( fp, "%dd%d+%d ",     pMobIndex->damage[DICE_NUMBER], 
	     	     	          pMobIndex->damage[DICE_TYPE], 
	     	     	          pMobIndex->damage[DICE_BONUS] );
    fprintf( fp, "%s\n",          attack_table[pMobIndex->dam_type].name);
    fprintf( fp, "%d %d %d %d\n", pMobIndex->ac[AC_PIERCE],
	     	     	          pMobIndex->ac[AC_BASH],
	     	     	          pMobIndex->ac[AC_SLASH],
	     	     	          pMobIndex->ac[AC_EXOTIC] );
    /*fprintf( fp, "%d %d %d %d\n", pMobIndex->level * 4,
				  pMobIndex->level * 4,
				  pMobIndex->level * 4,
				  pMobIndex->level * 3/2 );*/

	/***
     *** Fix their flags 
	pMobIndex->imm_flags = fixFlags( pMobIndex->imm_flags );
	***/

    fprintf( fp, "%s ",           fwrite_flag( pMobIndex->off_flags,  buf ) );
    fprintf( fp, "%s ",	          fwrite_flag( pMobIndex->imm_flags,  buf ) );
    fprintf( fp, "0 "); // res flags
    fprintf( fp, "0\n"); // vul nflags
    fprintf( fp, "%s %s %s %ld\n",
	         position_table[pMobIndex->start_pos].short_name,
	         position_table[pMobIndex->default_pos].short_name,
	         sex_table[pMobIndex->sex].name,
      	     	 pMobIndex->wealth );
	/* temporary measure */
    fprintf( fp, "%s ",           fwrite_flag( pMobIndex->form,  buf ) );

	/*fprintf( fp, "%s ",				fwrite_flag( race_table[pMobIndex->race].form, buf ) );*/

    fprintf( fp, "%s ",      	  fwrite_flag( pMobIndex->parts, buf ) );

    fprintf( fp, "%s ",           size_flags[pMobIndex->size].name );

    for( i = 0 ; i < MAX_RESIST ; i++ )
        fprintf(fp,"%d ", pMobIndex->resists[i] );
	//for( i=0 ; i < MAX_RESIST ; i++ )
		//fprintf(fp,"%d ", race_table[pMobIndex->race].resists[i] );

	fprintf(fp,"\n");

    /* save factions */
    {
        Faction *f;

        for( f = pMobIndex->factions ; f != NULL ; f = f->next )
            fprintf(fp,"F %ld %d %ld %ld\n", f->standing, f->factionID, f->aggroPoint, f->passivePoint );
    }

    fprintf( fp, "none\n" );          

    return;
}


/*****************************************************************************
 Name:		save_mobiles
 Purpose:	Save #MOBILES secion of an area file.
 Called by:	save_area(olc_save.c).
 Notes:         Changed for ROM OLC.
 ****************************************************************************/
void save_mobiles( FILE *fp, Area *pArea )
{
    int i;
    MobIndex *pMob;

    fprintf( fp, "#MOBILES\n" );

    for( i = pArea->lvnum; i <= pArea->uvnum; i++ )
    {
		if ( (pMob = get_mob_index( i )) )
	    	save_mobile( fp, pMob );
    }

    fprintf( fp, "#0\n\n\n\n" );
    return;
}





/*****************************************************************************
 Name:		save_object
 Purpose:	Save one object to file.
                new ROM format saving -- Hugin
 Called by:	save_objects (below).
 ****************************************************************************/
void save_object( FILE *fp, ObjIndex *pObjIndex, int vnum )
{
    Affect *pAf;
    ExtraDescr *pEd;
    char buf[MAX_STRING_LENGTH];

    fprintf( fp, "#%d %d\n",    pObjIndex->vnum, VERSION(1) ); 
    fprintf( fp, "%s~\n",    pObjIndex->name ); 
    fprintf( fp, "%s~\n",    pObjIndex->short_descr ); 
    fprintf( fp, "%s~\n",    fix_string( pObjIndex->description ) ); 
    fprintf( fp, "%s~\n",    pObjIndex->material ); 
    fprintf( fp, "%s ",      item_name(pObjIndex->item_type) ); 
    fprintf( fp, "%s ",      fwrite_flag( pObjIndex->extra_flags, buf ) ); 
    fprintf( fp, "%s\n",     fwrite_flag( pObjIndex->wear_flags,  buf ) ); 

/*
 *  Using fwrite_flag to write most values gives a strange
 *  looking area file, consider making a case for each
 *  item type later.
 */

    switch ( pObjIndex->item_type )
    {
        default:
	    fprintf( fp, "%s ",  fwrite_flag( pObjIndex->value[0], buf ) );
	    fprintf( fp, "%s ",  fwrite_flag( pObjIndex->value[1], buf ) );
	    fprintf( fp, "%s ",  fwrite_flag( pObjIndex->value[2], buf ) );
	    fprintf( fp, "%s ",  fwrite_flag( pObjIndex->value[3], buf ) );
	    fprintf( fp, "%s\n", fwrite_flag( pObjIndex->value[4], buf ) );
            fprintf( fp,"%d ", pObjIndex->value[5] ); 
            fprintf( fp,"%d ", pObjIndex->value[6] );
            fprintf( fp,"%d ", pObjIndex->value[7] );
            fprintf( fp,"%d ", pObjIndex->value[8] );
            fprintf( fp,"%d\n", pObjIndex->value[9] );

	    break;

	case ITEM_FORGE:
	    fprintf(fp,"%d %d '%s' '%s' 0\n0 0 0 0 0\n",
		pObjIndex->value[0],
		pObjIndex->value[1],
		skill_table[pObjIndex->value[2]].name,
		flag_string( forge_flags, pObjIndex->value[3] ) );
	    break;

	case ITEM_PRAYER_BOOK:
	case ITEM_LYRIC_SHEET:
	case ITEM_ARCANE_SCROLL:
	{
		SpellIndex* pSpellIndex = get_spell_index(pObjIndex->value[0]);

		fprintf(fp,"'%s' %d %d %d %d %d %d 0 0 0\n",
			pObjIndex->value[0] <= 0 ? "none" : (pSpellIndex ? pSpellIndex->name : "none"),
		pObjIndex->value[1],
		pObjIndex->value[2],
		pObjIndex->value[3],
		pObjIndex->value[4],
		pObjIndex->value[5],
		pObjIndex->value[6]  );
	    break;
	}

	case ITEM_SPELLBOOK:
	{
	    int i;
		SpellIndex* pSpellIndex;

	    for (i=0; i<10;i++)
		{
			if ( pObjIndex->value[i] > 0 )
			{
				pSpellIndex = get_spell_index(pObjIndex->value[i]);
				fprintf(fp,"'%s' ", pSpellIndex ? pSpellIndex->name : "0 ");
			}
			else
		    	fprintf(fp,"0 ");
		}

	    fprintf(fp,"\n");
	    break;
	}

        case ITEM_WEAPON:
		check_twohandedness( pObjIndex );
		check_ranged_weapon( pObjIndex );
	    fprintf( fp, "'%s' %d %d %s %s\n",
	    	weapon_name(pObjIndex->value[0]),
		pObjIndex->value[1],
		pObjIndex->value[2],
		attack_table[pObjIndex->value[3]].name,
		fwrite_flag( pObjIndex->value[4], buf ) );

            fprintf( fp,"%d ", pObjIndex->value[5] <= 0 ? 35 : pObjIndex->value[5] );
            fprintf( fp,"%d ", pObjIndex->value[6] );
	    if ( pObjIndex->value[7] > 1 )
		{
			SpellIndex* pSpellIndex = get_spell_index(pObjIndex->value[7]);
			fprintf( fp,"'%s' ", pSpellIndex ? pSpellIndex->name : "0 " );
		}
	    else
		fprintf( fp, "%d ", pObjIndex->value[7] );
            fprintf( fp,"%d ", pObjIndex->value[8] );
            fprintf( fp,"%d\n", pObjIndex->value[9] );


		break;
        case ITEM_LIGHT:
	    fprintf( fp, "0 0 %d 0 0\n",
		     pObjIndex->value[2] < 1 ? 999  /* infinite */
		     : pObjIndex->value[2] );
            fprintf( fp,"%d ", pObjIndex->value[5] );
            fprintf( fp,"%d ", pObjIndex->value[6] );
            fprintf( fp,"%d ", pObjIndex->value[7] );
            fprintf( fp,"%d ", pObjIndex->value[8] );
            fprintf( fp,"%d\n", pObjIndex->value[9] );


	    break;

        case ITEM_PILL:
        case ITEM_POTION:
        case ITEM_SCROLL:
		{
			SpellIndex* pSpellIndex1;
			SpellIndex* pSpellIndex2;
			SpellIndex* pSpellIndex3;
			pSpellIndex1 = get_spell_index(pObjIndex->value[1]);
			pSpellIndex2 = get_spell_index(pObjIndex->value[2]);
			pSpellIndex3 = get_spell_index(pObjIndex->value[3]);

			fprintf( fp, "%d '%s' '%s' '%s' %d\n",
		     pObjIndex->value[0] > 0 ? pObjIndex->value[0] : 0,
			 pObjIndex->value[1] != -1 ?  (pSpellIndex1 ? pSpellIndex1->name : "0") : "0",
		     pObjIndex->value[2] != -1 ?  (pSpellIndex2 ? pSpellIndex2->name : "0") : "0",
		     pObjIndex->value[3] != -1 ?  (pSpellIndex3 ? pSpellIndex3->name : "0") : "0",
		     0 /* unused */ );
            fprintf( fp,"%d ", pObjIndex->value[5] );
            fprintf( fp,"%d ", pObjIndex->value[6] );
            fprintf( fp,"%d ", pObjIndex->value[7] );
            fprintf( fp,"%d ", pObjIndex->value[8] );
            fprintf( fp,"%d\n", pObjIndex->value[9] );
		}
	    break;

		case ITEM_MOBILE:
        case ITEM_CONTAINER:
	    fprintf( fp, "%d %s %d %d %d\n",
			pObjIndex->value[0],
			fwrite_flag(pObjIndex->value[1], buf),
			pObjIndex->value[2],
			pObjIndex->value[3],
			pObjIndex->value[4]);
            fprintf( fp,"%d ", pObjIndex->value[5] );
            fprintf( fp,"%d ", pObjIndex->value[6] );
            fprintf( fp,"%d ", pObjIndex->value[7] );
            fprintf( fp,"%d ", pObjIndex->value[8] );
            fprintf( fp,"%d\n", pObjIndex->value[9] );


		break;
		
        case ITEM_FOUNTAIN:
	case ITEM_DRINK_CON:
	    fprintf( fp, "%d %d '%s' %d %d\n",
			pObjIndex->value[0],
			pObjIndex->value[1],
			liq_table[pObjIndex->value[2]].liq_name,
			pObjIndex->value[3],
			pObjIndex->value[4] );
            fprintf( fp,"%d ", pObjIndex->value[5] );
            fprintf( fp,"%d ", pObjIndex->value[6] );
            fprintf( fp,"%d ", pObjIndex->value[7] );
            fprintf( fp,"%d ", pObjIndex->value[8] );
            fprintf( fp,"%d\n", pObjIndex->value[9] );


	    break;

	case ITEM_ARMOR:
		fprintf( fp,"%d ", pObjIndex->value[0] );
		fprintf( fp,"%d ", pObjIndex->value[1] );
		fprintf( fp,"%d ", pObjIndex->value[2] );
		fprintf( fp,"%d ", pObjIndex->value[3] );
		fprintf( fp,"%d\n", pObjIndex->value[4] );
		fprintf( fp,"%d ", pObjIndex->value[5] );
		fprintf( fp,"%d ", pObjIndex->value[6] );
		fprintf( fp,"%d ", pObjIndex->value[7] );
		fprintf( fp,"%d ", pObjIndex->value[8] );
		fprintf( fp,"%d ", pObjIndex->value[9] );
		break;

/*
 	case ITEM_ARMOR:
	    fprintf( fp,"%d ", pObjIndex->level );
	    fprintf( fp,"%d ", pObjIndex->level );
	    fprintf( fp,"%d ", pObjIndex->level );
	    fprintf( fp,"%d ", pObjIndex->level/5 );
	    fprintf( fp,"0 0 0 0 0 0\n");
	    break;*/

        case ITEM_STAFF:
        case ITEM_WAND:
	    fprintf( fp, "%d ", pObjIndex->value[0] );
	    fprintf( fp, "%d ", pObjIndex->value[1]);
	    fprintf( fp, "%d ", pObjIndex->value[2]);
	    fprintf( fp, "'%s' ", skill_table[UMAX(0,pObjIndex->value[3])].name);
	    fprintf( fp, "%d\n", pObjIndex->value[4]);
            fprintf( fp,"%d ", pObjIndex->value[5] );
            fprintf( fp,"%d ", pObjIndex->value[6] );
            fprintf( fp,"%d ", pObjIndex->value[7] );
            fprintf( fp,"%d ", pObjIndex->value[8] );
            fprintf( fp,"%d\n", pObjIndex->value[9] );

	    break;
    }

    fprintf( fp, "%d ", pObjIndex->level );
    fprintf( fp, "%d ", pObjIndex->weight );
    fprintf( fp, "%ld ", pObjIndex->cost );

/*
         if ( pObjIndex->condition >  90 ) letter = 'P';
    else if ( pObjIndex->condition >  75 ) letter = 'G';
    else if ( pObjIndex->condition >  50 ) letter = 'A';
    else if ( pObjIndex->condition >  25 ) letter = 'W';
    else if ( pObjIndex->condition >  10 ) letter = 'D';
    else if ( pObjIndex->condition >   0 ) letter = 'B';
    else                                   letter = 'R';
*/


    fprintf( fp, "%d %d %d\n", 
			pObjIndex->condition,
			pObjIndex->durability,
			pObjIndex->quality );

	fprintf( fp, "%s~\n", pObjIndex->deity <= 0 ? "0" : deity_table[ pObjIndex->deity ].name );

    for( pAf = pObjIndex->affected; pAf; pAf = pAf->next )
    {
        fprintf( fp, "A\n%d %d '%s'\n",  
			pAf->location, 
			pAf->modifier, 
			pAf->misc > 0 ? skill_table[pAf->misc].name : "0" );
    }

    for( pEd = pObjIndex->extra_descr; pEd; pEd = pEd->next )
    {
        fprintf( fp, "E\n%s~\n%s~\n", pEd->keyword,
		 fix_string( pEd->description ) );
    }

	// Write out artifact information
	if ( pObjIndex->artifact != NULL )
	{

	}
    return;
}
 



/*****************************************************************************
 Name:		save_objects
 Purpose:	Save #OBJECTS section of an area file.
 Called by:	save_area(olc_save.c).
 Notes:         Changed for ROM OLC.
 ****************************************************************************/
void save_objects( FILE *fp, Area *pArea )
{
    int i;
    ObjIndex *pObj;

    fprintf( fp, "#OBJECTS\n" );

    for( i = pArea->lvnum; i <= pArea->uvnum; i++ )
    {
		if ( (pObj = get_obj_index( i )) )
	    	save_object( fp, pObj, pObj->vnum );
    }

    fprintf( fp, "#0\n\n\n\n" );
    return;
}
 




/*****************************************************************************
 Name:		save_rooms
 Purpose:	Save #ROOMS section of an area file.
 Called by:	save_area(olc_save.c).
 ****************************************************************************/
void save_rooms( FILE *fp, Area *pArea )
{
    Room *pRoomIndex;
    ExtraDescr *pEd;
    Exit *pExit;
    int iHash;
    int door;

    fprintf( fp, "#ROOMS\n" );
    for( iHash = 0; iHash < MAX_KEY_HASH; iHash++ )
    {
        for( pRoomIndex = room_index_hash[iHash]; pRoomIndex; pRoomIndex = pRoomIndex->next )
        {
            if ( pRoomIndex->area == pArea )
            {
                fprintf( fp, "#%d %d\n",	pRoomIndex->vnum, VERSION(1) );
                fprintf( fp, "%s~\n",		pRoomIndex->name );
                fprintf( fp, "%s~\n",		fix_string( pRoomIndex->description ) );
		fprintf( fp, "0 " );
                fprintf( fp, "%d ",		pRoomIndex->room_flags );
                fprintf( fp, "%d\n",		pRoomIndex->sector_type );
				fprintf( fp, "%d\n",		pRoomIndex->terrain );

		if ( pRoomIndex->heal_rate > 0 )
		    fprintf(fp, "H %d\n", pRoomIndex->heal_rate );
		
		if ( pRoomIndex->mana_rate > 0 )
		    fprintf(fp, "M %d\n", pRoomIndex->mana_rate );

		if ( pRoomIndex->clan > 0 )
		    fprintf(fp, "C %s~\n", pRoomIndex->clan->name );

		if ( pRoomIndex->guild >= 0 && pRoomIndex->guild < 16 )
		    fprintf(fp, "G %s~\n", class_table[pRoomIndex->guild].name);

	  	if ( pRoomIndex->clan <= 0 )
                for ( pEd = pRoomIndex->extra_descr; pEd;
                      pEd = pEd->next )
                {
                    fprintf( fp, "E\n%s~\n%s~\n", pEd->keyword,
                                                  fix_string( pEd->description ) );
                }
                for( door = 0; door < MAX_DIR; door++ )	/* I hate this! */
                {
                    if ( ( pExit = pRoomIndex->exit[door] )
                          && pExit->u1.to_room )
                    {
                        fprintf( fp, "D%d\n",      pExit->orig_door );
                        fprintf( fp, "%s~\n",      fix_string( pExit->description ) );
                        fprintf( fp, "%s~\n",      pExit->keyword );
                        fprintf( fp, "%s %d %d\n", print_flags(pExit->rs_flags),
                                                   pExit->key,
                                                   pExit->u1.to_room->vnum );
                    }
                }
		fprintf( fp, "S\n" );
            }
        }
    }
    fprintf( fp, "#0\n\n\n\n" );
    return;
}



/*****************************************************************************
 Name:		save_specials
 Purpose:	Save #SPECIALS section of area file.
 Called by:	save_area(olc_save.c).
 ****************************************************************************/
void save_specials( FILE *fp, Area *pArea )
{
    int iHash;
    MobIndex *pMobIndex;
    
    fprintf( fp, "#SPECIALS\n" );

    for( iHash = 0; iHash < MAX_KEY_HASH; iHash++ )
    {
        for( pMobIndex = mob_index_hash[iHash]; pMobIndex; pMobIndex = pMobIndex->next )
        {
            if ( pMobIndex && pMobIndex->area == pArea && pMobIndex->spec_fun )
            {
                fprintf( fp, "M %d %s Load to: %s\n", pMobIndex->vnum,
                                                      spec_string( pMobIndex->spec_fun ),
                                                      pMobIndex->short_descr );
            }
        }
    }

    fprintf( fp, "S\n\n\n\n" );
    return;
}

void save_spawn_contents( FILE *fp, Spawn *spawn );
void save_spawn( FILE *fp, Spawn *spawn );

void save_resets( FILE *fp, Area *pArea )
{
    Room *pRoom;
    int iHash;
	Spawn	*spawn;

    fprintf( fp, "#RESETS\n" );

    for( iHash = 0; iHash < MAX_KEY_HASH; iHash++ )
    {
        for( pRoom = room_index_hash[iHash]; pRoom; pRoom = pRoom->next )
        {
            if ( pRoom->area == pArea )
	    	{
    			for ( spawn = pRoom->spawns; spawn ; spawn = spawn->next_in_room )
    			{
					save_spawn( fp, spawn );
					save_spawn_contents( fp, spawn->contains );
				}
			}
		}
	}
    fprintf( fp, "S\n\n\n\n" );
    return;
}

void save_spawn_contents( FILE *fp, Spawn *spawn )
{
	Spawn *s;

	for( s = spawn; s; s = s->next_content )
	{
		save_spawn( fp, s );
		save_spawn_contents( fp, s->contains );
	}
}

void save_spawn( FILE *fp, Spawn *spawn )
{
	switch( toupper(spawn->type) )
	{
		case 'M':
			fprintf(fp,"%d load mob %d room %d ", spawn->index, spawn->source, spawn->target ); break;
		case 'O':
			fprintf(fp,"%d load obj %d room %d ", spawn->index, spawn->source, spawn->target ); break;
		case 'E':
			fprintf(fp,"%d eq obj %d mob %d ", spawn->index, spawn->source, spawn->target ); break;
		case 'I':
			fprintf(fp,"%d inv obj %d mob %d ", spawn->index, spawn->source, spawn->target ); break;
		case 'D':
			fprintf(fp,"%d load door %s room %d ", spawn->index, dir_name[spawn->source], spawn->target ); break;
		case 'P': case 'C':
			fprintf(fp,"%d put obj %d obj %d ", spawn->index, spawn->source, spawn->target ); break;
		case 'Q':
			fprintf(fp,"%d reset quest %d mob %d ", spawn->index, spawn->source, spawn->target ); break;
		case 'S':
			fprintf(fp,"%d reset script %d mob %d ", spawn->index, spawn->source, spawn->target ); break;
		default:
			log_bug("Unknown spawn type %c", spawn->type );
			return;
	}

	if ( toupper(spawn->type) == 'D' )
	{
		if ( spawn->interval != 3 && spawn->interval != 0 )
			fprintf(fp,"int %d ", spawn->interval);
	}
	else
	{
		if ( spawn->interval != 15 && spawn->interval != 0 )
			fprintf(fp,"int %d ", spawn->interval);
	}

	if ( spawn->frequency != 100 && spawn->frequency != 0 )
		fprintf(fp,"freq %d ", spawn->frequency);

	if ( spawn->placeholder > 0 )
		fprintf(fp,"ph %d ", spawn->placeholder);

	if ( spawn->despawn > 0 )
		fprintf(fp,"ds %d ", spawn->despawn );

    switch( toupper(spawn->type) )
    {
        case 'E':
			fprintf(fp,"loc %s ", flag_string( wear_loc_flags, spawn->misc ) ); break;
        case 'D':
			fprintf(fp,"flags %s ", print_flags( spawn->misc ) ); break;
    }

	fprintf(fp,"--\n");
	return;
}

/*****************************************************************************
 Name:		save_shops
 Purpose:	Saves the #SHOPS section of an area file.
 Called by:	save_area(olc_save.c)
 ****************************************************************************/
void save_shops( FILE *fp, Area *pArea )
{
    Shop *pShopIndex;
    MobIndex *pMobIndex;
    int iTrade;
    int iHash;
    
    fprintf( fp, "#SHOPS\n" );

    for( iHash = 0; iHash < MAX_KEY_HASH; iHash++ )
    {
        for( pMobIndex = mob_index_hash[iHash]; pMobIndex; pMobIndex = pMobIndex->next )
        {
            if ( pMobIndex && pMobIndex->area == pArea && pMobIndex->pShop )
            {
                pShopIndex = pMobIndex->pShop;

                fprintf( fp, "%d ", pShopIndex->keeper );
                for ( iTrade = 0; iTrade < MAX_TRADE; iTrade++ )
                {
                    if ( pShopIndex->buy_type[iTrade] != 0 )
                    {
                       fprintf( fp, "%d ", pShopIndex->buy_type[iTrade] );
                    }
                    else
                       fprintf( fp, "0 ");
                }
                fprintf( fp, "%d %d ", pShopIndex->profit_buy, pShopIndex->profit_sell );
                fprintf( fp, "%d %d\n", pShopIndex->open_hour, pShopIndex->close_hour );
            }
        }
    }

    fprintf( fp, "0\n\n\n\n" );
    return;
}



/*****************************************************************************
 Name:		save_area
 Purpose:	OLC interface to save this area
 Called by:	do_asave(olc_save.c).
 ****************************************************************************/
void save_area( Area *pArea )
{
	extern void saveAreaFile( Area *pArea );

    // We don't save all areas - specifically we never save clanhalls
    // because we might clobber them on OLC after they're made on main.
    if ( IS_SET(pArea->area_flags,AREA_NOASAVE) )
        return;

	saveAreaFile( pArea );
}

// General interface for saving clan halls
void saveAreaFile( Area *pArea )
{
    FILE *fp;
	char	filename[MAX_STRING_LENGTH];
    ExtraDescr *pEd;

    backup( pArea->filename );
    fclose( fpReserve );

	snprintf( filename, sizeof(filename), "%s%s", getDirectory(AREA_DIR), pArea->filename );
    if ( !( fp = fopen( filename, "w" ) ) )
    {
		log_bug( "Open_area: fopen", 0 );
		log_error( pArea->filename );
		return;
    }

    fprintf( fp, "#AREADATA\n" );
    fprintf( fp, "Name        %s~\n",        pArea->name );
    fprintf( fp, "Builders    %s~\n",        fix_string( pArea->builders ) );
    fprintf( fp, "VNUMs       %d %d\n",      pArea->lvnum, pArea->uvnum );
    fprintf( fp, "Security    %d\n",         pArea->security );
	fprintf( fp, "Levels      %d %d\n",		pArea->llevel, pArea->ulevel );
    fprintf( fp, "Credits     [%2d-%2d] [%-32s] [%s]~\n",
		pArea->llevel, pArea->ulevel, pArea->name, pArea->builders );
	fprintf( fp, "Hide        %d\n",		pArea->hide_area );
    fprintf( fp, "XP          %d\n",        pArea->exp_mod );

    for( pEd = pArea->echoes; pEd; pEd = pEd->next )
    {
        fprintf( fp, "E\n%s~\n%s~\n", pEd->keyword,
         fix_string( pEd->description ) );
    }

	fprintf( fp, "End\n\n\n\n" );
    save_mobiles( fp, pArea );
    save_objects( fp, pArea );
    save_rooms( fp, pArea );
	save_quests( fp, pArea );
    save_specials( fp, pArea );
    save_resets( fp, pArea );
    save_shops( fp, pArea );
	save_recipes( fp, pArea );
	save_scripts( fp, pArea );

    fprintf( fp, "#$\n" );

    fclose( fp );
    fpReserve = fopen( NULL_FILE, "r" );
    return;
}



/*****************************************************************************
 Name:		do_asave
 Purpose:	Entry point for saving area data.
 Called by:	interpreter(interp.c)
 ****************************************************************************/
void do_asave( Character *ch, char *argument )
{
    char arg1 [MAX_INPUT_LENGTH];
    Area *pArea;
    FILE *fp;
    int value;

    fp = NULL;

    if ( !ch )       /* Do an autosave */
    {
		save_area_list();
		for( pArea = area_first; pArea; pArea = pArea->next )
		{
	    	save_area( pArea );
	    	REMOVE_BIT( pArea->area_flags, AREA_CHANGED );
		}
		return;
    }

    smash_tilde( argument );
    strcpy( arg1, argument );

    if ( arg1[0] == '\0' )
    {
        cprintf(ch, "Syntax:\n\r" );
        cprintf(ch, "  asave <vnum>   - saves a particular area\n\r" );
        cprintf(ch, "  asave list     - saves the area.lst file\n\r" );
        cprintf(ch, "  asave area     - saves the area being edited\n\r" );
        cprintf(ch, "  asave changed  - saves all changed zones\n\r" );
        cprintf(ch, "  asave world    - saves the world! (db dump)\n\r" );
        cprintf(ch,"   asave spells   - saev the spell files\n\r" );
        cprintf(ch,"\n\r");
        return;
    }

    /* Snarf the value (which need not be numeric). */
    value = atoi( arg1 );

    if ( !( pArea = get_area_data( value ) ) && is_number( arg1 ) )
    {
	    send_to_char( "That area does not exist.\n\r", ch );
	    return;
    }

    /* Save area of given vnum. */
    /* ------------------------ */

    if ( is_number( arg1 ) )
    {
	    if ( !IS_BUILDER( ch, pArea ) )
	    {
	        send_to_char( "You are not a builder for this area.\n\r", ch );
	        return;
	    }
	    save_area_list();
	    save_area( pArea );
	    return;
    }

    if ( !str_cmp( "spells", arg1 ) )
    {
        save_spells( ch );
        cprintf(ch,"Spells saved.\n\r");
        return;
    }

    /* Save the world, only authorized areas. */
    /* -------------------------------------- */

    if ( !str_cmp( "world", arg1 ) )
    {
		save_area_list();
		for( pArea = area_first; pArea; pArea = pArea->next )
		{
	    	/* Builder must be assigned this area. */
	    	if ( !IS_BUILDER( ch, pArea ) )
				continue;	  

	    	save_area( pArea );
	    	REMOVE_BIT( pArea->area_flags, AREA_CHANGED );
		}
		send_to_char( "You saved the world.\n\r", ch );
		return;
    }

    /* Save changed areas, only authorized areas. */
    /* ------------------------------------------ */

    if ( !str_cmp( "changed", arg1 ) )
    {
	char buf[MAX_INPUT_LENGTH];

	save_area_list();

	send_to_char( "Saved zones:\n\r", ch );
	sprintf( buf, "None.\n\r" );

	for( pArea = area_first; pArea; pArea = pArea->next )
	{
	    /* Builder must be assigned this area. */
	    if ( !IS_BUILDER( ch, pArea ) )
		continue;

	    /* Save changed areas. */
	    if ( IS_SET(pArea->area_flags, AREA_CHANGED) )
	    {
		save_area( pArea );
		sprintf( buf, "%24s - '%s'\n\r", pArea->name, pArea->filename );
		send_to_char( buf, ch );
		REMOVE_BIT( pArea->area_flags, AREA_CHANGED );
	    }
        }
	if ( !str_cmp( buf, "None.\n\r" ) )
	    send_to_char( buf, ch );
        return;
    }

    /* Save the area.lst file. */
    /* ----------------------- */
    if ( !str_cmp( arg1, "list" ) )
    {
	save_area_list();
	return;
    }

    /* Save area being edited, if authorized. */
    /* -------------------------------------- */
    if ( !str_cmp( arg1, "area" ) )
    {
	/* Is character currently editing. */
	if ( ch->desc->editor == 0 )
	{
	    send_to_char( "You are not editing an area, "
		"therefore an area vnum is required.\n\r", ch );
	    return;
	}
	
	/* Find the area to save. */
	switch (ch->desc->editor)
	{
	    case ED_AREA:
		pArea = (Area *)ch->desc->pEdit;
		break;
	    case ED_ROOM:
		pArea = ch->in_room->area;
		break;
	    case ED_OBJECT:
		pArea = ( (ObjIndex *)ch->desc->pEdit )->area;
		break;
	    case ED_MOBILE:
		pArea = ( (MobIndex *)ch->desc->pEdit )->area;
		break;
	    default:
		pArea = ch->in_room->area;
		break;
	}

	if ( !IS_BUILDER( ch, pArea ) )
	{
	    send_to_char( "You are not a builder for this area.\n\r", ch );
	    return;
	}

	save_area_list();
	save_area( pArea );
	REMOVE_BIT( pArea->area_flags, AREA_CHANGED );
	send_to_char( "Area saved.\n\r", ch );
	return;
    }

     /* Save Help File 
    if(!str_cmp(arg1, "helps"))
    {
        save_helps();
        send_to_char( "Helps Saved.\n\r", ch);
	log_string("Helps are saved!");
        return;
    }
	*/

    /* Show correct syntax. */
    /* -------------------- */
    do_asave( ch, "" );
    return;
}

void save_helps( void )
{
    Help * pHelp;
    FILE * fp;
	char	helpfile[MAX_STRING_LENGTH];

	snprintf(helpfile,sizeof(helpfile),"%s/%s", AREA_DIR, "help.are" );
    if ( (fp = fopen( helpfile, "w")) == NULL )
    {
        log_bug( "Open_help: fopen", 0);
        log_error( "help.are");
		return;
     }

        fprintf(fp, "#HELPS\n");

        for ( pHelp = help_first; pHelp != NULL; pHelp = pHelp->next )
        {
            if(pHelp->delete)
                continue;

            fprintf(fp, "%d %s~\n\n%s~\n",
                    pHelp->level, pHelp->keyword, fix_string(pHelp->text));
        }
        fprintf(fp,"0 $~\n\n#$\n");
        fclose(fp);
        return;
}


void save_quest( FILE *fp, Quest *q )
{
    int i;

    fprintf(fp,"#%d\n", q->vnum);
	fprintf(fp,"%s~\n", q->keyword );
    fprintf(fp,"%s~\n", q->name);
    fprintf(fp,"%s~\n", q->short_descr);
    fprintf(fp,"%s~\n", q->long_descr);
	fprintf(fp,"%s~\n", q->hint );
	fprintf(fp,"%s~\n", q->goodbye );
	fprintf(fp,"%s\n", print_flags( q->flags ) );
	for( i=0 ; i<8 ; i++ )
		fprintf(fp,"%s~ %d\n", 	q->faction_hits[i].faction == NULL ? "0" : q->faction_hits[i].faction,
								q->faction_hits[i].amount );
	for( i=0 ; i<8 ; i++ )
		fprintf(fp,"%s~ %d\n",   q->faction_avail[i].faction == NULL ? "0" : q->faction_avail[i].faction,
							    q->faction_avail[i].amount );
			
    fprintf(fp,"%d %d %d %d %d %d %d\n",
        q->reward_vnum,
        q->reward_coins[CUR_SILVER],
        q->reward_coins[CUR_GOLD],
        q->reward_coins[CUR_ELECTRUM],
        q->reward_coins[CUR_PLATINUM],
        q->reward_coins[CUR_ALATINUM],
        q->reward_experience );
	for( i=0 ; i < MAX_INGREDIENT ; i++ )
		fprintf(fp,"%d%c",q->required[i],i<MAX_INGREDIENT-1 ? ' ' : '\n' );
    for( i=0 ; i < MAX_PC_RACE ; i++ )
        fprintf(fp,"%d%c",q->race_avail[i],i<MAX_PC_RACE-1 ? ' ' : '\n' );
    for( i=0 ; i < MAX_CLASS ; i++ )
        fprintf(fp,"%d%c",q->class_avail[i],i<MAX_CLASS-1 ? ' ' : '\n' );
    for( i=0 ; i < MAX_DEITY ; i++ )
        fprintf(fp,"%d%c",q->deity_avail[i],i<MAX_DEITY-1 ? ' ' : '\n' );
    fprintf(fp,"%d %d\n", q->min_level, q->max_level );

    return;
}

void save_quests( FILE *fp, Area *pArea )
{
    int i;
	Quest *q;

    fprintf( fp, "#QUESTS\n" );

    for( i = pArea->lvnum; i <= pArea->uvnum; i++ )
    {
    	if ( (q = get_quest_index( i )) )
        	save_quest( fp, q );
    }

    fprintf( fp, "#0\n\n\n\n" );
    return;
}

void save_scripts( FILE *fp, Area *pArea )
{
    int i;
	ScriptIndex	*script;

    fprintf( fp, "#SCRIPTS\n" );

    for( i = pArea->lvnum; i <= pArea->uvnum; i++ )
    {
    	if ( (script = get_script_index( i )) )
        	save_script( fp, script );
    }

    fprintf( fp, "#0\n\n\n\n" );
    return;
}

void save_script( FILE *fp, ScriptIndex *script )
{
	fprintf(fp,"#%d\n", script->vnum );
	fprintf(fp,"%s~\n", script->name );
	fprintf(fp,"%d %s\n",
		script->priority,
		print_flags( script->trigger ) );
	fprintf(fp,"%s~\n", script->direct_object);
	fprintf(fp,"%s~\n", script->script );
	fprintf(fp,"\n\n");
	return;
}

void save_recipes( FILE *fp, Area *pArea )
{
    int i;
	Recipe *pRec;

    fprintf( fp, "#RECIPES\n" );

    for( i = pArea->lvnum; i <= pArea->uvnum; i++ )
    {
    	if ( (pRec = get_recipe_index( i )) )
        	save_recipe( fp, pRec );
    }

    fprintf( fp, "#0\n\n\n\n" );
    return;
}


void save_recipe( FILE *fp, Recipe *r )
{
	int i;

	fprintf(fp,"#%d\n", r->vnum );
	fprintf(fp,"%s~\n", r->name );
	fprintf(fp,"%s~\n", skill_table[r->trade_skill].name );
	fprintf(fp,"%s\n", print_flags(r->foundation_skills) );
	fprintf(fp,"%d %d %d %d\n", r->result_vnum, r->fail_vnum, 
								r->difficulty, r->trivial );
	for( i=0; i<MAX_INGREDIENT ; i++ )
		fprintf(fp,"%d ", r->components[i] );
	fprintf(fp,"\n\n");
	return;
}

// Append spells to its file.
// New spells that don't have a source file set go into "spells".
void save_spells( Character *ch )
{
    FILE *fp, *fpList;
    int  i;
    char oldFile[MAX_INPUT_LENGTH], newFile[MAX_INPUT_LENGTH];
    char *tmp;
    char *filename;
    SpellIndex *spell;

    // First, rename all the .spl files.
    if ( ( fpList = fopen( SPELL_LIST, "r" ) ) == NULL )
    {
        log_error( SPELL_LIST );    
        cprintf(ch,"Save failed: unable to open %s for reading.\n\r", SPELL_LIST );
        return;
    }

    // For each file listed in our spell index file....
    for ( ; ; )
    {
        tmp = fread_word( fpList );

        /* If we find a '$' we're done loading */
        if ( *tmp == '$' )
            break;

        snprintf(oldFile,sizeof(oldFile),"%s%s", getDirectory(SPELL_DIR),tmp);
        snprintf(newFile,sizeof(newFile),"%s%s.bak", getDirectory(SPELL_DIR),tmp);

        // Rename the file
        if( rename( oldFile, newFile ) < 0 )
        {
            cprintf(ch,"Unable to rename file %s\n\r", oldFile );
            continue;
        }
           
        // Open this file for append - should be 0 bytes here 
        if ( (fp = fopen( oldFile, "a" )) == NULL )
        {
            cprintf(ch,"Unable to append to %s.\n\r", oldFile);
            continue;
        }
 
        // Dump to it all spells taht belong in it. 
        fprintf(fp,"#SPELLS\n"); 
        for( i=0 ; i <= top_spell_vnum ; i++ )
        {
            spell = get_spell_index(i);

            if ( spell == NULL )
                continue;

            if ( (filename = spell->filename) == NULL )
            {
                cprintf(ch,"Spell %s not saved - no filename!\n\r", spell->name);
                continue;
            }

            if ( strcmp( filename, oldFile ) )
                continue; // this spell doesn't go in this file

            save_spell(fp,spell);
        }
 
        fprintf(fp,"#-1\n#$\n");
        fclose(fp);
    }

    fclose(fpList);
    return;
}

void save_spell( FILE *fp, SpellIndex *spell )
{
    int i;
    extern void fprint_spell_affects( FILE *fp, SpellIndex *spell );

    fprintf(fp,"\n#%d\n",       spell->vnum );
    fprintf(fp,"%s~\n",         spell->name );
    fprintf(fp,"%s~\n",         spell->full_name );
    fprintf(fp,"%s~\n",         fix_string( spell->short_descr ) );
    fprintf(fp,"%s~\n",         fix_string( spell->description ) );
    fprintf(fp,"%s~\n",         spell->sgsn == NULL ? "" : skill_table[ *spell->sgsn ].name );
    fprintf(fp,"~\n");
    fprintf(fp,"%s~\n",         spell->func_name );
    fprintf(fp,"%d %d %d\n",    spell->base_mana, spell->series, spell->series_rank );

    for(i=0;i<MAX_CLASS;i++)
        fprintf(fp,"%d ",spell->class_level[i]);

    fprintf(fp,"\n%d %d %d\n",    spell->target, spell->beats, spell->recast );
    fprintf(fp,"%s~\n",         spell->msg_damage);
    fprintf(fp,"%s~\n",         spell->incantation);
    fprintf(fp,"%s~\n",         spell->gesture);
    fprintf(fp,"%s~\n",         spell->msg_off);
    fprintf(fp,"%s~\n",         spell->msg_obj);
    fprintf(fp,"%s\n",          print_flags( spell->flags ) );

    fprintf(fp,"%s~\n",  flag_string( spell_type_flags, spell->spell_type ) );

    switch( spell->spell_type )
    {
    case SPELL_BUFF:
        fprint_spell_affects( fp, spell );
        fprintf(fp,"%s~\n", spell->action.generic.okRoomEcho );
        fprintf(fp,"%s~\n", spell->action.generic.okVictimEcho );
        break;

    case SPELL_DEBUFF:
        fprint_spell_affects( fp, spell );
        fprintf(fp,"%s~\n", spell->action.generic.okRoomEcho );
        fprintf(fp,"%s~\n", spell->action.generic.okVictimEcho );
        fprintf(fp,"%s~\n", spell->action.generic.failRoomEcho );
        fprintf(fp,"%s~\n", spell->action.generic.failVictimEcho );
        fprintf(fp,"%s~\n", flag_string( dam_flags, spell->action.generic.damType ) );
        fprintf(fp,"%s~\n", flag_string( savingthrow_flags, spell->action.generic.saveType ) );
        break;

    case SPELL_BOLT:
        fprintf(fp,"%s~\n", flag_string( dam_flags, spell->action.generic.damType ) );
        fprintf(fp,"%s~\n", flag_string( savingthrow_flags, spell->action.generic.saveType ) );
        fprintf(fp,"%d %d\n", spell->action.generic.lowDamage, spell->action.generic.highDamage );
        fprintf(fp,"%d\n",  spell->action.generic.range );
        break;

    case SPELL_NUKE:
        fprintf(fp,"%s~\n", flag_string( dam_flags, spell->action.generic.damType ) );
        fprintf(fp,"%s~\n", flag_string( savingthrow_flags, spell->action.generic.saveType ) );
        fprintf(fp,"%d %d\n", spell->action.generic.lowDamage, spell->action.generic.highDamage );
        break;

    case SPELL_COMBO_NUKE:
        fprint_spell_affects( fp, spell );
        fprintf(fp,"%s~\n", spell->action.generic.okRoomEcho );
        fprintf(fp,"%s~\n", spell->action.generic.okVictimEcho );
        fprintf(fp,"%s~\n", spell->action.generic.failRoomEcho );
        fprintf(fp,"%s~\n", spell->action.generic.failVictimEcho );
        fprintf(fp,"%s~\n", flag_string( dam_flags, spell->action.generic.damType ) );
        fprintf(fp,"%s~\n", flag_string( savingthrow_flags, spell->action.generic.saveType ) );
        fprintf(fp,"%d %d\n", spell->action.generic.lowDamage, spell->action.generic.highDamage );
        break;

        default:
		break;
    }

    return;
}

void fprint_spell_affects( FILE *fp, SpellIndex *spell )
{
    int i;

    for(i=0;i<5;i++)
    {
        fprintf(fp,"%d %d %d %d ",
            spell->action.generic.affects[i].where,
            spell->action.generic.affects[i].location,
            spell->action.generic.affects[i].modifier,
            spell->action.generic.affects[i].duration );

        if ( spell->action.generic.affects[i].location != APPLY_SKILL )
            fprintf(fp,"%d ", spell->action.generic.affects[i].misc );
        else
            fprintf(fp,"'%s' ", skill_table[ spell->action.generic.affects[i].misc ].name );

        fprintf(fp,"%s ", print_flags( spell->action.generic.affects[i].flags ) );
        fprintf(fp,"%s ", print_flags( spell->action.generic.affects[i].bitvector ) );
        fprintf(fp,"%s~\n", "none" ); /*spell->action.generic.affects[i].description == NULL 
                                ? "none" : spell->action.generic.affects[i].description );*/
    }
}

