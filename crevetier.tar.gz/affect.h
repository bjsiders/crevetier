/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#ifndef affect_h
#define affect_h

#include "thoctype.h"

struct	affect_data
{
    Affect *		next;
    bool			valid;
    sh_int			where;
    sh_int			type;
    sh_int			level;
    time_t	 		duration;
    sh_int			location;
    sh_int			modifier;
    int				bitvector;
    long			flags;
    long			caster_id;
	sh_int			misc;
};

#define AFF_SPELL               (A)     /* 1 */
#define AFF_SKILL               (B)     /* 2 */
#define AFF_DAMAGE_SHIELD       (C)     /* 4 */
#define AFF_ABIL                (D)     /* 8 */
#define AFF_PULSE               (E)     /* 16 */
#define AFF_NOT_SAME_DEITY      (F)     /* 32 */
#define AFF_NOT_OPPOSITE_ALIGN  (G)     /* 64 */
#define AFF_NONSPELL            (H)
#define AFF_NEGATIVE            (I)
#define AFF_ABSOLUTE_TIME       (J)     /* Measure time in seconds */
#define AFF_OBJ                 (K)

/* 
 * This indicates what vector the 'bitvector' part
 * of an affect is applied to.
 */
#define TO_AFFECTS			0
#define TO_OBJECT			1
#define TO_IMMUNE			2
#define TO_RESIST			3
#define TO_VULN				4
#define TO_WEAPON			5
#define DAMAGE_OVER_TIME	6
#define SAVES_BONUS			7
#define DAMAGE_SHIELD		8

/*
 * Apply types (for affects).
 */
#define APPLY_NONE                  0
#define APPLY_STR                   1
#define APPLY_DEX                   2
#define APPLY_INT                   3
#define APPLY_WIS                   4
#define APPLY_CON                   5
#define APPLY_SEX                   6
#define APPLY_CLASS                 7
#define APPLY_LEVEL                 8
#define APPLY_AGE                   9
#define APPLY_HEIGHT                10
#define APPLY_WEIGHT                11
#define APPLY_MANA                  12
#define APPLY_HIT                   13
#define APPLY_MOVE                  14
#define APPLY_GOLD                  15
#define APPLY_EXP                   16
#define APPLY_AC                    17
#define APPLY_HITROLL               18
#define APPLY_DAMROLL               19
#define APPLY_SPELL_AFFECT          25
#define APPLY_SAVE_REFLEX           26
#define APPLY_SAVE_FORTITUDE        27
#define APPLY_SAVE_WILLPOWER        28
#define APPLY_CHA                   29
#define APPLY_SPEED                 30
#define APPLY_RES_FIRE              31
#define APPLY_RES_ICE               32
#define APPLY_RES_EARTH             33
#define APPLY_RES_AIR               34
#define APPLY_RES_SOUND             35
#define APPLY_RES_DARK              36
#define APPLY_RES_LIGHT             37
#define APPLY_RES_WATER             38
#define APPLY_RES_POISON            39
#define APPLY_RES_DISEASE           40
#define APPLY_RES_MENTAL            41
#define APPLY_RES_ACID              42
#define APPLY_RES_ELECTRICITY       43
#define APPLY_RES_SPIRIT            44
#define APPLY_SKILL                 45
#define APPLY_MOVE_RATE             46
#define APPLY_BLADETURN             47
#define APPLY_ABSORB                48
#define APPLY_REGEN_HP              50
#define APPLY_REGEN_MANA            51
#define APPLY_REGEN_STAMINA         52
#define APPLY_REGEN_MOVES           53
#define APPLY_REGEN_BASE            54
#define APPLY_ROOT                  55
#define APPLY_CONVERT_HP_TO_MANA    56
#define APPLY_STAMINA               57
#define APPLY_BASE_HITS             58
#define APPLY_ADD_PROC              59
#define APPLY_RES_BODY              60

/*
    Spell flags
 */
#define DUR_NORMAL                              0
#define DUR_PERMANENT                           -1
#define DUR_SPECIAL                             -2

/*
    Affect macros
 */
#define IS_SPELL(paf)               (IS_SET((paf)->flags,AFF_SPELL))
#define IS_SKILL(paf)               (IS_SET((paf)->flags,AFF_SKILL))

/* 
 * Affect function library.
 */
void 	affect_enchant( Object *obj);
void 	affect_modify( Character *ch, Affect *paf, bool fAdd );
Affect  *affect_find(Affect *paf, int sn);
void 	affect_check(Character *ch,int where,int vector);
bool 	check_replace( Character *ch, Affect *paf );
bool 	affect_to_char( Character *ch, Affect *paf );
void 	affect_to_obj(Object *obj, Affect *paf);
void 	affect_remove( Character *ch, Affect *paf );
void 	affect_remove_obj( Object *obj, Affect *paf);
void 	skill_affect_strip( Character *ch, int sn );
void 	affect_strip( Character *ch, int sn );
bool 	is_affected( Character *ch, int sn, int type );
void 	affect_join( Character *ch, Affect *paf );
char *	affect_loc_name( int location, int misc );
char *	affect_bit_name( int vector );

void	spellAffectToChar( Character *ch, Affect *af );
void	skillAffectToChar( Character *ch, Affect *af );

/*
 * macros 
 */
#endif /* affect_h */
