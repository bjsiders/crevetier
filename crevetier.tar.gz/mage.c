/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/** System Include Files **/
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/** Custom Header Files **/
#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "tables.h"
#include "recycle.h"

bool mage_mesmerize(int sn,int level,Character *ch,void *vo,int dur);
bool spell_dancing_lights(int sn,int level,Character *ch,void *vo,int target);
bool spell_dazzling_lights(int sn,int level,Character *ch,void *vo,int target);
bool spell_mesmerizing_lights(int sn,int level,Character *ch,void *vo,int target);
bool spell_irridescent_lights(int sn,int level,Character *ch,void *vo,int target);

/** The library of  mage spells, arranged alphabetically */
bool spell_phantasmal_imp( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, 0, SAVE_WILLPOWER) )
	{
		act("$N is unaffected by the illusion.",ch,NULL,victim,TO_CHAR);
		act("You feel a twinge of panic but recover your senses.",victim,NULL,NULL,TO_CHAR);
		return TRUE;
	}

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(90);
    af.location     = APPLY_AC;
    af.modifier     = -50;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

	act("$N panics and is distracted by the phantasmal illusion!",ch,NULL,victim,TO_CHAR);
	act("You begin to panic and fumble as the visage of an imp appears near you.",ch,NULL,victim,TO_VICT);
	return TRUE;
}

bool spell_phantasmal_attacker( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, 0, SAVE_WILLPOWER) )
    {
        act("$N is unaffected by the illusion.",ch,NULL,victim,TO_CHAR);
        act("You feel a twinge of panic but recover your senses.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;   
    af.level        = level;
    af.duration     = seconds(90);
    af.location     = APPLY_AC;
    af.modifier     = -100;   
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$N panics and is distracted by the phantasmal illusion!",ch,NULL,victim,TO_CHAR);
    act("You begin to panic and fumble as the visage of an attacker appears near you.",ch,NULL,victim,TO_VICT);
    return TRUE;
}

bool spell_phantasmal_killer( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, 0, SAVE_WILLPOWER) )
    {
        act("$N is unaffected by the illusion.",ch,NULL,victim,TO_CHAR);
        act("You feel a twinge of panic but recover your senses.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;   
    af.level        = level;
    af.duration     = seconds(90);
    af.location     = APPLY_AC;
    af.modifier     = -150;   
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$N panics and is distracted by the phantasmal illusion!",ch,NULL,victim,TO_CHAR);
    act("You begin to panic and fumble as the visage of a killer appears near you.",ch,NULL,victim,TO_VICT);
    return TRUE;
}

bool spell_phantasmal_terror( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, 0, SAVE_WILLPOWER) )
    {
        act("$N is unaffected by the illusion.",ch,NULL,victim,TO_CHAR);
        act("You feel a twinge of panic but recover your senses.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;   
    af.level        = level;
    af.duration     = seconds(90);
    af.location     = APPLY_AC;
    af.modifier     = -200;   
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$N panics and is distracted by the phantasmal illusion!",ch,NULL,victim,TO_CHAR);
    act("You begin to panic and fumble as the visage of a terror appears near you.",ch,NULL,victim,TO_VICT);
    return TRUE;
}

bool spell_phantasmal_horror( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, 0, SAVE_WILLPOWER) )
    {
        act("$N is unaffected by the illusion.",ch,NULL,victim,TO_CHAR);
        act("You feel a twinge of panic but recover your senses.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;   
    af.level        = level;
    af.duration     = minutes(90);
    af.location     = APPLY_AC;
    af.modifier     = -250;   
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$N panics and is distracted by the phantasmal illusion!",ch,NULL,victim,TO_CHAR);
    act("You begin to panic and fumble as the visage of a horror appears near you.",ch,NULL,victim,TO_VICT);
    return TRUE;
}

bool spell_blinded_vision( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, 0, SAVE_WILLPOWER) )
	{
		cprintf(ch,"You failed.\n\r");
		cprintf(victim,"Your vision dims briefly but returns to normal.\n\r");
		return TRUE;
	}

    af.where        = TO_AFFECTS;
    af.bitvector    = AFF_BLIND;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(60);
    af.location     = APPLY_HITROLL;
    af.modifier     = -240;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your vision is blinded, you can't see anything!",victim,NULL,NULL,TO_CHAR);
    act("$n gropes about in confusion, $e seems to be blinded!",victim,NULL,NULL,TO_ROOM);
	return TRUE;
}

bool spell_dimmed_vision( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, 0, SAVE_WILLPOWER) )
    {
        cprintf(ch,"You failed.\n\r");
        cprintf(victim,"Your vision dims briefly but returns to normal.\n\r");
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = AFF_BLIND;
    af.type         = sn;   
    af.level        = level;
    af.duration     = seconds(15);
    af.location     = APPLY_HITROLL;
    af.modifier     = -60;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your vision is dimmed, you can't see anything!",victim,NULL,NULL,TO_CHAR);
    act("$n gropes about in confusion, $e seems to be blinded!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_darkened_vision( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, 0, SAVE_WILLPOWER) )
    {
        cprintf(ch,"You failed.\n\r");
        cprintf(victim,"Your vision dims briefly but returns to normal.\n\r");
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = AFF_BLIND;
    af.type         = sn;   
    af.level        = level;
    af.duration     = seconds(30);
    af.location     = APPLY_HITROLL;
    af.modifier     = -120;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your vision is darkened, you can't see anything!",victim,NULL,NULL,TO_CHAR);
    act("$n gropes about in confusion, $e seems to be blinded!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_blackened_vision( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, 0, SAVE_WILLPOWER) )
	{
		cprintf(ch,"You failed.\n\r");
		cprintf(victim,"Your vision dims briefly but returns to normal.\n\r");
		return TRUE;
	}

    af.where        = TO_AFFECTS;
    af.bitvector    = AFF_BLIND;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(45);
    af.location     = APPLY_HITROLL;
    af.modifier     = -180;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your vision is blackened, you can't see anything!",victim,NULL,NULL,TO_CHAR);
    act("$n gropes about in confusion, $e seems to be blinded!",victim,NULL,NULL,TO_ROOM);
	return TRUE;
}

bool spell_magic_missile( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(5),highDam(6));

    if ( check_saves_spell(ch, victim, DAM_LIGHTNING, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_LIGHTNING , DF_SHOW | DF_SPELL );   
    return TRUE;
}

bool spell_magic_shock( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;
    
    dam = calcSpellDamage(ch,sn,lowDam(10),highDam(12));   
    
    if ( check_saves_spell(ch, victim, DAM_LIGHTNING, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_LIGHTNING , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_magic_burst( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;
    
    dam = calcSpellDamage(ch,sn,lowDam(18),highDam(22));   
    
    if ( check_saves_spell(ch, victim, DAM_LIGHTNING, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_LIGHTNING , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_magic_blast( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;
    
    dam = calcSpellDamage(ch,sn,lowDam(30),highDam(37));   
    
    if ( check_saves_spell(ch, victim, DAM_LIGHTNING, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_LIGHTNING , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_magic_explosion( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;
    
    dam = calcSpellDamage(ch,sn,lowDam(49),highDam(60));   
    
    if ( check_saves_spell(ch, victim, DAM_LIGHTNING, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_LIGHTNING , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_magic_detonation( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;
    
    dam = calcSpellDamage(ch,sn,lowDam(77),highDam(94));   
    
    if ( check_saves_spell(ch, victim, DAM_LIGHTNING, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_LIGHTNING , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_magic_eruption( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;
    
    dam = calcSpellDamage(ch,sn,lowDam(116),highDam(142));   
    
    if ( check_saves_spell(ch, victim, DAM_LIGHTNING, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_LIGHTNING , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_magic_cataclysm( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;
    
    dam = calcSpellDamage(ch,sn,lowDam(169),highDam(206));   
    
    if ( check_saves_spell(ch, victim, DAM_LIGHTNING, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_LIGHTNING , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_arcane_power(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	Affect af;

	af.where		= TO_AFFECTS;
	af.type			= sn;
	af.level		= level;
	af.duration		= minutes(15);
	af.location		= APPLY_DAMROLL;
	af.modifier		= 12;
	af.bitvector	= 0;
	af.flags		= AFF_SPELL;

	spellAffectToChar( victim, &af );
	act("You are filled with arcane power!",victim,NULL,NULL,TO_CHAR);
	if ( victim != ch )
		act("$N is filled with arcane power!",ch,NULL,victim,TO_CHAR);
	return TRUE;
}

bool spell_arcane_might(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

	if ( victim != ch && victim != ch->pet )
	{
		cprintf(ch,"You can only cast this on yourself or your pet.\n\r");
		return FALSE;
	}

    af.where        = TO_AFFECTS; 
    af.type         = sn;   
    af.level        = level;
    af.duration     = minutes(15);
    af.location     = APPLY_DAMROLL;
    af.modifier     = 18;   
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are filled with arcane might!",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N is filled with arcane might!",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_arcane_fury(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

	if ( victim != ch && victim != ch->pet )
	{
		cprintf(ch,"You can only cast this on yourself or your pet.\n\r");
		return FALSE;
	}

    af.where        = TO_AFFECTS; 
    af.type         = sn;   
    af.level        = level;
    af.duration     = minutes(15);
    af.location     = APPLY_DAMROLL;
    af.modifier     = 24;   
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are filled with arcane fury!",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N is filled with arcane fury!",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_arcane_dominance(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

	if ( victim != ch && victim != ch->pet )
	{
		cprintf(ch,"You can only cast this on yourself or your pet.\n\r");
		return FALSE;
	}

    af.where        = TO_AFFECTS; 
    af.type         = sn;   
    af.level        = level;
    af.duration     = minutes(15);
    af.location     = APPLY_DAMROLL;
    af.modifier     = 36;   
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are filled with arcane dominance!",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N is filled with arcane dominance!",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_arcane_strength(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

	if ( victim != ch && victim != ch->pet )
	{
		cprintf(ch,"You can only cast this on yourself or your pet.\n\r");
		return FALSE;
	}

    af.where        = TO_AFFECTS; 
    af.type         = sn;   
    af.level        = level;
    af.duration     = minutes(15);
    af.location     = APPLY_DAMROLL;
    af.modifier     = 6;   
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are filled with arcane strength!",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N is filled with arcane strength!",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_archmage_armor(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

	if ( victim != ch && victim != ch->pet )
	{
		cprintf(ch,"You can only cast this on yourself or your pet.\n\r");
		return FALSE;
	}

    af.where        = TO_AFFECTS; 
    af.type         = sn;   
    af.level        = level;
    af.duration     = minutes(76);
    af.location     = APPLY_AC;
    af.modifier     = 170;   
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are protected by archmage armor.",ch,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N is protected by archmage armor.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_master_armor(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

	if ( victim != ch && victim != ch->pet )
	{
		cprintf(ch,"You can only cast this on yourself or your pet.\n\r");
		return FALSE;
	}

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(88);
    af.location     = APPLY_AC;
    af.modifier     = 225;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are protected by master armor.",ch,NULL,NULL,TO_CHAR); 
    if ( victim != ch )
        act("$N is protected by master armor.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_student_armor(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

	if ( victim != ch && victim != ch->pet )
	{
		cprintf(ch,"You can only cast this on yourself or your pet.\n\r");
		return FALSE;
	}

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_AC;
    af.modifier     = 35;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are protected by student armor.",ch,NULL,NULL,TO_CHAR); 
    if ( victim != ch )
        act("$N is protected by student armor.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_apprentice_armor(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

	if ( victim != ch && victim != ch->pet )
	{
		cprintf(ch,"You can only cast this on yourself or your pet.\n\r");
		return FALSE;
	}

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(52);
    af.location     = APPLY_AC;
    af.modifier     = 75;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are protected by apprentice armor.",ch,NULL,NULL,TO_CHAR); 
    if ( victim != ch )
        act("$N is protected by apprentice armor.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_mage_armor(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

	if ( victim != ch && victim != ch->pet )
	{
		cprintf(ch,"You can only cast this on yourself or your pet.\n\r");
		return FALSE;
	}

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(64);
    af.location     = APPLY_AC;
    af.modifier     = 120;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are protected by hmage armor.",ch,NULL,NULL,TO_CHAR); 
    if ( victim != ch )
        act("$N is protected by mage armor.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_minor_hallucination(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	Affect af;

	/* Check saves - willpower */
	if ( check_saves_spell(ch,victim,0,SAVE_WILLPOWER) )
	{
		act("Your illusion fails to trick $N.",ch,NULL,victim,TO_CHAR);
		act("You resist the illusion!",ch,NULL,victim,TO_VICT);
		return TRUE;
	}

	af.where		= TO_AFFECTS;
	af.type			= sn;
	af.level		= level;
	af.duration		= seconds(30);
	af.modifier		= 0;
	af.location		= 0;
	af.bitvector	= 0;
	af.flags		= AFF_SPELL;
	spellAffectToChar( victim, &af );

	act("Your vision shifts and shimmers - something about your environment isn't right.",victim,NULL,NULL,TO_CHAR);
	act("$n appears to be confused by $S surroundings.",victim,NULL,NULL,TO_ROOM);
	return TRUE;
}

bool spell_major_hallucination(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	Affect af;

	/* Check saves - willpower */
	if ( check_saves_spell(ch,victim,0,SAVE_WILLPOWER) )
	{
		act("Your illusion fails to trick $N.",ch,NULL,victim,TO_CHAR);
		act("You resist the illusion!",ch,NULL,victim,TO_VICT);
		return TRUE;
	}

	af.where		= TO_AFFECTS;
	af.type			= sn;
	af.level		= level;
	af.duration		= seconds(30);
	af.modifier		= 0;
	af.location		= 0;
	af.bitvector	= 0;
	af.flags		= AFF_SPELL;
	spellAffectToChar( victim, &af );

	act("Your vision shifts and shimmers - something about your environment isn't right.",victim,NULL,NULL,TO_CHAR);
	act("$n appears to be confused by $S surroundings.",victim,NULL,NULL,TO_ROOM);
	return TRUE;
}

bool spell_enhanced_strength(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	Affect af;

	if ( victim != ch && victim != ch->pet )
	{
		cprintf(ch,"You can only cast this on yourself or your pet.\n\r");
		return FALSE;
	}

	af.where		= TO_AFFECTS;
	af.type			= sn;
	af.level		= level;
	af.duration		= minutes(38);
	af.modifier		= 15;
	af.location		= APPLY_STR;
	af.bitvector	= 0;
	af.flags		= AFF_SPELL;
	spellAffectToChar( victim, &af );

	act("Your muscles surge with heightened strength!",victim,NULL,NULL,TO_CHAR);
	act("$n's muscles surge with heightened strength!",victim,NULL,NULL,TO_ROOM);
	return TRUE;
}

bool spell_spirit_strength(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

	if ( victim != ch && victim != ch->pet )
	{
		cprintf(ch,"You can only cast this on yourself or your pet.\n\r");
		return FALSE;
	}

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(46);
    af.modifier     = 30;
    af.location     = APPLY_STR;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your muscles surge with heightened strength!",victim,NULL,NULL,TO_CHAR);
    act("$n's muscles surge with heightened strength!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_soul_strength(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

	if ( victim != ch && victim != ch->pet )
	{
		cprintf(ch,"You can only cast this on yourself or your pet.\n\r");
		return FALSE;
	}

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(54);
    af.modifier     = 45;
    af.location     = APPLY_STR;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your muscles surge with heightened strength!",victim,NULL,NULL,TO_CHAR);
    act("$n's muscles surge with heightened strength!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_ka_strength(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

	if ( victim != ch && victim != ch->pet )
	{
		cprintf(ch,"You can only cast this on yourself or your pet.\n\r");
		return FALSE;
	}

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(60);
    af.modifier     = 60;
    af.location     = APPLY_STR;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your muscles surge with heightened strength!",victim,NULL,NULL,TO_CHAR);
    act("$n's muscles surge with heightened strength!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_minor_haste( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level; 
    af.duration     = minutes(8); 
    af.modifier     = 90;
    af.location     = APPLY_SPEED;
    af.bitvector    = AFF_HASTE;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n begins to move more quickly.",victim,NULL,NULL,TO_ROOM);
    act("You begin to move more quickly.",victim,NULL,NULL,TO_CHAR);
    return TRUE; 
}

bool spell_lesser_haste( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(10); 
    af.modifier     = 85;
    af.location     = APPLY_SPEED;
    af.bitvector    = AFF_HASTE;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n begins to move more quickly.",victim,NULL,NULL,TO_ROOM);
    act("You begin to move more quickly.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_haste( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(12); 
    af.modifier     = 80;
    af.location     = APPLY_SPEED;
    af.bitvector    = AFF_HASTE;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n begins to move more quickly.",victim,NULL,NULL,TO_ROOM);
    act("You begin to move more quickly.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_major_haste( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(14); 
    af.modifier     = 75;
    af.location     = APPLY_SPEED;
    af.bitvector    = AFF_HASTE;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n begins to move more quickly.",victim,NULL,NULL,TO_ROOM);
    act("You begin to move more quickly.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_greater_haste( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(16); 
    af.modifier     = 70;
    af.location     = APPLY_SPEED;
    af.bitvector    = AFF_HASTE;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n begins to move more quickly.",victim,NULL,NULL,TO_ROOM);
    act("You begin to move more quickly.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_superior_haste( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(18); 
    af.modifier     = 65;
    af.location     = APPLY_SPEED;
    af.bitvector    = AFF_HASTE;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n begins to move more quickly.",victim,NULL,NULL,TO_ROOM);
    act("You begin to move more quickly.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_minor_curse( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        cprintf(ch,"You failed.\n\r");
        cprintf(victim,"Your briefly feel vulnerable.\n\r");
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = AFF_CURSE;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(12);
    af.location     = APPLY_SAVE_FORTITUDE;
    af.modifier     = -6;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
	af.location		= APPLY_SAVE_REFLEX;
	spellAffectToChar( victim, &af );
	af.location		= APPLY_SAVE_WILLPOWER;
	spellAffectToChar( victim, &af );

	act("You feel vulnerable and unprotected.",victim,NULL,NULL,TO_CHAR);
	act("$n appears vulnerable and unprotected.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_lesser_curse( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        cprintf(ch,"You failed.\n\r");
        cprintf(victim,"Your briefly feel vulnerable.\n\r");
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = AFF_CURSE;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(14);
    af.location     = APPLY_SAVE_FORTITUDE;
    af.modifier     = -12;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
	af.location		= APPLY_SAVE_REFLEX;
	spellAffectToChar( victim, &af );
	af.location		= APPLY_SAVE_WILLPOWER;
	spellAffectToChar( victim, &af );

	act("You feel vulnerable and unprotected.",victim,NULL,NULL,TO_CHAR);
	act("$n appears vulnerable and unprotected.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_curse( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        cprintf(ch,"You failed.\n\r"); 
        cprintf(victim,"Your briefly feel vulnerable.\n\r");
        return TRUE;
    }
 
    af.where        = TO_AFFECTS;
    af.bitvector    = AFF_CURSE;
    af.type         = sn;   
    af.level        = level;
    af.duration     = minutes(16);
    af.location     = APPLY_SAVE_FORTITUDE;
    af.modifier     = -18;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
    af.location     = APPLY_SAVE_REFLEX;
    spellAffectToChar( victim, &af );
    af.location     = APPLY_SAVE_WILLPOWER;
    spellAffectToChar( victim, &af );

    act("You feel vulnerable and unprotected.",victim,NULL,NULL,TO_CHAR);
    act("$n appears vulnerable and unprotected.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_major_curse( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        cprintf(ch,"You failed.\n\r"); 
        cprintf(victim,"Your briefly feel vulnerable.\n\r");
        return TRUE;
    }
 
    af.where        = TO_AFFECTS;
    af.bitvector    = AFF_CURSE;
    af.type         = sn;   
    af.level        = level;
    af.duration     = minutes(18);
    af.location     = APPLY_SAVE_FORTITUDE;
    af.modifier     = -24;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
    af.location     = APPLY_SAVE_REFLEX;
    spellAffectToChar( victim, &af );
    af.location     = APPLY_SAVE_WILLPOWER;
    spellAffectToChar( victim, &af );

    act("You feel vulnerable and unprotected.",victim,NULL,NULL,TO_CHAR);
    act("$n appears vulnerable and unprotected.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_greater_curse( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        cprintf(ch,"You failed.\n\r"); 
        cprintf(victim,"Your briefly feel vulnerable.\n\r");
        return TRUE;
    }
 
    af.where        = TO_AFFECTS;
    af.bitvector    = AFF_CURSE;
    af.type         = sn;   
    af.level        = level;
    af.duration     = minutes(20);
    af.location     = APPLY_SAVE_FORTITUDE;
    af.modifier     = -30;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
    af.location     = APPLY_SAVE_REFLEX;
    spellAffectToChar( victim, &af );
    af.location     = APPLY_SAVE_WILLPOWER;
    spellAffectToChar( victim, &af );

    act("You feel vulnerable and unprotected.",victim,NULL,NULL,TO_CHAR);
    act("$n appears vulnerable and unprotected.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_strain( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
    {
        cprintf(ch,"You failed.\n\r");
        cprintf(victim,"Your briefly feel weak.\n\r");
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(12);
    af.location     = APPLY_STR;
    af.modifier     = -20;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("You become strained and weak!",victim,NULL,NULL,TO_CHAR);
    act("$n appears strained and weak!",victim,NULL,NULL,TO_ROOM); 
    return TRUE;
}

bool spell_weaken( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
    {
        cprintf(ch,"You failed.\n\r");
        cprintf(victim,"Your briefly feel weak.\n\r");
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(16);
    af.location     = APPLY_STR;
    af.modifier     = -40;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
    
    act("You become strained and weak!",victim,NULL,NULL,TO_CHAR);  
    act("$n appears strained and weak!",victim,NULL,NULL,TO_ROOM); 
    return TRUE;
}

bool spell_enfeeble( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
    {
        cprintf(ch,"You failed.\n\r");
        cprintf(victim,"Your briefly feel weak.\n\r");
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(20);
    af.location     = APPLY_STR;
    af.modifier     = -60;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
    
    act("You become strained and weak!",victim,NULL,NULL,TO_CHAR);  
    act("$n appears strained and weak!",victim,NULL,NULL,TO_ROOM); 
    return TRUE;
}

bool spell_debilitate( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
    {
        cprintf(ch,"You failed.\n\r");
        cprintf(victim,"Your briefly feel weak.\n\r");
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(24);
    af.location     = APPLY_STR;
    af.modifier     = -80;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
    
    act("You become strained and weak!",victim,NULL,NULL,TO_CHAR);  
    act("$n appears strained and weak!",victim,NULL,NULL,TO_ROOM); 
    return TRUE;
}

bool spell_cripple( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
    {
        cprintf(ch,"You failed.\n\r");
        cprintf(victim,"Your briefly feel weak.\n\r");
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(28);
    af.location     = APPLY_STR;
    af.modifier     = -100;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
    
    act("You become strained and weak!",victim,NULL,NULL,TO_CHAR);  
    act("$n appears strained and weak!",victim,NULL,NULL,TO_ROOM); 
    return TRUE;
}

bool spell_zone_of_coldness( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Character *vch, *vch_next;
    int dam;

    act("$n summons forth a freezing cloud of ice!",ch,NULL,NULL,TO_ROOM);
    act("You summon forth a freezing cloud of ice!",ch,NULL,NULL,TO_CHAR);

    for (vch = victim->in_room->people; vch != NULL; vch = vch_next)
    {
    	vch_next = vch->next_in_room;

    	if (is_safe_spell(ch,vch,TRUE)
    	||  (IS_NPC(vch) && IS_NPC(ch) && (ch->fighting != vch || vch->fighting != ch))
		||  is_same_group(ch,vch) )
        	continue;

    	dam = calcSpellDamage(ch,sn,lowDam(10),highDam(20));

    	if ( check_saves_spell(ch, vch, DAM_COLD, SAVE_FORTITUDE) )
        	dam /= 2;

	    damage( ch, vch, dam, sn, DAM_COLD , DF_SHOW | DF_SPELL );
    }
    return TRUE;
}

bool spell_squall( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Character *vch, *vch_next;
    int dam;

    act("$n summons forth a freezing cloud of ice!",ch,NULL,NULL,TO_ROOM);
    act("You summon forth a freezing cloud of ice!",ch,NULL,NULL,TO_CHAR);
 
    for (vch = victim->in_room->people; vch != NULL; vch = vch_next)
    {
        vch_next = vch->next_in_room;

        if (is_safe_spell(ch,vch,TRUE)
        ||  (IS_NPC(vch) && IS_NPC(ch) && (ch->fighting != vch || vch->fighting != ch))
        ||  is_same_group(ch,vch) )
            continue;

        dam = calcSpellDamage(ch,sn,lowDam(20),highDam(40));

        if ( check_saves_spell(ch, vch, DAM_COLD, SAVE_FORTITUDE) )
            dam /= 2;

        damage( ch, vch, dam, sn, DAM_COLD , DF_SHOW | DF_SPELL );
    }   
    return TRUE;
}

bool spell_sleet_storm( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Character *vch, *vch_next;
    int dam;

    act("$n summons forth a freezing cloud of ice!",ch,NULL,NULL,TO_ROOM);
    act("You summon forth a freezing cloud of ice!",ch,NULL,NULL,TO_CHAR);
    
    for (vch = victim->in_room->people; vch != NULL; vch = vch_next)
    {
        vch_next = vch->next_in_room;

        if (is_safe_spell(ch,vch,TRUE)
        ||  (IS_NPC(vch) && IS_NPC(ch) && (ch->fighting != vch || vch->fighting != ch))
        ||  is_same_group(ch,vch) )
            continue;

        dam = calcSpellDamage(ch,sn,lowDam(40),highDam(80));

        if ( check_saves_spell(ch, vch, DAM_COLD, SAVE_FORTITUDE) )
            dam /= 2;

        damage( ch, vch, dam, sn, DAM_COLD , DF_SHOW | DF_SPELL );
    }
    return TRUE;
}

bool spell_ice_storm( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Character *vch, *vch_next;
    int dam;

    act("$n summons forth a freezing cloud of ice!",ch,NULL,NULL,TO_ROOM);
    act("You summon forth a freezing cloud of ice!",ch,NULL,NULL,TO_CHAR);
    
    for (vch = victim->in_room->people; vch != NULL; vch = vch_next)
    {
        vch_next = vch->next_in_room;

        if (is_safe_spell(ch,vch,TRUE)
        ||  (IS_NPC(vch) && IS_NPC(ch) && (ch->fighting != vch || vch->fighting != ch))
        ||  is_same_group(ch,vch) )
            continue;

        dam = calcSpellDamage(ch,sn,lowDam(80),highDam(140));

        if ( check_saves_spell(ch, vch, DAM_COLD, SAVE_FORTITUDE) )
            dam /= 2;

        damage( ch, vch, dam, sn, DAM_COLD , DF_SHOW | DF_SPELL );
    }
    return TRUE;
}

bool spell_frigid_torrent( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Character *vch, *vch_next;
    int dam;

    act("$n summons forth a freezing cloud of ice!",ch,NULL,NULL,TO_ROOM);
    act("You summon forth a freezing cloud of ice!",ch,NULL,NULL,TO_CHAR);
    
    for (vch = victim->in_room->people; vch != NULL; vch = vch_next)
    {
        vch_next = vch->next_in_room;

        if (is_safe_spell(ch,vch,TRUE)
        ||  (IS_NPC(vch) && IS_NPC(ch) && (ch->fighting != vch || vch->fighting != ch))
        ||  is_same_group(ch,vch) )
            continue;

        dam = calcSpellDamage(ch,sn,lowDam(140),highDam(280));

        if ( check_saves_spell(ch, vch, DAM_COLD, SAVE_FORTITUDE) )
            dam /= 2;

        damage( ch, vch, dam, sn, DAM_COLD , DF_SHOW | DF_SPELL );
    }
    return TRUE;
}

bool spell_grasping_roots( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
	Affect af;

    if ( check_saves_spell(ch, victim, 0, SAVE_REFLEX) )
    {
        act("Ethereal roots try to grasp you, but you avoid them.",victim,NULL,NULL,TO_CHAR);
        act("Ethereal roots try to grasp $N, but $E avoids them.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(7);
    af.location     = APPLY_ROOT;
    af.modifier     = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

	act("Ethereal roots materialize and hold you to the ground - you can't move!",victim,NULL,NULL,TO_CHAR);
	act("Ethereal roots materialize and holod $n to the ground!",victim,NULL,NULL,TO_ROOM);
	return TRUE;
}

bool spell_holding_roots( int sn, int level, Character *ch, void *vo,int target )
{   
    Character *victim = (Character *) vo;
	Affect af;
    
    if ( check_saves_spell(ch, victim, 0, SAVE_REFLEX) )
    {
        act("Ethereal roots try to grasp you, but you avoid them.",victim,NULL,NULL,TO_CHAR); 
        act("Ethereal roots try to grasp $N, but $E avoids them.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(13);
    af.location     = APPLY_ROOT;
    af.modifier     = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Ethereal roots materialize and hold you to the ground - you can't move!",victim,NULL,NULL,TO_CHAR);
    act("Ethereal roots materialize and holod $n to the ground!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_binding_roots( int sn, int level, Character *ch, void *vo,int target )
{   
    Character *victim = (Character *) vo;
	Affect af;
    
    if ( check_saves_spell(ch, victim, 0, SAVE_REFLEX) )
    {
        act("Ethereal roots try to grasp you, but you avoid them.",victim,NULL,NULL,TO_CHAR); 
        act("Ethereal roots try to grasp $N, but $E avoids them.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(19);
    af.location     = APPLY_ROOT;
    af.modifier     = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Ethereal roots materialize and hold you to the ground - you can't move!",victim,NULL,NULL,TO_CHAR);
    act("Ethereal roots materialize and holod $n to the ground!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_minor_windspark( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(10),highDam(12));

    if ( check_saves_spell(ch, victim, DAM_AIR, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_AIR , DF_SHOW | DF_SPELL );
    return TRUE; 
}

bool spell_major_windspark( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(24),highDam(29));

    if ( check_saves_spell(ch, victim, DAM_AIR, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_AIR , DF_SHOW | DF_SPELL );    
    return TRUE;
}

bool spell_minor_steamburst( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(48),highDam(59));

    if ( check_saves_spell(ch, victim, DAM_AIR, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_AIR , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_major_steamburst( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(85),highDam(104));

    if ( check_saves_spell(ch, victim, DAM_AIR, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_AIR , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_minor_vacuum( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(139),highDam(170));

    if ( check_saves_spell(ch, victim, DAM_AIR, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_AIR , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_major_vacuum( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(214),highDam(262));

    if ( check_saves_spell(ch, victim, DAM_AIR, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_AIR , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_elementaling( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet;	
	int conj_skill, hp_max;
	int i;
	char buf[MAX_STRING_LENGTH];

	if ( ch->pet != NULL )
	{
		cprintf(ch,"Dismiss the one you have!\n\r");
		return FALSE;
	}

	pet = create_mobile( get_mob_index( MOB_VNUM_ELEMENTAL ) );
	SET_BIT( pet->act, ACT_PET );
	SET_BIT( pet->affected_by, AFF_CHARM );
	SET_BIT( pet->form, FORM_SUMMONED );
	pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
	char_to_room( pet, ch->in_room );
	pet->leader = ch;
	ch->pet = pet;

	pet->class = csn_paladin;
	conj_skill = get_skill(ch,skill_lookup("conjuration"));
	hp_max = conj_skill * 5;
	pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
	pet->max_base_hit = pet->max_stat_hit / 5;
	pet->stat_hit = pet->max_stat_hit;
	pet->base_hit = pet->max_base_hit;
	pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000;
	pet->level = ch->level;

	for( i=0 ; i < MAX_STATS ; i++ )
		pet->perm_stat[i] = 100 + (conj_skill*3);

	for( i=0 ; i<4 ; i++ )
		pet->armor[i] = conj_skill * 2 / 10;
	pet->armor[3] /= 4;

	pet->hitroll = conj_skill * 4 / 10;
	pet->damage[0] = 1;
	pet->damage[1] = 6;
	pet->damage[2] = conj_skill * 2 / 10;

	pet->absorb = UMAX( pet->absorb, 10 );

	snprintf(buf,sizeof(buf),"elementaling");
	free_string( pet->name );
	pet->name = str_dup( buf );

	snprintf(buf,sizeof(buf),"an elementaling");
	free_string( pet->short_descr );
	pet->short_descr = str_dup( buf );
 
	snprintf(buf,sizeof(buf),"An elementaling stands here at attention.\n\r");
	free_string( pet->long_descr );
	pet->long_descr = str_dup( buf );

	pet->resists[ RESIST_SLASH ].value      += conj_skill /2;
	pet->resists[ RESIST_PIERCE ].value     += conj_skill /2;
    pet->resists[ RESIST_CONCUSSION ].value += conj_skill /2;

	add_follower( pet, ch );
	act("In a cloud of smoke, $N appears and bows to you.",ch,NULL,pet,TO_CHAR);
	act("In a cloud of smoke, $N appears and bows to $n.",ch,NULL,pet,TO_ROOM);
	return TRUE;
}

bool spell_lesser_elemental( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet;	
	int conj_skill, hp_max;
	int i;
	char buf[MAX_STRING_LENGTH];

	if ( ch->pet != NULL )
	{
		cprintf(ch,"Dismiss the one you have!\n\r");
		return FALSE;
	}

	pet = create_mobile( get_mob_index( MOB_VNUM_ELEMENTAL ) );
	SET_BIT( pet->act, ACT_PET );
	SET_BIT( pet->affected_by, AFF_CHARM );
	SET_BIT( pet->form, FORM_SUMMONED );
	pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
	char_to_room( pet, ch->in_room );
	pet->leader = ch;
	ch->pet = pet;

	pet->class = csn_ranger;
	conj_skill = get_skill(ch,skill_lookup("conjuration"));
	hp_max = conj_skill * 9;
	pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
	pet->max_base_hit = pet->max_stat_hit / 5;
	pet->stat_hit = pet->max_stat_hit;
	pet->base_hit = pet->max_base_hit;
	pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000;
	pet->level = ch->level;

	for( i=0 ; i < MAX_STATS ; i++ )
		pet->perm_stat[i] = 100 + (conj_skill*3);

	for( i=0 ; i<4 ; i++ )
		pet->armor[i] = conj_skill * 4 / 10;
	pet->armor[3] /= 4;

	pet->hitroll = conj_skill * 6 / 10;
	pet->damage[0] = 2;
	pet->damage[1] = 6;
	pet->damage[2] = conj_skill * 4 / 10;

	pet->absorb = UMAX( pet->absorb, 20 );

	snprintf(buf,sizeof(buf),"lesser elemental");
	free_string( pet->name );
	pet->name = str_dup( buf );

	snprintf(buf,sizeof(buf),"a lesser elemental");
	free_string( pet->short_descr );
	pet->short_descr = str_dup( buf );
 
	snprintf(buf,sizeof(buf),"A lesser elemental stands here at attention.\n\r");
	free_string( pet->long_descr );
	pet->long_descr = str_dup( buf );

    pet->resists[ RESIST_SLASH ].value      += conj_skill /2;
    pet->resists[ RESIST_PIERCE ].value     += conj_skill /2;
    pet->resists[ RESIST_CONCUSSION ].value += conj_skill /2;  

	add_follower( pet, ch );
	act("In a cloud of smoke, $N appears and bows to you.",ch,NULL,pet,TO_CHAR);
	act("In a cloud of smoke, $N appears and bows to $n.",ch,NULL,pet,TO_ROOM);
	return TRUE;
}

bool spell_elemental( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet;	
	int conj_skill, hp_max;
	int i;
	char buf[MAX_STRING_LENGTH];

	if ( ch->pet != NULL )
	{
		cprintf(ch,"Dismiss the one you have!\n\r");
		return FALSE;
	}

	pet = create_mobile( get_mob_index( MOB_VNUM_ELEMENTAL ) );
	SET_BIT( pet->act, ACT_PET );
	SET_BIT( pet->affected_by, AFF_CHARM );
	SET_BIT( pet->form, FORM_SUMMONED );
	pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
	char_to_room( pet, ch->in_room );
	pet->leader = ch;
	ch->pet = pet;

	pet->class = csn_ranger;
	conj_skill = get_skill(ch,skill_lookup("conjuration"));
	hp_max = conj_skill * 15;
	pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
	pet->max_base_hit = pet->max_stat_hit / 5;
	pet->stat_hit = pet->max_stat_hit;
	pet->base_hit = pet->max_base_hit;
	pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000;
	pet->level = ch->level;

	for( i=0 ; i < MAX_STATS ; i++ )
		pet->perm_stat[i] = 100 + (conj_skill*3);

	for( i=0 ; i<4 ; i++ )
		pet->armor[i] = conj_skill * 6 / 10;
	pet->armor[3] /= 4;

	pet->hitroll = conj_skill * 8 / 10;
	pet->damage[0] = 3;
	pet->damage[1] = 6;
	pet->damage[2] = conj_skill * 6 / 10;

	pet->absorb = UMAX( pet->absorb, 30 );

	snprintf(buf,sizeof(buf),"elemental");
	free_string( pet->name );
	pet->name = str_dup( buf );

	snprintf(buf,sizeof(buf),"an elemental");
	free_string( pet->short_descr );
	pet->short_descr = str_dup( buf );
 
	snprintf(buf,sizeof(buf),"An elemental stands here at attention.\n\r");
	free_string( pet->long_descr );
	pet->long_descr = str_dup( buf );

    pet->resists[ RESIST_SLASH ].value      += conj_skill /2;
    pet->resists[ RESIST_PIERCE ].value     += conj_skill /2;  
    pet->resists[ RESIST_CONCUSSION ].value += conj_skill /2;  

	add_follower( pet, ch );
	act("In a cloud of smoke, $N appears and bows to you.",ch,NULL,pet,TO_CHAR);
	act("In a cloud of smoke, $N appears and bows to $n.",ch,NULL,pet,TO_ROOM);
	return TRUE;
}

bool spell_greater_elemental( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet;	
	int conj_skill, hp_max;
	int i;
	char buf[MAX_STRING_LENGTH];

	if ( ch->pet != NULL )
	{
		cprintf(ch,"Dismiss the one you have!\n\r");
		return FALSE;
	}

	pet = create_mobile( get_mob_index( MOB_VNUM_ELEMENTAL ) );
	SET_BIT( pet->act, ACT_PET );
	SET_BIT( pet->affected_by, AFF_CHARM );
	SET_BIT( pet->form, FORM_SUMMONED );
	pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
	char_to_room( pet, ch->in_room );
	pet->leader = ch;
	ch->pet = pet;

	pet->class = csn_fighter;
	conj_skill = get_skill(ch,skill_lookup("conjuration"));
	hp_max = conj_skill * 23;
	pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
	pet->max_base_hit = pet->max_stat_hit / 5;
	pet->stat_hit = pet->max_stat_hit;
	pet->base_hit = pet->max_base_hit;
	pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000;
	pet->level = ch->level;

	for( i=0 ; i < MAX_STATS ; i++ )
		pet->perm_stat[i] = 100 + (conj_skill*3);

	for( i=0 ; i<4 ; i++ )
		pet->armor[i] = conj_skill * 8 / 10;
	pet->armor[3] /= 4;

	pet->hitroll = conj_skill * 10 / 10;
	pet->damage[0] = 4;
	pet->damage[1] = 6;
	pet->damage[2] = conj_skill * 7 / 10;

	pet->absorb = UMAX( pet->absorb, 40 );

	snprintf(buf,sizeof(buf),"greater elemental");
	free_string( pet->name );
	pet->name = str_dup( buf );

	snprintf(buf,sizeof(buf),"a greater elemental");
	free_string( pet->short_descr );
	pet->short_descr = str_dup( buf );
 
	snprintf(buf,sizeof(buf),"A greater elemental stands here at attention.\n\r");
	free_string( pet->long_descr );
	pet->long_descr = str_dup( buf );

    pet->resists[ RESIST_SLASH ].value      += conj_skill /2;
    pet->resists[ RESIST_PIERCE ].value     += conj_skill /2;  
    pet->resists[ RESIST_CONCUSSION ].value += conj_skill /2;  

	add_follower( pet, ch );
	act("In a cloud of smoke, $N appears and bows to you.",ch,NULL,pet,TO_CHAR);
	act("In a cloud of smoke, $N appears and bows to $n.",ch,NULL,pet,TO_ROOM);
	return TRUE;
}

bool spell_superior_elemental( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet;	
	int conj_skill, hp_max;
	int i;
	char buf[MAX_STRING_LENGTH];

	if ( ch->pet != NULL )
	{
		cprintf(ch,"Dismiss the one you have!\n\r");
		return FALSE;
	}

	pet = create_mobile( get_mob_index( MOB_VNUM_ELEMENTAL ) );
	SET_BIT( pet->act, ACT_PET );
	SET_BIT( pet->affected_by, AFF_CHARM );
	SET_BIT( pet->form, FORM_SUMMONED );
	pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
	char_to_room( pet, ch->in_room );
	pet->leader = ch;
	ch->pet = pet;

	pet->class = csn_fighter;
	conj_skill = get_skill(ch,skill_lookup("conjuration"));
	hp_max = conj_skill * 33;
	pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
	pet->max_base_hit = pet->max_stat_hit / 5;
	pet->stat_hit = pet->max_stat_hit;
	pet->base_hit = pet->max_base_hit;
	pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000;
	pet->level = ch->level;

	for( i=0 ; i < MAX_STATS ; i++ )
		pet->perm_stat[i] = 100 + (conj_skill*3);

	for( i=0 ; i<4 ; i++ )
		pet->armor[i] = conj_skill * 10 / 10;
	pet->armor[3] /= 4;

	pet->hitroll = conj_skill * 12 / 10;
	pet->damage[0] = 5;
	pet->damage[1] = 6;
	pet->damage[2] = conj_skill * 8 / 10;

	pet->absorb = UMAX( pet->absorb, 50 );

	snprintf(buf,sizeof(buf),"superior elemental");
	free_string( pet->name );
	pet->name = str_dup( buf );

	snprintf(buf,sizeof(buf),"a superior elemental");
	free_string( pet->short_descr );
	pet->short_descr = str_dup( buf );
 
	snprintf(buf,sizeof(buf),"A superior elemental stands here at attention.\n\r");
	free_string( pet->long_descr );
	pet->long_descr = str_dup( buf );

    pet->resists[ RESIST_SLASH ].value      += conj_skill /2;
    pet->resists[ RESIST_PIERCE ].value     += conj_skill /2;  
    pet->resists[ RESIST_CONCUSSION ].value += conj_skill /2;  

	add_follower( pet, ch );
	act("In a cloud of smoke, $N appears and bows to you.",ch,NULL,pet,TO_CHAR);
	act("In a cloud of smoke, $N appears and bows to $n.",ch,NULL,pet,TO_ROOM);
	return TRUE;
}

bool spell_elemental_lord( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet;	
	int conj_skill, hp_max;
	int i;
	char buf[MAX_STRING_LENGTH];

	if ( ch->pet != NULL )
	{
		cprintf(ch,"Dismiss the one you have!\n\r");
		return FALSE;
	}

	pet = create_mobile( get_mob_index( MOB_VNUM_ELEMENTAL ) );
	SET_BIT( pet->act, ACT_PET );
	SET_BIT( pet->affected_by, AFF_CHARM );
	SET_BIT( pet->form, FORM_SUMMONED );
	pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
	char_to_room( pet, ch->in_room );
	pet->leader = ch;
	ch->pet = pet;

	pet->class = csn_barbarian;
	conj_skill = get_skill(ch,skill_lookup("conjuration"));
	hp_max = conj_skill * 45;
	pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
	pet->max_base_hit = pet->max_stat_hit / 5;
	pet->stat_hit = pet->max_stat_hit;
	pet->base_hit = pet->max_base_hit;
	pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000;
	pet->level = ch->level;

	for( i=0 ; i < MAX_STATS ; i++ )
		pet->perm_stat[i] = 100 + (conj_skill*3);

	for( i=0 ; i<4 ; i++ )
		pet->armor[i] = conj_skill * 12 / 10;
	pet->armor[3] /= 4;

	pet->hitroll = conj_skill * 14 / 10;
	pet->damage[0] = 6;
	pet->damage[1] = 6;
	pet->damage[2] = conj_skill * 10 / 10;

	snprintf(buf,sizeof(buf),"elemental lord");
	free_string( pet->name );
	pet->name = str_dup( buf );

	snprintf(buf,sizeof(buf),"an elemental lord");
	free_string( pet->short_descr );
	pet->short_descr = str_dup( buf );
 
	snprintf(buf,sizeof(buf),"An elemental lord stands here at attention.\n\r");
	free_string( pet->long_descr );
	pet->long_descr = str_dup( buf );

    pet->resists[ RESIST_SLASH ].value      += conj_skill /2;
    pet->resists[ RESIST_PIERCE ].value     += conj_skill /2;  
    pet->resists[ RESIST_CONCUSSION ].value += conj_skill /2;  

	add_follower( pet, ch );
	act("In a cloud of smoke, $N appears and bows to you.",ch,NULL,pet,TO_CHAR);
	act("In a cloud of smoke, $N appears and bows to $n.",ch,NULL,pet,TO_ROOM);
	return TRUE;
}

bool spell_invisibility( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

	act( "$n wavers and fades away into thin air!", victim,NULL,NULL,TO_ROOM);

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(15);
    af.location  = APPLY_NONE;
    af.modifier  = 0;
    af.bitvector = AFF_INVISIBLE;
	af.misc		 = 0;
	af.flags	 = AFF_SPELL;
    spellAffectToChar( victim, &af );
    send_to_char( "You fade out of existence.\n\r", victim );
    return TRUE;
}

/* procs a dot */
bool mirage_of_fire( Character *ch, char *spell )
{
	Character 	*pet;
	Object		*obj;
	int 		skill = get_skill(ch,gsn_illusion);

	if ( (pet = ch->pet) == NULL )
	{
		cprintf(ch,"You do not have a pet.\n\r");
		return FALSE;
	}

	if ( get_eq_char( pet, WEAR_WIELD ) != NULL )
	{
		act("$N already has a weapon.",ch,NULL,pet,TO_CHAR);
		return FALSE;
	}

	if ( get_obj_index( VNUM_ELEMENTAL_FLAMESWORD ) == NULL )
	{
		cprintf(ch,"Failed!  (this is a bug, please report it!)\n\r");
		return FALSE;
	}

	if ( (obj = create_object( get_obj_index( VNUM_ELEMENTAL_FLAMESWORD ) )) == NULL )
	{
		cprintf(ch,"Failed!  (this is a bug, please report it!)\n\r");
		return FALSE;
	}


	obj->value[1] = 1;
	obj->value[2] = UMAX(skill,10);
    obj->value[9] = (skill/2)*(ch->level/2)*-1;
	obj->value[7] = spell_lookup( spell, 0 );

	obj_to_char(obj,pet);
	equip_char(pet,obj,WEAR_WIELD);
	act("$n summons forth $p from the Plane of Fire.",pet,obj,NULL,TO_ROOM);
	return TRUE;
}


bool spell_minor_mirage_of_fire( int sn, int level, Character *ch, void *vo, int target )
{
	return mirage_of_fire( ch, "flameburst" );
}

bool spell_major_mirage_of_fire( int sn, int level, Character *ch, void *vo, int target )
{
	return mirage_of_fire( ch, "blast of flame" );
}

bool spell_greater_mirage_of_fire( int sn, int level, Character *ch, void *vo, int target )
{
	return mirage_of_fire( ch, "ekpyrotic blast" );
}

bool mirage_of_air( Character *ch, char *spell )
{
	Character 	*pet;
	Object		*obj;
	int 		skill = get_skill(ch,gsn_illusion);

	if ( (pet = ch->pet) == NULL )
	{
		cprintf(ch,"You do not have a pet.\n\r");
		return FALSE;
	}

	if ( get_eq_char( pet, WEAR_WIELD ) != NULL )
	{
		act("$N already has a weapon.",ch,NULL,pet,TO_CHAR);
		return FALSE;
	}

	if ( get_obj_index( VNUM_ELEMENTAL_AIRSWORD ) == NULL )
	{
		cprintf(ch,"Failed!  (this is a bug, please report it!)\n\r");
		return FALSE;
	}

	if ( (obj = create_object( get_obj_index( VNUM_ELEMENTAL_AIRSWORD ) )) == NULL )
	{
		cprintf(ch,"Failed!  (this is a bug, please report it!)\n\r");
		return FALSE;
	}


	obj->value[1] = 1;
	obj->value[2] = UMAX(skill,10);
    obj->value[9] = (skill/2)*(ch->level/2)*-1;
	obj->value[7] = spell_lookup( spell, 0 );

	obj_to_char(obj,pet);
	equip_char(pet,obj,WEAR_WIELD);
	act("$n summons forth $p from the Plane of Air.",pet,obj,NULL,TO_ROOM);
	return TRUE;
}

bool mirage_of_water( Character *ch, char *spell )
{
	Character 	*pet;
	Object		*obj;
	int 		skill = get_skill(ch,gsn_illusion);

	if ( (pet = ch->pet) == NULL )
	{
		cprintf(ch,"You do not have a pet.\n\r");
		return FALSE;
	}

	if ( get_eq_char( pet, WEAR_WIELD ) != NULL )
	{
		act("$N already has a weapon.",ch,NULL,pet,TO_CHAR);
		return FALSE;
	}

	if ( get_obj_index( VNUM_ELEMENTAL_WATERSWORD ) == NULL )
	{
		cprintf(ch,"Failed!  (this is a bug, please report it!)\n\r");
		return FALSE;
	}

	if ( (obj = create_object( get_obj_index( VNUM_ELEMENTAL_WATERSWORD ) )) == NULL )
	{
		cprintf(ch,"Failed!  (this is a bug, please report it!)\n\r");
		return FALSE;
	}


	obj->value[1] = 1;
	obj->value[2] = UMAX(skill,10);
    obj->value[9] = (skill/2)*(ch->level/2)*-1;
	obj->value[7] = spell_lookup( spell, 1 );

	obj_to_char(obj,pet);
	equip_char(pet,obj,WEAR_WIELD);
	act("$n summons forth $p from the Plane of Water.",pet,obj,NULL,TO_ROOM);
	return TRUE;
}

bool mirage_of_earth( Character *ch, char *spell )
{
	Character 	*pet;
	Object		*obj;
	int 		skill = get_skill(ch,gsn_illusion);

	if ( (pet = ch->pet) == NULL )
	{
		cprintf(ch,"You do not have a pet.\n\r");
		return FALSE;
	}

	if ( get_eq_char( pet, WEAR_WIELD ) != NULL )
	{
		act("$N already has a weapon.",ch,NULL,pet,TO_CHAR);
		return FALSE;
	}

	if ( get_obj_index( VNUM_ELEMENTAL_EARTHSWORD ) == NULL )
	{
		cprintf(ch,"Failed!  (this is a bug, please report it!)\n\r");
		return FALSE;
	}

	if ( (obj = create_object( get_obj_index( VNUM_ELEMENTAL_EARTHSWORD ) )) == NULL )
	{
		cprintf(ch,"Failed!  (this is a bug, please report it!)\n\r");
		return FALSE;
	}


	obj->value[1] = 1;
	obj->value[2] = UMAX(skill,10);
    obj->value[9] = (skill/2)*(ch->level/2)*-1;
	obj->value[7] = spell_lookup( spell, 0 );

	obj_to_char(obj,pet);
	equip_char(pet,obj,WEAR_WIELD);
	act("$n summons forth $p from the Plane of Earth.",pet,obj,NULL,TO_ROOM);
	return TRUE;
}

bool spell_minor_mirage_of_air( int sn, int level, Character *ch, void *vo, int target )
{
	return mirage_of_air( ch, "minor windspark" );
}

bool spell_major_mirage_of_air( int sn, int level, Character *ch, void *vo, int target )
{
	return mirage_of_air( ch, "minor steamburst" );
}

bool spell_greater_mirage_of_air( int sn, int level, Character *ch, void *vo, int target )
{
	return mirage_of_air( ch, "minor vacuum" );
}


bool spell_minor_mirage_of_water( int sn, int level, Character *ch, void *vo, int target )
{
    return mirage_of_water( ch, "deluge" );
}

bool spell_major_mirage_of_water( int sn, int level, Character *ch, void *vo, int target )
{
    return mirage_of_water( ch, "storm" );
}

bool spell_greater_mirage_of_water( int sn, int level, Character *ch, void *vo, int target )
{
    return mirage_of_water( ch, "tempest" );
}

 bool spell_minor_mirage_of_earth( int sn, int level, Character *ch, void *vo, int target )
{
	return mirage_of_earth( ch, "orb of sand" );
}

bool spell_major_mirage_of_earth( int sn, int level, Character *ch, void *vo, int target )
{
	return mirage_of_earth( ch, "orb of rock" );
}

bool spell_greater_mirage_of_earth( int sn, int level, Character *ch, void *vo, int target )
{
	return mirage_of_earth( ch, "orb of steel" );
}

bool spell_acid_dot( int sn, int level, Character *ch,void *vo,int low,int high,char *noun)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_ACID, SAVE_FORTITUDE) )
    {
        actprintf(victim,NULL,NULL,TO_ROOM,"$n is surrounded by a %s of acid, but it dissipates.",noun);
        actprintf(victim,NULL,NULL,TO_CHAR,"You are surrouned by a %s of acid, but it dissipates.",noun); 
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
        af.caster_id    = ch->id;
        af.bitvector    = DAM_ACID;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = low*3/2;
        af.modifier     = high*3/2;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        actprintf(victim,NULL,NULL,TO_CHAR,"Your flesh melts away as a %s of acid surrounds you!",noun);
        actprintf(victim,NULL,NULL,TO_ROOM,"$n's flesh melts away as a %s of acid surrounds $m.",noun);
    }

    damage( ch, victim, 0, sn, DAM_ACID , DF_SPELL );
    return TRUE;
}

bool spell_film_of_acid(int sn,int level,Character *ch,void *vo,int target)
{
	return spell_acid_dot(sn,level,ch,vo,1,5,"film");
}


bool spell_vapor_of_acid(int sn,int level,Character *ch,void *vo,int target)
{
	return spell_acid_dot(sn,level,ch,vo,6,10,"vapor");
}


bool spell_mist_of_acid(int sn,int level,Character *ch,void *vo,int target)
{
	return spell_acid_dot(sn,level,ch,vo,11,18,"mist");
}


bool spell_haze_of_acid(int sn,int level,Character *ch,void *vo,int target)
{
	return spell_acid_dot(sn,level,ch,vo,19,30,"haze");
}


bool spell_cloud_of_acid(int sn,int level,Character *ch,void *vo,int target)
{
	return spell_acid_dot(sn,level,ch,vo,31,55,"cloud");
}

bool spell_minor_elemental_shield( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet = (Character *) vo;
	Object *shield;
	int i;
	int conj_skill = get_skill(ch,skill_lookup("conjuration"));

	if ( (pet = ch->pet) == NULL )
	{
		cprintf(ch,"You must have a pet!\n\r");
		return FALSE;
	}

	if ( (shield = get_eq_char(pet,WEAR_SHIELD)) != NULL )
	{
		act("$N is already equipped with a shield.",ch,NULL,pet,TO_CHAR);
		return FALSE;
	}
 
	if ( get_obj_index( VNUM_ELEMENTAL_SHIELD ) == NULL )
	{
		act("You are unable to create the shield.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

	if ( (shield = create_object( get_obj_index(VNUM_MAGE_SHIELD) )) == NULL )
	{
		act("You are unable to create the shield.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

	/* Set shield */
	shield->level = level;
	shield->value[5] = mapArmorSlot( gpn_buckler_shields );

	for( i=0 ; i < 4 ; i++ )
		shield->value[i] = conj_skill;

	act("$p wavers into existance in front of $n.",pet,shield,NULL,TO_ROOM);
	act("$p wavers into existance in front of you.",pet,shield,NULL,TO_CHAR);
	shield->timer = level;
	obj_to_char( shield, pet );
	equip_char( pet, shield, WEAR_SHIELD );
	return TRUE;
}

bool spell_lesser_elemental_shield( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet = (Character *) vo;
	Object *shield;
	int i;
	int conj_skill = get_skill(ch,skill_lookup("conjuration"));

	if ( (pet = ch->pet) == NULL )
	{
		cprintf(ch,"You must have a pet!\n\r");
		return FALSE;
	}

	if ( (shield = get_eq_char(pet,WEAR_SHIELD)) != NULL )
	{
		act("$N is already equipped with a shield.",ch,NULL,pet,TO_CHAR);
		return FALSE;
	}
 
	if ( get_obj_index( VNUM_ELEMENTAL_SHIELD ) == NULL )
	{
		act("You are unable to create the shield.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

	if ( (shield = create_object( get_obj_index(VNUM_MAGE_SHIELD) )) == NULL )
	{
		act("You are unable to create the shield.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

	/* Set shield */
	shield->level = level;
	shield->value[5] = mapArmorSlot( gpn_small_shields );

	for( i=0 ; i < 4 ; i++ )
		shield->value[i] = conj_skill;

	act("$p wavers into existance in front of $n.",pet,shield,NULL,TO_ROOM);
	act("$p wavers into existance in front of you.",pet,shield,NULL,TO_CHAR);
	shield->timer = level;
	obj_to_char( shield, pet );
	equip_char( pet, shield, WEAR_SHIELD );
	return TRUE;
}

bool spell_elemental_shield( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet = (Character *) vo;
	Object *shield;
	int i;
	int conj_skill = get_skill(ch,skill_lookup("conjuration"));

	if ( (pet = ch->pet) == NULL )
	{
		cprintf(ch,"You must have a pet!\n\r");
		return FALSE;
	}

	if ( (shield = get_eq_char(pet,WEAR_SHIELD)) != NULL )
	{
		act("$N is already equipped with a shield.",ch,NULL,pet,TO_CHAR);
		return FALSE;
	}
 
	if ( get_obj_index( VNUM_ELEMENTAL_SHIELD ) == NULL )
	{
		act("You are unable to create the shield.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

	if ( (shield = create_object( get_obj_index(VNUM_MAGE_SHIELD) )) == NULL )
	{
		act("You are unable to create the shield.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

	/* Set shield */
	shield->level = level;
	shield->value[5] = mapArmorSlot( gpn_medium_shields );

	for( i=0 ; i < 4 ; i++ )
		shield->value[i] = conj_skill;

	act("$p wavers into existance in front of $n.",pet,shield,NULL,TO_ROOM);
	act("$p wavers into existance in front of you.",pet,shield,NULL,TO_CHAR);
	shield->timer = level;
	obj_to_char( shield, pet );
	equip_char( pet, shield, WEAR_SHIELD );
	return TRUE;
}

bool spell_greater_elemental_shield( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet = (Character *) vo;
	Object *shield;
	int i;
	int conj_skill = get_skill(ch,skill_lookup("conjuration"));

	if ( (pet = ch->pet) == NULL )
	{
		cprintf(ch,"You must have a pet!\n\r");
		return FALSE;
	}

	if ( (shield = get_eq_char(pet,WEAR_SHIELD)) != NULL )
	{
		act("$N is already equipped with a shield.",ch,NULL,pet,TO_CHAR);
		return FALSE;
	}
 
	if ( get_obj_index( VNUM_ELEMENTAL_SHIELD ) == NULL )
	{
		act("You are unable to create the shield.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

	if ( (shield = create_object( get_obj_index(VNUM_MAGE_SHIELD) )) == NULL )
	{
		act("You are unable to create the shield.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

	/* Set shield */
	shield->level = level;
	shield->value[5] = mapArmorSlot( gpn_large_shields );

	for( i=0 ; i < 4 ; i++ )
		shield->value[i] = conj_skill;

	act("$p wavers into existance in front of $n.",pet,shield,NULL,TO_ROOM);
	act("$p wavers into existance in front of you.",pet,shield,NULL,TO_CHAR);
	shield->timer = level;
	obj_to_char( shield, pet );
	equip_char( pet, shield, WEAR_SHIELD );
	return TRUE;
}

bool spell_phantasmal_protector(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;
    
    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(10);
    af.location     = 0;
    af.modifier     = 0;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
 
    spellAffectToChar( victim, &af );
    act("A shimmer in the air near you reveals the presence of a phantasmal protector.",
			victim,NULL,NULL,TO_CHAR);
    act("A shimmer in the air near $n reveals the presence of a phantasmal protector.",
			victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_phantasmal_defender(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(10);
    af.location     = 0;
    af.modifier     = 0;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("A shimmer in the air near you reveals the presence of a phantasmal defender.",
            victim,NULL,NULL,TO_CHAR);
    act("A shimmer in the air near $n reveals the presence of a phantasmal defender.",
            victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_phantasmal_guardian(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(10);
    af.location     = 0;
    af.modifier     = 0;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("A shimmer in the air near you reveals the presence of a phantasmal guardian.",
            victim,NULL,NULL,TO_CHAR);
    act("A shimmer in the air near $n reveals the presence of a phantasmal guardian.",
            victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_dancing_lights(int sn,int level,Character *ch,void *vo,int target)
{
    return mage_mesmerize(sn,level,ch,vo,20);
}

bool spell_dazzling_lights(int sn,int level,Character *ch,void *vo,int target)
{
    return mage_mesmerize(sn,level,ch,vo,40);
}

bool spell_mesmerizing_lights(int sn,int level,Character *ch,void *vo,int target)
{
    return mage_mesmerize(sn,level,ch,vo,60);
}

bool spell_irridescent_lights(int sn,int level,Character *ch,void *vo,int target)
{
    return mage_mesmerize(sn,level,ch,vo,80);
}

bool spell_prismatic_lights(int sn,int level,Character *ch,void *vo,int target)
{
    return mage_mesmerize(sn,level,ch,vo,100);
}

bool spell_color_spray(int sn,int level,Character *ch,void *vo,int target)
{
    Character *vch;
    int ok = 0;

    act("You spread your hands and release a dancing spray of hypnotic lights!",ch,NULL,NULL,TO_CHAR);
    act("$n spreads $s hands and releases a dancing spray of hyponotic lights!",ch,NULL,NULL,TO_ROOM);

    for( vch = ch->in_room->people ; vch ; vch = vch->next_in_room )
    {
        if( vch == ch || is_same_group(vch,ch) || is_safe_spell(ch,vch,TRUE))
            continue;

        ok += spell_dancing_lights(sn,level,ch,(void *)vch,0);
    }

    if ( !ok )
    {
        act("Nobody appears to be affected.",ch,NULL,NULL,TO_CHAR);
        act("Nobody appears to be affected.",ch,NULL,NULL,TO_ROOM);
    }

    return TRUE;
}

bool spell_irridescent_spray(int sn,int level,Character *ch,void *vo,int target)
{
    Character *vch;
    int ok = 0;

    act("You spread your hands and release a dazzling spray of hypnotic lights!",ch,NULL,NULL,TO_CHAR);
    act("$n spreads $s hands and releases a dazzling spray of hyponotic lights!",ch,NULL,NULL,TO_ROOM);

    for( vch = ch->in_room->people ; vch ; vch = vch->next_in_room )
    {
        if( vch == ch || is_same_group(vch,ch) || is_safe_spell(ch,vch,TRUE))
            continue;

        ok += spell_dazzling_lights(sn,level,ch,(void *)vch,0);
    }

    if ( !ok )
    {
        act("Nobody appears to be affected.",ch,NULL,NULL,TO_CHAR);
        act("Nobody appears to be affected.",ch,NULL,NULL,TO_ROOM);
    }

    return TRUE;
}

bool spell_chromatic_spray(int sn,int level,Character *ch,void *vo,int target)
{
    Character *vch;
    int ok = 0;

    act("You spread your hands and release a mesmerizing spray of hypnotic lights!",ch,NULL,NULL,TO_CHAR);
    act("$n spreads $s hands and releases a mesmerizing spray of hyponotic lights!",ch,NULL,NULL,TO_ROOM);

    for( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
    {
        if( vch == ch || is_same_group(vch,ch) || is_safe_spell(ch,vch,TRUE))
            continue;

        ok += spell_mesmerizing_lights(sn,level,ch,(void *)vch,0);
    }

    if ( !ok )
    {
        act("Nobody appears to be affected.",ch,NULL,NULL,TO_CHAR);
        act("Nobody appears to be affected.",ch,NULL,NULL,TO_ROOM);
    }

    return TRUE;
}

bool spell_prismatic_spray(int sn,int level,Character *ch,void *vo,int target)
{
    Character *vch;
    int ok = 0;

    act("You spread your hands and release an irridescent spray of hypnotic lights!",ch,NULL,NULL,TO_CHAR);
    act("$n spreads $s hands and releases an irridescent spray of hyponotic lights!",ch,NULL,NULL,TO_ROOM);

    for( vch = ch->in_room->people ; vch ; vch = vch->next_in_room )
    {
        if( vch == ch || is_same_group(vch,ch) || is_safe_spell(ch,vch,TRUE))
            continue;

        ok += spell_irridescent_lights(sn,level,ch,(void *)vch,0);
    }

    if ( !ok )
    {
        act("Nobody appears to be affected.",ch,NULL,NULL,TO_CHAR);
        act("Nobody appears to be affected.",ch,NULL,NULL,TO_ROOM);
    }

    return TRUE;
}

bool mage_mesmerize(int sn,int level,Character *ch,void *vo,int dur)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( !IS_NPC(victim) )
    {
        act("$N is not an NPC.",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    if ( victim->mez_timer > current_time )
    {
        actprintf(ch,NULL,victim,TO_CHAR,"$N cannot be mesmerized again for %d second%s.",
            victim->mez_timer - current_time, victim->mez_timer - current_time == 1 ? "" : "s");
        return FALSE;
    }

    // You have to make two saving throws to resist a mez
    if ( check_saves_spell(ch, victim, 0, SAVE_WILLPOWER) &&
         check_saves_spell(ch, victim, 0, SAVE_FORTITUDE) )
	{
		act("$N appears to be unaffected.",ch,NULL,victim,TO_CHAR);
		act("A hypnotic display of lights appears but fails to ensnare you.",victim,NULL,NULL,TO_CHAR);
		return TRUE;
	}

    af.where        = TO_AFFECTS;
    af.bitvector    = AFF_MESMERIZE;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(dur);
    af.location     = 0;
    af.modifier     = 0;
    af.flags        = AFF_SPELL;
    af.misc         = 0;
    spellAffectToChar( victim, &af );

    // 2 minute mez timer
    victim->mez_timer = current_time + 120;

	act("$N is enraptured by the hypnotic pattern of lights!",ch,NULL,victim,TO_CHAR);
	act("You are enraptured by the hypnotic pattern of lights!",ch,NULL,victim,TO_VICT);

    // Stop attackers
    stop_fighting( victim, TRUE );
	return TRUE;
}
