#ifndef vnums_h
#define vnums_h

/*
    Mob Vnums
*/

// Shifters
#define SHIFT_VNUM_LION                     1202
#define SHIFT_VNUM_TIGER                    1203
#define SHIFT_VNUM_BEAR                     1204
#define SHIFT_VNUM_WOLF                     1205
#define SHIFT_VNUM_TREANT                   1206

// Arcane Pets
#define MOB_VNUM_ANIMATE_BONES              1
#define MOB_VNUM_SKELETAL_PET               1234
#define MOB_VNUM_ELEMENTAL                  1235
#define MOB_VNUM_SHADOWBEAST                1236
#define VNUM_GOLEM                          1237

/* 
    Object Vnums
*/
#define OBJ_VNUM_DUMMY    1

// Resources
#define VNUM_ANTIMONY                       30745
#define VNUM_ARSENIC                        30746
#define VNUM_COPPER_ORE                     30747
#define VNUM_IRON_ORE                       30748
#define VNUM_LIMESTONE                      30749
#define VNUM_TIN_ORE                        30750

// NPC Hides
#define VNUM_TATTERED_HIDE                  30399
#define VNUM_HIDE                           30398
#define VNUM_FINE_HIDE                      30397

// Spell Loads and Starting Equipment
#define VNUM_ELEMENTAL_SHIELD               1258
#define VNUM_MAGE_SHIELD                    1267
#define VNUM_ELEMENTAL_FLAMESWORD           1268
#define VNUM_ELEMENTAL_EARTHSWORD           1269
#define VNUM_ELEMENTAL_AIRSWORD             1270
#define VNUM_ELEMENTAL_WATERSWORD           1271
#define VNUM_BAG_OF_HOLDING                 1281
#define VNUM_HALO_OF_LIGHT                  1215
#define VNUM_SUMMONED_FOOD                  1216
#define VNUM_SUMMONED_DRINK                 1217
#define VNUM_WARLOCK_SPELLBOOK              1221
#define VNUM_SORCERER_SPELLBOOK             1223
#define VNUM_MAGE_SPELLBOOK                 1225
#define VNUM_ARCANIST_SPELLBOOK             1227
#define VNUM_NEWBIE_SPELLBOOK               1200
#define VNUM_NEWBIE_HEAL_BOOK               3183
#define VNUM_NEWBIE_COURAGE_BOOK            3170
#define VNUM_NEWBIE_ROBES                   1210
#define VNUM_NEWBIE_JERKIN_LEATHER          1211
#define VNUM_NEWBIE_JERKIN_CHAIN            1212
#define VNUM_NEWBIE_BOOTS_LEATHER           1213
#define VNUM_NEWBIE_TORCH                   1214
#define VNUM_NEWBIE_SHAMAN_BOOK             349
#define VNUM_NEWBIE_DRUID_BOOK              321

#define VNUM_WEAPON_THRUSTING_SHORT         26
#define VNUM_WEAPON_THRUSTING_LONG          27
#define VNUM_WEAPON_SLASHING_SHORT          28
#define VNUM_WEAPON_SLASHING_LONG           29
#define VNUM_WEAPON_AXE                     30
#define VNUM_WEAPON_POLEARM                 31
#define VNUM_WEAPON_SPEAR                   32
#define VNUM_WEAPON_1H_CONCUSSION           33
#define VNUM_WEAPON_2H_CONCUSSION           34
#define VNUM_WEAPON_WHIP                    35
#define VNUM_WEAPON_STAFF                   36

// Special internal vnums
/*
 * Well known object virtual numbers.
 * Defined in #OBJECTS.
 */
#define OBJ_VNUM_SPELLBOOK        1200
#define OBJ_VNUM_SILVER_ONE          1
#define OBJ_VNUM_GOLD_ONE            2
#define OBJ_VNUM_GOLD_SOME           3
#define OBJ_VNUM_SILVER_SOME         4
#define OBJ_VNUM_COINS               5
#define OBJ_VNUM_COIN_ONE            6

#define OBJ_VNUM_CORPSE_NPC         10
#define OBJ_VNUM_CORPSE_PC          11
#define OBJ_VNUM_SEVERED_HEAD       12
#define OBJ_VNUM_TORN_HEART         13
#define OBJ_VNUM_SLICED_ARM         14
#define OBJ_VNUM_SLICED_LEG         15
#define OBJ_VNUM_GUTS               16
#define OBJ_VNUM_BRAINS             17
#define OBJ_VNUM_RAW_MEAT           18
#define OBJ_VNUM_COOKED_MEAT        19

#define OBJ_VNUM_MUSHROOM           20
#define OBJ_VNUM_LIGHT_BALL         21
#define OBJ_VNUM_SPRING             22
#define OBJ_VNUM_DISC               23
#define OBJ_VNUM_PORTAL             25
#define OBJ_VNUM_ROSE             1001

#define OBJ_VNUM_PIT              3010

#define OBJ_VNUM_SCHOOL_MACE      3700
#define OBJ_VNUM_SCHOOL_DAGGER    3701
#define OBJ_VNUM_SCHOOL_SWORD     3702
#define OBJ_VNUM_SCHOOL_SPEAR     3717
#define OBJ_VNUM_SCHOOL_STAFF     3718
#define OBJ_VNUM_SCHOOL_AXE       3719
#define OBJ_VNUM_SCHOOL_FLAIL     3720
#define OBJ_VNUM_SCHOOL_WHIP      3721
#define OBJ_VNUM_SCHOOL_POLEARM   3722
#define OBJ_VNUM_SCHOOL_VEST      3703
#define OBJ_VNUM_SCHOOL_SHIELD    3704
#define OBJ_VNUM_SCHOOL_BANNER    3716
#define OBJ_VNUM_MAP              3162

/*
    Room Vnums
*/
#define ROOM_VNUM_LIMBO              2
#define ROOM_VNUM_CHAT              1200
#define ROOM_VNUM_TEMPLE            3001
#define ROOM_VNUM_ALTAR             3054
#define ROOM_VNUM_SCHOOL            9800

#endif /* vnums_h */
