#ifndef global_h
#define global_h

/*
 * Global variables.
 */
extern Help *           help_first;
extern Shop *           shop_first;

extern Character *      char_list;
extern Character *      char_disposition_list;
extern Descriptor *     descriptor_list;
extern Object *         object_list;

extern time_t           boot_time;
extern TimeZone *       tzTable;
extern time_t           current_time;
extern bool             fLogAll;
extern FILE *           fpReserve;
extern FILE *           fpChannel;

/*
 * Global Constants
 */
extern char * const     scan_dir_name[];
extern char * const     extended_dir_name[];
extern char * const     dir_name [];
extern const  sh_int    rev_dir[];          /* sh_int - ROM OLC */

/*
 * Global variables
 */
extern Area * area_first;
extern Area * area_last;
extern Shop * shop_last;

extern int top_timezone;
extern int top_affect;
extern int top_area;
extern int top_ed;
extern int top_exit;
extern int top_note_id;
extern int top_help;
extern int top_mob_index;
extern int top_spell_index;
extern int top_obj_index;
extern int top_recipe_index;
extern int top_quest_index;
extern int top_script_index;
extern int top_reset;
extern int top_room;
extern int top_shop;

extern int top_vnum_script;
extern int top_vnum_mob;
extern int top_vnum_recipe;
extern int top_vnum_quest;
extern int top_vnum_obj;
extern int top_vnum_room;

extern char str_empty       [1];

extern ScriptIndex * script_index_hash[MAX_KEY_HASH];
extern MobIndex *    mob_index_hash[MAX_KEY_HASH];
extern ObjIndex *    obj_index_hash[MAX_KEY_HASH];
extern Room *        room_index_hash[MAX_KEY_HASH];
extern Recipe *      recipe_index_hash[MAX_KEY_HASH];
extern Quest *       quest_index_hash[MAX_KEY_HASH];

#endif /* global_h */
