/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/******************************************************************
 ArpensMUD 3.2, Server II.  Arcane Spell System "Khav" Release 1.0
 Copyright Benjamin J. Siders, Cross-Check MSDG 2001, 2002 
 
 The Cleric-specific spells from the 'fury' release.  

 All of the "Fury" spells are based on concepts from:
 
 Ultima, EverQuest, Dungeons and Dragons, Advanced Dungeons and Dragons, 
 Earthdawn, Baldur's Gate, Shadows of Amn, Quest for Glory, and untold
 other games we've all played.
 ******************************************************************/

/** System Include Files **/
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/** Custom Header Files **/
#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "tables.h"
#include "recycle.h"

void clear_NPC_disposition( Character * );

/** The library of Cleric spells, arranged alphabetically */

bool spell_aura_of_grace( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(18);
    af.location     = APPLY_ABSORB;
    af.modifier     = 6;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );

    cprintf(victim,"A mystical aura shimmers around your body.\n\r");
    act("A mystical aura shimmers around $n.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}   

bool spell_aura_of_sanctity( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(18);
    af.location     = APPLY_ABSORB;
    af.modifier     = 8;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );

    cprintf(victim,"A mystical aura shimmers around your body.\n\r");
    act("A mystical aura shimmers around $n.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}   

bool spell_aura_of_devotion( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(18);
    af.location     = APPLY_ABSORB;
    af.modifier     = 4;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );

    cprintf(victim,"A mystical aura shimmers around your body.\n\r");
    act("A mystical aura shimmers around $n.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}   

bool spell_aura_of_faith( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;
 
    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(18);
    af.location     = APPLY_ABSORB;
    af.modifier     = 2;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );

	cprintf(victim,"A mystical aura shimmers around your body.\n\r");
	act("A mystical aura shimmers around $n.",victim,NULL,NULL,TO_ROOM);
    return TRUE;   
}

bool spell_cause_minor_wounds( int sn, int level, Character *ch,void *vo,int target) 
{
	Character *victim = (Character *) vo;
	int dam;

	dam = calcSpellDamage(ch,sn,6,8);

	if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
		dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
} 

bool spell_cause_light_wounds( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,16,20);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_cause_moderate_wounds( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,31,39);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_cause_major_wounds( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,63,79);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_cause_serious_wounds( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,118,147);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;

    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_cause_critical_wounds( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,190,238);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_rebuke_undead_c( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

	if ( !IS_SET(victim->form,FORM_UNDEAD))
	{
		act("$N is not undead!",ch,NULL,victim,TO_CHAR);
		return FALSE;
	}

    dam = calcSpellDamage(ch,sn,10,12);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_ward_undead_c( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;       

    if ( !IS_SET(victim->form,FORM_UNDEAD))
    {
        act("$N is not undead!",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,18,22);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );      
    return TRUE;
}

bool spell_repulse_undead_c( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;       

    if ( !IS_SET(victim->form,FORM_UNDEAD))
    {
        act("$N is not undead!",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,30,37);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );      
    return TRUE;
}

bool spell_dismiss_undead_c( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;       

    if ( !IS_SET(victim->form,FORM_UNDEAD))
    {
        act("$N is not undead!",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,49,60);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );      
    return TRUE;
}

bool spell_expel_undead_c( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;       

    if ( !IS_SET(victim->form,FORM_UNDEAD))
    {
        act("$N is not undead!",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,73,89);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );      
    return TRUE;
}

bool spell_exile_undead_c( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;       

    if ( !IS_SET(victim->form,FORM_UNDEAD))
    {
        act("$N is not undead!",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,116,142);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );      
    return TRUE;
}

bool spell_banish_undead_c( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;       

    if ( !IS_SET(victim->form,FORM_UNDEAD))
    {
        act("$N is not undead!",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,169,206);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );      
    return TRUE;
}

bool spell_courage( int sn, int level, Character *ch, void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;
	SpellIndex* pSpellIndex;
	int skill, SHbon;

	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		skill = get_skill(ch,*(pSpellIndex->sgsn));
	}
	else
	{
		log_bug("spell_courage: Spell index not found(%d)",sn);
		return TRUE;
	}

 	SHbon = UMIN(8,(skill-1)*2);
	
    if ( is_affected( victim, sn ,AFF_SPELL) )
    {
        if (victim == ch)
          send_to_char("You already feel courageous..\n\r",ch);
        else
          act("$N is already courageous.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(30);
    af.location  = APPLY_AC;
    af.modifier  = 10;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    af.location  = APPLY_HIT;
    af.modifier  = 10 + SHbon;
    spellAffectToChar( victim, &af );

    act( "$n is filled with courage.", victim, NULL, NULL, TO_ROOM );
    cprintf(victim,"You are filled with courage!\n\r");
    return TRUE;
}

bool spell_bravery( int sn, int level, Character *ch, void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;
	SpellIndex* pSpellIndex;
	int skill, SHbon;

	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		skill = get_skill(ch,*(pSpellIndex->sgsn));
	}
	else
	{
		log_bug("spell_bravery: Spell index not found(%d)",sn);
		return TRUE;
	}

    SHbon = UMIN(14,(skill-pSpellIndex->class_level[ch->class])*2);

    if ( is_affected( victim, sn ,AFF_SPELL) )
    {
        if (victim == ch)
          send_to_char("You already feel courageous..\n\r",ch);
        else
          act("$N is already courageous.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(36);
    af.location  = APPLY_AC;
    af.modifier  = 20;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    af.location  = APPLY_HIT;
    af.modifier  = 20 + SHbon;

    spellAffectToChar( victim, &af );

    act( "$n is filled with bravery.", victim, NULL, NULL, TO_ROOM );
    cprintf(victim,"You are filled with bravery!\n\r");
    return TRUE;
}

bool spell_valor( int sn, int level, Character *ch, void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;
	SpellIndex* pSpellIndex;
	int skill, SHbon;

	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		skill = get_skill(ch,*(pSpellIndex->sgsn));
	}
	else
	{
		log_bug("spell_valor: Spell index not found(%d)",sn);
		return TRUE;
	}

	SHbon = UMIN(17,(skill-pSpellIndex->class_level[ch->class])*3);

    if ( is_affected( victim, sn ,AFF_SPELL) )
    {
        if (victim == ch)
          send_to_char("You already feel courageous..\n\r",ch);
        else
          act("$N is already courageous.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(42);
    af.location  = APPLY_AC;
    af.modifier  = 30;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    af.location  = APPLY_HIT;
    af.modifier  = 34 + SHbon;
    spellAffectToChar( victim, &af );

    act( "$n is filled with valor.", victim, NULL, NULL, TO_ROOM );
    cprintf(victim,"You are filled with valor!\n\r");
    return TRUE;
}

bool spell_boldness( int sn, int level, Character *ch, void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;
	SpellIndex* pSpellIndex;
	int skill, SHbon;

	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		skill = get_skill(ch,*(pSpellIndex->sgsn));
	}
	else
	{
		log_bug("spell_boldness: Spell index not found(%d)",sn);
		return TRUE;
	}

	SHbon = UMIN(19,(skill-pSpellIndex->class_level[ch->class])*3);

    if ( is_affected( victim, sn ,AFF_SPELL) )
    {
        if (victim == ch)
          send_to_char("You already feel courageous..\n\r",ch);
        else
          act("$N is already courageous.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(48);
    af.location  = APPLY_AC;
    af.modifier  = 55;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    af.location  = APPLY_HIT;
    af.modifier  = 52 + SHbon;
    spellAffectToChar( victim, &af );

    act( "$n is filled with boldness.", victim, NULL, NULL, TO_ROOM );
    cprintf(victim,"You are filled with boldness!\n\r");
    return TRUE;
}


bool spell_resolution( int sn, int level, Character *ch, void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;
	SpellIndex* pSpellIndex;
	int skill, SHbon;

	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		skill = get_skill(ch,*(pSpellIndex->sgsn));
	}
	else
	{
		log_bug("spell_resolution: Spell index not found(%d)",sn);
		return TRUE;
	}

	SHbon = UMIN(19,(skill-pSpellIndex->class_level[ch->class])*3);


    if ( is_affected( victim, sn ,AFF_SPELL) )
    {
        if (victim == ch)
          send_to_char("You already feel courageous..\n\r",ch);
        else
          act("$N is already courageous.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(54);
    af.location  = APPLY_AC;
    af.modifier  = 75;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    af.location  = APPLY_HIT;
    af.modifier  = 72 + SHbon;
    spellAffectToChar( victim, &af );

    act( "$n is filled with resolution.", victim, NULL, NULL, TO_ROOM );
    cprintf(victim,"You are filled with resolution!\n\r");
    return TRUE;
}

bool spell_gallantry( int sn, int level, Character *ch, void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;
	SpellIndex* pSpellIndex;
	int skill, SHbon;

	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		skill = get_skill(ch,*(pSpellIndex->sgsn));
	}
	else
	{
		log_bug("spell_gallantry: Spell index not found(%d)",sn);
		return TRUE;
	}

	SHbon = UMIN(21,(skill-pSpellIndex->class_level[ch->class])*3);

    if ( is_affected( victim, sn ,AFF_SPELL) )
    {
        if (victim == ch)
          send_to_char("You already feel courageous..\n\r",ch);
        else
          act("$N is already courageous.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(63);
    af.location  = APPLY_AC;
    af.modifier  = 100;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    af.location  = APPLY_HIT;
    af.modifier  = 94 + SHbon;
    spellAffectToChar( victim, &af );

    act( "$n is filled with gallantry.", victim, NULL, NULL, TO_ROOM );
    cprintf(victim,"You you are filled with gallantry!\n\r");
    return TRUE;
}

bool spell_audacity( int sn, int level, Character *ch, void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;
	SpellIndex* pSpellIndex;
	int skill, SHbon;

	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		skill = get_skill(ch,*(pSpellIndex->sgsn));
	}
	else
	{
		log_bug("spell_audacity: Spell index not found(%d)",sn);
		return TRUE;
	}

	SHbon = UMIN(25,(skill-pSpellIndex->class_level[ch->class])*3);

    if ( is_affected( victim, sn ,AFF_SPELL) )
    {
        if (victim == ch)
          send_to_char("You already feel courageous..\n\r",ch);
        else
          act("$N is already courageous.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(63);
    af.location  = APPLY_AC;
    af.modifier  = 130;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    af.location  = APPLY_HIT;
    af.modifier  = 118 + SHbon;
    spellAffectToChar( victim, &af );

    act( "$n is filled with audacity.", victim, NULL, NULL, TO_ROOM );
    cprintf(victim,"You you are filled with audacity!\n\r");
    return TRUE;
}

bool spell_heroism( int sn, int level, Character *ch, void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;
	SpellIndex* pSpellIndex;
	int skill, SHbon;

	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		skill = get_skill(ch,*(pSpellIndex->sgsn));
	}
	else
	{
		log_bug("spell_heroism: Spell index not found(%d)",sn);
		return TRUE;
	}

	SHbon = (skill-pSpellIndex->class_level[ch->class])*4;
	
    if ( is_affected( victim, sn ,AFF_SPELL) )
    {
        if (victim == ch)
          send_to_char("You already feel courageous..\n\r",ch);
        else
          act("$N is already courageous.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(63);
    af.location  = APPLY_AC;
    af.modifier  = 165;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    af.location  = APPLY_HIT;
    af.modifier  = 144 + SHbon;
    spellAffectToChar( victim, &af );

    act( "$n is filled with heroism.", victim, NULL, NULL, TO_ROOM );
    cprintf(victim,"You you are filled with heroism!\n\r");
    return TRUE;
}


bool spell_divine_immunity( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_IMMUNE;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(12);
    af.location     = 0;
    af.modifier     = 0;
    af.bitvector    = IMM_WEAPON;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
    
    af.bitvector	= IMM_MAGIC;
    spellAffectToChar( victim, &af );
    
    act("You are protected by $y!\n\r",victim,NULL,NULL,TO_CHAR);
    act("$n is surrounded by a shimmering sphere of immunity!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_divine_invulnerability( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_IMMUNE;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(18);
    af.location     = 0;
    af.modifier     = 0;
    af.bitvector    = IMM_WEAPON;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
    
    af.bitvector	= IMM_MAGIC;
    spellAffectToChar( victim, &af );
    
    act("You are protected by $y!\n\r",victim,NULL,NULL,TO_CHAR);
    act("$n is surrounded by a shimmering sphere of invulnerability!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_divine_imperviousness( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_IMMUNE;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(24);
    af.location     = 0;
    af.modifier     = 0;
    af.bitvector    = IMM_WEAPON;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
    
    af.bitvector	= IMM_MAGIC;
    spellAffectToChar( victim, &af );
    
    act("You are protected by $y!\n\r",victim,NULL,NULL,TO_CHAR);
    act("$n is surrounded by a shimmering sphere of imperviousness!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_divine_invincibility( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_IMMUNE;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(30);
    af.location     = 0;
    af.modifier     = 0;
    af.bitvector    = IMM_WEAPON;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
    
    af.bitvector 	= IMM_MAGIC;
    spellAffectToChar( victim, &af );
    
    act("You are protected by $y!\n\r",victim,NULL,NULL,TO_CHAR);
    act("$n is surrounded by a shimmering sphere of invincibility!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_faith( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(20);
    af.location     = APPLY_HITROLL;
    af.modifier     = 10;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

	act("You are filled with faith in $y.",victim,NULL,NULL,TO_CHAR);
	act("$n radiates a white aura briefly.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_piety( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(26);
    af.location     = APPLY_HITROLL;
    af.modifier     = 30;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("You are filled with pious belief in $y.",victim,NULL,NULL,TO_CHAR);
    act("$n radiates a white aura briefly.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_devotion( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(32);
    af.location     = APPLY_HITROLL;
    af.modifier     = 55;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("You are filled with devotion to $y.",victim,NULL,NULL,TO_CHAR);
    act("$n radiates a white aura briefly.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_grace( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(38);
    af.location     = APPLY_HITROLL;
    af.modifier     = 85;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("You are filled with the grace of $y.",victim,NULL,NULL,TO_CHAR);
    act("$n radiates with a bright white aura briefly.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_justice( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(44);
    af.location     = APPLY_HITROLL;
    af.modifier     = 120;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("You are filled with the justice of $y.",victim,NULL,NULL,TO_CHAR);
    act("$n radiates with a bright white aura briefly.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_zeal( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(50);
    af.location     = APPLY_HITROLL;
    af.modifier     = 160;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("You are filled with zeal for $y.",victim,NULL,NULL,TO_CHAR);
    act("$n radiates with a bright white aura briefly.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_holiness( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(56);
    af.location     = APPLY_HITROLL;
    af.modifier     = 205;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("You are filled with the holiness of $y.",victim,NULL,NULL,TO_CHAR);
    act("$n radiates with a blinding white aura.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_sanctity( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(62);
    af.location     = APPLY_HITROLL;
    af.modifier     = 255;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("You are filled with the sanctity of $y.",victim,NULL,NULL,TO_CHAR);
    act("$n radiates with a brilliant white aura!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}


bool spell_holy_armor( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(32);
    af.location     = APPLY_AC;
    af.modifier     = 8;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("You are protected by holy armor.",victim,NULL,NULL,TO_CHAR);
    actprintf(victim,NULL,NULL,TO_ROOM,"A glowing suit of shimmering %s armor covers $n.",
		deity_table[ch->deity].align == ALIGN_GOOD ? "white" :
			(deity_table[ch->deity].align == ALIGN_EVIL ? "black" : "grey") );
    return TRUE;
}

bool spell_holy_shield( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_AC;
    af.modifier     = 16;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("You are protected by a holy shield.",victim,NULL,NULL,TO_CHAR);
    actprintf(victim,NULL,NULL,TO_ROOM,"A %s shield of divine power floats before $n.",
        deity_table[ch->deity].align == ALIGN_GOOD ? "golden" :
            (deity_table[ch->deity].align == ALIGN_EVIL ? "charcoal" : "crimson") );
    return TRUE;
}

bool spell_holy_deflection( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(48);
    af.location     = APPLY_AC;
    af.modifier     = 25;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("You are protected by a holy shield of deflection.",victim,NULL,NULL,TO_CHAR);
    actprintf(victim,NULL,NULL,TO_ROOM,"A %s shield of divine deflection floats before $n.",
        deity_table[ch->deity].align == ALIGN_GOOD ? "golden" :
            (deity_table[ch->deity].align == ALIGN_EVIL ? "charcoal" : "crimson") );
    return TRUE;
}

bool spell_holy_defense( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(56);
    af.location     = APPLY_AC;
    af.modifier     = 35;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("You are protected by a holy aura of defense.",victim,NULL,NULL,TO_CHAR);
    actprintf(victim,NULL,NULL,TO_ROOM,"A %s globe of defense envelops $n.",
        deity_table[ch->deity].align == ALIGN_GOOD ? "bright" :
            (deity_table[ch->deity].align == ALIGN_EVIL ? "dark" : "luminous") );
    return TRUE;
}

bool spell_holy_protection( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(62);
    af.location     = APPLY_AC;
    af.modifier     = 47;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("You are protected by a holy aura of protection.",victim,NULL,NULL,TO_CHAR);
    actprintf(victim,NULL,NULL,TO_ROOM,"A %s globe of protection envelops $n.",
        deity_table[ch->deity].align == ALIGN_GOOD ? "bright" :
            (deity_table[ch->deity].align == ALIGN_EVIL ? "dark" : "luminous") );
    return TRUE;
}

bool spell_holy_guardian( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(70);
    af.location     = APPLY_AC;
    af.modifier     = 60;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("You are protected by a holy guardian.",victim,NULL,NULL,TO_CHAR);
    actprintf(victim,NULL,NULL,TO_ROOM,"A%s guardian protects $n from harm.",
        deity_table[ch->deity].align == ALIGN_GOOD ? "n angelic" :
            (deity_table[ch->deity].align == ALIGN_EVIL ? " demonic" : " sagacious") );
    return TRUE;
}

/* Symbol spells */
bool spell_symbol_of_ceina( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(45);
    af.location     = APPLY_BASE_HITS;
    af.modifier     = victim->max_base_hit / 10;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("The Symbol of Ceina floats before your eyes.",victim,NULL,NULL,TO_CHAR);
	if ( victim != ch )
		act("The Symbol of Ceina floats before $N.",ch,NULL,victim,TO_CHAR);

	victim->base_hit += ( victim->max_base_hit / 10 );
    return TRUE;
}

bool spell_symbol_of_alaina( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;  
    af.duration     = minutes(54);
    af.location     = APPLY_BASE_HITS;
    af.modifier     = victim->max_base_hit / 5;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("The Symbol of Alaina floats before your eyes.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("The Symbol of Alaina floats before $N.",ch,NULL,victim,TO_CHAR);

	victim->base_hit += ( victim->max_base_hit / 5 );
    return TRUE; 
}

bool spell_symbol_of_kaliena( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;  
    af.duration     = minutes(63);
    af.location     = APPLY_BASE_HITS;
    af.modifier     = victim->max_base_hit * 3 / 10;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("The Symbol of Kaliena floats before your eyes.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("The Symbol of Kaliana floats before $N.",ch,NULL,victim,TO_CHAR);

	victim->base_hit += ( victim->max_base_hit *3/ 10 );
    return TRUE; 
}

bool spell_symbol_of_heliana( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;  
    af.duration     = minutes(72);
    af.location     = APPLY_BASE_HITS;
    af.modifier     = victim->max_base_hit * 4 / 10;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("The Symbol of Heliana floats before your eyes.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("The Symbol of Heliana floats before $N.",ch,NULL,victim,TO_CHAR);

	victim->base_hit += ( victim->max_base_hit *4/ 10 );
    return TRUE; 
}

bool spell_symbol_of_jalayna( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;  
    af.duration     = minutes(81);
    af.location     = APPLY_BASE_HITS;
    af.modifier     = victim->max_base_hit * 5/ 10;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("The Symbol of Jalayna floats before your eyes.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("The Symbol of Jalayna floats before $N.",ch,NULL,victim,TO_CHAR);

	victim->base_hit += ( victim->max_base_hit * 5/ 10 );
    return TRUE; 
}

bool cleric_strength_burst( int sn, int level, Character *ch, void *vo, int target,
							int amount, int duration, char *message1, char *message2 )
{
	Character *victim = (Character *) vo;

	Affect af;

	af.where			= TO_AFFECTS;
	af.type				= sn;
	af.level			= level;
	af.duration			= seconds(duration);
	af.location			= APPLY_STR;
	af.modifier			= amount;
	af.bitvector		= 0;
	af.flags			= AFF_SPELL;
	spellAffectToChar( victim, &af );

	act(message1,victim,NULL,NULL,TO_CHAR);
	act(message2,victim,NULL,NULL,TO_ROOM);
	return TRUE;
}

bool spell_righteous_strength( int sn, int level, Character *ch, void *vo, int target )
{
	return cleric_strength_burst(sn,level,ch,vo,target,40,39,
		"You are consumed with righteous strength!",
		"$n is consumed with righteous strength!");
}

bool spell_righteous_power( int sn, int level, Character *ch, void *vo, int target )
{
	return cleric_strength_burst(sn,level,ch,vo,target,60,48,
		"You are consumed with righteous power!",
		"$n is consumed with righteous power!");
}

bool spell_righteous_anger( int sn, int level, Character *ch, void *vo, int target )
{
    return cleric_strength_burst(sn,level,ch,vo,target,80,57,
        "You are consumed with righteous anger!",
        "$n is consumed with righteous anger!");
}

bool spell_righteous_fury( int sn, int level, Character *ch, void *vo, int target )
{
    return cleric_strength_burst(sn,level,ch,vo,target,100,66,
        "You are consumed with righteous fury!",
        "$n is consumed with righteous fury!");
}

bool cleric_blind( int sn, int level, Character *ch, void *vo, int target,
					int duration, int modifier, 
					char *message1, char *message2 )
{
    Character *victim = (Character *) vo;
    Affect af;
    bool fSave;

    if ( (fSave = check_saves_spell(ch, victim, DAM_FIRE, SAVE_WILLPOWER)) )
	{
		act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
		act("Your eyes sting briefly but the sensation fades.",victim,NULL,NULL,TO_CHAR);
		return TRUE;
	}

    af.where        = TO_AFFECTS;
    af.bitvector    = AFF_BLIND;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(duration);
    af.location     = APPLY_HITROLL;
    af.modifier     = modifier;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act(message1,victim,NULL,NULL,TO_CHAR);
    act(message2,victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_luminance( int sn, int level, Character *ch, void *vo, int target )
{
    return cleric_blind(sn,level,ch,vo,target,20,-24,
        "You are struck blind by divine luminance!",
        "$n is struck blind!");
}

bool spell_pious_luminance( int sn, int level, Character *ch, void *vo, int target )
{
    return cleric_blind(sn,level,ch,vo,target,28,-52, 
        "You are struck blind by divine luminance!", 
        "$n is struck blind!");
}

bool spell_devoted_luminance( int sn, int level, Character *ch, void *vo, int target )
{
    return cleric_blind(sn,level,ch,vo,target,36,-84, 
        "You are struck blind by divine luminance!", 
        "$n is struck blind!");
}

bool spell_just_luminance( int sn, int level, Character *ch, void *vo, int target )
{
    return cleric_blind(sn,level,ch,vo,target,44,-120, 
        "You are struck blind by divine luminance!", 
        "$n is struck blind!");
}

bool spell_holy_luminance( int sn, int level, Character *ch, void *vo, int target )
{
    return cleric_blind(sn,level,ch,vo,target,52,-160, 
        "You are struck blind by divine luminance!", 
        "$n is struck blind!");
}

bool spell_divine_luminance( int sn, int level, Character *ch, void *vo, int target )
{
    return cleric_blind(sn,level,ch,vo,target,60,-204, 
        "You are struck blind by divine luminance!", 
        "$n is struck blind!");
}

bool spell_shroud_of_guilt( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_WILLPOWER) )
    {
        cprintf(ch,"You failed.\n\r");
        cprintf(victim,"Your spirit feels weak, but you recover.\n\r");
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(20);
    af.modifier  = -10;
    af.location  = APPLY_RES_SPIRIT;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n appears to be uncomfortable.",victim,NULL,NULL,TO_ROOM);
    act("You feel weak in spirit.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_shroud_of_shame( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_WILLPOWER) )
    {
        cprintf(ch,"You failed.\n\r");
        cprintf(victim,"Your spirit feels weak, but you recover.\n\r"); 
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(20);
    af.modifier  = -20;
    af.location  = APPLY_RES_SPIRIT;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n appears to be uncomfortable.",victim,NULL,NULL,TO_ROOM);
    act("You feel weak in spirit.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_shroud_of_sin( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_WILLPOWER) )
    {
        cprintf(ch,"You failed.\n\r");
        cprintf(victim,"Your spirit feels weak, but you recover.\n\r"); 
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(20);
    af.modifier  = -30;
    af.location  = APPLY_RES_SPIRIT;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n appears to be uncomfortable.",victim,NULL,NULL,TO_ROOM);
    act("You feel weak in spirit.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_purity_of_spirit( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;     

    af.where        = TO_AFFECTS;
    af.type         = sn; 
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_RES_SPIRIT;
    af.modifier     = 15;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your spirit is protected.",victim,NULL,NULL,TO_CHAR);
    if( ch != victim )    
        act("$N is protected in spirit.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_clarity_of_spirit( int sn, int level, Character *ch,void *vo,int target) 
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_RES_SPIRIT;
    af.modifier     = 30;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your spirit is protected.",victim,NULL,NULL,TO_CHAR);               
    if( ch != victim ) 
        act("$N is protected in spirit.",ch,NULL,victim,TO_CHAR); 

    return TRUE;
}

bool spell_solidarity_of_spirit( int sn, int level, Character *ch,void *vo,int target) 
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_RES_SPIRIT;
    af.modifier     = 50;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your spirit is protected.",victim,NULL,NULL,TO_CHAR);               
    if( ch != victim ) 
        act("$N is protected in spirit.",ch,NULL,victim,TO_CHAR); 

    return TRUE;
}

bool spell_stun_person( int sn, int level, Character *ch, void *vo, int target )
{
	Character *victim = (Character *) vo;
	
	if ( !IS_SET(victim->form,FORM_HUMANOID) )
	{
		act("$N is not a humanoid.",ch,NULL,victim,TO_CHAR);
		return FALSE;
	}

    if ( victim->stun_timer > current_time )
    {
        actprintf(ch,NULL,victim,TO_CHAR,"$N cannot be stunned for %d more second%s.",
            current_time - victim->stun_timer,
            current_time - victim->stun_timer == 1 ? "" : "s" );
        return FALSE;
    }

	if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
        act("Your muscles stiffen but then relax again.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

	act("You are stunned!",victim,NULL,NULL,TO_CHAR);
	act("$n is stunned!",victim,NULL,NULL,TO_ROOM);
	DAZE_STATE(victim,PULSE_PER_SECOND * 3);
	return TRUE;
}

bool spell_halt_person( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    if ( !IS_SET(victim->form,FORM_HUMANOID) )
    {
        act("$N is not a humanoid.",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    if ( victim->stun_timer > current_time )
    {
        actprintf(ch,NULL,victim,TO_CHAR,"$N cannot be stunned for %d more second%s.",
            current_time - victim->stun_timer,
            current_time - victim->stun_timer == 1 ? "" : "s" );
        return FALSE;
    }

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
        act("Your muscles stiffen but then relax again.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n is stunned!",victim,NULL,NULL,TO_ROOM);
    DAZE_STATE(victim,PULSE_PER_SECOND * 5);
    return TRUE;
}

bool spell_freeze_person( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    if ( !IS_SET(victim->form,FORM_HUMANOID) )
    {
        act("$N is not a humanoid.",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    if ( victim->stun_timer > current_time )
    {
        actprintf(ch,NULL,victim,TO_CHAR,"$N cannot be stunned for %d more second%s.",
            current_time - victim->stun_timer,
            current_time - victim->stun_timer == 1 ? "" : "s" );
        return FALSE;
    }

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
        act("Your muscles stiffen but then relax again.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n is stunned!",victim,NULL,NULL,TO_ROOM);
    DAZE_STATE(victim,PULSE_PER_SECOND * 7);
    return TRUE;
}

bool spell_hold_person( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    if ( !IS_SET(victim->form,FORM_HUMANOID) )
    {
        act("$N is not a humanoid.",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    if ( victim->stun_timer > current_time )
    {
        actprintf(ch,NULL,victim,TO_CHAR,"$N cannot be stunned for %d more second%s.",
            current_time - victim->stun_timer,
            current_time - victim->stun_timer == 1 ? "" : "s" );
        return FALSE;
    }

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
        act("Your muscles stiffen but then relax again.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n is stunned!",victim,NULL,NULL,TO_ROOM);
    DAZE_STATE(victim,PULSE_PER_SECOND * 9);
    return TRUE;
}

bool spell_immobilize_person( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    if ( !IS_SET(victim->form,FORM_HUMANOID) )
    {
        act("$N is not a humanoid.",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    if ( victim->stun_timer > current_time )
    {
        actprintf(ch,NULL,victim,TO_CHAR,"$N cannot be stunned for %d more second%s.",
            current_time - victim->stun_timer,
            current_time - victim->stun_timer == 1 ? "" : "s" );
        return FALSE;
    }

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
        act("Your muscles stiffen but then relax again.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n is stunned!",victim,NULL,NULL,TO_ROOM);
    DAZE_STATE(victim,PULSE_PER_SECOND * 11);
    return TRUE;
}

bool spell_paralyze_person( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    if ( !IS_SET(victim->form,FORM_HUMANOID) )
    {
        act("$N is not a humanoid.",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    if ( victim->stun_timer > current_time )
    {
        actprintf(ch,NULL,victim,TO_CHAR,"$N cannot be stunned for %d more second%s.",
            current_time - victim->stun_timer,
            current_time - victim->stun_timer == 1 ? "" : "s" );
        return FALSE;
    }

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
        act("Your muscles stiffen but then relax again.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n is stunned!",victim,NULL,NULL,TO_ROOM);
    DAZE_STATE(victim,PULSE_PER_SECOND * 13);
    return TRUE;
}


bool spell_purification( int sn, int level, Character *ch, void *vo, int target)
{
    Character *victim = (Character *) vo;
    Affect          af;

    if ( !IS_SET(victim->form,FORM_UNDEAD) )
    {
        act("$N is not undead.",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
	{
		act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
		return TRUE;
	}

    af.where        = DAMAGE_OVER_TIME;
	af.caster_id	= ch->id;
    af.bitvector    = DAM_SPIRIT;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(60);
    af.location     = 18;
    af.modifier     = 22;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

	act("$n cringes in the agony of purification!",victim,NULL,NULL,TO_ROOM);
	act("You cringe in the agony of purification!",victim,NULL,NULL,TO_CHAR);
	return TRUE;
}

bool spell_mundation( int sn, int level, Character *ch, void *vo, int target)
{
    Character *victim = (Character *) vo;
    Affect          af;

    if ( !IS_SET(victim->form,FORM_UNDEAD) )
    {
        act("$N is not undead.",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
    {
        act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    af.where        = DAMAGE_OVER_TIME;
	af.caster_id	= ch->id;
    af.bitvector    = DAM_SPIRIT;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(60);
    af.location     = 28;
    af.modifier     = 36;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n cringes in the agony of mundation!",victim,NULL,NULL,TO_ROOM);
    act("You cringe in the agony of mundation!",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_ablution( int sn, int level, Character *ch, void *vo, int target)
{
    Character *victim = (Character *) vo;
    Affect          af;

    if ( !IS_SET(victim->form,FORM_UNDEAD) )
    {
        act("$N is not undead.",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
    {
        act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    af.where        = DAMAGE_OVER_TIME;
	af.caster_id	= ch->id;
    af.bitvector    = DAM_SPIRIT;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(60);
    af.location     = 44;
    af.modifier     = 54;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n cringes in the agony of ablution!",victim,NULL,NULL,TO_ROOM);
    act("You cringe in the agony of ablution!",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_abstersion( int sn, int level, Character *ch, void *vo, int target)
{
    Character *victim = (Character *) vo;
    Affect          af;

    if ( !IS_SET(victim->form,FORM_UNDEAD) )
    {
        act("$N is not undead.",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
    {
        act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    af.where        = DAMAGE_OVER_TIME;
	af.caster_id	= ch->id;
    af.bitvector    = DAM_SPIRIT;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(60);
    af.location     = 64;
    af.modifier     = 76;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n cringes in the agony of abstersion!",victim,NULL,NULL,TO_ROOM);
    act("You cringe in the agony of abstersion!",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_detersion( int sn, int level, Character *ch, void *vo, int target)
{
    Character *victim = (Character *) vo;
    Affect          af;

    if ( !IS_SET(victim->form,FORM_UNDEAD) )
    {
        act("$N is not undead.",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
    {
        act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    af.where        = DAMAGE_OVER_TIME;
	af.caster_id	= ch->id;
    af.bitvector    = DAM_SPIRIT;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(60);
    af.location     = 96;
    af.modifier     = 114;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n cringes in the agony of detersion!",victim,NULL,NULL,TO_ROOM);
    act("You cringe in the agony of detersion!",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_dearth(int sn , int level, Character *ch, void *vo, int target)
{
    Character *victim = (Character *) vo;
    Affect          af;

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_WILLPOWER) )
    {
        act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(5);
    af.location     = APPLY_SAVE_REFLEX;
    af.modifier     = -15;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

	af.location		= APPLY_SAVE_WILLPOWER;
	spellAffectToChar( victim, &af );
	
	af.location		= APPLY_SAVE_FORTITUDE;
	spellAffectToChar( victim, &af );

	act("Your soul is devoid of purpose.",victim,NULL,NULL,TO_CHAR);
	act("$N appears to be dejected and aimless.",victim,NULL,NULL,TO_ROOM);
	return TRUE;
}

bool spell_paucity(int sn , int level, Character *ch, void *vo, int target)
{
    Character *victim = (Character *) vo;
    Affect          af;

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_WILLPOWER) )
    {
        act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(5);
    af.location     = APPLY_SAVE_REFLEX;
    af.modifier     = -30;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    af.location     = APPLY_SAVE_WILLPOWER;
    spellAffectToChar( victim, &af );

    af.location     = APPLY_SAVE_FORTITUDE;
    spellAffectToChar( victim, &af );

    act("Your soul is devoid of purpose.",victim,NULL,NULL,TO_CHAR);
    act("$N appears to be dejected and aimless.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_exiguity(int sn , int level, Character *ch, void *vo, int target)
{
    Character *victim = (Character *) vo;
    Affect          af;

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_WILLPOWER) )
    {
        act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(5);
    af.location     = APPLY_SAVE_REFLEX;
    af.modifier     = -45;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    af.location     = APPLY_SAVE_WILLPOWER;
    spellAffectToChar( victim, &af );

    af.location     = APPLY_SAVE_FORTITUDE;
    spellAffectToChar( victim, &af );

    act("Your soul is devoid of purpose.",victim,NULL,NULL,TO_CHAR);
    act("$N appears to be dejected and aimless.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}


bool spell_atone( int sn, int level, Character *ch, void *vo, int target )
{
	Character *victim = (Character *) vo;
	Melee *m, *m_next;
	
	if ( !IS_NPC(victim) )
	{
		act("$N is not an NPC.",ch,NULL,victim,TO_CHAR);
		return FALSE;
	}
	
	for( m = victim->melee_list ; m != NULL ; m = m_next )
	{
		m_next = m->next;
		
		free_melee( m );
	}
	
	victim->melee_list = NULL;
    clear_NPC_disposition( victim );

	act("You atone for all aggression against $N.",ch,NULL,victim,TO_CHAR);
	act("$n atones for all aggression against you.",ch,NULL,victim,TO_VICT);
	act("$n atones for all aggression against $N.",ch,NULL,victim,TO_NOTVICT);
	return TRUE;
}

bool spell_sphere_of_cure_minor_wounds( int sn, int level, Character *ch, void *vo, int target )
{
    extern Spell( cure_minor_wounds );
	Character *victim;
	int i;
	
	for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
	{
		if ( (victim = ch->pgroup->members[i]) != NULL
             && victim->in_room == ch->in_room )
        {
        	spell_cure_minor_wounds( sn, level, ch, (void *) victim, TARGET_CHAR );
        }
    }
    
   	return TRUE;
}

bool spell_sphere_of_cure_light_wounds( int sn, int level, Character *ch, void *vo, int target )
{
    extern Spell( cure_light_wounds );
	Character *victim;
	int i;
	
	for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
	{
		if ( (victim = ch->pgroup->members[i]) != NULL
             && victim->in_room == ch->in_room )
        {
        	spell_cure_light_wounds( sn, level, ch, (void *) victim, TARGET_CHAR );
        }
    }
    
   	return TRUE;
}

bool spell_sphere_of_cure_moderate_wounds( int sn, int level, Character *ch, void *vo, int target )
{
    extern Spell( cure_moderate_wounds );
	Character *victim;
	int i;
	
	for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
	{
		if ( (victim = ch->pgroup->members[i]) != NULL
             && victim->in_room == ch->in_room )
        {
        	spell_cure_moderate_wounds( sn, level, ch, (void *) victim, TARGET_CHAR );
        }
    }
    
   	return TRUE;
} 
bool spell_sphere_of_cure_major_wounds( int sn, int level, Character *ch, void *vo, int target )
{
    extern Spell( cure_major_wounds );
	Character *victim;
	int i;
	
	for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
	{
		if ( (victim = ch->pgroup->members[i]) != NULL
             && victim->in_room == ch->in_room )
        {
        	spell_cure_major_wounds( sn, level, ch, (void *) victim, TARGET_CHAR );
        }
    }
    
   	return TRUE;
}

bool spell_sphere_of_cure_serious_wounds( int sn, int level, Character *ch, void *vo, int target )
{
    extern Spell( cure_serious_wounds );
	Character *victim;
	int i;
	
	for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
	{
		if ( (victim = ch->pgroup->members[i]) != NULL
             && victim->in_room == ch->in_room )
        {
        	spell_cure_serious_wounds( sn, level, ch, (void *) victim, TARGET_CHAR );
        }
    }
    
   	return TRUE;
}

bool spell_sphere_of_cure_critical_wounds( int sn, int level, Character *ch, void *vo, int target )
{
    extern Spell( cure_critical_wounds );
	Character *victim;
	int i;
	
	for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
	{
		if ( (victim = ch->pgroup->members[i]) != NULL
             && victim->in_room == ch->in_room )
        {
        	spell_cure_critical_wounds( sn, level, ch, (void *) victim, TARGET_CHAR );
        }
    }
    
   	return TRUE;
}

bool spell_sphere_of_cure_fatal_wounds( int sn, int level, Character *ch, void *vo, int target )
{
    extern Spell( cure_fatal_wounds );
	Character *victim;
	int i;
	
	for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
	{
		if ( (victim = ch->pgroup->members[i]) != NULL
             && victim->in_room == ch->in_room )
        {
        	spell_cure_fatal_wounds( sn, level, ch, (void *) victim, TARGET_CHAR );
        }
    }
    
   	return TRUE;
}

bool spell_divine_inquiry( int sn, int level, Character *ch, void *vo, int target )
{
	Character *victim = (Character *) vo;

	if ( IS_NPC(victim) )
	{
		act("$N has not last any experience to death.",ch,NULL,victim,TO_CHAR);
		return TRUE;
	}

	if ( victim == ch ) 
		actprintf(ch,NULL,victim,TO_CHAR,"You have lost %d experience to death.",victim->pcdata->lost_xp);

	actprintf(ch,NULL,victim,TO_CHAR,"$N has lost %d experience to death.",victim->pcdata->lost_xp);
	return TRUE;
}

/*
 * Cleric spell, temporarily adds proc to a weapon
 */
bool spell_consecrate( int sn, int level, Character *ch, void *vo, int target )
{
	Object *obj = (Object *) vo;
	int skill = get_skill(ch,gsn_destruction);

	     if ( skill <= 14)  sn = spell_lookup("cause minor wounds",1);
	else if ( skill <= 25 ) sn = spell_lookup("cause light wounds",1);
	else if ( skill <= 36 ) sn = spell_lookup("cause moderate wounds",1);
	else if ( skill <= 47 ) sn = spell_lookup("cause major wounds",1);
	else                    sn = spell_lookup("cause serious wounds",1);

	if ( sn < 1 )
	{
		act("$y is unable to grant your request.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

 	obj->value[7] = sn;
    obj->value[8] = skill/4;
    obj->value[9] = (skill/2)*(ch->level/2)*-1;
    SET_BIT( obj->value[4], WEAPON_DECLINING_PROC );

	act("You consecrate $p.",ch,obj,NULL,TO_CHAR);
	act("$n consecrates $p.",ch,obj,NULL,TO_ROOM);
	return TRUE;
}

bool spell_death_knell( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,ch->level/2,ch->level);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;

    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}
