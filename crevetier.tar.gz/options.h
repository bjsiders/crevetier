/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#ifndef options_h
#define options_h

#define HAS_OPT(ch,opt)             (IS_NPC(ch)?FALSE:IS_SET((ch)->pcdata->options,(opt)))
#define HAS_SCOREOPT(ch,opt)        (IS_NPC(ch)?FALSE:IS_SET((ch)->pcdata->score_options,(opt)))
#define HAS_AUTOOPT(ch,opt)         (IS_NPC(ch)?FALSE:IS_SET((ch)->pcdata->auto_options,(opt)))
#define HAS_COLOROPT(ch,opt)        (IS_NPC(ch)?FALSE:IS_SET((ch)->pcdata->color_options,(opt)))
#define HAS_COMMOPT(ch,opt)         (IS_NPC(ch)?FALSE:IS_SET((ch)->pcdata->comm_options,(opt)))
#define HAS_DISPOPT(ch,opt)         (IS_SET((ch)->display,(opt)))

/*
 * Option types
 */
#define OPT_TYPE_SCORE          (A) 
#define OPT_TYPE_DISPLAY        (B) 
#define OPT_TYPE_AUTO           (C) 
#define OPT_TYPE_COLOR          (D) 
#define OPT_TYPE_OPTION         (E) 
#define OPT_TYPE_COMM           (F) 

/*
 *  Auto options
 */
#define AUTO_ASSIST              (A)
#define AUTO_EXIT                (B)
#define AUTO_LOOT                (C)
#define AUTO_SAC                 (D)
#define AUTO_GOLD                (E)
#define AUTO_SPLIT               (F)
#define AUTO_LOOKINCORPSE        (F)
#define AUTO_SWITCHSTYLES        (H)
#define AUTO_EAT                 (I)
#define AUTO_DRINK               (J)

/* Misc options */
#define OPT_NOREVEAL                (A)
#define OPT_NOREVEAL_CLANMATES      (B)
#define OPT_NOREVEAL_GROUPMATES     (C)
#define OPT_NOGIVE                  (D)
#define OPT_NOAUTOREPLYTEXT         (E)
#define OPT_NOSIGNATURE             (F)
#define OPT_CANLOOT                 (G)
#define OPT_NOWAKE                  (H)
#define OPT_NOSUMMON                (I)
#define OPT_NOFOLLOW                (J)

/* Display options */
#define DISP_HOLYLIGHT              (A)
#define DISP_COMBAT_DEBUG           (B)
#define DISP_REGEN_DEBUG            (C)
#define DISP_IMPROVE_DEBUG          (D)
#define DISP_XP_DEBUG               (E)
#define DISP_SAVES_DEBUG            (F)
#define DISP_WHO_NOTITLES           (G)
#define DISP_WHO_NOGUILDS           (H)
#define DISP_WHO_NOSURNAMES         (I)
#define DISP_FULL_EQUIPMENT         (J)
#define DISP_SHOW_AUTOSAVES         (K)
#define DISP_APPEND_CONDITION       (L)
#define DISP_NO_BATTLE_PROMPT       (M)
#define DISP_ALERT_REUSE            (N)
#define DISP_SHOW_ALL_SKILL_LEVELS  (O)
#define DISP_SHOW_WHEN_FULL         (P)
#define DISP_SHOW_HUNGER            (Q)
#define DISP_SAVE_DEBUG             (R)
#define DISP_CARRIAGE_RETURN        (S)
#define DISP_AUTOEAT                (T)
#define DISP_TRADESKILL_DEBUG       (U)
#define DISP_SHOW_SUBRACES          (V)
#define DISP_SUPPRESS_IGNORES       (W)
#define DISP_NO_EMOTE_MARKS         (X)
#define DISP_SHOW_OBJ_COND          (Y)
#define DISP_MONITOR_GROUP          (Z)
#define DISP_SHOW_SAVES             (aa)
#define DISP_SHOW_AGGRESSION        (bb)

/* Color options */
#define COLOR_TOGGLE                (A)
#define COLOR_MOB_CON               (B)
#define COLOR_OBJ_CON               (C)
#define COLOR_NOTE_TO               (D)
#define COLOR_SPELLS                (E)

/* Score options */
#define SCORE_OPT_SHOW_BANK         (A)
#define SCORE_OPT_SHOW_XP           (B)
#define SCORE_OPT_SHOW_RESISTS      (C)
#define SCORE_OPT_SHOW_AFFECTS      (D)

/* Comm options */
#define COMM_OPT_BRIEF              (A)
#define COMM_OPT_COMBINE            (B)
#define COMM_OPT_COMPACT            (C)
#define COMM_OPT_PROMPT             (D)
#define COMM_OPT_BEEPTELL           (E)

extern const int option_flag_types[];
extern const struct flag_type option_flags[];
int option_lookup( const char *name );

#endif
