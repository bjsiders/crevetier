#ifndef thocdef_h
#define thocdef_h

#include "bits.h"

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE (!FALSE)
#endif

#define MAX_STRING_LENGTH       4608
#define MSL                     MAX_STRING_LENGTH

#define checkForNull( val )     if ( !str_cmp(val,"(null") )  { free_string(val); val = NULL; }

#endif /* thocdef_h */
