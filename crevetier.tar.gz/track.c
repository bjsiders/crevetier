/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "thoc.h"
#include "recycle.h"

Track *getTrackingData( Character *ch, Room *r );

void addTrackingData( Character *ch, Room *r, int dir, bool arriveOrLeave )
{
	Track *t;
	Object *obj;

	return;

	/* There may not always be an update, depending on the terrain */
	/* Tracks are never left in certain terrain */
	switch( r->sector_type )
	{
 		case	SECT_INSIDE:
		case	SECT_WATER_SWIM:
		case 	SECT_WATER_NOSWIM:
		case	SECT_AIR:				return;
	
		/* Some terrains always give tracks */
		case	SECT_ROAD:
		case	SECT_DESERT:
		case	SECT_CITY:
		case	SECT_FIELD:				return;
		/* And some terrains are hit and miss */	
	
		case	SECT_FOREST: 	if( number_percent() < 10 )		return;
		case	SECT_HILLS:
		case	SECT_ICE: 		if( number_percent() < 25 )		return;
 		case 	SECT_MOUNTAIN: 	if( number_percent() < 40 )		return;
	}

	if ( (t = getTrackingData( ch, r )) == NULL )
	{
		log_bug("Unable to find/create tracking data for ch [%s]", ch->name );
		return;
	}

	if ( is_affected(ch,vnum_levitation,AFF_SPELL) && number_percent() < 50 )
		return;

	if ( is_affected(ch,vnum_pass_without_trace,AFF_SPELL) )
		return;

	if ( arriveOrLeave == T_ARRIVE )
	{	
		t->arrive_time 		= current_time;
		t->arrive_dir  		= dir;
	}
	else
	if ( arriveOrLeave == T_DEPART )
	{
		t->depart_time		= current_time;
		t->depart_dir		= dir;
	}
	t->who				= ch;
	t->footwear_vnum 	= ( obj = get_eq_char(ch,WEAR_FEET)) == NULL ? 0 : obj->pIndexData->vnum;
	t->injury_percent 	= ( ch->stat_hit * 100 / max_stat_hit(ch) );
	t->weight_percent	= ( get_carry_weight(ch) * 100 / can_carry_w(ch) );

	return;
}

Track *getTrackingData( Character *ch, Room *r )
{
	Track *t;

	for ( t = r->tracking ; t != NULL ; t = t->next_in_room )
		if ( t->who == ch )
			return t;

	t = new_tracking( );
	t->next_in_room = r->tracking;
	r->tracking = t;
	return t;
}

/*
void do_track( Character *ch, char *argument )
{
	int	skill;
	Track	*t;
	int		count = 0;

	cprintf(ch,"== Tracking Information for %s ==\n\r", ch->in_room->name );
	for( t = ch->in_room->tracking ; t != NULL ; t = t->next )
	{
		++count;
		if( current_time - UMAX(t->arrive_time,t->depart_time) )
		cprintf(ch," %2d. %s entered %s and left %s\n\r",
	}
}
*/
