#ifndef class_h
#define class_h

#include <sys/types.h>

#define MAX_CLASS   16

#define MELEE       0
#define STEALTH     1
#define ARCANE      2
#define DIVINE      3

#define EASY        0
#define MODERATE    1
#define CHALLENGING 2
#define DIFFICULT   3

#define CLA_CAN_CRITICAL        (A)
#define CLA_CAN_FOCUS           (B)
#define CLA_NO_AGNOSTIC         (C)

struct    class_type
{
    char *      name;               // the full name of the class
    char        who_name    [5];    // Three-letter name for 'who'
    sh_int      attr_prime;         // Prime attribute
    sh_int      attr_second;        // Secondary attribut
    sh_int      hp_min;             // Min hp gained on leveling
    sh_int      hp_max;             // Max hp gained on leveling
    bool        fMana;              // Class gains mana on level
    char *      base_group;         // base skills gained
    char *      default_group;      // default skills gained
    sh_int      base_hit_gain;
    sh_int      group;
    int         outfit[8];
    short *     csn;
    long        flags;
    float       thac0;
    sh_int      skill_pts;
    char *      description;
    int         difficulty;
    int         default_weapon;
};

/*
    Class-specific data
 */
struct ranger_data
{
    int     species_enemy;
    time_t  last_species_enemy;
};

/* CSN's */
extern short csn_mage;
extern short csn_specialist;
extern short csn_warlock;
extern short csn_arcanist;

extern short csn_cleric;
extern short csn_crusader;
extern short csn_shaman;
extern short csn_druid;

extern short csn_thief;
extern short csn_assassin;
extern short csn_monk;
extern short csn_bard;

extern short csn_fighter;
extern short csn_barbarian;
extern short csn_ranger;
extern short csn_paladin;

extern const struct class_type      class_table[MAX_CLASS];


#endif /* class_h */
