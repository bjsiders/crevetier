/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "thoc.h"
#include "recycle.h"
#include "interp.h"
#include "tables.h"
#include "styles.h"
#include "options.h"

void do_style_list( Character *ch, char *argument );
int style_lookup( const char *name, int weapon_sn );
void    set_fighting    ( Character *ch, Character *victim );

#define ATTACK(x)		(x)
#define DAMAGE(x)		(x)
#define DEFENSE(x)		(x)
#define FLAGS(x)		(x)

const struct	style_type		style_table	[] =
{
	{ "null style",  0, &gsn_unarmed_combat,
		{ 53,53,53,53,  53,53,53,53,  53,53,53,53,  53,53,53,53 }
	},

	{ "twist stab", 20, &gsn_thrusting_shortblades,
		{ 53,53,53,53,  53,53,53,53,  2,2,2,53,  2,2,2,2 },
		OPENING_NONE, FLAGS(0), 
		"You thrust your weapon into $N&C and give the hilt an expert twist!",
		"$n&C thrusts $s weapon into you and gives the hilt an expert twist!",
		"$n&C thrusts $s weapon into $N&C and gives the hilt an expert twist!",
		ATTACK(20), DAMAGE(2), DEFENSE(0), NULL,
		"None"
		, 0, NULL
	},

	{ "side thrust", 15, &gsn_thrusting_shortblades,
		{ 53,53,53,53,  53,53,53,53, 4,4,4,53,  4,4,4,4 },
		STYLE_EVADE, FLAGS(0),
		"Sidestepping, you bury your weapon into $N&C's side.",	
		"Sidestepping, $n&C buries $s weapon into your side.",	
		"Sidestepping, $n&C buries $s weapon into $N&C's side.",
		ATTACK(35), DAMAGE(4), DEFENSE(-1), style_side_thrust,
		"4-second stun"
		, 0, NULL
	},

	{ "belly stab", 35, &gsn_thrusting_shortblades,
		{ 53,53,53,53,  53,53,53,53, 6,6,6,53,  6,6,6,6 },
		OPENING_NONE, FLAGS(0),
		"You drive your blade deep into $N&C's belly.",
		"$n&C drives $s blade deep into your belly.",
		"$n&C drives $s blade deep into $N&C's belly.",
		ATTACK(5), DAMAGE(3), DEFENSE(-1), style_belly_stab,
		"Short-duration bleeding"
		, 0, NULL
	},

	{ "puncture lung", 45, &gsn_thrusting_shortblades,
		{ 53,53,53,53,  53,53,53,53, 8,8,8,53,  8,8,8,8 },
		STYLE_STARTER, FLAGS(0),
		"You slip your weapon between $N&C's ribs and puncture $S lung!",
		"$n&C slips $s weapon between your ribs and punctures your lung!",
		"$n&C slips $s weapon between $N&C's ribs and punctures $S lung!",
		ATTACK(10), DAMAGE(24), DEFENSE(0), NULL,
		"None"
		, 0, NULL
	},

	{ "separate shoulder", 60, &gsn_thrusting_shortblades,
		{ 53,53,53,53,  53,53,53,53,  10,10,10,53,  10,10,10,10 },
		STYLE_PARRY, FLAGS(0),
		"You stab $N&C's shoulder and rip through the tendons!",
		"$n&C stabs your shoulder and rips through the tendons!",
		"$n&C stabs $N&C's shoulder and rips through the tendons!",
		ATTACK(35), DAMAGE(5), DEFENSE(0), style_separate_shoulder,
		"18% attack speed reduction"
		, 0, NULL
	},

	{ "kidney stab", 35, &gsn_thrusting_shortblades,
		{ 53,53,53,53,  53,53,53,53,  12,12,12,53,  12,12,12,12 },
		STYLE_STYLE, FLAGS(0),
		"You drive your blade into $N&C's kidney!",
		"$n&C drives $s blade into your kidney!",
		"$n&C drives $s blade into $N&C's kidney!",
		ATTACK(10), DAMAGE(12), DEFENSE(0), style_kidney_stab,
		"Medium-duration bleeding", "side thrust"
		, 0, NULL
	},

	{ "stinger", 75, &gsn_thrusting_shortblades,
		{ 53,53,53,53,  53,53,53,53,  15,15,15,53,  15,15,15,15 },	
		OPENING_NONE, FLAGS(0),
		"You lunge forward and quickly stab at $N&C.",
		"$n&C lunges forward and quickly stabs at you.",
		"$n&C lunges forward and quickly stabs at $N&C.",
		ATTACK(0), DAMAGE(30), DEFENSE(0), NULL,
		"None"
		, 0, NULL
	},

	{ "rib splitter", 90, &gsn_thrusting_shortblades,
		{ 53,53,53,53,  53,53,53,53,  18,18,18,53,  18,18,18,18 },
		STYLE_STYLE, FLAGS(0),
		"You drive your weapon into $N&C's rib cage and shatter the bones!",
		"$n&C drives $s weapon into your rib cage and shatters the bones!",
		"$n&C drives $s weapon into $N&C's rib cage and shatters the bones!",
		ATTACK(20), DAMAGE(36), DEFENSE(-4), style_snare,
		"Medium movement rate reduction", "puncture lung"
		, 0, NULL
	},

	{ "flatblade bash", 50, &gsn_thrusting_shortblades,
		{ 53,53,53,53,  53,53,53,53,  21,21,21,53,  21,21,21,21 },
		STYLE_STYLE, FLAGS(0),
		"You bash $N&C with the flat of your weapon.",
		"$n&C bashes you with the flat of $s weapon.",
		"$n&C bashes $N&C with the flat of $s weapon.",
		ATTACK(10), DAMAGE(21), DEFENSE(0), style_flatblade_bash,
		"6-second stun", "separate shoulder"
		, 0, NULL
	},

	{ "thigh stab", 90, &gsn_thrusting_shortblades,
		{ 53,53,53,53,  53,53,53,53,  25,25,25,53,  25,25,25,25 },
		STYLE_STYLE, FLAGS(0),
		"You bury your weapon to the hilt in $N&C's leg!",
		"$n&C buries $s weapon to the hilt in your leg!",
		"$n&C buries $s weapon to the hilt in $N&C's leg!",
		ATTACK(10), DAMAGE(25), DEFENSE(0), style_thigh_stab,
		"24% attack speed reductin", "kidney stab"
		, 0, NULL
	},

	{ "sever carotid", 145, &gsn_thrusting_shortblades,
		{ 53,53,53,53,  53,53,53,53,  29,29,29,53,  29,29,29,29 },
		STYLE_STARTER, FLAGS(0),
		"You reverse your grip and stab into $N&C's neck!",
		"$n&C reverses $s grip and stabs into your neck!",
		"$n&C reverses $s grip and stabs into $N&C's neck!",
		ATTACK(20), DAMAGE(87), DEFENSE(0), NULL,
		"None"
		, 0, NULL
	},

	{ "spin thrust", 205, &gsn_thrusting_shortblades,
		{ 53,53,53,53,  53,53,53,53,  34,34,34,53,  34,34,34,34 },
		STYLE_PARRY, FLAGS(0),
		"Double-gripping your weapon, you spin and bury it into $N&C's chest.",
		"Double-gripping $s weapon, $n&C spins and buries it into your chest.",
		"Double-gripping $s weapon, $n&C spins and buries it into $N&C's chest.",
		ATTACK(20), DAMAGE(68), DEFENSE(0), style_spin_thrust,
		"Long-duration bleeding"
		, 0, NULL
	},

	{ "reverse stab", 190, &gsn_thrusting_shortblades,
		{ 53,53,53,53,  53,53,53,53,  39,39,39,53,  39,39,39,39 },
		OPENING_NONE, FLAGS(0),
		"You reverse your grip and bring your weapon down heavily on $N&C!",
		"$n&C reverses $s grip and brings $s weapon down heavily on you!",
		"$n&C reverses $s grip and brings $s weapon down heavily on $N&C!",
		ATTACK(35), DAMAGE(78), DEFENSE(-5), NULL,
		"None"
		, 0, NULL
	},

	{ "carpus shatter", 105, &gsn_thrusting_shortblades,
		{ 53,53,53,53,  53,53,53,53,  44,44,44,53,  44,44,44,44 },
		STYLE_STYLE, FLAGS(0),
		"You strike quickly at $N&C, shattering the carpus bones!",
		"$n&C strikes quickly at you, shattering the carpus bones!",
		"$n&C strikes quickly at $N&C, shattering the carpus bones!",
		ATTACK(10), DAMAGE(88), DEFENSE(0), style_carpus_shatter,
		"36% attack speed reduction", "sever carotid"
		, 0, NULL
	},

	{ "heart stab", 240, &gsn_thrusting_shortblades,
		{ 53,53,53,53,  53,53,53,53,  50,50,50,53,  50,50,50,50 },
		STYLE_EVADE, FLAGS(0),
		"You thrust your weapon directly into $N&C's heart!",
		"$n&C thrusts $s weapon directly into your heart!",
		"$n&C thrusts $s weapon directly into $N&C's heart!",
		ATTACK(0), DAMAGE(50), DEFENSE(0), style_heart_stab,
		"8-second stun"
		, 0, NULL
	},

	/* Thrusting Long */
	{ "snakebite", 20, &gsn_thrusting_longblades,
		{ 53,53,53,53,  53,53,53,53,  2,2,2,53,  2,2,2,2 },
		OPENING_NONE, FLAGS(0),
		"You drive your blade into $N&C's ribcage!",
		"$n&C drives $s blade into your ribcage!",
		"$n&C drives $s blade into $N's ribcage!",
		ATTACK(0), DAMAGE(4), DEFENSE(0), NULL,
		"None"
		, 0, NULL
	},

	{ "spider bite", 10, &gsn_thrusting_longblades,
		{ 53,53,53,53,  53,53,53,53,  4,4,4,53,  4,4,4,4 },
		STYLE_STARTER, FLAGS(0),
		"You duck in and shove your weapon up into $N&C's gullet!",
		"$n&C ducks in and shoves $s weapon up into your gullet!",
		"$n&C ducks in and shoves $s weapon up into $N&C's gullet!",
		ATTACK(15), DAMAGE(4), DEFENSE(0), style_spider_bite,
		"Short-duration bleeding"
		, 0, NULL
	},

	{ "scorpion sting", 20, &gsn_thrusting_longblades,
		{ 53,53,53,53,  53,53,53,53,  6,6,6,53,  6,6,6,6 },
		OPENING_NONE, FLAGS(0),
		"You reverse your grip and spin, driving your weapon into $N&C's leg!",
		"$n&C reverses $s grip and spins, driving $s weapon into your leg!",
		"$n&C reverse $s grip and spins, driving $s weapon into $N&C's leg!",
		ATTACK(15), DAMAGE(3), DEFENSE(-3), style_scorpion_sting,
		"4-second stun"
		, 0, NULL
	},

	{ "wasp sting", 25, &gsn_thrusting_longblades,
		{ 53,53,53,53,  53,53,53,53,  8,8,8,53,  8,8,8,8 },
		STYLE_STYLE, FLAGS(0),
		"You move in on $N&C and stab your blade into $S neck!",
		"$n&C moves in on you and stabs $s blade into your neck!",
		"$n&C moves in on $N&C and stabs $s blade into $S neck!",
		ATTACK(15), DAMAGE(8), DEFENSE(0), style_wasp_sting,
		"24% attack speed reduction", "snakebite"
		, 0, NULL
	},

	{ "coil", 30, &gsn_thrusting_longblades,
		{ 53,53,53,53,  53,53,53,53,  10,10,10,53,  10,10,10,10 },
		OPENING_NONE, FLAGS(0),
		"You spring at $N&C and plunge your weapon into $S belly!",
		"$n&C springs at you and plunges $s weapon into your belly!",
		"$n&C springs at $N&C and plunges $s weapon into $S belly!",
		ATTACK(0), DAMAGE(10), DEFENSE(3), style_coil,
		"Imposes defensive penalty on victim"
		, 0, NULL
	},

	{ "sidewinder", 60, &gsn_thrusting_longblades,
		{ 53,53,53,53,  53,53,53,53,  12,12,12,53,  12,12,12,12 },
		OPENING_NONE, FLAGS(0),
		"Dropping to a crouch, you stab upward at $N&C.",
		"Dropping to a crouch, $n&C stabs upward at you.",
		"Dropping to a crouch, $n&C stabs upward at $N&C.",
		ATTACK(35), DAMAGE(6), DEFENSE(-3), NULL,
		"None"
		, 0, NULL
	},

	{ "hornet sting", 35, &gsn_thrusting_longblades,
		{ 53,53,53,53,  53,53,53,53,  15,15,15,53,  15,15,15,15 },
		OPENING_NONE, FLAGS(0),
		"Feinting, you lunge at $N&C and glance your blade off $S skull!",
		"Feinting, $n&C lunges at you and glances $s blade off your skull!",
		"Feinting, $n&C lunges at you and glances $s blade off $S skull!",
		ATTACK(15), DAMAGE(5), DEFENSE(4), style_hornet_sting,
		"Medium-duration bleeding"
		, 0, NULL
	},

	{ "copperhead", 60, &gsn_thrusting_longblades,
		{ 53,53,53,53,  53,53,53,53,  18,8,18,53,  18,18,18,18 },
		STYLE_STYLE, FLAGS(0),
		"You sidestep and stab $N&C in the side of the calf.",
		"$n&C sidesteps and stabs you in the side of the calf.",
		"$n&C sidesteps and stabs $N&C in the side of the calf.",
		ATTACK(15), DAMAGE(36), DEFENSE(0), NULL,
		"None", "sidewinder"
		, 0, NULL
	},

	{ "black widow", 70, &gsn_thrusting_longblades,
		{ 53,53,53,53,  53,53,53,53,  21,21,21,53,  21,21,21,21 },
		STYLE_STARTER, FLAGS(0),
		"You drop to one knee and bury your blade in $N&C's foot!",
		"$n&C drops to one knee and buries $s blade in your foot!",
		"$n&C drops to one knee and buries $s blade in $N&C's foot!",
		ATTACK(15), DAMAGE(10), DEFENSE(-5), style_snare,
		"Movement rate reduction"
		, 0, NULL
	},

	{ "asp", 60, &gsn_thrusting_longblades,
		{ 53,53,53,53,  53,53,53,53,  25,25,25,53,  25,25,25,25 },
		STYLE_EVADE, FLAGS(0),
		"You dodge and split $N&C's shin with your weapon!",
		"$n&C dodges and splits your shin with $s weapon!",
		"$n&C dodges and splits $N&C's shin with $s weapon!",
		ATTACK(15), DAMAGE(12), DEFENSE(8), style_asp,
		"6-second stun"
		, 0, NULL
	},

	{ "tarantula", 100, &gsn_thrusting_longblades,
		{ 53,53,53,53,  53,53,53,53,  29,29,29,53,  29,29,29,29 },
		STYLE_STYLE, FLAGS(0),
		"Stabbing $N&C, you drag your blade downward, tearing through the flesh.", 
		"Stabbing you, $n&C drags $s blade downward, tearing through the flesh.",
		"Stabbing $N&C, $n&C drags $s blade downward, tearing through the flesh.",
		ATTACK(15), DAMAGE(58), DEFENSE(9), NULL,
		"None", "black widow"
		, 0, NULL
	},

	{ "diamondback", 80, &gsn_thrusting_longblades,
		{ 53,53,53,53,  53,53,53,53,  34,34,34,53,  34,34,34,34 },
		STYLE_STYLE, FLAGS(0),
		"You slide your blade under $N&C's jaw and shatter the bone!",
		"$n&C slides $s blade under your jaw and shatters the bone!",
		"$n&C slides $s blade under $N&C's jaw and shatters the bone!",
		ATTACK(50), DAMAGE(34), DEFENSE(11), style_diamondback,
		"34% attack speed reduction", "copperhead"
		, 0, NULL
	},

	{ "viper", 90, &gsn_thrusting_longblades,
		{ 53,53,53,53,  53,53,53,53,  39,39,39,53,  39,39,39,39 },
		STYLE_STYLE, FLAGS(0),
		"You pierce $N&C's chest and lean down on the blade, breaking through ribs.",
		"$n&C pierces your chest and leans down on the blade, breaking through ribs.",
		"$n&C pierces $N&C's chest and leans down on the blade, breaking through ribs.",
		ATTACK(35), DAMAGE(78), DEFENSE(10), NULL,
		"None", "asp"
		, 0, NULL
	},

	{ "cobra", 150, &gsn_thrusting_longblades,
		{ 53,53,53,53,  53,53,53,53, 44,44,44,53,  44,44,44,44 },
		STYLE_STYLE, FLAGS(0),
		"You disembowel $N&C as you stab into $S loins and rip apart the flesh!",
		"$n&C disembowels you as $e stabs into your loins and rips apart the flesh!",
		"$n&C disembowels $N&C as $e stabs into $S loins and rips apart the flesh!",
		ATTACK(15), DAMAGE(44), DEFENSE(0), style_cobra,
		"Long-duration bleeding", "viper"
		, 0, NULL
	},
	
	{ "dragonbite", 175, &gsn_thrusting_longblades,
		{ 53,53,53,53,  53,53,53,53, 50,50,50,53,  50,50,50,50 },
		STYLE_STYLE, FLAGS(0),
		"You plant your weapon into the side of $N&C's neck and tear open a massive gash!",
		"$n&C plants $s weapon into the side of your neck and tears open a massive gash!",
		"$n&C plants $s weapon into the side of $N&C's neck and tears open a massive gash!",
		ATTACK(35), DAMAGE(100), DEFENSE(12), style_dragonbite,
		"Long-duration bleeding", "diamondback"
		, 0, NULL
	},
	
	{ "rat bite", 20, &gsn_slashing_shortblades,
		{ 53,53,53,53,  53,53,53,53,  2,2,2,53,  2,2,2,2 },
		OPENING_NONE, FLAGS(0),
		"You slice at $N&C and tear open a mild gash.",
		"$n&C slices at you and tears open a mild gash.",
		"$n&C slices at $N&C and tears open a mild gash.",
		ATTACK(20), DAMAGE(3), DEFENSE(0), NULL,
		"None"
		, 0, NULL
	},

	{ "skive", 20, &gsn_slashing_shortblades,
		{ 53,53,53,53,  53,53,53,53,  4,4,4,53,  4,4,4,4 },
		STYLE_STARTER, FLAGS(0),
		"You slash $N&C and leave a bloody section of flesh hanging loose.",
		"$n&C slashes you and leaves a bloody section of flesh hanging loose.",
		"$n&C slashes $N&C and leaves a bloody section of flesh hanging loose.",
		ATTACK(35), DAMAGE(4), DEFENSE(0), NULL,
		"None"
		, 0, NULL
	},

	{ "cat bite", 35, &gsn_slashing_shortblades,
		{ 53,53,53,53,  53,53,53,53,  6,6,6,53,  6,6,6,6 },
		OPENING_NONE, FLAGS(0),
		"You slice at $N&C and rip open a vicious wound!",
		"$n&C slices at you and rips open a vicious wound!",
		"$n&C slices at $N&C and rips open a vicious wound!",
		ATTACK(0), DAMAGE(6), DEFENSE(0), NULL,
		"None"
		, 0, NULL
	},

	{ "Tesulor's quarter", 35, &gsn_slashing_shortblades,
		{ 53,53,53,53,  53,53,53,53,  8,8,8,53,  8,8,8,8 },
		STYLE_STYLE, FLAGS(0),
		"You cleave apart $N&C's hip, exposing a bloodied thatch of mangled tendons!",
		"$n&C cleaves apart your hip, exposing a bloodied thatch of mangled tendons!",
		"$n&C cleaves apart $N&C's hip, exposing a bloodied thatch of mangled tendons!",
		ATTACK(20), DAMAGE(8), DEFENSE(0), style_snare,
		"Movement rate reduction", "skive"
		, 0, NULL
	},

	{ "riposte", 30, &gsn_slashing_shortblades,
		{ 53,53,53,53,  53,53,53,53,  10,10,10,53,  10,10,10,10 },
		STYLE_BLOCK, FLAGS(0),
		"You respond with a painful diagonal cut across $N&C's torso.",
		"$n&C responds with a painful diagonal cut across your torso.",
		"$n&C responds with a painful diagonal cut across $N&C's torso.",
		ATTACK(30), DAMAGE(30), DEFENSE(2), NULL,
		"None"
		, 0, NULL
	},

	{ "hound's maw", 45, &gsn_slashing_shortblades,
		{ 53,53,53,53,  53,53,53,53,  12,12,12,53,  12,12,12,12 },
		STYLE_STYLE, FLAGS(0),
		"You bring your weapon up and shatter $N&C's jaw with a powerful slash to the face!",
		"$n&C brings $s weapon up and shatters your jaw with a powerful slash to the face!",
		"$n&C brings $s weapon up and shatters $N&C's jaw with a powerful slash to the face!",
		ATTACK(20), DAMAGE(6), DEFENSE(0), style_hounds_maw,
		"Short-duration bleeding", "cat bite"
		, 0, NULL
	},

	{ "cett's return", 55, &gsn_slashing_shortblades,
		{ 53,53,53,53,  53,53,53,53,  15,15,15,53,  15,15,15,15 },
		STYLE_PARRY, FLAGS(0),
		"You bring your weapon down on $N&C's head, glancing a blow off $S skull.",
		"$n&C brings $s weapon down on your head, glancing a blow off your skull.",
		"$n&C brings $s weapon down on $N&C's head, glancing a blow off $S skull.",
		ATTACK(35), DAMAGE(30), DEFENSE(5), NULL,
		"None"
		, 0, NULL
	},

	{ "steel rejoinder", 45, &gsn_slashing_shortblades,
		{ 53,53,53,53,  53,53,53,53,  18,18,18,53,  18,18,18,18 },
		STYLE_STYLE, FLAGS(0),
		"You cut a deep line across $N&C's neck.",
		"$n&C cuts a deep line across your neck.",
		"$n&C cuts a deep line across $N&C's neck.",
		ATTACK(20), DAMAGE(36), DEFENSE(4), NULL,
		"None", "riposte"
		, 0, NULL
	},

	{ "Manikov's quarter", 50, &gsn_slashing_shortblades,
		{ 53,53,53,53,  53,53,53,53,  21,21,21,53,  21,21,21,21 },
		STYLE_STYLE, FLAGS(0),
		"You slice deep into $N&C's rib cage, splintering bone!",
		"$n&C slices deep into your rib cage, splintering bone!",
		"$n&C slices deep into $N&C's rib cage, splintering bone!",
		ATTACK(35), DAMAGE(21), DEFENSE(0), style_manikovs_quarter,
		"Medium-duration bleeding", "Tesulor's quarter"
		, 0, NULL
	},

	{ "Taihr's Finale", 90, &gsn_slashing_shortblades,
		{ 53,53,53,53,  53,53,53,53,  25,25,25,53,  25,25,25,25 },
		STYLE_EVADE, FLAGS(0),
		"You rip open $N&C's throat with a high slash and spin to finish with an ankle cut!",
		"$n&C rips open your throat with a high slash and spins to finish with an ankle cut!",
		"$n&C rips open $N&C's throat with a high slash and spins to finish with an ankle cut!",
		ATTACK(50), DAMAGE(50), DEFENSE(5), style_taihrs_finale,
		"20% attack speed reduction"
		, 0, NULL
	},

	{ "wolf's maw", 70, &gsn_slashing_shortblades,
		{ 53,53,53,53,  53,53,53,53,  29,29,29,53,  29,29,29,29 },
		STYLE_STYLE, FLAGS(0),
		"You move to a parrying position, but slash quickly at $N&C's head!",
		"$n&C moves to a parrying position, but slashes quickly at your head!",
		"$n&C moves to a parrying position, but slashes quickly at $N&C's head!",
		ATTACK(20), DAMAGE(58), DEFENSE(0), style_wolfs_maw,
		"5-second stun", "hound's maw"
		, 0, NULL
	},

	{ "crippler", 170, &gsn_slashing_shortblades,
		{ 53,53,53,53,  53,53,53,53,  34,34,34,53,  34,34,34,34 },
		OPENING_NONE, FLAGS(0),
		"You double your grip and slash hard at $N&C's arms.",
		"$n&C doubles $s grip and slashes hard at your arms.",
		"$n&C doubles $s grip and slashes hard at $N&C's arms.",
		ATTACK(35), DAMAGE(68), DEFENSE(-7), style_crippler,
		"Imposes defensive penalty on victim"
		, 0, NULL
	},
	
	{ "griffonclaw", 140, &gsn_slashing_shortblades,
		{ 53,53,53,53,  53,53,53,53,  39,39,39,53,  39,39,39,39 },
		STYLE_STYLE, FLAGS(0),
		"You make a quick cut across $N&C's carotid and slice opon an artery!",
		"$n&C makes a quick cut across your carotid and slices open an artery!",
		"$n&C makes a quick cut across $N&C's carotid and slices open an artery!",
		ATTACK(20), DAMAGE(39), DEFENSE(0), style_griffonclaw,
		"Long-duration bleeding", "Cett's return"
		, 0, NULL
	},

	{ "Vesikur's quarter", 105, &gsn_slashing_shortblades,
		{ 53,53,53,53,  53,53,53,53,  44,44,44,53,  44,44,44,44 },
		STYLE_STYLE, FLAGS(0),
		"You slash hard at $N&C's hands, leaving a bloody mass of pulp!",
		"$n&C slashes hard at your hands, leaving a bloody mass of pulp!",
		"$n&C slashes hard at $N&C's hands, leaving a bloody mass of pulp!",
		ATTACK(35), DAMAGE(88), DEFENSE(0), style_vesikurs_quarter,
		"40% attack speed reduction", "Manikov's quarter"
		, 0, NULL
	},

	{ "wyrmfang", 175, &gsn_slashing_shortblades,
		{ 53,53,53,53,  53,53,53,53,   50,50,50,53,  50,50,50,50 },
		STYLE_STYLE, FLAGS(0),
		"You feint low and then spin, breaking $N&C's skull open with a brutal slice to the head!",
		"$n&C feints low and then spins, breaking your skull open with a brutal slice to the head!",
		"$n&C feints low and then spins, breaking $N&C's skull open with a brutal slice to the head!",
		ATTACK(50), DAMAGE(150), DEFENSE(-10), style_wyrmfang,
		"9-second stun", "griffonclaw"
		, 0, NULL
	},

	/*** Slashing Longblades ***/
	{ "crescent moon", 20, &gsn_slashing_longblades,
		{ 53,53,53,53,  53,53,53,53,  2,2,2,53,  2,2,2,2 },
		OPENING_NONE, FLAGS(0),
		"You swing your weapon in a wide arc and strike $N&C in the shoulder.",
		"$n&C swings $s weapon in a wide arc and strikes you in the shoulder.",
		"$n&C swings $s weapon in a wide arc and strikes $N&C in the shoulder.",
		ATTACK(30), DAMAGE(3), DEFENSE(0), NULL,
		"None"
		, 0, NULL
	},

	{ "dissever", 15, &gsn_slashing_longblades,
		{ 53,53,53,53,  53,53,53,53,  4,4,4,53,  4,4,4,4 },
		STYLE_STARTER, FLAGS(0),
		"You cut deep into $N's arms, severing tendons.",
		"$n&C cuts deep into your arms, severing tendons",
		"$n&C cuts deep into $N's arms, severing tendons",
		ATTACK(50), DAMAGE(8), DEFENSE(0), NULL,
		"None"
		, 0, NULL
	},

	{ "half moon", 25, &gsn_slashing_longblades,
		{ 53,53,53,53,  53,53,53,53,  6,6,6,53,  6,6,6,6 },
		STYLE_STYLE, FLAGS(0),
		"You swing your weapon in a diagonal slash, lacerating $N&C across the torso.",
		"$n&C swings $s weapon in a diagonal slash, lacerating you across the torso.",
		"$n&C swings $s weapon in a diagonal slash, lacerating $N&C across the torso.",
		ATTACK(30), DAMAGE(12), DEFENSE(0), style_half_moon,
		"Short-duration bleeding", "crescent moon"
		, 0, NULL
	},

	{ "inhibitor", 25, &gsn_slashing_longblades,
		{ 53,53,53,53,  53,53,53,53,  8,8,8,53,  8,8,8,8 },
		OPENING_NONE, FLAGS(0),
		"Your weapon bites deep into $N's legs, breaking open a brutal gash.",
		"$n&C's weapon bites deep into your legs, breaking open a brutal gash.",
		"$n&C's weapon bites deep into $N's legs, breaking open a brutal gash.",
		ATTACK(50), DAMAGE(0), DEFENSE(4), style_snare,
		"Movement rate reduction"
		, 0, NULL
	},

	{ "instigator", 35, &gsn_slashing_longblades,
		{ 53,53,53,53,  53,53,53,53,  10,10,10,53, 10,10,10,10 },
		OPENING_NONE, FLAGS(0),
		"You lightly cut $N&C just above the eyes, leaving a painful and irritating wound.",
		"$n&C lightly cuts you just above the eyes, leaving a painful and irritating wound.",
		"$n&C lightly cuts $N&C just above the eyes, leaving a painful and irritating wound.",
		ATTACK(30), DAMAGE(10), DEFENSE(-5), style_instigator,
		"Taunt"
		, 0, NULL
	},

	{ "gibbous moon", 45, &gsn_slashing_longblades,
		{ 53,53,53,53,  53,53,53,53,  12,12,12,53,  12,12,12,12 },
		STYLE_STYLE, FLAGS(0),
		"You swing in a tight arch, gouging a deep gash in $N's serratus anterior.",
		"$n&C swings in a tight arch, gouging a deep gash in your serratus anterior.",
		"$n&C swings in a tight arch, gouging a deep gash in $N's serratus anterior.",
		ATTACK(30), DAMAGE(24), DEFENSE(0), style_gibbous_moon,
		"18% attack speed reduction", "half moon"
		, 0, NULL
	},

	{ "Kajeda's antiphon", 40, &gsn_slashing_longblades,
		{ 53,53,53,53,  53,53,53,53,  15,15,15,53,  15,15,15,15 },
		STYLE_EVADE, FLAGS(0),
		"You reposition and slash quickly at $N.",
		"$n&C repositions and slashes quickly at you.",
		"$n&C repositions and slashes quickly at $N.",
		ATTACK(20), DAMAGE(45), DEFENSE(5), NULL,
		"None"
		, 0, NULL
	},

	{ "iron retort", 65, &gsn_slashing_longblades,
		{ 53,53,53,53,  53,53,53,53,  18,18,18,53,  18,18,18,18 },
		STYLE_PARRY, FLAGS(0),
	"You return with a hard cut across the face of $N!",
	"$n&C returns with a hard cut across your face!",
	"$n&C returns with a hard cut across the face of $N!",
		ATTACK(50), DAMAGE(18), DEFENSE(9), style_iron_retort,
		"Imposes defensive penalty on victim"
		, 0, NULL
	},

	{ "dissect", 105, &gsn_slashing_longblades,
		{ 53,53,53,53,  53,53,53,53,  21,21,21,53,  21,21,21,21 },
		OPENING_NONE, FLAGS(0),
		"You cut open a long vertical slice down $N's torso!",
		"$n&C cuts open a long vertical slice down your torso!",
		"$n&C cuts open a long vertical slice down $N's torso!",
		ATTACK(20), DAMAGE(41), DEFENSE(9), NULL,
		"None"
		, 0, NULL
	},

	{ "full moon", 90, &gsn_slashing_longblades,
		{ 53,53,53,53,  53,53,53,53,  25,25,25,53,  25,25,25,25 },
		STYLE_STYLE, FLAGS(0),
		"You spin, swordarm extended, and connect with $N's jaw!",
		"$n&C spins, swordarm extended, and connects with your jaw!",
		"$n&C spins, swordarm extended, and connects with $N's jaw!",
		ATTACK(30), DAMAGE(75), DEFENSE(0), style_full_moon,
		"6-second stun", "gibbous moon"
		, 0, NULL
	},

	{ "rupture", 105, &gsn_slashing_longblades,
		{ 53,53,53,53,  53,53,53,53,  29,29,29,53,  29,29,29,29 },
		STYLE_STYLE, FLAGS(0),
		"You slice open a crucial artery on $N's arm; blood spurts violently!",
		"$n&C slices open a crucual artery on your arm; blood spurts violently!",
		"$n&C slices open a crucual artery on $N's arm; blood spurts violently!",
		ATTACK(10), DAMAGE(29), DEFENSE(0), style_rupture,
		"Medium-duration bleeding", "iron retort"
		, 0, NULL
	},

	{ "painbringer", 125, &gsn_slashing_longblades,
		{ 53,53,53,53,  53,53,53,53,  34,34,34,53,  34,34,34,34 },
		STYLE_BLOCK, FLAGS(0),
		"Your blade hits $N, and you give it a vicious, practiced twist!",
		"$n&C's blade hits you, and $n&C gives it a vicious, practiced twist!",
		"$n&C's blade hits $N, and $n&C gives it a vicious, practiced twist!",
		ATTACK(20), DAMAGE(102), DEFENSE(0), style_painbringer,
		"36% attack speed reduction"
		, 0, NULL
	},

	{ "blade's anguish", 140, &gsn_slashing_longblades,
		{ 53,53,53,53,  53,53,53,53,  39,39,39,53,  39,39,39,39 },
		STYLE_STYLE, FLAGS(0),
		"Your brutal slash rips the flesh off $N's skull!",
		"$n&C's brutal slash rips the flesh off your skull!",
		"$n&C's brutal slash rips the flesh off $N's skull!",
		ATTACK(10), DAMAGE(78), DEFENSE(0), style_blades_anguish,
		"9-second stun", "rupture"
		, 0, NULL
	},

	{ "bloodbringer", 105, &gsn_slashing_longblades,
		{ 53,53,53,53,  53,53,53,53,  44,44,44,53,  44,44,44,44 },
		STYLE_STYLE, FLAGS(0),
		"Your barbaric slice tears apart $N's shoulder, leaving a bloody hole!",
		"$n&C's barbaric slice tears apart your shoulder, leaving a bloody hole!",
		"$n&C's barbaric slice tears apart $N's shoulder, leaving a bloody hole!",
		ATTACK(10), DAMAGE(88), DEFENSE(-8), style_bloodbringer,
		"Long-duration bleeding", "painbringer"
		, 0, NULL
	},

	{ "double moon", 240, &gsn_slashing_longblades,
		{ 53,53,53,53,  53,53,53,53,  50,50,50,53,  50,50,50,50 },
		OPENING_NONE, FLAGS(0),
		"Your powerful slash strikes $N's ribs, tearing through flesh and splintering bone!",
		"$n&C's powerful slash strikes your ribes, tearing through flesh and splintering bone!",
		"$n&C's powerful slash strikes $N's ribes, tearing through flesh and splintering bone!",
		ATTACK(30), DAMAGE(150), DEFENSE(0), NULL,
		"None"
		, 0, NULL
	},

	{ "chop", 20, &gsn_axe,
		{ 53,53,53,53,  53,53,53,53,  53,53,53,53,  2,2,2,2, },
		OPENING_NONE, FLAGS(0),
		"You chop viciously at $N.",
		"$n chops viciously at you.",
		"$n chops viciously at $N.",
		ATTACK(30), DAMAGE(4), DEFENSE(0), NULL,
		"None"
		, 0, NULL
	},

	{ "carve", 50, &gsn_axe,
		{ 53,53,53,53,  53,53,53,53,  53,53,53,53,  4,4,4,4 },
		STYLE_STARTER, FLAGS(0),
		"You carve open a painful laceration on $N!!",
		"$n carves open a painful laceration on you.",
		"$n carves open a painful laceration on $N.",
		ATTACK(50), DAMAGE(12), DEFENSE(0), NULL,
		"None"
		, 0, NULL
	},

	{ "cleave", 20, &gsn_axe,
		{ 53,53,53,53,  53,53,53,53,  53,53,53,53,  6,6,6,6 },
		OPENING_NONE, FLAGS(0),
		"You cut open $N's torso with a mighty cleave!",
		"$n cuts open your torso with a mighty cleave!",
		"$n cuts open $N's torso with a mighty cleave!",
		ATTACK(50), DAMAGE(6), DEFENSE(0), style_snare,
		"Movement rate reduction"
		, 0, NULL
	},

	{ "antagonizer", 25, &gsn_axe,
		{ 53,53,53,53,  53,53,53,53,  53,53,53,53,  8,8,8,8 },
		OPENING_NONE, FLAGS(0),
		"You taunt $N as you bury your axe deep in $S flesh.",
		"$n taunts you as $e buries $s axe deep in your flesh.",
		"$n taunts $N as $e buries $s axe deep in $S flesh.",
		ATTACK(50), DAMAGE(8), DEFENSE(4), style_instigator,
		"Taunt"
		, 0, NULL
	},

	{ "disect", 50, &gsn_axe,
		{ 53,53,53,53,  53,53,53,53,  53,53,53,53,  10,10,10,10 },
		STYLE_STYLE, FLAGS(0),
		"You bring your axe upward and embed it into $N's stomach!",
		"$n brings $s axe upward and embeds it in your stomach!",
		"$n brings $s axe upward and embeds it in $N's stomach!",
		ATTACK(20), DAMAGE(30), DEFENSE(0), NULL,
		"None", "carve"
		, 0, NULL
	},

	{ "gash", 45, &gsn_axe,
		{ 53,53,53,53,  53,53,53,53,  53,53,53,53,  12,12,12,12, },
		STYLE_STYLE, FLAGS(0),
		"Using a backhand grip, you gash $N across the face with your axe!",
		"Using a backhand grip, $n gashes you across the face with $s axe!",
		"Using a backhand grip, $n gashes $N across the face with $s axe!",
		ATTACK(35), DAMAGE(24), DEFENSE(0), style_gash,
		"Short-duration bleeding", "cleave"
		, 0, NULL
	},

	{ "hew", 75, &gsn_axe,
		{ 53,53,53,53,  53,53,53,53,  53,53,53,53,  15,15,15,15 },
		OPENING_NONE, FLAGS(0),
		"You double your grip and bash $N with the flat of your blade!",
		"$n doubles $s grip and bashes you with the flat of $s blade.",
		"$n doubles $s grip and bashes $N with the flat of $s blade.",
		ATTACK(35), DAMAGE(30), DEFENSE(0), style_hew,
		"6-second stun"
		, 0, NULL
	},

	{ "decapitate", 90, &gsn_axe,
		{ 53,53,53,53,  53,53,53,53,   53,53,53,53,  18,18,18,18 },
		STYLE_PARRY, FLAGS(0),
		"You swing brutally at $N and sink your blade into $S arm!",
		"$n swings brutally at you and sinks $s blade into your arm.",
		"$n swings brutally at $N and sinks $s blade into $S arm.",
		ATTACK(20), DAMAGE(18), DEFENSE(0), style_decapitate,
		"20% attack speed reduction"
		, 0, NULL
	},

	{ "amputate", 105, &gsn_axe,
		{ 53,53,53,53,  53,53,53,53,  53,53,53,53,  21,21,21,21 },
		STYLE_STYLE, FLAGS(0),
		"You bring your axe straight down on $N's shoulder and nearly sever the arm!",
		"$n brings $s axe straight down on your shoulder and nearly severs the arm!",
		"$n brings $s axe straight down on $N's shoulder and nearly severs the arm!",
		ATTACK(50), DAMAGE(41), DEFENSE(0), style_moderate_pain,
		"Moderate Pain", "gash"
		, 0, NULL
	},

	{ "rive", 125, &gsn_axe,
		{ 53,53,53,53,  53,53,53,53,  53,53,53,53,  25,25,25,25 },
		OPENING_NONE, FLAGS(0),
		"Your barbaric slash shatters bones and severs tendons!",
		"$n's barbaric slash shatters bones and severs tendons!",	
		"$n's barbaric slash shatters bones and severs tendons!",
		ATTACK(20), DAMAGE(50), DEFENSE(0), style_rive,
		"30% attack speed reduction"
		, 0, NULL
	},

	{ "sunder", 145, &gsn_axe,
		{ 53,53,53,53,  53,53,53,53,  53,53,53,53,  29,29,29,29 },
		STYLE_STYLE, FLAGS(0),
		"You tear open a series of bleeding wounds with a quick slice!",
		"$n tears oepn a series of bleeding wounds with a quick slice!",
		"$n tears open a series of bleeding wounds with a quick slice!",
		ATTACK(35), DAMAGE(58), DEFENSE(0), style_sunder,
		"Medium-duration bleeding", "hew"
		, 0, NULL
	},

	{ "sever", 170, &gsn_axe,
		{ 53,53,53,53,  53,53,53,53,  53,53,53,53,  34,34,34,34 },
		STYLE_STYLE, FLAGS(0),
		"Your inhumane assault leaves $N's arm hanging by tendons and sinew!",
		"$n's inhumane assault leaves your arm hanging by tendons and sinew!",
		"$n's inhumane assault leaves $N's arm hanging by tendons and sinew!",
		ATTACK(20), DAMAGE(68), DEFENSE(0), style_severe_pain,
		"Severe Pain", "decapitate"
		, 0, NULL
	},

	{ "chine", 190, &gsn_axe,
		{ 53,53,53,53,  53,53,53,53,  53,53,53,53,  39,39,39,39 },
		STYLE_STYLE, FLAGS(0),
		"You catch $N out of position and bury your blade in $S spine!",
		"$n catches you out of position and buries $s blade in your spine!",
		"$n catches $N out of position and buries $s blade in $S spine!",
		ATTACK(50), DAMAGE(78), DEFENSE(0), style_chine,
		"40% attack speed reduction", "sunder"
		, 0, NULL
	},

	{ "behead", 215, &gsn_axe,
		{ 53,53,53,53,  53,53,53,53,  53,53,53,53,  44,44,44,44 },
		STYLE_STYLE, FLAGS(0),
		"You choke up your grip and cut deep into $N's neck!",
		"$n chokes up $s grip and cuts deep into your neck!",
		"$n chokes up $s grip and cuts deep into $N's neck!",
		ATTACK(35), DAMAGE(88), DEFENSE(0), style_behead,
		"Long-duration bleeding", "rive"
		, 0, NULL
	},

	{ "executioner", 240, &gsn_axe,
		{ 53,53,53,53,  53,53,53,53,  53,53,53,53,  50,50,50,50 },
		STYLE_STYLE, FLAGS(0),
		"You bring your axe straight down, splitting $N's cranium!",
		"$n brings $s axe straight down, splitting your cranium!",
		"$n brings $s axe straight down, splitting $N's cranium!",
		ATTACK(50), DAMAGE(150), DEFENSE(0), style_executioner,
		"10-second stun", "behead"
		, 0, NULL
	},

    { "daze", 20, &gsn_1h_concussion, 
		{ 53,53,53,53,  53,53,53,2,  53,53,53,53,  2,2,2,2 }, 
		OPENING_NONE, FLAGS(0), 
		"You slam your weapon into the side of $N's head!", 
		"$n slams $s weapon into the side of your head!", 
		"$n slams $s weapon into the side of $N's head!", 
		ATTACK(35), DAMAGE(3), DEFENSE(0), NULL,
		"None"
		, 0, NULL
    }, 

    { "bruiser", 15, &gsn_1h_concussion, 
		{ 53,53,53,53,  53,53,53,4,  53,53,53,53,  4,4,4,4 }, 
		STYLE_STARTER, FLAGS(0), 
		"You crush $N's ribs with your weapon!", 
		"$n crushes your ribs with $s weapon!", 
		"$n crushes $N's ribs with $s weapon!", 
		ATTACK(50), DAMAGE(8), DEFENSE(0), style_perforate, 
		"Moderate Pain"
		, 0, NULL
    }, 

    { "legbreaker", 40, &gsn_1h_concussion, 
		{ 53,53,53,53,  53,53,53,6,  53,53,53,53,  6,6,6,6 }, 
		OPENING_NONE, FLAGS(0), 
		"You swing low and break $N's leg!", 
		"$n swings low and breaks your leg!", 
		"$n swings low and breaks $N's leg!", 
		ATTACK(50), DAMAGE(6), DEFENSE(-2), style_legbreaker, 
		"4-second root"
		, 0, NULL
    }, 

    { "bludgeon", 25, &gsn_1h_concussion, 
		{ 53,53,53,53,  53,53,53,8,  53,53,53,53,  8,8,8,8 }, 
		STYLE_STYLE, FLAGS(0), 
		"You slam your weapon hard into $N!", 
		"$n slams $s weapon hard into you!", 
		"$n slams $s weapon hard into $N!", 
		ATTACK(35), DAMAGE(4), DEFENSE(-3), style_instigator, 
		"Taunt", "bruiser"
		, 0, NULL
    }, 

    { "crusher", 35, &gsn_1h_concussion, 
		{ 53,53,53,53,  53,53,53,10,  53,53,53,53,  10,10,10,10 }, 
		STYLE_STYLE, FLAGS(0), 
		"You smash your weapon into the bruised part of $N's ribs!", 
		"$n smashes $s weapon into the bruised part of your ribs!", 
		"$n smashes $s weapon into the bruised part of $N's ribs!", 
		ATTACK(35), DAMAGE(10), DEFENSE(0), style_moderate_pain, 
		"Short-duration bleeding", "bruiser"
		, 0, NULL
    }, 

    { "concussion", 70, &gsn_1h_concussion, 
		{ 53,53,53,53,  53,53,53,12,  53,53,53,53,  12,12,12,12 }, 
		OPENING_NONE, FLAGS(0), 
		"$N's eyes unfocus as you slam your weapon into the side of $s head!", 
		"You feel dizzy as $n slams $s weapon into the side of your head!", 
		"$N's eyes unfocus as $n slams $s weapon into the side of $N's head!", 
		ATTACK(20), DAMAGE(24), DEFENSE(0), style_concussion, 
		"28% attack speed reduction"
		, 0, NULL
    }, 

    { "contusions", 60, &gsn_1h_concussion, 
		{ 53,53,53,53,  53,53,53,15,  53,53,53,53,  15,15,15,15 }, 
		STYLE_STYLE, FLAGS(0), 
		"$N staggers as you smash $s muscles into pulp!", 
		"You stagger as $n smashes your muscles into pulp!", 
		"$N staggers as $n smash $s muscles into pulp!", 
		ATTACK(35), DAMAGE(15), DEFENSE(0), style_contusions, 
		"4-second stun", "bludgeon"
		, 0, NULL
    }, 

    { "basher", 80, &gsn_1h_concussion, 
		{ 53,53,53,53,  53,53,53,18,  53,53,53,53,  18,18,18,18 }, 
		STYLE_STYLE, FLAGS(0), 
		"You knock $N backwards with a powerful blow!", 
		"$n knocks you backwards with a powerful blow!", 
		"$n knocks $N backwards with a powerful blow!", 
		ATTACK(35), DAMAGE(36), DEFENSE(0), style_basher, 
		"6-second stun", "bruiser"
		, 0, NULL
    }, 

    { "entrenchment", 70, &gsn_1h_concussion, 
		{ 53,53,53,53,  53,53,53,21,  53,53,53,53,  21,21,21,21 }, 
		OPENING_NONE, FLAGS(0), 
		"You stagger $N with a quick blow as you take a step away.", 
		"$n staggers you with a quick blow as $n takes a step away.", 
		"$n staggers $N with a quick blow as $n takes a step away.", 
		ATTACK(0), DAMAGE(0), DEFENSE(8), /*style_entrenchment, */ NULL,
		"Detaunt"
		, 0, NULL
    }, 

    { "destroyer", 75, &gsn_1h_concussion, 
		{ 53,53,53,53,  53,53,53,25,  53,53,53,53,  25,25,25,25 }, 
		STYLE_STARTER, FLAGS(0), 
		"You draw back and smash your weapon into $N with all your strength!", 
		"$n draws back and smashes $s weapon into you with all $s strength!", 
		"$n draws back and smashes $s weapon into $N with all $s strength!", 
		ATTACK(35), DAMAGE(25), DEFENSE(0), NULL,
		"None"
		, 0, NULL
    }, 

    { "skullcrusher", 75, &gsn_1h_concussion, 
		{ 53,53,53,53,  53,53,53,29,  53,53,53,53,  29,29,29,29 }, 
		STYLE_BLOCK, FLAGS(0), 
		"You knock $N to $S knees with a powerful blow to $S head!", 
		"$n knocks you to your knees with a powerful blow to your head!", 
		"$n knocks $N to $S knees with a powerful blow to $S head!", 
		ATTACK(50), DAMAGE(58), DEFENSE(-4), NULL,
		"None"
		, 0, NULL
    }, 

    { "devastator", 85, &gsn_1h_concussion, 
		{ 53,53,53,53,  53,53,53,34,  53,53,53,53,  34,34,34,34 }, 
		STYLE_STYLE, FLAGS(0), 
		"You swing your weapon around and smash $N's nose deep into $S face!", 
		"$n swings $s weapon around and smashes your nose deep into your face!", 
		"$n swings $s weapon around and smashes $N's nose deep into $S face!", 
		ATTACK(35), DAMAGE(34), DEFENSE(0), style_devastator, 
		"Medium-duration bleeding", "concussion"
		, 0, NULL
    }, 

    { "bonecrusher", 90, &gsn_1h_concussion, 
		{ 53,53,53,53,  53,53,53,39,  53,53,53,53,  39,39,39,39 }, 
		STYLE_PARRY, FLAGS(0), 
		"You break $N's extended arm with a swift blow!", 
		"$n breaks your extended arm with a swift blow!", 
		"$n breaks $N's extended arm with a swift blow!", 
		ATTACK(35), DAMAGE(39), DEFENSE(4), style_severe_pain, 
		"Severe Pain"
		, 0, NULL
    }, 

    { "mauler", 105, &gsn_1h_concussion, 
		{ 53,53,53,53,  53,53,53,44,  53,53,53,53,  44,44,44,44 }, 
		STYLE_STYLE, FLAGS(0), 
		"You disfigure $N by slamming your weapon into $S face from below!", 
		"$n disfigures you by slamming $s weapon into your face from below!", 
		"$n disfigures $N by slamming $s weapon into $S face from below!", 
		ATTACK(35), DAMAGE(44), DEFENSE(0), style_mauler, 
		"42% attack speed reduction", "skullcrusher"
		, 0, NULL
    }, 

    { "pulverizer", 125, &gsn_1h_concussion, 
		{ 53,53,53,53,  53,53,53,50,  53,53,53,53,  50,50,50,50 }, 
		STYLE_STYLE, FLAGS(0), 
		"With a powerful blow, you pulp $N's head into an unrecognizable mess!", 
		"With a powerful blow, $n pulps your head into an unrecognizable mess!", 
		"With a powerful blow, $n pulps $N's head into an unrecognizable mess!", 
		ATTACK(35), DAMAGE(44), DEFENSE(0), style_mauler, 
		"8-second stun", "devastator"
		, 0, NULL
    }, 

    { "anvil", 20, &gsn_2h_concussion, 
		{ 53,53,53,53,  53,53,53,2,  53,53,53,53,  2,2,2,2 }, 
		OPENING_NONE, FLAGS(0), 
		"You smash $N to the ground!", 
		"$n smashes you to the ground!", 
		"$n smashes $N to the ground!", 
		ATTACK(50), DAMAGE(3), DEFENSE(0), NULL,
		"None"
		, 0, NULL
    }, 

    { "pound", 10, &gsn_2h_concussion, 
		{ 53,53,53,53,  53,53,53,4,  53,53,53,53,  4,4,4,4 }, 
		STYLE_STARTER, FLAGS(0), 
		"You pound $N into a bloody mass!", 
		"$n pounds you into a bloody mass!", 
		"$n pounds $N into a bloody mass!", 
		ATTACK(35), DAMAGE(4), DEFENSE(0), style_moderate_pain, 
		"Pain"
		, 0, NULL
    }, 

    { "blast", 20, &gsn_2h_concussion, 
		{ 53,53,53,53,  53,53,53,6,  53,53,53,53,  6,6,6,6 }, 
		OPENING_NONE, FLAGS(0), 
		"You swing your weapon in a half-circle and knock $N backwards!", 
		"$n swing $s weapon in a half-circle and knocks you backwards!", 
		"$n swing $s weapon in a half-circle and knocks $N backwards!", 
		ATTACK(20), DAMAGE(6), DEFENSE(2), NULL,
		"None"
		, 0, NULL
    }, 

    { "slam", 25, &gsn_2h_concussion, 
		{ 53,53,53,53,  53,53,53,8,  53,53,53,53,  8,8,8,8 }, 
		STYLE_STYLE, FLAGS(0), 
		"You crush an organ in $N with a strong swing of your weapon!", 
		"$n crushes an organ in you with a strong swing of $s weapon!", 
		"$n crushes an organ in $N  with a strong swing of $s weapon!", 
		ATTACK(35), DAMAGE(44), DEFENSE(0), style_perforate, 
		"Short-duration bleeding", "pound"
		, 0, NULL
    }, 

    { "ruiner", 35, &gsn_2h_concussion, 
		{ 53,53,53,53,  53,53,53,10,  53,53,53,53,  10,10,10,10 }, 
		OPENING_NONE, FLAGS(0), 
		"You sweep $N's legs out from under $S with a powerful sweep of your weapon!", 
		"$n sweeps your legs out from under you with a powerful sweep of $s weapon!", 
		"$n sweeps $N's legs out from under $N with a powerful sweep of $s weapon!", 
		ATTACK(20), DAMAGE(20), DEFENSE(0), style_snare, 
		"Movement rate reduction"
		, 0, NULL
    }, 

    { "rifthammer", 35, &gsn_2h_concussion, 
		{ 53,53,53,53,  53,53,53,12,  53,53,53,53,  12,12,12,12 }, 
		STYLE_STARTER, FLAGS(0), 
		"You ruin $N's body with a crushing blow!", 
		"$n ruins your body with a crushing blow!", 
		"$n ruins $N's body with a crushing blow!", 
		ATTACK(35), DAMAGE(24), DEFENSE(0), style_thigh_stab, 
		"24% attack speed reduction"
		, 0, NULL
    }, 

    { "provoker", 35, &gsn_2h_concussion, 
		{ 53,53,53,53,  53,53,53,15,  53,53,53,53,  15,15,15,15 }, 
		OPENING_NONE, FLAGS(0), 
		"You drag your weapon through the ground and spray $N with debris!", 
		"$n drags $s weapon through the ground and sprays you with debris!", 
		"$n drags $s weapon through the ground and sprays $N with debris!", 
		ATTACK(35), DAMAGE(7), DEFENSE(-4), style_instigator, 
		"Taunt"
		, 0, NULL
    }, 

    { "demolish", 40, &gsn_2h_concussion, 
		{ 53,53,53,53,  53,53,53,18,  53,53,53,53,  18,18,18,18 }, 
		STYLE_STYLE, FLAGS(0), 
		"You quickly swing your weapon and catch $N rising to stand!", 
		"$n quickly swings $s weapon and catches you rising to stand!", 
		"$n quickly swings $s weapon and catches $N rising to stand!", 
		ATTACK(20), DAMAGE(18), DEFENSE(0), style_severe_pain, 
		"Moderate pain", "ruiner"
		, 0, NULL
    }, 

    { "smithys fury", 45, &gsn_2h_concussion, 
		{ 53,53,53,53,  53,53,53,21,  53,53,53,53,  21,21,21,21 }, 
		STYLE_BLOCK, FLAGS(0), 
		"Your mighty strike drives $N's arm into $S leg!", 
		"$n's mighty strike drives your arm into your leg!", 
		"$n's mighty strike drives $N's arm into $S leg!", 
		ATTACK(35), DAMAGE(21), DEFENSE(-2), style_coil, 
		"Imposes defensive penalty on victim"
		, 0, NULL
    }, 

    { "crumble", 65, &gsn_2h_concussion, 
		{ 53,53,53,53,  53,53,53,25,  53,53,53,53,  25,25,25,25 }, 
		STYLE_STYLE, FLAGS(0), 
		"$N collapses as you finish $S broken body with a powerful stroke!", 
		"You collapses as $n finishes your broken body with a powerful stroke!", 
		"$N collapses as $n finishes $S broken body with a powerful stroke!", 
		ATTACK(35), DAMAGE(50), DEFENSE(0), style_sunder, 
		"Medium-duration bleeding", "rifthammer"
		, 0, NULL
    }, 

    { "conqueror", 70, &gsn_2h_concussion, 
		{ 53,53,53,53,  53,53,53,29,  53,53,53,53,  29,29,29,29 }, 
		STYLE_STYLE, FLAGS(0), 
		"You swing your weapon in an overhead swing, straight into $N's body!", 
		"$n swings $s weapon in an overhead swing, straight into your body!", 
		"$n swings $s weapon in an overhead swing, straight into $N's body!", 
		ATTACK(20), DAMAGE(58), DEFENSE(-6), style_conqueror, 
		"44% attack speed reduction", "provoker"
		, 0, NULL
    }, 

    { "smithys retort", 80, &gsn_2h_concussion, 
		{ 53,53,53,53,  53,53,53,34,  53,53,53,53,  34,34,34,34 }, 
		STYLE_PARRY, FLAGS(0), 
		"You swing a glancing blow off of $N's head!", 
		"$n swings a glancing blow off of your head!", 
		"$n swings a glancing blow off of $N's head!", 
		ATTACK(35), DAMAGE(34), DEFENSE(0), style_smithysretort, 
		"6-second stun"
		, 0, NULL
    }, 

    { "lambast", 70, &gsn_2h_concussion, 
		{ 53,53,53,53,  53,53,53,39,  53,53,53,53,  39,39,39,39 }, 
		STYLE_STYLE, FLAGS(0), 
		"You crush $N's head, while $N lies helpless on the ground!", 
		"$n crushes your head, while you lie helpless on the ground!", 
		"$n crushes $N's head, while $N lies helpless on the ground!", 
		ATTACK(20), DAMAGE(58), DEFENSE(-6), style_lambast, 
		"7-second stun", "demolish"
		, 0, NULL
    }, 

    { "widowmaker", 70, &gsn_2h_concussion, 
		{ 53,53,53,53,  53,53,53,44,  53,53,53,53,  44,44,44,44 }, 
		STYLE_STYLE, FLAGS(0), 
		"Your powerful blow smashes $N into a twitching pulp!", 
		"$n's powerful blow smashes you into a twitching pulp!", 
		"$n's powerful blow smashes $N into a twitching pulp!", 
		ATTACK(50), DAMAGE(88), DEFENSE(0), style_widowmaker, 
		"8-second stun", "crumble"
		, 0, NULL
    }, 

    { "deaths cradle", 70, &gsn_2h_concussion, 
		{ 53,53,53,53,  53,53,53,50,  53,53,53,53,  50,50,50,50 }, 
		STYLE_STYLE, FLAGS(0), 
		"You swing your weapon in a horizontal swing, driving deep into $N's ribs!", 
		"$n swings $s weapon in a horizontal swing, driving deep into your ribs!", 
		"$n swings $s weapon in a horizontal swing, driving deep into $N's ribs!", 
		ATTACK(20), DAMAGE(100), DEFENSE(-9), style_dragonbite, 
		"Long-duration bleeding", "conqueror"
		, 0, NULL
    }, 

    { "prod", 20, &gsn_spear,
       { 53,53,53,53,  53,53,2,53,  53,53,53,53,  2,2,2,2 },
       OPENING_NONE, FLAGS(0),
       "You poke at $N!",
       "$n pokes at you!",
       "$n pokes at $N!",
       ATTACK(35), DAMAGE(5), DEFENSE(0), NULL,
       "None"
		, 0, NULL
	},

   	{ "perforate", 25, &gsn_spear,
       { 53,53,53,53,  53,53,4,53,  53,53,53,53,  4,4,4,4 },
       STYLE_STARTER, FLAGS(0),
       "You tear open $N's stomach with a few strong jabs!",
       "$n tears open your stomach with a few strong jabs!",
       "$n tears open $N's stomach with a few strong jabs!",
       ATTACK(35), DAMAGE(8), DEFENSE(0), style_perforate,
       "Short-duration bleeding"
		, 0, NULL
   	},

    { "bore", 30, &gsn_spear,
       { 53,53,53,53,  53,53,6,53,  53,53,53,53,  6,6,6,6 },
       OPENING_NONE, FLAGS(0),
       "You lunge forward and impale $N, pushing your weapon deep into $S chest!",
       "$n lunges forward and impales you, pushing $s weapon deep into your chest!",
       "$n lunges forward and impales $N, pushing $s weapon deep into $S chest!",
       ATTACK(25), DAMAGE(12), DEFENSE(0), NULL,
       "None"
		, 0, NULL
   },

   { "penetrate", 35, &gsn_spear,
       { 53,53,53,53,  53,53,8,53,  53,53,53,53,  8,8,8,8 },
       STYLE_STYLE, FLAGS(0),
       "You drive your weapon deep into one of the holes in $N's chest!",
       "$n drives $s weapon deep into one of the holes in your chest!",
       "$n drives $s weapon deep into one of the holes in $N's chest!",
       ATTACK(45), DAMAGE(15), DEFENSE(0), style_moderate_pain,
       "Pain", "perforate"
		, 0, NULL
       },

    { "spit", 30, &gsn_spear,
       { 53,53,53,53,  53,53,10,53,  53,53,53,53,  10,10,10,10 },
       OPENING_NONE, FLAGS(0),
       "You duck to the side and slam your weapon through $N's lower calves!",
       "$n ducks to the side and slams $s weapon through your lower calves!",
       "$n ducks to the side and slams $s weapon through $N's lower calves!",
       ATTACK(50), DAMAGE(7), DEFENSE(-2), style_snare,
       "Movement rate reduction"
		, 0, NULL
       },

	{ "jab", 40, &gsn_spear,
       { 53,53,53,53,  53,53,12,53,  53,53,53,53,  12,12,12,12 },
       OPENING_NONE, FLAGS(0),
       "You slam your weapon into $N with a quick jab!",
       "$n slams $s weapon into you with a quick jab!",
       "$n slams $s weapon into $N with a quick jab!",
       ATTACK(20), DAMAGE(22), DEFENSE(0), NULL,
       "None"
		, 0, NULL
	},

   { "pierce", 45, &gsn_spear,
       { 53,53,53,53,  53,53,15,53,  53,53,53,53,  15,15,15,15 },
       STYLE_STYLE, FLAGS(0),
       "You force your weapon deep into $N's body!",
       "$n forces $s weapon deep into your body!",
       "$n forces $s weapon deep into $N's body!",
       ATTACK(20), DAMAGE(28), DEFENSE(0), style_thigh_stab,
       "24% attack speed reduction", "jab"
		, 0, NULL
   },

   { "skewer", 60, &gsn_spear,
       { 53,53,53,53,  53,53,18,53,  53,53,53,53,  18,18,18,18 },
       OPENING_NONE, FLAGS(0),
       "You skewer $N on your weapon!",
       "$n skewers you on $s weapon!",
       "$n skewers $N on $s weapon!",
       ATTACK(25), DAMAGE(35), DEFENSE(0), NULL,
       "None"
		, 0, NULL
   },

   { "brace", 80, &gsn_spear,
       { 53,53,53,53,  53,53,21,53,  53,53,53,53,  21,21,21,21 },
       STYLE_PARRY, FLAGS(0),
       "You knock aside $N's weapon, step quickly back, and brace as $N steps onto your weapon!",
       "$n knocks aside your weapon, steps quickly back, and braces as you step onto $s weapon!",
       "$n knocks aside $N's weapon, steps quickly back, and braces as $N steps onto $s weapon!",
       ATTACK(-20), DAMAGE(50), DEFENSE(7), style_instigator,
       "Taunt"
		, 0, NULL
   },

   { "spike", 120, &gsn_spear,
       { 53,53,53,53,  53,53,25,53,  53,53,53,53,  25,25,25,25 },
       STYLE_STYLE, FLAGS(0),
       "You drive $N to the ground with your weapon through $s body!",
       "$n drives you to the ground with $s weapon through your body!",
       "$n drives $N to the ground with $s weapon through $N's body!",
       ATTACK(35), DAMAGE(45), DEFENSE(3), style_spike,
       "Medium-duration bleeding", "pierce"
		, 0, NULL
   },

   { "discard", 140, &gsn_spear,
       { 53,53,53,53,  53,53,29,53,  53,53,53,53,  29,29,29,29 },
       STYLE_STYLE, FLAGS(0),
       "You throw $N off your weapon and across the room with a strong swing!",
       "$n throws you off $s weapon and across the room with a strong swing!",
       "$n throws $N off $s weapon and across the room with a strong swing!",
       ATTACK(50), DAMAGE(60), DEFENSE(0), style_discard,
       "Imposes defensive penalty on victim", "brace"
		, 0, NULL
   },

   { "lance", 150, &gsn_spear,
       { 53,53,53,53,  53,53,34,53,  53,53,53,53,  34,34,34,34 },
       STYLE_STYLE, FLAGS(0),
       "You drive $N back by pushing your weapon deeper!",
       "$n drives you back by pushing $s weapon deeper!",
       "$n drives $N back by pushing $s weapon deeper!",
       ATTACK(30), DAMAGE(55), DEFENSE(0), style_lance,
       "Imposes defensive penalty on victim", "skewer"
		, 0, NULL
   },

   { "pin", 160, &gsn_spear,
       { 53,53,53,53,  53,53,39,53,  53,53,53,53,  39,39,39,39 },
       STYLE_STYLE, FLAGS(0),
       "You heft your weapon high then spin and slam it into the ground and pin $N there!",
       "$n hefts $s weapon high then spins and slams it into the ground and pins you there!",
       "$n hefts $s weapon high then spins and slams it into the ground and pins $N there!",
       ATTACK(50), DAMAGE(70), DEFENSE(0), style_pin,
       "10-second stun", "brace"
		, 0, NULL
   },

   { "gore", 190, &gsn_spear,
       { 53,53,53,53,  53,53,44,53,  53,53,53,53,  44,44,44,44 },
       STYLE_STYLE, FLAGS(0),
       "You rip a gaping hole in $N's chest with a sideways thrust!",
       "$n rips a gaping hole in your chest with a sideways thrust!",
       "$n rips a gaping hole in $N's chest with a sideways thrust!",
       ATTACK(40), DAMAGE(115), DEFENSE(2), style_gore,
       "Long-duration bleeding", "skewer"
		, 0, NULL
   },

   { "impale", 240, &gsn_spear,
       { 53,53,53,53,  53,53,44,53,  53,53,53,53,  44,44,44,44 },
       STYLE_STYLE, FLAGS(0),
       "You drive your weapon to the grip into $N's body!",
       "$n drives $s weapon to the grip into your body!",
       "$n drives $s weapon to the grip into $N's body!",
       ATTACK(30), DAMAGE(130), DEFENSE(-4), style_severe_pain,
       "Severe pain", "lance"
		, 0, NULL
   },

	{ NULL }
		
};

int style_lookup( const char *name, int weapon_sn)
{
    int style;

	if ( name == NULL )
		return 0;

    for (style = 0; style_table[style].name != NULL ; style++)
    {
	if (LOWER(name[0]) == LOWER(style_table[style].name[0])
	&&  !str_prefix(name,style_table[style].name))
		{
			if ( weapon_sn < 0 || *style_table[style].weapon_sn == weapon_sn )
	    	return style;
		}
    }

    return -1;
}

void do_styles( Character *ch, char *argument )
{
	char arg[MAX_INPUT_LENGTH];
	int style;
	int weapon_sn;
	Character *victim;

	argument = one_argument( argument, arg );

	if ( arg[0] == '\0' )
	{
		cprintf(ch,"Usage:  style 'style_name' <victim>\n\r"
		   "	style list <weapon_skill_name>\n\r"
				   "	* Victim is optional if you're fighting somebody already.\n\r"
		   "	* If no weapon skill is given to list, your wielded type is the default\n\r");
		return;
	}

	/* check for cancel */
	if ( !str_cmp(arg,"none") || !str_cmp(arg,"cancel") || !str_cmp(arg,"clear") )
	{	
		if ( ch->style <= 0 )
			cprintf(ch,"You have no style prepared!\n\r");
		else
			cprintf(ch,"You decide not to perform the %s style.\n\r", style_table[ch->style].name );

		ch->style = 0;
		return;
	}

	if ( !str_cmp(arg,"list") )
	{
		do_style_list(ch,argument);
		return;
	}

	if ( ch->style != NULL && !HAS_AUTOOPT(ch, AUTO_SWITCHSTYLES))
	{
		cprintf(ch,"You're already performing the %s style.\n\r", style_table[ch->style].name );
		return;
	}

	weapon_sn = get_weapon_sn( ch, GET_WEAPON_SN );
	if ( (style = style_lookup( arg, -1 )) < 0 )
	{
		cprintf(ch,"No style called '%s'.\n\r", arg );
		return;
	}

    if ( style_table[style].class_level[ch->class] > get_skill(ch,weapon_sn) && !IS_IMMORTAL(ch) )
    {
		if ( style_table[style].class_level[ch->class] > 51 )
	    	cprintf(ch,"Your class cannot use that style.\n\r");
		else
	    	cprintf(ch,"Your skill isn't high enough, a minimum of %d is required in %s.\n\r",
				style_table[style].class_level[ch->class], 
				skill_table[*style_table[style].weapon_sn].name );
		return;
    }

	if ( *style_table[style].weapon_sn != weapon_sn )
	{
		cprintf(ch,"That style is a %s style and your current weapon style is %s.\n\r",
			skill_table[ *style_table[style].weapon_sn ].name,
			skill_table[ weapon_sn ].name );
		return;
	}

	if ( ch->stamina < style_table[style].stamina )
	{
		cprintf(ch,"You don't have enough stamina.\n\r");
		return;
	}

	ch->style = style;
	actprintf(ch,NULL,NULL,TO_CHAR,"You prepare to perform the %s style.", style_table[style].name );

	if ( ch->fighting == NULL && *argument != '\0' )
	{
	    if ( (victim = get_char_room(ch,argument)) == NULL )
	{
	    cprintf(ch,"That person isn't here.\n\r");      
	    return;
	}
		one_hit(ch,victim,TYPE_UNDEFINED);
	}
	return;
}

void do_style_list( Character *ch, char *argument )
{
	int sn;
	int count=0;
	int i;

	if ( *argument == NULL )
		sn = get_weapon_sn(ch, GET_WEAPON_SN );
 	else
	if ( (sn = skill_lookup(argument)) < 1 )
	{
		cprintf(ch,"No such weapon skill '%s'.\n\r", argument );
		return;
	}

	if ( skill_table[sn].type != SKILL_WEAPON )
	{
		if( *argument == NULL )
			cprintf(ch, "Your current weapon style of %s is not a weapon skill.\n\r",
				skill_table[sn].name );
		else
			cprintf(ch,"That's not a weapon skill.\n\r");
		return;
	}

	cprintf(ch,"[%s %s]\n\r", capitalize(class_table[ch->class].name), skill_table[sn].name );
	for( i=0; style_table[i].name != NULL ; i++ )
	{
		if ( style_table[i].class_level[ch->class] > get_skill(ch,sn) && !IS_IMMORTAL(ch) )
			continue;

		if ( *style_table[i].weapon_sn != sn )
			continue;

		cprintf(ch," * %-s, requires %d skill and %d stamina\n\r",
			style_table[i].name, style_table[i].class_level[ch->class], style_table[i].stamina );
		cprintf(ch,"   Attack:  %+d   Damage: %+d   Defense: %+d\n\r",
			style_table[i].attack, style_table[i].damage, style_table[i].defense );
		cprintf(ch,"   Opening: %s\n\r", opening_move(i) );
		cprintf(ch,"   Affect : %s\n\r", style_table[i].affect );
	
		cprintf(ch,"\n\r");	
		++count;
	}

	cprintf(ch,"(%d styles found for you)\n\r", count);
}

bool can_use_style( Character *ch, Character *victim, int style )
{
	int weapon_sn;

	if ( style_table[style].opening == OPENING_NONE )
		return TRUE;
	
	if ( style_table[style].opening == STYLE_STARTER && ch->fighting != NULL )
		return FALSE;

	if ( style_table[style].opening == STYLE_PARRY && 
			(ch->last_defend != STYLE_PARRY || ch->fighting != ch->last_defend_attacker) )
		return FALSE;

	if ( style_table[style].opening == STYLE_EVADE && 
			(ch->last_defend != STYLE_EVADE || ch->fighting != ch->last_defend_attacker) )
		return FALSE;
	
	if ( style_table[style].opening == STYLE_BLOCK && 
			(ch->last_defend != STYLE_BLOCK || ch->fighting != ch->last_defend_attacker) )
		return FALSE;

	if ( style_table[style].opening == STYLE_STYLE )
	{
		int sn;

    	weapon_sn = get_weapon_sn( ch, GET_WEAPON_SN );
		if ( (sn = style_lookup( style_table[style].opening_style, weapon_sn )) < 1 )
		{
			log_bug("No style called %s", style_table[style].opening_style );
			return FALSE;
		}

		if ( ch->last_style != sn || ch->fighting != ch->last_style_victim )
			return FALSE;
	}

	return TRUE;
}

void set_style(Character *ch,Character *victim,int style)
{
	ch->last_style = style;
	ch->last_style_victim = victim;
	return;
}

void clear_style(Character *ch)
{
	ch->last_style = 0;
	ch->last_style_victim = NULL;
}

void set_defend(Character *ch,Character *victim,int style)
{
    ch->last_defend = style;
    ch->last_defend_attacker = victim;
    return;
}

void clear_defend(Character *ch)
{
    ch->last_defend = 0;
    ch->last_defend_attacker = NULL;
}

char *opening_move( int style )
{
	if ( style_table[style].opening == OPENING_NONE )	
		return "no opening";
	if ( style_table[style].opening == STYLE_EVADE )
		return "you evade";
	if ( style_table[style].opening == STYLE_PARRY )
		return "you parry";
	if ( style_table[style].opening == STYLE_BLOCK )
		return "you shield block";
	if ( style_table[style].opening == STYLE_STARTER )
		return "opening move";
	if ( style_table[style].opening == STYLE_STYLE )
		return style_table[style].opening_style;

	return "unknown (this usually means an error)";
}

void apply_style_defense( Character *ch, int sn )
{
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = vnum_positioning;
    af.level     = ch->level;
    af.duration  = seconds(30);
    af.location  = APPLY_SKILL;
    af.modifier  = style_table[sn].defense;
    af.misc      = gsn_parry;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( ch, &af );

    af.misc     = gsn_dodge;
    spellAffectToChar( ch, &af );
}

/* ================================================================== */

/*
 * Actual style code
 */
bool style_side_thrust( Character *ch, Character *victim, int style )
{
    DAZE_STATE(victim,PULSE_PER_SECOND*4);
	act("You are stunned!",victim,NULL,NULL,TO_CHAR);
	act("$n&C is stunned!",victim,NULL,NULL,TO_ROOM);
    return 0;
}

bool style_perforate( Character *ch, Character *victim, int style )
{
	Affect af;

	af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(30);
    af.location     = 2;
    af.modifier     = 4;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );


	act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);
	act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
	return TRUE;
}

bool style_belly_stab( Character *ch, Character *victim, int style )
{
	Affect af;

	af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(30);
    af.location     = 1;
    af.modifier     = 2;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );


	act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);
	act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
	return TRUE;
}

bool style_separate_shoulder( Character *ch, Character *victim, int style )
{
	Affect af;

	af.where		= TO_AFFECTS;
    af.caster_id    = ch->id;
    af.bitvector    = AFF_SLOW;
    af.type	 = vnum_slow;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = APPLY_SPEED;
    af.modifier     = 118;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );

    return TRUE;
}

bool style_devastator( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = 14;
    af.modifier     = 19;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);  
    act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool style_spike( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = 8;
    af.modifier     = 12;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);  
    act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool style_kidney_stab( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = 3;
    af.modifier     = 4;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );


    act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);  
    act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool style_flatblade_bash( Character *ch, Character *victim, int style )
{
    DAZE_STATE(victim,PULSE_PER_SECOND*6);
    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n&C is stunned!",victim,NULL,NULL,TO_ROOM);
    return 0;   
}

bool style_concussion( Character *ch, Character *victim, int style )
{
    Affect af;

	af.where		= TO_AFFECTS;
    af.caster_id    = ch->id;
    af.bitvector    = AFF_SLOW;
    af.type	 = vnum_slow;
    af.level	= style_table[style].class_level[ch->class];      
    af.duration     = seconds(60);
    af.location     = APPLY_SPEED;
    af.modifier     = 128;
    af.flags	= AFF_SPELL;       
    spellAffectToChar( victim, &af );

    return TRUE;
}

bool style_thigh_stab( Character *ch, Character *victim, int style )
{
    Affect af;

	af.where		= TO_AFFECTS;
    af.caster_id    = ch->id;
    af.bitvector    = AFF_SLOW;
    af.type	 = vnum_slow;
    af.level	= style_table[style].class_level[ch->class];      
    af.duration     = seconds(60);
    af.location     = APPLY_SPEED;
    af.modifier     = 124;
    af.flags	= AFF_SPELL;       
    spellAffectToChar( victim, &af );

    return TRUE;
}

bool style_spin_thrust( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(90);
    af.location     = 8;
    af.modifier     = 10;  
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );


    act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);
    act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}


bool style_carpus_shatter( Character *ch, Character *victim, int style )
{
    Affect af;

	af.where		= TO_AFFECTS;
    af.caster_id    = ch->id;
    af.bitvector    = AFF_SLOW;
    af.type	 = vnum_slow;    
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = APPLY_SPEED;
    af.modifier     = 136;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );

    return TRUE;
}

bool style_heart_stab( Character *ch, Character *victim, int style )
{
    DAZE_STATE(victim,PULSE_PER_SECOND*8);
    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n&C is stunned!",victim,NULL,NULL,TO_ROOM);
    return 0;
}

bool style_spider_bite( Character *ch, Character *victim, int style )
{
   	Affect af;

    af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];	 
    af.duration     = seconds(30);
    af.location     = 2;
    af.modifier     = 3;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );


    act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);	   
    act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool style_scorpion_sting( Character *ch, Character *victim, int style )
{
    DAZE_STATE(victim,PULSE_PER_SECOND*4);
    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n&C is stunned!",victim,NULL,NULL,TO_ROOM);
    return 0;
}

bool style_wasp_sting( Character *ch, Character *victim, int style )
{
    Affect af;

	af.where		= TO_AFFECTS;
    af.caster_id    = ch->id;
    af.bitvector    = AFF_SLOW;
    af.type	 = vnum_slow;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = APPLY_SPEED;
    af.modifier     = 124;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );

    return TRUE;
}

bool style_discard( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = vnum_positioning;
    af.level     = ch->level;
    af.duration  = seconds(30);
    af.location  = APPLY_SKILL;
    af.modifier  = -6;
    af.misc      = gsn_parry;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( ch, &af );      

    af.misc     = gsn_dodge;   
    spellAffectToChar( ch, &af );  
	
	return TRUE;
}

bool style_coil( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = vnum_positioning;
    af.level     = ch->level;
    af.duration  = seconds(30);
    af.location  = APPLY_SKILL;
    af.modifier  = -5;
    af.misc      = gsn_parry;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( ch, &af );      

    af.misc     = gsn_dodge;   
    spellAffectToChar( ch, &af );  
	
	return TRUE;
}

bool style_hornet_sting( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];	 
    af.duration     = seconds(60);
    af.location     = 7;
    af.modifier     = 9;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );


    act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);	   
    act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool style_asp( Character *ch, Character *victim, int style )
{
    DAZE_STATE(victim,PULSE_PER_SECOND*6);
    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n&C is stunned!",victim,NULL,NULL,TO_ROOM);
    return 0;
}

bool style_lance( Character *ch, Character *victim, int style )
{
    Affect af;

	af.where		= TO_AFFECTS;
    af.caster_id    = ch->id;
    af.bitvector    = AFF_SLOW;
    af.type	 = vnum_slow;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = APPLY_SPEED;
    af.modifier     = 135;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );

    return TRUE;
}

bool style_diamondback( Character *ch, Character *victim, int style )
{
    Affect af;

	af.where		= TO_AFFECTS;
    af.caster_id    = ch->id;
    af.bitvector    = AFF_SLOW;
    af.type	 = vnum_slow;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = APPLY_SPEED;
    af.modifier     = 134;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );

    return TRUE;
}

bool style_cobra( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(90);
    af.location     = 18;
    af.modifier     = 22; 
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );


    act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);
    act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool style_dragonbite( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(90);
    af.location     = 25;
    af.modifier     = 33; 
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );


    act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);
    act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool style_hounds_maw( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = 3;
    af.modifier     = 6;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );


    act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);
    act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool style_manikovs_quarter( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = 8;
    af.modifier     = 10;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );


    act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);
    act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool style_taihrs_finale( Character *ch, Character *victim, int style )
{
    Affect af;

	af.where		= TO_AFFECTS;
    af.caster_id    = ch->id;
    af.bitvector    = AFF_SLOW;
    af.type	 = vnum_slow;    
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = APPLY_SPEED;
    af.modifier     = 120;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );

    return TRUE;
}

bool style_pin( Character *ch, Character *victim, int style )
{
    DAZE_STATE(victim,PULSE_PER_SECOND*10);
    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n&C is stunned!",victim,NULL,NULL,TO_ROOM);
    return 0;
}

bool style_wolfs_maw( Character *ch, Character *victim, int style )
{
    DAZE_STATE(victim,PULSE_PER_SECOND*5);
    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n&C is stunned!",victim,NULL,NULL,TO_ROOM);
    return 0;
}

bool style_crippler( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where     = TO_AFFECTS; 
    af.type      = vnum_positioning;
    af.level     = ch->level;
    af.duration  = seconds(30);   
    af.location  = APPLY_SKILL;   
    af.modifier  = -7;
    af.misc      = gsn_parry;   
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( ch, &af );

    af.misc     = gsn_dodge;
    spellAffectToChar( ch, &af );

    return TRUE;
}

bool style_gore( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(90);
    af.location     = 25;
    af.modifier     = 33;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );


    act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);
    act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool style_griffonclaw( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(90);
    af.location     = 25;
    af.modifier     = 33;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );


    act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);
    act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool style_mauler( Character *ch, Character *victim, int style )
{
    Affect af;

	af.where		= TO_AFFECTS;
    af.caster_id    = ch->id;
    af.bitvector    = AFF_SLOW;
    af.type	 = vnum_slow;    
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = APPLY_SPEED;
    af.modifier     = 142;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );

    return TRUE;
}

bool style_conqueror( Character *ch, Character *victim, int style )
{
    Affect af;

	af.where		= TO_AFFECTS;
    af.caster_id    = ch->id;
    af.bitvector    = AFF_SLOW;
    af.type	 = vnum_slow;    
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = APPLY_SPEED;
    af.modifier     = 144;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );

    return TRUE;
}

bool style_vesikurs_quarter( Character *ch, Character *victim, int style )
{
    Affect af;

	af.where		= TO_AFFECTS;
    af.caster_id    = ch->id;
    af.bitvector    = AFF_SLOW;
    af.type	 = vnum_slow;    
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = APPLY_SPEED;
    af.modifier     = 140;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );

    return TRUE;
}

bool style_wyrmfang( Character *ch, Character *victim, int style )
{
    DAZE_STATE(victim,PULSE_PER_SECOND*9);
    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n&C is stunned!",victim,NULL,NULL,TO_ROOM);
    return 0;
}

bool style_half_moon( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(30);
    af.location     = 2;
    af.modifier     = 3;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );


    act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);
    act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool style_rupture( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;   
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = 12;
    af.modifier     = 15;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );


    act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);
    act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool style_bloodbringer( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;   
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(90);
    af.location     = 18;
    af.modifier     = 22;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );


    act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);
    act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool style_snare( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where	= TO_AFFECTS;
    af.type	 = vnum_snare;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(30);
    af.location     = APPLY_MOVE_RATE;
    af.modifier     = PULSE_PER_SECOND / 2;
    af.bitvector    = 0;
    af.flags	= AFF_SPELL;
    spellAffectToChar(victim,&af);     
    return TRUE;
}

bool style_gibbous_moon( Character *ch, Character *victim, int style )
{
    Affect af;

	af.where		= TO_AFFECTS;
    af.caster_id    = ch->id;    
    af.bitvector    = AFF_SLOW;  
    af.type	 = vnum_slow;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);    
    af.location     = APPLY_SPEED;
    af.modifier     = 118;     
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );

    return TRUE;
}

bool style_painbringer( Character *ch, Character *victim, int style )
{
    Affect af;

	af.where		= TO_AFFECTS;
    af.caster_id    = ch->id;
    af.bitvector    = AFF_SLOW;
    af.type	 = vnum_slow;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = APPLY_SPEED;
    af.modifier     = 136;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );

    return TRUE;
}

bool style_iron_retort( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = vnum_positioning;
    af.level     = ch->level;
    af.duration  = seconds(30);
    af.location  = APPLY_SKILL;
    af.modifier  = -5;
    af.misc      = gsn_parry;	  
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( ch, &af );

    af.misc     = gsn_dodge;
    spellAffectToChar( ch, &af );

    return TRUE;
}

bool style_full_moon( Character *ch, Character *victim, int style )
{
    DAZE_STATE(victim,PULSE_PER_SECOND*6);
    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n&C is stunned!",victim,NULL,NULL,TO_ROOM);
    return 0;
}

bool style_blades_anguish( Character *ch, Character *victim, int style )
{
    DAZE_STATE(victim,PULSE_PER_SECOND*9);
    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n&C is stunned!",victim,NULL,NULL,TO_ROOM);
    return 0;
}

bool style_instigator( Character *ch, Character *victim, int style )
{
	int chance;

	if ( victim->fighting == ch || victim->fighting == NULL || !IS_NPC(victim) )
		return 0;

	/* check taunt */
	chance = 50 + ch->level - victim->level;
	if ( number_percent() < chance )
	{
		stop_fighting( victim->fighting, FALSE );
    	stop_fighting( victim, FALSE );

    	set_fighting( ch, victim );
    	set_fighting( victim, ch );
		act("$N snarls and turns to face you!",ch,NULL,victim,TO_CHAR);
		act("$N snarls and turns to face $n!",ch,NULL,victim,TO_NOTVICT);
		act("You snarl and turn to face $n!",ch,NULL,victim,TO_VICT);
	}

	return 0;
}

bool style_gash( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(30);
    af.location     = 3;
    af.modifier     = 4;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );


    act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);
    act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool style_hew( Character *ch, Character *victim, int style )
{
    DAZE_STATE(victim,PULSE_PER_SECOND*6);
    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n&C is stunned!",victim,NULL,NULL,TO_ROOM);
    return 0;
}

bool style_decapitate( Character *ch, Character *victim, int style )
{
    Affect af;

	af.where		= TO_AFFECTS;
    af.caster_id    = ch->id;
    af.bitvector    = AFF_SLOW;
    af.type	 = vnum_slow;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = APPLY_SPEED;
    af.modifier     = 120;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );

    return TRUE;
}

bool style_moderate_pain( Character *ch, Character *victim, int style )
{
    Affect af;

	af.where		= TO_AFFECTS;
    af.caster_id    = ch->id;
    af.bitvector    = 0;
	af.misc			= 0;
    af.type	 = vnum_pain;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = APPLY_HITROLL;
    af.modifier     = -10;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );

    return TRUE;
}
	
bool style_rive( Character *ch, Character *victim, int style )
{
    Affect af;

	af.where		= TO_AFFECTS;
    af.caster_id    = ch->id;
    af.bitvector    = AFF_SLOW;
    af.type	 = vnum_slow;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = APPLY_SPEED;
    af.modifier     = 130;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );

    return TRUE;
}

bool style_sunder( Character *ch, Character *victim, int style )
{
    Affect af;  

    af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = 10;
    af.modifier     = 15;
    af.flags	= AFF_SPELL;  
    spellAffectToChar( victim, &af );


    act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);
    act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}


bool style_severe_pain( Character *ch, Character *victim, int style )
{
    Affect af;

	af.where		= TO_AFFECTS;
    af.caster_id    = ch->id;
    af.bitvector    = 0;
    af.misc	 = 0;
    af.type	 = vnum_pain;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = APPLY_HITROLL;
    af.modifier     = -20;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );

    return TRUE;
}

bool style_behead( Character *ch, Character *victim, int style )
{
    Affect af;  

    af.where	= DAMAGE_OVER_TIME;
    af.caster_id    = ch->id;
    af.bitvector    = DAM_BODY;
    af.type	 = vnum_bleeding;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(90);
    af.location     = 20;
    af.modifier     = 22;
    af.flags	= AFF_SPELL;  
    spellAffectToChar( victim, &af );


    act("You begin to bleed!",victim,NULL,NULL,TO_CHAR);
    act("$n begins to bleed!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool style_chine( Character *ch, Character *victim, int style )
{
    Affect af;

	af.where		= TO_AFFECTS;
    af.caster_id    = ch->id;
    af.bitvector    = AFF_SLOW;
    af.type	 = vnum_slow;
    af.level	= style_table[style].class_level[ch->class];
    af.duration     = seconds(60);
    af.location     = APPLY_SPEED;
    af.modifier     = 140;
    af.flags	= AFF_SPELL;
    spellAffectToChar( victim, &af );

    return TRUE;
}

bool style_executioner( Character *ch, Character *victim, int style )
{
    DAZE_STATE(victim,PULSE_PER_SECOND*10);
    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n&C is stunned!",victim,NULL,NULL,TO_ROOM);
    return 0;
}

bool style_contusions( Character *ch, Character *victim, int style )
{
    DAZE_STATE(victim,PULSE_PER_SECOND*4);
    act("You are stunned!",victim,NULL,NULL,TO_CHAR);      
    act("$n&C is stunned!",victim,NULL,NULL,TO_ROOM);
    return 0;
}

bool style_basher( Character *ch, Character *victim, int style )
{
    DAZE_STATE(victim,PULSE_PER_SECOND*6);
    act("You are stunned!",victim,NULL,NULL,TO_CHAR);      
    act("$n&C is stunned!",victim,NULL,NULL,TO_ROOM);
    return 0;
}

bool style_pulverizer( Character *ch, Character *victim, int style )
{
    DAZE_STATE(victim,PULSE_PER_SECOND*8);
    act("You are stunned!",victim,NULL,NULL,TO_CHAR);      
    act("$n&C is stunned!",victim,NULL,NULL,TO_ROOM);
    return 0;
}

bool style_smithysretort( Character *ch, Character *victim, int style )
{
    DAZE_STATE(victim,PULSE_PER_SECOND*6);
    act("You are stunned!",victim,NULL,NULL,TO_CHAR);      
    act("$n&C is stunned!",victim,NULL,NULL,TO_ROOM);
    return 0;
}

bool style_lambast( Character *ch, Character *victim, int style )
{
    DAZE_STATE(victim,PULSE_PER_SECOND*7);
    act("You are stunned!",victim,NULL,NULL,TO_CHAR);      
    act("$n&C is stunned!",victim,NULL,NULL,TO_ROOM);
    return 0;
}

bool style_widowmaker( Character *ch, Character *victim, int style )  
{
    DAZE_STATE(victim,PULSE_PER_SECOND*8);
    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n&C is stunned!",victim,NULL,NULL,TO_ROOM);
    return 0;
}

bool style_legbreaker( Character *ch, Character *victim, int style )
{
    Affect af;

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = vnum_root;   
    af.level        = ch->level;
    af.duration     = seconds(4);
    af.location     = APPLY_ROOT;
    af.modifier     = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

	act("You are immobilized!",victim,NULL,NULL,TO_CHAR);
	act("$n is immobilized!",victim,NULL,NULL,TO_CHAR);
    return TRUE;  
}
