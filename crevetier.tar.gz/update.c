/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "thoc.h"
#include "interp.h"
#include "tables.h"
#include "lookup.h"
#include "recycle.h"
#include "journal.h"
#include "olc.h"
#include "options.h"

/*
 * Local functions.
 */
void 	write_resource_file( void );
void 	save_load( void );
DECLARE_DO_FUN( do_lastlevel );
int	hit_gain	 ( Character *ch );
int	mana_gain	 ( Character *ch );
int	move_gain	 ( Character *ch );
void	mobile_update	 ( void );
void	affect_update	 ( void );
void	regen_update	 ( void );
void	weather_update	 ( void );
void	char_update	 ( void );
void	obj_update	 ( void );
void	aggr_update	 ( void );
bool	do_autoeat	( Character *ch );
bool	do_autodrink	( Character *ch );
bool 	is_aggressive( Character *npc, Character *pc, bool fInfo);

/* used for saving */

int	save_number = 0;


int getSkillPoints( Character *ch, int level )
{
	int points;

	points = level * exp_to_level[level].spm;

    switch ( class_table[ch->class].group )
    {
    case MELEE:
        points += (points / 10); break;
    case STEALTH:
        if ( ch->class == csn_assassin )
            points += (points / 3);
        else
            points += (points / 4);
        break;
    case ARCANE:
    case DIVINE:
        points += (points / 3); break;
    default:
        break;
    }

	return points;
}

/*
 * Advancement stuff.
 */
void advance_level( Character *ch, bool hide )
{
	int cast_stat;
    int add_hp;
    int add_base;
    int add_mana;
    int add_move;
    int add_prac;
	int add_stam;

    ch->pcdata->last_level = 
	( ch->played + (int) (current_time - ch->logon) ) / 3600;

    /* Check pkill status */
    if ( ch->clan == 0 && 
		!IS_SET(ch->act,PLR_NONCLAN) &&
		 ch->level >=5 && ( ch->level >= 10 || ch->pcdata->last_level >= 50) )
    {
		if ( !hide )
		{
			cprintf(ch,"IMPORTANT: &RYou are now a part of the pkill system.  See 'help pkill' for details.&x\n\r");
			wiznet("$N is now a clanner.",ch,NULL,WIZ_LEVELS,0,0);
		}
		ch->clan = clan_lookup("loner");
		ch->clan->total_players++;
    }

    if ( ch->level >= LEVEL_IMMORTAL && ch->clan != NULL )
    {
		cprintf(ch,"IMMORTAL: You are no longer clanned.\n\r");
		ch->clan = NULL;
    }

    add_hp	= number_range(
		    class_table[ch->class].hp_min,
		    class_table[ch->class].hp_max );
	add_hp += ch->pcdata->start_stat[STAT_CON] / 20;

    if ( class_table[ch->class].group == ARCANE )
		cast_stat = ch->pcdata->start_stat[STAT_INT];
    else
		cast_stat = ch->pcdata->start_stat[STAT_WIS];

    add_mana = number_range( cast_stat/6, cast_stat /4 );
    add_mana = class_table[ch->class].fMana * add_mana / 100;
	add_mana += ch->pcdata->start_stat[cast_stat] / 20;

    add_move	= number_range( ch->pcdata->start_stat[STAT_DEX] / 10, ch->pcdata->start_stat[STAT_DEX] / 5 );
			
    add_prac	= getSkillPoints( ch, ch->level );

    add_hp = add_hp * 9/10;
    add_mana = add_mana * 9/10;
    add_move = add_move * 9/10;

	add_stam = number_range( ch->pcdata->start_stat[STAT_CON] / 10,
							 ch->pcdata->start_stat[STAT_CON] / 5 );

    add_hp = (100+apply_stat(ch,STAT_CON))*add_hp/100;
    add_hp	= UMAX(  2, add_hp   );
    add_mana	= UMAX(  2, add_mana );
    add_move	= UMAX(  6, add_move );
    add_base    = class_table[ch->class].base_hit_gain;

    ch->max_base_hit	+= (ch->pcdata->last_basegain = add_base);
    ch->base_hit		+= add_base;
    ch->max_stat_hit 	+= (ch->pcdata->last_statgain = add_hp);
    ch->max_mana		+= (ch->pcdata->last_managain = add_mana);
    ch->max_move		+= (ch->pcdata->last_movegain = add_move);
    ch->practice	+= (ch->pcdata->last_skillgain = add_prac);
	ch->stamina		+= (ch->pcdata->last_stamgain = add_stam);
	ch->max_stamina	+= add_stam;
    ch->train		+= (ch->pcdata->last_traingain = 3);

    ch->pcdata->perm_stat_hit	+= add_hp;
    ch->pcdata->perm_mana	+= add_mana;
    ch->pcdata->perm_move	+= add_move;
    ch->pcdata->perm_base_hit	+= add_base;
	ch->pcdata->perm_stamina		+= add_stam;

    if ( ch->perm_stat[ class_table[ch->class].attr_prime ] < get_max_train(ch,class_table[ch->class].attr_prime) )
	{
		ch->perm_stat[ class_table[ch->class].attr_prime ]++;
		ch->pcdata->last_primegain = 1;
	}
	else
	{
		ch->train += 1;
		ch->pcdata->last_traingain += 1;
	}

	if ( ch->level % 2 == 0 )
	{
		if ( ch->perm_stat[ class_table[ch->class].attr_second ] < get_max_train(ch,class_table[ch->class].attr_second) )  
		{
			ch->perm_stat[ class_table[ch->class].attr_second ]++;
			ch->pcdata->last_secondgain = 1;
		}
		else
		{
			ch->train += 1;
			ch->pcdata->last_traingain += 1;
		}
	}
	else
		ch->pcdata->last_secondgain = 0;

    if (!hide)
		do_lastlevel(ch,"");

	ch->pcdata->date_last_level = current_time;
	addEventToJournal( ch->pcdata->journal, "Attained level %d!", ch->level );
	return;
}

void do_lastlevel( Character *ch, char *arg )
{
		int len;
		char blanks[50];

		memset(blanks,' ',sizeof(blanks));

		len = cprintf(ch,"+-----------------------------+\n\r");
		len = cprintf(ch,"| Stat Hits:    %4d (%d)", 
			ch->pcdata->last_statgain, 
			max_stat_hit(ch) ); 	
		cprintf(ch,"%.*s|\n\r", 30-len, blanks );
		len = cprintf(ch,"| Base Hits:    %4d (%d)", 
			ch->pcdata->last_basegain,
			ch->max_base_hit ); 
		cprintf(ch,"%.*s|\n\r", 30-len, blanks );
		if( class_table[ch->class].fMana )
		{
			len = cprintf(ch,"| Mana Pool:    %4d (%d)", ch->pcdata->last_managain, max_mana(ch) );
			cprintf(ch,"%.*s|\n\r", 30-len, blanks );
		}
		len = cprintf(ch,"| Movement:     %4d (%d)", 
			ch->pcdata->last_movegain, 
			ch->max_move );
		cprintf(ch,"%.*s|\n\r", 30-len, blanks );
		len = cprintf(ch,"| Stamina:      %4d (%d)",
			ch->pcdata->last_stamgain,
			max_stamina(ch) );
		cprintf(ch,"%.*s|\n\r", 30-len, blanks );
		len = cprintf(ch,"|");
		cprintf(ch,"%.*s|\n\r", 30-len, blanks );
		len = cprintf(ch,"| %-12s: %4d (%d)",
					capitalize( statnames[ class_table[ch->class].attr_prime ]),
					1, get_curr_stat(ch,class_table[ch->class].attr_prime) );
  		cprintf(ch,"%.*s|\n\r", 30-len, blanks );
		if ( ch->pcdata->last_secondgain > 0 )
		{
       		len = cprintf(ch,"| %-12s: %4d (%d)",
                    capitalize( statnames[ class_table[ch->class].attr_second ]),
                    1, get_curr_stat(ch,class_table[ch->class].attr_second) );
			cprintf(ch,"%.*s|\n\r", 30-len, blanks );
		}
		len = cprintf(ch,"|");
		cprintf(ch,"%.*s|\n\r", 30-len, blanks );
		len = cprintf(ch,"| Trains:       %4d (%d)", 3, ch->train );
		cprintf(ch,"%.*s|\n\r", 30-len, blanks );
		len = cprintf(ch,"| Skill Points: %4d (%d)", ch->pcdata->last_skillgain, ch->practice );
 		cprintf(ch,"%.*s|\n\r", 30-len, blanks );
		len = cprintf(ch,"+-----------------------------+\n\r\n\r");

    return;
}   



void gain_exp( Character *tch, int gain, bool fSplit )
{
    char buf[MAX_STRING_LENGTH];
	Character *ch;

	if ( is_affected(tch,gsn_shapeshifting,AFF_SKILL))
		ch = tch->desc->original;
	else
		ch = tch;

    if ( IS_NPC(ch) )
		return;

	if ( ch->level >= 20 && ch->pcdata->split >= 1 && fSplit )
    {
		long	exp_gain, spec_gain;

		spec_gain = (gain * ch->pcdata->split / 100);
		exp_gain = gain - spec_gain;
		cprintf(ch,"Gain: %d  Spec: %d  Exp: %d\n\r",gain,spec_gain,exp_gain);
		ch->pcdata->spec_exp += spec_gain;
		ch->exp += exp_gain;
	}
	else
    	ch->exp += gain;

    ch->exp = UMAX(ch->exp,0);
    while ( ch->level < LEVEL_HERO && ch->exp >= exp_to_level[ch->level].tnl )
    {
		ch->exp -= exp_to_level[ch->level].tnl;
		ch->level++;
		cprintf(ch," *** &WYou have reached level %d!&x ***\n\r", ch->level );
		sprintf(buf,"%s gained level %d",ch->name,ch->level);
		log_string(buf);
		sprintf(buf,"$N has attained level %d!",ch->level);

		/* Show different message if the player was loaded in for a reward */
		if(ch->desc && ch->desc->connected != CON_GET_REWARD)
		{
			wiznet(buf,ch,NULL,WIZ_LEVELS,0,0);
			pnet(buf,ch,NULL,WIZ_LEVELS,0,get_trust(ch));
		}
		else
		{
		    sprintf(buf,"$N has attained level %d! (while offline from reward)",ch->level);
			wiznet(buf,ch,NULL,WIZ_LEVELS,0,0);
		}

		advance_level(ch,FALSE);
		save_char_obj(ch);
    }

    if ( ch->pcdata->spec_exp > exp_to_level[ch->pcdata->spec_level].tnl )
	{
		cprintf(ch,"&WYou have gained a specialization point!&x.\n\r");
		ch->pcdata->spec_exp -= exp_to_level[ch->pcdata->spec_level].tnl;
		ch->pcdata->spec_level = UMIN(ch->pcdata->spec_level+1,50);
		ch->pcdata->spec_points++;
    }
    return;
}

void gain_condition( Character *ch, int iCond, int value, bool show_status )
{
    int condition;

    if ( value == 0 || IS_NPC(ch) || ch->level >= LEVEL_IMMORTAL 
		|| ch->shapeshifted != NULL || is_affected(ch,gsn_shapeshifting,AFF_SKILL) )
		return;

	if ( !str_cmp( "monk", class_table[ch->class].name ) && get_skill(ch,gsn_spirit) )
		return;

    condition				= ch->pcdata->condition[iCond];
    if (condition == -1)
        return;

    ch->pcdata->condition[iCond]	= URANGE( 0, condition + value, 48 );

    if ( show_status && ch->pcdata->condition[iCond] == 0 && IS_SET(ch->display,DISP_SHOW_HUNGER) )
    {
		switch ( iCond )
		{
		case COND_HUNGER:
	    	send_to_char( "You are hungry.\n\r",  ch );
	    	break;
	
		case COND_THIRST:
	    	send_to_char( "You are thirsty.\n\r", ch );
	    	break;
	
		case COND_DRUNK:
	    	if ( condition != 0 )
			send_to_char( "You are sober.\n\r", ch );
	    	break;
		}
    }

    return;
}



/*
 * Mob autonomous action.
 * This function takes 25% to 35% of ALL Merc cpu time.
 * -- Furey
 */
void mobile_update( void )
{
    Character *ch;
    Character *ch_next;
    Exit *pexit;
    int door;

    /* Examine all mobs. */
/*printf("start mob up\n");*/
    for ( ch = char_list; ch != NULL; ch = ch_next )
    {
		ch_next = ch->next;

		if ( !IS_NPC(ch) || ch->in_room == NULL || IS_AFFECTED(ch,AFF_CHARM))
	    	continue;

		if (ch->in_room->area->empty && !IS_SET(ch->act,ACT_UPDATE_ALWAYS))
	    	continue;

		/* Examine call for special procedure */
		if ( ch->spec_fun != 0 && ch->daze <= 0 )
		{
	    	if ( (*ch->spec_fun) ( ch ) )
				continue;
		}

		if (ch->pIndexData->pShop != NULL) /* give him some gold */
				ch->coins[CUR_ALATINUM] = 1;

		/* That's all for sleeping / busy monster, and empty zones */
		if ( ch->position != POS_STANDING )
	    	continue;

		/* Scavenge */
		if ( IS_SET(ch->act, ACT_SCAVENGER)
		&&   ch->in_room->contents != NULL
		&&   number_bits( 6 ) == 0 )
		{
	    	Object *obj;
	    	Object *obj_best;
	    	int max;
	
	    	max         = 1;
	    	obj_best    = 0;
	    	for ( obj = ch->in_room->contents; obj; obj = obj->next_content )
	    	{
				if ( CAN_WEAR(obj, ITEM_TAKE) && can_loot(ch, obj)
		     		&& obj->cost > max  && obj->cost > 0)
				{
		    		obj_best    = obj;
		    		max         = obj->cost;
				}
	    	}
	
	    	if ( obj_best )
	    	{
				Character *vch;
				bool fGrab = TRUE;
				for( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
					if ( vch->on == obj_best )
					{
						fGrab = FALSE;
						break;
					}

				if ( fGrab )
				{	
					obj_from_room( obj_best );
					obj_to_char( obj_best, ch );
					act( "$n gets $p.", ch, obj_best, NULL, TO_ROOM );
				}
	    	}
		}
	
		/* Wander */
		if ( !IS_SET(ch->act, ACT_SENTINEL) 
		&& number_bits(3) == 0
		&& ( door = number_bits( 5 ) ) <= 5
		&& ( pexit = ch->in_room->exit[door] ) != NULL
		&&   pexit->u1.to_room != NULL
		&&   !IS_SET(pexit->exit_info, EX_CLOSED)
		&&   !IS_SET(pexit->u1.to_room->room_flags, ROOM_NO_MOB)
		&& ( !IS_SET(ch->act, ACT_STAY_AREA)
		||   pexit->u1.to_room->area == ch->in_room->area ) 
		&& ( !IS_SET(ch->act, ACT_OUTDOORS)
		||   !IS_SET(pexit->u1.to_room->room_flags,ROOM_INDOORS)) 
		&& ( !IS_SET(ch->act, ACT_INDOORS)
		||   IS_SET(pexit->u1.to_room->room_flags,ROOM_INDOORS)))
		{
	    	move_char( ch, door, FALSE );
		}
   	}
	/*printf("end mob up\n");*/

    return;
}



/*
 * Update the weather.
 */
void weather_update( void )
{
    char buf[MAX_STRING_LENGTH];
    Descriptor *d;
    int diff;

    buf[0] = '\0';

	if ( ++time_info.quarterhour > 3 )
	{
		time_info.quarterhour = 0;
		++time_info.hour;
    
		switch ( time_info.hour )
    	{
    	case  5:
		weather_info.sunlight = SUN_LIGHT;
		strcat( buf, "The day has begun.\n\r" );
		break;
	
    	case  6:
		weather_info.sunlight = SUN_RISE;
		strcat( buf, "The sun rises in the east.\n\r" );
		break;
	
    	case 19:
		weather_info.sunlight = SUN_SET;
		strcat( buf, "The sun slowly disappears in the west.\n\r" );
		break;
	
    	case 20:
		weather_info.sunlight = SUN_DARK;
		strcat( buf, "The night has begun.\n\r" );
		break;
	
    	case 24:
		time_info.hour = 0;
		time_info.day++;
		break;
    	}
	}

    if ( time_info.day   >= days_per_month[time_info.month] )
    {
	time_info.day = 0;
	time_info.month++;
    }

    if ( time_info.month >= 11 )
    {
	time_info.month = 0;
	time_info.year++;
    }

    /*
     * Weather change.
     */
    if ( time_info.month >= 9 && time_info.month <= 16 )
	diff = weather_info.mmhg >  985 ? -2 : 2;
    else
	diff = weather_info.mmhg > 1015 ? -2 : 2;

    weather_info.change   += diff * dice(1, 4) + dice(2, 6) - dice(2, 6);
    weather_info.change    = UMAX(weather_info.change, -12);
    weather_info.change    = UMIN(weather_info.change,  12);

    weather_info.mmhg += weather_info.change;
    weather_info.mmhg  = UMAX(weather_info.mmhg,  960);
    weather_info.mmhg  = UMIN(weather_info.mmhg, 1040);

    switch ( weather_info.sky )
    {
    default: 
	log_bug( "Weather_update: bad sky %d.", weather_info.sky );
	weather_info.sky = SKY_CLOUDLESS;
	break;

    case SKY_CLOUDLESS:
	if ( weather_info.mmhg <  990
	|| ( weather_info.mmhg < 1010 && number_bits( 2 ) == 0 ) )
	{
	    strcat( buf, "The sky is getting cloudy.\n\r" );
	    weather_info.sky = SKY_CLOUDY;
	}
	break;

    case SKY_CLOUDY:
	if ( weather_info.mmhg <  970
	|| ( weather_info.mmhg <  990 && number_bits( 2 ) == 0 ) )
	{
	    strcat( buf, "It starts to rain.\n\r" );
	    weather_info.sky = SKY_RAINING;
	}

	if ( weather_info.mmhg > 1030 && number_bits( 2 ) == 0 )
	{
	    strcat( buf, "The clouds disappear.\n\r" );
	    weather_info.sky = SKY_CLOUDLESS;
	}
	break;

    case SKY_RAINING:
	if ( weather_info.mmhg <  970 && number_bits( 2 ) == 0 )
	{
	    strcat( buf, "Lightning flashes in the sky.\n\r" );
	    weather_info.sky = SKY_LIGHTNING;
	}

	if ( weather_info.mmhg > 1030
	|| ( weather_info.mmhg > 1010 && number_bits( 2 ) == 0 ) )
	{
	    strcat( buf, "The rain stopped.\n\r" );
	    weather_info.sky = SKY_CLOUDY;
	}
	break;

    case SKY_LIGHTNING:
	if ( weather_info.mmhg > 1010
	|| ( weather_info.mmhg >  990 && number_bits( 2 ) == 0 ) )
	{
	    strcat( buf, "The lightning has stopped.\n\r" );
	    weather_info.sky = SKY_RAINING;
	    break;
	}
	break;
    }

    if ( buf[0] != '\0' )
    {
	for ( d = descriptor_list; d != NULL; d = d->next )
	{
	    if ( d->connected == CON_PLAYING
	    &&   IS_OUTSIDE(d->character)
	    &&   IS_AWAKE(d->character) )
		send_to_char( buf, d->character );
	}
    }

    return;
}



/*
 * Update all chars, including mobs.
*/
void char_update( void )
{   
    Character *ch;
    Character *ch_next;
    Character *ch_quit;

    ch_quit	= NULL;

    /* update save counter */
    save_number++;

    if (save_number > 29)
	save_number = 0;

    for ( ch = char_list; ch != NULL; ch = ch_next )
    {
		ch_next = ch->next;

		if ( IS_NPC(ch) && ch->pIndexData->vnum == MOB_VNUM_SHADOWBEAST && ch->fighting == NULL )
		{
			act("$n vanishes into the shadows with a hiss.",ch,NULL,NULL,TO_ROOM);
			extract_char( ch, TRUE );
			continue;
		}

        if ( ch->timer > 30 && ch->shapeshifted == NULL )
            ch_quit = ch;

		if ( ch->position >= POS_STUNNED )
		{
            /* check to see if we need to go home */
            if (IS_NPC(ch) && ch->zone != NULL && ch->zone != ch->in_room->area
            && ch->desc == NULL &&  ch->fighting == NULL 
	    && !IS_AFFECTED(ch,AFF_CHARM) && number_percent() < 5)
            {
            	act("$n wanders on home.",ch,NULL,NULL,TO_ROOM);
            	extract_char(ch,TRUE);
            	continue;
            }

	}

	if ( ch->position == POS_STUNNED )
	    update_pos( ch );

	if ( !IS_NPC(ch) && ch->level < LEVEL_IMMORTAL )
	{
	    Object *obj;
		int condition, drunk_cond;

	    if ( ( obj = get_eq_char( ch, WEAR_LIGHT ) ) != NULL
	    &&   obj->item_type == ITEM_LIGHT
	    &&   obj->value[2] > 0 )
	    {
		if ( --obj->value[2] == 0 && ch->in_room != NULL )
		{
		    --ch->in_room->light;
		    act( "$p goes out.", ch, obj, NULL, TO_ROOM );
		    act( "$p flickers and goes out.", ch, obj, NULL, TO_CHAR );
		    extract_obj( obj );
		}
	 	else if ( obj->value[2] <= 5 && ch->in_room != NULL)
		    act("$p flickers.",ch,obj,NULL,TO_CHAR);
	    }

		/* Remove this so IMMs autologout too */
	    if ( ch->level >= 59 )
			ch->timer = 0;

	    if ( ++ch->timer >= 20 )
	    {
			if ( ch->was_in_room == NULL && ch->in_room != NULL )
			{
		    	ch->was_in_room = ch->in_room;
		    	if ( ch->fighting != NULL )
					stop_fighting( ch, TRUE );
		    	act( "$n disappears into the void.", ch, NULL, NULL, TO_ROOM );
		    	send_to_char( "You disappear into the void.\n\r", ch );
		    	if (ch->level > 1)
		        	save_char_obj( ch );
		    	char_from_room( ch );
		    	char_to_room( ch, get_room_index( ROOM_VNUM_LIMBO ) );
			}
	    }

		drunk_cond = ch->pcdata->condition[COND_DRUNK];
	    gain_condition( ch, COND_DRUNK,  -1, FALSE );
	    gain_condition( ch, COND_FULL, ch->size > SIZE_MEDIUM ? -4 : -2, FALSE );
	    gain_condition( ch, COND_THIRST, -1, FALSE );
	    gain_condition( ch, COND_HUNGER, ch->size > SIZE_MEDIUM ? -2 : -1, FALSE);

		if ( ch->pcdata->condition[COND_HUNGER] == 0 && HAS_AUTOOPT(ch,AUTO_EAT) 
				&& IS_AWAKE( ch ) )
			do_autoeat( ch );
		if ( ch->pcdata->condition[COND_THIRST] == 0 && HAS_AUTOOPT(ch,AUTO_DRINK) 
				&& IS_AWAKE( ch ) )
			do_autodrink( ch );

		for (condition = COND_DRUNK; condition <= COND_HUNGER; condition++)
		{
    		if ( ch->pcdata->condition[condition] == 0 && IS_SET(ch->display,DISP_SHOW_HUNGER) )
    		{
				switch ( condition )
				{
				case COND_HUNGER:
	    			send_to_char( "You are hungry.\n\r",  ch );
		    		break;
	
				case COND_THIRST:
	    			send_to_char( "You are thirsty.\n\r", ch );
	    			break;
	
				case COND_DRUNK:
	    			if ( drunk_cond != 0 )
						send_to_char( "You are sober.\n\r", ch );
	    		break;
				}
    		}
		}
	}

	if ( IS_SET(ch->display,DISP_CARRIAGE_RETURN) && ch->fighting == NULL && 
			( ch->desc == NULL || (ch->desc != NULL && ch->desc->pString == NULL)) )
	    cprintf(ch,"\n\r");

		if ( ch->position == POS_INCAP && number_range(0,1) == 0)
	    	damage( ch, ch, 1, TYPE_UNDEFINED, DAM_NONE,0);
		else if ( ch->position == POS_MORTAL )
	    	damage( ch, ch, 1, TYPE_UNDEFINED, DAM_NONE,0);
    }

    /*
     * Autosave and autoquit.
     * Check that these chars still exist.
     */
    for ( ch = char_list; ch != NULL; ch = ch_next )
    {
        ch_next = ch->next;

	if (ch->desc != NULL && ch->desc->descriptor % 30 == save_number &&
		ch->fighting == NULL )
	{
	    if ( IS_SET(ch->display,DISP_SHOW_AUTOSAVES) && !IS_NPC(ch) )
	    	cprintf(ch,"\n\r - - &W%s saved&x - -\n\r\n\r",ch->name);
	    save_char_obj(ch);
	}

        if (ch == ch_quit)
	{
            do_function(ch, &do_quit, "" );
	}
    }

    return;
}




/*
 * Update all objs.
 * This function is performance sensitive.
 */
void obj_update( void )
{   
    Object *obj;
    Object *obj_next;
    Affect *paf, *paf_next;

    for ( obj = object_list; obj != NULL; obj = obj_next )
    {
	Character *rch;
	char *message;

	obj_next = obj->next;

	/* go through affects and decrement */
        for ( paf = obj->affected; paf != NULL; paf = paf_next )
        {
            paf_next    = paf->next;

			if ( paf->duration == DUR_PERMANENT )
				continue;

            if ( paf->duration > 0 )
            {
                /*paf->duration--;*/
                if (number_range(0,4) == 0 && paf->level > 0)
                  paf->level--;  /* spell strength fades with time */
            }
            else if ( paf->duration < 0 )
                ;

			if( current_time > paf->duration )
            {
                if ( paf_next == NULL
                ||   paf_next->type != paf->type
                ||   paf_next->duration > 0 )
                {
                    if ( paf->type > 0 && skill_table[paf->type].msg_obj )
                    {
						if (obj->carried_by != NULL)
						{
			    			rch = obj->carried_by;
                            if ( paf->type >= 0 )
                            {
			    			    if( IS_SET(paf->flags,AFF_SKILL) )
			    			        act( skill_table[paf->type].msg_obj,rch,obj,NULL,TO_CHAR);
                                else
                                if ( IS_SET(paf->flags,AFF_SPELL) )
                                {
                                    SpellIndex *sp = get_spell_index( paf->type );
                                    if ( sp != NULL )
                                        act( sp->msg_obj, rch, obj, NULL, TO_CHAR );
                                }
                            }
						}
        
						if (obj->in_room != NULL && obj->in_room->people != NULL)
						{
			    			rch = obj->in_room->people;
                            if ( paf->type >= 0 )
                            {
                                if( IS_SET(paf->flags,AFF_SKILL) )
                                    act( skill_table[paf->type].msg_obj,rch,obj,NULL,TO_ALL);
                                else
                                if ( IS_SET(paf->flags,AFF_SPELL) )
                                {
                                    SpellIndex *sp = get_spell_index( paf->type );
                                    if ( sp != NULL )
                                        act( sp->msg_obj, rch, obj, NULL, TO_ALL );
                                }
                            }
						}
                    } /* wear-off message for objects */
                } /* affect can expire */

                affect_remove_obj( obj, paf );
            } /* wear-off */
        }


	if ( obj->timer <= 0 || --obj->timer > 0 )
	    continue;

	switch ( obj->item_type )
	{
	default:              message = "$p crumbles into dust.";  break;
	case ITEM_FOUNTAIN:   message = "$p dries up.";         break;
	case ITEM_CORPSE_NPC: message = "$p decays into dust."; break;
	case ITEM_CORPSE_PC:  message = "$p decays into dust."; break;
	case ITEM_FOOD:       message = "$p decomposes.";	break;
	case ITEM_POTION:     message = "$p has evaporated from disuse.";	
								break;
	case ITEM_PORTAL:     message = "$p fades out of existence."; break;
	case ITEM_CONTAINER: 
	    if (CAN_WEAR(obj,ITEM_WEAR_FLOAT))
		if (obj->contains)
		    message = 
		"$p flickers and vanishes, spilling its contents on the floor.";
		else
		    message = "$p flickers and vanishes.";
	    else
		message = "$p crumbles into dust.";
	    break;
	}

	if ( obj->carried_by != NULL )
	{
	    if (IS_NPC(obj->carried_by) 
	    &&  obj->carried_by->pIndexData->pShop != NULL)
			obj->carried_by->coins[CUR_SILVER] += obj->cost/5;
	    else
	    {
	    	act( message, obj->carried_by, obj, NULL, TO_CHAR );
			if ( obj->wear_loc == WEAR_FLOAT)
		    	act(message,obj->carried_by,obj,NULL,TO_ROOM);
	    }
	}
	else if ( obj->in_room != NULL
	&&      ( rch = obj->in_room->people ) != NULL )
	{
	    if (! (obj->in_obj && obj->in_obj->pIndexData->vnum == OBJ_VNUM_PIT
	           && !CAN_WEAR(obj->in_obj,ITEM_TAKE)))
	    {
	    	act( message, rch, obj, NULL, TO_ROOM );
	    	act( message, rch, obj, NULL, TO_CHAR );
	    }
	}

        if ((obj->item_type == ITEM_CORPSE_PC || obj->wear_loc == WEAR_FLOAT)
	&&  obj->contains)
	{   /* save the contents */
     	    Object *t_obj, *next_obj;

	    for (t_obj = obj->contains; t_obj != NULL; t_obj = next_obj)
	    {
		next_obj = t_obj->next_content;
		obj_from_obj(t_obj);

		if (obj->in_obj) /* in another object */
		    obj_to_obj(t_obj,obj->in_obj);

		else if (obj->carried_by)  /* carried */
		    if (obj->wear_loc == WEAR_FLOAT)
			if (obj->carried_by->in_room == NULL)
			    extract_obj(t_obj);
			else
			    obj_to_room(t_obj,obj->carried_by->in_room);
		    else
		    	obj_to_char(t_obj,obj->carried_by);

		else if (obj->in_room == NULL)  /* destroy it */
		    extract_obj(t_obj);

		else /* to a room */
		    obj_to_room(t_obj,obj->in_room);
	    }
	}

	extract_obj( obj );
    }

    return;
}

/*
 * Chase Rules.  If the NPC has a higher % of hp left and are even level,
 * they'll chase.  If the NPC is higher level, they'll chase even if they're
 * down by 5% per level.  If the NPC is UNDERpowered, they'll only chase if
 * they have a 5% advantage per level.
 */
bool willFollow( Character *npc, Character *pc )
{
	int		npc_percent, pc_percent;
	int		diff;

	/* TEMPORARY DISABLE */
	return FALSE;

	npc_percent = npc->stat_hit * 100 / max_stat_hit( npc );
	pc_percent  = pc->stat_hit * 100 / max_stat_hit( pc );

	/* 'diff' has to be positive for the NPC to chase */
	diff = npc_percent - pc_percent;

	/* Now apply level difference * 5 */
	/* example:  npc level 23, player level 19 = 4 * 5 = +20
	 * So, if the NPC has 42% and the player has 55% aand the
 	 * player flees, the difference works out to -13 above.
	 * But here the NPC gets +20 due to the level difference.
	*/
	diff += ( ( npc->level - pc->level ) * 5 );

	if( diff > 0 )
		return TRUE;
	else
		return FALSE;
}

int checkForChasers( Character *ch )
{
	Character *npc, *npc_next;
	Room *r;
	Exit *e, *pback;
	int i;
    bool found = FALSE;;

	for( i=0 ; i<6; i++ )
	{
		/* Make sure there's a door, it goes somewhere, its destination has a door back,
		 * and it goes to the current room.  Also skip closed doors */
		if ( ( e = ch->in_room->exit[i] ) != NULL && ( r = e->u1.to_room ) != NULL &&
			(pback = r->exit[rev_dir[i]]) != NULL && pback->u1.to_room == ch->in_room 
			&& !IS_SET( e->exit_info, EX_CLOSED ) )
		{
			/* Scan this room for characters who are aggressive */
			for( npc = r->people ; npc != NULL ; npc = npc_next )
			{
				npc_next = npc->next_in_room;

				/* Skip PCs, NPCs who are in combat, wimpies, mezzed, or those with daze or wait states */
				if( !IS_NPC(npc) || npc->fighting != NULL || IS_SET(npc->act,ACT_WIMPY) 
                 || npc->daze > 0 || npc->wait > 0 || IS_AFFECTED(npc,AFF_MESMERIZE) )
					continue;

				/* Ok, if they're hostile, then move them to the same room */
	    		if ( get_melee_disposition(npc,ch) >= DISPOS_AGGRESSIVE && npc->pathing.index < MAX_STACK && willFollow(npc,ch) )
				{
					int save_room = npc->in_room->vnum;

					if ( move_char(npc, rev_dir[i], TRUE ) )
					{
						found = TRUE;
						npc->pathing.array[npc->pathing.index++] = save_room;
					}
				}
			} /* end npc loop */
		} /* valid exit */
	} /* door loop */

	return found;
}

/*
 * Aggress.
 *
 * for each mortal PC
 *     for each mob in room
 *         aggress on some random PC
 *
 * This function takes 25% to 35% of ALL Merc cpu time.
 * Unfortunately, checking on each PC move is too tricky,
 *   because we don't the mob to just attack the first PC
 *   who leads the party into the room.
 *
 * -- Furey
 */
void aggr_update( void )
{
    Character *wch;
    Character *wch_next;
    Character *ch;
    Character *ch_next;
    Character *vch;
    Character *vch_next;
    Character *victim;

	/* Loop across all PC's */
    for ( wch = char_list; wch != NULL; wch = wch_next )
    {
		wch_next = wch->next;

		if ( IS_NPC(wch) || IS_IMMORTAL(wch) 
			||   wch->in_room == NULL 
			||   wch->in_room->area->empty)
	    		continue;

		/* First, check for adjacent NPCs who are aggro, and move them here */
		if ( checkForChasers( wch ) )
			continue;

		/* Find NPCs in room */
		for ( ch = wch->in_room->people; ch != NULL; ch = ch_next )
		{
	    	int count;

	    	ch_next	= ch->next_in_room;

	    	if ( !IS_NPC(ch)
			||	!is_aggressive(ch,wch, FALSE)
	    	/*||   !IS_SET(ch->act, ACT_AGGRESSIVE)*/
	    	||   IS_SET(ch->in_room->room_flags,ROOM_SAFE)
	    	||   IS_AFFECTED(ch,AFF_CALM)
	    	||   ch->fighting != NULL
	    	||   IS_AFFECTED(ch, AFF_CHARM)
	    	||   !IS_AWAKE(ch)
	    	||   ( IS_SET(ch->act, ACT_WIMPY) && IS_AWAKE(wch) )
	    	||   !can_see( ch, wch ) 
	    	||   number_bits(1) == 0)
				continue;

	    /*
	     * Ok we have a 'wch' player character and a 'ch' npc aggressor.
	     * Now make the aggressor fight a RANDOM pc victim in the room,
	     *   giving each 'vch' an equal chance of selection.
		 * Ensure that the mob actually has a reason to hate the selected player
	     */
	    count	= 0;
	    victim	= NULL;
	    for ( vch = wch->in_room->people; vch != NULL; vch = vch_next )
	    {
		int diff = con_diff(vch->level,ch->level);
		vch_next = vch->next_in_room;

		if ( !IS_NPC(vch)
		&&   vch->level < LEVEL_IMMORTAL
		&&   diff < 2 /* mob is at least blue */
		&&   ( !IS_SET(ch->act, ACT_WIMPY) || !IS_AWAKE(vch) )
		&&   can_see( ch, vch ) 
		&&   (is_aggressive(ch, vch, TRUE) || IS_SET(ch->act,ACT_AGGRESSIVE)) )
		{//The last check is for if they do hate the player for a reason, or are just aggy
		    if ( number_range( 0, count ) == 0 )
			victim = vch;
		    count++;
		}
	    }

	    if ( victim == NULL )
		continue;

		/* Check for an attack message */
		if( ch->pIndexData->attack_echo != NULL )
			act(ch->pIndexData->attack_echo,ch,NULL,victim,TO_ROOM);

	    one_hit( ch, victim, TYPE_UNDEFINED );
		}
    }

    return;
}

void set_NPC_disposition( Character *v )
{
	v->next_dispos = char_disposition_list;
	char_disposition_list = v;
	return;
}

void clear_NPC_disposition( Character *v )
{
	Character *ch;

	if ( v == char_disposition_list )
		char_disposition_list = v->next_dispos;
	else
	{
		if(char_disposition_list)
		{//This better be initialized to NULL
			for( ch = char_disposition_list ; ch->next_dispos != NULL ; ch = ch->next_dispos )
				if( ch->next_dispos == v )
					break;

			if( ch->next_dispos != v )
			{
				log_bug("clear_NPC_disposition: v not in list",0);
				return;
			}
		ch->next_dispos = v->next_dispos;
		}
	}

	v->next_dispos = NULL;
	return;
}

/*  Remove 'md' from 'ch''s list. */
void melee_from_list( Melee *md, Character *ch )
{
    Melee *imd;

    if ( md == ch->melee_list )
		ch->melee_list = md->next;
    else
    {
        for ( imd = ch->melee_list ; imd->next != NULL ; imd = imd->next )
	    	if ( imd->next == md )
				break;

        if ( imd->next != md )
        {
	    	log_bug("melee_from_list: md not in list",0);
 	    	return;
        }
    
        imd->next = md->next;
    }

    free_melee( md );
}

void melee_update( void )
{
    Character *ch, *ch_next;
    Melee 	*md;
    Melee  *md_next;

    for ( ch = char_disposition_list ; ch != NULL ; ch = ch_next )
    {
		ch_next = ch->next_dispos;

		for ( md = ch->melee_list ; md != NULL ; md = md_next )
		{
	    	md_next = md->next;
	    	if ( --md->timer <= 0 ) /* Expires */
			{
				/* Downgrade disposition */
				if( --md->disposition <= DISPOS_PASSIVE )
	        		melee_from_list( md, ch );
				else
					md->timer = 60 * PULSE_PER_SECOND / PULSE_MELEE_UPDATE * 3;

				/* Mobs spend 3 minutes in each disposition.  The above math
				 * uses the truth of rational division A/B div C/D = A/B * D/C
				 */
			}
		}

		if( ch->melee_list == NULL )
			clear_NPC_disposition( ch );
    }
}

// Regens resource, adds it if there is none
void regenResource( Room *room, int type, int amount )
{
	Resource *r;

	if ( !str_cmp("None",flag_string( resource_flags, type )) )
		return;

	for( r = room->resources ; r != NULL ; r = r->next )
		if ( r->resource == type )
			break;

	if ( r == NULL )
	{
		r = new_resource( );
		r->resource = type;
		r->amount = 0;

		r->next = room->resources;
		room->resources = r;
	}

	r->amount += amount;
}

// Refresh natural resources
void updateResources( void )
{
	int i;
	Room *r;

	for( i=0; i < top_vnum_room; i++ )
	{
		if ( (r=get_room_index(i)) == NULL )
			continue;
	
		switch ( r->sector_type )
		{
			case SECT_UNDERGROUND:
				regenResource( r, NR_ANTIMONY, dice(1,6) );
				regenResource( r, NR_ARSENIC, dice(1,6) );
				regenResource( r, NR_COPPER, dice(1,10) );
				regenResource( r, NR_TIN, dice(1,10) );
				regenResource( r, NR_IRON, dice(1,10) );
				regenResource( r, NR_COAL, dice(1,6) );
				break;
			case SECT_HILLS:
				regenResource( r, NR_STONE, number_range(0,1) );
				regenResource( r, NR_LIMESTONE, number_range(0,1) );
				regenResource( r, NR_IRON, number_range(0,1) );
				break;
			case SECT_MOUNTAIN:
				regenResource( r, NR_ANTIMONY, dice(1,3) );
                regenResource( r, NR_ARSENIC, dice(1,3) );
                regenResource( r, NR_COPPER, dice(1,6) );
                regenResource( r, NR_TIN, dice(1,46) );
                regenResource( r, NR_IRON, dice(1,6) );
				regenResource( r, NR_LIMESTONE, dice(1,6) );
				regenResource( r, NR_STONE, dice(1,6) );
				break;
			case SECT_FOREST:
				regenResource( r, NR_FOREST, dice(2,4) );
				break;
			default:
				break;
		}
	}
}

/*
 * Handle all kinds of updates.
 * Called once per pulse from game loop.
 * Random times to defeat tick-timing clients and players.
 */

void update_handler( void )
{
    static  int	    pulse_affect_update;
    static  int     pulse_area;
    static  int     pulse_mobile;
    static  int     pulse_violence;
    static  int     pulse_point;
    static  int	    pulse_regen;
    static  int	    pulse_melee;
	static	int		pulse_spawn;
	static	int		pulse_resource;
	static	int		bGoAhead;
	extern	void 	updateSpawn( void );

	if ( --pulse_resource <= 0 )
	{
		pulse_resource = PULSE_RESOURCE;
		if ( !bGoAhead )
			bGoAhead = TRUE;
		else
		{
			updateResources( );
			write_resource_file( );
		}
	}

	if ( --pulse_spawn <= 0 )
	{
		pulse_spawn = PULSE_SPAWN;
		updateSpawn( );
	}

    if ( --pulse_affect_update	<= 0 )
    {
	pulse_affect_update	= PULSE_AFFECT_UPDATE;
	affect_update( );
    }

    if ( --pulse_area     <= 0 )
    {
		pulse_area	= PULSE_AREA;
		/* number_range( PULSE_AREA / 2, 3 * PULSE_AREA / 2 ); */
		area_update	( );
		save_load( );
    }

    if ( --pulse_mobile   <= 0 )
    {
	pulse_mobile	= PULSE_MOBILE;
	mobile_update	( );
    }

    if ( --pulse_regen <=0 )
    {
	pulse_regen	= PULSE_REGEN;
	regen_update	( );
    }

    if ( --pulse_violence <= 0 )
    {
	pulse_violence	= PULSE_VIOLENCE;
	violence_update	( );
    }

    if ( --pulse_melee <= 0 )
    {
	pulse_melee = PULSE_MELEE_UPDATE;
	melee_update( );
    }

    if ( --pulse_point    <= 0 )
    {
	wiznet("TICK!",NULL,NULL,WIZ_TICKS,0,0);
	pulse_point     = PULSE_TICK;
/* number_range( PULSE_TICK / 2, 3 * PULSE_TICK / 2 ); */
	weather_update	( );
	char_update	( );
	obj_update	( );
    }

    aggr_update( );
    tail_chain( );
    return;
}


void affect_update( void )
{
    Affect *paf, *paf_next;
    Character *ch;
    extern void dot( Character *, Affect * );
	extern void pulse_spell( Character *, Affect * );

    for ( ch = char_list ; ch != NULL ; ch = ch->next )
    {
		int last_type = -1;

        for ( paf = ch->affected; paf != NULL; paf = paf_next )
        {
            paf_next        = paf->next;

			if ( paf->location == APPLY_BLADETURN || paf->duration == DUR_PERMANENT )
				continue;

			if ( IS_SET(paf->flags,AFF_PULSE))
				pulse_spell( ch, paf );

	    	if ( (paf->duration - current_time ) <= 6 &&
				 (paf->duration - current_time ) > 0 && paf->type != last_type )
			{
	       		SpellIndex* pSpellIndex = get_spell_index(paf->type);

				cprintf(ch,"The '%s' affect on you is about to wear off.\n\r",
					IS_SET(paf->flags,AFF_SPELL) ? (pSpellIndex ? pSpellIndex->name : "(null)") :
					   skill_table[paf->type].name);
				
				if ( IS_NPC(ch) && IS_SET(ch->act,ACT_PET) && ch->master != NULL )
				{
					actprintf(ch->master,NULL,ch,TO_CHAR,"The '%s' affect on your pet is about to wear off.",
					IS_SET(paf->flags,AFF_SPELL) ? (pSpellIndex ? pSpellIndex->name : "(null)") : 
						skill_table[paf->type].name);
				}
			}

	    	if ( paf->where == DAMAGE_OVER_TIME )
			{
				dot( ch, paf );
				// Check for a dead-un
				if ( ch->affected == NULL || ch->in_room == NULL )
					break;
			}

            paf->level = UMAX(0,paf->level - 1 );

			if( current_time >= paf->duration )
            {
				if ( paf->type != last_type )
                {
                    if ( paf->type > 0 && IS_SKILL(paf) && skill_table[paf->type].msg_off )
					{
                        cprintf(ch,"%s\n\r", skill_table[paf->type].msg_off );
						if ( IS_NPC(ch) && IS_SET(ch->act,ACT_PET) && ch->master != NULL )
							actprintf(ch->master,NULL,ch,TO_CHAR,
								"The '%s' affect on your pet wears off.", skill_table[paf->type].name );
					}
                    else
					{
						if ( paf->type > 0 && IS_SPELL(paf) )
						{
							SpellIndex* pSpellIndex = get_spell_index(paf->type);

							if(pSpellIndex && pSpellIndex->msg_off)
							{
								cprintf( ch, "%s\n\r",pSpellIndex->msg_off );
								if ( IS_NPC(ch) && IS_SET(ch->act,ACT_PET) && ch->master != NULL )
								{
									actprintf(ch->master,NULL,ch,TO_CHAR,
									"The '%s' affect on your pet wears off.", pSpellIndex->name );
								}
							}
						}
					}
            	} 
                affect_remove( ch, paf );
            }

            last_type = paf->type;
        }
    }
    return;
}

bool do_autoeat( Character *ch )
{
	Object *obj;

	for( obj = ch->carrying ; obj ; obj = obj->next_content )
	{
		/* Make sure its not poisoned */
		if (obj->item_type == ITEM_FOOD && obj->value[3] == 0)
		{
            if( HAS_DISPOPT(ch, DISP_AUTOEAT) )
			    eat_item( ch, obj, ECHO_ON );
            else
			    eat_item( ch, obj, ECHO_OFF );
			return TRUE;
		}
	}

	return FALSE;
}

bool do_autodrink( Character *ch )
{
	Object *obj;

	for( obj = ch->carrying ; obj ; obj = obj->next_content )
	{
		/* Make sure its not poisoned */
		if ( obj->item_type == ITEM_DRINK_CON && obj->value[3] == 0)
		{
            if( HAS_DISPOPT(ch, DISP_AUTOEAT) )
			    drink_item( ch, obj, ECHO_ON );
            else
			    drink_item( ch, obj, ECHO_OFF );
			return TRUE;
		}
	}

	return FALSE;
}


char *why_aggressive( Character *npc, Character *pc )
{
	if ( !IS_NPC(npc) || npc->position <= POS_SLEEPING )
        return NULL;

    // Mezzed NPCs are never aggressive
    if ( IS_AFFECTED(npc,AFF_MESMERIZE) )
        return NULL;

	/* Simplest case - no melee data, no factions */
    /* We don't use this aggro if the NPC is chasing somebody down */
	if ( npc->factions == NULL && npc->melee_list == NULL)
	{
		if( npc->pathing.index == 0 && npc->pursuit.index == 0 )
			return IS_SET(npc->act,ACT_AGGRESSIVE) ? "is naturally aggressive" : NULL;
		else
			return NULL;
	}

    /* Check melee data, melee data overrides factions.  That is, if
     * you have great faction but you've attacked them, they're going
	 * to fight back. */
    if ( get_melee_disposition(npc,pc) >= DISPOS_HOSTILE )
        return "remembers you from a previous conflict";
		
	/* Next check factions. */
	if ( npc->factions != NULL )
	{
		Faction *f, *fpc;

		/* See if any ally factions are aggressive 
		 * NPC factions are a smaller scan, use that for the outer join
		 * We check aggression first.  Alignment may later impact this.
         * An evil character may attack its enemies always, even if they're also friends.
         * Good characters may not.  Or this could be OLC-settable.
		 */
		for( f = npc->factions ; f != NULL ; f = f->next )
		{
			if ( f->standing != FACTION_MEMBER_OF )
				continue;
				
			if ( (fpc = findFaction(pc,f)) != NULL && fpc->counter <= f->aggroPoint )
				return "takes exception to your faction standing";
		}

		/* Now look for passive factions to cancel aggro flags.  That is, barring all else,
         * if something is aggressive but you've got great faction with its ally factions,
         * the aggression is ignored. */
        for( f = npc->factions ; f != NULL ; f = f->next )
        {
            if ( f->standing != FACTION_MEMBER_OF )
                continue;

			/* Check if the player has any faction with this ally, and if so, if it's any good */
            if ( (fpc = findFaction(pc,f)) != NULL && fpc->counter >= f->passivePoint )
                return NULL;
        }
	}

	/* Ok so there's no relevent factions and no relevent melee dispositions.
	 * Just return the NPC's aggro setting
	 */
    return IS_SET(npc->act,ACT_AGGRESSIVE) ? "is naturally aggressive" : NULL;
}

bool is_aggressive( Character *npc, Character *pc, bool fInfo )
{
    /*fInfo will return why the character was attacked: if fInfo is TRUE
	 TRUE means it was a faction or memory
	FALSE means it's nothing special, just because the mob is aggy
	If it is false, it returns just whether the mob will attack or not
	fInfo only changes the basic aggy checks to false, the others remain TRUE, because if this function
	is called with fInfo true, it means the mob IS aggy*/

	if ( !IS_NPC(npc) || npc->position <= POS_SLEEPING )
		return FALSE;

    // Mezzed NPCs are never aggressive
    if ( IS_AFFECTED(npc,AFF_MESMERIZE) )
        return FALSE;

	/* Simplest case - no melee data, no factions */
    /* We don't use this aggro if the NPC is chasing somebody down */
	if ( npc->factions == NULL && npc->melee_list == NULL)
	{
		if(fInfo == FALSE && npc->pathing.index == 0 && npc->pursuit.index == 0 )
			return IS_SET(npc->act,ACT_AGGRESSIVE) ? TRUE : FALSE;
		else
			return FALSE;//fInfo TRUE, FALSE means the mob is aggy w/no melee or factions
	}

    /* Check melee data, melee data overrides factions.  That is, if
     * you have great faction but you've attacked them, they're going
	 * to fight back. */
    if ( get_melee_disposition(npc,pc) >= DISPOS_HOSTILE )
        return TRUE;
		
	/* Next check factions. */
	if ( npc->factions != NULL )
	{
		Faction *f, *fpc;

		/* See if any ally factions are aggressive 
		 * NPC factions are a smaller scan, use that for the outer join
		 * We check aggression first.  Alignment may later impact this.
         * An evil character may attack its enemies always, even if they're also friends.
         * Good characters may not.  Or this could be OLC-settable.
		 */
		for( f = npc->factions ; f != NULL ; f = f->next )
		{
			if ( f->standing != FACTION_MEMBER_OF )
				continue;
				
			if ( (fpc = findFaction(pc,f)) != NULL && fpc->counter <= f->aggroPoint )
				return TRUE;
		}

		/* Now look for passive factions to cancel aggro flags.  That is, barring all else,
         * if something is aggressive but you've got great faction with its ally factions,
         * the aggression is ignored. */
        for( f = npc->factions ; f != NULL ; f = f->next )
        {
            if ( f->standing != FACTION_MEMBER_OF )
                continue;

			/* Check if the player has any faction with this ally, and if so, if it's any good */
            if ( (fpc = findFaction(pc,f)) != NULL && fpc->counter >= f->passivePoint )
                return FALSE;
        }
	}

	/* Ok so there's no relevent factions and no relevent melee dispositions.
	 * Just return the NPC's aggro setting
	 */
	if(fInfo == FALSE)
		return IS_SET(npc->act,ACT_AGGRESSIVE) ? TRUE : FALSE;
	else
		return FALSE;
}

int get_melee_disposition( Character *npc, Character *ch )
{
	Melee *m;

    if( npc->melee_list != NULL )
    {
        for( m = npc->melee_list ; m != NULL ; m = m->next )
        {
            if( m->group == ch->pgroup )
				return m->disposition;
        }
    }

	return DISPOS_PASSIVE;
}

int get_max_melee_disposition( Character *ch )
{
	Melee *m;
	int top = DISPOS_PASSIVE;

	for( m = ch->melee_list ; m != NULL ; m = m->next )
		top = UMAX(top,m->disposition);

	return top;
}

int rewardExtraSkillPoints( Character *ch )
{
	int i;
	int total = 0;

	if ( ch->version >= 14 )
		return 0;

	for( i = 1 ; i < ch->level ; i++ )
		total += (exp_to_level[i].spm * i);

	switch( class_table[ch->class].group )
	{
	case MELEE:
	case STEALTH:	
		total /= 4; break;
	case DIVINE:
	case ARCANE: 
		total /= 3; break;
	default:
		total = 0; break;
	}

	return total;
}

/*
 * Only clear if the player is the only group member
 */
void clear_melee_disposition( Character *npc, Character *pc )
{
    Melee *m;

	if ( !IS_NPC(npc) )
		return;

    if( npc->melee_list != NULL )
    {
        for( m = npc->melee_list ; m != NULL ; m = m->next )
        {
            if( m->group == pc->pgroup )
			{
				int i;

	    		for ( i=0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
        			if ( m->group->members[i] != NULL && m->group->members[i] != pc )
						return;

				melee_from_list( m, npc );
				return;
			}
        }
    }
}

/*
 * Save loads
 */
void save_load( void )
{
	FILE *fp;

	if ( global_port != 4005 )
		return;

	fclose( fpReserve );
	if ( (fp = fopen( LOAD_FILE, "a")) == NULL )
	{
		fpReserve = fopen( NULL_FILE, "r" );
		log_bug("Unable to open %s",LOAD_FILE);
		return;
	}

	/* Write cvs */
	fprintf( fp, "%ld,%d\n", (long) current_time, count_characters( ) );
	fclose( fp );
	fpReserve = fopen( NULL_FILE, "r" );
	return;
}

/*
 * upgrade clan buildings
 */
void upgradeBarracks( Building *bld )
{
	Room *entrance, *mana, *hp, *both;
	Exit *pExit;

	if ( (entrance = get_room_index(bld->entrance_room)) == NULL )
	{
		log_bug("Unable to find entrance room for a barracks: %d",bld->entrance_room);
		return;
	}

	// Find regen rooms
	if ( (pExit = entrance->exit[DIR_EAST]) == NULL ||
		 (hp = pExit->u1.to_room) == NULL )
	{
		log_bug("Unable to find hp regen room in barracks %d",entrance->vnum);
		return;
	}

	
	if ( (pExit = entrance->exit[DIR_SOUTH]) == NULL ||
		 (mana = pExit->u1.to_room) == NULL )
	{
		log_bug("Unable to find mana regen room in barracks %d",entrance->vnum);
		return;
	}

	// Find common room
    if ( (pExit = mana->exit[DIR_EAST]) == NULL ||
         (both = pExit->u1.to_room) == NULL )
    {
        log_bug("Unable to find combo regen room in barracks %d",entrance->vnum);
        return;
    }

	// Update regen levels
	hp->heal_rate =   ( 125 + (bld->level*3) );
	mana->mana_rate = ( 125 + (bld->level*3) );
	both->heal_rate = ( 110 + (bld->level*2) );
	both->mana_rate = ( 110 + (bld->level*2) );
	return;
}

void upgradeBuilding( Building *bld )
{
	bld->level++;

	switch( bld->type )
	{
		case BUILDING_BARRACKS:
			upgradeBarracks(bld); break;
		//case BUILDING_SMITHY:
			//upgradeSmithy(bld); break;
		default:
			log_bug("bad building type %d",bld->type); break;
	}
	
	return;
}
