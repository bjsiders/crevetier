/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized
 for one specific implementation, and it is not generic nor compatible with
 standard ROM area files.  It also uses Boehm's garbage collector (not
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "thoc.h"
#include "olc.h"
#include "tables.h"
#include "lookup.h"
#include "recycle.h"
#include "db.h"

LEDIT( ledit_okroomecho )
{ 
    SpellIndex  *spell;

    EDIT_SPELL(ch, spell);

    if ( spell->spell_type != SPELL_BUFF &&
         spell->spell_type != SPELL_DEBUFF &&
         spell->spell_type != SPELL_COMBO_NUKE )
    {
        cprintf(ch,"Only buffs, debuffs, and combo nukes have room echos.\n\r");
        return FALSE;
    }

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Syntax:  okroomecho [string]\n\r");
        return FALSE;
    }

    free_string( spell->action.generic.okRoomEcho );
    spell->action.generic.okRoomEcho = str_dup( argument );

    cprintf(ch,"Room echo on a successful cast set to \"%s\".\n\r", spell->action.generic.okRoomEcho );
    return TRUE; 
}

LEDIT( ledit_okvictimecho )
{ 
    SpellIndex  *spell;

    EDIT_SPELL(ch, spell);

    if ( spell->spell_type != SPELL_BUFF &&
         spell->spell_type != SPELL_DEBUFF &&
         spell->spell_type != SPELL_COMBO_NUKE )
    {
        cprintf(ch,"Only buffs, debuffs, and combo nukes have room echos.\n\r");
        return FALSE;
    }

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Syntax:  okvictimecho [string]\n\r");
        return FALSE;
    }

    free_string( spell->action.generic.okVictimEcho );
    spell->action.generic.okVictimEcho = str_dup( argument );

    cprintf(ch,"Victim echo on a successful cast set to \"%s\".\n\r", spell->action.generic.okVictimEcho );
    return TRUE; 
}

LEDIT( ledit_failroomecho )
{ 
    SpellIndex  *spell;

    EDIT_SPELL(ch, spell);

    if ( spell->spell_type != SPELL_DEBUFF )
    {
        cprintf(ch,"Only debuffs have room echos on a saving throw.\n\r");
        return FALSE;
    }

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Syntax:  failroomecho [string]\n\r");
        return FALSE;
    }

    free_string( spell->action.generic.failRoomEcho );
    spell->action.generic.failRoomEcho = str_dup( argument );

    cprintf(ch,"Room echo when the victim saves set to \"%s\".\n\r", spell->action.generic.failRoomEcho );
    return TRUE; 
}

LEDIT( ledit_failvictimecho )
{ 
    SpellIndex  *spell;

    EDIT_SPELL(ch, spell);

    if ( spell->spell_type != SPELL_DEBUFF )
    {
        cprintf(ch,"Only debuffs have room echos on a saving throw.\n\r");
        return FALSE;
    }

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Syntax:  failvictimecho [string]\n\r");
        return FALSE;
    }

    free_string( spell->action.generic.failVictimEcho );
    spell->action.generic.failVictimEcho = str_dup( argument );

    cprintf(ch,"Victim echo when the victim saves set to \"%s\".\n\r", spell->action.generic.failVictimEcho );
    return TRUE; 
}

LEDIT (ledit_sourcefile)
{ 
    SpellIndex  *spell;

    EDIT_SPELL(ch, spell);

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Syntax:  sourcefile [string]\n\r");
        return FALSE;
    }

    free_string( spell->filename );
    spell->filename = str_dup( argument );

    cprintf(ch,"Source filename set to \"%s\".\n\r", spell->filename );
    return TRUE; 
}

LEDIT (ledit_name )
{ 
    SpellIndex  *spell;

    EDIT_SPELL(ch, spell);

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Syntax:  name [string]\n\r");
        return FALSE;
    }

    free_string( spell->name );
    spell->name = str_dup( argument );

    cprintf(ch,"Spell name set to \"%s\".\n\r", spell->name );
    return TRUE; 
}

LEDIT (ledit_fullname )
{ 
    SpellIndex  *spell;

    EDIT_SPELL(ch, spell);

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Syntax:  fullname [string]\n\r");
        return FALSE;
    }

    free_string( spell->full_name );
    spell->full_name = str_dup( argument );

    cprintf(ch,"Spell full name set to \"%s\".\n\r", spell->name );
    return TRUE;
}

LEDIT (ledit_mana )
{ 
    SpellIndex  *spell;
    int amt;

    EDIT_SPELL(ch, spell);

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Syntax:  mana [amount]\n\r");
        return FALSE;
    }

    amt = atoi(argument);
    if ( amt < 0 )
    {
        cprintf(ch,"Mana cost must be at least 0.\n\r");
        return FALSE;
    }

    spell->base_mana = amt;
    cprintf(ch,"Mana cost set to %d.\n\r", spell->base_mana );
    return TRUE; 
}

LEDIT ( ledit_affects )
{ 
    SpellIndex *spell;
    int slot;
    int mod, loc, where, dur, misc;
    long flags, bitvector;
    char arg1[MAX_STRING_LENGTH];
    char arg2[MAX_STRING_LENGTH];
    const void *flag_table = NULL;

    EDIT_SPELL(ch,spell);

    if ( spell->spell_type != SPELL_BUFF &&
         spell->spell_type != SPELL_DEBUFF &&
         spell->spell_type != SPELL_COMBO_NUKE )
    {
        cprintf(ch,"Only buffs, debuffs, and combo spells have affects.\n\r");
        return FALSE;
    }

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );

    if ( arg1[0] == '\0' || arg2[0] == '\0' )
    {    
        cprintf(ch,"Syntax:  aff <slot#> -w<where> -l<loc> -m<mod> -d<dur> -f'<flags>' -v<vec:flags> [-s<skill>]\n\r"
                   "         aff <slot#> clear  [reset all affect attributes to 0/undefined]\n\r"
                   "         To set the bitvector, vec can be one of: aff imm dam\n\r"
                   "         The flag is a valid affect flag, immunity flag, or damage type.\n\r"
                   "         To set blind, you'd type:  -vaff:blind\n\r");
        return FALSE;
    }

    slot = atoi( arg1 );
    if ( slot < 1 || slot > 5 )
    {
        cprintf(ch,"There are only 5 affect slots per spell.  Use slot 1-5.\n\r");
        return FALSE;
    }

    --slot;

    if ( !str_cmp( arg2, "clear" ) )
    {
        spell->action.generic.affects[slot].where     = 0;
        spell->action.generic.affects[slot].location  = 0;
        spell->action.generic.affects[slot].modifier  = 0;
        spell->action.generic.affects[slot].duration  = 0;
        spell->action.generic.affects[slot].misc      = 0;
        spell->action.generic.affects[slot].flags     = 0;
        spell->action.generic.affects[slot].bitvector = 0;

        cprintf(ch,"Slot %d reset and cleared out.\n\r", ++slot);
        return TRUE;
    }

    mod         = spell->action.generic.affects[slot].modifier;
    loc         = spell->action.generic.affects[slot].location;
    dur         = spell->action.generic.affects[slot].duration;
    where       = spell->action.generic.affects[slot].where;
    flags       = spell->action.generic.affects[slot].flags | AFF_SPELL | AFF_ABSOLUTE_TIME;
    bitvector   = spell->action.generic.affects[slot].bitvector;
    misc        = spell->action.generic.affects[slot].misc;
    
    // Now start parsing through input
    while( arg2[0] != '\0' )
    {
        if ( arg2[0] != '-' )
        {
            cprintf(ch,"Arguments to aff must be prefixed by a dash.\n\r");
            return FALSE;
        }

        switch( arg2[1] )
        {
            case 'w': case 'W':
                if ( (where = flag_value( aff_where_flags, arg2+2 )) == NO_FLAG )
                {
                    cprintf(ch,"%s is not a valid where location.\n\r", arg2+2 );
                    return FALSE;
                }
                break;

            case 'l': case 'L':
                if ( (loc = flag_value( apply_flags, arg2+2 )) == NO_FLAG )
                {
                    if ( !is_number(arg2+2) )
                    {
                        cprintf(ch,"%s is not a valid affect location.\n\r", arg2+2 );
                        return FALSE;
                    }
                    else
                        loc = atoi(arg2+2);
                }   
                break;

            case 'm': case 'M':
                mod = atoi(arg2+2); 
                break;

            case 'd': case 'D':
            {
                int mult;

                // 120s, 5m, etc
                if ( UPPER(arg2[strlen(arg2)-1]) != 'S' &&
                     UPPER(arg2[strlen(arg2)-1]) != 'M' )
                {
                    cprintf(ch,"Duration must be a follow followed by 'm' or 's' (minutes/seconds).\n\r"
                               "For example, 90s (90 seconds), 72m (72 minutes).\n\r");
                    return FALSE;
                }
                mult = UPPER(arg2[strlen(arg2)-1]) == 'M' ? 60 : 1;
                dur = atoi(arg2+2) * mult;
                break;
            }
         
            case 'f': case 'F':
            
                if ( flag_value( aff_flags, arg2+2 ) == NO_FLAG )
                {
                    cprintf(ch,"%s is not a valid affect flag.\n\r", arg2+2 );
                    return FALSE;
                }
                flags |= flag_value( aff_flags, arg2+2 );
                break;

            case 'v': case 'V':
                if ( !strncmp( arg2+2, "dam", 3 ) )
                    flag_table = dam_flags;
                else
                if ( !strncmp( arg2+2, "aff", 3 ) )
                    flag_table = affect_flags;
                else
                if ( !strncmp( arg2+2, "imm", 3 ) )
                    flag_table = imm_flags;
                else
                {
                    cprintf(ch,"You must specify dam, aff, or imm for your bitvector.\n\r");
                    return FALSE;
                }

                if ( flag_value( flag_table, arg2+6 ) == NO_FLAG )
                {
                    cprintf(ch,"No such flag: %s\n\r", arg2+6 );
                    return FALSE;
                }

                bitvector |= flag_value( flag_table, arg2+6 );
                break;

            case 's': case 'S':
                misc = skill_lookup( arg2+2 );
                break;

            default:
                cprintf(ch,"No such switch: %c.\n\r", arg2[1] );
                return FALSE;
        }

        argument = one_argument( argument, arg2 );
    }

    spell->action.generic.affects[slot].where       = where;
    spell->action.generic.affects[slot].location    = loc;
    spell->action.generic.affects[slot].modifier    = mod;
    spell->action.generic.affects[slot].duration    = dur;
    spell->action.generic.affects[slot].misc        = misc;
    spell->action.generic.affects[slot].flags       = flags;
    spell->action.generic.affects[slot].bitvector   = bitvector;

    cprintf(ch, "Affect #%d\n\r", slot+1 );
    cprintf(ch, "   af.where          = %s\n\r", 
        flag_string( aff_where_flags, spell->action.generic.affects[slot].where ) );
    cprintf(ch, "   af.location       = %s\n\r", 
        flag_string( apply_flags, spell->action.generic.affects[slot].location ) );
    cprintf(ch, "   af.modifier       = %+d\n\r", 
        spell->action.generic.affects[slot].modifier );
    cprintf(ch, "   af.duration       = %d %s\n\r",
        spell->action.generic.affects[slot].duration < 120 ? 
            spell->action.generic.affects[slot].duration : 
                spell->action.generic.affects[slot].duration / 60,
        spell->action.generic.affects[slot].duration  < 120 ? "seconds" : "minutes" );
    cprintf(ch, "   af.misc           = %s\n\r",
        loc == APPLY_SKILL ? skill_table[spell->action.generic.affects[slot].misc].name : "0" );
    cprintf(ch, "   af.flags          = %s\n\r",
        flag_string( aff_flags, spell->action.generic.affects[slot].flags) );
    cprintf(ch, "   af.bitvector       = %s\n\r",
        flag_table == NULL ? "0" : flag_string( flag_table, spell->action.generic.affects[slot].bitvector ) );

    return FALSE;
}

LEDIT (ledit_classlevel )
{ 
    SpellIndex  *spell;
    int class, level;
    char arg[MAX_INPUT_LENGTH];

    EDIT_SPELL(ch, spell);

    argument = one_argument( argument, arg );
    if ( arg[0] == '\0' || argument[0] == '\0' || !is_number(argument) || atoi(argument)<0)
    {
        cprintf(ch,"Syntax:  classlevel <class_name> <level>\n\r"
                   "Set spell level to 0 to disallow a class to cast it.\n\r");
        return FALSE; 
    }

    level = atoi(argument);
    class = class_lookup(arg);

    if ( class < 0 )
    {
        cprintf(ch,"No such class: %s\n\r", arg );
        return FALSE;
    }

    spell->class_level[class] = level;
    cprintf(ch,"%s is a level %d spell for the %s class.\n\r",
                spell->full_name,
                spell->class_level[class],
                class_table[class].name );
    return TRUE;
}

LEDIT( ledit_damage )
{ 
    SpellIndex *spell;
    int low, high;
    char arg[MAX_STRING_LENGTH];

    EDIT_SPELL( ch, spell );

    if ( spell->spell_type != SPELL_COMBO_NUKE &&
         spell->spell_type != SPELL_NUKE &&
         spell->spell_type != SPELL_BOLT )
    {
        cprintf(ch,"Only nukes, bolts, and combo spells have damage ranges.\n\r");
        return FALSE;
    }

    argument = one_argument( argument, arg );
    if ( argument[0] == '\0' || arg[0] == '\0' )
    {
        cprintf(ch,"Syntax:  damage <low> <high>\n\r");
        return FALSE;
    }

    low = atoi(arg);
    high = atoi(argument);

    spell->action.generic.lowDamage = low;
    spell->action.generic.highDamage = high;
    cprintf(ch,"Damage range set to: %d - %d\n\r", spell->action.generic.lowDamage, spell->action.generic.highDamage );
    return TRUE;
}

LEDIT( ledit_damtype )
{ 
    SpellIndex *spell;
    int type;

    EDIT_SPELL( ch, spell );

    if ( spell->spell_type != SPELL_COMBO_NUKE &&
         spell->spell_type != SPELL_NUKE &&
         spell->spell_type != SPELL_BOLT &&
         spell->spell_type != SPELL_DEBUFF )
    {
        cprintf(ch,"Only nukes, bolts, debuffs, and combo spells have damtypes.\n\r");
        return FALSE;
    }

    if ( argument[0] == '\0' )
    {
        cprintf(ch,"Syntax:  damtype <dam_flag>\n\r");
        return FALSE;
    }

    if ( (type = flag_value( dam_flags, argument )) == NO_FLAG )
    {
        cprintf(ch,"No such damage type.\n\r");
        return FALSE;
    }
   
    spell->action.generic.damType = type;
    cprintf(ch,"Damage type set to: %s\n\r", flag_string( dam_flags, spell->action.generic.damType ) ); 
    return TRUE;
}

LEDIT( ledit_savingthrow )
{ 
    SpellIndex *spell;
    int type;

    EDIT_SPELL( ch, spell );

    if ( spell->spell_type != SPELL_COMBO_NUKE &&
         spell->spell_type != SPELL_DEBUFF &&
         spell->spell_type != SPELL_NUKE &&
         spell->spell_type != SPELL_BOLT )
    {
        cprintf(ch,"Only debuffs, bolts, nukes, and combo spells have saving throws.\n\r");
        return FALSE;
    }

    if ( argument[0] == '\0' )
    {
        cprintf(ch,"Syntax:  savingthrow <fortitude|reflex|willpower>\n\r");
        return FALSE;
    }

    if ( (type = flag_value( savingthrow_flags, argument )) == NO_FLAG )
    {
        cprintf(ch,"No such saving throw type.\n\r");
        return FALSE;
    }
   
    spell->action.generic.saveType = type;
    cprintf(ch,"Saving throw set to: %s\n\r", flag_string( savingthrow_flags, spell->action.generic.saveType ) ); 
    return TRUE;
}

LEDIT( ledit_spelltype )
{ 
    SpellIndex *spell;
    int type;

    EDIT_SPELL( ch, spell );

    if ( argument[0] == '\0' )
    {
        cprintf(ch,"Syntax:  spelltype <spell_type>\n\r"
                   "         buff, debuff, nuke, combo\n\r");
        return FALSE;
    }

    if ( (type = flag_value( spell_type_flags, argument )) == NO_FLAG )
    {
        cprintf(ch,"No such spell type.\n\r");
        return FALSE;
    }
   
    spell->spell_type = type;
    cprintf(ch,"Spell type set to: %s\n\r", flag_string( spell_type_flags, spell->spell_type ) ); 
    return TRUE;
}

LEDIT (ledit_type )
{ 
    SpellIndex *spell;
    int type;

    EDIT_SPELL( ch, spell );

    if ( argument[0] == '\0' )
    {
        cprintf(ch,"Syntax:  type <target_type>\n\r"
                   "         ? target_type\n\r");
        return FALSE;
    }

    if ( (type = flag_value( spell_target_flags, argument )) == NO_FLAG )
    {
        cprintf(ch,"No such spell target type.\n\r");
        return FALSE;
    }
   
    spell->target = type;
    cprintf(ch,"Spell target type set to: %s\n\r", flag_string( spell_target_flags, spell->target ) ); 
    return TRUE;
}

LEDIT (ledit_school )
{ 
    SpellIndex *spell;
    int school;
    
    EDIT_SPELL(ch, spell);

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Syntax:  school [spell group]\n\r");
        return FALSE;
    }

    if ( (school = skill_lookup(argument)) < 1 )
    {
        cprintf(ch,"No such skill: %s\n\r", argument );
        return FALSE;
    }

    if ( !IS_SET(skill_table[school].flags,SKILL_SPELL_GROUP) )
    {
        cprintf(ch,"%s is not a spell group.\n\r", skill_table[school].name );
        return FALSE; 
    }

    spell->sgsn = skill_table[school].pgsn;
    cprintf(ch,"Spell group set to \"%s\".\n\r", skill_table[school].name );
    return TRUE;
}

LEDIT (ledit_range)
{ 
    SpellIndex  *spell;
    int amt;

    EDIT_SPELL(ch, spell);

    if ( spell->spell_type != SPELL_BOLT )
    {
        cprintf(ch,"Only bolts have a range element.\n\r");
        return FALSE;
    }

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Syntax:  range [amount in tenths of a second]\n\r");
        return FALSE;
    }

    amt = atoi(argument);
    if ( amt < 1 || amt > 5)
    {
        cprintf(ch,"Range time must be between 1 and 5.\n\r");
        return FALSE;
    }

    spell->action.generic.range = amt;
    cprintf(ch,"Range set to %d rooms.\n\r", 
        spell->action.generic.range );
    return TRUE;
}

LEDIT (ledit_casting_time )
{ 
    SpellIndex  *spell;
    int amt;

    EDIT_SPELL(ch, spell);

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Syntax:  castingtime [amount in tenths of a second]\n\r");
        return FALSE;
    }

    amt = atoi(argument);
    if ( amt < 0 )
    {
        cprintf(ch,"Casting time must be at least 0.\n\r");
        return FALSE;
    }

    spell->beats = amt;
    cprintf(ch,"Casting time set to %d.%d.\n\r", 
        spell->beats / 10,
        spell->beats % 10 );
    return TRUE;
}

LEDIT (ledit_recasting_time )
{ 
    SpellIndex  *spell;
    int amt;

    EDIT_SPELL(ch, spell);

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Syntax:  recastingtime [amount in tenths of a second]\n\r");
        return FALSE;
    }

    amt = atoi(argument);
    if ( amt < 0 )
    {
        cprintf(ch,"Recasting time must be at least 0.\n\r");
        return FALSE;
    }

    spell->recast = amt;
    cprintf(ch,"Recasting time set to %d.%d.\n\r",
        spell->recast / 10,
        spell->recast % 10 );
    return TRUE;
}

LEDIT (ledit_damage_noun )
{ 
    SpellIndex  *spell;

    EDIT_SPELL(ch, spell);

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Syntax:  damagenoun [string]\n\r");
        return FALSE;
    }

    free_string( spell->msg_damage );
    spell->msg_damage = str_dup( argument );

    cprintf(ch,"Damage noun set to \"%s\".\n\r", spell->msg_damage );
    return TRUE;
}

LEDIT (ledit_function)
{ 
    SpellIndex  *spell;

    EDIT_SPELL(ch, spell);

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Syntax:  function [string]\n\r");
        return FALSE;
    }

    free_string( spell->func_name );
    spell->func_name = str_dup( argument );

    cprintf(ch,"Function message set to \"%s\".\n\r", spell->func_name );
    return TRUE;
}

LEDIT (ledit_incantation )
{ 
    SpellIndex  *spell;

    EDIT_SPELL(ch, spell);

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Syntax:  incantation [string]\n\r");
        return FALSE;
    }

    free_string( spell->incantation );
    spell->incantation = str_dup( argument );

    cprintf(ch,"Incantation message set to \"%s\".\n\r", spell->incantation );
    return TRUE;
}

LEDIT (ledit_gesture )
{ 
    SpellIndex  *spell;

    EDIT_SPELL(ch, spell);

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Syntax:  gesture [string]\n\r");
        return FALSE;
    }

    free_string( spell->gesture );
    spell->gesture = str_dup( argument );

    cprintf(ch,"Gesture message set to \"%s\".\n\r", spell->gesture );
    return TRUE;
}

LEDIT (ledit_wearoff_msg )
{ 
    SpellIndex  *spell;

    EDIT_SPELL(ch, spell);

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Syntax:  wearoff [string]\n\r");
        return FALSE;
    }

    free_string( spell->msg_off );
    spell->msg_off = str_dup( argument );

    cprintf(ch,"Wearoff message set to \"%s\".\n\r", spell->msg_off );
    return TRUE;
}

LEDIT (ledit_object_wearoff_msg )
{ 
    SpellIndex  *spell;

    EDIT_SPELL(ch, spell);

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Syntax:  objwearoff [string]\n\r");
        return FALSE;
    }

    free_string( spell->msg_obj );
    spell->msg_obj = str_dup( argument );

    cprintf(ch,"Object wearoff message set to \"%s\".\n\r", spell->msg_obj );
    return TRUE;
}

LEDIT (ledit_flags )
{
    SpellIndex  *spell;
    int value;

    if ( argument[0] != '\0' )
    {
        EDIT_SPELL( ch, spell );

        if ( ( value = flag_value( spell_flags, argument ) ) != NO_FLAG )
        {
            spell->flags ^= value;

            cprintf(ch,"Spell flags set to %s.\n\r", flag_string( spell_flags, spell->flags ) );
            return TRUE;
        }
    }

    cprintf( ch, "Syntax: flags [flag]\n\r"
                  "Type '? spell' for a list of flags.\n\r" );
    return FALSE;

}


LEDIT (ledit_show )
{
    SpellIndex *spell;
    int i;

    EDIT_SPELL(ch, spell);

    cprintf(ch,"Spell #%d\n\r", spell->vnum );
    cprintf(ch,"Source File:    [%s]\n\r", spell->filename );
    cprintf(ch,"Function:       [%s]\n\r", spell->func_name );
    cprintf(ch,"Name:           [%s]\n\r", spell->name );
    cprintf(ch,"Full Name:      [%s]\n\r", spell->full_name );
    cprintf(ch,"Type:           [%s]\n\r", flag_string( spell_type_flags,
                                                        spell->spell_type ) );
    cprintf(ch,"Mana Cost:      [%d]\n\r", spell->base_mana );
    cprintf(ch,"Spell Group:    [%s]\n\r", spell->sgsn == NULL ? "unassigned" :
                                           skill_table[*spell->sgsn].name );
    cprintf(ch,"Target Type:    [%s]\n\r", flag_string( spell_target_flags, spell->target) );
    cprintf(ch,"Casting Time:   [%d.%ds]\n\r", spell->beats / 10, spell->beats % 10 );
    cprintf(ch,"Recast Time:    [%d.%ds]\n\r", spell->recast / 10, spell->recast % 10 );
    cprintf(ch,"Damage Noun:    [%s]\n\r", spell->msg_damage == NULL ? "unassigned" :
                                           spell->msg_damage );

    cprintf(ch,"Incantation:    [%s]\n\r", spell->incantation );
    cprintf(ch,"Gestures:       [%s]\n\r", spell->gesture );
    cprintf(ch,"Wear-off:       [%s]\n\r", spell->msg_off );
    cprintf(ch,"Obj Wear-off:   [%s]\n\r", spell->msg_obj );
    cprintf(ch,"Flags:          [%s]\n\r", flag_string( spell_flags, spell->flags|AFF_ABSOLUTE_TIME ) );
    cprintf(ch,"Casting Levels:\n\r");
    for( i=0; i < MAX_CLASS ;i++ )
        if ( spell->class_level[i] > 0 )
            cprintf(ch,"  %s(%d)", class_table[i].name, spell->class_level[i] );

    cprintf(ch,"\n\r");
    switch( spell->spell_type )
    {
        case SPELL_BOLT:
            cprintf(ch," * %d to %d %s damage, ",
                spell->action.generic.lowDamage,
                spell->action.generic.highDamage,
                flag_string( dam_flags, spell->action.generic.damType ) );
            cprintf(ch,"%s save for half damage\n\r",
                flag_string( savingthrow_flags, spell->action.generic.saveType ) );
            cprintf(ch,"Range: %d rooms\n\r", spell->action.generic.range );
            break;

        case SPELL_NUKE:
            cprintf(ch," * %d to %d %s damage, ",
                spell->action.generic.lowDamage,
                spell->action.generic.highDamage,
                flag_string( dam_flags, spell->action.generic.damType ) );
            cprintf(ch,"%s save for half damage\n\r",
                flag_string( savingthrow_flags, spell->action.generic.saveType ) );
            break;

        case SPELL_COMBO_NUKE:
            cprintf(ch," * %d to %d %s damage, ",
                spell->action.generic.lowDamage,
                spell->action.generic.highDamage,
                flag_string( dam_flags, spell->action.generic.damType ) );
            cprintf(ch,"%s save vs ", flag_string( dam_flags, spell->action.generic.damType ) );
            cprintf(ch,"%s for half damage\n\r",
                flag_string( savingthrow_flags, spell->action.generic.saveType ) );
            cprintf(ch,"If successful, echo to room:     [%s]\n\r", spell->action.generic.okRoomEcho );
            cprintf(ch,"If successful, echo to victim:   [%s]\n\r", spell->action.generic.okVictimEcho );
            for( i=0; i < 5; i++ )
            {
                int mark = ch->desc->outtop;

                formatAffectDescription( ch, &spell->action.generic.affects[i] );
                if( ch->desc->outtop != mark )
                    cprintf(ch,"for %s (flags: %s)\n\r",
                        getAffectDurationString( &spell->action.generic.affects[i] ),
                        flag_string(aff_flags, spell->action.generic.affects[i].flags) );
            }

            break;

        case SPELL_DEBUFF:
            cprintf(ch,"If failed, echo to room:       [%s]\n\r", spell->action.generic.failRoomEcho );
            cprintf(ch,"If failed, echo to victim:     [%s]\n\r", spell->action.generic.failVictimEcho );
            cprintf(ch,"If successful, echo to room:   [%s]\n\r", spell->action.generic.okRoomEcho );
            cprintf(ch,"If successful, echo to victim: [%s]\n\r", spell->action.generic.okVictimEcho );
            for( i=0; i < 5; i++ )
            {
                int mark = ch->desc->outtop;

                formatAffectDescription( ch, &spell->action.generic.affects[i] );
                if( ch->desc->outtop != mark )
                    cprintf(ch,"for %s (flags: %s)\n\r",
                        getAffectDurationString( &spell->action.generic.affects[i] ),
                        flag_string(aff_flags, spell->action.generic.affects[i].flags) );
            }

            cprintf(ch,"%s save vs ", flag_string( dam_flags, spell->action.generic.damType ) );
            cprintf(ch,"%s to avoid affect\n\r", flag_string( savingthrow_flags, spell->action.generic.saveType ) );
            break;

        case SPELL_BUFF:
            cprintf(ch,"If successful, echo to room:     [%s]\n\r", spell->action.generic.okRoomEcho );
            cprintf(ch,"If successful, echo to victim:   [%s]\n\r", spell->action.generic.okVictimEcho );
            for( i=0; i < 5; i++ )
            {
                int mark = ch->desc->outtop;

                formatAffectDescription( ch, &spell->action.generic.affects[i] );
                if( ch->desc->outtop != mark )
                    cprintf(ch,"for %s (flags: %s)\n\r", 
                        getAffectDurationString( &spell->action.generic.affects[i] ),
                        flag_string(aff_flags, spell->action.generic.affects[i].flags) );
            }
            break;
        default:
            cprintf(ch," * Spell type unknown, no printable affects\n\r");
            break;
    }

    return TRUE;
}


LEDIT( ledit_create )
{
    SpellIndex *pSpell, *copy_source;
    int  value;
    int  iHash;
	char arg[MAX_INPUT_LENGTH];

	argument = one_argument( argument, arg );
    value = atoi( arg );

    if ( arg[0] == '\0' || value == 0 )
    {
		cprintf(ch,"Syntax:  ledit create [vnum] (from vnum)\n\r");
		return FALSE;
    }

    if ( ch->pcdata->security < 8 )
    {
		cprintf(ch,"SpellEdit:  Minimum security of 8 is required to make spells.\n\r");
		return FALSE;
    }

    if ( get_spell_index( value ) )
    {
		cprintf(ch,"SpellEdit:  Spell vnum already exists.\n\r");
		return FALSE;
    }

    pSpell			        = (SpellIndex *) GC_MALLOC( sizeof(SpellIndex) );
    pSpell->vnum			= value;
        
    iHash			        = value % MAX_KEY_HASH;
    pSpell->next			= spell_index_hash[iHash];
    spell_index_hash[iHash]	= pSpell;
    ch->desc->pEdit		    = (void *) pSpell;
    top_spell_vnum          = UMAX( top_spell_vnum, value );
    cprintf( ch, "Spell created.\n\r" );

	if ( *argument == NULL )
    	return TRUE;
    else
    {
        cprintf(ch,"Spell copying is currently disabled.\n\r");
        return TRUE;
    }

	/* Copy? */
	argument = one_argument( argument, arg );
	if ( str_cmp(arg,"from") )
	{
		cprintf(ch,"Invalid copy syntax.  Ignoring.\n\r");
		return TRUE;
	}

	value = atoi( argument );
	if ( value <= 0 )
	{
		cprintf(ch,"Malformed copy, ignoring.\n\r");
		return TRUE;
	}

	if ( (copy_source = get_spell_index( value )) == NULL )
	{
		cprintf(ch,"No such spell with vnum %d, copy ignored.\n\r", value );
		return TRUE;
	}

	//copySpellIndex( pSpell, copy_source );
	cprintf(ch,"Spell %d (%s) copied to %d.\n\r",
		value, copy_source->name, pSpell->vnum );
	return TRUE;
}

LEDIT (ledit_short)
{
    SpellIndex  *spell;

    EDIT_SPELL(ch, spell);

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Syntax:  short [string]\n\r");
        return FALSE;
    }

    free_string( spell->short_descr );
    spell->short_descr = str_dup( argument );

    cprintf(ch,"Short description set to \"%s\".\n\r", spell->short_descr );
    return TRUE;
}

LEDIT( ledit_desc )
{
    SpellIndex *pSpell;

    EDIT_SPELL(ch, pSpell);

    if ( argument[0] == '\0' )
    {
        string_append( ch, &pSpell->description );
        return TRUE;
    }

    cprintf(ch,"Syntax:  desc    - line edit\n\r");
    return FALSE;
}

