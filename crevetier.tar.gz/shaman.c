/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/** System Include Files **/
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/** Custom Header Files **/
#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "tables.h"
#include "recycle.h"

bool spell_talisman_of_ugroth(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(60);
    af.location  = APPLY_HIT;
    af.modifier  = 64;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;

    spellAffectToChar( victim, &af );
    send_to_char( "A Talisman glows before your eyes.\n\r", victim );
	if ( victim != ch )
		act("A glowing Talisman appears before $N.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_talisman_of_zakath(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(68);
    af.location  = APPLY_HIT;
    af.modifier  = 122;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;

    spellAffectToChar( victim, &af );
    send_to_char( "A Talisman glows before your eyes.\n\r", victim );
    if ( victim != ch )
        act("A glowing Talisman appears before $N.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_talisman_of_makaar(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(76);
    af.location  = APPLY_HIT;
    af.modifier  = 198;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;

    spellAffectToChar( victim, &af );
    send_to_char( "A Talisman glows before your eyes.\n\r", victim );
    if ( victim != ch )
        act("A glowing Talisman appears before $N.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_talisman_of_kaldinor(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(84);
    af.location  = APPLY_HIT;
    af.modifier  = 264;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;

    spellAffectToChar( victim, &af );
    send_to_char( "A Talisman glows before your eyes.\n\r", victim );
    if ( victim != ch )
        act("A glowing Talisman appears before $N.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_vitality(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( is_affected( victim, sn , AFF_SPELL) )
    {
        if (victim == ch)
          send_to_char("Your vitality is already enhanced.\n\r",ch);
        else
          act("$N is already envigorated.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(UMIN(30,20+level));
    af.location  = APPLY_CON;
    af.modifier  = UMIN(12,5+level);
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );
    send_to_char( "Your body feels robust and healthy.\n\r", victim );
    act("$n feels robust and healthy.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_vitality_of_bison(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( is_affected( victim, sn , AFF_SPELL) )
    {
        if (victim == ch)
          send_to_char("Your vitality is already enhanced.\n\r",ch);
        else
          act("$N is already envigorated.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(45);
    af.location  = APPLY_CON;
    af.modifier  = UMIN(31,12+level/2);
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );
    send_to_char( "Your body feels robust and healthy.\n\r", victim );
    act("$n feels robust and healthy.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

/************* REAL SHAMAN SPELLS **************/

bool spell_inner_strength( int sn, int level, Character *ch, void *vo,int target )
{
	Character *victim = (Character *) vo;
	Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(30);
    af.location  = APPLY_STR;
    af.modifier  = 10;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );   

    send_to_char( "Your muscles surge with inner strength.\n\r", victim );
    act("$n surges with inner strength.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_inner_resolve( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;    
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(38);
    af.location  = APPLY_STR;  
    af.modifier  = 22;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "Your muscles surge with spirit strength.\n\r", victim );
    act("$n surges with spirit strength.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_inner_fortitude( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;    
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(46);
    af.location  = APPLY_STR;  
    af.modifier  = 34;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "Your muscles surge with soul strength.\n\r", victim );
    act("$n surges with soul strength.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_inner_power( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;    
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(54);
    af.location  = APPLY_STR;  
    af.modifier  = 46;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "Your muscles surge with inner power.\n\r", victim );
    act("$n surges with inner power.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_inner_might( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;    
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(62);
    af.location  = APPLY_STR;  
    af.modifier  = 58;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "Your muscles surge with spirit power.\n\r", victim );
    act("$n surges with spirit power.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_inner_dominance( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;    
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(70);
    af.location  = APPLY_STR;  
    af.modifier  = 70;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "Your muscles surge with soul power.\n\r", victim );
    act("$n surges with soul power.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_spirit_of_cat( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;    
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(30);
    af.location  = APPLY_DEX;  
    af.modifier  = 10;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "You are filled with the spirit of the cat.\n\r", victim );
    act("$n appears nimble and quick.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_spirit_of_lynx( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(38);
    af.location  = APPLY_DEX;
    af.modifier  = 20;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "You are filled with the spirit of the lynx.\n\r", victim );
    act("$n appears nimble and quick.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_spirit_of_cougar( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(46);
    af.location  = APPLY_DEX;
    af.modifier  = 34;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "You are filled with the spirit of the cougar.\n\r", victim );
    act("$n appears nimble and quick.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_spirit_of_leopard( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(54);
    af.location  = APPLY_DEX;
    af.modifier  = 46;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "You are filled with the spirit of the leopard.\n\r", victim );
    act("$n appears nimble and quick.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_spirit_of_tiger( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(62);
    af.location  = APPLY_DEX;
    af.modifier  = 58;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "You are filled with the spirit of the tiger.\n\r", victim );
    act("$n appears nimble and quick.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_spirit_of_cheetah( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(70);
    af.location  = APPLY_DEX;
    af.modifier  = 70;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "You are filled with the spirit of the cheetah.\n\r", victim );
    act("$n appears nimble and quick.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_spirit_of_badger( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(30);
    af.location  = APPLY_CON;
    af.modifier  = 10;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "You are filled with the spirit of the badger.\n\r", victim );
    act("$n appears tough and hardy.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_spirit_of_boar( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(38);
    af.location  = APPLY_CON;
    af.modifier  = 22;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "You are filled with the spirit of the boar.\n\r", victim );
    act("$n appears tough and hardy.",victim,NULL,NULL,TO_ROOM); 
    return TRUE;
}

bool spell_spirit_of_horse( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(46);
    af.location  = APPLY_CON;
    af.modifier  = 34;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "You are filled with the spirit of the horse.\n\r", victim );
    act("$n appears tough and hardy.",victim,NULL,NULL,TO_ROOM); 
    return TRUE;
}

bool spell_spirit_of_bear( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(54);
    af.location  = APPLY_CON;
    af.modifier  = 46;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "You are filled with the spirit of the bear.\n\r", victim );
    act("$n appears tough and hardy.",victim,NULL,NULL,TO_ROOM); 
    return TRUE;
}

bool spell_spirit_of_ox( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(62);
    af.location  = APPLY_CON;
    af.modifier  = 58;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "You are filled with the spirit of the ox.\n\r", victim );
    act("$n appears tough and hardy.",victim,NULL,NULL,TO_ROOM); 
    return TRUE;
}

bool spell_spirit_of_bison( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(70);
    af.location  = APPLY_CON;
    af.modifier  = 70;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "You are filled with the spirit of the bison.\n\r", victim );
    act("$n appears tough and hardy.",victim,NULL,NULL,TO_ROOM); 
    return TRUE;
}

bool spell_spirit_of_racoon( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;    

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level; 
    af.duration  = minutes(30);
    af.location  = APPLY_WIS;
    af.modifier  = 10;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "You are filled with the spirit of the racoon.\n\r", victim );
    act("$n appears sagacious.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_spirit_of_fox( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;     
    af.duration  = minutes(38);
    af.location  = APPLY_WIS;
    af.modifier  = 22;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "You are filled with the spirit of the fox.\n\r", victim );
    act("$n appears sagacious.",victim,NULL,NULL,TO_ROOM);      
    return TRUE;
}

bool spell_spirit_of_otter( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;     
    af.duration  = minutes(46);
    af.location  = APPLY_WIS;
    af.modifier  = 34;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "You are filled with the spirit of the otter.\n\r", victim );
    act("$n appears sagacious.",victim,NULL,NULL,TO_ROOM);      
    return TRUE;
}

bool spell_spirit_of_coyote( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;     
    af.duration  = minutes(54);
    af.location  = APPLY_WIS;
    af.modifier  = 46;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "You are filled with the spirit of the coyote.\n\r", victim );
    act("$n appears sagacious.",victim,NULL,NULL,TO_ROOM);      
    return TRUE;
}

bool spell_spirit_of_owl( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;     
    af.duration  = minutes(62);
    af.location  = APPLY_WIS;
    af.modifier  = 58;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "You are filled with the spirit of the owl.\n\r", victim );
    act("$n appears sagacious.",victim,NULL,NULL,TO_ROOM);      
    return TRUE;
}

bool spell_spirit_of_wolf( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;     
    af.duration  = minutes(70);
    af.location  = APPLY_WIS;
    af.modifier  = 70;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "You are filled with the spirit of the wolf.\n\r", victim );
    act("$n appears sagacious.",victim,NULL,NULL,TO_ROOM);      
    return TRUE;
}

bool spell_toad_skin( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;     
    af.duration  = minutes(30);
    af.location  = APPLY_AC;
    af.modifier  = 15;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "Your skin hardens and takes on a greenish tint.\n\r", victim );
    act("$n's flesh hardens and takes on a greenish tint.",victim,NULL,NULL,TO_ROOM);      
    return TRUE;
}

bool spell_turtle_skin( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(38);
    af.location  = APPLY_AC; 
    af.modifier  = 45;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "Your skin hardens and takes on a greenish tint.\n\r", victim ); 
    act("$n's flesh hardens and takes on a greenish tint.",victim,NULL,NULL,TO_ROOM); 
    return TRUE;
}

bool spell_scale_skin( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(46);
    af.location  = APPLY_AC; 
    af.modifier  = 75;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "Your skin hardens and is covered in thick scales.\n\r", victim ); 
    act("$n's flesh hardens and is covered by thick scales.",victim,NULL,NULL,TO_ROOM); 
    return TRUE;
}

bool spell_bone_skin( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(54);
    af.location  = APPLY_AC; 
    af.modifier  = 110;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "Your skin hardens and is covered with boney plates.\n\r", victim ); 
    act("$n's flesh hardens and is covered by boney plates.",victim,NULL,NULL,TO_ROOM); 
    return TRUE;
}

bool spell_horn_skin( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(62);
    af.location  = APPLY_AC; 
    af.modifier  = 140;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    send_to_char( "Your skin hardens and is covered by bumpy horns.\n\r", victim ); 
    act("$n's flesh hardens and is covered by bumpy horns.",victim,NULL,NULL,TO_ROOM); 
    return TRUE;
}

bool spell_lesser_quickening( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;     

    af.where        = TO_AFFECTS;
    af.type         = sn; 
    af.level        = level;
    af.duration     = minutes(12);
    af.modifier     = 82;
    af.location     = APPLY_SPEED;
    af.bitvector    = AFF_HASTE;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n's actions speed up!",victim,NULL,NULL,TO_ROOM);
    act("Your actions speed up!",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_quickening( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(16);
    af.modifier     = 76;
    af.location     = APPLY_SPEED;
    af.bitvector    = AFF_HASTE;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n's actions speed up!",victim,NULL,NULL,TO_ROOM);
    act("Your actions speed up!",victim,NULL,NULL,TO_CHAR); 
  	return TRUE;
}

bool spell_major_quickening( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(20);
    af.modifier     = 70;
    af.location     = APPLY_SPEED;
    af.bitvector    = AFF_HASTE;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n's actions speed up!",victim,NULL,NULL,TO_ROOM);
    act("Your actions speed up!",victim,NULL,NULL,TO_CHAR); 
  	return TRUE;
}

bool spell_greater_quickening( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(24);
    af.modifier     = 64;
    af.location     = APPLY_SPEED;
    af.bitvector    = AFF_HASTE;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n's actions speed up!",victim,NULL,NULL,TO_ROOM);
    act("Your actions speed up!",victim,NULL,NULL,TO_CHAR); 
	return TRUE;
}

bool spell_restorative_trance( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(15);
    af.modifier     = 25;
    af.location     = APPLY_REGEN_STAMINA;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

	if ( victim != ch )
		act("$N's soul enters a restorative trance.",ch,NULL,victim,TO_CHAR);
	act("Your soul enters a restorative trance.",victim,NULL,NULL,TO_CHAR);
	return TRUE;
}

bool spell_restorative_meditation( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;      

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(21);
    af.modifier     = 50; 
    af.location     = APPLY_REGEN_STAMINA;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    if ( victim != ch )
        act("$N's soul enters a restorative meditation.",ch,NULL,victim,TO_CHAR);
    act("Your soul enters a restorative meditation.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_restorative_hypnosis( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;      

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(27);
    af.modifier     = 75; 
    af.location     = APPLY_REGEN_STAMINA;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    if ( victim != ch )
        act("$N's soul enters a restorative hypnosis.",ch,NULL,victim,TO_CHAR);
    act("Your soul enters a restorative hypnosis.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_regenerative_trance( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;      

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(15);
    af.modifier     = 20;
    af.location     = APPLY_REGEN_HP;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

	af.modifier 	= 1;
	af.location		= APPLY_REGEN_BASE;

    if ( victim != ch )
        act("$N's soul enters a regenerative trance.",ch,NULL,victim,TO_CHAR);
    act("Your soul enters a regenerative trance.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_regenerative_meditation( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;     

    af.where        = TO_AFFECTS;
    af.type         = sn; 
    af.level        = level;
    af.duration     = minutes(21);
    af.modifier     = 40; 
    af.location     = APPLY_REGEN_HP;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    af.modifier     = 2;
    af.location     = APPLY_REGEN_BASE;

    if ( victim != ch )
        act("$N's soul enters a regenerative meditation.",ch,NULL,victim,TO_CHAR);
    act("Your soul enters a regenerative meditation.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_regenerative_hypnosis( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;     

    af.where        = TO_AFFECTS;
    af.type         = sn; 
    af.level        = level;
    af.duration     = minutes(27);
    af.modifier     = 60; 
    af.location     = APPLY_REGEN_HP;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    af.modifier     = 4;
    af.location     = APPLY_REGEN_BASE;

    if ( victim != ch )
        act("$N's soul enters a regenerative hypnosis.",ch,NULL,victim,TO_CHAR);
    act("Your soul enters a regenerative hypnosis.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_tepefaction( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;       

    dam = calcSpellDamage(ch,sn,5,6);

    if ( check_saves_spell(ch,victim,DAM_FIRE,SAVE_FORTITUDE) )
        dam /= 2;  
    damage( ch, victim, dam, sn, DAM_FIRE , DF_SHOW | DF_SPELL );
    return TRUE;   
}

bool spell_calefaction( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,15,19);

    if ( check_saves_spell(ch,victim,DAM_FIRE,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_FIRE , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_torrefaction( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,33,41);

    if ( check_saves_spell(ch,victim,DAM_FIRE,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_FIRE , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_incineration( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,62,77);

    if ( check_saves_spell(ch,victim,DAM_FIRE,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_FIRE , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_cremation( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,100,125);

    if ( check_saves_spell(ch,victim,DAM_FIRE,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_FIRE , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_shardstrike( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,15,19);

    if ( check_saves_spell(ch,victim,DAM_COLD,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_COLD , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_frost_spirits( int sn, int level, Character *ch,void *vo,int target)   
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,31,39);

    if ( check_saves_spell(ch,victim,DAM_COLD,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_COLD , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_snowstrike( int sn, int level, Character *ch,void *vo,int target)   
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,56,70);

    if ( check_saves_spell(ch,victim,DAM_COLD,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_COLD , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_ice_spirits( int sn, int level, Character *ch,void *vo,int target)   
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,93,116);

    if ( check_saves_spell(ch,victim,DAM_COLD,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_COLD , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_bloodfreeze( int sn, int level, Character *ch,void *vo,int target)   
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,145,181);

    if ( check_saves_spell(ch,victim,DAM_COLD,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_COLD , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_body_shock( int sn, int level, Character *ch,void *vo,int target)   
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,13,17);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_mind_shock( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,32,40);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_soul_shock( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,60,75);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_spirit_shock( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,102,127);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_life_shock( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,161,202);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_poison( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_POISON, SAVE_FORTITUDE) )
    {
		act("You resist the poison.",victim,NULL,NULL,TO_CHAR);
        act("The poison fails to take hold.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_POISON;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = 4;
        af.modifier     = 5;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

		af.bitvector	= AFF_POISON;
		af.where		= TO_AFFECTS;
		af.location		= 0;
		af.modifier		= 0;
		spellAffectToChar( victim, &af );

        act("You have been poisoned!",victim,NULL,NULL,TO_CHAR);
        act("$n has been poisoned!",victim,NULL,NULL,TO_ROOM);
    }

    damage( ch, victim, 0, sn, DAM_POISON , DF_SPELL );
    return TRUE;
}

bool spell_corruption( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_POISON, SAVE_FORTITUDE) ) 
    {
        act("You resist the poison.",victim,NULL,NULL,TO_CHAR);
        act("The poison fails to take hold.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_POISON; 
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = 9;
        af.modifier     = 12; 
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_POISON;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("You have been poisoned!",victim,NULL,NULL,TO_CHAR);  
        act("$n has been poisoned!",victim,NULL,NULL,TO_ROOM); 
    }

    damage( ch, victim, 0, sn, DAM_POISON , DF_SPELL ); 
    return TRUE;
}

bool spell_marasmus( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_POISON, SAVE_FORTITUDE) ) 
    {
        act("You resist the poison.",victim,NULL,NULL,TO_CHAR);
        act("The poison fails to take hold.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_POISON; 
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = 16;
        af.modifier     = 25; 
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_POISON;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("You have been poisoned!",victim,NULL,NULL,TO_CHAR);  
        act("$n has been poisoned!",victim,NULL,NULL,TO_ROOM); 
    }

    damage( ch, victim, 0, sn, DAM_POISON , DF_SPELL ); 
    return TRUE;
}

bool spell_defoedation( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_POISON, SAVE_FORTITUDE) ) 
    {
        act("You resist the poison.",victim,NULL,NULL,TO_CHAR);
        act("The poison fails to take hold.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_POISON; 
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = 25;
        af.modifier     = 31; 
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_POISON;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("You have been poisoned!",victim,NULL,NULL,TO_CHAR);  
        act("$n has been poisoned!",victim,NULL,NULL,TO_ROOM); 
    }

    damage( ch, victim, 0, sn, DAM_POISON , DF_SPELL ); 
    return TRUE;
}

bool spell_contamination( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_POISON, SAVE_FORTITUDE) ) 
    {
        act("You resist the poison.",victim,NULL,NULL,TO_CHAR);
        act("The poison fails to take hold.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_POISON; 
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = 36;
        af.modifier     = 45; 
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_POISON;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("You have been poisoned!",victim,NULL,NULL,TO_CHAR);  
        act("$n has been poisoned!",victim,NULL,NULL,TO_ROOM); 
    }

    damage( ch, victim, 0, sn, DAM_POISON , DF_SPELL ); 
    return TRUE;
}

bool spell_venenation( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_POISON, SAVE_FORTITUDE) ) 
    {
        act("You resist the poison.",victim,NULL,NULL,TO_CHAR);
        act("The poison fails to take hold.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_POISON; 
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = 49;
        af.modifier     = 61; 
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_POISON;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("You have been poisoned!",victim,NULL,NULL,TO_CHAR);  
        act("$n has been poisoned!",victim,NULL,NULL,TO_ROOM); 
    }

    damage( ch, victim, 0, sn, DAM_POISON , DF_SPELL ); 
    return TRUE;
}

bool spell_inquination( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_POISON, SAVE_FORTITUDE) ) 
    {
        act("You resist the poison.",victim,NULL,NULL,TO_CHAR);
        act("The poison fails to take hold.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_POISON; 
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = 64;
        af.modifier     = 81; 
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_POISON;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("You have been poisoned!",victim,NULL,NULL,TO_CHAR);  
        act("$n has been poisoned!",victim,NULL,NULL,TO_ROOM); 
    }

    damage( ch, victim, 0, sn, DAM_POISON , DF_SPELL ); 
    return TRUE;
}

bool spell_atrophy( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_POISON, SAVE_FORTITUDE) ) 
    {
        act("You resist the poison.",victim,NULL,NULL,TO_CHAR);
        act("The poison fails to take hold.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_POISON; 
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = 81;
        af.modifier     = 100; 
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_POISON;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("You have been poisoned!",victim,NULL,NULL,TO_CHAR);  
        act("$n has been poisoned!",victim,NULL,NULL,TO_ROOM); 
    }

    damage( ch, victim, 0, sn, DAM_POISON , DF_SPELL ); 
    return TRUE;
}

bool spell_fever( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_DISEASE, SAVE_FORTITUDE) ) 
    {
        act("You resist the disease.",victim,NULL,NULL,TO_CHAR);
        act("The disease fails to take hold.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_DISEASE; 
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(90);
        af.location     = 3;
        af.modifier     = 6; 
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_DISEASE;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("You feel sick and feverish.",victim,NULL,NULL,TO_CHAR);  
        act("$n appears to be sick and feverish.",victim,NULL,NULL,TO_ROOM); 
    }

    damage( ch, victim, 0, sn, DAM_DISEASE , DF_SPELL ); 
    return TRUE;
}

bool spell_sickness( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_DISEASE, SAVE_FORTITUDE) )
    {
        act("You resist the disease.",victim,NULL,NULL,TO_CHAR);
        act("The disease fails to take hold.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_DISEASE;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(90);
        af.location     = 6;
        af.modifier     = 14;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_DISEASE;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("You feel sick and feverish.",victim,NULL,NULL,TO_CHAR);
        act("$n appears to be sick and feverish.",victim,NULL,NULL,TO_ROOM);
    }

    damage( ch, victim, 0, sn, DAM_DISEASE , DF_SPELL );
    return TRUE;
}

bool spell_illness( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_DISEASE, SAVE_FORTITUDE) )
    {
        act("You resist the disease.",victim,NULL,NULL,TO_CHAR);
        act("The disease fails to take hold.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_DISEASE;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(90);
        af.location     = 14; 
        af.modifier     = 24; 
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_DISEASE;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("You feel ill and delirious.",victim,NULL,NULL,TO_CHAR);
        act("$n appears to be ill and delirious.",victim,NULL,NULL,TO_ROOM);
    }

    damage( ch, victim, 0, sn, DAM_DISEASE , DF_SPELL );
    return TRUE;
}

bool spell_plague( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_DISEASE, SAVE_FORTITUDE) )
    {
        act("You resist the disease.",victim,NULL,NULL,TO_CHAR);
        act("The disease fails to take hold.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_DISEASE;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(90);
        af.location     = 25; 
        af.modifier     = 36; 
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_DISEASE;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("You are stricken with the plague.",victim,NULL,NULL,TO_CHAR);
        act("$n is stricken with the plague.",victim,NULL,NULL,TO_ROOM);
    }

    damage( ch, victim, 0, sn, DAM_DISEASE , DF_SPELL );
    return TRUE;
}

bool spell_scourge( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_DISEASE, SAVE_FORTITUDE) )
    {
        act("You resist the disease.",victim,NULL,NULL,TO_CHAR);
        act("The disease fails to take hold.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {       
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_DISEASE; 
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(90);
        af.location     = 37;
        af.modifier     = 52;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_DISEASE;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("You are stricken with the scourge.",victim,NULL,NULL,TO_CHAR);
        act("$n is stricken with the scourge.",victim,NULL,NULL,TO_ROOM);    
    }

    damage( ch, victim, 0, sn, DAM_DISEASE , DF_SPELL );
    return TRUE;
}

bool spell_pestilence( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_DISEASE, SAVE_FORTITUDE) )
    {
        act("You resist the disease.",victim,NULL,NULL,TO_CHAR);
        act("The disease fails to take hold.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {       
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_DISEASE; 
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(90);
        af.location     = 53;
        af.modifier     = 72;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_DISEASE;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("You are stricken with pestilence .",victim,NULL,NULL,TO_CHAR);
        act("$n is stricken with pestilence.",victim,NULL,NULL,TO_ROOM);    
    }

    damage( ch, victim, 0, sn, DAM_DISEASE , DF_SPELL );
    return TRUE;
}

bool spell_mortification( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_DISEASE, SAVE_FORTITUDE) )
    {
        act("You resist the disease.",victim,NULL,NULL,TO_CHAR);
        act("The disease fails to take hold.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {       
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_DISEASE; 
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(90);
        af.location     = 73;
        af.modifier     = 90;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_DISEASE;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("You write in agony and pain as your body erupts in open sores.",victim,NULL,NULL,TO_CHAR);
        act("$n writes in agony and pain as $s body erupts in open sores.",victim,NULL,NULL,TO_ROOM);    
    }

    damage( ch, victim, 0, sn, DAM_DISEASE , DF_SPELL );
    return TRUE;
}

bool spell_delaceration( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_DISEASE, SAVE_FORTITUDE) )
    {
        act("You resist the disease.",victim,NULL,NULL,TO_CHAR);
        act("The disease fails to take hold.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {       
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_DISEASE; 
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(90);
        af.location     = 91;
        af.modifier     = 112;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_DISEASE;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("You scream in blinding pain as your body is corrupted with disease.",victim,NULL,NULL,TO_CHAR);
        act("$n screams in blinding pain as $s body is corrupted with disease.",victim,NULL,NULL,TO_ROOM);    
    }

    damage( ch, victim, 0, sn, DAM_DISEASE , DF_SPELL );
    return TRUE;
}

bool spell_gnat_swarm( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
    {
        act("A swarm of gnats covers your body but falls away dead.",victim,NULL,NULL,TO_CHAR);
        act("The gnats cover $n but then fall away dead.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = AFF_SLOW;
        af.type         = sn;
        af.level        = level;
        af.duration     = minutes(4);
        af.location     = APPLY_SPEED;
        af.modifier     = 114;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("Your body is covered with biting gnats!",victim,NULL,NULL,TO_CHAR);
        act("$n is covered by a swarm of biting gnats!",victim,NULL,NULL,TO_ROOM);
    }

	return TRUE;
}

bool spell_mosquito_swarm( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
    {
        act("A swarm of mosquitos covers your body but falls away dead.",victim,NULL,NULL,TO_CHAR);
        act("The mosquitos cover $n but then fall away dead.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = AFF_SLOW;
        af.type         = sn;
        af.level        = level;
        af.duration     = minutes(6);
        af.location     = APPLY_SPEED;
        af.modifier     = 118;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("Your body is covered with biting mosquitos!",victim,NULL,NULL,TO_CHAR);
        act("$n is covered by a swarm of biting mosquitos!",victim,NULL,NULL,TO_ROOM);
    }

    return TRUE;
}

bool spell_locust_swarm( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
    {
        act("A swarm of locusts covers your body but falls away dead.",victim,NULL,NULL,TO_CHAR);
        act("The locusts cover $n but then fall away dead.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = AFF_SLOW;
        af.type         = sn;
        af.level        = level;
        af.duration     = minutes(9);
        af.location     = APPLY_SPEED;
        af.modifier     = 122;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("Your body is covered with biting locusts.",victim,NULL,NULL,TO_CHAR);
        act("$n is covered by a swarm of biting locusts!",victim,NULL,NULL,TO_ROOM);
    }

    return TRUE;
}

bool spell_wasp_swarm( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
    {
        act("A swarm of wasps covers your body but falls away dead.",victim,NULL,NULL,TO_CHAR);
        act("The wasps cover $n but then fall away dead.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = AFF_SLOW;
        af.type         = sn;
        af.level        = level;
        af.duration     = minutes(13);
        af.location     = APPLY_SPEED;
        af.modifier     = 126;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("Your body is covered with biting wasps!",victim,NULL,NULL,TO_CHAR);
        act("$n is covered by a swarm of biting wasps!",victim,NULL,NULL,TO_ROOM);
    }

    return TRUE;
}

bool spell_hornet_swarm( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
    {
        act("A swarm of hornets covers your body but falls away dead.",victim,NULL,NULL,TO_CHAR);
        act("The hornets cover $n but then fall away dead.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = AFF_SLOW;
        af.type         = sn;
        af.level        = level;
        af.duration     = minutes(18);
        af.location     = APPLY_SPEED;
        af.modifier     = 130;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("Your body is covered with biting hornets!",victim,NULL,NULL,TO_CHAR);
        act("$n is covered by a swarm of biting hornets!",victim,NULL,NULL,TO_ROOM);
    }

    return TRUE;
}

bool spell_tic( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        act("You feel a twinge in your neck but the sensation vanishes.",victim,NULL,NULL,TO_CHAR);
        act("Nothing seems to happen.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = 0;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(20);
        af.location     = APPLY_HITROLL;
        af.modifier     = -30;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("You are distracted by an annoying tic in your neck.",victim,NULL,NULL,TO_CHAR);
        act("$n appears to be distracted.",victim,NULL,NULL,TO_ROOM);
    }

    return TRUE;
}

bool spell_itch( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        act("You feel a twinge in your neck but the sensation vanishes.",victim,NULL,NULL,TO_CHAR);
        act("Nothing seems to happen.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = 0;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(30);
        af.location     = APPLY_HITROLL;
        af.modifier     = -60;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("You are distracted by an annoying itch in your neck.",victim,NULL,NULL,TO_CHAR);
        act("$n appears to be distracted.",victim,NULL,NULL,TO_ROOM);
    }

    return TRUE;
}

bool spell_irritation( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        act("You feel a twinge in your neck but the sensation vanishes.",victim,NULL,NULL,TO_CHAR);
        act("Nothing seems to happen.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = 0;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(40);
        af.location     = APPLY_HITROLL;
        af.modifier     = -90;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("You are distracted by an annoying irritation of your skin.",victim,NULL,NULL,TO_CHAR);
        act("$n appears to be distracted.",victim,NULL,NULL,TO_ROOM);
    }

    return TRUE;
}

bool spell_distraction( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        act("You feel a twinge in your neck but the sensation vanishes.",victim,NULL,NULL,TO_CHAR);
        act("Nothing seems to happen.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = 0;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(50);
        af.location     = APPLY_HITROLL;
        af.modifier     = -130;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("You are distracted as your skin erupts in an itchy rash.",victim,NULL,NULL,TO_CHAR);
        act("$n appears to be distracted.",victim,NULL,NULL,TO_ROOM);
    }

    return TRUE;
}

bool spell_diversion( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        act("You feel a twinge in your neck but the sensation vanishes.",victim,NULL,NULL,TO_CHAR);
        act("Nothing seems to happen.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = 0;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = APPLY_HITROLL;
        af.modifier     = -170;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("You are distracted as your flesh burns with an intolerable itchy rash!",victim,NULL,NULL,TO_CHAR);
        act("$n appears to be distracted.",victim,NULL,NULL,TO_ROOM);
    }

    return TRUE;
}

bool spell_deprecate( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        act("You feel weak for a moment, but it passes.",victim,NULL,NULL,TO_CHAR);
        act("Nothing seems to happen.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = 0;
        af.type         = sn;
        af.level        = level;
        af.duration     = minutes(2);
        af.location     = APPLY_RES_POISON;
        af.modifier     = -12;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

		af.location		= APPLY_RES_DISEASE;
		spellAffectToChar( victim, &af );

		af.location		= APPLY_RES_FIRE;
		spellAffectToChar( victim, &af );
	
		af.location		= APPLY_RES_ICE;
		spellAffectToChar( victim, &af );

        act("You convulse in fear as your spirit feels weak and exposed.",victim,NULL,NULL,TO_CHAR);
        act("$n appears uncomfortable and exposed.",victim,NULL,NULL,TO_ROOM);
    }

    return TRUE;
}

bool spell_deplore( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        act("You feel weak for a moment, but it passes.",victim,NULL,NULL,TO_CHAR);
        act("Nothing seems to happen.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = 0;
        af.type         = sn;
        af.level        = level;
        af.duration     = minutes(6);
        af.location     = APPLY_RES_POISON;
        af.modifier     = -24;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.location     = APPLY_RES_DISEASE;
        spellAffectToChar( victim, &af );

        af.location     = APPLY_RES_FIRE;
        spellAffectToChar( victim, &af );

        af.location     = APPLY_RES_ICE;
        spellAffectToChar( victim, &af );

        act("You convulse in fear as your spirit feels weak and exposed.",victim,NULL,NULL,TO_CHAR);
        act("$n appears uncomfortable and exposed.",victim,NULL,NULL,TO_ROOM);
    }

    return TRUE;
}

bool spell_deprave( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        act("You feel weak for a moment, but it passes.",victim,NULL,NULL,TO_CHAR);
        act("Nothing seems to happen.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = 0;
        af.type         = sn;
        af.level        = level;
        af.duration     = minutes(12);
        af.location     = APPLY_RES_POISON;
        af.modifier     = -36;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.location     = APPLY_RES_DISEASE;
        spellAffectToChar( victim, &af );

        af.location     = APPLY_RES_FIRE;
        spellAffectToChar( victim, &af );

        af.location     = APPLY_RES_ICE;
        spellAffectToChar( victim, &af );

        act("You convulse in fear as your spirit feels weak and exposed.",victim,NULL,NULL,TO_CHAR);
        act("$n appears uncomfortable and exposed.",victim,NULL,NULL,TO_ROOM);
    }

    return TRUE;
}

bool spell_crow_eye(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(12);
    af.location  = APPLY_HITROLL;
    af.modifier  = 55;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

	act("Your vision sharpens.",victim,NULL,NULL,TO_CHAR);
	if ( victim != ch )
		act("$N's vision sharpens.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_hawks_eye(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(14);
    af.location  = APPLY_HITROLL;
    af.modifier  = 105;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your vision sharpens.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N's vision sharpens.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_falcons_eye(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(16);
    af.location  = APPLY_HITROLL;
    af.modifier  = 155;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your vision sharpens.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N's vision sharpens.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_eagles_eye(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(18);
    af.location  = APPLY_HITROLL;
    af.modifier  = 205;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your vision sharpens.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N's vision sharpens.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}
