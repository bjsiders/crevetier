/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Thanks to abaddon for proof-reading our comm.c and pointing out bugs.  *
 *  Any remaining bugs are, of course, our work, not his.  :)              *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

/***************************************************************************
*    ROM 2.4 is copyright 1993-1998 Russ Taylor                            *
*    ROM has been brought to you by the ROM consortium                     *
*        Russ Taylor (rtaylor@hypercube.org)                               *
*        Gabrielle Taylor (gtaylor@hypercube.org)                          *
*        Brian Moore (zump@rom.org)                                        *
*    By using this code, you have agreed to follow the terms of the        *
*    ROM license, in the file Rom24/doc/rom.license                        *
***************************************************************************/

#include "thoc.h"
#include "options.h"

int     create_cmd_lookup       ( const char *arg );
void    process_creation        ( Descriptor *d, char *argument );
void    creation_screen         ( Character *ch );
void    creation_menu           ( Character *ch );
char *check_parse_name_errstring( char *name );
bool    check_done              ( Character *ch, bool fQuiet, char *prefix );
void    initializeRace          ( Character *ch, int race, int subrace );

extern const char echo_off_str [];
extern const char echo_on_str  [];
extern const char go_ahead_str [];

void process_creation( Descriptor *d, char *argument )
{
    Character *ch;
    int cmd;
    char command[MAX_INPUT_LENGTH];

    ch = d->character;

    if ( ch->gen_data == NULL )
    {
        cprintf(ch,"Creating new character generation data...\n\r");
        ch->gen_data = new_gen_data();
        ch->gen_data->state = 0;
        ch->gen_data->state_func = NULL;
        ch->gen_data->sex = -1;
        ch->gen_data->race = -1;
        ch->gen_data->subrace = -1;
        ch->gen_data->class = -1;
        ch->gen_data->weapon_sn = -1;
        ch->gen_data->deity = -1;
        ch->gen_data->name[0] = '\0';
        ch->gen_data->password[0] = '\0';
    }

    argument = one_argument( argument, command );

    // If there's a previous state, we run that function again
    if ( ch->gen_data->state_func != NULL && ch->gen_data->state > 0 )
        (*ch->gen_data->state_func)(ch,command);
    else
    {
        if ( command[0] == '\0' )
        {
            creation_screen(ch);
            creation_menu(ch);
        }
        else
        {
            if ( (cmd = create_cmd_lookup( command )) < 0 )
            {
                cprintf(ch,"&RInvalid command.\n\r&x");
                creation_menu(ch);
            }
            else
                (*create_cmd_table[cmd].func_ptr)(ch,argument);
        }
    }
    return;
}

void creation_screen( Character *ch )
{
    char sex[32], race[32], class[32], subrace[32], 
         name[32], password[32], deity[32];
    
    // Fill in what they've picked out so far
    strcpy(sex,"???");
    strcpy(race,"???");
    strcpy(subrace,"???");
    strcpy(class,"???");
    strcpy(password,"???");
    strcpy(name,"???");
    strcpy(deity,"???");

    if ( ch->gen_data )
    {
        if ( ch->gen_data->sex >= 0 ) 
        {
            strcpy(sex,sex_table[ch->gen_data->sex].name);
            sex[0] = UPPER(sex[0]);
        }

        if ( ch->gen_data->race >= 0 )
        {
            strcpy(race,race_table[ch->gen_data->race].name);
            race[0] = UPPER(race[0]);
        }

        if ( ch->gen_data->subrace >= 0 )
        {
            strcpy(subrace,subrace_table[ch->gen_data->subrace].name);
            subrace[0] = UPPER(subrace[0]);
        }

        if ( ch->gen_data->class >= 0 )
        {
            strcpy(class,class_table[ch->class].name);
            class[0] = UPPER(class[0]);
        }

        if ( ch->gen_data->deity >= 0 )
        {
            strcpy(deity,deity_table[ch->gen_data->deity].name);
            deity[0] = UPPER(deity[0]);
            snprintf(deity+strlen(deity),sizeof(deity)-strlen(deity)," (%s)", 
                deity_table[ch->gen_data->deity].align == ALIGN_GOOD ? "Good" :    
                deity_table[ch->gen_data->deity].align == ALIGN_EVIL ? "Evil" : "Neutral" );
        }

        if ( ch->gen_data->password[0] != '\0' )
            strcpy(password,"********");

        if ( ch->gen_data->name[0] != '\0' )
            strcpy(name,ch->gen_data->name);
    }

    cprintf(ch,"&W+--= &GTHOC Character Creation&W =-------------------------------------------------+\n\r");
    cprintf(ch,"&W|&x Name:   &W%-18s&x  Password: &W%-s&x\n\r"
               "&W|&x Level:  &W%-18d&x  Gender:   &W%-s&x\n\r"
               "&W|&x Race:   &W%-18s&x  Subrace:  &W%-s&x\n\r"
               "&W|&x Class:  &W%-18s&x  Deity:    &W%-s&x\n\r",
        name, password, 1, sex, race, subrace, class, deity );

    if ( ch->gen_data && ch->gen_data->subrace >= 0 )
    {
        cprintf(ch,"&W+------------------------------------------------------------------------------+\n\r"); 
        cprintf(ch,"&W| ABILITIES &x(starting/training maximum)\n\r");
        cprintf(ch,"&W|&x Strength:       &g%3d&x / &g%3d\n\r", ch->perm_stat[STAT_STR], get_max_train(ch,STAT_STR) );
        cprintf(ch,"&W|&x Dexterity:      &g%3d&x / &g%3d\n\r", ch->perm_stat[STAT_DEX], get_max_train(ch,STAT_DEX) );
        cprintf(ch,"&W|&x Constitution:   &g%3d&x / &g%3d\n\r", ch->perm_stat[STAT_CON], get_max_train(ch,STAT_CON) );
        cprintf(ch,"&W|&x Intelligence:   &g%3d&x / &g%3d\n\r", ch->perm_stat[STAT_INT], get_max_train(ch,STAT_INT) );
        cprintf(ch,"&W|&x Wisdom:         &g%3d&x / &g%3d\n\r", ch->perm_stat[STAT_WIS], get_max_train(ch,STAT_WIS) );
        cprintf(ch,"&W|&x Charisma:       &g%3d&x / &g%3d\n\r", ch->perm_stat[STAT_CHA], get_max_train(ch,STAT_CHA) );
    }

    if ( ch->gen_data && ch->gen_data->class >= 0 )
    {
        int class = ch->gen_data->class;
        int bonus = 0;

        if ( ch->gen_data->subrace >= 0 )
            bonus = ch->perm_stat[STAT_CON] / 20;
 
        cprintf(ch,"&W+------------------------------------------------------------------------------+\n\r"); 
        cprintf(ch,"&W|&x Primary Attribute:     &W%s\n\r", capitalize(statnames[class_table[class].attr_prime]) );
        cprintf(ch,"&W|&x Secondary Attribute:   &W%s\n\r", capitalize(statnames[class_table[class].attr_second]) );
        cprintf(ch,"&W|&x Base HP gain/level:    &g%d\n\r", class_table[class].base_hit_gain );
        cprintf(ch,"&W|&x Stat HP gain/level:    &g%d&x-&g%d&x (includes &g%+d&x attribute bonus)\n\r", 
            class_table[class].hp_min + bonus,
            class_table[class].hp_max + bonus, bonus);
        cprintf(ch,"&W|&x Mana gain:             &W%s\n\r", !class_table[class].fMana ? "N/A" : class_table[class].fMana == 100 ? "Full" : "Partial" );
        cprintf(ch,"&W|&x Difficulty:            &W%s\n\r",
            class_table[class].difficulty == EASY ? "Easy" :
                (class_table[class].difficulty == MODERATE ? "Average" :
                    (class_table[class].difficulty == CHALLENGING ? "Challenging" : "Very Difficult")) );
        cprintf(ch,"&W|&x Description:           &W%s\n\r", class_table[class].description );
        cprintf(ch,"&W|&x Starting weapon:       &W%s\n\r", 
            ch->gen_data->weapon_sn < 0 ? "Default" : capitalize(flag_string(starting_weapon_flags,ch->gen_data->weapon_sn)));
    }

    cprintf(ch,"&W+------------------------------------------------------------------------------+\n\r");
    cprintf(ch,"&W| &xCreation Status:\n\r");
    if ( check_done(ch,FALSE,"&W| &x* &R") )
        cprintf(ch,"&W| * &GReady to play!&x\n\r");
    cprintf(ch,"&W+------------------------------------------------------------------------------+\n\r");
}

void cr_done( Character *ch, char *argument )
{
    Object *weapon;

    if (!check_done(ch,FALSE,NULL) )
    {
        cprintf(ch,"\n\r");
        creation_menu(ch);
        return;
    }

    group_add(ch,"rom basics",FALSE);
    group_add(ch,class_table[ch->class].base_group,FALSE);
    group_add(ch,class_table[ch->class].default_group,FALSE);

    // Creation weapon
    weapon = create_object(get_obj_index( ch->gen_data->weapon_sn ));
    obj_to_char( weapon, ch );

    free_gen_data( ch->gen_data );
    ch->gen_data = NULL;
    do_function(ch,&do_help,"motd");
    cprintf(ch,"(Push enter to continue...)\n\r");
    ch->desc->connected = CON_READ_MOTD;
    ch->level = 0;
    return;
}

bool check_done( Character *ch, bool fQuiet, char *prefix )
{
    bool fOk = TRUE;

    // Make sure everything is set up
    if ( ch->gen_data->name[0] == '\0' )
    {
        if ( !fQuiet )
            cprintf(ch,"%sYou haven't picked a name yet.\n\r", prefix ? prefix : "" );
        fOk = FALSE;
    }

    if ( ch->gen_data->password[0] == '\0' )
    {
        if ( !fQuiet )
        cprintf(ch,"%sYou haven't set your password yet.\n\r", prefix ? prefix : "" );
        fOk = FALSE;
    }

    if ( ch->gen_data->sex < 0 )
    {
        if ( !fQuiet )
        cprintf(ch,"%sYou haven't picked a gender yet.\n\r", prefix ? prefix : "" );
        fOk = FALSE;
    }

    if ( ch->gen_data->race < 0 )
    {
        if ( !fQuiet )
        cprintf(ch,"%sYou haven't picked a race yet.\n\r", prefix ? prefix : "" );
        fOk = FALSE;
    }

    if ( ch->gen_data->class < 0 )
    {
        if ( !fQuiet )
        cprintf(ch,"%sYou haven't picked a class yet.\n\r", prefix ? prefix : "" );
        fOk = FALSE;
    }

    if ( ch->gen_data->deity < 0 )
    {
        if ( !fQuiet )
        cprintf(ch,"%sYou haven't picked a deity yet.\n\r", prefix ? prefix : "" );
        fOk = FALSE;
    }

    return fOk;
}

void cr_color( Character *ch, char *argument )
{
    TOGGLE_BIT(ch->pcdata->color_options,COLOR_TOGGLE);
    ch->desc->color = !ch->desc->color;
    cprintf(ch,"Color %sabled.\n\r\n\r",  ch->desc->color ? "en" : "dis");
    creation_menu(ch);
}

void creation_menu( Character *ch )
{   
    cprintf(ch,"\n\r&W+------&G THOC Creation Menu &W--------\n\r");
    cprintf(ch," Change/set [&gname&x]     (%s)\n\r",
        ch->gen_data->name[0] == '\0' ? "???" : ch->gen_data->name );
    cprintf(ch," Change/set [&gpassword&x] (%s)\n\r",
        ch->gen_data->password[0] == '\0' ? "???" : "******" );
    cprintf(ch," Change/set [&ggender&x]   (%s)\n\r",
        ch->gen_data->sex >= 0 ? sex_table[ch->gen_data->sex].name : "???");
    cprintf(ch," Change/set [&grace&x]     (%s)\n\r",
        ch->gen_data->subrace < 0 ? "???" : subrace_table[ch->gen_data->subrace].name );
    cprintf(ch," Change/set [&gclass&x]    (%s)\n\r",
        ch->gen_data->class < 0 ? "???" : class_table[ch->gen_data->class].name );
    cprintf(ch," Change/set [&gdeity&x]    (%s)\n\r",
        ch->gen_data->deity < 0 ? "???" : deity_table[ch->gen_data->deity].name );
    cprintf(ch," Change/set [&gweapon&x]   (%s)\n\r",
            ch->gen_data->weapon_sn < 0 ? "default" : flag_string(starting_weapon_flags,ch->gen_data->weapon_sn));

    cprintf(ch," [&RCancel&x] creation\n\r");
    cprintf(ch," Turn [&gcolor&x] on/off\n\r");
    cprintf(ch," [&YHelp!&x]\n\r");

    if ( check_done(ch,TRUE,NULL) )
        cprintf(ch,"  [&BDone&x], let's start playing!\n\r");

    cprintf(ch,
"Type a command in [brackets] to edit that aspect of your new character (e.g.,\n\r"
"type \"name\" to set your character's name), or hit enter to look at your\n\r"
"character sheet so far.  Type \"help\" for more details.\n\r");
    cprintf(ch,"\n\r&WCommand:&x ");
}

int create_cmd_lookup( const char *arg )
{
    int cmd;
    
    for ( cmd = 0; create_cmd_table[cmd].name[0] != '\0'; cmd++ )
        if ( arg[0] == create_cmd_table[cmd].name[0]
        &&   !str_prefix( arg, create_cmd_table[cmd].name ) )
            return cmd;

    return -1;
}

void cr_password( Character *ch, char *argument )
{
    char *pwdnew, *p;

    ch->gen_data->state_func = cr_password;

    if ( ch->gen_data->name[0] == '\0' )
    {
        cprintf(ch,"You must select a name before you can set your password.\n\r\n\r");
        ch->gen_data->state_func = NULL;
        creation_menu(ch);
        return;
    }

    switch( ch->gen_data->state )
    {
    case 0:
        cprintf(ch,
"Passwords must be at least 6 characters long, and we strongly recommend that you\n\r"
"don't use easy and obvious passwords like dictionary words or variations of your\n\r"
"name.  Good passwords contain mixed-case alphanumerics and punctuation.  Also,\n\r"
"the tilde character is not permitted.\n\r\n\r"
"Please select a password: ");
        cprintf(ch,echo_off_str);
        ch->gen_data->state = PROMPT;
        return;
    case PROMPT:
        cprintf(ch,"\n\r");
        if ( strlen(argument) < 6)
        {
            cprintf(ch,"Passwords must be at least 6 characters long.\n\r");
            cprintf(ch,"Please try a different password: ");
            return;
        }

        pwdnew = crypt( argument, ch->gen_data->name );
        for( p = pwdnew; *p != '\0'; p++ )
        {
            if ( *p == '~' )
            {
                cprintf(ch,"That password contains illegal characters when encrypted.\n\r");
                cprintf(ch,"Please try a different password: ");
                return;
            }
        }

        strcpy( ch->gen_data->password, pwdnew );
        if ( ch->pcdata->pwd != NULL )
            free_string( ch->pcdata->pwd );
        ch->pcdata->pwd = str_dup( pwdnew );
        cprintf(ch,"Please retype your password to verify: ");
        ch->gen_data->state = VERIFY_PASSWORD;
        return;
    case VERIFY_PASSWORD:
        cprintf(ch,"\n\r");
        if ( strcmp( crypt( argument, ch->pcdata->pwd ), ch->pcdata->pwd ) )
        {
            cprintf(ch,"The passwords do not match.  Please try again.\n\r\n\r");
            cprintf(ch,"Please select a password: ");
            ch->gen_data->state = PROMPT;
            return;
        }
        // Password is ok!
        cprintf(ch,echo_on_str);
        ch->gen_data->state = 0;
        ch->gen_data->state_func = NULL;
        cprintf(ch,"New password set!\n\r\n\r");
        creation_menu(ch);
        return;
    default:
        cprintf(ch,"\n\rAn internal error occured.\n\r(Push enter to continue...)\n\r");
        ch->gen_data->state = 0;
        ch->gen_data->state_func = NULL;
        return;
    }
}

void show_races( Character *ch )
{
    int race;
    char tmp[25];

    cprintf(ch,
"\n\rNote: &RRaces with a ! next to their name are uncommon or rare races, and may\n\r"
     "not be available the next time you create.  In fact, they may not be available\n\r"
     "by the time you pick your race!  The race list is dynamic and a ! race may get\n\r"
     "snatched up by somebody else.\n\r&x");

    for ( race = 1; subrace_table[race].name != NULL; race++ )
    {
        if ( subrace_table[race].next_avail != NULL &&
             *subrace_table[race].next_avail > current_time )
            continue;

        if ( subrace_table[race].race_index != NULL )
            snprintf(tmp,sizeof(tmp),"%s (%s)",
                subrace_table[race].name,
                race_table[*subrace_table[race].race_index].name );
        else
            snprintf(tmp,sizeof(tmp),"%s", subrace_table[race].name );

        cprintf(ch,"%s * %-24s",
            subrace_table[race].next_avail == NULL ? "  " : "!!",
            tmp );
        cprintf(ch," STR &g%3d&x DEX &g%3d&x CON &g%3d&x INT &g%3d&x WIS &g%3d&x CHA &g%3d&x\n\r",
            subrace_table[race].stat_adj[STAT_STR], subrace_table[race].stat_adj[STAT_DEX],
            subrace_table[race].stat_adj[STAT_CON], subrace_table[race].stat_adj[STAT_INT],
            subrace_table[race].stat_adj[STAT_WIS], subrace_table[race].stat_adj[STAT_CHA] );
    }
    return;
}

void initializeClassSkills( Character *ch, int class )
{
    /* Reset old skills, add race/subrace back in */
    if ( ch->gen_data->subrace >= 0 )
        initializeRace( ch, ch->gen_data->race, ch->gen_data->subrace );

    group_add(ch,"rom basics",FALSE);
    group_add(ch,class_table[ch->class].base_group,FALSE);
    group_add(ch,class_table[ch->class].default_group,FALSE);
}

void initializeRace( Character *ch, int race, int subrace )
{
    int i;

    /* initialize stats */
    ch->affected_by  = ch->affected_by|race_table[race].aff;
    ch->imm_flags    = ch->imm_flags|race_table[race].imm;
    ch->form         = race_table[race].form;
    ch->parts        = race_table[race].parts;

    /* clear out old skills and abilities */
    for( i=0 ; i < MAX_SKILL ; i++ )
    {
        ch->pcdata->skill_mod[i] = 0;
        if ( skill_table[i].type != SKILL_TRADE && skill_table[i].type != SKILL_FOUNDATION)
            ch->pcdata->learned[i] = 0;
    }

    for( i=0 ; i < MAX_PROFICIENCY ; i++ )
        ch->pcdata->profs[i] = 0;

    /* add skills */
    for (i = 0; i < 5; i++)
    {
        if (pc_race_table[race].skills[i] == NULL)
            break;
        group_add(ch,pc_race_table[race].skills[i],FALSE);
    }

    ch->size = pc_race_table[race].size;

    /* Setup stats */
    for( i = 0 ; i < MAX_STATS ; i++ )
        ch->perm_stat[i] = subrace_table[subrace].stat_adj[i];

    if ( ch->gen_data->class >= 0 )
    {
        ch->perm_stat[class_table[ch->gen_data->class].attr_prime] += 25;
        ch->perm_stat[class_table[ch->gen_data->class].attr_second] += 15;

        group_add(ch,"rom basics",FALSE);
        group_add(ch,class_table[ch->class].base_group,FALSE);
        group_add(ch,class_table[ch->class].default_group,FALSE);
    }
}

void cr_race( Character *ch, char *argument )
{
    int race;
    int subrace;

    ch->gen_data->state_func = cr_race;
    switch( ch->gen_data->state )
    {
    case 0:
        cprintf(ch,
"Your character's race and subrace are both very important decisions, as they\n\r"
"cannot be changed once you finish creating your character.  Your race determines\n\r"
"what your character's attributes will be when you start, how high you can train\n\r"
"them, what classes you may pick from, and in the future, where in the game world\n\r"
"you begin play.  Some races have special abilities, and many of the subraces are\n\r"
"uncommon or rare, and not always available for play.\n\r\n\r");
        show_races(ch);
        cprintf(ch,"Please select a race (%s): ", 
            ch->gen_data->subrace < 0 ? "none" : subrace_table[ch->gen_data->subrace].name );
        ch->gen_data->state = PROMPT;
        return;
    case PROMPT:
        switch( *argument )
        {
        case '\0':
            ch->gen_data->state = 0;
            ch->gen_data->state_func = NULL;
            cprintf(ch,"Selection cancelled.\n\r\n\r");
            creation_menu(ch);
            return;
        default:
            if ( (subrace = subrace_lookup(argument)) < 1 )
            {
                cprintf(ch,"There is no such race.\n\r");
                cprintf(ch,"Please select a race (%s): ",
                    ch->gen_data->subrace < 0 ? "none" : subrace_table[ch->gen_data->subrace].name );
                return;
            }

            break;
        }

        // Logic/handling
        // Current class cannot play it
        if ( ch->gen_data->class >= 0 &&
             !subrace_table[subrace].class_mult[ch->gen_data->class] )
        {
            cprintf(ch,
"The %s class is not available to the %s race.  You'll have to change your class\n\r"
"if you wish to select the %s race.\n\r",
                class_table[ch->gen_data->class].name,
                subrace_table[subrace].name,
                subrace_table[subrace].name );
            cprintf(ch,"Please select a race (%s): ",
                ch->gen_data->subrace < 0 ? "none" : subrace_table[ch->gen_data->subrace].name );
            return;
        }

        // Is this subrace available for play at all?
        if ( subrace_table[subrace].next_avail != NULL )
        {
            if ( (*subrace_table[subrace].next_avail) > current_time && ch->gen_data->subrace != subrace )
            {
                cprintf(ch,
"That race is not available for play at the moment, and will become available at\n\r"
"a random point in the future.  Making multiple newbies will not make it\n\r"
"available for play sooner.  The date and time at which that race is available\n\r"
"for play again has been set as a random point in the future.\n\r\n\r");
                cprintf(ch,"Please select a race (%s): ",
                    ch->gen_data->subrace < 0 ? "none" : subrace_table[ch->gen_data->subrace].name );
                return;
            }
            else // Set randomized future availability
                set_next_avail( subrace );
        }

        // Everything's ok then
        // Have to be sure to unset next avail on the character's
        // previous race selection, if any.
        unset_next_avail( ch->gen_data->subrace );

        if ( subrace_table[subrace].race_index != NULL )
            race = *subrace_table[subrace].race_index;
        else
            race = race_lookup( subrace_table[subrace].name );

        ch->race = ch->gen_data->race = race;
        ch->pcdata->subrace = ch->gen_data->subrace = subrace;
        cprintf(ch,"Your character is a member of the %s race.\n\r",
            subrace_table[subrace].name );
        if ( subrace_table[subrace].race_index != NULL )
            cprintf(ch,"The %s are part of the %s race.\n\r",
                subrace_table[subrace].name, race_table[race].name );
        cprintf(ch,"\n\r");
        ch->gen_data->state = 0;
        ch->gen_data->state_func = NULL;

        // Initialize race information
        initializeRace( ch, race, subrace );
        creation_menu(ch);
        return;
    }

}

// Hackish.
void show_classes( Character *ch )
{
    int i;
    bool isAgnostic = FALSE;

    if ( ch->gen_data->deity == deity_lookup("agnostic") )
        isAgnostic = TRUE;

    for( i=0 ; i < MAX_CLASS ; i++ )
        if ( isAgnostic && IS_SET(class_table[i].flags,CLA_NO_AGNOSTIC))
            cprintf(ch," - %-18s %-s )&x\n\r",
                class_table[i].name, class_table[i].description );
        else
        if ( ch->gen_data->subrace < 0 ||
             subrace_table[ch->gen_data->subrace].class_mult[i] )
            cprintf(ch," * &W%-18s %-s&x\n\r", 
                capitalize(class_table[i].name), class_table[i].description );
        else
            cprintf(ch," - %-18s %-s )&x\n\r",
                class_table[i].name, class_table[i].description );
}

void cr_class( Character *ch, char *argument )
{
    int class;

    ch->gen_data->state_func = cr_class;
    switch( ch->gen_data->state )
    {
    case 0:
        cprintf(ch,
"\n\rYour choice of class determines most of what your character knows how to do.\n\r"
"Your class selection will determine your hit points, your skills, your\n\r"
"abilities, what kind of weapons and armor you can use, what kinds of spells you\n\r"
"can cast (if any!).  Picking your class is very important, and it's one of the\n\r"
"few decisions about your character that you cannot change later.  Note that not\n\r"
"all races can play all classes.  Classes you cannot play due to race\n\r"
"restrictions (and possible alignment restrictions) are prefixed with a dash.\n\r\n\r");

        show_classes(ch);
        cprintf(ch,"Please select a class (%s): ",
            ch->gen_data->class < 0 ? "none" : class_table[ch->gen_data->class].name );
        ch->gen_data->state = PROMPT;
        return;

    case PROMPT:
        switch( *argument )
        {
        case '\0':
            ch->gen_data->state = 0;
            ch->gen_data->state_func = NULL;
            cprintf(ch,"Selection cancelled.\n\r\n\r");
            process_creation(ch->desc,"");
            return;
        default:
            if ( (class = class_lookup(argument)) < 0 )
            {
                cprintf(ch,"There is no such class.\n\r");
                cprintf(ch,"Please select a class (%s): ",
                    ch->gen_data->class < 0 ? "none" : class_table[ch->gen_data->class].name );
                return;
            }
            break;
        }
        
        // Sanity checking
        // Alignment restrictions
        if ( IS_SET(class_table[class].flags,CLA_NO_AGNOSTIC) &&
             ch->gen_data->deity == deity_lookup("agnostic") )
        {
            cprintf(ch,
"The %s class may not be agnostic.  You'll have to change your deity if you\n\r"
"want to play this class.\n\r", class_table[class].name );
            cprintf(ch,"Please select a class (%s): ",
                ch->gen_data->class < 0 ? "none" : class_table[ch->gen_data->class].name );
            return;
        }

        // Subrace restrictions
        if ( ch->gen_data->subrace > 0 &&
             !subrace_table[ch->gen_data->subrace].class_mult[class] )
        {
            cprintf(ch,
"The %s class may not be played by the %s race.  You'll have to\n\r"
"change your race if you want to play this class.\n\r", 
                    class_table[class].name, 
                    subrace_table[ch->gen_data->subrace].name );
            cprintf(ch,"Please select a class (%s): ",
                ch->gen_data->class < 0 ? "none" : class_table[ch->gen_data->class].name );
            return;
        }

        // That's it!
        if ( ch->gen_data->class >= 0 && ch->gen_data->subrace >= 0 ) // Drop old req's
        {
            ch->perm_stat[class_table[ch->gen_data->class].attr_prime] -= 25;
            ch->perm_stat[class_table[ch->gen_data->class].attr_second] -= 15;
        }

        ch->class = ch->gen_data->class = class;
        cprintf(ch,"Your class has been set to %s.\n\r\n\r", class_table[class].name );
        ch->gen_data->state = 0;
        ch->gen_data->state_func = NULL;

        // Add ne req's
        if ( ch->gen_data->subrace >= 0 ) // Drop old req's
        {
            ch->perm_stat[class_table[ch->class].attr_prime] += 25;
            ch->perm_stat[class_table[ch->class].attr_second] += 15;
        }

        ch->gen_data->weapon_sn = class_table[ch->class].default_weapon;
        initializeClassSkills( ch, class );
        creation_menu(ch);
        return;
    }
}

void show_deities( Character *ch )
{
    int i;

    // Show available deities
    if ( ch->gen_data->subrace >= 0 )
    {
        int d = deity_lookup( subrace_table[ch->gen_data->subrace].patron_deity );
        if ( d >= 0 )
            cprintf(ch," * &WThe %s patron deity is %s, %s.&x\n\r\n\r",
                subrace_table[ch->gen_data->subrace].name,
                deity_table[d].name, deity_table[d].role );
    }

    for ( i = 1 ; deity_table[i].name != NULL ; i++ )
        cprintf(ch," * [%-7s] &W%s&x, %s\n\r",
            deity_table[i].align == ALIGN_GOOD ? " Good  " :
                deity_table[i].align == ALIGN_EVIL ? " Evil  " : "Neutral",
            deity_table[i].name,deity_table[i].role );

    if ( ch->gen_data->class < 0 ||
        !IS_SET(class_table[ch->gen_data->class].flags,CLA_NO_AGNOSTIC) )
    {
        cprintf(ch," * [%-7s] &W%s&x, %s\n\r",
            deity_table[0].align == ALIGN_GOOD ? " Good  " :
                deity_table[0].align == ALIGN_EVIL ? " Evil  " : "Neutral",
            deity_table[0].name,deity_table[0].role );
    }
}

void cr_deity( Character *ch, char *argument )
{
    int deity, align;

    ch->gen_data->state_func = cr_deity;
    switch( ch->gen_data->state )
    {
    case 0:
        cprintf(ch,
"Your choice of deity determines your alignment in THOC.  Among other things,\n\r"
"this affects which divine classes may cast beneificial spells on you, since\n\r"
"the gods will not bestow their gifts upon those of different alignments.\n\r"
"There is also some deity-specific and alignment-specific equipment in the\n\r"
"game, as well as NPCs who are biased for or against followers of specific\n\r"
"deities.  You can change your deity later in your character's career if you\n\r"
"wish, it's not a permanent decision.  The only limitation is that classes\n\r"
"that can cast divine spells (Druid, Shaman, Cleric, Crusader, Paladin) may\n\r"
"not be Agnostic.\n\r\n\r");
        show_deities(ch);
        cprintf(ch,"Please select a deity (%s): ", ch->gen_data->deity < 0 ? "none" : deity_table[ch->gen_data->deity].name );
        ch->gen_data->state = PROMPT;
        return;
    case PROMPT:
        switch( *argument )
        {
        case '\0':
            ch->gen_data->state = 0;
            ch->gen_data->state_func = NULL;
            cprintf(ch,"Selection cancelled.\n\r\n\r");
            process_creation(ch->desc,"");
            return;
        default:
            if ( (deity = deity_lookup( argument )) < 0 )
            {
                cprintf(ch,"%s is not a valid deity.", argument[0] == '\0' ? "(None)" : argument );
                cprintf(ch,"Please select a deity (%s): ", ch->gen_data->deity < 0 ? "none" : deity_table[ch->gen_data->deity].name );
                return;
            }
        }

        // Divine casters cannot be agnostic - Dru/Cle/Cru/Sha/Pal.
        if ( ch->gen_data->class >= 0 && 
             IS_SET(class_table[ch->gen_data->class].flags,CLA_NO_AGNOSTIC) &&
             deity == deity_lookup("agnostic") )
        {
            cprintf(ch,"Divine spellcasters cannot be agnostic.\n\r");
            cprintf(ch,"Please select a deity (%s): ", 
                ch->gen_data->deity < 0 ? "none" : deity_table[ch->gen_data->deity].name );
                return;
        }

        ch->deity = ch->gen_data->deity = deity;
        align = deity_table[deity].align;
        cprintf(ch,"You have selected %s as your deity, making your alignment %s.\n\r\n\r",
            deity_table[ch->gen_data->deity].name, align == ALIGN_GOOD ? "Good" : align == ALIGN_EVIL ? "Evil" : "Neutral" );
        ch->gen_data->state = 0;
        ch->gen_data->state_func = NULL;
        creation_menu(ch);
        return;
    }
}

void show_weapons( Character *ch )
{
    ObjIndex *weapon;
    int i, sn;

    // Ugly hack, but the default weapons range from vnums 26 to 36
    for( i=26 ; i<= 36 ; i++ )
    {
        if ( (weapon = get_obj_index(i)) == NULL )
            continue;

        // Find skill sn
        if ( !(*weapon_table[get_weapon_index(weapon->value[0])].gsn) )
            continue;

        sn = *weapon_table[get_weapon_index(weapon->value[0])].gsn;
        if ( ch->pcdata->learned[sn] < 1 )
            continue;

        cprintf(ch, " * %-20s\n\r", 
            skill_table[ *weapon_table[get_weapon_index(weapon->value[0])].gsn ].name );
    }
}

void cr_weapon( Character *ch, char *argument )
{
    int weapon, sn;


    if ( ch->gen_data->class < 0 )
    {
        cprintf(ch,"You cannot select your starting weapon until you pick a class.\n\r\n\r");
        return;
    }

    ch->gen_data->state_func = cr_weapon;
    switch( ch->gen_data->state )
    {
    case 0:
        cprintf(ch,
"All characters begin their careers with a default weapon choice.  Since many\n\r"
"characters may not have an opportunity to try a different weapon until after\n\r"
"they've invested training into their starting weapon, you have the option of\n\r"
"picking which weapon you begin the game with.  Your options are limited by \n\r"
"your choice of class.\n\r\n\r");
        show_weapons(ch);
        cprintf(ch,"Please pick a starting weapon (%s): ",
            ch->gen_data->weapon_sn < 0 ? "default" : flag_string(starting_weapon_flags,ch->gen_data->weapon_sn) );
        ch->gen_data->state = PROMPT;
        return;
    case PROMPT:
        switch( *argument )
        {
        case '\0':
            ch->gen_data->state = 0;
            ch->gen_data->state_func = NULL;
            cprintf(ch,"Selection cancelled.\n\r\n\r");
            creation_menu(ch);
            return;
        default:

            weapon = flag_value(starting_weapon_flags,argument);

            if ( weapon == NO_FLAG || (sn = skill_lookup(argument)) < 1 )
            {
                cprintf(ch,"That's not a valid weapon group.\n\r");
                cprintf(ch,"Please pick a starting weapon (%s): ",
                        ch->gen_data->weapon_sn < 0 ? "default" : flag_string(starting_weapon_flags,ch->gen_data->weapon_sn) );
                return;
            }

            if ( skill_table[sn].skill_level[ch->gen_data->class] < 1 ||
                 ch->pcdata->learned[sn] < 1 )
            {
                cprintf(ch,"Your class doesn't have the &g%s&x skill at level 1.\n\r",
                    skill_table[sn].name );
                cprintf(ch,"Please pick a starting weapon (%s): ",
                        ch->gen_data->weapon_sn < 0 ? "default" : flag_string(starting_weapon_flags,ch->gen_data->weapon_sn) );
                return;
            }

            ch->gen_data->weapon_sn = weapon;
            cprintf(ch,"You will begin the game with a weapon from the &G%s&x group.\n\r\n\r",
                flag_string(starting_weapon_flags,ch->gen_data->weapon_sn));
            ch->gen_data->state = 0;
            ch->gen_data->state_func = NULL;
            creation_menu(ch);
            return;
        }
    }

    return;
}

void cr_gender( Character *ch, char *argument )
{
    ch->gen_data->state_func = cr_gender;

    switch( ch->gen_data->state )
    {
    case 0:
        cprintf(ch,
"The gender of your character has no impact on game mechanics or how good your\n\r"
"character will be at anything.  You usually are not allowed to change your\n\r"
"character's gender once you finish creating, so be sure you can liv with your\n\r"
"selection.\n\r\n\rSelect the gender of this character (%s): ", ch->gen_data->sex < 0 ? "none" : sex_table[ch->gen_data->sex].name );
        ch->gen_data->state = PROMPT;
        return;
    case PROMPT:
        switch ( *argument )
        {
            case '\0':
                ch->gen_data->state = 0;
                ch->gen_data->state_func = NULL;
                cprintf(ch,"Selection cancelled.\n\r\n\r");
                process_creation(ch->desc,"");
                return;
            case 'm': case 'M':
                ch->sex = ch->pcdata->true_sex 
                        = ch->gen_data->sex = SEX_MALE; break;
                
            case 'f': case 'F':
                ch->sex = ch->pcdata->true_sex 
                        = ch->gen_data->sex = SEX_FEMALE; break;
            default:
                cprintf(ch,"Select the gender of this character (%s): ", ch->gen_data->sex < 0 ? "none" : sex_table[ch->gen_data->sex].name );
                return;
        }
        cprintf(ch,"Your character will be &g%s&x.\n\r\n\r",
            ch->gen_data->sex < 0 ? "none" : sex_table[ch->gen_data->sex].name );
        ch->gen_data->state = 0;
        ch->gen_data->state_func = NULL;
        creation_menu(ch);
        return;
    }
}

void cr_cancel( Character *ch, char *argument )
{
    Descriptor *d = ch->desc;

    if ( ch->gen_data && ch->gen_data->subrace > 0 )
        unset_next_avail( ch->gen_data->subrace );

    free_gen_data( ch->gen_data );
    ch->gen_data = NULL;
    free_char( ch );
    d->character = NULL;

    deprintf(d,"Creation cancelled.\n\r");
    deprintf(d,"(Push enter to continue...)\n\r");
    d->connected = CON_LOGIN_MENU;

    return;
}

void cr_name( Character *ch, char *argument )
{
    Descriptor d;
    bool name_taken = FALSE;

    ch->gen_data->state_func = cr_name;

    switch( ch->gen_data->state )
    {
    case PROMPT:
        {
            char *tmp;
            if ( argument[0] == '\0' )
                argument = ch->gen_data->name;
        
            argument[0] = UPPER(argument[0]);

            // Parse name
            tmp = check_parse_name_errstring( argument );
            if ( tmp != NULL )
            {
                cprintf(ch,"That name is not available because %s.\n\r",tmp);
                cprintf(ch,"&WPick a name for your character&x (%s): ", ch->gen_data->name );
                return;
            }

            if ( !check_being_created_name( argument ) )
            {
                name_taken = TRUE;
            }

            if ( load_char_obj( &d, argument ) )
            {
                free_char( d.character );
                name_taken = TRUE;
            }

            if ( name_taken )
            {
                cprintf(ch,"%s has been taken by another player already.\n\r", argument);
                cprintf(ch,"&WPick a name for your character&x (%s): ", ch->gen_data->name );
                return;
            }

            strcpy(ch->gen_data->name,argument);
            cprintf(ch,"You have selected &W%s&x as your new name.\n\r",
                ch->gen_data->name );
            cprintf(ch,
"&WWe recommend that brand-new players review the naming policy&x to ensure that\n\r"
"your name complies.  People often get attached to favorite names and many are\n\r"
"not allowed on THOC.\n\r\n\r&WWould you like to review the naming policy now?&x (y/n): ");
            ch->gen_data->state = REVIEW_NAMING_POLICY;

            return;
        }

    case REVIEW_NAMING_POLICY:
        switch( *argument )
        {
        case 'n': case 'N':
            ch->gen_data->state = 0;
            ch->gen_data->state_func = NULL;
            if ( ch->name != NULL )
                free_string( ch->name );
            ch->name = str_dup( ch->gen_data->name );
            cprintf(ch,"&WYour character's name will be '&G%s&W'.&x\n\r\n\r", ch->name );
            process_creation(ch->desc,"");
            return;
        case 'y': case 'Y':
            cprintf(ch,"&WIs '%s' a dictionary word, or a variant/mutation of one?&x (y/n): ",
                ch->gen_data->name );
            ch->gen_data->state = REVIEW_NP_DICTIONARY;
            return;
        default:
            cprintf(ch,"&WWould you like to review the naming policy now?&x (y/n): ");
            return;
        }

    case REVIEW_NP_DICTIONARY:
        switch( *argument )
        {
        case 'y': case 'Y':
            cprintf(ch,"&RDictionary names and variations on them are not permitted.&x\n\r");
            cprintf(ch,"&WPick a name for your character&x(%s): ", ch->gen_data->name );
            ch->gen_data->state = PROMPT;
            return;
        case 'n': case 'N':
            cprintf(ch,"&WIs '%s' from a book, film, comic, or any other copyrighted source?&x (y/n): ",
                ch->gen_data->name );
            ch->gen_data->state = REVIEW_NP_COPYRIGHTED;
            return;
        default:
            cprintf(ch,"&WIs '%s' a dictionary word, or a variant/mutation of one?&x (y/n): ",
                ch->gen_data->name );
            return;
        }

    case REVIEW_NP_COPYRIGHTED:
        switch( *argument )
        {
        case 'y': case 'Y':
            cprintf(ch,"&RCopyrighted names and pop culture references are not permitted.&x\n\r");
            cprintf(ch,"&WPick a name for your character&x (%s): ", ch->gen_data->name );
            ch->gen_data->state = PROMPT;
            return;
        case 'n': case 'N':
            cprintf(ch,"&WIs '%s' a modern or goofy name (like Bob, Dorfkin)?&x (y/n): ", 
                ch->gen_data->name );
            ch->gen_data->state = REVIEW_NP_ANACHRONISM;
            return;
        default:
            cprintf(ch,"&WIs '%s' from a book, film, comic, or any other copyrighted source?&x (y/n): ",
                ch->gen_data->name );
            return;
        }

    case REVIEW_NP_ANACHRONISM:
        switch( *argument )
        {
        case 'y': case 'Y':
            cprintf(ch,"&RNames must be a general fantasy-literature, pseudo-medieval nature.&x\n\r");
            cprintf(ch,"&WPick a name for your character&x (%s): ", ch->gen_data->name );
            ch->gen_data->state = PROMPT;
            return;
        case 'n': case 'N':
            cprintf(ch,"&WLast chance!  Are you sure that '%s' is an acceptable name?&x (y/n): ", 
                ch->gen_data->name );
            ch->gen_data->state = REVIEW_NP_LAST_CHANCE;
            return;
        default:
            cprintf(ch,"&WIs '%s' a modern or goofy name (like Bob, Dorfkin)?&x (y/n): ", 
                ch->gen_data->name );
            return;
        }

    case REVIEW_NP_LAST_CHANCE:
        switch( *argument )
        {
        case 'y': case 'Y':
            cprintf(ch,"&WNote that the Admins are the final authority on whether a name is acceptable.&x\n\r\n\r");
            ch->gen_data->state = 0;
            ch->gen_data->state_func = NULL;
            if ( ch->name != NULL )
                free_string( ch->name );
            ch->name = str_dup( ch->gen_data->name );
            cprintf(ch,"Your character's name will be '&G%s&x'.\n\r", ch->name );
            process_creation(ch->desc,"");
            return;
        case 'n': case 'N':
            cprintf(ch,"&WPick a name for your character&x (%s): ", ch->gen_data->name );
            ch->gen_data->state = PROMPT;
            return;
        default:
            cprintf(ch,"&WLast chance!  Are you sure that '%s' is an acceptable name?&x (y/n): ",
                ch->gen_data->name );
            return;
        }
    }

    if ( argument[0] == '\0' )
    {
        cprintf(ch,
"&RNote&x: We enforce a somewhat strict &Wnaming policy&x on THOC.  The short version\n\r"
"is that your name needs to be relatively original and sound like a real name\n\r"
"that a person in a fantasy setting might have.  This means no English words,\n\r"
"no names with titles in them, nothing stolen from pop fiction, no phoetic\n\r"
"variations, no anachronisms, etc.  ");
        cprintf(ch,                "Note that if your name is not in-line with\n\r"
"the naming policy, you'll usually be given a chance to work with the Admins\n\r"
"to come up with something new.  If this effort fails, you'll just be renamed\n\r"
"to something appropriate.\n\r\n\r");
        cprintf(ch,"&WPick a name for your character&x (%s): ", ch->gen_data->name );
        ch->gen_data->state = PROMPT;
        return;
    }
    else
    {
        ch->gen_data->state = PROMPT;
        cr_name(ch,argument);
        return;
    }
}

void cr_help( Character *ch, char *argument )
{
    cprintf(ch,
"--- &CTHOC Creation Help&x ---------------------------------------------------------\n\r"
"THOC character creation is done in modular steps, and you can do most of the\n\r"
"steps in any order you like.  Typically, you pick a name, password, gender, race,\n\r"
"class, deity, and then you're done.  You may optionally change your starting\n\r"
"weapon type as well.  To change one of these settings, just type the command\n\r"
"enclosed in [&gbrackets&x] on the main menu.  For example, to change your class,\n\r"
"just type \"class\", and you'll be moved through the class selection prompts.\n\r\n\r"
"While in these selection prompts, you can usually hit enter at the prompt to\n\r"
"cancel and go back to the main menu.  For example, if you type \"race\" but then\n\r"
"decide you don't want to change your race, just hit enter at the race selection\n\r"
"menu and you'll be sent back to the main menu.\n\r\n\r"
"When you're at the main creation menu, you can just hit enter to get a detailed\n\r"
"display of what your character's starting stats and attributes will look like,\n\r"
"including details on your class.\n\r\n\r"
"Once you've done everything necessary to get your character setup, a new option\n\r"
"will show up on the creation menu, called [&BDone&x].  Type \"done\" when you\n\r"
"are satisfied with your character set up, and that's all there is to it.\n\r\n\r"
"(Push enter to continue...)\n\r");
    return;
}
