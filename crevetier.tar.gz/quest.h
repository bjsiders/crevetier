#ifndef quest_h
#define quest_h

#define MAX_QUEST_FACTION       8
struct quest_data
{
    Area *          area;
    Quest *         next_index;
    Quest *         next;
    int             vnum;
    char *          name;
    char *          keyword;
    char *          short_descr;
    char *          long_descr;
    char *          hint;
    char *          goodbye;
    int             reward_vnum;
    int             reward_coins[MAX_CURRENCY];
    int             reward_experience;
    int             required[MAX_INGREDIENT];
    FactionAmount   faction_hits[MAX_QUEST_FACTION];
    FactionAmount   faction_avail[MAX_QUEST_FACTION];
    bool            race_avail[MAX_PC_RACE];
    bool            class_avail[MAX_CLASS];
    bool            deity_avail[MAX_DEITY];
    short           min_level;
    short           max_level;
    long            flags;
};

#define QUEST_PRIVATE       (A)
#define QUEST_YANK_MOB      (B)
#define QUEST_ONE_TIMER     (C)
#define QUEST_CONSIGNMENT   (D)

#endif /* quest_h */
