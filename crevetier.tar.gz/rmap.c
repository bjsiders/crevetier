// THOC Random Wilderness generator 1.0
// Siders 
/*
 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "thoc.h"
#include "olc.h"

Node map[MAPSIZE][MAPSIZE];
int top_rmap_vnum;
int bias;

void printMap( Character *ch )
{
    int i, j;

    for( i=0; i<MAPSIZE; i++ )
    {
        cprintf(ch,"\n\r");
        for( j=0; j<MAPSIZE; j++ )
        {
            if ( !map[j][i].exists )
            {
                cprintf(ch,"    ");
                continue;
            }
            if ( map[j][i].links[DIR_WEST] )
                cprintf(ch," - o");
            else
                cprintf(ch,"   o");
        }

        // print south links
        cprintf(ch,"\n\r");
        for( j=0; j<MAPSIZE; j++ )
        {
            if ( !map[j][i].exists )
            {
                cprintf(ch,"    ");
                continue;
            }
            if( map[j][i].links[DIR_SOUTH] )
                cprintf(ch,"   |");    
            else
                cprintf(ch,"    ");
        }

    }
	cprintf(ch,"\n\r");
}

void makeMap( int x, int y, int depth )
{
    int i;

    map[x][y].exists = 1;
    map[x][y].vnum = top_rmap_vnum++;

    if ( depth >= MAXDEPTH )
        return;

    for( i=0 ; i<4 ; i++ )
    {
        if ( number_percent() < bias && depth >= 1)
            continue;

        switch(i){
            case DIR_NORTH:
                if (map[x][y-1].links[DIR_NORTH]) 
                    continue; 
                map[x][y-1].exists = 1;
                map[x][y-1].links[DIR_SOUTH]=1;
                map[x][y].links[DIR_NORTH]=1;
                makeMap(x,y-1,depth+1);
                break;
            case DIR_EAST:
                if (map[x+1][y].links[DIR_EAST]) 
                    continue;
                map[x+1][y].exists = 1;
                map[x+1][y].links[DIR_WEST]=1;
                map[x][y].links[DIR_EAST]=1;
                makeMap(x+1,y,depth+1);
                break;
            case DIR_SOUTH:
                if (map[x][y+1].links[DIR_SOUTH]) 
                    continue;
                map[x][y+1].exists = 1;
                map[x][y+1].links[DIR_NORTH]=1;
                map[x][y].links[DIR_SOUTH]=1;
                makeMap(x,y+1,depth+1);
                break;
            case DIR_WEST:
                if (map[x-1][y].links[DIR_WEST]) 
                    continue;
                map[x-1][y].exists = 1;
                map[x-1][y].links[DIR_EAST]=1;
                map[x][y].links[DIR_WEST]=1;
                makeMap(x-1,y,depth+1);
                break;
        }
    }

    return;
}

void initMap( void )
{
	int i, j, k;

	for( i=0; i<MAPSIZE; i++ )
		for( j=0; j<MAPSIZE; j++ )
		{
			map[i][j].exists = 0;
			map[i][j].vnum = 0;
			for( k=0; k<4; k++ )
				map[i][j].links[k] = 0;
		}
}

void do_rmap( Character *ch, char *argument )
{
	char arg[MAX_INPUT_LENGTH];

	argument = one_argument( argument, arg );

	bias = 25;
	if ( arg[0] != '\0' )
		bias = atoi(arg);

    initMap( );
    makeMap( MAPSIZE/2, MAPSIZE/2, 0 );
    printMap( ch );
	cprintf(ch,"Using bias %d.\n\r",bias);
}

