/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/** System Include Files **/
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/** Custom Header Files **/
#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "tables.h"
#include "recycle.h"

/** The library of generic divine spells */

bool spell_cure_light_wounds( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int heal_amt;
    
    heal_amt = calcHealAmount(ch,sn,17,28);

    apply_healing( victim, heal_amt ); 

	if ( ch != victim )
    	actprintf(ch,NULL,victim,TO_CHAR,"You heal $N for %d hit points.",heal_amt);
	else
		cprintf(ch,"You heal yourself for %d hit points.\n\r",heal_amt);

    act("$n appears to feel a little better.",victim,NULL,NULL,TO_ROOM);
	cprintf(victim,"You feel a little better.\n\r");
    return TRUE;
}

bool spell_cure_major_wounds( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int heal_amt;
    
    heal_amt = calcHealAmount(ch,sn,47,74);

    apply_healing( victim, heal_amt ); 

	if( ch != victim )
    	actprintf(ch,NULL,victim,TO_CHAR,"You heal $N for %d hit points.",heal_amt);
	else
        cprintf(ch,"You heal yourself for %d hit points.\n\r",heal_amt);

    act("$n appears to feel better.",victim,NULL,NULL,TO_ROOM);
	cprintf(victim,"You feel better.\n\r");
    return TRUE;
}

bool spell_cure_minor_wounds( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int heal_amt;
    
    heal_amt = calcHealAmount(ch,sn,9,16);

    apply_healing( victim, heal_amt ); 

	if( ch != victim )
   		actprintf(ch,NULL,victim,TO_CHAR,"You heal $N for %d hit points.",heal_amt);
	else
        cprintf(ch,"You heal yourself for %d hit points.\n\r",heal_amt);

    act("$n appears to feel a little better.",victim,NULL,NULL,TO_ROOM);
	cprintf(victim,"You feel a little better.\n\r");
    return TRUE;
}

bool spell_cure_moderate_wounds( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int heal_amt;
    
    heal_amt = calcHealAmount(ch,sn,29,46);

    apply_healing( victim, heal_amt ); 

	if( ch != victim )
    	actprintf(ch,NULL,victim,TO_CHAR,"You heal $N for %d hit points.",heal_amt);
	else
        cprintf(ch,"You heal yourself for %d hit points.\n\r",heal_amt);

    act("$n appears to feel better.",victim,NULL,NULL,TO_ROOM);
	cprintf(victim,"You feel better.\n\r");
    return TRUE;
}

bool spell_cure_serious_wounds( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int heal_amt;

    heal_amt = calcHealAmount(ch,sn,75,118);

	apply_healing( victim, heal_amt );

	if( ch != victim )
    	actprintf(ch,NULL,victim,TO_CHAR,"You heal $N for %d hit points.",heal_amt);
	else
        cprintf(ch,"You heal yourself for %d hit points.\n\r",heal_amt);

    act("$n appears to feel much better.",victim,NULL,NULL,TO_ROOM);
	cprintf(victim,"You feel much better!\n\r");
    return TRUE;
}

bool spell_cure_critical_wounds( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int heal_amt;

    heal_amt = calcHealAmount(ch,sn,119,184);

    apply_healing( victim, heal_amt );

	if( ch != victim )
    	actprintf(ch,NULL,victim,TO_CHAR,"You heal $N for %d hit points.",heal_amt);
	else
        cprintf(ch,"You heal yourself for %d hit points.\n\r",heal_amt);

    act("$n appears to feel much better.",victim,NULL,NULL,TO_ROOM);
	cprintf(victim,"You feel much better!\n\r");
    return TRUE;
}

bool spell_cure_fatal_wounds( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int heal_amt;

    heal_amt = calcHealAmount(ch,sn,185,283);

    apply_healing( victim, heal_amt );

	if ( ch != victim )
		actprintf(ch,NULL,victim,TO_CHAR,"You heal $N for %d hit points.",heal_amt);
	else
        cprintf(ch,"You heal yourself for %d hit points.\n\r",heal_amt);

    act("$n appears to feel much better.",victim,NULL,NULL,TO_ROOM);
	cprintf(victim,"You feel much better!\n\r");
    return TRUE;
}

/* Disease resists */
bool spell_endure_disease( int sn, int level, Character *ch,void *vo,int target) 
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_RES_DISEASE;
    af.modifier     = 15;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your resistance to disease is increased.",victim,NULL,NULL,TO_CHAR);               
    if( ch != victim ) 
        act("$N is protected from disease.",ch,NULL,victim,TO_CHAR); 

    return TRUE;
}

bool spell_resist_disease( int sn, int level, Character *ch,void *vo,int target) 
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_RES_DISEASE;
    af.modifier     = 30;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your resistance to disease is increased.",victim,NULL,NULL,TO_CHAR);               
    if( ch != victim ) 
        act("$N is protected from disease.",ch,NULL,victim,TO_CHAR); 

    return TRUE;
}

bool spell_prevent_disease( int sn, int level, Character *ch,void *vo,int target) 
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_RES_DISEASE;
    af.modifier     = 50;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your resistance to disease is increased.",victim,NULL,NULL,TO_CHAR);               
    if( ch != victim ) 
        act("$N is protected from disease.",ch,NULL,victim,TO_CHAR); 

    return TRUE;
}

/* poison resists */
bool spell_endure_poison( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;     

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);      
    af.location     = APPLY_RES_POISON;
    af.modifier     = 15;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your resistance to poison is increased.",victim,NULL,NULL,TO_CHAR);

    if( ch != victim )  
        act("$N is protected from poison.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_resist_poison( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;  

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_RES_POISON;
    af.modifier     = 30;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your resistance to poison is increased.",victim,NULL,NULL,TO_CHAR);

    if( ch != victim )
        act("$N is protected from poison.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_prevent_poison( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_RES_POISON;
    af.modifier     = 50;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your resistance to poison is increased.",victim,NULL,NULL,TO_CHAR);

    if( ch != victim )
        act("$N is protected from poison.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool restore_xp( Character *ch, Character *victim, int percent )
{
	if ( IS_NPC(victim) )
	{
		act("$N is an NPC and cannot be resurrected.",ch,NULL,victim,TO_CHAR);
		return FALSE;
	}

	if ( victim->pcdata->lost_xp <= 0 )
	{
		act("$N is in no need of a resurrection.",ch,NULL,victim,TO_CHAR);
		return FALSE;
	}

	gain_exp(victim,victim->pcdata->lost_xp * percent / 100,FALSE);
	act("You resurrect $N and restore $S lost experience.",ch,NULL,victim,TO_CHAR);
	actprintf(ch,NULL,victim,TO_VICT,"$n resurrects you and restores %d lost experience!",victim->pcdata->lost_xp * percent / 100);
	if ( victim == ch )
	    actprintf(ch,NULL,NULL,TO_CHAR,"You resurrect yourself and restore %d lost experience!",victim->pcdata->lost_xp * percent / 100);


	victim->pcdata->lost_xp = 0;
	return TRUE;
}

bool spell_rejuvenate( int sn, int level, Character *ch,void *vo,int target)
{
    return restore_xp(ch,(Character *) vo,75);
}


bool spell_revive( int sn, int level, Character *ch,void *vo,int target)
{
    return restore_xp(ch,(Character *) vo,80);
}


bool spell_resuscitate( int sn, int level, Character *ch,void *vo,int target)
{
    return restore_xp(ch,(Character *) vo,84);
}


bool spell_revivicate( int sn, int level, Character *ch,void *vo,int target)
{
    return restore_xp(ch,(Character *) vo,88);
}

bool spell_resurrect( int sn, int level, Character *ch,void *vo,int target)
{
    return restore_xp(ch,(Character *) vo,92);
}

bool spell_cure_blindness( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect *paf;
	SpellIndex* pSpellIndex;
	int skill;

	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		skill = get_skill(ch,*(pSpellIndex->sgsn));
	}
	else
	{
		log_bug("spell_cure_blindness: Spell index not found(%d)",sn);
		return TRUE;
	}

    for ( paf = victim->affected ; paf != NULL ; paf = paf->next )
    {
        if( paf->where == TO_AFFECTS && paf->bitvector == AFF_BLIND  )
        {
			paf->level -= skill;
            if ( paf->level < 0 )
            {
                affect_strip(victim,paf->type);
                act("You are cured of the blindness.",victim,NULL,NULL,TO_CHAR);
                act("$n is cured of the blindness.",victim,NULL,NULL,TO_ROOM);
                return TRUE;
            }
			else
			{
            	act("The blindness is weakened but not cured.",victim,NULL,NULL,TO_ROOM);
            	act("The blindness is weakened but not cured.",victim,NULL,NULL,TO_CHAR);
				return TRUE;
			}
        }
    }

    act("$N doesn't seem to be suffering from any blindness affects.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_cure_poison( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect *paf;
	SpellIndex* pSpellIndex;
	int skill;

	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		skill = get_skill(ch,*(pSpellIndex->sgsn));
	}
	else
	{
		log_bug("spell_cure_poison: Spell index not found(%d)",sn);
		return TRUE;
	}

    for ( paf = victim->affected ; paf != NULL ; paf = paf->next )
    {
        if( paf->where == DAMAGE_OVER_TIME && paf->bitvector == DAM_POISON )
        {
			paf->level -= skill;
            if ( paf->level < 0 )
            {
                affect_strip(victim,paf->type);
                act("You are cured of the poison.",victim,NULL,NULL,TO_CHAR);
                act("$n is cured of the poison.",victim,NULL,NULL,TO_ROOM);
                return TRUE;
            }
			else
			{
            	act("The poison is weakened but not cured.",victim,NULL,NULL,TO_ROOM);
            	act("The poison is weakened but not cured.",victim,NULL,NULL,TO_CHAR);
				return TRUE;
			}
        }
    }

    act("$N doesn't seem to be suffering from any poisoning.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_cure_disease( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect *paf;
	SpellIndex* pSpellIndex;
	int skill;

	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		skill = get_skill(ch,*(pSpellIndex->sgsn));
	}
	else
	{
		log_bug("spell_disease: Spell index not found(%d)",sn);
		return TRUE;
	}

    for ( paf = victim->affected ; paf != NULL ; paf = paf->next )
    {
    	if ( paf->where == DAMAGE_OVER_TIME && paf->bitvector == DAM_POISON )
    	{
			paf->level -= skill;
        	if ( paf->level < 0 )
        	{
            	affect_strip(victim,paf->type);
        		act("You are cured of the disease.",victim,NULL,NULL,TO_CHAR);
        		act("$n is cured of the disease.",victim,NULL,NULL,TO_ROOM);
        		return TRUE;
        	}
			else
			{
        		act("The disease is weakened but not cured.",victim,NULL,NULL,TO_ROOM);
        		act("The disease is weakened but not cured.",victim,NULL,NULL,TO_CHAR);
				return TRUE;
			}
    	}
    }

    act("$N doesn't seem to be suffering from any diseases.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_endure_fire_d( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_RES_FIRE;
    af.modifier     = 15;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your resistance to fire is increased.",victim,NULL,NULL,TO_CHAR);
    if( ch != victim )
        act("$N is protected from fire.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_resist_fire_d( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_RES_FIRE;
    af.modifier     = 30;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your resistance to fire is increased.",victim,NULL,NULL,TO_CHAR);
    if( ch != victim )
        act("$N is protected from fire.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_prevent_fire_d( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_RES_FIRE;
    af.modifier     = 50;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your resistance to fire is increased.",victim,NULL,NULL,TO_CHAR);
    if( ch != victim )
        act("$N is protected from fire.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_endure_cold_d( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_RES_ICE;
    af.modifier     = 15;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your resistance to frost is increased.",victim,NULL,NULL,TO_CHAR);
    if( ch != victim )
        act("$N is protected from frost.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_resist_cold_d( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_RES_ICE;
    af.modifier     = 30;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your resistance to frost is increased.",victim,NULL,NULL,TO_CHAR);
    if( ch != victim )
        act("$N is protected from frost.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_prevent_cold_d( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_RES_ICE;
    af.modifier     = 50;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your resistance to frost is increased.",victim,NULL,NULL,TO_CHAR);
    if( ch != victim )
        act("$N is protected from frost.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

