/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#if defined(macintosh)
#include <types.h>
#include <time.h>
#else
#include <sys/types.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "thoc.h"
#include "interp.h"
#include "magic.h"

/*
 * The following special functions are available for mobiles.
 */
DECLARE_SPEC_FUN(	spec_breath_any		);
DECLARE_SPEC_FUN(	spec_breath_acid	);
DECLARE_SPEC_FUN(	spec_breath_fire	);
DECLARE_SPEC_FUN(	spec_breath_frost	);
DECLARE_SPEC_FUN(	spec_breath_gas		);
DECLARE_SPEC_FUN(	spec_breath_lightning	);
DECLARE_SPEC_FUN(	spec_guard		);
DECLARE_SPEC_FUN(	spec_poison		);

/* the function table */
const   struct  spec_type    spec_table[] =
{
    {	"spec_breath_any",		spec_breath_any		},
    {	"spec_breath_acid",		spec_breath_acid	},
    {	"spec_breath_fire",		spec_breath_fire	},
    {	"spec_breath_frost",		spec_breath_frost	},
    {	"spec_breath_gas",		spec_breath_gas		},
    {	"spec_breath_lightning",	spec_breath_lightning	},	
    {	"spec_guard",			spec_guard		},
    {	"spec_poison",			spec_poison		},
    {	NULL,				NULL			}
};


char *spec_name( SPEC_FUN *function)
{
    int i;

    for (i = 0; spec_table[i].function != NULL; i++)
    {
	if (function == spec_table[i].function)
	    return spec_table[i].name;
    }

    return NULL;
}

/*
 * Core procedure for dragons.
 */
bool dragon( Character *ch, char *spell_name )
{
    Character *victim;
    Character *v_next;
    int sn;

    return FALSE;

    for ( victim = ch->in_room->people; victim != NULL; victim = v_next )
    {
	v_next = victim->next_in_room;
	if ( victim->fighting == ch && number_bits( 3 ) == 0 )
	    break;
    }

    if ( victim == NULL )
	return FALSE;

    if ( ( sn = skill_lookup( spell_name ) ) < 0 )
	return FALSE;
    (*skill_table[sn].spell_fun) ( sn, ch->level, ch, victim, TARGET_CHAR);
    return TRUE;
}



/*
 * Special procedures for mobiles.
 */
bool spec_breath_any( Character *ch )
{
	return FALSE;

    switch ( number_bits( 3 ) )
    {
    case 0: return spec_breath_fire		( ch );
    case 1:
    case 2: return spec_breath_lightning	( ch );
    case 3: return spec_breath_gas		( ch );
    case 4: return spec_breath_acid		( ch );
    case 5:
    case 6:
    case 7: return spec_breath_frost		( ch );
    }

    return FALSE;
}



bool spec_breath_acid( Character *ch )
{
    return dragon( ch, "acid breath" );
}



bool spec_breath_fire( Character *ch )
{
    return dragon( ch, "fire breath" );
}



bool spec_breath_frost( Character *ch )
{
    return dragon( ch, "frost breath" );
}



bool spec_breath_gas( Character *ch )
{
     return FALSE;
}



bool spec_breath_lightning( Character *ch )
{
    return dragon( ch, "lightning breath" );
}

bool spec_guard( Character *ch )
{
    Character *victim;

    if ( !IS_AWAKE(ch) || ch->fighting != NULL )
		return FALSE;

	/* Guards attack any aggressive NPC that enters the room first.
	 * If there are none, it attacks any NPC that is fighting a player.
	 * IF there are none, it attacks any NPC with 'aggressive' disposition.
	 * If there are none, it attacks a player fighting another player if
	 * either has negative faction.
	 */

	/* Search for ally guards in trouble */
	for ( victim = ch->in_room->people; victim != NULL; victim = victim->next )
	{
		if( IS_NPC(victim) && IS_SET(victim->act,ACT_GUARD) && victim->fighting != NULL && !are_enemies(ch,victim) )
		{
			one_hit(ch,victim->fighting,TYPE_UNDEFINED );
			return TRUE;
		}
	}

	/* Search for aggressive NPCs */
    for ( victim = ch->in_room->people; victim != NULL; victim = victim->next )
    {
		if( IS_NPC(victim) && IS_SET(victim->act,ACT_AGGRESSIVE) && !IS_SET(victim->act,ACT_WIMPY) )
    	{
		
			one_hit( ch, victim, TYPE_UNDEFINED );
			return TRUE;
    	}
	}

	/* Search for NPCs fighting PC's */
	for( victim = ch->in_room->people; victim != NULL; victim = victim->next )
	{
		if( IS_NPC(victim) && victim->fighting != NULL && !IS_NPC(victim->fighting) )
		{
			one_hit( ch, victim, TYPE_UNDEFINED );
			return TRUE;
		}
	}

	/* Search for NPCs with aggressive disposition */
	for( victim = ch->in_room->people ; victim != NULL ; victim = victim->next )
	{
		if( IS_NPC(victim) && get_max_melee_disposition(victim) >= DISPOS_AGGRESSIVE )
		{
			one_hit( ch, victim, TYPE_UNDEFINED );
			return TRUE;
		}
	}

	/* Search for PC's who are fighting
	 * for now, do nothing
	 *
	for( victim = ch->in_room->people ; victim != NULL ; victim = victim->next )
	{
		Character *fight;

		if( !IS_NPC(victim) && (fight=victim->fighting) != NULL && !IS_NPC(fight))
		{

		}
	}
	 */

    return FALSE;
}


bool spec_poison( Character *ch )
{
    Character *victim;
    extern Spell( natural_venom );

    if ( ch->position != POS_FIGHTING
    || ( victim = ch->fighting ) == NULL
    ||   number_percent( ) > 2 * ch->level )
	return FALSE;

    act( "You bite $N!",  ch, NULL, victim, TO_CHAR    );
    act( "$n bites $N!",  ch, NULL, victim, TO_NOTVICT );
    act( "$n bites you!", ch, NULL, victim, TO_VICT    );
    spell_natural_venom( vnum_natural_venom, ch->level, ch, victim,TARGET_CHAR);
    return TRUE;
}


/* OLC Inserted */
/*****************************************************************************
 Name:		spec_string
 Purpose:	Given a function, return the appropriate name.
 Called by:	<???>
 ****************************************************************************/
char *spec_string( SPEC_FUN *fun )	/* OLC */
{
    int cmd;
    
    for ( cmd = 0; spec_table[cmd].name[0] != '\0'; cmd++ )
	if ( fun == spec_table[cmd].function )
	    return spec_table[cmd].name;

    return 0;
}



/*****************************************************************************
 Name:		spec_lookup
 Purpose:	Given a name, return the appropriate spec fun.
 Called by:	do_mset(act_wiz.c) load_specials,reset_area(db.c)
 ****************************************************************************/
SPEC_FUN *spec_lookup( const char *name )	/* OLC */
{
    int cmd;
   
    for ( cmd = 0; spec_table[cmd].name != NULL; cmd++ )
	if ( !str_cmp( name, spec_table[cmd].name ) )
	    return spec_table[cmd].function;

    return 0;
}


