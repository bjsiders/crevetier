#ifndef craft_h
#define craft_h

#define CRAFTING_CAP                     600
#define     FORGE_TAILOR_KIT        1
#define     FORGE_JEWELER_BAG       2
#define     FORGE_SMITHING_FORGE    3
#define     FORGE_KILN              4
#define     FORGE_FLETCHING_KIT     5
#define     FORGE_OVEN              6
#define     FORGE_STILL             7
#define     FORGE_CHEMIST_LAB       8


#define     MAX_INGREDIENT    10

#define TS_WOODWORKING        (A)
#define TS_METALWORKING       (B)
#define TS_LEATHERWORKING     (C)
#define TS_STONEWORKING       (D)
#define TS_CLOTHWORKING       (E)

#define TS_APOTHECARY           (F)
#define TS_ARMORSMITHING        (G)
#define TS_FLETCHING            (H)
#define TS_JEWELCRAFTING        (I)
#define TS_TAILORING            (J)
#define TS_WEAPONSMITHING       (K)
#define TS_SPELLCRAFTING        (L)

struct recipe_type
{
    Area        *area;
    int         vnum;
    Recipe      *next;
    char        *name;
    sh_int      trade_skill;
    int         result_vnum;
    int         fail_vnum;
    int         difficulty;
    int         trivial;
    int         components[MAX_INGREDIENT];
    int         foundation_skills;
};

extern const struct recipe_type     recipe_table[];

#endif /* craft_h */
