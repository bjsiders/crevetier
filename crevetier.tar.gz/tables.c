/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/
 
/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <stdio.h>
#include <time.h>
#include "thoc.h"
#include "tables.h"
#include "interp.h"

int mapArmorSlot( int gpn )
{
	int i;

	for( i = 1 ; armor_table[0].name != NULL ; i++ )
		if( *(armor_table[i].pgpn) == gpn )
			return i;

	return 0;
}

const struct armor_type armor_table[MAX_ARMOR+1] =
{
     	{ "non-armor", 0, NULL, "NA" },
     	{ "cloth armor", 0, &gpn_cloth_armor, "Cl" },
     	{ "leather armor", 10, &gpn_leather_armor, "Le" },
     	{ "studded leather armor", 19, &gpn_studded_leather_armor, "St" },
     	{ "chain mail armor", 27, &gpn_chain_mail_armor, "Ch"  },
     	{ "plate mail armor", 34, &gpn_plate_mail_armor, "Pl"  } ,
	   	{ "small shields",	0, &gpn_small_shields, "Sm" },
		{ "medium shields",	0, &gpn_medium_shields, "Md" },
		{ "large shields", 0, &gpn_large_shields, "Lg"  },
		{ "scale mail armor", 23, &gpn_scale_mail_armor, "Sc" },
		{ "buckler shields", 0, &gpn_buckler_shields, "Bu" },
		{ NULL, 0 , NULL, NULL }
};

const char *statnames[6] =
{
	"strength",
	"dexterity",
	"constitution",
	"intelligence",
	"wisdom",
	"charisma"
};


/* XP for an even con kill */
const int eck[61] =
{
	 1	,		/* 0 */
	10	,
	20	,
	25	,
	30	,		
	35,			/* 5 */
	40,
	45,
	50,
	55,		
	60,		/* 10 */
	65,
	70,
	75,
	80,		
	85,
	90,
	95,
	100,
	110,	
	120,		/* 20 */
	130,
	140,
	150,
	160,	
	170,
	180,
	190,
	200,
	215,	
	230,	/* 30 */
	245,
	260,
	275,
	290,	
	305,
	320,
	335,
	350,
	370,	
	390,	/* 40 */
	410,
	430,
	450,
	475,
	500,
	550,
	600,
	650,
	700,	
	750,		/* 50 */
	800,
	850,
	900,
	950, 
	1000,
	1050,
	1100,
	1150,
	1200,	
	1250,	/* 60*/
};

/* Experience table */
const struct level_data exp_to_level[61] =
{
	  {  10, 1 },
	  {	100, 2 }, /* l 1 */
      {	250, 2 }, 
      {	350, 2 },
      {	450, 2 },
      {	600, 3 }, /* L 5 */
      {	750, 3 },
      {	1000, 3 },
      {	1250, 3 },
      {	1500, 3 },
      {	1750, 3 }, /* L10 */
      {	2000, 3 }, 
      {	2500, 3 },
      {	3000, 3 },
      { 3500, 3 },
      {	4000, 3 },
      {	5000, 3 },
      {	6000, 4 },
      {	7000, 4 },
      {	8500, 4 },
      {	10000, 4 }, /* 20 */
      {	12000, 4 }, 
      {	14000, 4 }, 
      {	15000, 4  }, 
      {	16000, 4 }, 
      {	17000, 5 }, 
      {	17500, 5 }, 
      {	20000, 5 }, 
      {	22500, 5 }, 
      {	25000, 5 }, 
      {	27500, 5 }, /* 30 */
      {	30000, 5 },
      {	35000, 6 },
      {	40000, 6 },
      {	45000, 6 },
      {	50000, 6 },
      {	55000, 6 },
      {	60000, 6 },
      {	65000, 7 },
      {	70000, 7 }, 
      {	75000, 7 }, /* 40 */
      {	80000, 7 }, 
      {	90000, 7 },
      {	100000, 8 },
      {	110000, 8 },
      {	125000, 8 },
      {	150000, 8 },
      {	200000, 9 },
      {	300000, 9 },
      {	500000, 9 },
      {	750000, 10 }, /* 50 */
      {	500000, 10 }, 
      {	2000000, 10 },
      {	500000, 1 },
      {	750000, 1 },
      {	1000000, 1 },
      {	1500000, 1 },
      {	2000000, 1 },
      {	3000000, 1 },
      {	5000000, 1 },
      {	7500000, 1 },
};

Clan *clan_table;

/* for position */
const struct position_type position_table[] =
{
    {	"dead",			"dead"	},
    {	"mortally wounded",	"mort"	},
    {	"incapacitated",	"incap"	},
    {	"stunned",		"stun"	},
    {	"sleeping",		"sleep"	},
    {	"resting",		"rest"	},
    {   "sitting",		"sit"   },
    {	"fighting",		"fight"	},
    {	"standing",		"stand"	},
    {	NULL,			NULL	}
};

const struct deity_type	deity_table[] =
{
    { "agnostic", "I don't believe or disbelieve", 	ALIGN_NEUTRAL 	},

    { "Santorum", "Lord High God, Keeper of Knowledge", ALIGN_NEUTRAL 	},

    { "Sedlashek", "Prince of Chaos" , 			ALIGN_NEUTRAL	},
    { "Taihr", "Mother Nature"	 , 			ALIGN_NEUTRAL	},
    { "Lanthanam", "Father Time", 			ALIGN_NEUTRAL	},
    { "Dasche", "Messenger of the Gods"	, 		ALIGN_NEUTRAL	},
    { "Ivetherutte", "Goddess of the Heavens",		ALIGN_NEUTRAL	},

    { "Jaboc", "Watcher of Mortal Souls",		ALIGN_GOOD	},
    { "Druim Cett", "Prince of Valor", 			ALIGN_GOOD	},
    { "Hijanisha", "Lord of Honor", 			ALIGN_GOOD	},
    { "Kajeda", "Daughter of Rivers and Seas", 		ALIGN_GOOD 	},
    { "Danaes", "Goddess of Healing",			ALIGN_GOOD	},

    { "Tarlov", "Prince of Deceit"	, 		ALIGN_EVIL	},
    { "Potiphor", "Source of Greed",			ALIGN_EVIL	},
    { "Chaslith", "Lord of Shadows", 			ALIGN_EVIL	},
    { "Noxulitul", "Watchman of the Dead",		ALIGN_EVIL	},
    { "Solcombe", "Fallen Angel, Custodian of the River Magarcanus", ALIGN_EVIL	},
    { NULL		}
};

/* for sex */
const struct sex_type sex_table[] =
{
   {	"none"		},
   {	"male"		},
   {	"female"	},
   {	"either"	},
   {	NULL		}
};

/* for sizes */
const struct size_type size_table[] =
{ 
    {	"tiny"		},
    {	"small" 	},
    {	"medium"	},
    {	"large"		},
    {	"huge", 	},
    {	"giant" 	},
    {	NULL		}
};

/* various flag tables */
const struct flag_type cmd_flags[] =
{
	{	"Global Channels",		CMD_CHAN_GLOBAL,	FALSE	},
	{	"Local Channels",		CMD_CHAN_LOCAL,		FALSE	},
	{	"Channel Options",		CMD_CHAN_OPTION,	FALSE	},
	{	"Spools",				CMD_SPOOL,			FALSE	},
	{	"Spool Control",		CMD_SPOOL_CONTROL,	FALSE	},
	{	"Violations",			CMD_SPOOL_VIOLATION,FALSE	},
	{	"Roundtables",			CMD_ROUNDTABLE,		FALSE	},
	{	"Skills",				CMD_SKILL,			FALSE	},
	{	"Combat",				CMD_COMBAT,			FALSE	},
	{	"Magic",				CMD_MAGIC,			FALSE	},
	{	"Options",				CMD_OPTION,			FALSE	},
	{	"NPC Interaction",		CMD_NPC_INTERACTION,FALSE	},
	{	"Tradeskills",			CMD_TRADESKILL,		FALSE	},
	{	"In-Game Information",	CMD_INFO_INGAME,	FALSE	},
	{	"Object Information",	CMD_INFO_OBJECT,	FALSE	},
	{	"Character Information",CMD_INFO_CHAR,		FALSE	},
	{	"HoC Information",		CMD_INFO_HOC,		FALSE	},
	{	"World Interaction",	CMD_WORLD,			FALSE	},
	{	"Object Interaction",	CMD_WORLD_OBJECT,	FALSE	},
	{	"Door Interaction",		CMD_WORLD_DOOR,		FALSE	},
	{	"Equipment Interaction",CMD_WORLD_EQUIP,	FALSE	},
	{	"Character Positions",	CMD_WORLD_POS,		FALSE	},
	{	"Character Control",	CMD_CHAR,			FALSE	},
	{	"Group",				CMD_GROUP,			FALSE	},
	{	"Guild",				CMD_GUILD,			FALSE	},
	{	"Miscellaneous",		CMD_MISC,			FALSE	},
	{	NULL,					0,					FALSE	}
};

const struct flag_type wizcmd_flags[] =
{
    {   "Game Control",         WIZCMD_GAME_CONTROL,    FALSE   },
    {   "Game Information",     WIZCMD_GAME_INFO,       FALSE   },
    {   "Player Punishments",   WIZCMD_PUNISHMENTS,     FALSE   },
    {   "Site Punishments",     WIZCMD_SITE_PUNISHMENTS,FALSE   },
    {   "Guild Control",        WIZCMD_GUILD,           FALSE   },
    {   "Spools",               WIZCMD_SPOOLS,          FALSE   },
    {   "Channels",             WIZCMD_CHANNELS,        FALSE   },
    {   "Customer Service",     WIZCMD_CUSTOMER_SERVICE,FALSE   },
    {   "Visibility",           WIZCMD_VISIBILITY,      FALSE   },
    {   "Snoop Commands",       WIZCMD_SNOOP_COMMANDS,  FALSE   },
    {   "Echos",                WIZCMD_ECHOS,           FALSE   },
    {   "Server Settings",      WIZCMD_SERVER_SETTINGS, FALSE   },
    {   "Server Info",          WIZCMD_SERVER_INFO,     FALSE   },
    {   "Server Control",       WIZCMD_SERVER_CONTROL,  FALSE   },
    {   "File Generation",      WIZCMD_FILE_GENERATION, FALSE   },
    {   "Miscellaneous",        WIZCMD_MISC,            FALSE   },
	{	NULL,					0,					    FALSE	}
};

const struct flag_type act_flags[] =
{
    {	"npc",			A,	FALSE	},
    {	"sentinel",		B,	TRUE	},
    {	"scavenger",	C,	TRUE	},
	{	"teleporter",	bb,	TRUE	},
    {   "banker",		D,	TRUE	},
	{   "guard",		E,	TRUE	},
	{	"registrar",	L,	TRUE	},
    {	"aggressive",	F,	TRUE	},
    {	"stay_area",	G,	TRUE	},
    {	"wimpy",		H,	TRUE	},
    {	"pet",			I,	TRUE	},
    {	"train",		J,	TRUE	},
    {   "yell",         ACT_YELL,   TRUE }, /* yell for help when dying */
	{	"noexp",		N,	TRUE	},
    {	"noalign",		U,	TRUE	},
    {	"nopurge",		V,	TRUE	},
    {	"outdoors",		W,	TRUE	},
    {	"indoors",		Y,	TRUE	},
    {   "no-class",     Z,  TRUE    },
    {	"healer",		aa,	TRUE	},
    {	"update_always",cc,	TRUE	},
    {	"smithy",		dd,	TRUE	},
    {	NULL,			0,	FALSE	}
};

const struct flag_type plr_flags[] =
{
    {	"npc",			A,	FALSE	},
    {	"autoassist",		C,	FALSE	},
    {	"autoexit",		D,	FALSE	},
    {	"autoloot",		E,	FALSE	},
    {	"autosac",		F,	FALSE	},
    {	"autogold",		G,	FALSE	},
    {	"autosplit",		H,	FALSE	},
    {	"holylight",		N,	FALSE	},
	{	"nowake",		O,	FALSE	},
    {	"can_loot",		P,	FALSE	},
    {	"nosummon",		Q,	FALSE	},
    {	"nofollow",		R,	FALSE	},
    {	"permit",		U,	TRUE	},
    {	"log",			W,	FALSE	},
    {	"deny",			X,	FALSE	},
    {	"freeze",		Y,	FALSE	},
    {	"thief",		Z,	FALSE	},
    {	"killer",		aa,	FALSE	},
	{	"builder",		bb, TRUE	},
	{	"teamlead",		 J, TRUE	},
    {	NULL,			0,	0	}
};

const struct flag_type affect_flags[] =
{
    {	"blind",		A,	TRUE	},
    {	"invisible",		B,	TRUE	},
    {	"detect_evil",		C,	TRUE	},
    {	"detect_invis",		D,	TRUE	},
    {	"detect_magic",		E,	TRUE	},
    {	"detect_hidden",	F,	TRUE	},
    {	"detect_good",		G,	TRUE	},
    {	"faerie_fire",		I,	TRUE	},
    {	"infrared",		J,	TRUE	},
    {	"curse",		K,	TRUE	},
    {	"poison",		M,	TRUE	},
    {	"protect_evil",		N,	TRUE	},
    {	"protect_good",		O,	TRUE	},
    {	"sneak",		P,	TRUE	},
    {	"hide",			Q,	TRUE	},
    {	"sleep",		R,	TRUE	},
    {	"charm",		S,	TRUE	},
    {	"flying",		T,	TRUE	},
    {	"pass_door",		U,	TRUE	},
    {	"haste",		V,	TRUE	},
    {	"calm",			W,	TRUE	},
    {	"plague",		X,	TRUE	},
    {	"weaken",		Y,	TRUE	},
    {	"dark_vision",		Z,	TRUE	},
    {	"berserk",		aa,	TRUE	},
    {	"swim",			bb,	TRUE	},
    {	"regeneration",		cc,	TRUE	},
    {	"slow",			dd,	TRUE	},
    {	NULL,			0,	0	}
};

const struct flag_type off_flags[] =
{
    {	"area_attack",	A,	TRUE	},
    {	"backstab",		B,	TRUE	},
    {	"bash",			C,	TRUE	},
    {	"berserk",		D,	TRUE	},
    {	"disarm",		E,	TRUE	},
    {	"dodge",		F,	TRUE	},
    {	"fade",			G,	TRUE	},
    {	"kick",			I,	TRUE	},
    {	"parry",		K,	TRUE	},
    {	"rescue",		L,	TRUE	},
    {	"trip",			N,	TRUE	},
	{	"draintouch",	V,	TRUE	},
    {	"assist_all",	P,	TRUE	},
    {	"assist_align",	Q,	TRUE	},
    {	"assist_race",	R,	TRUE	},
    {	"assist_players",	S,	TRUE	},
    {	"assist_guard",	T,	TRUE	},
    {	"assist_vnum",	U,	TRUE	},
	{	"assist_faction",	W,  TRUE	},
    {	NULL,			0,	0	}
};

const struct flag_type imm_flags[] =
{
    {	"summon",		A,	TRUE	},
    {	"magic",		B,	TRUE	},
    {	"weapon",		C,	TRUE	},
    {	"charm",		D,	TRUE	},
    {	NULL,			0,	0	}
};

const struct flag_type form_flags[] =
{
    {	"edible",		FORM_EDIBLE,		TRUE	},
    {	"poison",		FORM_POISON,		TRUE	},
    {	"magical",		FORM_MAGICAL,		TRUE	},
    {	"instant_decay",	FORM_INSTANT_DECAY,	TRUE	},
    {	"has_hide",		FORM_HAS_HIDE,		TRUE	},
    {	"blessed",		FORM_BLESSED,		TRUE	},
    {	"unholy",		FORM_UNHOLY,		TRUE	},
    {	"constructed",	FORM_CONSTRUCTED,		TRUE	},
    {	"intangible",		FORM_INTANGIBLE,	TRUE	},
	{	"undead",		FORM_UNDEAD,	TRUE	},
	{	"animal",		FORM_ANIMAL,	TRUE	},
	{	"humanoid",		FORM_HUMANOID,	TRUE	},
	{	"plant",		FORM_PLANT,		TRUE	},
	{	"summoned",		FORM_SUMMONED,	TRUE	},
	{	"extra-planer",	FORM_EXTRAPLANER, TRUE	},
	{   "gilled",		FORM_GILLS, TRUE },
	{ 	"vis-night",	FORM_VIS_NIGHT, TRUE },
    {	NULL,			0,			0	}
};

const struct flag_type part_flags[] =
{
    {	"head",			PART_HEAD,		TRUE	},
    {	"arms",			PART_ARMS,		TRUE	},
    {	"legs",			PART_LEGS,		TRUE	},
    {	"heart",		PART_HEART,		TRUE	},
    {	"brains",		PART_BRAINS,		TRUE	},
    {	"guts",			PART_GUTS,		TRUE	},
    {	"hands",		PART_HANDS,		TRUE	},
    {	"feet",			PART_FEET,		TRUE	},
    {	"fingers",		PART_FINGERS,		TRUE	},
    {	"ear",			PART_EAR,		TRUE	},
    {	"eye",			PART_EYE,		TRUE	},
    {	"long_tongue",		PART_LONG_TONGUE,	TRUE	},
    {	"eyestalks",		PART_EYESTALKS,		TRUE	},
    {	"tentacles",		PART_TENTACLES,		TRUE	},
    {	"fins",			PART_FINS,		TRUE	},
    {	"wings",		PART_WINGS,		TRUE	},
    {	"tail",			PART_TAIL,		TRUE	},
    {	"claws",		PART_CLAWS,		TRUE	},
    {	"fangs",		PART_FANGS,		TRUE	},
    {	"horns",		PART_HORNS,		TRUE	},
    {	"scales",		PART_SCALES,		TRUE	},
    {	"tusks",		PART_TUSKS,		TRUE	},
    {	NULL,			0,			0	}
};

const struct flag_type comm_flags[] =
{
    {	"quiet",		COMM_QUIET,		TRUE	},
    {   "deaf",			COMM_DEAF,		TRUE	},
    {   "nowiz",		COMM_NOWIZ,		TRUE	},
    {   "noclangossip",	COMM_NOAUCTION,		TRUE	},
    {   "nogossip",		COMM_NOGOSSIP,		TRUE	},
    {   "noquestion",	COMM_NOQUESTION,	TRUE	},
    {   "nomusic",		COMM_NOMUSIC,		TRUE	},
    {   "noclan",		COMM_NOCLAN,		TRUE	},
    {   "noshouts",		COMM_NOSHOUT,		TRUE	},
    {   "no_ooc",		COMM_NOOOC,		TRUE	},
    {   "telnet_ga",	COMM_TELNET_GA,		TRUE	},
    {   "nograts",		COMM_NOGRATS,		TRUE	},
    {   "noemote",		COMM_NOEMOTE,		FALSE	},
    {   "noshout",		COMM_NOSHOUT,		FALSE	},
    {   "notell",		COMM_NOTELL,		FALSE	},
    {   "nochannels",	COMM_NOCHANNELS,	FALSE	},
    {   "snoop_proof",	COMM_SNOOP_PROOF,	FALSE	},
    {   "afk",			COMM_AFK,		TRUE	},
    {	NULL,			0,			0	}
};

const struct dam_flag_conv damage_flag_convert[] =
{
    { DAM_NONE,           0 	},
    { DAM_BASH,           RESIST_CONCUSSION	},
    { DAM_PIERCE,         RESIST_PIERCE	},
    { DAM_SLASH,          RESIST_SLASH },
    { DAM_FIRE,           RESIST_FIRE },
    { DAM_COLD,           RESIST_ICE },
    { DAM_LIGHTNING,      RESIST_ELECTRICITY },
    { DAM_ACID,           RESIST_ACID },
    { DAM_POISON,         RESIST_POISON },
    { DAM_EARTH,          RESIST_EARTH },
    { DAM_AIR,            RESIST_AIR },
    { DAM_MENTAL,         RESIST_MENTAL },
    { DAM_DISEASE,        RESIST_DISEASE },
    { DAM_DARK,           RESIST_DARK },
    { DAM_WATER,          RESIST_WATER },
    { DAM_LIGHT,          RESIST_LIGHT },
    { DAM_SOUND,          RESIST_SOUND },
    { DAM_SPIRIT,         RESIST_SPIRIT },
	{ DAM_BODY,			  RESIST_BODY },
    { DAM_OTHER,          0 },
    { -1,               	-1 }
};

const char *usage_name [ MAX_USAGE ] =
{
	"hourly",
	"daily",
	"weekly",
	"monthly"
};

const char *con_state[29] =
{
	"Playing",
 	"GetName",
	"GetPass",
	"NewName",
	"NewPass",
	"ConfPwd",
	"GetRace",
	"GetSex ",
	"GetClas",
	"GetAlig",
	"DefChoi",
	"GenGrp ",
	"Weapon ",
	"IMOTD  ",
	"MOTD   ",
    "BrkCon ",
	"GetPara",
	"GetPath",
	"RiteWay",
	"Color? ",
	"ImpStat",
	"HowMuch",
	"Menu   ",
	"NewName",
	"GuiChk ",
	"PCIW   ",
	"Poll   ",
	"Specify",
};

const char *rolename[] =
{
	"Developer",
	"Coder",
	"Admin",
	"Builder",
	"Ambience"
};

const int building_table[MAX_BUILDING][2] =
{
	{ -1, -1 },//generic
 	{ 2500, 5000 },//barracks
	{ -1,   2500 },//smithy
 	{ 2000, 4000 },//woodsmith
 	{ 5000,10000 },//magelab
 	{ 5000,10000 },//sanctum
 	{ 1500,3000 },//watchtower
 	{ 2000,4000 },//wall
 	{ 2500,5000 },//
};

// Specialization titles
const char *specTitle[] =
{
    "Trained",          // unspecialized
    "Proficient",       // Rank 1
    "Gifted",           // Rank 2
    "Talented",         // Rank 3
    "Accomplished",     // Rank 4
    "Illustrious",      // Rank 5
    "Masterful",        // Rank 6
    "Legendary",        // Rank 7!
};

