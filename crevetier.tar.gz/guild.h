#ifndef guild_h
#define guild_h

#define GUILD_START_SIZE 4

/* makeguild */
struct make_guild
{
    char            *name;
    Character       *leader;
    bool            approve[GUILD_START_SIZE];
};

/* player guilds */
struct rank_data
{
    char    *name;
    long    flags;
};

#define MAX_GUILD_RANK    9
struct clan_data
{
    Clan        *next;
    char        *name;
    char        *password;
    Rank        ranks[MAX_GUILD_RANK];
    long        guild_points;
    int         total_players;
    long        banked[MAX_CURRENCY];
    time_t      founded;
    char        *founder;
    long        flags;
    int         hall;
};

#define    CLAN_IS_INDEPENDENT        (A)


// Clan alliancs
#define MAX_ALLIANCE    10
struct alliance_data
{
    char        *name;      // Name of the alliance
    Clan        *owner;     // Clan that owns the alliance
    Clan        *members[MAX_ALLIANCE];
};

/* Guild command structure */
struct gc_type
{
    char    *name;
    void    (*gc_fun)(Character *, char*, char*);
    long    officer_permissions;
};

/* guild command macros */
#define GCOP_DISSOLVE       (A)
#define GCOP_INVITE         (B)
#define GCOP_PASSWORD       (C)
#define GCOP_RANK           (D)
#define GCOP_REMOVE         (E)
#define GCOP_SET            (F)
#define GCOP_USE_GUILDCHAT  (G)
#define GCOP_USE_ALLYCHAT   (H)
#define GCOP_DEPOSIT        (I)
#define GCOP_WITHDRAW       (J)
#define GCOP_CLAIM          (K)
#define GCOP_BUILD          (L)
#define GCOP_DEMOLISH       (M)
#define GCOP_HALL           (N)
#define GCOP_UPGRADE        (O)
#define GCOP_CONVERT        (P)

#define MAX_GUILD_RANK        9

/*
 * Guild command functions.
 */
#define DECLARE_GUILD_FUNCTION(x)   void x ( Character *, char *, char * )
void gc_approve( Character *, char *, char * );
void gc_balance( Character *, char *, char * );
void gc_build( Character *, char *, char * );
void gc_decline( Character *, char *, char * );
void gc_claim( Character *, char *, char * );
void gc_convert( Character *, char *, char * );
void gc_create( Character *, char *, char * );
void gc_refuse( Character *, char *, char * );
void gc_demolish( Character *, char *, char * );
void gc_deposit( Character *, char *, char * );
void gc_dissolv( Character *, char *, char * );
void gc_dissolve( Character *, char *, char * );
void gc_hall( Character *, char *, char * );
void gc_info( Character *, char *, char * );
void gc_invite( Character *, char *, char * );
void gc_join( Character *, char *, char * );
void gc_password( Character *, char *, char * );
void gc_rank( Character *, char *, char * );
void gc_remove( Character *, char *, char * );
void gc_set( Character *, char *, char * );
void gc_top( Character *, char *, char * );
void gc_upgrade( Character *, char *, char * );
void gc_withdraw( Character *, char *, char * );
void gc_who( Character *, char *, char * );

extern              Clan            *clan_table;
extern const struct gc_type guild_command_table [];

#endif /* guild_h */
