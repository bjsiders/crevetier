/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "thoc.h"
#include "recycle.h"
#include "interp.h"
#include "olc.h"
#include "tables.h"
#include "options.h"

char		*last_char = "nobody", *last_cmd = "none";
bool	check_social	( Character *ch, char *command, char *argument );

/*
 * Command logging types.
 */

/*
 * Log-all switch.
 */
bool				fLogAll		= FALSE;


DECLARE_DO_FUN (dummy );
DECLARE_DO_FUN (dummy2);

const struct gc_type guild_command_table [] =
{
    { "approve", 	gc_approve , 	0       },
	{ "balance",	gc_balance , 	0		},
	{ "build",		gc_build , 		GCOP_BUILD },
	{ "claim",		gc_claim ,		GCOP_CLAIM },
    { "convert",    gc_convert ,    GCOP_CONVERT },
    { "create", 	gc_create , 	0       },
	{ "decline",	gc_decline , 	0		},
    { "deposit",    gc_deposit ,    GCOP_DEPOSIT    },
	{ "demolish",	gc_demolish,	GCOP_DEMOLISH	},
	{ "dissolv",	gc_dissolv,		GCOP_DISSOLVE	},
    { "dissolve",   gc_dissolve ,   GCOP_DISSOLVE   },
	{ "refuse",		gc_refuse,		0		},
	{ "hall",		gc_hall,		GCOP_HALL },
    { "info",   	gc_info ,   	0       },
    { "invite", 	gc_invite , 	GCOP_INVITE },
    { "join",   	gc_join ,   	0       },
    { "password",   gc_password ,   GCOP_PASSWORD   },
    { "rank",   	gc_rank ,   	GCOP_RANK   },
    { "remove", 	gc_remove , 	0 },
    { "set",    	gc_set  ,   	GCOP_SET    },
    { "top",    	gc_top  ,   	0       },
	{ "upgrade",	gc_upgrade,		GCOP_UPGRADE },
	{ "who",		gc_who ,		0		},
    { "withdraw",   gc_withdraw,    GCOP_WITHDRAW   },
    { NULL,     NULL,       		0       }
};

const struct rt_type rt_command_table [] =
{
/*Round Table anyone functions*/
	{ "create",			rtc_create ,		RT_CREATE		},
	{ "accept",			rtc_accept ,		RT_CREATE		},
	{ "decline",		rtc_decline ,		RT_CREATE		},
	{ "add",			rtc_add ,			RT_ANYONE       },
	{ "remove",			rtc_remove ,		RT_ANYONE       },
	{ "done",			rtc_done ,			RT_ANYONE       },
	{ "current",		rtc_current ,		RT_ANYONE       },
	{ "list",			rtc_list ,			RT_ANYONE       },
	{ "listall",		rtc_listall ,		RT_ANYONE       },
	{ "exit",			rtc_exit ,			RT_ANYONE       },
/*Round Table leader only functions*/
	{ "passcontrol",	rtc_passcontrol ,	RT_LEADER       },
	{ "logging",		rtc_logging ,		RT_LEADER       },
	{ "invite",			rtc_invite ,		RT_LEADER       },
	{ "squelch",		rtc_squelch ,		RT_LEADER       },
	{ "squelchsub",		rtc_squelchsub ,	RT_LEADER       },
	{ "ordername",		rtc_ordername ,		RT_LEADER       },
	{ "ordernumber",	rtc_ordernumber ,	RT_LEADER       },
	{ "kick",			rtc_kick ,			RT_LEADER       },
	{ "allsquelched",	rtc_allsquelched ,	RT_LEADER       },
	{ "subpresent",		rtc_subpresent ,	RT_LEADER       },
	{ "whoshown",		rtc_whoshown ,		RT_LEADER       },
	{ "autoaccept",		rtc_autoaccept ,	RT_LEADER       },
	{ "showsettings",	rtc_showsettings ,	RT_LEADER       },
	{ NULL,		NULL,						0		}
};

/*
 * Creation table
 */
const struct create_cmd_type create_cmd_table [] =
{
    { "name",   cr_name     },
    { "gender", cr_gender   },
    { "race",   cr_race     },
    { "class",  cr_class    },
    { "deity",  cr_deity    },
    { "weapon", cr_weapon   },
    { "password", cr_password },
    { "cancel", cr_cancel   },
    { "color",  cr_color    },
    { "done",   cr_done     },
    { "help",   cr_help     },
    { "", 0                 },
};

/*
 * Command table.
 */
const	struct	cmd_type	cmd_table	[] =
{
    /*
     * Common movement commands.
     */
    { "north",		do_north,		POS_STANDING,    0,  LOG_NEVER|NOSHOW|NOHIDE|NOSPAM,	CMD_MOVEMENT, NULL, 0 },
    { "east",		do_east,		POS_STANDING,	 0,  LOG_NEVER|NOSHOW|NOHIDE|NOSPAM,	CMD_MOVEMENT, NULL, 0 },
    { "south",		do_south,		POS_STANDING,	 0,  LOG_NEVER|NOSHOW|NOHIDE|NOSPAM,	CMD_MOVEMENT, NULL, 0 },
    { "west",		do_west,		POS_STANDING,	 0,  LOG_NEVER|NOSHOW|NOHIDE|NOSPAM,	CMD_MOVEMENT, NULL, 0 },
    { "up",			do_up,			POS_STANDING,	 0,  LOG_NEVER|NOSHOW|NOHIDE|NOSPAM,	CMD_MOVEMENT, NULL, 0 },
    { "down",		do_down,		POS_STANDING,	 0,  LOG_NEVER|NOSHOW|NOHIDE|NOSPAM,	CMD_MOVEMENT, NULL, 0 },
	{ "dummy",		do_dummy,		POS_DEAD,		 52, LOG_NEVER|NOSHOW|NOHIDE,	CMD_MOVEMENT, NULL, 0 },

    /*
     * Common other commands.
     * Placed here so one and two letter abbreviations work.
     */
    { "at",             do_at,          POS_DEAD,		L6,	LOG_NORMAL,				WIZCMD_MISC, NULL, 0 },
    { "cast",			do_cast,		POS_FIGHTING, 	0,  LOG_NORMAL|NOHIDE,		CMD_MAGIC, NULL, 0 },
    { "cancel", 		do_cancel,		POS_SLEEPING,	0,  LOG_NORMAL,				CMD_MAGIC, NULL, 0 },
	{ "silentcast",	do_silentcast,	POS_FIGHTING,	0,	LOG_NORMAL|NOHIDE },
	{ "qc",				do_quickcast,	POS_FIGHTING,	0,  LOG_NORMAL|NOHIDE,		CMD_MAGIC, NULL, 0 },
	/*{ "pet",			do_pet,			POS_FIGHTING,	0,  LOG_NORMAL|NOHIDE },*/
	{ "bind",			do_bind,		POS_RESTING,	0,	LOG_NORMAL|NOHIDE|NOCHARM, CMD_WORLD, NULL, 0 },
    { "buy",			do_buy,			POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_NPC_INTERACTION, NULL, 0 },
	//{ "build",			do_build,		POS_STANDING,	0,  LOG_NORMAL|NOHIDE },gc command
    { "channels",       do_channels,    POS_DEAD,       0,  LOG_NORMAL|NOCHARM,		CMD_CHAN_GLOBAL, NULL , 0 },
    { "custom",			do_custom,		POS_SLEEPING,   0,  LOG_NORMAL|NOCHARM,		CMD_OPTION, NULL, 0 },
	{ "cut",			do_cut,			POS_STANDING,	0,	LOG_NORMAL|NOHIDE,		CMD_TRADESKILL, NULL, 0 },
    { "exits",			do_exits,		POS_RESTING,	0,  LOG_NORMAL|NOCHARM,		CMD_WORLD, NULL, 0 },
    { "expsplit",		do_expsplit, 	POS_DEAD,		20, LOG_NORMAL|NOCHARM,		CMD_OPTION, NULL, 0 },
    { "xpsplit",    	do_expsplit, 	POS_DEAD,  		20, LOG_NORMAL|NOCHARM|NOSHOW,CMD_OPTION, NULL, 0 },
	{ "get",			do_get,			POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD_OBJECT, NULL, 0 },
    { "goto",           do_goto,        POS_DEAD,       L8, LOG_NORMAL,				WIZCMD_MISC, NULL, 0 },
    { "group",          do_group,       POS_SLEEPING,   0,  LOG_NORMAL|NOCHARM,		CMD_GROUP, NULL, 0 },
    { "guild",			do_guild,		POS_DEAD,		L4, LOG_ALWAYS|NOCHARM,		WIZCMD_GUILD, NULL, 0 },
	/*{ "guildcommand", 	do_guildcommand, POS_SLEEPING, 	0,  LOG_NORMAL|NOCHARM,		CMD_GUILD, NULL, 0 },*/
    { "gc",				do_guildcommand, POS_SLEEPING, 	0,  LOG_NORMAL|NOCHARM, CMD_GUILD, NULL, 0 },
	{ "grename",		do_grename,		POS_DEAD,		L4, LOG_ALWAYS|NOCHARM,		WIZCMD_GUILD, NULL, 0 },
    { "hit",			do_kill,		POS_FIGHTING,	0,  LOG_NORMAL|NOHIDE,		CMD_COMBAT, NULL, 0 },
    { "inventory",		do_inventory,	POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_CHAR, NULL, 0 },
	{ "intercept",		do_intercept,	POS_FIGHTING,	0,  LOG_NORMAL|NOCHARM|NOHIDE, CMD_SKILL, &gsn_intercept, 1 },
	{ "journal",		do_journal,		POS_SLEEPING,	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_CHAR, NULL, 0 },
    { "kill",			do_kill,		POS_FIGHTING,	0,  LOG_NORMAL|NOHIDE,		CMD_COMBAT, NULL, 0 },
    { "look",			do_look,		POS_RESTING,	0,  LOG_NORMAL,				CMD_WORLD, NULL, 0 },
    { "lore",			do_lore,		POS_RESTING,	0,  LOG_NORMAL,				CMD_INFO_OBJECT, NULL, 0 },
	{ "lastlogin",		do_lastlogin,	POS_DEAD,		1,	LOG_NORMAL,				CMD_INFO_CHAR, NULL, 0 },
	{ "lastlevel",		do_lastlevel,	POS_SLEEPING,	0,	LOG_NORMAL,				CMD_INFO_CHAR, NULL, 0 },
	{ "layonhands",		do_layonhands,	POS_STANDING,	0,	LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_lay_on_hands, 1 },
	{ "legsweep",		do_legsweep,	POS_FIGHTING,	0,	LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_body, 5 },
    { "clan",			do_clantalk,	POS_SLEEPING,	0,  LOG_NORMAL,				CMD_CHAN_GLOBAL, NULL , 0 },
	{ "mapspells",		do_mapspells,	POS_SLEEPING,	0,	LOG_NORMAL,				CMD_MAGIC, NULL, 0 },
	{ "mine",			do_mine,		POS_STANDING,	0,	LOG_NORMAL|NOHIDE,		CMD_TRADESKILL, NULL, 0 },
    { "music",          do_music,   	POS_SLEEPING,   0,  LOG_NORMAL,				CMD_CHAN_GLOBAL, NULL , 0 },
    { "order",			do_order,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE|NOCHARM, CMD_WORLD, NULL, 0 },
    { "peek",			do_peek,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD, NULL, 0 },
    { "case",           do_peek,        POS_RESTING,    0,  LOG_NORMAL|NOHIDE,      CMD_WORLD, NULL, 0 },
    { "pledge",         do_pledge,      POS_STANDING,   0,  LOG_NORMAL|NOCHARM,     CMD_OPTION, NULL, 0 },
    { "practice",       do_practice,	POS_SLEEPING,   0,  LOG_NORMAL|NOCHARM,		CMD_INFO_CHAR, NULL, 0 },
	{ "pnet",			do_pnet,		POS_SLEEPING,	0,  LOG_NORMAL|NOCHARM,		CMD_OPTION, NULL, 0 },
    { "rest",			do_rest,		POS_SLEEPING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD_POS, NULL, 0 },
    { "resist",			do_resist,		POS_SLEEPING,	0,	LOG_NORMAL|NOCHARM,		CMD_INFO_CHAR, NULL, 0 },
	{ "respec",			do_respecialize,POS_DEAD,		56, LOG_ALWAYS|NOCHARM,		WIZCMD_CUSTOMER_SERVICE, NULL, 0 },
    { "release",		do_release,		POS_SLEEPING,	0,  LOG_NORMAL,				CMD_MAGIC, NULL, 0 },
	{ "reveal",			do_reveal,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD, NULL, 0 },
	{ "reuse",			do_reuse,		POS_SLEEPING,	0,	LOG_NORMAL|NOCHARM,		CMD_MAGIC, NULL, 0 },
    { "sit",			do_sit,			POS_SLEEPING,   0,  LOG_NORMAL|NOHIDE,		CMD_WORLD_POS, NULL, 0 },
    { "sockets",        do_sockets,		POS_DEAD,       L4, LOG_NORMAL|NOCHARM,		WIZCMD_SERVER_INFO, NULL, 0 },
    { "surname",		do_surname,		POS_SLEEPING,   25, LOG_NORMAL|NOCHARM,		CMD_OPTION, NULL, 0 },
	{ "sum",			do_sum,			POS_SLEEPING,   0,  LOG_NORMAL|NOCHARM,		CMD_MISC, NULL, 0 },
    { "stand",			do_stand,		POS_SLEEPING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD_POS, NULL, 0 },
    { "tell",			do_tell,		POS_SLEEPING,	0,  LOG_NORMAL|NOHIDE,		CMD_CHAN_LOCAL, NULL, 0 },
	{ "teleport",		do_teleport,	POS_STANDING,	0,	LOG_NORMAL|NOHIDE,		CMD_NPC_INTERACTION, NULL, 0 },
    { "unlock",         do_unlock,      POS_RESTING,    0,  LOG_NORMAL|NOHIDE,		CMD_WORLD_DOOR, NULL, 0 },
	/*{ "unpractice",		do_unpractice,	POS_RESTING,	0,	LOG_NORMAL|NOHIDE  },*/
    { "wield",			do_wear,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD_EQUIP, NULL, 0 },
    { "wizhelp",		do_wizhelp,		POS_DEAD,		IM, LOG_NORMAL,				WIZCMD_MISC, NULL, 0 },
    { "worth",			do_worth,		POS_SLEEPING,	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_CHAR, NULL, 0 },

    { "disband",        do_disband,     POS_RESTING,    0,   LOG_NORMAL,			CMD_GROUP, NULL, 0 },
    { "invite",         do_invite,      POS_RESTING,    0,   LOG_NORMAL,			CMD_GROUP, NULL, 0 },

    /*
     * Informational commands.
     */
    { "affects",		do_affects,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_CHAR, NULL, 0 },
	{ "accept",         do_accept,      POS_RESTING,    0,   LOG_NORMAL,			CMD_GROUP, NULL, 0 },
    { "areas",			do_areas,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_INGAME, NULL, 0 },
    { "ask",            do_ask,         POS_SITTING,    0,  LOG_NORMAL|NOHIDE,		CMD_NPC_INTERACTION, NULL, 0 },
    { "auction",        do_auction,     POS_SLEEPING,   0,  LOG_NORMAL,				CMD_CHAN_GLOBAL, NULL , 0 },
	{ "audit",			do_audit,		POS_DEAD,		55, LOG_ALWAYS|NOHIDE|NOCHARM, WIZCMD_FILE_GENERATION, NULL, 0},
	{ "aim",			do_aim,			POS_STANDING,	0,  LOG_NORMAL|NOHIDE,		CMD_COMBAT, NULL, 0 },
	{ "bestiary",		do_bestiary,	POS_RESTING,	0,  LOG_NORMAL,				CMD_SKILL, NULL, 0 },
    { "bug",			do_bug,			POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_SPOOL, NULL, 0 },
    { "changes",		do_changes,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_SPOOL, NULL, 0 },
    { "commands",		do_commands,	POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_HOC, NULL, 0 },
    { "combat",         do_combat,      POS_DEAD,       0,  LOG_NORMAL|NOCHARM,     CMD_INFO_CHAR, NULL, 0 },
    { "compare",		do_compare,		POS_RESTING,	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_OBJECT, NULL, 0 },
    { "consider",		do_consider,	POS_RESTING,	0,  LOG_NORMAL,				CMD_COMBAT, NULL, 0 },
    { "convert",		do_convert,		POS_STANDING, 	0,  LOG_NORMAL|NOHIDE,		CMD_NPC_INTERACTION, NULL, 0 },
	{ "consent",		do_consent,		POS_DEAD,		0,	LOG_ALWAYS,				CMD_OPTION, NULL, 0 },
	{ "concentrate",	do_concentrate,	POS_FIGHTING,	0,  LOG_NORMAL|NOHIDE,		CMD_SKILL, NULL, 0 },
	{ "copy",			do_copy,		POS_RESTING,	0, 	LOG_NORMAL|NOHIDE,		CMD_MAGIC, NULL, 0 },
    { "count",			do_count,		POS_SLEEPING,	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_INGAME, NULL, 0 },
    { "craft",			do_craft,		POS_STANDING,	0,  LOG_NORMAL|NOHIDE,		CMD_TRADESKILL, NULL, 0 },
    { "credits",		do_credits,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_HOC, NULL, 0 },
    { "equipment",		do_equipment,	POS_DEAD,	 	0,  LOG_NORMAL,				CMD_INFO_CHAR, NULL, 0 },
	{ "erase",			do_erase,		POS_RESTING,	0,	LOG_NORMAL,				CMD_MAGIC, NULL, 0 },
    { "examine",		do_examine,		POS_RESTING,	0,  LOG_NORMAL,				CMD_INFO_OBJECT, NULL, 0 },
	{ "factions",		do_factions,	POS_SLEEPING,   0,  LOG_NORMAL|NOCHARM,		CMD_INFO_CHAR, NULL, 0 },
    { "fix",			do_fix,			POS_SLEEPING,	0,  LOG_NORMAL|NOCHARM,		CMD_SPOOL, NULL, 0 },
	{ "finger",			do_finger,		POS_SLEEPING,	0,	LOG_NORMAL|NOCHARM,		CMD_INFO_INGAME, NULL, 0 },
    { "help",			do_help,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_HOC, NULL, 0 },
    { "idea",			do_idea,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_SPOOL, NULL, 0 },
    { "ignore",			do_ignore,		POS_SLEEPING,	0,  LOG_NORMAL|NOCHARM,		CMD_OPTION, NULL, 0 },
    /*{ "info",           do_groups,      POS_SLEEPING,   0,  LOG_NORMAL|NOCHARM,		CMD_INFO_CHAR, NULL, 0 },*/
    { "motd",			do_motd,		POS_DEAD,       0,  LOG_NORMAL|NOCHARM,		CMD_INFO_HOC, NULL, 0 },
    { "news",			do_news,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_SPOOL, NULL, 0 },
    { "abilities",      do_abilities,   POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_CHAR, NULL, 0 },
	{ "palmattack",		do_palmattack,	POS_FIGHTING,	0,	LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_body, 27 },
	{ "paralyze",		do_paralyze,	POS_FIGHTING,	0,	LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_mind, 18 },
	{ "pall",			do_pall,		POS_FIGHTING,	0,	LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_spirit, 47 },
	{ "gamepatch",		do_patch,		POS_DEAD,		0,	LOG_NORMAL|NOCHARM,		CMD_SPOOL, NULL, 0 },
    { "read",			do_read,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE|NOCHARM, CMD_MAGIC, NULL, 0 },
    { "report",			do_report,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_CHAN_LOCAL, NULL, 0 },
	{ "repair",			do_repair,		POS_STANDING,	0,  LOG_NORMAL|NOHIDE,		CMD_TRADESKILL, NULL, 0 },
    { "rules",			do_rules,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_HOC, NULL, 0 },
    { "score",			do_score,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_CHAR, NULL, 0 },
	{ "scribe",			do_scribe,		POS_SITTING,	0,  LOG_NORMAL|NOHIDE,		CMD_MAGIC, NULL, 0 },
    { "skills",			do_skills,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_CHAR, NULL, 0 },
	{ "skin",			do_skin,		POS_STANDING,	0,  LOG_NORMAL|NOHIDE,		CMD_TRADESKILL, NULL, 0 },
    { "socials",		do_socials,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_HOC, NULL, 0 },
	{ "shapeshift",		do_shapeshift,	POS_STANDING,	0,	LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_shapeshifting, 1 },
	{ "showspawns",		do_showspawns,	POS_DEAD,		52,	LOG_NORMAL|NOCHARM,		WIZCMD_GAME_INFO, NULL, 0},
    { "spells",			do_spells,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_CHAR, NULL, 0 },
    { "spool",			do_spool,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_SPOOL_CONTROL, NULL, 0 },
    /*{ "story",			do_story,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_HOC, NULL, 0 },*/
	{ "stockpile",		do_stockpile,	POS_STANDING,	0,	LOG_NORMAL|NOHIDE,		CMD_TRADESKILL, NULL, 0 },
    { "time",			do_time,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_INGAME, NULL, 0 },
    { "timezone",       do_timezone,    POS_SLEEPING,   0,  LOG_NORMAL|NOCHARM,     CMD_OPTION, NULL, 0 },
	{ "todo",			do_todo,		POS_DEAD,		0,	LOG_NORMAL|NOCHARM,		CMD_SPOOL, NULL, 0 },
    { "typo",			do_typo,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_SPOOL, NULL, 0 },
    { "weather",		do_weather,		POS_RESTING,	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_INGAME, NULL, 0 },
    { "who",			do_who,			POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_INGAME, NULL, 0 },
    { "whois",			do_whois,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_INFO_INGAME, NULL, 0 },
    { "wizlist",		do_wizlist,		POS_DEAD,       0,  LOG_NORMAL|NOCHARM,		CMD_INFO_INGAME, NULL, 0 },

    /*
     * Configuration commands.
     */
    { "alia",			do_alia,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM|NOSHOW, CMD_OPTION, NULL, 0 },
    { "alias",			do_alias,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_OPTION, NULL, 0 },
    { "description",	do_description,	POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_OPTION, NULL, 0 },
    { "delet",			do_delet,		POS_DEAD,	 	0,  LOG_ALWAYS|NOCHARM|NOSHOW, CMD_CHAR, NULL, 0 },
    { "delete",			do_delete,		POS_STANDING,	0,  LOG_ALWAYS|NOCHARM,		CMD_CHAR, NULL, 0 },
    { "destro",			do_destro,		POS_RESTING,  	0,  LOG_NORMAL|NOCHARM|NOSHOW, CMD_WORLD_EQUIP, NULL, 0 },
    { "destroy",		do_destroy,		POS_RESTING,	0,  LOG_NORMAL|NOCHARM|NOHIDE, CMD_WORLD_EQUIP, NULL, 0 },
    { "depractice",     do_depractice,  POS_RESTING,    0,  LOG_NORMAL|NOCHARM,     CMD_NPC_INTERACTION, NULL, 0 },
    { "detrain",        do_detrain,     POS_RESTING,    0,  LOG_NORMAL|NOCHARM,     CMD_NPC_INTERACTION, NULL, 0 },
    { "degain",         do_degain,      POS_RESTING,    0,  LOG_NORMAL|NOCHARM,     CMD_NPC_INTERACTION, NULL, 0 },
    { "password",		do_password,	POS_DEAD,	 	0,  LOG_NEVER|NOCHARM,		CMD_CHAR, NULL, 0 },
    { "prompt",			do_prompt,		POS_DEAD,       0,  LOG_NORMAL|NOCHARM,		CMD_OPTION, NULL, 0 },
    { "scroll",			do_scroll,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_OPTION, NULL, 0 },
    { "title",			do_title,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_OPTION, NULL, 0 },
    { "unalias",		do_unalias,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_OPTION, NULL, 0 },
    { "wimpy",			do_wimpy,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_OPTION, NULL, 0 },

    { "cnotes",			do_cnote,		POS_DEAD,		0,  LOG_NORMAL|NOCHARM,		CMD_SPOOL, NULL, 0 },
	{ "signature",		do_signature,	POS_DEAD,		0,	LOG_NORMAL|NOCHARM,		CMD_OPTION, NULL, 0 },
    { "anotes",			do_anote,		POS_DEAD,		52, LOG_NORMAL|NOCHARM,		WIZCMD_SPOOLS, NULL, 0 },
    { "appeal",			do_appeal,		POS_DEAD,		0,  LOG_NORMAL|NOCHARM,		CMD_SPOOL_VIOLATION, NULL, 0 },

	{ "analyze",		do_analyze,		POS_DEAD,		52, LOG_NORMAL,				WIZCMD_GAME_INFO, NULL, 0 },

    /*
     * Communication commands.
     */
    { "afk",			do_afk,			POS_SLEEPING,	0,  LOG_NORMAL|NOCHARM,		CMD_CHAN_OPTION, NULL, 0 },
	{ "away",			do_afk,			POS_SLEEPING,	0,	LOG_NORMAL|NOCHARM,		CMD_CHAN_OPTION, NULL, 0 },
    { "advice",			do_question,	POS_SLEEPING,	0,  LOG_NORMAL,				CMD_CHAN_GLOBAL, NULL , 0 },
    { "deaf",			do_deaf,		POS_DEAD,	  	0,  LOG_NORMAL,				CMD_CHAN_OPTION, NULL, 0 },
    { "emote",			do_emote,		POS_RESTING,	0,  LOG_NORMAL,				CMD_CHAN_LOCAL, NULL, 0 },
    { "pmote",			do_pmote,		POS_RESTING,	0,  LOG_NORMAL,				CMD_CHAN_LOCAL, NULL, 0 },
    { ".",				do_gossip,		POS_SLEEPING,	0,  LOG_NORMAL|NOSHOW,		CMD_CHAN_GLOBAL, NULL , 0 },
    { "gossip",			do_gossip,		POS_SLEEPING,	0,  LOG_NORMAL,				CMD_CHAN_GLOBAL, NULL , 0 },
    { ",",				do_emote,		POS_RESTING,	0,  LOG_NORMAL|NOSHOW,		CMD_CHAN_LOCAL, NULL, 0 },
    { "email",          do_email,       POS_SLEEPING,   0,  LOG_NORMAL,             CMD_OPTION, NULL, 0 },
    { "grats",			do_grats,		POS_SLEEPING,	0,  LOG_NORMAL,				CMD_CHAN_GLOBAL, NULL , 0 },
    { "gtell",			do_gtell,		POS_DEAD,	 	0,  LOG_NORMAL,				CMD_CHAN_LOCAL, NULL, 0 },
    { ";",				do_gtell,		POS_DEAD,	 	0,  LOG_NORMAL|NOSHOW,		CMD_CHAN_LOCAL, NULL, 0 },
    { "note",			do_note,		POS_SLEEPING,	0,  LOG_NORMAL,				CMD_SPOOL, NULL, 0 },
	{ "post",			do_post,		POS_SLEEPING,	0,	LOG_NORMAL,				CMD_SPOOL_CONTROL, NULL, 0 },
    { "ooc",			do_ooctalk,		POS_SLEEPING,	0,  LOG_NORMAL,				CMD_CHAN_GLOBAL, NULL , 0 },
	{ "wizclan",		do_wizclan,		POS_DEAD,		59, LOG_NORMAL,				WIZCMD_CHANNELS, NULL, 0 },
    { "]",	 			do_ooctalk,		POS_SLEEPING,   0,  LOG_NORMAL|NOSHOW,		CMD_CHAN_GLOBAL, NULL , 0 },
	{ "quest",			do_quest,		POS_SLEEPING,	0,	LOG_NORMAL,				CMD_CHAN_GLOBAL, NULL , 0 },
    { "quiet",			do_quiet,		POS_SLEEPING, 	0,  LOG_NORMAL|NOCHARM,		CMD_CHAN_OPTION, NULL, 0 },
    { "reply",			do_reply,		POS_SLEEPING,	0,  LOG_NORMAL|NOCHARM,		CMD_CHAN_LOCAL, NULL, 0 },
    { "replay",			do_replay,		POS_SLEEPING,	0,  LOG_NORMAL|NOCHARM,		CMD_CHAN_OPTION, NULL, 0 },
    { "say",			do_say,			POS_RESTING,	0,  LOG_NORMAL,				CMD_CHAN_LOCAL, NULL, 0 },
    { "'",				do_say,			POS_RESTING,	0,  LOG_NORMAL|NOSHOW,		CMD_CHAN_LOCAL, NULL, 0 },
	{ "system",			do_system,		POS_DEAD,		52, LOG_NORMAL|NOCHARM,		WIZCMD_SPOOLS, NULL, 0 },
    { "unread",			do_unread,		POS_SLEEPING,   0,  LOG_NORMAL|NOCHARM,		CMD_SPOOL_CONTROL, NULL, 0 },
    { "yell",			do_yell,		POS_RESTING,	0,  LOG_NORMAL,				CMD_CHAN_LOCAL, NULL, 0 },
    { "rt",				do_rt,			POS_SLEEPING,	0,	LOG_NORMAL,				CMD_ROUNDTABLE, NULL, 0 },
    { "roundtable",		do_rt,			POS_SLEEPING,	0,	LOG_NORMAL,				CMD_ROUNDTABLE, NULL, 0 },
    { "rtcommand",		do_rtcommand,	POS_SLEEPING,	0,  LOG_NORMAL,				CMD_ROUNDTABLE, NULL, 0 },
    /*{ "roundtablecommand",do_rtcommand,	POS_SLEEPING,	0,  LOG_NORMAL,				CMD_ROUNDTABLE, NULL, 0 },*/
    { "sub",			do_sub,			POS_SLEEPING,	0,  LOG_NORMAL,				CMD_ROUNDTABLE, NULL, 0 },

    /*
     * Object manipulation commands.
     */
    /*{ "brandish",		do_brandish,	POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_MAGIC, NULL, 0 },*/
    { "close",			do_close,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD_DOOR, NULL, 0 },
    { "climb",          do_climb,       POS_STANDING,   0,  LOG_NORMAL|NOHIDE,      CMD_MOVEMENT, NULL, 0 },
    { "drink",			do_drink,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD, NULL, 0 },
    { "drop",			do_drop,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD_OBJECT, NULL, 0 },
    { "eat",			do_eat,			POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD, NULL, 0 },
    { "envenom",		do_envenom,		POS_STANDING,	0,  LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_envenom, 1 },
    { "enemy",          do_enemy,       POS_RESTING,    0,  LOG_NORMAL|NOCHARM,     CMD_NPC_INTERACTION, NULL, 0 },
    { "fill",			do_fill,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD, NULL, 0 },
    { "give",			do_give,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD_OBJECT, NULL, 0 },
    { "heal",			do_heal,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_NPC_INTERACTION, NULL, 0 },
    { "hold",			do_wear,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD_EQUIP, NULL, 0 },
    { "jump",           do_jump,        POS_STANDING,   0,  LOG_NORMAL|NOHIDE,      CMD_MOVEMENT, NULL, 0 },
    { "list",			do_list,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE|NOCHARM, CMD_NPC_INTERACTION, NULL, 0 },
	{ "library",		do_library,		POS_DEAD,		0,  LOG_NORMAL|NOCHARM,		CMD_INFO_INGAME, NULL, 0 },
    { "lock",			do_lock,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD_DOOR, NULL, 0 },
    { "open",			do_open,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD_DOOR, NULL, 0 },
	{ "options",		do_options,		POS_SLEEPING,	0,  LOG_NORMAL|NOCHARM,		CMD_OPTION, NULL, 0 },
    { "pick",			do_pick,		POS_STANDING,	0,  LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_open_lock, 1 },
    { "pour",			do_pour,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD, NULL, 0 },
	{ "push",			do_push,		POS_STANDING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD, NULL, 0 },
    { "put",			do_put,			POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD_OBJECT, NULL, 0 },
    /*{ "quaff",			do_quaff,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_MAGIC, NULL, 0 },*/
    /*{ "recite",			do_recite,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_MAGIC, NULL, 0 },*/
    { "remove",			do_remove,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD_EQUIP, NULL, 0 },
    { "sell",			do_sell,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_NPC_INTERACTION, NULL, 0 },
    { "take",			do_get,			POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD_OBJECT, NULL, 0 },
    { "sacrifice",		do_sacrifice,	POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD, NULL, 0 },
    { "value",			do_value,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE|NOCHARM, CMD_INFO_OBJECT, NULL, 0 },
    { "wear",			do_wear,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD_EQUIP, NULL, 0 },
    /*{ "zap",			do_zap,			POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_MAGIC, NULL, 0 },*/
	{ "zgui",			do_zgui,		POS_SLEEPING,	0,	LOG_NORMAL|NOCHARM|NOSHOW, CMD_OPTION, NULL, 0 },

    /*
     * Combat commands.
     */
    { "backstab",		do_backstab,	POS_FIGHTING,	0,  LOG_NORMAL,				CMD_SKILL, &gsn_backstab, 1 },
    { "bash",			do_bash,		POS_FIGHTING,   0,  LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_bash, 1 },
    { "bs",				do_backstab,	POS_FIGHTING,	0,  LOG_NORMAL|NOSHOW,		CMD_SKILL, &gsn_backstab, 1 },
    { "berserk",		do_berserk,		POS_FIGHTING,	0,  LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_berserk, 1 },
    { "dirt",			do_dirt,		POS_FIGHTING,	0,  LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_dirt, 1 },
    { "disarm",			do_disarm,		POS_FIGHTING,	0,  LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_disarm, 1 },
	{ "distract",		do_distract,	POS_FIGHTING,	0,	LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_chicanery, 1 },
    { "flee",			do_flee,		POS_FIGHTING,	0,  LOG_NORMAL|NOHIDE,		CMD_COMBAT, NULL, 0 },
    { "kick",			do_kick,		POS_FIGHTING,	0,  LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_kick, 1 },
	{ "kistrike",		do_kistrike,	POS_FIGHTING,	0,	LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_mind, 51 },
    { "murde",			do_murde,		POS_FIGHTING,	0,  LOG_NORMAL|NOHIDE|NOSHOW,CMD_COMBAT, NULL, 0 },
    { "murder",			do_murder,		POS_FIGHTING,	5,  LOG_ALWAYS|NOHIDE,		CMD_COMBAT, NULL, 0 },
    { "rescue",			do_rescue,		POS_FIGHTING,	0,  LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_rescue, 1 },
    { "trip",			do_trip,		POS_FIGHTING,   0,  LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_trip, 1 },

    /*
     * Miscellaneous commands.
     */
    { "enter", 			do_enter, 		POS_STANDING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD, NULL, 0 },
	{ "firstaid",		do_first_aid,	POS_STANDING,	0,  LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_first_aid, 1 },
	{ "firewithin",		do_firewithin,	POS_STANDING,	0,	LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_spirit, 3 },
	{ "mending",		do_mending,		POS_STANDING,	0,	LOG_NORMAL|NOHIDE,		CMD_SKILL, &gsn_body, 38 },
    { "follow",			do_follow,		POS_RESTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD, NULL, 0 },
    { "focus",          do_focus,       POS_STANDING,   0,  LOG_NORMAL|NOHIDE|NOCHARM,CMD_SKILL, NULL, 0 },
    { "gain",			do_gain,		POS_STANDING,	0,  LOG_NORMAL|NOHIDE,		CMD_NPC_INTERACTION, NULL, 0 },
    /*{ "groups",			do_groups,		POS_SLEEPING,   0,  LOG_NORMAL|NOHIDE,		CMD_INFO_CHAR, NULL, 0 },*/
    /*{ "hide",			do_hide,		POS_STANDING,	0,  LOG_NORMAL|NOHIDE },*/
    { "qui",			do_qui,			POS_DEAD,	 	0,  LOG_NORMAL|NOSHOW|NOCHARM, CMD_CHAR, NULL, 0 },
    { "quit",			do_quit,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_CHAR, NULL, 0 },
    { "recall",			do_recall,		POS_FIGHTING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD, NULL, 0 },
    { "/",				do_recall,		POS_FIGHTING,	0,  LOG_NORMAL|NOSHOW|NOHIDE, CMD_WORLD, NULL, 0 },
    { "rent",			do_rent,		POS_DEAD,	 	0,  LOG_NORMAL|NOSHOW|NOCHARM, CMD_CHAR, NULL, 0 },
	{ "reinforce",		do_reinforce,	POS_STANDING,	0,	LOG_NORMAL|NOHIDE,		CMD_TRADESKILL, NULL, 0 },
    { "save",			do_save,		POS_DEAD,	 	0,  LOG_NORMAL|NOCHARM,		CMD_CHAR, NULL, 0 },
    { "sleep",			do_sleep,		POS_SLEEPING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD_POS, NULL, 0 },
    { "sneak",	 		do_sneak,		POS_STANDING,	0,  LOG_NORMAL,				CMD_SKILL, &gsn_stealth, 1 },
    { "split",			do_split,		POS_RESTING,	0,  LOG_NORMAL|NOCHARM,		CMD_WORLD, NULL, 0 },
    { "steal",			do_steal,		POS_STANDING,	0,  LOG_NORMAL,				CMD_SKILL, &gsn_pick_pocket, 1 },
    { "train",			do_train,		POS_RESTING,	0,  LOG_NORMAL|NOCHARM,		CMD_NPC_INTERACTION, NULL, 0 },
    { "visible",		do_visible,		POS_SLEEPING,	0,  LOG_NORMAL,				CMD_WORLD, NULL, 0 },
    { "wake",			do_wake,		POS_SLEEPING,	0,  LOG_NORMAL|NOHIDE,		CMD_WORLD_POS, NULL, 0 },
    { "scan",			do_scan,		POS_STANDING,	0,  LOG_NORMAL,				CMD_WORLD, NULL, 0 },
    //{ "where",			do_where,		POS_RESTING,	0,  LOG_NORMAL|NOCHARM },
	{ "worldnotes",		do_worldnotes,	POS_SLEEPING,	0,	LOG_NORMAL|NOCHARM|NOSHOW,CMD_SPOOL, NULL, 0 },
	{ "wnotes",			do_worldnotes,	POS_SLEEPING,	0,	LOG_NORMAL|NOCHARM,		CMD_SPOOL, NULL, 0 },
	{ "offlinenotes",	do_offlinenotes, POS_SLEEPING,  0,	LOG_NORMAL|NOCHARM|NOSHOW,	CMD_SPOOL, NULL, 0 },
	{ "olnotes",		do_offlinenotes, POS_SLEEPING,  0,  LOG_NORMAL|NOCHARM,		CMD_SPOOL, NULL, 0 },


	{ "tlr",			do_tlr,			POS_SLEEPING,	0,	LOG_NORMAL|NOCHARM,		CMD_SPOOL, NULL, 0 },

    /*
     * Immortal commands.
     */
#if !defined(__ARPENS)
	{ "skiptoleve",				do_ski,			POS_DEAD,		0,  LOG_NEVER, CMD_MISC, NULL, 0 },
	{ "skiptolevel",			do_skip,		POS_DEAD,		0,	LOG_ALWAYS, CMD_MISC, NULL, 0 },
#endif

#if defined(__OLC)
	{ "advance",		do_advance,		POS_DEAD,		56,  LOG_ALWAYS, WIZCMD_MISC, NULL, 0 },
#elif defined(__ARPENS) || defined(__TEST)
    { "advance",		do_advance,		POS_DEAD,		L1,  LOG_ALWAYS, WIZCMD_MISC, NULL, 0 },
#endif
    { "-",				do_admin,		POS_DEAD,		L1,  LOG_NORMAL|NOSHOW, WIZCMD_CHANNELS, NULL, 0 },
    { "admintalk",		do_admin,		POS_DEAD,		L1,  LOG_NORMAL, WIZCMD_CHANNELS, NULL, 0 },
    { "average",		do_average,		POS_DEAD,		L6,  LOG_NORMAL, WIZCMD_GAME_INFO, NULL, 0 },
    { "dump",			do_dump,		POS_DEAD,		L1,  LOG_ALWAYS, WIZCMD_FILE_GENERATION, NULL, 0 },
	{ "dumpspawn",		do_dumpspawn,	POS_DEAD,		L5,  LOG_ALWAYS, WIZCMD_FILE_GENERATION, NULL, 0 },
    { "trust",			do_trust,		POS_DEAD,		L1,  LOG_ALWAYS, WIZCMD_MISC, NULL, 0 },
    { "violate",		do_violate,		POS_DEAD,		L1,  LOG_ALWAYS, WIZCMD_GAME_CONTROL, NULL, 0 },

    { "allow",			do_allow,		POS_DEAD,		L2,  LOG_ALWAYS, WIZCMD_SITE_PUNISHMENTS, NULL, 0 },
    { "ban",			do_ban,			POS_DEAD,		L2,  LOG_ALWAYS, WIZCMD_SITE_PUNISHMENTS, NULL, 0 },
    { "deny",			do_deny,		POS_DEAD,		L1,  LOG_ALWAYS, WIZCMD_PUNISHMENTS, NULL, 0 },
    { "disconnect",		do_disconnect,	POS_DEAD,		L3,  LOG_ALWAYS, WIZCMD_PUNISHMENTS, NULL, 0 },
    { "flag",			do_flag,		POS_DEAD,		L4,  LOG_ALWAYS, WIZCMD_GAME_CONTROL, NULL, 0 },
    { "freeze",			do_freeze,		POS_DEAD,		L4,  LOG_ALWAYS, WIZCMD_PUNISHMENTS, NULL, 0 },
	{ "limits",			do_limits,		POS_DEAD,		L1,  LOG_NORMAL, WIZCMD_SERVER_INFO, NULL, 0 },
    { "permban",		do_permban,		POS_DEAD,		L1,  LOG_ALWAYS, WIZCMD_SITE_PUNISHMENTS, NULL, 0 },
    { "protect",		do_protect,		POS_DEAD,		L1,  LOG_ALWAYS, WIZCMD_SNOOP_COMMANDS, NULL, 0 },
    { "pload",			do_pload,		POS_DEAD,		L2,  LOG_ALWAYS, WIZCMD_MISC, NULL, 0 },
    { "punload",		do_punload,		POS_DEAD,		L2,  LOG_ALWAYS, WIZCMD_MISC, NULL, 0 },
    { "reboo",			do_reboo,		POS_DEAD,		L2,  LOG_NORMAL|NOSHOW, WIZCMD_SERVER_CONTROL, NULL, 0 },
    { "reboot",			do_reboot,		POS_DEAD,		L2,  LOG_ALWAYS, WIZCMD_SERVER_CONTROL, NULL, 0 },
    { "rename",			do_rename,		POS_DEAD,		L6,  LOG_ALWAYS, WIZCMD_CUSTOMER_SERVICE, NULL, 0 },
	{ "reward",			do_reward,		POS_DEAD,		L6,  LOG_ALWAYS, WIZCMD_CUSTOMER_SERVICE, NULL, 0 },
    { "set",			do_set,			POS_DEAD,		L2,  LOG_ALWAYS, WIZCMD_GAME_CONTROL, NULL, 0 },
    { "shutdow",		do_shutdow,		POS_DEAD,		L1,  LOG_NORMAL|NOSHOW, WIZCMD_SERVER_CONTROL, NULL, 0 },
    { "shutdown",		do_shutdown,	POS_DEAD,		L1,  LOG_ALWAYS, WIZCMD_SERVER_CONTROL, NULL, 0 },
    { "wizlock",		do_wizlock,		POS_DEAD,		L2,  LOG_ALWAYS, WIZCMD_SERVER_SETTINGS, NULL, 0 },

    { "force",			do_force,		POS_DEAD,		L7,  LOG_ALWAYS, WIZCMD_GAME_CONTROL, NULL, 0 },
    { "dload",          do_dload,       POS_DEAD,       L2,  LOG_ALWAYS, WIZCMD_MISC, NULL, 0 },
    { "load",			do_load,		POS_DEAD,		L6,  LOG_ALWAYS, WIZCMD_GAME_CONTROL, NULL, 0 },
    { "newlock",		do_newlock,		POS_DEAD,		L4,  LOG_ALWAYS, WIZCMD_SERVER_SETTINGS, NULL, 0 },
    { "nochannels",		do_nochannels,	POS_DEAD,		L5,  LOG_ALWAYS, WIZCMD_PUNISHMENTS, NULL, 0 },
    { "noemote",		do_noemote,		POS_DEAD,		L5,  LOG_ALWAYS, WIZCMD_PUNISHMENTS, NULL, 0 },
    { "noshout",		do_noshout,		POS_DEAD,		L5,  LOG_ALWAYS, WIZCMD_PUNISHMENTS, NULL, 0 },
    { "notell",			do_notell,		POS_DEAD,		L5,  LOG_ALWAYS, WIZCMD_PUNISHMENTS, NULL, 0 },
    { "pecho",			do_pecho,		POS_DEAD,		L4,  LOG_ALWAYS, WIZCMD_ECHOS, NULL, 0 },
    { "pardon",			do_pardon,		POS_DEAD,		L3,  LOG_ALWAYS, WIZCMD_CUSTOMER_SERVICE, NULL, 0 },
	{ "passwd",			do_passwd,		POS_DEAD,		L1,  LOG_ALWAYS, WIZCMD_CUSTOMER_SERVICE, NULL, 0 },
#if defined (__ARPENS)
    { "restore",		do_restore,		POS_DEAD,		L5,  LOG_ALWAYS, WIZCMD_GAME_CONTROL, NULL, 0 },
    { "sla",			do_sla,			POS_DEAD,		L3,  LOG_NORMAL|NOSHOW, WIZCMD_GAME_CONTROL, NULL, 0 },
    { "slay",			do_slay,		POS_DEAD,		L3,  LOG_ALWAYS, WIZCMD_GAME_CONTROL, NULL, 0 },
	{ "purge",			do_purge,		POS_DEAD,		L6,  LOG_ALWAYS, WIZCMD_GAME_CONTROL, NULL, 0 },
#else
    { "purge",          do_purge,       POS_DEAD,        0,  LOG_ALWAYS, CMD_MISC, NULL, 0 },
    { "restore",        do_restore,     POS_DEAD,       L6,  LOG_ALWAYS, WIZCMD_GAME_CONTROL, NULL, 0 },
    { "sla",            do_sla,         POS_DEAD,       L6,  LOG_NORMAL|NOSHOW, WIZCMD_GAME_CONTROL, NULL, 0 },
    { "slay",           do_slay,        POS_DEAD,       L6,  LOG_ALWAYS, WIZCMD_GAME_CONTROL, NULL, 0 },
#endif
    { "transfer",		do_transfer,	POS_DEAD,		L5,  LOG_ALWAYS, WIZCMD_MISC, NULL, 0 },

    { "poofin",			do_bamfin,		POS_DEAD,		L8,  LOG_NORMAL, WIZCMD_VISIBILITY, NULL, 0 },
    { "poofout",		do_bamfout,		POS_DEAD,		L8,  LOG_NORMAL, WIZCMD_VISIBILITY, NULL, 0 },
    { "enablepk",       do_enablepk,    POS_DEAD,       L4,  LOG_ALWAYS, WIZCMD_GAME_CONTROL, NULL, 0 },
    { "enablelooting",  do_enablelooting, POS_DEAD,     L4,  LOG_ALWAYS< WIZCMD_GAME_CONTROL, NULL, 0 },
    { "gecho",			do_echo,		POS_DEAD,		L4,  LOG_ALWAYS, WIZCMD_ECHOS, NULL, 0 },
	{ "hockey",			do_hockey,		POS_DEAD,		0,	 LOG_NORMAL, CMD_CHAN_GLOBAL, NULL, 0 },
    { "incognito",		do_incognito,	POS_DEAD,		IM,  LOG_NORMAL, WIZCMD_VISIBILITY, NULL, 0 },
    { "log",			do_log,			POS_DEAD,		L1,  LOG_ALWAYS, WIZCMD_SNOOP_COMMANDS, NULL, 0 },
    { "memory",			do_memory,		POS_DEAD,		IM,  LOG_NORMAL, WIZCMD_SERVER_INFO, NULL, 0 },
    { "mwhere",			do_mwhere,		POS_DEAD,		IM,  LOG_NORMAL, WIZCMD_GAME_INFO, NULL, 0 },
	{ "hwhere",			do_hwhere,		POS_DEAD,		IM,  LOG_NORMAL, WIZCMD_GAME_INFO, NULL, 0 },
    { "owhere",			do_owhere,		POS_DEAD,		IM,  LOG_NORMAL, WIZCMD_GAME_INFO, NULL, 0 },
    { "peace",			do_peace,		POS_DEAD,		L5,  LOG_NORMAL, WIZCMD_GAME_CONTROL, NULL, 0 },
    { "penalty",		do_penalty,		POS_DEAD,		IM,  LOG_NORMAL, WIZCMD_SPOOLS, NULL, 0 },
    { "echo",			do_recho,		POS_DEAD,		L6,  LOG_ALWAYS, WIZCMD_ECHOS, NULL, 0 },
    { "rtlist",			do_rtlist,		POS_DEAD,		IM,  LOG_NORMAL, WIZCMD_GAME_INFO, NULL, 0 },
    { "return",         do_return,      POS_DEAD,       L6,  LOG_NORMAL, WIZCMD_GAME_CONTROL, NULL, 0 },
    { "snoop",			do_snoop,		POS_DEAD,		L5,  LOG_ALWAYS, WIZCMD_SNOOP_COMMANDS, NULL, 0 },
    { "spellset",		do_spellset,	POS_DEAD,		L2,  LOG_ALWAYS, WIZCMD_GAME_CONTROL, NULL, 0 },
    { "stat",			do_stat,		POS_DEAD,		IM,  LOG_NORMAL, WIZCMD_GAME_INFO, NULL, 0 },
    { "string",			do_string,		POS_DEAD,		L5,  LOG_ALWAYS, WIZCMD_GAME_CONTROL, NULL, 0 },
	{ "styles",			do_styles,		POS_FIGHTING,	 0,  LOG_NORMAL|NOHIDE, CMD_COMBAT, NULL, 0 },
    { "stealth",        do_sneak,       POS_STANDING,   0,  LOG_NORMAL, CMD_SKILL, &gsn_stealth, 1 },
    { "switch",			do_switch,		POS_DEAD,		L6,  LOG_ALWAYS, WIZCMD_GAME_CONTROL, NULL, 0 },
    { "wizinvis",		do_invis,		POS_DEAD,		IM,  LOG_NORMAL, WIZCMD_VISIBILITY, NULL, 0 },
    { "version",		do_version,		POS_DEAD,		0,   LOG_NORMAL, CMD_INFO_HOC, NULL, 0 },
#if defined(__OLC)
    { "vnum",			do_vnum,		POS_DEAD,		52,  LOG_NORMAL, WIZCMD_GAME_INFO, NULL, 0 },
    { "vlist",			do_arealist,	POS_DEAD,		52,  LOG_NORMAL, WIZCMD_GAME_INFO, NULL, 0 },
#else
    { "vnum",			do_vnum,		POS_DEAD,		L6,  LOG_NORMAL, WIZCMD_GAME_INFO, NULL, 0 },
    { "vlist",			do_arealist,	POS_DEAD,		L7,  LOG_NORMAL, WIZCMD_GAME_INFO, NULL, 0 },
#endif
    { "zecho",			do_zecho,		POS_DEAD,		L4,  LOG_ALWAYS, WIZCMD_ECHOS, NULL, 0 },

    { "clone",			do_clone,		POS_DEAD,		L5,  LOG_ALWAYS, WIZCMD_GAME_CONTROL, NULL, 0 },

    { "wiznet",			do_wiznet,		POS_DEAD,		IM,  LOG_NORMAL, WIZCMD_MISC, NULL, 0 },
    { "immtalk",		do_immtalk,		POS_DEAD,		IM,  LOG_NORMAL, WIZCMD_CHANNELS, NULL, 0 },
    { "imotd",          do_imotd,       POS_DEAD,       IM,  LOG_NORMAL, WIZCMD_MISC, NULL, 0 },
    { ":",				do_immtalk,		POS_DEAD,		IM,  LOG_NORMAL|NOSHOW, WIZCMD_CHANNELS, NULL, 0 },
    { "smote",			do_smote,		POS_DEAD,		IM,  LOG_NORMAL, WIZCMD_ECHOS, NULL, 0 },
	{ "precognition",	do_precognition,POS_DEAD,		 1,  LOG_NORMAL|NOHIDE, CMD_SKILL, &gsn_mind, 29 },

    /*
     * OLC
     */

    { "asave",          do_asave,		POS_DEAD,    	52,  LOG_NORMAL, WIZCMD_MISC, NULL, 0 },
#if defined(__OLC)
    { "edit",			do_olc,			POS_DEAD,    	0,  LOG_NORMAL, CMD_MISC, NULL, 0 },
    { "aedit",			do_aedit,		POS_DEAD,    	0,  LOG_NORMAL, CMD_MISC, NULL, 0 },
    { "redit",			do_redit,		POS_DEAD,    	0,  LOG_NORMAL, CMD_MISC, NULL, 0 },
    { "medit",			do_medit,		POS_DEAD,    	0,  LOG_NORMAL, CMD_MISC, NULL, 0 },
	{ "fedit",			do_fedit,		POS_DEAD,		0,  LOG_NORMAL, CMD_MISC, NULL, 0 },
    /*{ "hedit",          do_hedit,       POS_DEAD,    	0,  LOG_NORMAL },*/
    { "oedit",			do_oedit,		POS_DEAD,    	0,  LOG_NORMAL, CMD_MISC, NULL, 0 },
	{ "ready",			do_reset_room,	POS_DEAD,	   52,  LOG_NORMAL, WIZCMD_MISC, NULL, 0 },
	{ "alist",			do_alist,		POS_DEAD,    	0,  LOG_NORMAL, WIZCMD_GAME_INFO, NULL, 0 },
	{ "walkbuild",		do_walkbuild,	POS_DEAD,		52, LOG_NORMAL,	WIZCMD_MISC, NULL, 0 },
    { "openvnum",		do_openvnum,	POS_DEAD,		L7,  LOG_NORMAL, WIZCMD_MISC, NULL, 0 },
	{ "rmap",			do_rmap,		POS_DEAD,		52, LOG_NORMAL, WIZCMD_MISC, NULL, 0 },
#endif
	{ "alist",			do_alist,		POS_DEAD,    	IM,  LOG_NORMAL, CMD_INFO_INGAME, NULL, 0 },
	{ "refres",			do_refres,		POS_DEAD,		58, LOG_NEVER|NOSHOW, WIZCMD_SERVER_CONTROL, NULL, 0 },
	{ "refresh",		do_refresh,		POS_DEAD,		58,	LOG_ALWAYS, WIZCMD_SERVER_CONTROL, NULL, 0 },
	{ "reset",			do_reset,		POS_DEAD,		52,	LOG_NORMAL, WIZCMD_GAME_CONTROL, NULL, 0 },
    { "port",			do_port,		POS_DEAD,    	0,  LOG_NORMAL, CMD_INFO_HOC, NULL, 0 },

 	{ "petitio",        do_petitio,     POS_DEAD,   0,  LOG_NORMAL|NOCHARM|NOSHOW, CMD_SPOOL_VIOLATION, NULL, 0 },
    { "petition",       do_petition,    POS_DEAD,   0,  LOG_NORMAL|NOCHARM, CMD_SPOOL_VIOLATION, NULL, 0 },


    /* 
     * GUI Commands
     */
     { "friend",		do_friend,		POS_DEAD,		0,  LOG_NORMAL|NOCHARM, CMD_OPTION, NULL, 0 },
     { "guiinit",		do_initialize_gui,POS_DEAD,		0,  LOG_NORMAL|NOCHARM|NOSHOW, CMD_OPTION, NULL, 0 },

    /*
     * End of list.
     */
    { "",		0,		POS_DEAD,	 0,  LOG_NORMAL, CMD_MISC, NULL, 0 }
};




/*
 * The main entry point for executing commands.
 * Can be recursively called from 'at', 'order', 'force'.
 */
void interpret( Character *ch, char *argument )
{
    char command[MAX_INPUT_LENGTH];
    char logline[MAX_INPUT_LENGTH];
    int cmd;
    int trust;
    bool found;

    /*
     * Strip leading spaces.
     */
    while ( isspace(*argument) )
		argument++;

    if ( argument[0] == '\0' )
		return;

    /*
     * Implement freeze command.
     */
    if ( !IS_NPC(ch) && IS_SET(ch->act, PLR_FREEZE) )
    {
		send_to_char( "You're totally frozen!\n\r", ch );
		return;
    }

    /*
     * Grab the command word.
     * Special parsing so ' can be a command,
     *   also no spaces needed after punctuation.
     */
    strcpy( logline, argument );
    if ( !isalpha(argument[0]) && !isdigit(argument[0]) )
    {
		command[0] = argument[0];
		command[1] = '\0';
		argument++;
		while ( isspace(*argument) )
	    	argument++;
    }
    else
    {
		argument = one_argument( argument, command );
    }

    /*
     * Look for command in command table.
     */
    found = FALSE;
    trust = get_trust( ch );
    for ( cmd = 0; cmd_table[cmd].name[0] != '\0'; cmd++ )
    {
		if ( command[0] == cmd_table[cmd].name[0]
		&&   !str_prefix( command, cmd_table[cmd].name )
		&&   cmd_table[cmd].level <= trust )
		{
	    	found = TRUE;
	    	break;
		}
    }

	/* If a command is flagged as no spam, reset the spam counter */
	if(IS_SET(cmd_table[cmd].flags,NOSPAM) && ch->desc != NULL)
		ch->desc->repeat = 0;

	/* 
	 * Items set to NOHIDE cannot be done while hiding.
	 * If it's a NOHIDE item and you're HIDING and not SNEAKING,
 	 * you lose your HIDE.
	 */
	//if ( !IS_AFFECTED(ch,AFF_SNEAK) && IS_SET(cmd_table[cmd].flags,NOHIDE) )
		//REMOVE_BIT(ch->affected_by,AFF_HIDE);

    /*
     * Log and snoop.
     */
    if ( IS_SET(cmd_table[cmd].flags,LOG_NEVER) )
		strcpy( logline, "" );

    if ( ( !IS_NPC(ch) && IS_SET(ch->act, PLR_LOG) )
    	|| fLogAll || IS_SET(cmd_table[cmd].flags,LOG_ALWAYS) )
    {
		wizprintf(ch,NULL,WIZ_SECURE,0,get_trust(ch),
            "Log %s: %s", ch->name, logline );
    }

    if ( ch->desc != NULL && ch->desc->snoop_by != NULL )
    {
		write_to_buffer( ch->desc->snoop_by, "% ",    2 );
		write_to_buffer( ch->desc->snoop_by, logline, 0 );
		write_to_buffer( ch->desc->snoop_by, "\n\r",  2 );
    }

    if ( !found )
    {
		/*
	 	* Look for command in socials table.
	 	*/
		if ( !check_social( ch, command, argument ) )
	    	cprintf( ch, "Huh?\n\r" );
		return;
    }

    /*
     * Character not in position for command?
     */
    if ( ch->position < cmd_table[cmd].position )
    {
		switch( ch->position )
		{
		case POS_DEAD:
	    	send_to_char( "Lie still; you are DEAD.\n\r", ch );
	    	break;

		case POS_MORTAL:
		case POS_INCAP:
	    	send_to_char( "You are hurt far too bad for that.\n\r", ch );
	    	break;

		case POS_STUNNED:
	    	send_to_char( "You are too stunned to do that.\n\r", ch );
	    	break;

		case POS_SLEEPING:
	    	send_to_char( "In your dreams, or what?\n\r", ch );
	    	break;

		case POS_RESTING:
	    	send_to_char( "Nah... You feel too relaxed...\n\r", ch);
	    	break;

		case POS_SITTING:
	    	send_to_char( "Better stand up first.\n\r",ch);
	    	break;

		case POS_FIGHTING:
	    	send_to_char( "No way!  You are still fighting!\n\r", ch);
	    	break;

		}
		return;
    }

    /*
     * Dispatch the command.
     */
	last_char = ch->name;
	last_cmd  = cmd_table[cmd].name;

    (*cmd_table[cmd].do_fun) ( ch, argument );

    tail_chain( );
    return;
}

/* function to keep argument safe in all commands -- no static strings */
void do_function (Character *ch, DoFun *do_fun, char *argument)
{
    char *command_string;
    
    /* copy the string */
    command_string = str_dup(argument);
    
    /* dispatch the command */
    (*do_fun) (ch, command_string);
    
    /* free the string */
    free_string(command_string);
}
    
bool check_social( Character *ch, char *command, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Character *victim, *vch;
    int cmd;
    bool found;

    found  = FALSE;
    for ( cmd = 0; social_table[cmd].name[0] != '\0'; cmd++ )
    {
	if ( command[0] == social_table[cmd].name[0]
	&&   !str_prefix( command, social_table[cmd].name ) )
	{
	    found = TRUE;
	    break;
	}
    }

    if ( !found )
	return FALSE;

    if ( !IS_NPC(ch) && IS_SET(ch->comm, COMM_NOEMOTE) )
    {
	send_to_char( "You are anti-social!\n\r", ch );
	return TRUE;
    }

    switch ( ch->position )
    {
    case POS_DEAD:
	send_to_char( "Lie still; you are DEAD.\n\r", ch );
	return TRUE;

    case POS_INCAP:
    case POS_MORTAL:
	send_to_char( "You are hurt far too bad for that.\n\r", ch );
	return TRUE;

    case POS_STUNNED:
	send_to_char( "You are too stunned to do that.\n\r", ch );
	return TRUE;

    case POS_SLEEPING:
	/*
	 * I just know this is the path to a 12" 'if' statement.  :(
	 * But two players asked for it already!  -- Furey
	 */
	if ( !str_cmp( social_table[cmd].name, "snore" ) )
	    break;
	send_to_char( "In your dreams, or what?\n\r", ch );
	return TRUE;

    }

    one_argument( argument, arg );
    victim = NULL;
    if ( arg[0] == '\0' )
    {
//	act( social_table[cmd].others_no_arg, ch, NULL, victim, TO_ROOM    );
//	act( social_table[cmd].char_no_arg,   ch, NULL, victim, TO_CHAR    );
		for( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
		{
			if ( isIgnoring( vch, !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name ) )
			{
				if ( !IS_IMMORTAL(ch) )
				{
					if ( !IS_SET(vch->display,DISP_SUPPRESS_IGNORES) && IS_AWAKE(vch) )
            			cprintf(vch,"&G<&xIgnoring %s: social&G>&x\n\r", !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name );
				}
				else
				{
					act("You bypassed an ignore setting for $N.",ch,NULL,vch,TO_CHAR);
					act( social_table[cmd].others_no_arg, ch, NULL, vch, TO_VICT    );
				}
			}
			else if(vch != ch)
				act( social_table[cmd].others_no_arg, ch, NULL, vch, TO_VICT    );
			else
				act( social_table[cmd].char_no_arg,   ch, NULL, vch, TO_CHAR    );
		}
    }
    else if ( ( victim = get_char_room( ch, arg ) ) == NULL )
    {
		send_to_char( "They aren't here.\n\r", ch );
    }
    else if ( victim == ch )
    {
//	act( social_table[cmd].others_auto,   ch, NULL, victim, TO_ROOM    );
//	act( social_table[cmd].char_auto,     ch, NULL, victim, TO_CHAR    );
		for( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
		{
			if ( isIgnoring( vch, !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name ) )
			{
				if ( !IS_IMMORTAL(ch) )
				{
					if ( !IS_SET(vch->display,DISP_SUPPRESS_IGNORES) && IS_AWAKE(vch) )
            			cprintf(vch,"&G<&xIgnoring %s: social&G>&x\n\r", !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name );
				}
				else
				{
					act("You bypassed an ignore setting for $N.",ch,NULL,vch,TO_CHAR);
					act( social_table[cmd].others_auto,   ch, NULL, vch, TO_VICT    );
				}
			}
			else if(vch != ch)
				act( social_table[cmd].others_auto,   ch, NULL, vch, TO_VICT    );
			else
				act( social_table[cmd].char_auto,     ch, NULL, vch, TO_CHAR    );
		}
    }
    else
    {
	act( social_table[cmd].others_found,  ch, NULL, victim, TO_NOTVICT );
	act( social_table[cmd].char_found,    ch, NULL, victim, TO_CHAR    );
	if ( isIgnoring( victim, !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name ) )
	{
		if ( !IS_IMMORTAL(ch) )
		{
			if ( !IS_SET(victim->display,DISP_SUPPRESS_IGNORES) && IS_AWAKE(victim) )
            	cprintf(victim,"&G<&xIgnoring %s: social&G>&x\n\r", !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name );
		}
		else
		{
			act("You bypassed an ignore setting for $N.",ch,NULL,victim,TO_CHAR);
			act( social_table[cmd].vict_found,    ch, NULL, victim, TO_VICT    );
		}
	}
	else
		act( social_table[cmd].vict_found,    ch, NULL, victim, TO_VICT    );

	if ( !IS_NPC(ch) && IS_NPC(victim)
	&&   !IS_AFFECTED(victim, AFF_CHARM)
	&&   IS_AWAKE(victim) 
	&&   victim->desc == NULL)
	{
	    switch ( number_bits( 4 ) )
	    {
	    case 0:

	    case 1: case 2: case 3: case 4:
	    case 5: case 6: case 7: case 8:
		act( social_table[cmd].others_found,
		    victim, NULL, ch, TO_NOTVICT );
		act( social_table[cmd].char_found,
		    victim, NULL, ch, TO_CHAR    );
		act( social_table[cmd].vict_found,
		    victim, NULL, ch, TO_VICT    );
		break;

	    case 9: case 10: case 11: case 12:
		act( "$n slaps $N.",  victim, NULL, ch, TO_NOTVICT );
		act( "You slap $N.",  victim, NULL, ch, TO_CHAR    );
		act( "$n slaps you.", victim, NULL, ch, TO_VICT    );
		break;
	    }
	}
    }

    return TRUE;
}

/* 
 * Given a string like 14*foo, return 14 and 'foo'
*/
int mult_argument2(char *argument, Character *ch, char *obj_name, 
	Object** container, Character** npc, int* currency, bool* all_items)
{
    char *pdot;
    int number = 1;
	char arg1[MAX_INPUT_LENGTH];
	char arg2[MAX_INPUT_LENGTH];
	char arg3[MAX_INPUT_LENGTH];
	char container_name[MAX_INPUT_LENGTH];
	Character *loop_char = NULL;
	extern Character *find_keeper( Character *ch );

	obj_name[0] = '\0';
	*currency = -1;

	argument = one_argument(argument, arg1);
	argument = one_argument(argument, arg2);
	argument = one_argument(argument, arg3);

	/* Check for merchant */
	if ( ( *npc = find_keeper( ch ) ) == NULL )
	{
		/* Check for banker */
		for(loop_char = ch->in_room->people; loop_char != NULL; loop_char = loop_char->next_in_room)
		{
			if ( IS_NPC(loop_char) && IS_SET(loop_char->act, ACT_BANKER) )
			{
				*npc = loop_char;
				break;
			}
		}
	}
	
	/* Check for coins */
	if(is_number(arg1))
	{
		/* Check for currency type */
		*currency = currency_lookup(arg2);

		return atoi(arg1);
	}

	/* Check for #*obj_name */
    for ( pdot = arg1; *pdot != '\0'; pdot++ )
    {
        if ( *pdot == '*' )
        {
            *pdot = '\0';
            number = atoi( arg1 );
            *pdot = '*';
            strcpy( obj_name, pdot+1 );
			break;
        }
    }

	/* Get object name */
	if(obj_name[0] == '\0')
	{ 
		/* Check for "all" or "all." */
		if(!str_cmp(arg1,"all"))
		{
			*all_items = TRUE;
			/* obj_name will be container or nothing here */
			strcpy(container_name, arg2);
		}
		else if(!str_prefix("all.",arg1))
		{
			*all_items = TRUE;
			/* obj_name will be the object */
			strcpy(obj_name, &arg1[4]);
		}
		else
		{
			/* obj_name will be container, coins, in/from/etc, or nothing here */
			/*if(!strcmp(arg2,"coins"))
				strcpy(obj_name, arg2);
			else*/
				strcpy(obj_name, arg1);
		}
	}
 
	if(!str_cmp(arg2,"from") 
	|| !str_cmp(arg2,"in") 
	|| !str_cmp(arg2,"on"))
	{
		strcpy(container_name, arg3);
	} 
	else if(!strcmp(arg2,"coins"))
	{
		strcpy(obj_name, arg2);
	}
	else
	{
	 	strcpy(container_name,arg2);
	}	

	/* Check for container */
	*container = get_obj_here( ch, container_name );

    /*strcpy( arg, argument );
    return 1;*/
	return number;
}

/*
 * Contributed by Alander.
 */
void do_commands( Character *ch, char *argument )
{
	Buffer *buffer;
    int cmd, cmd_type, level, col = 0;
	Help *pHelp;

	buffer = new_buf();
	bprintf(buffer, "  &W==&x &RCommand Listing&x &W==&x\n\r");

    if(HAS_COLOROPT(ch,COLOR_TOGGLE))
	    bprintf(buffer, "[&RRed&x commands have no help file available]\n\r");
    else
	    bprintf(buffer, "[Commands followed by (&R*&x) have no help file available]\n\r");

	for ( cmd_type = 0; cmd_flags[cmd_type].name != NULL; cmd_type++, col = 0)
	{
		bool found = FALSE;
		char buf[MAX_STRING_LENGTH];

		bprintf(buffer, "\n\r  &W==&x &R%s&x &W==&x\n\r",cmd_flags[cmd_type].name);

    	for ( cmd = 0; cmd_table[cmd].name[0] != '\0'; cmd++ )
    	{
			bool found_help = FALSE;

        	if ( cmd_table[cmd].level <  LEVEL_HERO 
            &&   cmd_table[cmd].level <= get_trust( ch )
			&&   !IS_SET(cmd_table[cmd].flags,NOSHOW)
			&&	 cmd_table[cmd].cmd_category == cmd_flags[cmd_type].bit)
			{
				/* See if we have the skill to use this command */
				if ( !IS_IMMORTAL(ch) && (cmd_table[cmd].gsn_skill != NULL 
				&& get_skill(ch,*(cmd_table[cmd].gsn_skill)) < cmd_table[cmd].skill_level))
				{
					continue;
				}

				found = TRUE;

				/* check for help file */
				for( pHelp = help_first; pHelp != NULL; pHelp = pHelp->next )
				{
					level = (pHelp->level < 0) ? -1 * pHelp->level - 1 : pHelp->level;

					if (level > get_trust(ch) )
						continue;

					if ( is_name( cmd_table[cmd].name, pHelp->keyword ) )
					{
						found_help = TRUE;
						break;
					}
				}

                if(HAS_COLOROPT(ch, COLOR_TOGGLE))
                {
				    if ( !found_help )
                    {
				    	sprintf(buf, "&R%s&x", cmd_table[cmd].name);
					    bprintf(buffer, "%-17s", buf);
                    }
                    else
					    bprintf(buffer, "%-13s", cmd_table[cmd].name);

	    		    if ( ++col % 6 == 0 )
					    bprintf(buffer, "\n\r");
                }
                else
                {
				    if ( !found_help )
				    {
					    sprintf(buf, "%s(&R*&x)", cmd_table[cmd].name);
					    /* Have to use 20 for the str length to count for the color codes */
					    bprintf(buffer, "%-20s", buf);
				    }
			 	    else		
					    bprintf(buffer, "%-16s", cmd_table[cmd].name);

	    		    if ( ++col % 4 == 0 )
					    bprintf(buffer, "\n\r");
                }
			}
    	}

		if(!found)
			bprintf(buffer, "None\n\r");
    	else if( !HAS_COLOROPT(ch,COLOR_TOGGLE) && col % 4 != 0 )
			bprintf(buffer, "\n\r");
    	else if( HAS_COLOROPT(ch,COLOR_TOGGLE) && col % 6 != 0 )
			bprintf(buffer, "\n\r");
	}
 
    if( !HAS_COLOROPT(ch,COLOR_TOGGLE) && col % 4 != 0 )
		bprintf(buffer, "\n\r");
    else if( HAS_COLOROPT(ch,COLOR_TOGGLE) && col % 6 != 0 )
		bprintf(buffer, "\n\r");

	page_to_char(buf_string(buffer),ch);
	free_buf(buffer);
    return;
}

void do_wizhelp( Character *ch, char *argument )
{
	Buffer *buffer;
    int cmd, cmd_type, level, col = 0;
	Help *pHelp;

	buffer = new_buf();
	bprintf(buffer, "  &W==&x &RImmortal Command Listing&x &W==&x\n\r");
	bprintf(buffer, "[Commands followed by (&R*&x) have no help file available]\n\r");

	for ( cmd_type = 0; wizcmd_flags[cmd_type].name != NULL; cmd_type++, col = 0)
	{
		bool found = FALSE;
		char buf[MAX_STRING_LENGTH];

		bprintf(buffer, "\n\r  &W==&x &R%s&x &W==&x\n\r",wizcmd_flags[cmd_type].name);

    	for ( cmd = 0; cmd_table[cmd].name[0] != '\0'; cmd++ )
    	{
			bool found_help = FALSE;

        	if ( cmd_table[cmd].level >=  LEVEL_HERO 
              && cmd_table[cmd].level <= get_trust( ch ) 
			  && !IS_SET(cmd_table[cmd].flags,NOSHOW)
			  && cmd_table[cmd].cmd_category == wizcmd_flags[cmd_type].bit)
			{
				found = TRUE;

				/* check for help file */
				for( pHelp = help_first; pHelp != NULL; pHelp = pHelp->next )
				{
					level = (pHelp->level < 0) ? -1 * pHelp->level - 1 : pHelp->level;

					if (level > get_trust(ch) )
						continue;

					if ( is_name( cmd_table[cmd].name, pHelp->keyword ) )
					{
						found_help = TRUE;
						break;
					}
				}

				if ( !found_help )
				{
					sprintf(buf, "%s(&R*&x)", cmd_table[cmd].name);
					/* Have to use 20 for the str length to count for the color codes */
					bprintf(buffer, "%-20s", buf);
				}
			 	else		
					bprintf(buffer, "%-16s", cmd_table[cmd].name);

	    		if ( ++col % 4 == 0 )
					bprintf(buffer, "\n\r");
			}
    	}

		if(!found)
			bprintf(buffer, "None\n\r");
    	else if( col % 4 != 0 )
			bprintf(buffer, "\n\r");
	}
 
    if ( col % 4 != 0 )
		bprintf(buffer, "\n\r");

	page_to_char(buf_string(buffer),ch);
	free_buf(buffer);
    return;
}


