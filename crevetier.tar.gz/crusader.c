/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/** System Include Files **/
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/** Custom Header Files **/
#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "tables.h"
#include "recycle.h"

void crusader_stat_hit(int sn,int level,Character *ch,Character *victim,int dur,int percent,char *word)
{
	Affect af;
	
	af.where		= TO_AFFECTS;
	af.type			= sn;
	af.level		= level;
	af.duration		= minutes(dur);
	af.location		= APPLY_HIT;
	af.modifier		= max_stat_hit(victim) * percent / 100;
	af.bitvector	= 0;
	af.flags		= 0;
	spellAffectToChar( victim, &af );
	
	actprintf(victim,NULL,NULL,TO_CHAR,"The Symbol of the %s hovers in your vision.",word);
	act("$n is protected by a divine symbol.",victim,NULL,NULL,TO_ROOM);
	return;
}

bool spell_symbol_of_the_chosen(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_stat_hit(sn,level,ch,victim,50,10,"Chosen");
	return TRUE;
}

bool spell_symbol_of_the_blessed(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_stat_hit(sn,level,ch,victim,60,15,"Blessed");
	return TRUE;
}

bool spell_symbol_of_the_sanctified(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_stat_hit(sn,level,ch,victim,70,20,"Sanctified");
	return TRUE;
}

bool spell_symbol_of_the_crusader(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_stat_hit(sn,level,ch,victim,80,25,"Crusader");
	return TRUE;
}

void crusader_defense(int sn,int level,Character *ch,Character *victim,int dur,int ac)
{
	Affect af;
	
	af.where		= TO_AFFECTS;
	af.type			= sn;
	af.level		= level;
	af.duration		= minutes(dur);
	af.location		= APPLY_AC;
	af.modifier		= ac;
	af.bitvector	= 0;
	af.flags		= 0;
	spellAffectToChar( victim, &af );
	
	act("You are protected by $y.",victim,NULL,NULL,TO_CHAR);
	act("$n is protected by $y.",victim,NULL,NULL,TO_ROOM);
	return;
}

bool spell_initiates_defense(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_defense(sn,level,ch,victim,30,10);
	return TRUE;
}

bool spell_acolytes_defense(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_defense(sn,level,ch,victim,42,26);
	return TRUE;
}

bool spell_curates_defense(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_defense(sn,level,ch,victim,54,53);
	return TRUE;
}

bool spell_disciples_defense(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_defense(sn,level,ch,victim,66,83);
	return TRUE;
}

bool spell_vindicators_defense(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_defense(sn,level,ch,victim,78,116);
	return TRUE;
}

bool spell_crusaders_defense(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_defense(sn,level,ch,victim,90,153);
	return TRUE;
}

bool spell_sanctuary(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	Affect af;
	
	af.where		= TO_IMMUNE;
	af.type			= sn;
	af.level		= level;
	af.duration		= seconds(12);
	af.location		= 0;
	af.modifier		= 0;
	af.bitvector	= IMM_WEAPON;
	af.flags		= 0;
	spellAffectToChar(victim,&af);
	af.bitvector	= IMM_MAGIC;
	af.flags		= 0;
	spellAffectToChar(victim,&af);
	
	act("You are held in sanctuary by $y!",ch,NULL,NULL,TO_CHAR);
	act("$n is held in sanctuary by $y!",ch,NULL,NULL,TO_ROOM);
	return TRUE;
}


bool spell_greater_sanctuary(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	Affect af;
	
	af.where		= TO_IMMUNE;
	af.type			= sn;
	af.level		= level;
	af.duration		= seconds(18);
	af.location		= 0;
	af.modifier		= 0;
	af.bitvector	= IMM_WEAPON;
	af.flags		= 0;
	spellAffectToChar(victim,&af);
	af.bitvector	= IMM_MAGIC;
	af.flags		= 0;
	spellAffectToChar(victim,&af);
	
	act("You are held in sanctuary by $y!",ch,NULL,NULL,TO_CHAR);
	act("$n is held in sanctuary by $y!",ch,NULL,NULL,TO_ROOM);
	return TRUE;
}

bool spell_superior_sanctuary(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	Affect af;
	
	af.where		= TO_IMMUNE;
	af.type			= sn;
	af.level		= level;
	af.duration		= seconds(24);
	af.location		= 0;
	af.modifier		= 0;
	af.bitvector	= IMM_WEAPON;
	af.flags		= 0;
	spellAffectToChar(victim,&af);
	af.bitvector	= IMM_MAGIC;
	spellAffectToChar(victim,&af);
	
	act("You are held in sanctuary by $y!",ch,NULL,NULL,TO_CHAR);
	act("$n is held in sanctuary by $y!",ch,NULL,NULL,TO_ROOM);
	return TRUE;
}

void crusader_postcurve_hitbuff(int sn,int level,Character *ch,Character *victim,int dur,int amt,char *word)
{
	Affect af;
	
	af.where		= TO_AFFECTS;
	af.type			= sn;
	af.level		= level;
	af.duration		= minutes(dur);
	af.location		= APPLY_HITROLL;
	af.modifier		= amt;
	af.bitvector	= 0;
	af.flags		= 0;
	spellAffectToChar(victim,&af);
	
	actprintf(victim,NULL,NULL,TO_CHAR,"You are gifted by $y with %s vision!",word);
	if ( victim != ch )
		actprintf(ch,NULL,victim,TO_CHAR,"$N is gifted by $y with %s vision!",word);
		
	return;
}

bool spell_inspired_vision(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_postcurve_hitbuff(sn,level,ch,victim,8,15,"inspired");
	return TRUE;
}

bool spell_blessed_vision(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_postcurve_hitbuff(sn,level,ch,victim,10,50,"blessed");
	return TRUE;
}

bool spell_holy_vision(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_postcurve_hitbuff(sn,level,ch,victim,12,100,"holy");
	return TRUE;
}

bool spell_divine_vision(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_postcurve_hitbuff(sn,level,ch,victim,14,160,"divine");
	return TRUE;
}

bool spell_immortal_vision(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_postcurve_hitbuff(sn,level,ch,victim,16,220,"immortal");
	return TRUE;
}	

void crusader_damage_add(int sn,int level,Character *ch,Character *victim,int dur,int amt)
{
	Affect af;
	
	af.where		= TO_AFFECTS;
	af.type			= sn;
	af.level		= level;
	af.duration		= minutes(dur);
	af.location		= APPLY_DAMROLL;
	af.modifier		= amt;
	af.bitvector	= 0;
	af.flags		= 0;
	spellAffectToChar(victim,&af);
	
	actprintf(victim,NULL,NULL,TO_CHAR,"You swing your weapons with great zeal!");
	actprintf(victim,NULL,NULL,TO_ROOM,"$n swings $s weapons with great zeal!");	
	return;
}

bool spell_initiates_hammer(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_damage_add(sn,level,ch,victim,12,3);
	return TRUE;
}

bool spell_acolytes_hammer(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_damage_add(sn,level,ch,victim,14,7);
	return TRUE;
}

bool spell_curates_hammer(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_damage_add(sn,level,ch,victim,16,12);
	return TRUE;
}

bool spell_disciples_hammer(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_damage_add(sn,level,ch,victim,18,18);
	return TRUE;
}

bool spell_vindicators_hammer(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_damage_add(sn,level,ch,victim,20,25);
	return TRUE;
}

void crusader_str_buff(int sn,int level,Character *ch,Character *victim,int dur,int amt,char *word)
{
	Affect af;
	
	af.where		= TO_AFFECTS;
	af.type			= sn;
	af.level		= level;
	af.duration		= minutes(dur);
	af.location		= APPLY_STR;
	af.modifier		= amt;
	af.bitvector	= 0;
	af.flags		= 0;
	spellAffectToChar(victim,&af);
	
	actprintf(victim,NULL,NULL,TO_CHAR,"You are imbued with angelic %s!",word);
	actprintf(victim,NULL,NULL,TO_ROOM,"$n is imbued with angelic %s!",word);	
	return;
}

bool spell_angelic_potency(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_str_buff(sn,level,ch,victim,20,15,"potency");
	return TRUE;
}

bool spell_angelic_strength(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_str_buff(sn,level,ch,victim,25,35,"strength");
	return TRUE;
}

bool spell_angelic_power(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_str_buff(sn,level,ch,victim,30,55,"power");
	return TRUE;
}

bool spell_angelic_might(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_str_buff(sn,level,ch,victim,35,75,"might");
	return TRUE;
}

bool spell_angelic_furor(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_str_buff(sn,level,ch,victim,40,95,"furor");
	return TRUE;
}

void crusader_con_buff(int sn,int level,Character *ch,Character *victim,int dur,int amt)
{
	Affect af;
	
	af.where		= TO_AFFECTS;
	af.type			= sn;
	af.level		= level;
	af.duration		= minutes(dur);
	af.location		= APPLY_CON;
	af.modifier		= amt;
	af.bitvector	= 0;
	af.flags		= 0;
	spellAffectToChar(victim,&af);
	
	actprintf(victim,NULL,NULL,TO_CHAR,"Your health is bolstered!");
	actprintf(victim,NULL,NULL,TO_ROOM,"$n's health is bolstered!");
	return;
}

bool spell_shrine_of_the_body(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_con_buff(sn,level,ch,victim,20,20);
	return TRUE;
}

bool spell_chapel_of_the_body(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_con_buff(sn,level,ch,victim,25,40);
	return TRUE;
}

bool spell_temple_of_the_body(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_con_buff(sn,level,ch,victim,30,60);
	return TRUE;
}

bool spell_sanctuary_of_the_body(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_con_buff(sn,level,ch,victim,35,80);
	return TRUE;
}

bool spell_cathedral_of_the_body(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_con_buff(sn,level,ch,victim,40,100);
	return TRUE;
}

void crusader_damage_shield(int sn,int level,Character *ch,Character *victim,int dur,int amt)
{
	Affect af;
	
	af.where            = DAMAGE_SHIELD;
    af.level            = level;
    af.type             = sn;
    af.duration         = minutes(dur);
    af.location         = amt;
    af.modifier         = amt;
    af.bitvector        = DAM_SPIRIT;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

	actprintf(victim,NULL,NULL,TO_CHAR,"You are protected by a divine barrier.");
	actprintf(victim,NULL,NULL,TO_CHAR,"$n is protected by a divine barrier.");	
	return;
}

bool spell_initiates_prayer(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_damage_shield(sn,level,ch,victim,8,1);
	return TRUE;
}

bool spell_acolytes_prayer(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_damage_shield(sn,level,ch,victim,11,2);
	return TRUE;
}

bool spell_curates_prayer(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_damage_shield(sn,level,ch,victim,14,5);
	return TRUE;
}

bool spell_disciples_prayer(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_damage_shield(sn,level,ch,victim,17,12);
	return TRUE;
}

bool spell_vindicators_prayer(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_damage_shield(sn,level,ch,victim,20,20);
	return TRUE;
}

void crusader_curse(int sn,int level,Character *ch,Character *victim,int dur,int amt)
{
	Affect af;
	if ( check_saves_spell(ch,victim,SAVE_WILLPOWER,DAM_SPIRIT) )
	{
		act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
		act("You feel weaker for a moment, but the sensation passes.",victim,NULL,NULL,TO_CHAR);
		return;
	}
	
	af.where		= TO_AFFECTS;
	af.type			= sn;
	af.level		= level;
	af.duration		= minutes(dur);
	af.location		= APPLY_DAMROLL;
	af.modifier		= amt;
	af.bitvector	= 0;
	af.flags		= 0;
	spellAffectToChar(victim,&af);
	
	act("$N shivers in terror as $E is cursed by $y.",ch,NULL,victim,TO_CHAR);
	act("You shiver in terror as you are cursed by $y.",ch,NULL,victim,TO_VICT);
	act("$N shivers in terror as $E is cursed by $y.",ch,NULL,victim,TO_NOTVICT);
	return;
}

bool spell_initiates_curse(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_curse(sn,level,ch,victim,2,-5);
	return TRUE;
}

bool spell_acolytes_curse(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_curse(sn,level,ch,victim,3,-10);
	return TRUE;
}

bool spell_curates_curse(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_curse(sn,level,ch,victim,4,-16);
	return TRUE;
}

bool spell_disciples_curse(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_curse(sn,level,ch,victim,5,-23);
	return TRUE;
}

bool spell_vindicators_curse(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_curse(sn,level,ch,victim,6,-35);
	return TRUE;
}

void crusader_purgatory(int sn,int level,Character *ch,Character *victim,int dur,int amt)
{
	Affect af;

	if ( check_saves_spell(ch,victim,SAVE_WILLPOWER,DAM_SPIRIT) )
	{
		act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
		act("You feel vulnerable for a moment, but the sensation passes.",victim,NULL,NULL,TO_CHAR);
		return;
	}
	af.where		= TO_AFFECTS;
	af.type			= sn;
	af.level		= level;
	af.duration		= minutes(dur);
	af.location		= APPLY_SAVE_REFLEX;
	af.modifier		= amt;
	af.bitvector	= 0;
	af.flags		= 0;
	spellAffectToChar(victim,&af);
	af.location		= APPLY_SAVE_WILLPOWER;
	spellAffectToChar(victim,&af);
	af.location		= APPLY_SAVE_FORTITUDE;
	spellAffectToChar(victim,&af);
	
	act("$N is marked for purgatory by $y!",ch,NULL,victim,TO_CHAR);
	act("You are marked for purgatory by $y.",ch,NULL,victim,TO_VICT);
	act("$N is marked for purgatory by $y.",ch,NULL,victim,TO_NOTVICT);
	return;
}

bool spell_purgatory(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_purgatory(sn,level,ch,victim,2,-10);
	return TRUE;
}

bool spell_greater_purgatory(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_purgatory(sn,level,ch,victim,4,-20);
	return TRUE;
}

bool spell_superior_purgatory(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	crusader_purgatory(sn,level,ch,victim,6,-35);
	return TRUE;
}


bool spell_minor_condemnation( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(5),highDam(7));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}


bool spell_major_condemnation( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(10),highDam(14));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_greater_condemnation( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(18),highDam(24));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_superior_condemnation( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(31),highDam(41));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_minor_damnation( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(50),highDam(68));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_major_damnation( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(78),highDam(106));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_greater_damnation( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(117),highDam(159));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_superior_damnation( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(171),highDam(231));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_minor_turn_undead( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    int dam;

    if ( !IS_SET(victim->form,FORM_UNDEAD))
    {
        act("$N is not undead!",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,5,6);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}



bool spell_lesser_turn_undead( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    int dam;

    if ( !IS_SET(victim->form,FORM_UNDEAD))
    {
        act("$N is not undead!",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,10,12);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_turn_undead( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    int dam;

    if ( !IS_SET(victim->form,FORM_UNDEAD))
    {
        act("$N is not undead!",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,18,22);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}
bool spell_greater_turn_undead( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    int dam;

    if ( !IS_SET(victim->form,FORM_UNDEAD))
    {
        act("$N is not undead!",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,31,37);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_minor_dispel_undead( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    int dam;

    if ( !IS_SET(victim->form,FORM_UNDEAD))
    {
        act("$N is not undead!",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,51,61);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_lesser_dispel_undead( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    int dam;

    if ( !IS_SET(victim->form,FORM_UNDEAD))
    {
        act("$N is not undead!",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,80,95);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_dispel_undead( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    int dam;

    if ( !IS_SET(victim->form,FORM_UNDEAD))
    {
        act("$N is not undead!",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,120,144);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_greater_dispel_undead( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    int dam;

    if ( !IS_SET(victim->form,FORM_UNDEAD))
    {
        act("$N is not undead!",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,174,209);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_stunning_flash( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
        act("Your muscles stiffen but then relax again.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n is stunned!",victim,NULL,NULL,TO_ROOM);
    DAZE_STATE(victim,PULSE_PER_SECOND * 4);
    return TRUE;
}


bool spell_stunning_flare( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
        act("Your muscles stiffen but then relax again.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n is stunned!",victim,NULL,NULL,TO_ROOM);
    DAZE_STATE(victim,PULSE_PER_SECOND * 6);
    return TRUE;
}

bool spell_stunning_glare( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
        act("Your muscles stiffen but then relax again.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n is stunned!",victim,NULL,NULL,TO_ROOM);
    DAZE_STATE(victim,PULSE_PER_SECOND * 8);
    return TRUE;
}

bool spell_stunning_halo( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
        act("Your muscles stiffen but then relax again.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n is stunned!",victim,NULL,NULL,TO_ROOM);
    DAZE_STATE(victim,PULSE_PER_SECOND * 9);
    return TRUE;
}

bool spell_stunning_aura( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
    {
        act("Nothing seems to happen.",ch,NULL,NULL,TO_CHAR);
        act("Your muscles stiffen but then relax again.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    act("$n is stunned!",victim,NULL,NULL,TO_ROOM);
    DAZE_STATE(victim,PULSE_PER_SECOND * 10);
    return TRUE;
}


bool spell_word_of_pain( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    int dam;
	SpellIndex* pSpellIndex;
	int skill;

	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		skill = get_skill(ch,*(pSpellIndex->sgsn));
	}
	else
	{
		log_bug("spell_word_of_pain: Spell index not found(%d)",sn);
		return TRUE;
	}

    dam = calcSpellDamage(ch,sn,skill*3,skill*4);

    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_word_of_protection(int sn,int level,Character *ch,void *vo,int target )
{
	Character *victim = (Character *) vo;
	Affect af;
	SpellIndex* pSpellIndex;
	int skill;

	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		skill = get_skill(ch,*(pSpellIndex->sgsn));
	}
	else
	{
		log_bug("spell_word_of_protection: Spell index not found(%d)",sn);
		return TRUE;
	}
	
	af.where		= TO_AFFECTS;
	af.type			= sn;
	af.level		= level;
	af.duration		= seconds(skill * 2);
	af.location		= APPLY_AC;
	af.modifier		= skill * 4;
	af.bitvector	= 0;
	af.flags		= 0;
	spellAffectToChar( victim, &af );
	
	act("You summon forth the immortal protection of $y!",ch,NULL,NULL,TO_CHAR);
	act("$n summons forth the immortal protection of $y!",ch,NULL,NULL,TO_ROOM);
	return TRUE;
}
