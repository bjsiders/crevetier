/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>
#include<unistd.h>
#include<sys/time.h>

#include "thoc.h"
#include "options.h"

extern	bool	cycle;
extern bool	merc_down;

void drainOverflow( int *cur, int max );
void RegenerationCycle( void );
void regen_Stamina( Character * );
void regen_Moves( Character * );
void regen_BaseHits( Character *  );
void regen_StatHits( Character *  );
void regen_Mana( Character *  );

#if defined(__ARPENS)
/*
void *regenThread( void *blank )
{
    pthread_t   my_tid;
    struct timeval	stall;

    my_tid = pthread_self( );
    if( pthread_detach( my_tid ) != 0 )
        log_string("Unable to detach thread %d",my_tid);
    
	log_string("regenThread beginning to cycle");
    RegenerationCycle( );
    return NULL;
}
*/

/* Update all regen once every 3 seconds.
 * Synchronize on our own
 */
#define REGEN_CYCLE_LENGTH  3   /* 3 seconds */
void RegenerationCycle( void )
{
    Character *ch, *ch_next;
    struct timeval  begin;
    struct timeval  end;
    struct timeval  stall;
    long diff_tvusec;
    long diff_tvsec;
    static int ticker;

    gettimeofday( &begin, NULL );

    while ( !merc_down )
    {
	++ticker;

        for ( ch = char_list ; ch != NULL ; ch = ch_next )
        {
            ch_next = ch->next;

            regen_Stamina( ch );
            regen_Moves( ch );
	    	if ( ticker % 5 == 0 )
                regen_BaseHits( ch );
            regen_StatHits( ch );
            regen_Mana( ch );
        }

        /* To change regen cycle, set REGEN_CYCLE_LENGTH to # of seconds */

        gettimeofday( &end, NULL );

        diff_tvsec = (int) begin.tv_sec - end.tv_sec;
        diff_tvusec = (int) begin.tv_usec - end.tv_usec + 1000000 * REGEN_CYCLE_LENGTH;

        while ( diff_tvusec < 0 )
        {
             diff_tvusec += 1000000;
             diff_tvsec -= 1;
        }

        while ( diff_tvusec >= 1000000 )
        {
             diff_tvusec -= 1000000;
             diff_tvsec += 1;
        }

        if ( diff_tvsec > 0 || ( diff_tvsec == 0 && diff_tvusec > 0 ) )
        {
            stall.tv_sec = diff_tvsec;
            stall.tv_usec = diff_tvusec;

            if ( select(0,NULL,NULL,NULL,&stall) < 0 )
            {
                log_error("RegenCycle: stall select");
                exit( 0 );
            }
        }

        gettimeofday( &begin, NULL );
    }
}

#endif

/* We also handle pathing here, as long as we're iterating across all the NPCs */
void regen_update( void )
{
    Character *ch, *ch_next;
    static char ticker;

    for ( ch = char_list ; ch != NULL ; ch = ch_next )
    {
        ch_next = ch->next;

		/* Add healer check here - look for damaged PC's in the
		 * room who may need help.  First cure poisons and disease
		 * spells, and then heal up.
		 */
		if( IS_NPC(ch) && IS_SET(ch->act,ACT_IS_HEALER))
			processNewbieHealer( ch );

        // Check for a special room flag
        if ( ch->in_room != NULL )
        {
            if ( IS_SET(ch->in_room->room_flags,ROOM_SWAMP_GAS))
            {
                SpellIndex *sp;

                if ( (sp = get_spell_index(vnum_swamp_gas)) != NULL )
                {
                    (*(sp->spell_fun))( vnum_swamp_gas, ch->level, ch, (void *) ch, TARGET_CHAR);
                }
            }
            
           if ( IS_SET(ch->in_room->room_flags,ROOM_NOXIOUS))
           {
                SpellIndex *sp;

                if ( (sp = get_spell_index(vnum_noxious_fumes)) != NULL )
                {
                    (*(sp->spell_fun))( vnum_noxious_fumes, ch->level, ch, (void *) ch, TARGET_CHAR);
                }
            }
        }

        regen_Stamina( ch );
        regen_Moves( ch );
        if ( ticker % 10 == 0 )
            regen_BaseHits( ch );
        regen_StatHits( ch );
        regen_Mana( ch );
		if ( !IS_NPC(ch) )
		{
			bool fLast = ch->pcdata->combat_timer;
			ch->pcdata->combat_timer = UMAX(0,ch->pcdata->combat_timer-1);
		
			if ( fLast && ch->pcdata->combat_timer == 0 )
				cprintf(ch,"&gYour combat timer has expired.&x\n\r");
		}

		/* Check for pathing - we only move about 1/3 of the checks */
		if ( IS_NPC(ch) && ch->pathing.index > 0 && number_percent() < 50 && ch->fighting == NULL && ch->pursuit.index == 0 &&
             !IS_AFFECTED(ch,AFF_MESMERIZE) )
		{
			/* Search for latest vnum and move to it if possible.  If not,
			 * log a stranded NPC and clear the pathing information.  Don't
			 * forget to decrement the index!! */
			int i;
			int vnum = ch->pathing.array[--ch->pathing.index]; 
			Exit *e;
			Room *r;

			//ch->pathing.index = 0;
			for( i=0 ; i<6 ; i++ )
			{
  				if ( ( e = ch->in_room->exit[i] ) != NULL && ( r = e->u1.to_room ) != NULL && r->vnum == vnum )
				{
					if ( !move_char( ch, i, TRUE ) )
					{
						log_string("Stranded NPC %d %s in room %d", ch->pIndexData->vnum, ch->short_descr, r->vnum );
						memset( &(ch->pathing), 0, sizeof(ch->pathing) );
					}
					break;
				}
			}	 /* door search */
		} /* NPC pathing */


        if ( ch->in_room != NULL && ch->in_room->sector_type == SECT_MAGMA &&
             !IS_AFFECTED(ch,AFF_FLYING) && !IS_IMMORTAL(ch) )
        {
            // Ouch!  Magma damage!
            act("&RYou are burning alive in the magma flow!&x",ch,NULL,NULL,TO_CHAR);
            damage(ch,ch,ch->stat_hit/2,TYPE_UNDEFINED,DAM_FIRE,0);
        }
    }
    ++ticker;
}

/* Use stamina if in combat.  Otherwise regen 1-8.
 * in 1 minute, you'll regen 20-240 stamina.
 */
void regen_Stamina( Character *ch )
{
    int adj;
	Affect *af;
	int last;

	if ( IS_AFFECTED(ch,AFF_POISON) )
		return;

	if ( ch->stamina > max_stamina(ch))
	{
		drainOverflow( &ch->stamina, max_stamina(ch) );
		return;
	}

/*
    pthread_mutex_lock( &(ch->mutex) );
*/
//    adj = get_curr_stat(ch,STAT_STR) / 3;
//	adj = UMAX(adj,4);

	adj = (3 * get_curr_stat(ch, STAT_STR) / 20) * (ch->level/10 + 2) / 5;

	last = ch->stamina;

    if ( ch->fighting != NULL )
		ch->stamina = UMAX(0,ch->stamina-1);

    switch ( ch->position )
    {
        case POS_SLEEPING: 	adj *= 3; break;
        case POS_RESTING:
        case POS_SITTING: 	adj= adj * 3 / 2;   break;
		case POS_STANDING:  adj = 0;		    break;
		case POS_FIGHTING:  adj = 0;		    break;
		default:			adj = 0;		    break;
    }

	if ( (af = find_affect_type(ch,APPLY_REGEN_STAMINA)) != NULL )
	{
		if(ch->position == POS_FIGHTING)
			adj += af->modifier / 2;
		else
			adj += af->modifier;
	}

	if ( !IS_NPC(ch) && ch->pcdata->subrace == gsn_ashinth )
		adj = 125 * adj / 100;

	if ( !IS_NPC(ch) && ch->pcdata->condition[COND_HUNGER] <= 0 )
		adj /= 2;

	if ( !IS_NPC(ch) && ch->pcdata->condition[COND_THIRST] <= 0 )
		adj /= 2;

    adj += (adj*(100+getAbilitySeries(ch,"tireless")*6))/100;
    ch->stamina = UMIN(max_stamina(ch), ch->stamina + adj );

	if ( ch->stamina == max_stamina(ch) && ch->stamina != last 
         && IS_SET(ch->display,DISP_SHOW_WHEN_FULL) )
		cprintf(ch,"&gYour stamina is full.&x\n\r");

/*
    pthread_mutex_unlock( &(ch->mutex) );
 */
    return;
}

void regen_Moves( Character *ch )
{
    int gain;
	Affect *af;

	drainOverflow( &ch->move, ch->max_move );

/*
    pthread_mutex_lock( &(ch->mutex) );
*/

    gain = get_curr_stat(ch,STAT_DEX)/5;
    switch ( ch->position )
    {
    	case POS_SLEEPING: break;
    	case POS_RESTING:  gain = 2 * gain / 3; break;
		case POS_SITTING:  gain /= 2; break;
		case POS_STANDING: gain /= 3; break;
		case POS_FIGHTING: gain = 0; break;
    }

	if ( (af = find_affect_type(ch,APPLY_REGEN_MOVES)) != NULL )
		gain += af->modifier;

    if ( !IS_NPC(ch) && ch->pcdata->subrace == gsn_ashinth )    
        gain = 125 * gain / 100;

    if ( !IS_NPC(ch) && ch->pcdata->condition[COND_HUNGER] <= 0 )
        gain /= 2;

    if ( !IS_NPC(ch) && ch->pcdata->condition[COND_THIRST] <= 0 )
        gain /= 2;

    ch->move = UMIN(ch->max_move,ch->move+gain);
/*
    pthread_mutex_unlock( &(ch->mutex) );
*/
}

void regen_BaseHits( Character *ch  )
{
    int gain;
	Affect *af;
	int last;

	if ( IS_AFFECTED(ch,AFF_POISON) )
		return;

	if ( ch->base_hit < -5 )
	{
		ch->base_hit--;
		damage(ch,ch,1,TYPE_UNDEFINED,DAM_NONE,0);
		return;
	}

	if ( ch->base_hit > ch->max_base_hit )
	{
		ch->base_hit = ch->max_base_hit;
		return;
	}

   gain = 1;
   switch( ch->position )
   {
	case POS_SLEEPING:	gain += 3;
	case POS_RESTING:	gain += 2;
	case POS_SITTING:	gain += 1;
	default:
		gain = 0;
	    break;
   }

   	if ( is_affected(ch,vnum_treeform,AFF_SPELL) && ch->in_room && ch->in_room->sector_type == SECT_FOREST )
		gain = UMAX(ch->level/5,gain);

   	if (ch->on != NULL && ch->on->item_type == ITEM_FURNITURE)
    	gain = gain * ch->on->value[4] / 100;

	if ( ch->position == POS_RESTING || ch->position == POS_SITTING || ch->position == POS_SLEEPING )
		gain = UMAX(gain,1);

	if ( (af = find_affect_type(ch,APPLY_REGEN_BASE)) != NULL )
		gain += af->modifier;

   	last = ch->base_hit; 

   	if ( !IS_NPC(ch) && ch->pcdata->subrace == gsn_ashinth )    
        gain = 125 * gain / 100;

    if ( !IS_NPC(ch) && ch->pcdata->condition[COND_HUNGER] <= 0 )
        gain /= 2;

    if ( !IS_NPC(ch) && ch->pcdata->condition[COND_THIRST] <= 0 )
        gain /= 2;

	if ( ch->in_room && ch->in_room->heal_rate > 0 )
		gain = ch->in_room->heal_rate * gain / 100;

   ch->base_hit = UMIN(ch->base_hit+gain,ch->max_base_hit);
   if ( ch->base_hit == ch->max_base_hit && ch->base_hit != last 
	&& IS_SET(ch->display,DISP_SHOW_WHEN_FULL) )
      cprintf(ch,"&gYour base hits are full.&x\n\r");

   return; 
}

void drainOverflow( int *hp, int max )
{
	int loss;

	/* Drain off 10% of the extra each tick */
	loss = ( *hp - max )  / 10;
	*hp = UMAX( *hp - loss, max );
	return;
}
	
void regen_StatHits( Character *ch  )
{
    int last;
    int gain;
    char debugging[MAX_STRING_LENGTH];
    char buf[MAX_STRING_LENGTH];
	Affect *af;

	if( IS_AFFECTED(ch,AFF_POISON) )
		return;

/*
    pthread_mutex_lock( &(ch->mutex) );
*/
	/* First, look for a conversion spell */
	if( (af = find_affect_type(ch,APPLY_CONVERT_HP_TO_MANA)) != NULL )
	{
		/* Drop 'modifier' points from stat hits, add to mana */
		ch->mana = UMIN( max_mana(ch), ch->mana + UMIN(af->modifier,ch->stat_hit) );
		ch->stat_hit = UMAX(0,ch->stat_hit - af->modifier);
	}
	
	/* If they have more stat hits than their max, drain it off */
	if ( ch->stat_hit > max_stat_hit( ch ) )
	{
		drainOverflow( &ch->stat_hit, max_stat_hit(ch) );
		return;
	}

    debugging[0] = '\0';

    /* I'm going to build this in parts so it's clear what we're doing */

    /* 1. Base value is (CON - 30) / 10 */
    gain = (3 *get_curr_stat(ch,STAT_CON) / 20) * (ch->level / 10 + 2) / 5;

    /* 2. Take 1/3 of that */
//    gain /= 3;

    /* 3. Add in 1/2 of the character's level */
//    gain += (ch->level/2);

    sprintf(buf,"Base: %d",gain);
    strcat(debugging,buf);

    switch ( ch->position )
    {
         default:            gain /= 4;                      break;
         case POS_SLEEPING:                                  break;
		 case POS_SITTING:
         case POS_RESTING:   gain /= 2;                      break;
         case POS_FIGHTING:  gain = 0;                      break;
    }

   sprintf(buf," / pos = %d", gain );
   strcat(debugging,buf);

    if ( is_affected(ch,vnum_treeform,AFF_SPELL) && ch->in_room && ch->in_room->sector_type == SECT_FOREST )
        gain += ( ch->level / 2 );

    if (ch->on != NULL && ch->on->item_type == ITEM_FURNITURE)
    {
        gain = gain * ch->on->value[4] / 100;
		sprintf(buf," * furn = %d", gain );
		strcat(debugging,buf);
    }

    if ( ch->level < 10 && IS_NPC(ch) )
	    gain /= 2;

    /* adjust for stat hits */
    gain = gain * ch->base_hit / UMAX(ch->max_base_hit,1);

    sprintf(buf," * base = %d",gain);
    strcat(debugging,buf);

	/* look for modifier affects */
	if ( (af = find_affect_type(ch,APPLY_REGEN_HP)) != NULL )
		gain += af->modifier;

    last = ch->stat_hit;

    if ( !IS_NPC(ch) && ch->pcdata->subrace == gsn_ashinth )    
        gain = 125 * gain / 100;

    if ( !IS_NPC(ch) && ch->pcdata->condition[COND_HUNGER] <= 0 )
        gain /= 2;

    if ( !IS_NPC(ch) && ch->pcdata->condition[COND_THIRST] <= 0 )
        gain /= 2;

	// Room regen
	if ( ch->in_room && ch->in_room->heal_rate > 0 )
		gain = ch->in_room->heal_rate * gain / 100;

    gain += (gain*(100+getAbilitySeries(ch,"regeneration")*6))/100;

    ch->stat_hit = UMIN(ch->stat_hit + gain, max_stat_hit(ch));  
    if ( ch->stat_hit == max_stat_hit(ch) && ch->stat_hit != last 
         && IS_SET(ch->display,DISP_SHOW_WHEN_FULL) )
	cprintf(ch,"&gYour stat hits are full.&x\n\r");

/*
    pthread_mutex_unlock(&(ch->mutex));
*/
}

void regen_Mana( Character *ch  )
{
    int gain;
    int last;
	Affect *af;

/* pthread_mutex_lock( &(ch->mutex) ); */

	if ( ch->mana > max_mana( ch ) )
	{
		drainOverflow( &ch->mana, max_mana(ch) );
		return;
	}

	switch( class_table[ ch->class ].group )
	{
		case MELEE:
		case DIVINE:
    		gain = (3 * get_curr_stat(ch,STAT_WIS) / 20) * (ch->level / 10 + 2) / 5; break;
		default:
		case ARCANE:
    		gain = (3 * get_curr_stat(ch,STAT_INT) / 20) * (ch->level / 10 + 2) / 5; break;
		case STEALTH:
			gain = (3 * get_curr_stat(ch,STAT_CHA) / 20) * (ch->level / 10 + 2) / 5; break;
	}
		
    switch ( ch->position )
    {
         default:            gain /= 4;                      break;
         case POS_SLEEPING:                                  break;
		 case POS_SITTING:
         case POS_RESTING:   gain /= 2;                      break;
         case POS_FIGHTING:  gain = 0;                      break;
    }

    if (ch->on != NULL && ch->on->item_type == ITEM_FURNITURE)
        gain = gain * ch->on->value[4] / 100;

	/* find an affect */
	if ( (af = find_affect_type(ch,APPLY_REGEN_MANA)) != NULL )
		gain += af->modifier;

    gain = UMAX(1,gain);
    last = ch->mana;

    if ( !IS_NPC(ch) && ch->pcdata->subrace == gsn_ashinth )    
        gain = 125 * gain / 100;

    if ( !IS_NPC(ch) && ch->pcdata->condition[COND_HUNGER] <= 0 )
        gain /= 2;

    if ( !IS_NPC(ch) && ch->pcdata->condition[COND_THIRST] <= 0 )
        gain /= 2;

	if ( ch->in_room && ch->in_room->mana_rate > 0 )
		gain = ch->in_room->mana_rate * gain / 100;

    gain += (gain*(100+getAbilitySeries(ch,"meditation")*6))/100;

    ch->mana = UMIN(ch->mana+gain,max_mana(ch));
    if ( ch->mana == max_mana(ch) && ch->mana != last 
         && IS_SET(ch->display,DISP_SHOW_WHEN_FULL) )
	cprintf(ch,"&gYour mana pool is full.&x\n\r");

/* pthread_mutex_unlock( &(ch->mutex) ); */

   return;
}

