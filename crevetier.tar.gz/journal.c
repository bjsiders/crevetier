/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/


#include <sys/types.h>
#include <sys/time.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdarg.h>
#include "thoc.h"
#include "olc.h"
#include "interp.h"
#include "tables.h"
#include "journal.h"
#include "recycle.h"

Journal *newJournal( void )
{
	Journal *new;

	if ( (new = (Journal *) GC_MALLOC( sizeof(Journal) )) == NULL )
	{
		log_error("newJournal: unable to GC_MALLOC");
		return NULL;
	}

	new->eventList = NULL;
	new->recipeList = NULL;
	new->questList = NULL;

	return new;
}

void freeJournal( Journal *j )
{
	if ( j->eventList != NULL )
		freeEventList( j->eventList );
	
	if( j->recipeList != NULL )
		free_string( j->recipeList );

	if( j->questList != NULL )
		free_string( j->questList );

	GC_FREE( j );
}

void freeEventList( JEvent *je )
{
	if ( je->next != NULL )
		freeEventList( je->next );

	freeJEvent( je );
}

JEvent *newJEvent( void )
{
	JEvent *new;

	if ( (new = (JEvent *) GC_MALLOC( sizeof(JEvent) )) == NULL )
	{
		log_error("newJEvent: unable to GC_MALLOC");
		return NULL;
	}

	new->when			= (time_t) 0;
	new->description	= NULL;
	new->next			= NULL;
	
	return new;
}

void freeJEvent( JEvent *je )
{
	if ( je->description != NULL )
		free_string( je->description );

	je->when	= (time_t) 0;
	je->next	= NULL;

	GC_FREE( je );
}

void addEventToJournal( Journal *j, const char *description, ... )
{
	JEvent *je;
	va_list	ap;
	char	buf[MAX_STRING_LENGTH];

	va_start( ap, description );
	vsnprintf(buf,sizeof(buf),description,ap);
	va_end( ap );

	je = newJEvent( );
	je->description = str_dup( buf );
	je->when		= current_time;

	eventToJournal( je, j );
}

void eventToJournal( JEvent *je, Journal *j )
{
	je->next = j->eventList;
	j->eventList = je;
}

void recipeToJournal( Recipe *r, Journal *j )
{
	char *tmp;
	int	size;
	char buf[MAX_STRING_LENGTH];

	size = j->recipeList == NULL ? 6 : strlen( j->recipeList ) + 6;

	tmp = (char *) GC_MALLOC( size );
	tmp[0] = '\0';

	if ( j->recipeList )
		strcpy(tmp,j->recipeList);

	snprintf(buf,sizeof(buf),";%d",r->vnum);
	strcat(tmp,buf);
	free_string( j->recipeList );
	j->recipeList = str_dup( tmp );
	GC_FREE( tmp );
}

void questToJournal( Quest *q, Journal *j )
{
	char *tmp;
	int	size;
	char buf[MAX_STRING_LENGTH];

	size = j->questList == NULL ? 7 : strlen( j->questList ) + 7;

	tmp = (char *) GC_MALLOC( size );
	tmp[0] = '\0';

	if ( j->questList )
		strcpy(tmp,j->questList);

	snprintf(buf,sizeof(buf),";%d",q->vnum);
	strcat(tmp,buf);
	free_string( j->questList );
	j->questList = str_dup( tmp );
	GC_FREE( tmp );
}

void showQuestJournal( Journal *j, Buffer *buffer )
{
	char *quests;
	char *t;

	bprintf(buffer," == My Quests Completed ==\n\r");
	if ( (quests = j->questList) == NULL )	
	{
		bprintf(buffer,"  (none completed)\n\r");
		return;
	}

	if ( (t = strchr(quests,';')) == NULL )
		bprintf(buffer,"  (none found)\n\r");

	while ( t != NULL )
	{
		Quest *q;

		++t;
		if ( (q = get_quest_index( atoi(t) )) == NULL )
			continue;
		else
			bprintf(buffer," * %s\n\r",q->name );
		t = strchr(t,';');
	}
	return;
}

void showRecipeJournal( Journal *j, Buffer *buffer )
{
	int sn;
	char *recs;
	char *t;
	int	numKnown[MAX_SKILL];

	memset( numKnown, 0, sizeof(numKnown) );

	bprintf(buffer," == My Trade Skill Recipes ==\n\r");
	if ( (recs = j->recipeList) == NULL )
	{
		bprintf(buffer,"  (none known)\n\r");
		return;
	}

	if ( (t = strchr(recs,';')) == NULL )
		bprintf(buffer,"  (none found)\n\r");

	while ( t != NULL )
	{
		Recipe *r;

		++t;
		if ( (r = get_recipe_index( atoi(t) )) == NULL )
			continue;
		else
		{
			ObjIndex *o;

			if ( (o = get_obj_index(r->result_vnum)) == NULL )
				log_string("Bad recipe vnum %d in journal",r->result_vnum);
			else
			{
				// Total it up
				numKnown[ r->trade_skill ]++;
				//bprintf(buffer," #%d. %s\n\r",r->vnum, o->short_descr);
			}
		}
		t = strchr(t,';');
	}

	bprintf(buffer," [     Skill     ] [#Known]\n\r");

	// Add it in
	for( sn=0; skill_table[sn].name != NULL; sn++ )
	{
		if ( skill_table[sn].type != SKILL_TRADE )
			continue;

		bprintf(buffer," %-17s %8d\n\r", capitalize(skill_table[sn].name), numKnown[sn] );
	}
		
	return;
}

void showEventJournal( Journal *j, Buffer *buffer )
{
	JEvent *je;
	bool	found = FALSE;

	bprintf(buffer," == My Journal Events ==\n\r");
	for( je = j->eventList ; je != NULL ; je = je->next )
	{
		found = TRUE;
		bprintf(buffer," %s :: %s\n\r", 
			format_date( je->when, "%H:%M on %A, %d/%b/%Y" ),
			je->description );
	}

	if ( !found )
		bprintf(buffer,"  (none found)\n\r");

	return;
}

void do_journal( Character *ch, char *argument )
{
	char 	arg[MAX_INPUT_LENGTH];
	Journal	*j;
	Buffer *buffer;
	bool	found = FALSE;

	if ( IS_NPC(ch) )
	{
		cprintf(ch,"NPCs don't keep good records.\n\r");
		return;
	}

	if ( (j=ch->pcdata->journal) == NULL )
	{
		cprintf(ch,"You don't have a journal.\n\r");
		return;
	}

	buffer = new_buf();
	argument = one_argument( argument, arg );

	if ( arg[0] == '\0' || !str_prefix(arg,"events") )
	{
		showEventJournal( j, buffer );
		found = TRUE;
		bprintf(buffer,"\n\r");
	}

	if ( arg[0] == '\0' || !str_prefix(arg,"recipes") )
	{
		if ( *argument != '\0' )
		{
			int vnum = atoi( argument );
			Recipe *r = get_recipe_index( vnum );

			if ( r && knowsRecipe( ch, r ))
			{
				int i;
				ObjIndex *pObj;

				if ( ( pObj = get_obj_index( r->result_vnum ) ) == NULL )
				{
					cprintf(ch,"This recipe is broken and currently produces nothing.\n\r");
					return;
				}
 
				bprintf(buffer," Recipe to create %s:\n\r", pObj->short_descr );
				for( i=0 ; i< MAX_INGREDIENT ; i++ )
				{
					if ( r->components[i] > 0 )
					{
						ObjIndex *o = get_obj_index(r->components[i]);

						if ( o )
							bprintf(buffer," * %s\n\r", o->short_descr );
					}
				}
			}

			page_to_char(buf_string(buffer),ch);
			free_buf(buffer);
			return;
		}
		showRecipeJournal( j, buffer );
		found = TRUE;
		bprintf(buffer,"\n\r");
	}

	if ( arg[0] == '\0' || !str_prefix(arg, "quests" ) )
	{
		showQuestJournal( j, buffer );
		found = TRUE;
		bprintf(buffer,"\n\r");
	}

	if ( !found )
		bprintf(buffer,"Syntax:  journal  [events|recipes|quests]\n\r");

	page_to_char(buf_string(buffer),ch);
	free_buf(buffer);

	return;
}

bool doneQuest( Character *ch, Quest *q )
{
	char *quests, *t;
	Journal *j;

	if ( IS_NPC(ch) )
		return FALSE;

	if ( (j=ch->pcdata->journal) == NULL )
		return FALSE;

    if ( (quests = j->questList) == NULL )
		return FALSE;

    if ( (t = strchr(quests,';')) == NULL )
		return FALSE;
        
    while ( t != NULL )
	{
		++t;
		if ( atoi(t) == q->vnum )
			return TRUE;
        t = strchr(t,';');
    }

    return FALSE;
}

bool knowsRecipe( Character *ch, Recipe *rec )
{
	char *recs, *t;
	Journal *j;

	if ( IS_NPC(ch) )
		return FALSE;

	if ( (j=ch->pcdata->journal) == NULL )
		return FALSE;

    if ( (recs = j->recipeList) == NULL )
		return FALSE;

    if ( (t = strchr(recs,';')) == NULL )
		return FALSE;
        
    while ( t != NULL )
	{
		++t;
		if ( atoi(t) == rec->vnum )
			return TRUE;
        t = strchr(t,';');
    }

    return FALSE;
}


