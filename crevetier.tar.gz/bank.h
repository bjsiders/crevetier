/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#ifndef bank_h
#define bank_h

#define BANK_MAX_ITEMS 5

#define CONVERT_PERSONAL_BANK 0
#define CONVERT_GUILD_BANK 1

void show_bank( Character *ch );
void get_bank( Character *ch, int amount, int currency_type, char *obj_name, bool all_coins );
void put_bank( Character *ch, int amount, int currency_type, char *obj_name, bool all_coins );
void obj_from_bank( Character *ch, Object *obj );
void obj_to_bank( Character *ch, Object *obj );
void get_coins_from_bank( Character *ch, int amount, int index );
void put_coins_in_bank( Character *ch, int amount, int index );
void coins_to_bank(Character *ch, long amount );
Object *get_obj_bank(Character *ch, char *argument );
void convert_coins( Character *ch, int conversion_loc );

#endif /* bank_h */
