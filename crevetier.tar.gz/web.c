/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include <sys/types.h>
#include <sys/time.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include <stdarg.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include "thoc.h"
#include "color.h"

/* Interface for the web site to get a list of default abilities and skills
 * for a class. */

void class_defaults( int fd, char *class_string )
{
    int gn;
    int class;
    int i;

    if ( (class = class_lookup(class_string)) <= 0 )
    {
        sock_printf(fd,"No such class: [%s]\n", class_string );
        return;
    }

    if ( (gn = group_lookup("rom basics")) >= 0 )
    {
        for( i=0 ; i < MAX_IN_GROUP ; i++ )
            sock_printf(fd,"DEFAULT: %s\n", group_table[gn].spells[i] );
    }

    if ( (gn = group_lookup(class_table[class].base_group)) >= 0 )
    {
        for( i=0 ; i < MAX_IN_GROUP ; i++ )
            sock_printf(fd,"DEFAULT: %s\n", group_table[gn].spells[i] );
    }

    if ( (gn = group_lookup(class_table[class].default_group)) >= 0 )
    {
        for( i=0 ; i < MAX_IN_GROUP ; i++ )
            sock_printf(fd,"DEFAULT: %s\n", group_table[gn].spells[i] );
    }

    return;
}

/* The game opens another socket that can be connected to
 * to get a dump of the who list
 */
void create_web_who( int fd )
{
    char buf[MAX_STRING_LENGTH];
    Descriptor *d;
    int  level_loop;
    char	*clan_out;
	int count = 0;
	Character ch;
	struct pc_data pc;

	memset(&ch,0,sizeof(ch));
	memset(&pc,0,sizeof(pc));
	ch.pcdata = &pc;

	/* For dark check */
	ch.in_room = get_room_index( 3001 );

	sock_printf(fd,"The Heirs of Crevetier\n");

	sock_printf(fd,"WebWho Created %s\n",
    	format_date( current_time, "%H:%M on %A, %d/%b/%Y" ) );

    /*
     * Set default arguments.
     */
	for ( level_loop = 60 ; level_loop > 0 ; level_loop-- )
	{
        switch( level_loop )
        {
        case 60:
             sock_printf(fd,"\nADMINISTRATION\n"); break;
        case 51:
             sock_printf(fd,"\nPLAYERS\n"); break;
        }

    	for ( d = descriptor_list; d != NULL; d = d->next )
    	{
        	Character *wch;
        	char const *class;
   			char  class_string[128];

			if ( d->connected != CON_PLAYING )
				continue;

        	wch   = ( d->original != NULL ) ? d->original : d->character;
			if ( wch->shapeshifted )
				wch = wch->shapeshifted;

        	if ( wch->level != level_loop || (!can_see( &ch, wch ) && IS_IMMORTAL(wch)) )
            	continue;
 
        	/*
         	* Figure out what to print for class.
	 		*/
	
			class = class_table[wch->class].who_name;
			sprintf(class_string,"%2d %6s %s", wch->level,
							wch->race < MAX_PC_RACE ? pc_race_table[wch->race].who_name : "none",
            				class );

			if ( IS_IMMORTAL(wch) )
			{
	    		switch ( wch->pcdata->imm_role )
	    		{
	    		default: break;
                		{				          /* 1234567890123 */
							case IMM_ROLE_CODER:     sprintf(class_string,"    Coder    "); break;
                    		case IMM_ROLE_ADMIN:     sprintf(class_string,"    Admin    "); break;
                    		case IMM_ROLE_BUILDER:   sprintf(class_string,"   Builder   "); break;
		    				case IMM_ROLE_AMBIENCE:	 sprintf(class_string,"  Ambience   "); break;
		    				case IMM_ROLE_DEVELOPER: sprintf(class_string,"  Developer  "); break;
                		}
	    		}
			}

            /* Figure out what to print for clans */
	        clan_out = get_clan_name_for_web( wch, &ch );

	        /*
	        * Format it up.
	        */
            snprintf( buf, sizeof(buf), "[%s] %s%s%s%s%s\n",
                class_string,
                clan_out,
                IS_SET(wch->comm, COMM_AFK) ? "[AFK] " : "",
				IS_SET(wch->act, PLR_TEAM_LEAD) ? "(Team Lead) " : "",
				wch->name, wch->pcdata->title );
			sock_printf(fd,buf);
			++count;
        }
    } /* end out foor loop */
    sock_printf(fd,"\n\nPlayers found: %d\n", count );
    return;
}

int create_web_socket( int port )
{
    static struct sockaddr_in sa_zero;
    struct sockaddr_in sa;
    int x = 1;
    int fd;

    if ( ( fd = socket( AF_INET, SOCK_STREAM, 0 ) ) < 0 )
    {
		log_error( "create_web_socket: socket" );
		return -1;
    }

    if ( setsockopt( fd, SOL_SOCKET, SO_REUSEADDR, (char *) &x, sizeof(x) ) < 0 )
    {
		log_error( "create_web_socket: SO_REUSEADDR" );
		close(fd);
		return -1;
    }

    sa		    	= sa_zero;
    sa.sin_family   = AF_INET;
    sa.sin_port	    = htons( port );

    if ( bind( fd, (struct sockaddr *) &sa, sizeof(sa) ) < 0 )
    {
		log_error("create_web_socket: bind" );
		close(fd);
		return -1;
    }

    if ( listen( fd, 3 ) < 0 )
    {
		log_error("create_web_socket: listen");
		close(fd);
		return -1;
    }

    return fd;
}

void process_webwho_request( int webSocket )
{
    struct sockaddr_in sock;
    int desc;
    int size;

    size = sizeof(sock);
    if ( ( desc = accept( webSocket, (struct sockaddr *) &sock, &size) ) < 0 )
    {
		log_error( "process_webwho_request: accept" );
		return;
    }

    // Read one line, see waht they want
    //readline(desc, buf, sizeof(buf) );
    //if ( !str_cmp(buf,"webwho") )
	    create_web_who( desc );
    //else
	//    class_defaults( desc, buf );
    close( desc );
    return;
}
