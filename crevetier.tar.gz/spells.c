/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized
 for one specific implementation, and it is not generic nor compatible with
 standard ROM area files.  It also uses Boehm's garbage collector (not
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/** System Include Files **/
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/** Custom Header Files **/
#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "tables.h"
#include "recycle.h"

bool check_cancel( int level, Affect *af );

/*
 * Spell functions.
 */
bool spell_detect_humanoids( int sn, int level, Character *ch, void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( is_affected( ch, vnum_detect_humanoids, AFF_SPELL ) ||
         is_affected( ch, vnum_detect_humanoids_d, AFF_SPELL) )
    {
        if (victim == ch)
          send_to_char("You can already sense humanoids.\n\r",ch);
        else
          act("$N can already sense humanoids.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(level);
    af.modifier  = 0;
    af.location  = APPLY_NONE;
    af.bitvector = 0;
    af.flags     = 0;
    af.misc         = 0;
    spellAffectToChar( victim, &af );
    send_to_char( "Your vision is coated by a dim grey mist.\n\r", victim );
    if ( ch != victim )
        act("$N's eyes are covered by a thin grey film.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_detect_plants( int sn, int level, Character *ch, void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if (  is_affected( ch, vnum_detect_plants, AFF_SPELL ) )
    {
        if (victim == ch)
          send_to_char("You can already sense plants.\n\r",ch);
        else
          act("$N can already sense plants.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(level);
    af.modifier  = 0;
    af.location  = APPLY_NONE;
    af.bitvector = 0;
    af.flags     = 0;
    af.misc         = 0;
    spellAffectToChar( victim, &af );
    send_to_char( "Your vision is coated by a dim green mist.\n\r", victim );
    if ( ch != victim )
        act("$N's eyes are covered by a thin green film.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_detect_summoned( int sn, int level, Character *ch, void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if (  is_affected( ch, vnum_detect_summoned, AFF_SPELL ) ||  
          is_affected( ch, vnum_detect_summoned_d, AFF_SPELL) )

    {
        if (victim == ch)
          send_to_char("You can already sense summoned creatures.\n\r",ch);
        else
          act("$N can already sense summoned creatures.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(level);
    af.modifier  = 0;
    af.location  = APPLY_NONE;
    af.bitvector = 0;
    af.flags     = 0;
    af.misc         = 0;
    spellAffectToChar( victim, &af );
    send_to_char( "Your vision is coated by a dim crimson mist.\n\r", victim );
    if ( ch != victim )
        act("$N's eyes are covered by a thin crimson film.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_detect_animals( int sn, int level, Character *ch, void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if (  is_affected( ch, vnum_detect_animals, AFF_SPELL ) ||  
          is_affected( ch, vnum_detect_animals_d, AFF_SPELL) )

    {
        if (victim == ch)
          send_to_char("You can already sense animals .\n\r",ch);
        else
          act("$N can already sense animals.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(level);
    af.modifier  = 0;
    af.location  = APPLY_NONE;
    af.bitvector = 0;
    af.flags     = 0;
    af.misc         = 0;
    spellAffectToChar( victim, &af );
    send_to_char( "Your vision is coated by a dim red mist.\n\r", victim );
    if ( ch != victim )
        act("$N's eyes are covered by a thin red film.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_detect_invisible( int sn, int level, Character *ch, void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( IS_AFFECTED(victim, AFF_DETECT_INVIS) )
    {
        if (victim == ch)
          send_to_char("You can already see invisible.\n\r",ch);
        else
          act("$N can already see invisible things.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(level);
    af.modifier  = 0;
    af.location  = APPLY_NONE;
    af.bitvector = AFF_DETECT_INVIS;
    af.flags     = 0;
    af.misc         = 0;
    spellAffectToChar( victim, &af );
    send_to_char( "Your eyes burn briefly as the magic sets in.\n\r", victim );
    if ( ch != victim )
    act("$N can see invisible.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_detect_undead( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( IS_AFFECTED(victim, AFF_DETECT_MAGIC) )
    {
        if (victim == ch)
          send_to_char("You can already sense the undead.\n\r",ch);
        else
          act("$N can already sense the undead.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(level);
    af.modifier  = 0;
    af.location  = APPLY_NONE;
    af.bitvector = AFF_DETECT_UNDEAD;
    af.flags     = AFF_SPELL;
    af.misc         = 0;
    spellAffectToChar( victim, &af );

    send_to_char( "Your vision goes out of focus briefly, and then refocuses.\n\r", victim );
    act("$n's eyes glow black, and then dim.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_detect_poison( int sn, int level, Character *ch, void *vo,int target)
{
    Object *obj = (Object *) vo;

    if ( obj->item_type == ITEM_DRINK_CON || obj->item_type == ITEM_FOOD )
    {
    if ( obj->value[3] != 0 )
        send_to_char( "You smell poisonous fumes.\n\r", ch );
    else
        send_to_char( "It looks delicious.\n\r", ch );
    }
    else
    {
    send_to_char( "It doesn't look poisoned.\n\r", ch );
    }

    return TRUE;
}

bool spell_resistance(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( is_affected( victim, sn , AFF_SPELL) )
    {
        if (victim == ch)
          send_to_char("Your resistance is already enhanced.\n\r",ch);
        else
          act("$N's resistance is already enhanced.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(UMIN(30,20+level));
    af.location  = APPLY_SAVE_WILLPOWER;
    af.modifier  = UMIN(15,5+level/2);
    af.bitvector = 0;
    af.flags      = AFF_SPELL;
    spellAffectToChar( victim, &af );
    af.location  = APPLY_SAVE_FORTITUDE;
    spellAffectToChar( victim, &af );
    af.location  = APPLY_SAVE_REFLEX;
    spellAffectToChar( victim, &af );

    send_to_char( "Your resistance is amplified.\n\r", victim );
    act("$n's resistance is amplified.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}


bool spell_weapon( int sn, int level, Character *ch, void *vo, int target )
{
    return TRUE;
}

bool spell_null( int sn, int level, Character *ch, void *vo, int target )
{
    send_to_char( "That's not a spell!\n\r", ch );
    return TRUE;
}


bool spell_word_of_recall( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Room *location;
    
    if (IS_NPC(victim))
      return TRUE;
   
    if ((location = get_room_index( ROOM_VNUM_TEMPLE)) == NULL)
    {
    send_to_char("You are completely lost.\n\r",victim);
    return TRUE;
    } 

    if (IS_SET(victim->in_room->room_flags,ROOM_NO_RECALL) ||
    IS_AFFECTED(victim,AFF_CURSE))
    {
    send_to_char("Spell failed.\n\r",victim);
    return TRUE;
    }

    if (victim->fighting != NULL)
    stop_fighting(victim,TRUE);
    
    ch->move /= 2;
    act("$n disappears.",victim,NULL,NULL,TO_ROOM);
    char_from_room(victim);
    char_to_room(victim,location);
    act("$n appears in the room.",victim,NULL,NULL,TO_ROOM);
    do_function(victim, &do_look, "auto");
    return TRUE;
}

bool spell_water_breathing(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( is_affected(victim,sn,AFF_SPELL) )
    {
        cprintf(ch,"You failed.\n\r");
        return TRUE;
    }

    af.where            = TO_AFFECTS;
    af.level            = level;
    af.type             = sn;
    af.duration         = minutes(20+level);
    af.location         = 0;
    af.modifier         = 0;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;

    cprintf(victim,"You are able to breathe underwater!\n\r");
    if ( ch != victim )
    act("$N can breathe underwater.",ch,NULL,victim,TO_CHAR);
    spellAffectToChar(victim,&af);
    return TRUE;
}

bool spell_restoration(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int restore;

    restore = UMIN(level*8,300);

    victim->stamina = UMIN(victim->stamina + restore, max_stamina(victim));

    act("$n is restored!",victim,NULL,NULL,TO_ROOM);
    act("You are restored!",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_invigor(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int restore;

    restore = UMIN(level*4,100);

    victim->stamina = UMIN(victim->stamina + restore, max_stamina(victim) );

    act("$n is reinvigorated.",victim,NULL,NULL,TO_ROOM);
    act("You are reinvigorated.",victim,NULL,NULL,TO_CHAR); 
    return TRUE;
}

bool spell_levitate(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( is_affected(victim,sn,AFF_SPELL) )
    {
        cprintf(ch,"You failed.\n\r");
        return TRUE;
    }

    af.where            = TO_AFFECTS;
    af.level            = level;
    af.type             = sn;
    af.duration         = minutes(12);
    af.location         = 0;
    af.modifier         = 0;
    af.bitvector        = AFF_FLYING;
    af.flags            = AFF_SPELL;

    act("$n begins to hover above the ground.",victim,NULL,NULL,TO_ROOM);
    act("You begin to hover above the ground.",victim,NULL,NULL,TO_CHAR);
    spellAffectToChar(victim,&af);
    return TRUE;
}


bool spell_summon_food( int sn, int level, Character *ch, void *vo,int target)
{
    Object *food;

    if ( (food = create_object( get_obj_index( VNUM_SUMMONED_FOOD ) )) == NULL )
    {
        cprintf(ch,"Something is amiss in the world of magic, the food cannot be created.\n\r");
        return TRUE;
    }

    obj_to_char( food, ch );
    act( "You summon forth $p.", ch, food, NULL, TO_CHAR );
    act( "$n summons forth $p.", ch, food, NULL, TO_ROOM );
    return TRUE;
}

bool spell_summon_drink( int sn, int level, Character *ch, void *vo,int target)
{
    Object *drink;

    if ( (drink = create_object( get_obj_index( VNUM_SUMMONED_DRINK ) )) == NULL )
    {
        cprintf(ch,"Something is amiss in the world of magic, the drink cannot be created.\n\r");
        return TRUE;
    }

    obj_to_char( drink, ch );
    act( "You summon forth $p.", ch, drink, NULL, TO_CHAR );
    act( "$n summons forth $p.", ch, drink, NULL, TO_ROOM );
    return TRUE;
}

bool spell_cancel_magic( int sn, int level, Character *ch, void *vo,int target )
{
    Character *victim = (Character *) vo;

    if ( victim->affected == NULL )
    {
		act("$N isn't affected by any kind of magic.",ch,NULL,victim,TO_CHAR);
		return TRUE;
    }

    if ( check_cancel( level, victim->affected ) )
    {
	    int save_sn;
		SpellIndex* pSpellIndex;

		affect_strip( victim, (save_sn = victim->affected->type) );
		
		pSpellIndex = get_spell_index(save_sn);
		cprintf(victim,"%s\n\r", pSpellIndex ? pSpellIndex->msg_off : "(null)" );
		cprintf(ch,"You have cancelled the %s spell.\n\r", pSpellIndex ? pSpellIndex->full_name : "(null)" );
    }
    else
		cprintf(ch,"You failed.\n\r");

    return TRUE;
}

bool spell_demon_smite(int sn,int level,Character *ch,void *vo,int target)
{
    int dam;
    Character *victim = (Character *) vo;

    dam = dice(level,20);
    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
        dam /= 2;

    damage(ch,victim,dam,sn,DAM_SPIRIT, DF_SHOW|DF_SPELL);
    return TRUE;
}


int spell_food_poisoning(int sn, int level, Character *ch, void *vo, int target)
{
    return TRUE;
}

int spell_swamp_gas(int sn, int level, Character *ch, void *vo, int target )
{
    Affect af;
    Character *victim = (Character *) vo;

    if ( sn == vnum_swamp_gas )
        act("&GThere is poisonous swamp gas in the air!&x",ch,NULL,NULL,TO_CHAR);
    else
    if ( sn == vnum_noxious_fumes )
        act("&YThere is noxious sulfuric vapor in the air!&x",ch,NULL,NULL,TO_CHAR);
    else
        act("&RThere is an unknown toxic gas in the air!&x",ch,NULL,NULL,TO_CHAR);

    if ( check_saves_spell(ch,victim,DAM_POISON,SAVE_FORTITUDE) )
    {
        act("You resist the poisonous fumes!",victim,NULL,NULL,TO_CHAR);
        act("$N resists the poisonous fumes!",ch,NULL,victim,TO_ROOM);
        return TRUE;
    }

    af.where        = DAMAGE_OVER_TIME;
    af.type         = sn;
    af.duration     = seconds(30+ch->level);
    af.location     = UMAX(ch->level/3,6);
    af.modifier     = UMAX(ch->level/4,3);
    af.caster_id    = ch->id;
    af.bitvector    = DAM_POISON;
    af.flags        = AFF_NONSPELL;
    spellAffectToChar(victim,&af);

    act( "You double over retching and gagging.", victim,NULL,NULL,TO_CHAR);
    act( "$n dobles over retching and gagging.", victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

int spell_natural_venom(int sn, int level, Character *ch, void *vo, int target )
{
    Affect af;
    Character *victim = (Character *) vo;

    if ( check_saves_spell(ch,victim,DAM_POISON,SAVE_FORTITUDE) )
    {
        act("You resist the venom!",victim,NULL,NULL,TO_CHAR);
        act("$N resists the venom!",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where         = DAMAGE_OVER_TIME;
    af.type          = sn;
    af.duration     = seconds(30+ch->level);
    af.location        = UMAX(ch->level/3,6);
    af.modifier     = UMAX(ch->level/4,3);
    af.caster_id    = ch->id;
    af.bitvector    = DAM_POISON;
    af.flags        = AFF_NONSPELL;
	af.level		= ch->level;
    spellAffectToChar(victim,&af);

    act( "You shiver and convulse as the venom courses through your veins.", victim,NULL,NULL,TO_CHAR);
    act( "$n shivers and convulses as venom courses through $s veins.", victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

