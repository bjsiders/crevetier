/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/** System Include Files **/
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/** Custom Header Files **/
#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "tables.h"
#include "recycle.h"

struct venom_table
{
	int level;
	int	damage;
	int	dur;
};

const struct venom_table SnakeVenom [] =
{
	{ 0, 2, 31 },
	{ 2, 4, 31 },
	{ 6, 10, 31 },
	{ 11, 17, 37 },
	{ 17, 27, 37 },
	{ 24, 42, 37 },
	{ 32, 64, 43 },
	{ 41, 96, 43 },
	{ 51, 140, 43 },
	{ 100, 140, 49 }
};

const struct venom_table AmphVenom [] =
{
	{ 0, 5 },
	{ 4, 15 },
	{ 8, 30 },
	{ 13, 45 },
	{ 19, 60 },
	{ 26, 75 },
	{ 34, 90 },
	{ 43, 115 },
	{ 100,130 }
};

const struct venom_table SpiderVenom [] =
{
	{ 0, -6, 10 },
	{ 6, -12, 20 },
	{ 10, -20, 26 },
	{ 15, -30, 32 },
	{ 21, -42, 38 },
	{ 28, -56, 44 },
	{ 36, -72, 50 },
	{ 45, -90, 60 },
	{ 100, -90, 75 }
};

const struct venom_table InsectVenom [] =
{
	{ 0, 4, 20 },
	{ 8, 8, 40 },
	{ 12, 14, 48 },
	{ 17, 20, 56 },
	{ 23, 26, 64 },
	{ 30, 32, 72 },
	{ 38, 38, 80 },
	{ 47, 44, 90 },
	{ 100, 44, 100 } 
};

const struct venom_table LizardVenom [] =
{
	{ 0, 10, 10 },
	{ 10, 25, 20 },
	{ 14, 50, 28 },
	{ 19, 75, 36 },
	{ 25, 100, 44 },
	{ 32, 125, 52 },
	{ 40, 150, 60 },
	{ 49, 175, 70 },
	{ 100, 175, 80 }
};

const struct venom_table PlantVenom [] =
{
	{ 0, 1 },
	{ 12, 2 },
	{ 16, 4 },
	{ 21, 6 },
	{ 27, 8 },
	{ 34, 10 },
	{ 42, 12 },
	{ 51, 14 },
	{ 100, 14 }
};

const struct venom_table ScorpionVenom [] =
{
	{0,0,5},
	{14,0,10},
	{18,0,16},
	{23,0,22},
	{29,0,28},
	{36,0,34},
	{44,0,40},
	{100,0,50}
};

bool spell_snake_venom( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;
	int i, dam, dur;

	for( i=0 ; SnakeVenom[i].level < level ; i++ )
		;

	dam = SnakeVenom[UMAX(0,i-1)].damage;
	dur = SnakeVenom[UMAX(0,i-1)].dur;

    if ( check_saves_spell(ch, victim, DAM_POISON, SAVE_FORTITUDE) )
    {
		act("You resist the poison.",victim,NULL,NULL,TO_CHAR);
        act("The poison fails to take hold.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_POISON;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(dur);
        af.location     = dam*3/4;
        af.modifier     = dam;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("You have been envenomed!",victim,NULL,NULL,TO_CHAR);
        act("$n has been envenomed!",victim,NULL,NULL,TO_ROOM);
    }

    damage( ch, victim, level, sn, DAM_POISON , DF_SPELL );
    return TRUE;
}

bool spell_amphibian_venom( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;
	int i, dur;

	for( i=0 ; AmphVenom[i].level < level ; i++ )
		;

	dur = AmphVenom[UMAX(0,i-1)].damage;

    if ( check_saves_spell(ch, victim, DAM_DISEASE, SAVE_FORTITUDE) )
    {
		act("You resist the disease.",victim,NULL,NULL,TO_CHAR);
        act("The disease fails to take hold.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
        af.caster_id    = ch->id;
        af.bitvector    = DAM_DISEASE;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(dur);
        af.location     = dur/4;
        af.modifier     = dur/2;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_DISEASE;   
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("You have been diseased!",victim,NULL,NULL,TO_CHAR);
        act("$n has been diseased!",victim,NULL,NULL,TO_ROOM);
    }

    damage( ch, victim, level, sn, DAM_DISEASE , DF_SPELL );
    return TRUE;
}

bool spell_spider_venom( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;
	int dur, amt;
	int i;

    for( i=0 ; SpiderVenom[i].level < level ; i++ )
        ;

    dur = SpiderVenom[UMAX(0,i-1)].dur;
	amt = SpiderVenom[UMAX(0,i-1)].damage;

    if ( check_saves_spell(ch, victim, DAM_POISON, SAVE_FORTITUDE) )
    {
        cprintf(ch,"Your poison fails to take hold.\n\r");
        cprintf(victim,"Your briefly feel weak.\n\r");
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(dur);
    af.location     = APPLY_STR;
    af.modifier     = amt;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your muscles stiffen up as poison courses through your veins!",victim,NULL,NULL,TO_CHAR);
    act("$n is weakened as poison courses through $s veins!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_insect_venom( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;
	int dur, amt, i;

    for( i=0 ; InsectVenom[i].level < level ; i++ )
        ;

    dur = InsectVenom[UMAX(0,i-1)].dur;
	amt = InsectVenom[UMAX(0,i-1)].damage;

    if ( check_saves_spell(ch, victim, DAM_POISON, SAVE_FORTITUDE) )
    {
        act("The poison fails to take hold.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = AFF_SLOW;
        af.type         = sn;
        af.level        = level;
        af.duration     = minutes(dur);
        af.location     = APPLY_SPEED;
        af.modifier     = (100+amt);
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("You feel lethargic as poison courses through your veins!",victim,NULL,NULL,TO_CHAR);
        act("$n appears to be lethargic as the poison grips $m!",victim,NULL,NULL,TO_ROOM);
    }

    return TRUE;
}

bool spell_lizard_venom( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;
	int amt, i, dur;

    for( i=0 ; LizardVenom[i].level < level ; i++ )
        ;

    dur = LizardVenom[UMAX(0,i-1)].dur;
	amt = LizardVenom[UMAX(0,i-1)].damage;

    if ( check_saves_spell(ch,victim,DAM_POISON,SAVE_FORTITUDE) )
    {
        cprintf(ch,"The poison fails to take hold.\n\r");
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.type         = sn;   
    af.level        = level;
    af.duration     = seconds(dur);
    af.location     = APPLY_MOVE_RATE;
    af.modifier     = PULSE_PER_SECOND * dur / 100;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar(victim,&af);

    act("Your legs feel heavy as the poison infects you.",victim,NULL,NULL,TO_CHAR);
    act("$n is slowed by the poison.",victim,NULL,NULL,TO_ROOM);
    return TRUE;   
}

bool spell_plant_venom( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
   	int i, dur;

	for( i=0 ; PlantVenom[i].level < level ; i++ )
        ;

    dur = PlantVenom[UMAX(0,i-1)].dur;

    if ( check_saves_spell(ch, victim, DAM_POISON, SAVE_FORTITUDE) )
    {
        act("$N shakes off the poison.",ch,NULL,victim,TO_CHAR);
        return TRUE;     
    }

    act("You are paralyzed by the poison!",victim,NULL,NULL,TO_CHAR);
    act("$n is paralyzed by the poison!",victim,NULL,NULL,TO_ROOM);
    DAZE_STATE(victim,PULSE_PER_SECOND * dur);
    return TRUE;
}

bool spell_scorpion_venom(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;     
	int i, dur;

    for( i=0 ; ScorpionVenom[i].level < level ; i++ )
        ;

    dur = ScorpionVenom[UMAX(0,i-1)].dur;

    /* Check saves - willpower */
    if ( check_saves_spell(ch,victim,DAM_POISON,SAVE_FORTITUDE) )
    {
        act("$N resists the poison.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(dur);
    af.modifier     = 0;
    af.location     = 0;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );    

    act("You feel light-headed and dizzy.",victim,NULL,NULL,TO_CHAR);
    act("$n appears to be light-headed from the poison.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

