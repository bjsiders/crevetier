#ifndef __spawn_h
#define __spawn_h
void    spawnToRoom( Room *r, Spawn *s );
void    spawnToContents( Spawn *s1, Spawn *s2 );
Spawn   *get_new_spawn ( void );
void    extractSpawnFromRoom( Spawn *spawn, Room *pRoom );
Spawn   *findExitSpawn( Room *room, int door );
#endif
