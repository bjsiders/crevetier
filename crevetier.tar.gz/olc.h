/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  File: olc.h                                                            *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 *                                                                         *
 *  This code was freely distributed with the The Isles 1.1 source code,   *
 *  and has been used here for OLC - OLC would not be what it is without   *
 *  all the previous coders who released their source code.                *
 *                                                                         *
 ***************************************************************************/
/*
 * This is a header file for all the OLC files.  Feel free to copy it into
 * thoc.h if you wish.  Many of these routines may be handy elsewhere in
 * the code.  -Jason Dinkel
 */

/*
 * The version info.  Please use this info when reporting bugs.
 * It is displayed in the game by typing 'version' while editing.
 * Do not remove these from the code - by request of Jason Dinkel
 */

#ifndef olc_h
#define olc_h

#define OLCVERSION    "ILAB Online Creation [Beta 1.0, ROM 2.3 modified]"
#define AUTHOR    "     By Jason(jdinkel@mines.colorado.edu)\n\r" \
                "     Modified for use with ROM 2.3\n\r"        \
                "     By Hans Birkeland (hansbi@ifi.uio.no)"
#define DATE    "     (Apr. 7, 1995 - ROM mod, Apr 16, 1995)"
#define CREDITS "     Original by Surreality(cxw197@psu.edu) and Locke(locke@lm.com)"

/*
 * New typedefs.
 */
typedef    bool OLC_FUN         ( Character *ch, char *argument );
#define DECLARE_OLC_FUN( fun )    OLC_FUN    fun

char *show_bit_list( const struct flag_type *flag_table );

/* Command procedures needed ROM OLC */
DECLARE_DO_FUN(    do_help    );

/*
 * Connected states for editor.
 */
#define ED_AREA         1
#define ED_ROOM         2
#define ED_OBJECT       3
#define ED_MOBILE       4
#define ED_HELP         5
#define ED_TRADESKILL   6
#define ED_QUEST        7
#define ED_SCRIPT       8
#define ED_SPELL        9

/*
 * Interpreter Prototypes
 */
void    aedit           ( Character *ch, char *argument );
void    redit           ( Character *ch, char *argument );
void    medit           ( Character *ch, char *argument );
void    oedit           ( Character *ch, char *argument );
void    hedit           ( Character *ch, char *argument );
void    tedit           ( Character *ch, char *argument );
void    qedit           ( Character *ch, char *argument );
void    sedit           ( Character *ch, char *argument );
void    ledit           ( Character *ch, char *argument );

/*
 * OLC Constants
 */
#define MAX_MOB    1        /* Default maximum number for resetting mobs */

/*
 * Structure for an OLC editor command.
 */
struct olc_cmd_type
{
    char * const        name;
    OLC_FUN *           olc_fun;
};

/*
 * Structure for an OLC editor startup command.
 */
struct    editor_cmd_type
{
    char * const        name;
    DoFun *            do_fun;
};

/*
 * Utils.
 */
Area *get_vnum_area     ( int vnum );
Area *get_area_data     ( int vnum );
int flag_value          ( const struct flag_type *flag_table, char *argument);
char *flag_string       ( const struct flag_type *flag_table, int bits );
void show_obj_values    ( Character *ch, ObjIndex *obj );
bool set_obj_values     ( Character *ch, ObjIndex *pObj, int value_num, char *argument);
void stripCRLF          ( char *string );

/*
 * Interpreter Table Prototypes
 */
extern const struct olc_cmd_type    aedit_table[];
extern const struct olc_cmd_type    redit_table[];
extern const struct olc_cmd_type    oedit_table[];
extern const struct olc_cmd_type    medit_table[];
extern const struct olc_cmd_type    tedit_table[];
extern const struct olc_cmd_type    qedit_table[];
extern const struct olc_cmd_type    sedit_table[];
extern const struct olc_cmd_type    ledit_table[];
extern const struct olc_cmd_type    hedit_table[];

/*
 * Editor Commands.
 */
DECLARE_DO_FUN( do_aedit );
DECLARE_DO_FUN( do_redit );
DECLARE_DO_FUN( do_oedit );
DECLARE_DO_FUN( do_medit );
DECLARE_DO_FUN( do_tedit );
DECLARE_DO_FUN( do_qedit );
DECLARE_DO_FUN( do_sedit );
DECLARE_DO_FUN( do_ledit );

/*
 * General Functions
 */
bool show_commands        ( Character *ch, char *argument );
bool show_help            ( Character *ch, char *argument );
bool edit_done            ( Character *ch );
bool show_version         ( Character *ch, char *argument );

DECLARE_DO_FUN( do_hedit       );

/* Help Editor - kermit 1/98 */
DECLARE_OLC_FUN( hedit_show    );
DECLARE_OLC_FUN( hedit_make );
DECLARE_OLC_FUN( hedit_desc   );
DECLARE_OLC_FUN( hedit_level   );
DECLARE_OLC_FUN( hedit_keywords   );
DECLARE_OLC_FUN( hedit_delete );

#define EDIT_HELP(ch, help)     ( help = (Help *)ch->desc->pEdit )

Help *new_help  (void);
void free_help   ( Help * pHelp);
void save_helps  (void);

/*
 * Area Editor Prototypes
 */
DECLARE_OLC_FUN( aedit_generate );
DECLARE_OLC_FUN( aedit_show        );
DECLARE_OLC_FUN( aedit_exp    );
DECLARE_OLC_FUN( aedit_create        );
DECLARE_OLC_FUN( aedit_name        );
DECLARE_OLC_FUN( aedit_file        );
DECLARE_OLC_FUN( aedit_ed         );
DECLARE_OLC_FUN( aedit_age        );
/* DECLARE_OLC_FUN( aedit_recall    );       ROM OLC */
DECLARE_OLC_FUN( aedit_reset        );
DECLARE_OLC_FUN( aedit_security        );
DECLARE_OLC_FUN( aedit_builder        );
DECLARE_OLC_FUN( aedit_vnum        );
DECLARE_OLC_FUN( aedit_levels        );
DECLARE_OLC_FUN( aedit_lvnum        );
DECLARE_OLC_FUN( aedit_uvnum        );
DECLARE_OLC_FUN( aedit_flags    );
DECLARE_OLC_FUN( aedit_hideinlist);

DECLARE_OLC_FUN( tedit_show        );
DECLARE_OLC_FUN( tedit_create    );
DECLARE_OLC_FUN( tedit_name        );
DECLARE_OLC_FUN( tedit_skill    );
DECLARE_OLC_FUN( tedit_result    );
DECLARE_OLC_FUN( tedit_fail        );
DECLARE_OLC_FUN( tedit_difficulty    );
DECLARE_OLC_FUN( tedit_craft_time        );
DECLARE_OLC_FUN( tedit_component    );
DECLARE_OLC_FUN( tedit_foundation );

DECLARE_OLC_FUN( sedit_create );
DECLARE_OLC_FUN( sedit_show );
DECLARE_OLC_FUN( sedit_name );
DECLARE_OLC_FUN( sedit_priority );
DECLARE_OLC_FUN( sedit_direct_object );
DECLARE_OLC_FUN( sedit_edit );
DECLARE_OLC_FUN( sedit_trigger );

DECLARE_OLC_FUN( qedit_faction );
DECLARE_OLC_FUN( qedit_greeting );
DECLARE_OLC_FUN( qedit_farewell );
DECLARE_OLC_FUN( qedit_show        );
DECLARE_OLC_FUN( qedit_keyword );
DECLARE_OLC_FUN( qedit_create    );
DECLARE_OLC_FUN( qedit_name        );
DECLARE_OLC_FUN( qedit_short_descr );
DECLARE_OLC_FUN( qedit_long_descr );
DECLARE_OLC_FUN( qedit_reward );
DECLARE_OLC_FUN( qedit_coins );
DECLARE_OLC_FUN( qedit_experience );
DECLARE_OLC_FUN( qedit_require );
DECLARE_OLC_FUN( qedit_race );
DECLARE_OLC_FUN( qedit_class );
DECLARE_OLC_FUN( qedit_deity );
DECLARE_OLC_FUN( qedit_minlevel );
DECLARE_OLC_FUN( qedit_maxlevel );
DECLARE_OLC_FUN( qedit_flags );

/*
 * Room Editor Prototypes
 */
DECLARE_OLC_FUN( redit_clan        );
DECLARE_OLC_FUN( redit_class        );
DECLARE_OLC_FUN( redit_delspawn    );
DECLARE_OLC_FUN( redit_show        );
DECLARE_OLC_FUN( redit_create        );
DECLARE_OLC_FUN( redit_name        );
DECLARE_OLC_FUN( redit_desc        );
DECLARE_OLC_FUN( redit_ed        );
DECLARE_OLC_FUN( redit_flag        );
DECLARE_OLC_FUN( redit_sector        );
DECLARE_OLC_FUN( redit_format        );
DECLARE_OLC_FUN( redit_north        );
DECLARE_OLC_FUN( redit_south        );
DECLARE_OLC_FUN( redit_east        );
DECLARE_OLC_FUN( redit_west        );
DECLARE_OLC_FUN( redit_up        );
DECLARE_OLC_FUN( redit_down        );
DECLARE_OLC_FUN( redit_qreset    );
DECLARE_OLC_FUN( redit_sreset    );
DECLARE_OLC_FUN( redit_mreset        );
DECLARE_OLC_FUN( redit_oreset        );
DECLARE_OLC_FUN( redit_qreset        );
DECLARE_OLC_FUN( redit_mlist        );
DECLARE_OLC_FUN( redit_olist        );
DECLARE_OLC_FUN( redit_mshow        );
DECLARE_OLC_FUN( redit_oshow        );
DECLARE_OLC_FUN( redit_hp        );
DECLARE_OLC_FUN( redit_mana        );



/*
 * Object Editor Prototypes
 */
DECLARE_OLC_FUN( oedit_show        );
/*DECLARE_OLC_FUN( oedit_timer        );*/
DECLARE_OLC_FUN( oedit_deity    );
DECLARE_OLC_FUN( oedit_create        );
DECLARE_OLC_FUN( oedit_copy    );
DECLARE_OLC_FUN( oedit_name        );
DECLARE_OLC_FUN( oedit_short        );
DECLARE_OLC_FUN( oedit_long        );
DECLARE_OLC_FUN( oedit_addaffect    );
DECLARE_OLC_FUN( oedit_delaffect    );
DECLARE_OLC_FUN( oedit_value0        );
DECLARE_OLC_FUN( oedit_value1        );
DECLARE_OLC_FUN( oedit_value2        );
DECLARE_OLC_FUN( oedit_value3        );
DECLARE_OLC_FUN( oedit_value4        );  /* ROM */
DECLARE_OLC_FUN( oedit_value5        );
DECLARE_OLC_FUN( oedit_value6           );
DECLARE_OLC_FUN( oedit_value7           );
DECLARE_OLC_FUN( oedit_value8           );
DECLARE_OLC_FUN( oedit_value9           );

DECLARE_OLC_FUN( oedit_weight        );
DECLARE_OLC_FUN( oedit_cost        );
DECLARE_OLC_FUN( oedit_ed        );

DECLARE_OLC_FUN( oedit_extra            );  /* ROM */
DECLARE_OLC_FUN( oedit_wear             );  /* ROM */
DECLARE_OLC_FUN( oedit_type             );  /* ROM */
DECLARE_OLC_FUN( oedit_affect           );  /* ROM */
DECLARE_OLC_FUN( oedit_material        );  /* ROM */
DECLARE_OLC_FUN( oedit_level            );  /* ROM */
DECLARE_OLC_FUN( oedit_condition        );  /* ROM */
DECLARE_OLC_FUN( oedit_durability    );
DECLARE_OLC_FUN( oedit_quality );



/*
 * Mobile Editor Prototypes
 */
DECLARE_OLC_FUN( medit_copy    );
DECLARE_OLC_FUN( medit_show        );
DECLARE_OLC_FUN( medit_attackecho    );
DECLARE_OLC_FUN( medit_spawnecho    );
DECLARE_OLC_FUN( medit_deathecho    );
DECLARE_OLC_FUN( medit_create        );
DECLARE_OLC_FUN( medit_name        );
DECLARE_OLC_FUN( medit_short        );
DECLARE_OLC_FUN( medit_long        );
DECLARE_OLC_FUN( medit_shop        );
DECLARE_OLC_FUN( medit_desc        );
DECLARE_OLC_FUN( medit_level        );
DECLARE_OLC_FUN( medit_align        );
DECLARE_OLC_FUN( medit_deity    );
DECLARE_OLC_FUN( medit_resists    );
DECLARE_OLC_FUN( medit_spec        );

DECLARE_OLC_FUN( medit_class        );
DECLARE_OLC_FUN( medit_sex        );  /* ROM */
DECLARE_OLC_FUN( medit_act        );  /* ROM */
DECLARE_OLC_FUN( medit_affect        );  /* ROM */
DECLARE_OLC_FUN( medit_ac        );  /* ROM */
DECLARE_OLC_FUN( medit_form        );  /* ROM */
DECLARE_OLC_FUN( medit_part        );  /* ROM */
DECLARE_OLC_FUN( medit_imm        );  /* ROM */
DECLARE_OLC_FUN( medit_off        );  /* ROM */
DECLARE_OLC_FUN( medit_size        );  /* ROM */
DECLARE_OLC_FUN( medit_hitdice        );  /* ROM */
DECLARE_OLC_FUN( medit_manadice        );  /* ROM */
DECLARE_OLC_FUN( medit_damdice        );  /* ROM */
DECLARE_OLC_FUN( medit_race        );  /* ROM */
DECLARE_OLC_FUN( medit_position        );  /* ROM */
DECLARE_OLC_FUN( medit_gold        );  /* ROM */
DECLARE_OLC_FUN( medit_hitroll        );  /* ROM */
DECLARE_OLC_FUN( medit_damtype        );  /* ARPENS */
DECLARE_OLC_FUN( medit_regen        );  /* ARPENS */
DECLARE_OLC_FUN( medit_factions        );  /* ARPENS */
DECLARE_OLC_FUN( medit_spellaffects        );  /* ARPENS */

/* 
 * Spell editor
 */
DECLARE_OLC_FUN( ledit_short );
DECLARE_OLC_FUN( ledit_desc );
DECLARE_OLC_FUN( ledit_range );
DECLARE_OLC_FUN( ledit_show );
DECLARE_OLC_FUN( ledit_name );
DECLARE_OLC_FUN( ledit_sourcefile );
DECLARE_OLC_FUN( ledit_fullname );
DECLARE_OLC_FUN( ledit_mana );
DECLARE_OLC_FUN( ledit_affects );
DECLARE_OLC_FUN( ledit_classlevel );
DECLARE_OLC_FUN( ledit_type );
DECLARE_OLC_FUN( ledit_spelltype );
DECLARE_OLC_FUN( ledit_school );
DECLARE_OLC_FUN( ledit_casting_time );
DECLARE_OLC_FUN( ledit_recasting_time );
DECLARE_OLC_FUN( ledit_damage_noun );
DECLARE_OLC_FUN( ledit_incantation );
DECLARE_OLC_FUN( ledit_gesture );
DECLARE_OLC_FUN( ledit_wearoff_msg );
DECLARE_OLC_FUN( ledit_object_wearoff_msg );
DECLARE_OLC_FUN( ledit_flags );
DECLARE_OLC_FUN( ledit_damage );
DECLARE_OLC_FUN( ledit_damtype );
DECLARE_OLC_FUN( ledit_savingthrow );
DECLARE_OLC_FUN( ledit_okroomecho );
DECLARE_OLC_FUN( ledit_okvictimecho );
DECLARE_OLC_FUN( ledit_failroomecho );
DECLARE_OLC_FUN( ledit_failvictimecho );
DECLARE_OLC_FUN( ledit_function );
DECLARE_OLC_FUN( ledit_create );

/*
 * Macros
 */

#define IS_SWITCHED( ch )       ( ch->desc->original )    /* ROM OLC */

#define IS_BUILDER(ch, Area)    ( ( ch->pcdata->security >= Area->security  \
                || strstr( Area->builders, ch->name )        \
                || strstr( Area->builders, "All" ) )        \
                && !IS_SWITCHED( ch ) )


/* Return pointers to what is being edited. */
#define EDIT_MOB(ch, mob)    ( mob = (MobIndex *)ch->desc->pEdit )
#define EDIT_OBJ(ch, obj)    ( obj = (ObjIndex *)ch->desc->pEdit )
#define EDIT_ROOM(ch, room)    ( room = ch->in_room )
#define EDIT_AREA(ch, area)    ( area = (Area *)ch->desc->pEdit )
#define EDIT_RECIPE(ch, rec) ( rec = (Recipe *)ch->desc->pEdit )
#define EDIT_QUEST(ch,que) ( que = ( Quest *) ch->desc->pEdit )
#define EDIT_SCRIPT(ch,scr) ( scr = ( ScriptIndex * ) ch->desc->pEdit )
#define EDIT_SPELL(ch,spl) (spl = (SpellIndex *) ch->desc->pEdit)



/* Return TRUE if area changed, FALSE if not. */
#define REDIT( fun )        bool fun( Character *ch, char *argument )
#define OEDIT( fun )        bool fun( Character *ch, char *argument )
#define MEDIT( fun )        bool fun( Character *ch, char *argument )
#define AEDIT( fun )        bool fun( Character *ch, char *argument )
#define HEDIT( fun )        bool fun( Character *ch, char *argument )
#define TEDIT( fun )        bool fun( Character *ch, char *argument )
#define QEDIT( fun )        bool fun( Character *ch, char *argument )
#define SEDIT( fun )        bool fun( Character *ch, char *argument )
#define LEDIT( fun )        bool fun( Character *ch, char *argument )

/*
 * Prototypes
 */
/* mem.c - memory prototypes. */
#define ED    ExtraDescr
Area    *new_area         ( void );
void        free_area         ( Area *pArea );
Exit    *new_exit         ( void );
void        free_exit         ( Exit *pExit );
ED         *new_extra_descr     ( void );
void        free_extra_descr     ( ED *pExtra );
Room *new_room_index         ( void );
void        free_room_index         ( Room *pRoom );
Affect    *new_affect         ( void );
void        free_affect         ( Affect* pAf );
Shop    *new_shop         ( void );
void        free_shop         ( Shop *pShop );
ObjIndex    *new_obj_index         ( void );
void        free_obj_index         ( ObjIndex *pObj );
MobIndex    *new_mob_index         ( void );
Recipe*        new_recipe_index        ( void );
Quest*        new_quest_index            ( void );
ScriptIndex*        new_script_index        ( void );
void        free_mob_index         ( MobIndex *pMob );
#undef    ED

#define OLC_BUILD_AS_I_WALK    (A)

#endif /* olc_h */
