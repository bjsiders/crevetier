/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#ifndef faction_h
#define faction_h

struct faction_type
{
	Faction		*next;
	bool		valid;
	char		*name;
	long		standing;
	long		counter;
	int			factionID;
	long		passivePoint;
	long		aggroPoint;
};

struct faction_amount
{
    char *      faction;
    int         amount;
};

Faction *faction_lookup( const char *arg );	
void 	save_factions( void );
void	load_factions( void );
void	loadDefaultFactions( void );
bool	removeFactionFromList( Faction **list, Faction *f );
Faction	*findFactionInList( Faction *list, char *argument );
Faction *findFactionByID( Faction *list, int id );
Faction *cloneFaction( Faction *f );
void 	addFactionToList( Faction **list, Faction *f );
void 	applyDefaultFactions( Character *ch );
void 	applyFactionFromDeath( Character *ch, Character *dyer, int percent );
char	*factionDescription( long counter );
char	*dispositionName( int dispo );
bool	are_allies( Character *c1, Character *c2 );
bool	are_enemies( Character *c1, Character *c2 );
void 	applyFaction( Character *ch, char *faction_name, int amount );
bool 	checkFaction( Character *ch, char *faction_name, int amount );

extern Faction *factionList;
extern int		topFactionID;

/* Faction Reactions */
#define MIN_FACTION     -50000
#define MAX_FACTION     50000

#define FACTION_UNITY       50000
#define FACTION_HARMONY     40000
#define FACTION_FRIENDLY    31000
#define FACTION_PLEASANT    23000
#define FACTION_AMIABLE     16000
#define FACTION_WARM        10000
#define FACTION_COOPERATIVE  4000
#define FACTION_AMUSEMENT    1000
#define FACTION_TOLERANT      250
#define FACTION_AMBIVALENT     50
#define FACTION_INDIFFERENT     0
#define FACTION_UNCERTAIN     -50
#define FACTION_SUSPICIOUS   -250
#define FACTION_DISTRUST    -1000
#define FACTION_DISTASTE    -4000
#define FACTION_DISGUST     -10000
#define FACTION_REVULSION   -16000
#define FACTION_ANGER       -23000
#define FACTION_AGGRESSIVE  -31000
#define FACTION_FURY        -40000
#define FACTION_HATRED      -50000

#define FACTION_MEMBER_OF   1
#define FACTION_ENEMY_OF    2

#define	findFactionOnChar(ch,arg)	(findFactionInList( (ch)->factions, (arg) ))
#define factionLookup(arg)			(findFactionInList( factionList, (arg) ))
#define findFaction(ch,f)			(findFactionByID( (ch)->factions, (f)->factionID ))

#endif /* faction_h */
