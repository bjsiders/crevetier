/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.
****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include <errno.h>
#include <dlfcn.h>
#include <sys/types.h>
#include <sys/time.h>
#include <stdarg.h>
#include <unistd.h>

#define _XOPEN_SOURCE 700
#include <time.h>

#include "thoc.h"
#include "gc.h"

char *string_space;
char *top_string;
char  str_empty    [1];
char *string_hash[MAX_KEY_HASH];
FILE *fpReserve;

/*
 * Memory management.
 * Increase MAX_STRING if you have too.
 * Tune the others only if you understand what you're doing.
 */
#define            MAX_STRING           4413120
#define            MAX_PERM_BLOCK       131072
#define            MAX_MEM_LIST         11

void *           rgFreeList[MAX_MEM_LIST];
const int        rgSizeList[MAX_MEM_LIST]    =
{
    16, 32, 64, 128, 256, 1024, 2048, 4096, 8192, 16384, 32768-64
};

int            nAllocString;
int            sAllocString;
int            nAllocPerm;
int            sAllocPerm;

/*
 * Read a letter from a file.
 */
char thoc_fread_letter( char *sourceFile, int lineNumber, FILE *fp )
{
    char c;

    do
    {
        c = getc( fp );
    }
    while ( isspace(c) );

    return c;
}

/*
 * Read a number from a file.
 */
int thoc_fread_number( char *sourceFile, int lineNumber, FILE *fp )
{
    int number;
    bool sign;
    char c;

    do
    {
        c = getc( fp );
    }
    while ( isspace(c) );

    number = 0;

    sign   = FALSE;
    if ( c == '+' )
    {
        c = getc( fp );
    }
    else if ( c == '-' )
    {
        sign = TRUE;
        c = getc( fp );
    }

    if ( !isdigit(c) )
    {
        log_bug( "Fread_number: bad format, found %c, "
             "called in file %s on line %d", c, sourceFile, lineNumber );
        exit( 1 );
    }

    while ( isdigit(c) )
    {
        number = number * 10 + c - '0';
        c      = getc( fp );
    }

    if ( sign )
        number = 0 - number;

    if ( c == '|' )
        number += fread_number( fp );
    else if ( c != ' ' )
        ungetc( c, fp );

    return number;
}

long thoc_fread_long( char *srcFile, int line, FILE *fp )
{
    long number;
    bool sign;
    char c;

    do
    {
        c = getc( fp );
    }
    while ( isspace(c) );

    number = 0;

    sign   = FALSE;
    if ( c == '+' )
    {
        c = getc( fp );
    }
    else if ( c == '-' )
    {
        sign = TRUE;
        c = getc( fp );
    }

    if ( !isdigit(c) )
    {
        log_bug( "Fread_number: bad format in call, line %d, file %s", line, srcFile );
        exit( 1 );
    }

    while ( isdigit(c) )
    {
        number = number * 10 + c - '0';
        c      = getc( fp );
    }

    if ( sign )
        number = 0 - number;

    if ( c == '|' )
        number += fread_number( fp );
    else if ( c != ' ' )
        ungetc( c, fp );

    return number;
}

long long thoc_fread_longflag( char *srcFile, int line, FILE *fp)
{
    long long number;
    char c;
    bool negative = FALSE;

    do
    {
        c = getc(fp);
    }
    while ( isspace(c));

    if (c == '-')
    {
        negative = TRUE;
        c = getc(fp);
    }

    number = 0;

    if (!isdigit(c) && c != '-' )  /* ROM OLC */
    {
        while (('A' <= c && c <= 'Z') || ('a' <= c && c <= 'z'))
        {
            number += thoc_longflag_convert(c);
            c = getc(fp);
        }
    }

    if ( c == '-' )      /* ROM OLC */
    {
        number = fread_number( fp );
        return -number;
    }

    while (isdigit(c))
    {
        number = number * 10 + c - '0';
        c = getc(fp);
    }

    if (c == '|')
        number += fread_flag(fp);

    else if  ( c != ' ')
        ungetc(c,fp);

    if (negative)
        return -1 * number;

    return number;
}

long thoc_fread_flag( char *srcFile, int line, FILE *fp)
{
    int number;
    char c;
    bool negative = FALSE;

    do
    {
        c = getc(fp);
    }
    while ( isspace(c));

    if (c == '-')
    {
        negative = TRUE;
        c = getc(fp);
    }

    number = 0;

    if (!isdigit(c) && c != '-' )  /* ROM OLC */
    {
        while (('A' <= c && c <= 'Z') || ('a' <= c && c <= 'z'))
        {
            number += thoc_flag_convert(c);
            c = getc(fp);
        }
    }

    if ( c == '-' )      /* ROM OLC */
    {
        number = fread_number( fp );
        return -number;
    }

    while (isdigit(c))
    {
        number = number * 10 + c - '0';
        c = getc(fp);
    }

    if (c == '|')
        number += fread_flag(fp);

    else if  ( c != ' ')
        ungetc(c,fp);

    if (negative)
        return -1 * number;

    return number;
}

long long thoc_longflag_convert(char letter)
{
    long long bitsum = 0;
    char i;

    if ('A' <= letter && letter <= 'Z') 
    {
        bitsum = 1;
        for (i = letter; i > 'A'; i--)
            bitsum *= 2;
    }
    else if ('a' <= letter && letter <= 'z')
    {
        bitsum = 67108864; /* 2^26 */
        for (i = letter; i > 'a'; i --)
            bitsum *= 2;
    }

    return bitsum;
}

long thoc_flag_convert(char letter )
{
    long bitsum = 0;
    char i;

    if ('A' <= letter && letter <= 'Z') 
    {
        bitsum = 1;
        for (i = letter; i > 'A'; i--)
            bitsum *= 2;
    }
    else if ('a' <= letter && letter <= 'z')
    {
        bitsum = 67108864; /* 2^26 */
        for (i = letter; i > 'a'; i --)
            bitsum *= 2;
    }

    return bitsum;
}

/*
 * Read and allocate space for a string from a file.
 * These strings are read-only and shared.
 * Strings are hashed:
 *   each string prepended with hash pointer to prev string,
 *   hash code is simply the string length.
 *   this function takes 40% to 50% of boot-up time.
 */
char *thoc_fread_string( char *srcF, int line, FILE *fp )
{
    char *plast;
    char c;
    bool fBootDb = FALSE;;

    if ( getenv("THOC_BOOTUP") == NULL )
        fBootDb = TRUE;
    
    plast = top_string + sizeof(char *);
    if ( plast > &string_space[MAX_STRING - MAX_STRING_LENGTH] )
    {
        log_bug( "Fread_string: MAX_STRING %d "
             "exceeded in %s, line %d", MAX_STRING, srcF, line );
        exit( 1 );
    }

    /*
     * Skip blanks.
     * Read first char.
     */
    do
    {
        c = getc( fp );
    }
    while ( isspace(c) );

    if ( ( *plast++ = c ) == '~' )
        return &str_empty[0];

    for ( ;; )
    {
        /*
         * Back off the char type lookup,
         *   it was too dirty for portability.
         *   -- Furey
         */

        switch ( *plast = getc(fp) )
        {
            default:
                plast++;
                break;
 
            case EOF:
                /* temp fix */
                log_bug( "Fread_string: EOF in %s line %d", srcF, line );
            return NULL;
                /* exit( 1 ); */
                break;
 
            case '\n':
                plast++;
                *plast++ = '\r';
                break;
 
            case '\r':
                break;
 
            case '~':
            plast++;
            {
                union
                {
                    char *    pc;
                    char    rgc[sizeof(char *)];
                } u1;
                int ic;
                int iHash;
                char *pHash;
                char *pHashPrev;
                char *pString;

                plast[-1] = '\0';
                iHash     = UMIN( MAX_KEY_HASH - 1, plast - 1 - top_string );
                for ( pHash = string_hash[iHash]; pHash; pHash = pHashPrev )
                {
                    for ( ic = 0; ic < sizeof(char *); ic++ )
                        u1.rgc[ic] = pHash[ic];
                    pHashPrev = u1.pc;
                    pHash    += sizeof(char *);

                    if ( top_string[sizeof(char *)] == pHash[0]
                    &&   !strcmp( top_string+sizeof(char *)+1, pHash+1 ) )
                        return pHash;
                }

        if ( fBootDb )
        {
            pString        = top_string;
            top_string        = plast;
            u1.pc        = string_hash[iHash];
            for ( ic = 0; ic < sizeof(char *); ic++ )
                pString[ic] = u1.rgc[ic];
            string_hash[iHash]    = pString;

            nAllocString += 1;
            sAllocString += top_string - pString;
                return pString + sizeof(char *);
        }
        else
        {
            return thoc_str_dup( top_string + sizeof(char *) );
        }
        }
    }
    }
}

char *thoc_fread_string_eol( char *srcF, int line, FILE *fp )
{
    static bool char_special[256-EOF];
    char *plast;
    char c;
    bool fBootDb = FALSE;

    if ( getenv("THOC_BOOTUP") == NULL )
        fBootDb = TRUE;
 
    if ( char_special[EOF-EOF] != TRUE )
    {
        char_special[EOF -  EOF] = TRUE;
        char_special['\n' - EOF] = TRUE;
        char_special['\r' - EOF] = TRUE;
    }
 
    plast = top_string + sizeof(char *);
    if ( plast > &string_space[MAX_STRING - MAX_STRING_LENGTH] )
    {
        log_bug( "Fread_string: MAX_STRING %d exceeded in %s line %d.", MAX_STRING, srcF, line );
        exit( 1 );
    }
 
    /*
     * Skip blanks.
     * Read first char.
     */
    do
    {
        c = getc( fp );
    }
    while ( isspace(c) );
 
    if ( ( *plast++ = c ) == '\n')
        return &str_empty[0];
 
    for ( ;; )
    {
        if ( !char_special[ ( *plast++ = getc( fp ) ) - EOF ] )
            continue;
 
        switch ( plast[-1] )
        {
        default:
            break;
 
        case EOF:
            log_bug( "Fread_string_eol  EOF in %s line %d", srcF, line );
            exit( 1 );
            break;
 
        case '\n':  case '\r':
            {
                union
                {
                    char *      pc;
                    char        rgc[sizeof(char *)];
                } u1;
                int ic;
                int iHash;
                char *pHash;
                char *pHashPrev;
                char *pString;
 
                plast[-1] = '\0';
                iHash     = UMIN( MAX_KEY_HASH - 1, plast - 1 - top_string );
                for ( pHash = string_hash[iHash]; pHash; pHash = pHashPrev )
                {
                    for ( ic = 0; ic < sizeof(char *); ic++ )
                        u1.rgc[ic] = pHash[ic];
                    pHashPrev = u1.pc;
                    pHash    += sizeof(char *);
 
                    if ( top_string[sizeof(char *)] == pHash[0]
                    &&   !strcmp( top_string+sizeof(char *)+1, pHash+1 ) )
                        return pHash;
                }
 
                if ( fBootDb )
                {
                    pString             = top_string;
                    top_string          = plast;
                    u1.pc               = string_hash[iHash];
                    for ( ic = 0; ic < sizeof(char *); ic++ )
                        pString[ic] = u1.rgc[ic];
                    string_hash[iHash]  = pString;
 
                    nAllocString += 1;
                    sAllocString += top_string - pString;
                    return pString + sizeof(char *);
                }
                else
                {
                    return thoc_str_dup( top_string + sizeof(char *) );
                }
            }
        }
    }
}

/*
 * Read to end of line (for comments).
 */
void thoc_fread_to_eol( char *srcF, int line, FILE *fp )
{
    char c;

    do
    {
        c = getc( fp );
    }
    while ( c != '\n' && c != '\r' );

    do
    {
        c = getc( fp );
    }
    while ( c == '\n' || c == '\r' );

    ungetc( c, fp );
    return;
}

/* Read until you hit a specific character */
char *thoc_fread_to_char( char *srcF, int line, FILE *fp, char whichChar )
{
    static char word[MAX_INPUT_LENGTH];
    char *pword;
    char cEnd;

    do
    {
        cEnd = getc( fp );
    }
    while ( isspace( cEnd ) );

    for ( pword = word ; pword < word + MAX_INPUT_LENGTH; pword++ )
    {
        *pword = getc( fp );
        if ( *pword == whichChar )
        {
            *pword = '\0';
            return word;
        }
    }

    word[MAX_INPUT_LENGTH-1] = '\0';
    log_bug( "Fread_word: word [%s] too long in %s line %d.", word, srcF, line );
    exit( 1 );
    return NULL;
}

/*
 * Read one word (into static buffer).
 */
char *thoc_fread_word( char *srcF, int line, FILE *fp )
{
    static char word[MAX_INPUT_LENGTH];
    char *pword;
    char cEnd;

    do
    {
    cEnd = getc( fp );
    }
    while ( isspace( cEnd ) );

    if ( cEnd == '\'' || cEnd == '"' )
    {
    pword   = word;
    }
    else
    {
    word[0] = cEnd;
    pword   = word+1;
    cEnd    = ' ';
    }

    for ( ; pword < word + MAX_INPUT_LENGTH; pword++ )
    {
    *pword = getc( fp );
    if ( cEnd == ' ' ? isspace(*pword) : *pword == cEnd )
    {
        if ( cEnd == ' ' )
        ungetc( *pword, fp );
        *pword = '\0';
        return word;
    }
    }

    word[MAX_INPUT_LENGTH-1] = '\0';
    log_bug( "Fread_word: word [%s] too long in %s line %d.", word, srcF, line );
    exit( 1 );
    return NULL;
}

/*
 * Allocate some ordinary memory,
 *   with the expectation of freeing it someday.
 */
void *thoc_alloc_mem( int sMem )
{
    void *pMem;
    int *magic;
    int iList;

    sMem += sizeof(*magic);

    for ( iList = 0; iList < MAX_MEM_LIST; iList++ )
    {
        if ( sMem <= rgSizeList[iList] )
            break;
    }

    if ( iList == MAX_MEM_LIST )
    {
        log_bug( "Alloc_mem: size %d too large.", sMem );
        exit( 1 );
    }

    if ( rgFreeList[iList] == NULL )
    {
        pMem              = thoc_alloc_perm( rgSizeList[iList] );
    }
    else
    {
        pMem              = rgFreeList[iList];
        rgFreeList[iList] = * ((void **) rgFreeList[iList]);
    }

    magic = (int *) pMem;
    *magic = MAGIC_NUM;
    pMem += sizeof(*magic);

    return pMem;
}

/*
 * Free some memory.
 * Recycle it back onto the free list for blocks of that size.
 */
void thoc_free_mem( void *pMem, int sMem, char *file, int line )
{
    int iList;
    int *magic;

    pMem -= sizeof(*magic);
    magic = (int *) pMem;

    if (*magic != MAGIC_NUM)
    {
        log_bug("Trying to recycle invalid memory of size %d: file %s line %d.",
            sMem, file, line );
        log_bug((char*) pMem + sizeof(*magic),0);
        return;
    }

    *magic = 0;
    sMem += sizeof(*magic);

    for ( iList = 0; iList < MAX_MEM_LIST; iList++ )
    {
        if ( sMem <= rgSizeList[iList] )
            break;
    }

    if ( iList == MAX_MEM_LIST )
    {
        log_bug( "Free_mem: size %d too large.", sMem );
        exit( 1 );
    }

    * ((void **) pMem) = rgFreeList[iList];
    rgFreeList[iList]  = pMem;

    return;
}


/*
 * Allocate some permanent memory.
 * Permanent memory is never freed,
 *   pointers into it may be copied safely.
 */
void *thoc_alloc_perm( int sMem )
{
    static char *pMemPerm;
    static int iMemPerm;
    void *pMem;

    while ( sMem % sizeof(long) != 0 )
    sMem++;
    if ( sMem > MAX_PERM_BLOCK )
    {
    log_bug( "Alloc_perm: %d too large.", sMem );
    exit( 1 );
    }

    if ( pMemPerm == NULL || iMemPerm + sMem > MAX_PERM_BLOCK )
    {
    iMemPerm = 0;
    if ( ( pMemPerm = GC_MALLOC( MAX_PERM_BLOCK ) ) == NULL )
    {
        log_error( "Alloc_perm" );
        exit( 1 );
    }
    }

    pMem        = pMemPerm + iMemPerm;
    iMemPerm   += sMem;
    nAllocPerm += 1;
    sAllocPerm += sMem;
    return pMem;
}

/*
 * Duplicate a string into dynamic memory.
 * Fread_strings are read-only and shared.
 */
char *thoc_str_dup( const char *str )
{
    char *str_new;

    if ( str[0] == '\0' )
    return &str_empty[0];

    if ( str >= string_space && str < top_string )
        return (char *) str;

    str_new = thoc_alloc_mem( strlen(str) + 1 );
    strcpy( str_new, str );
    return str_new;
}



/*
 * Free a string.
 * Null is legal here to simplify callers.
 * Read-only shared strings are not touched.
 */
void thoc_free_string( char *pstr )
{
    if ( pstr == NULL
    ||   pstr == &str_empty[0]
    || ( pstr >= string_space && pstr < top_string ) )
    return;

    free_mem( pstr, strlen(pstr) + 1 );
    return;
}


/*
 * Stick a little fuzz on a number.
 */
int thoc_number_fuzzy( int number )
{
    switch ( number_bits( 2 ) )
    {
    case 0:  number -= 1; break;
    case 3:  number += 1; break;
    }

    return UMAX( 1, number );
}

/*
 * Generate a random number.
 */
int thoc_number_range( int from, int to )
{
    int power;
    int number;

    if (from == 0 && to == 0)
    return 0;

    if ( ( to = to - from + 1 ) <= 1 )
    return from;

    for ( power = 2; power < to; power <<= 1 )
    ;

    while ( ( number = number_mm() & (power -1 ) ) >= to )
    ;

    return from + number;
}

/*
 * Generate a percentile roll.
 */
int thoc_number_percent( void )
{
    int percent;

    while ( (percent = number_mm() & (128-1) ) > 99 )
    ;

    return 1 + percent;
}



/*
 * Generate a random door.
 */
int thoc_number_door( void )
{
    int door;

    while ( ( door = number_mm() & (8-1) ) > 5)
        ;

    return door;
}

int thoc_number_bits( int width )
{
    return number_mm( ) & ( ( 1 << width ) - 1 );
}

void thoc_init_mm( )
{
    srandom(time(NULL)^getpid());
    return;
}
 
long thoc_number_mm( void )
{
    return random() >> 6;
}

/*
 * Roll some dice.
 */
int thoc_dice( int number, int size )
{
    int idice;
    int sum;

    switch ( size )
    {
    case 0: return 0;
    case 1: return number;
    }

    for ( idice = 0, sum = 0; idice < number; idice++ )
    sum += number_range( 1, size );

    return sum;
}

/*
 * Simple linear interpolation.
 */
int thoc_interpolate( int level, int value_00, int value_32 )
{
    return value_00 + level * (value_32 - value_00) / 32;
}

/*
 * Removes the tildes from a string.
 * Used for player-entered strings that go into disk files.
 */
void thoc_smash_tilde( char *str )
{
    for ( ; *str != '\0'; str++ )
    {
    if ( *str == '~' )
        *str = '-';
    }

    return;
}

/*
 * Compare strings, case insensitive.
 * Return TRUE if different
 *   (compatibility with historical functions).
 */
bool thoc_str_cmp( const char *astr, const char *bstr )
{
    if ( astr == NULL )
    {
    log_bug( "Str_cmp: null astr.", 0 );
    return TRUE;
    }

    if ( bstr == NULL )
    {
    log_bug( "Str_cmp: null bstr.", 0 );
    return TRUE;
    }

    for ( ; *astr || *bstr; astr++, bstr++ )
    {
    if ( LOWER(*astr) != LOWER(*bstr) )
        return TRUE;
    }

    return FALSE;
}

/*
 * Compare strings, case insensitive, for prefix matching.
 * Return TRUE if astr not a prefix of bstr
 *   (compatibility with historical functions).
 */
bool thoc_str_prefix( const char *astr, const char *bstr )
{
    if ( astr == NULL )
    {
    log_bug( "Strn_cmp: null astr.", 0 );
    return TRUE;
    }

    if ( bstr == NULL )
    {
    log_bug( "Strn_cmp: null bstr.", 0 );
    return TRUE;
    }

    for ( ; *astr; astr++, bstr++ )
    {
    if ( LOWER(*astr) != LOWER(*bstr) )
        return TRUE;
    }

    return FALSE;
}

/*
 * Compare strings, case insensitive, for match anywhere.
 * Returns TRUE is astr not part of bstr.
 *   (compatibility with historical functions).
 */
bool thoc_str_infix( const char *astr, const char *bstr )
{
    int sstr1;
    int sstr2;
    int ichar;
    char c0;

    if ( ( c0 = LOWER(astr[0]) ) == '\0' )
    return FALSE;

    sstr1 = strlen(astr);
    sstr2 = strlen(bstr);

    for ( ichar = 0; ichar <= sstr2 - sstr1; ichar++ )
    {
    if ( c0 == LOWER(bstr[ichar]) && !str_prefix( astr, bstr + ichar ) )
        return FALSE;
    }

    return TRUE;
}

/*
 * Compare strings, case insensitive, for suffix matching.
 * Return TRUE if astr not a suffix of bstr
 *   (compatibility with historical functions).
 */
bool thoc_str_suffix( const char *astr, const char *bstr )
{
    int sstr1;
    int sstr2;

    sstr1 = strlen(astr);
    sstr2 = strlen(bstr);
    if ( sstr1 <= sstr2 && !str_cmp( astr, bstr + sstr2 - sstr1 ) )
    return FALSE;
    else
    return TRUE;
}

/*
 * Returns an initial-capped string.
 */
char *thoc_capitalize( const char *str )
{
    static char strcap[MAX_STRING_LENGTH];
    int i;

    for ( i = 0; str[i] != '\0'; i++ )
    strcap[i] = LOWER(str[i]);
    strcap[i] = '\0';
    strcap[0] = UPPER(strcap[0]);
    return strcap;
}

void thoc_append_file( char *file, char *str )
{
    FILE *fp;

    if ( str[0] == '\0' )
        return;

    fclose( fpReserve );
    if ( ( fp = fopen( file, "a" ) ) == NULL )
        log_error( file );
    else
    {
        fprintf( fp, "%s\n", str );
        fclose( fp );
    }

    fpReserve = fopen( NULL_FILE, "r" );
    return;
}

/*
 * This function is here to aid in debugging.
 * If the last expression in a function is another function call,
 *   gcc likes to generate a JMP instead of a CALL.
 * This is called "tail chaining."
 * It hoses the debugger call stack for that call.
 * So I make this the last call in certain critical functions,
 *   where I really need the call stack to be right for debugging!
 *
 * If you don't understand this, then LEAVE IT ALONE.
 * Don't remove any calls to tail_chain anywhere.
 *
 * -- Furey
 */
void tail_chain( void )
{
    return;
}

/* New OLC functions */

/*
 * Sets vnum range for area using OLC protection features.
 */

char * thoc_getFileName( char *dir, char *file )
{
    static char filename[MAX_FILENAME];

    snprintf(filename,sizeof(filename),"%s/%s", dir, file );
    return filename;
}

time_t thoc_convertTimeString( const char *string )
{
    time_t time_es;
    struct tm timeptr;

    strptime( string, "$Date: %Y/%m/%d %H:%M:%S", &timeptr ); 
    time_es = mktime( &timeptr );
    return time_es;
}

char *one_argument_cs( char *argument, char *arg_first )
{
   char cEnd;

   while( isspace(*argument) )
      argument++;

    cEnd = ' ';
    if ( *argument == '\'' || *argument == '"' )
    cEnd = *argument++;

    while ( *argument != '\0' )
    {
      if ( *argument == cEnd )
      {
         argument++;
         break;
      }
        *arg_first = *argument;
        arg_first++;
        argument++;
    }
    *arg_first = '\0';

    while ( isspace(*argument) )
        argument++;

      return argument;
}

/*
 * Pick off one argument from a string and return the rest.
 * Understands quotes.
 */
char *one_argument( char *argument, char *arg_first )
{
    char cEnd;

    while ( isspace(*argument) )
    argument++;

    cEnd = ' ';
    if ( *argument == '\'' || *argument == '"' )
    cEnd = *argument++;

    while ( *argument != '\0' )
    {
    if ( *argument == cEnd )
    {
        argument++;
        break;
    }
    *arg_first = LOWER(*argument);
    arg_first++;
    argument++;
    }
    *arg_first = '\0';

    while ( isspace(*argument) )
    argument++;

    return argument;
}

int mult_argument(char *argument, char *arg)
{
    char *pdot;
    int number;

    for ( pdot = argument; *pdot != '\0'; pdot++ )
    {
        if ( *pdot == '*' )
        {
            *pdot = '\0';
            number = atoi( argument );
            *pdot = '*';
            strcpy( arg, pdot+1 );
            return number;
        }
    }

    strcpy( arg, argument );
    return 1;
}

/*
 * Given a string like 14.foo, return 14 and 'foo'
 */
int number_argument( char *argument, char *arg )
{
    char *pdot;
    int number;

    for ( pdot = argument; *pdot != '\0'; pdot++ )
    {
    if ( *pdot == '.' )
    {
        *pdot = '\0';
        number = atoi( argument );
        *pdot = '.';
        strcpy( arg, pdot+1 );
        return number;
    }
    }

    strcpy( arg, argument );
    return 1;
}

/*
 * Return true if an argument is completely numeric.
 */
bool is_number ( char *arg )
{

    if ( *arg == '\0' )
        return FALSE;

    if ( *arg == '+' || *arg == '-' )
        arg++;

    for ( ; *arg != '\0'; arg++ )
    {
        if ( !isdigit( *arg ) )
            return FALSE;
    }

    return TRUE;
}

char * format_date( time_t string, const char *fmt )
{
    static char time_str[80];
    struct tm *time_tm;

    time_tm = localtime(&string);   
    strftime(time_str,sizeof(time_str),fmt,time_tm);
    return time_str;
}

bool is_name ( char *str, char *namelist )
{
    char name[MAX_INPUT_LENGTH], part[MAX_INPUT_LENGTH];
    char *list, *string;

    /* fix crash on NULL namelist */
    if (namelist == NULL || namelist[0] == '\0')
        return FALSE;

    /* fixed to prevent is_name on "" returning TRUE */
    if (str[0] == '\0')
        return FALSE;

    string = str;
    /* we need ALL parts of string to match part of namelist */
    for ( ; ; )  /* start parsing string */
    {
        str = one_argument(str,part);

        if (part[0] == '\0' )
            return TRUE;

        /* check to see if this is part of namelist */
        list = namelist;
        for ( ; ; )  /* start parsing namelist */
        {
            list = one_argument(list,name);
            if (name[0] == '\0')  /* this name was not found */
                return FALSE;
    
            if (!str_prefix(string,name))
                return TRUE; /* full pattern match */
    
            if (!str_prefix(part,name))
                break;
        }
    }
}

bool is_exact_name(char *str, char *namelist )
{   
    char name[MAX_INPUT_LENGTH];
    
    if (namelist == NULL)
        return FALSE;

    for ( ; ; )
    {
        namelist = one_argument( namelist, name );
        if ( name[0] == '\0' )
            return FALSE;
        if ( !str_cmp( str, name ) )
            return TRUE;
    }
}   

char *ratio_color( int cur, int max, bool fMANA  )
{
    static char c[3];

    c[0] = '&';
    c[2] = '\0';
    if ( cur > (3*max/4) || max <= 0 )
        c[1] = 'x';
    else
    if ( cur > (max/2) )
        c[1] = 'Y';
    else
    if ( cur > (max/4) )
        c[1] = fMANA ? 'B' : 'R';
    else
        c[1] = fMANA ? 'b' : 'r';

   return c;
}

int con_diff( int level1, int level2 )
{
    int con_range;

    con_range = level1 / 10 + 1;
    return ( level1 - level2 ) / con_range;
}

char get_con_color( int level1, int level2 )
{
    int diff;

    diff = con_diff( level1, level2 );
    switch ( diff )
    {
        case 0: return 'W';
        case 1: return 'B';
        case 2: return 'G';
        case -1: return 'Y';
        case -2: return 'R';
        default:
            if ( diff < -2 )
                return 'M';
            else
            if ( diff > 2 )
                return 'x';
            else
            {
                log_bug("bad con amount",0);
                return 'x';
            }
    }
}

int strlen_nocol( char *x )
{   
    int len = 0;
    
    while( *x != '\0' )
    {   
        if ( *x == '&' && *(x+1) != '&' )
        {   
            x += 2;
            continue;
        }
        
        ++x;
        ++len;
    }
    
    return len;
}

void applySkillAdjust( int *val, int base, int numer, int denom )
{   
    int bonus;
    
    if ( denom == 0 )
        return;
    
    bonus = base + ( numer * 100 / denom );
    *val = ( *val * bonus / 100 );
}


float getDPS( int numDice, int typeDice, int tSecs )
{
    float dps;
    float secs;

    if ( tSecs == 0 )
        return 0.0;

    secs = tSecs;
    secs /= 10;

    dps = ((typeDice * numDice) - numDice) / 2 + numDice;
    dps = typeDice * numDice / 2;
    dps /= secs;

    return dps;
}

// Dec/18/03
// Ben's utility functions to handle books with 20 spells.  We're set up to
// only use 10 bits for each spell currently.  If the spell table gets bigger
// than 1024 spells this'll break.  And that's 10 unsigned bits, by the way.

// Sets the low-order ten btis of 'vector' to those of 'value'.  In truth,
// if value has bits set above 2^10, they will be retained.  Be careful.
long set10Bits( long vector, long value )
{   
    long tmp;
    
    vector |= BITS10;
    tmp = BITS10MASK | value;
    vector &= tmp;

    return vector;
}   
       
// Sets the 11th-20th low-order bits ov 'vector' to the bottom ten of 'value'.
// No sanity check for that other bits in 'value' aren't set.
long set20Bits( long vector, long value )
{       
    long tmp;
        
    vector |= BITS20;
    tmp = BITS20MASK | (value<<10);
    vector &= tmp;
            
    return vector;
}           
            
long get10Bits( long vector )
{
    return vector & BITS10;
}       
            
long get20Bits( long vector )
{       
    vector >>= 10;
    return vector & BITS10;
}

int readline(int fd, char *ptr, int maxlen)
{
    int n, rc;
    char    c;

    for (n = 1; n < maxlen; n++)
    {
        if ( (rc = read(fd, &c, 1)) == 1)
        {
            *ptr++ = c;
            if (c == '\n')
                break;
        }
        else if (rc == 0)
        {
            if (n == 1)
                return(0);  /* EOF, no data read */
            else
                break;      /* EOF, some data was read */
        }
        else
            return(-1); /* error */
    }

    *ptr = 0;
    return(n);
}

