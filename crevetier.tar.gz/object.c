/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include "thoc.h"

/* returns number of people on an object */
int count_users(Object *obj)
{
    Character *fch;
    int count = 0;

    if (obj->in_room == NULL)
	return 0;

    for (fch = obj->in_room->people; fch != NULL; fch = fch->next_in_room)
	if (fch->on == obj)
	    count++;

    return count;
}
     
/*
 * Give an obj to a char.
 */
void obj_to_char( Object *obj, Character *ch )
{
    obj->next_content	 = ch->carrying;
    ch->carrying	 = obj;
    obj->carried_by	 = ch;
    obj->in_room	 = NULL;
    obj->in_obj		 = NULL;
    ch->carry_number	+= get_obj_number( obj );
    ch->carry_weight	+= get_obj_weight( obj );
}

/*
 * Take an obj from its character.
 */
void obj_from_char( Object *obj )
{
    Character *ch;

    if ( ( ch = obj->carried_by ) == NULL )
    {
	    log_bug( "Obj_from_char: null ch.", 0 );
	    return;
    }

    if ( obj->wear_loc != WEAR_NONE )
		unequip_char( ch, obj );

    if ( ch->carrying == obj )
    {
	ch->carrying = obj->next_content;
    }
    else
    {
	Object *prev;

	for ( prev = ch->carrying; prev != NULL; prev = prev->next_content )
	{
	    if ( prev->next_content == obj )
	    {
		prev->next_content = obj->next_content;
		break;
	    }
	}

	if ( prev == NULL )
	    log_bug( "Obj_from_char: obj not in list.", 0 );
    }

    obj->carried_by	 = NULL;
    obj->next_content	 = NULL;
    ch->carry_number	-= get_obj_number( obj );
    ch->carry_weight	-= get_obj_weight( obj );
    return;
}



/*
 * Find the ac value of an obj, including position effect.
 */
int apply_ac( Object *obj, int iWear, int type )
{
	int ac = 0;

    if ( obj->item_type != ITEM_ARMOR )
		return 0;

    switch ( iWear )
    {
    case WEAR_FACE:			ac = obj->value[type] * .2; break;
    case WEAR_SHOULDERS: 	ac = obj->value[type] * 1.2; break;
    case WEAR_BODY:			ac = obj->value[type] * 2; break;
    case WEAR_HEAD:			ac = obj->value[type] * 1; break;
    case WEAR_LEGS:			ac = obj->value[type] * 1.4; break;
    case WEAR_FEET:			ac = obj->value[type] * 1; break;
    case WEAR_HANDS:		ac = obj->value[type] * 1; break;
    case WEAR_ARMS:			ac = obj->value[type] * .8; break;
    case WEAR_SHIELD:		ac = obj->value[type] * 1.5; break;
    case WEAR_NECK_1:		ac = obj->value[type] * 0; break;
    case WEAR_NECK_2:		ac = obj->value[type] * 0; break;
    case WEAR_ABOUT:		ac = obj->value[type] * 1; break;
    case WEAR_WAIST:		ac = obj->value[type] * 1; break;
    case WEAR_WRIST_L:		ac = obj->value[type] * .5; break;
    case WEAR_WRIST_R:		ac = obj->value[type] * .5; break;
    case WEAR_HOLD:			ac = obj->value[type] * 0; break;
    }

    return modForCondition( obj, ac );
}

int modForCondition( Object *obj, int value )
{
	if ( value <= 0 )
		return value;

	value = value * obj->condition / 100;
	/*value = value * obj->durability / 100;*/
	value = value * obj->quality / 100;
	return UMAX(1,value);
}

/*
 * Count occurrences of an obj in a list.
 */
int count_obj_list( ObjIndex *pObjIndex, Object *list )
{
    Object *obj;
    int nMatch;

    nMatch = 0;
    for ( obj = list; obj != NULL; obj = obj->next_content )
    {
	if ( obj->pIndexData == pObjIndex )
	    nMatch++;
    }

    return nMatch;
}

/*
 * Move an obj out of a room.
 */
void obj_from_room( Object *obj )
{
    Room *in_room;
    Character *ch;

    if ( ( in_room = obj->in_room ) == NULL )
    {
	    log_bug( "obj_from_room: NULL.", 0 );
	    return;
    }

    for (ch = in_room->people; ch != NULL; ch = ch->next_in_room)
	if (ch->on == obj)
	    ch->on = NULL;

    if ( obj == in_room->contents )
	    in_room->contents = obj->next_content;
    else
    {
	    Object *prev;

	    for ( prev = in_room->contents; prev; prev = prev->next_content )
	    {
	        if ( prev->next_content == obj )
	        {
		    prev->next_content = obj->next_content;
		    break;
	        }
	    }

	    if ( prev == NULL )
	    {
	        log_bug( "Obj_from_room: obj not found.", 0 );
	        return;
	    }
    }

    obj->in_room      = NULL;
    obj->next_content = NULL;
	
	resetObjectSpawn( obj );
    REMOVE_BIT( obj->extra_flags, ITEM_NOSHOW );
    return;
}

/*
 * Move an obj into a room.
 */
void obj_to_room( Object *obj, Room *pRoomIndex )
{
    obj->next_content		= pRoomIndex->contents;
    pRoomIndex->contents	= obj;
    obj->in_room		= pRoomIndex;
    obj->carried_by		= NULL;
    obj->in_obj			= NULL;
    return;
}

/*
 * Move an object into an object.
 */
void obj_to_obj( Object *obj, Object *obj_to )
{
    obj->next_content		= obj_to->contains;
    obj_to->contains		= obj;
    obj->in_obj			= obj_to;
    obj->in_room		= NULL;
    obj->carried_by		= NULL;
    if (obj_to->pIndexData->vnum == OBJ_VNUM_PIT)
        obj->cost = 0; 

    for ( ; obj_to != NULL; obj_to = obj_to->in_obj )
    {
	if ( obj_to->carried_by != NULL )
	{
	    obj_to->carried_by->carry_number += get_obj_number( obj );
	    obj_to->carried_by->carry_weight += get_obj_weight( obj )
		* WEIGHT_MULT(obj_to) / 100;
	}
    }

    return;
}

/*
 * Move an object out of an object.
 */
void obj_from_obj( Object *obj )
{
    Object *obj_from;

    if ( ( obj_from = obj->in_obj ) == NULL )
    {
		log_bug( "Obj_from_obj: null obj_from.", 0 );
		return;
    }

    if ( obj == obj_from->contains )
    {
		obj_from->contains = obj->next_content;
    }
    else
    {
		Object *prev;

		for ( prev = obj_from->contains; prev; prev = prev->next_content )
		{
	    	if ( prev->next_content == obj )
	    	{
				prev->next_content = obj->next_content;
				break;
	    	}
		}

		if ( prev == NULL )
		{
	    	log_bug( "Obj_from_obj: obj not found.", 0 );
	    	return;
		}
    }

    obj->next_content = NULL;
    obj->in_obj       = NULL;

	/* If from_obj is now empty, we reset its content spawn and flag reset */
	if ( obj_from->spawn != NULL && obj_from->contains == NULL )
	{
		SET_BIT(obj_from->spawn->flags,SPAWN_CONTENT);
		return;
	}

    for ( ; obj_from != NULL; obj_from = obj_from->in_obj )
    {
		if ( obj_from->carried_by != NULL )
		{
	    	obj_from->carried_by->carry_number -= get_obj_number( obj );
	    	obj_from->carried_by->carry_weight -= get_obj_weight( obj ) 
			* WEIGHT_MULT(obj_from) / 100;
		}
    }

    return;
}

/*
 * Extract an obj from the world.
 */
void extract_obj( Object *obj )
{
    Object *obj_content;
    Object *obj_next;

    if ( obj->in_room != NULL )
		obj_from_room( obj );
    else if ( obj->carried_by != NULL )
		obj_from_char( obj );
    else if ( obj->in_obj != NULL )
		obj_from_obj( obj );

    for ( obj_content = obj->contains; obj_content; obj_content = obj_next )
    {
		obj_next = obj_content->next_content;
		extract_obj( obj_content );
    }

    if ( object_list == obj )
    {
	object_list = obj->next;
    }
    else
    {
	Object *prev;

	for ( prev = object_list; prev != NULL; prev = prev->next )
	{
	    if ( prev->next == obj )
	    {
		prev->next = obj->next;
		break;
	    }
	}

	if ( prev == NULL )
	{
	    log_bug( "Extract_obj: obj %d not found.", obj->pIndexData->vnum );
	    return;
	}
    }

    --obj->pIndexData->count;
	resetObjectSpawn( obj );
    free_obj(obj);
    return;
}


/*
 * Find some object with a given index data.
 * Used by area-reset 'P' command.
 */
Object *get_obj_type( ObjIndex *pObjIndex )
{
    Object *obj;

    for ( obj = object_list; obj != NULL; obj = obj->next )
    {
	if ( obj->pIndexData == pObjIndex )
	    return obj;
    }

    return NULL;
}

/*
 * Return # of objects which an object counts as.
 * Thanks to Tony Chamberlain for the correct recursive code here.
 */
int get_obj_number( Object *obj )
{
    int number;
 
    if (obj->item_type == ITEM_CONTAINER || obj->item_type == ITEM_MONEY
    ||  obj->item_type == ITEM_GEM || obj->item_type == ITEM_JEWELRY)
        number = 0;
    else
        number = 1;
 
    for ( obj = obj->contains; obj != NULL; obj = obj->next_content )
        number += get_obj_number( obj );
 
    return number;
}


/*
 * Return weight of an object, including weight of contents.
 */
int get_obj_weight( Object *obj )
{
    int weight;
    Object *tobj;

    weight = obj->weight;
    for ( tobj = obj->contains; tobj != NULL; tobj = tobj->next_content )
		weight += get_obj_weight( tobj ) * WEIGHT_MULT(obj) / 100;

    return weight;
}

int get_true_weight(Object *obj)
{
    int weight;
 
    weight = obj->weight;
    for ( obj = obj->contains; obj != NULL; obj = obj->next_content )
        weight += get_obj_weight( obj );
 
    return weight;
}

bool has_unique( Object *obj )
{
    Object *pObj;

    if ( IS_SET(obj->extra_flags,ITEM_UNIQUE) )
	return TRUE;
    else
    if ( obj->contains == NULL )
	return FALSE;
    else
    for ( pObj = obj->contains ; pObj != NULL ; pObj = pObj->next_content )
    {
        if ( has_unique( pObj ) )
	    return TRUE;
    }

    return FALSE;
}

