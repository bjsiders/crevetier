#include <stdlib.h>
#include <stdarg.h>
#include <errno.h>
#include <string.h>
#include "defines.h"
#include "thoc.h"
#include "thocerror.h"

// Error organization from Stevens APUE
char *thoclog_msg_prefix[3] = { "", "[BUG] ", "[ERR] " };

// Log a generic string
void log_string( const char *fmt, ... )
{
    va_list     ap;

    va_start( ap, fmt );
    thoc_log( fmt, ap, THOCLOG_STRING );
    va_end( ap );
    return;
}

// Log a bug condition
void log_bug( const char *fmt, ... )
{
    va_list     ap;

    va_start( ap, fmt );
    thoc_log( fmt, ap, THOCLOG_BUG );
    va_end( ap );
    return;
}

// Log a system error
void log_error( const char *fmt, ... )
{
    va_list     ap;
    
    va_start( ap, fmt );
    thoc_log( fmt, ap, THOCLOG_ERROR );
    va_end( ap );
    return;
}

/*
thoc_log is a generic interface to the game logs, and handles automatic
naming and cycling of logfiles.  Bugs and errors go into their own log
files.  Log lines have the format YYYY-MM-DD HH:MM:SS for easy merging
and sorting.  Log files are named <port_type>_<DD>_<HH>_<YY>.log.
*/ 

bool firstLog = TRUE;
void thoc_log( const char *fmt, va_list ap, int msg_type )
{
    char            buf[MAX_STRING_LENGTH*4];
    static char     last_file[MAX_FILENAME];
    char            this_file[MAX_FILENAME];
    static FILE     *fp;
#if defined(__ARPENS)
    char            *label = "thoc";
#elif defined(__OLC)
    char            *label = "olc";
#elif defined(__TEST)
    char            *label = "test";
#else
    char            *label = "badlabel";
#endif
    struct timeval  now_time;
    time_t          time_es;
    int             errno_save = errno;

    // Create log message 
    gettimeofday( &now_time, NULL );
    time_es  = (time_t) now_time.tv_sec;
    snprintf(buf,sizeof(buf),"%s :: %s", 
                format_date( time_es, "%C%y-%m-%d %H:%S:%M" ),
                thoclog_msg_prefix[msg_type] );
    vsnprintf(buf+strlen(buf),sizeof(buf)-strlen(buf),fmt,ap);
    switch( msg_type )
    {
        case THOCLOG_ERROR:
            snprintf(buf+strlen(buf),sizeof(buf)-strlen(buf),": %s", strerror(errno_save) );
        default:
            break;
    }

    // Find log file to use
    snprintf(this_file,sizeof(this_file),"%s/%s_%s.log",
        getDirectory(LOG_DIR), label, format_date( time_es, "%d_%b_%y" ) );

    if ( firstLog || strncmp( this_file, last_file, sizeof(this_file) ) )
    {
        if ( !firstLog )
        {
            fprintf(fp,"(End of daily output)\n\n");
            fclose(fp);
        }

        if ( (fp = fopen(this_file,"a")) == NULL )
            fp = stderr;

        strcpy( last_file, this_file );
        firstLog = FALSE;
    }

    fprintf( fp, "%s\n", buf );
    fflush( fp );
    return;
}
        
