/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/** System Include Files **/
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/** Custom Header Files **/
#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "tables.h"
#include "recycle.h"

/** The library of Warlock spells, arranged alphabetically */
bool spell_agility( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(50);
    af.modifier     = 45;
    af.location     = APPLY_DEX;
    af.flags        = AFF_SPELL;
	af.bitvector	= 0;
    spellAffectToChar( victim, &af );

    act("You feel more nimble.",victim,NULL,NULL,TO_CHAR);
    act("$n looks more nimble.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_alacrity( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(32);
    af.modifier     = 78;
    af.location     = APPLY_SPEED;
    af.bitvector    = AFF_HASTE;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n begins to move more quickly.",victim,NULL,NULL,TO_ROOM);
    act("You begin to move more quickly.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_blast_of_flame( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
	int   dam;

	dam = calcSpellDamage(ch,sn,lowDam(25),highDam(30));

    if ( check_saves_spell(ch, victim, DAM_FIRE, SAVE_REFLEX) )
    	dam /= 2;
    damage( ch, victim, dam, sn, DAM_FIRE , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_blast_of_ice( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;
    int   dam;

	dam = calcSpellDamage(ch,sn,lowDam(95),highDam(114));
    
    if ( check_saves_spell(ch, victim, DAM_COLD, SAVE_REFLEX) )
        dam /= 2;   
    else
    {
        af.where        = TO_AFFECTS;
        af.type         = sn;
        af.level        = level;
        af.duration     = minutes(12);
        af.location     = APPLY_SPEED;
        af.modifier     = 120;
        af.bitvector    = 0;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("You feel lethargic.",victim,NULL,NULL,TO_CHAR);
        act("$n appears to be lethargic.",victim,NULL,NULL,TO_ROOM);
    }

    damage( ch, victim, dam, sn, DAM_COLD , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_cataclysmic_detonation( int sn, int level, Character *ch,void *vo,int target) 
{
    Character *victim = (Character *) vo;
	int   dam;

	dam = calcSpellDamage(ch,sn,lowDam(167),highDam(202));

    if ( check_saves_spell(ch, victim, DAM_FIRE, SAVE_REFLEX) )
    	dam /= 2;
    damage( ch, victim, dam, sn, DAM_FIRE , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_cold_intolerance( int sn, int level, Character *ch,void *vo,int target) 
{
	Character *victim = (Character *) vo;
	Affect af;

	if ( check_saves_spell(ch,victim,DAM_COLD,SAVE_FORTITUDE) )
	{
		cprintf(ch,"You failed.\n\r");
		cprintf(victim,"You shiver momentarily.\n\r");
		return TRUE;
	}

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(12);
    af.modifier  = -12;
    af.location  = APPLY_RES_ICE;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

	act("$n shivers uncomfortably.",victim,NULL,NULL,TO_ROOM);
	act("You shiver uncomfortably!",victim,NULL,NULL,TO_CHAR);
	return TRUE;
}

bool spell_cold_vulnerability( int sn, int level, Character *ch,void *vo,int target) 
{
	Character *victim = (Character *) vo;
	Affect af;

	if ( check_saves_spell(ch,victim,DAM_COLD,SAVE_FORTITUDE) )
	{
		cprintf(ch,"You failed.\n\r");
		cprintf(victim,"You shiver momentarily.\n\r");
		return TRUE;
	}

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(12);
    af.modifier  = -20;
    af.location  = APPLY_RES_ICE;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

	act("$n shivers uncomfortably.",victim,NULL,NULL,TO_ROOM);
	act("You shiver uncomfortably!",victim,NULL,NULL,TO_CHAR);
	return TRUE;
}

bool spell_ekpyrotic_blast( int sn, int level, Character *ch,void *vo,int target) 
{
    Character *victim = (Character *) vo;
	int   dam;

	dam = calcSpellDamage(ch,sn,lowDam(98),highDam(119));

    if ( check_saves_spell(ch, victim, DAM_FIRE, SAVE_REFLEX) )
    	dam /= 2;
    damage( ch, victim, dam, sn, DAM_FIRE , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_ekpyrotic_shell( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;
    
    af.where        = DAMAGE_SHIELD;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(14);
    af.modifier     = 18;   
    af.location     = 18;
    af.bitvector    = DAM_FIRE;
    af.flags        = AFF_SPELL;
    spellAffectToChar(victim,&af);

    act("$n is surrounded by a shell of ekpyrotic power.",victim,NULL,NULL,TO_ROOM);
    act("You are surrounded by a shell of ekpyrotic power.",victim,NULL,NULL,TO_CHAR);
    return TRUE; 
}   

bool spell_explosive_burst( int sn, int level, Character *ch,void *vo,int target) 
{
    Character *victim = (Character *) vo;
	int   dam;

	dam = calcSpellDamage(ch,sn,lowDam(12),highDam(15));

    if ( check_saves_spell(ch, victim, DAM_FIRE, SAVE_REFLEX) )
    	dam /= 2;
    damage( ch, victim, dam, sn, DAM_FIRE , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_heat_wave( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
	int   dam;

	dam = calcSpellDamage(ch,sn,lowDam(40),highDam(55));

    if ( check_saves_spell(ch, victim, DAM_FIRE, SAVE_REFLEX) )
    	dam /= 2;
    damage( ch, victim, dam, sn, DAM_FIRE , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_fireball( int sn, int level, Character *ch,void *vo,int target) 
{
    Character *victim = (Character *) vo;
	int   dam;

	dam = calcSpellDamage(ch,sn,lowDam(66),highDam(80));

    if ( check_saves_spell(ch, victim, DAM_FIRE, SAVE_REFLEX) )
    	dam /= 2;
    damage( ch, victim, dam, sn, DAM_FIRE , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_fire_intolerance( int sn, int level, Character *ch,void *vo,int target)
{   
    Character *victim = (Character *) vo;
    Affect af;   
    
    if ( check_saves_spell(ch,victim,DAM_FIRE,SAVE_FORTITUDE) )
    {
        cprintf(ch,"You failed.\n\r");
        cprintf(victim,"You begin to sweat momentarily.\n\r");
        return TRUE;
    }
        
    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(12);
    af.modifier  = -10;
    af.location  = APPLY_RES_FIRE;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );
    
    act("$n begins to sweat profusely.",victim,NULL,NULL,TO_ROOM);
    act("You begin to sweat profusely!",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_fire_shell( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = DAMAGE_SHIELD;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(10);
    af.modifier     = 5;
    af.location     = 5;  
    af.bitvector    = DAM_FIRE;
    af.flags        = AFF_SPELL;
    spellAffectToChar(victim,&af);

    act("$n is surrounded by a shell of fire.",victim,NULL,NULL,TO_ROOM);
    act("You are surrounded by a shell of fire.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_fire_vulnerability( int sn, int level, Character *ch,void *vo,int target)
{  
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch,victim,DAM_FIRE,SAVE_FORTITUDE) )
    {
        cprintf(ch,"You failed.\n\r");
        cprintf(victim,"You begin to sweat momentarily.\n\r");
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(12);
    af.modifier  = -18;
    af.location  = APPLY_RES_FIRE;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n begins to sweat profusely.",victim,NULL,NULL,TO_ROOM);
    act("You begin to sweat profusely!",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_flameburst( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

	dam = calcSpellDamage(ch,sn,lowDam(5),highDam(6));

    if ( check_saves_spell(ch, victim, DAM_FIRE, SAVE_REFLEX) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_FIRE , DF_SHOW|DF_SPELL );
    return TRUE;
}

bool spell_flame_shell( int sn, int level, Character *ch,void *vo,int target )
{
	Character *victim = (Character *) vo;
	Affect af;

	af.where		= DAMAGE_SHIELD;
	af.type			= sn;
	af.level		= level;
	af.duration		= minutes(8);
	af.modifier		= 2;
	af.location		= 2;
	af.bitvector	= DAM_FIRE;
	af.flags		= AFF_SPELL;
	spellAffectToChar(victim,&af);

	act("$n is surrounded by a shell of flame.",victim,NULL,NULL,TO_ROOM);
	act("You are surrounded by a shell of flame.",victim,NULL,NULL,TO_CHAR);
	return TRUE;
}

bool spell_frostbite( int sn, int level, Character *ch,void *vo,int target )
{
	Character *victim = (Character *) vo;
	Affect af;
    int   dam;
   
	dam = calcSpellDamage(ch,sn,lowDam(9),highDam(10)); 

    if ( check_saves_spell(ch, victim, DAM_COLD, SAVE_REFLEX) )
        dam /= 2;   
	else
	{
		af.where		= TO_AFFECTS;
		af.type			= sn;
		af.level		= level;
		af.duration		= minutes(12);
		af.location		= APPLY_SPEED;
		af.modifier		= 108;
		af.bitvector	= 0;
		af.flags		= AFF_SPELL;
		spellAffectToChar( victim, &af );

		act("You feel lethargic.",victim,NULL,NULL,TO_CHAR);
		act("$n appears to be lethargic.",victim,NULL,NULL,TO_ROOM);
	}

    damage( ch, victim, dam, sn, DAM_COLD , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_frostburst( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;
    int   dam;

	dam = calcSpellDamage(ch,sn,lowDam(181),highDam(219));
    
    if ( check_saves_spell(ch, victim, DAM_COLD, SAVE_REFLEX) )
        dam /= 2;   
    else
    {
        af.where        = TO_AFFECTS;
        af.type         = sn;
        af.level        = level;
        af.duration     = minutes(12);
        af.location     = APPLY_SPEED;
        af.modifier     = 128;
        af.bitvector    = 0;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("You feel lethargic.",victim,NULL,NULL,TO_CHAR);
        act("$n appears to be lethargic.",victim,NULL,NULL,TO_ROOM);
    }

    damage( ch, victim, dam, sn, DAM_COLD , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_frost_blast( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;
    int   dam;
   
	dam = calcSpellDamage(ch,sn,lowDam(51),highDam(61));     
    
    if ( check_saves_spell(ch, victim, DAM_COLD, SAVE_REFLEX) )
        dam /= 2;   
    else
    {
        af.where        = TO_AFFECTS;
        af.type         = sn;
        af.level        = level;
        af.duration     = minutes(12);
        af.location     = APPLY_SPEED;
        af.modifier     = 116;
        af.bitvector    = 0;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("You feel lethargic.",victim,NULL,NULL,TO_CHAR);
        act("$n appears to be lethargic.",victim,NULL,NULL,TO_ROOM);
    }

    damage( ch, victim, dam, sn, DAM_COLD , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_frost_rift( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;
    int   dam;
       
	dam = calcSpellDamage(ch,sn,lowDam(25),highDam(31));

    if ( check_saves_spell(ch, victim, DAM_COLD, SAVE_REFLEX) )
        dam /= 2;   
    else
    {
        af.where        = TO_AFFECTS;
        af.type         = sn;
        af.level        = level;
        af.duration     = minutes(12);
        af.location     = APPLY_SPEED;
        af.modifier     = 112;
        af.bitvector    = 0;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("You feel lethargic.",victim,NULL,NULL,TO_CHAR);
        act("$n appears to be lethargic.",victim,NULL,NULL,TO_ROOM);
    }

    damage( ch, victim, dam, sn, DAM_COLD , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_greater_agility( int sn, int level, Character *ch,void *vo,int target )
{   
    Character *victim = (Character *) vo;
    Affect af;
    
    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(62);
    af.modifier     = 75; 
    af.location     = APPLY_DEX;
    af.flags        = AFF_SPELL;
	af.bitvector		= 0;
    spellAffectToChar( victim, &af );
    
    act("You feel more nimble.",victim,NULL,NULL,TO_CHAR);
    act("$n looks more nimble.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
} 

bool spell_greater_alacrity( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.modifier     = 70;
    af.location     = APPLY_SPEED;
    af.bitvector    = AFF_HASTE;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n begins to move more quickly.",victim,NULL,NULL,TO_ROOM);
    act("You begin to move more quickly.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_greater_health( int sn, int level, Character *ch,void *vo,int target )
{   
    Character *victim = (Character *) vo;
    Affect af;
    
    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(62);
    af.modifier     = 75; 
    af.location     = APPLY_CON;
    af.flags        = AFF_SPELL;
	af.bitvector	= 0;
    spellAffectToChar( victim, &af );
    
    act("You feel more robust.",victim,NULL,NULL,TO_CHAR);
    act("$n looks more robust.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
} 

bool spell_greater_surge( int sn, int level, Character *ch,void *vo,int target )
{  
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(64);
    af.modifier     = 75;
    af.location     = APPLY_STR;
    af.flags        = AFF_SPELL;
	af.bitvector	= 0;
    spellAffectToChar( victim, &af );

    act("Your muscles surge with heightened strength!",victim,NULL,NULL,TO_CHAR); 
    act("$n's muscles surges with heightened strength!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_health( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(50);
    af.modifier     = 45;
    af.location     = APPLY_CON;
    af.flags        = AFF_SPELL;
	af.bitvector	= 0;
    spellAffectToChar( victim, &af );

    act("You feel more robust.",victim,NULL,NULL,TO_CHAR);
    act("$n looks more robust.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_heavy_feet( int sn, int level, Character *ch,void *vo,int target )
{
	Character *victim = (Character *) vo;
	Affect af;

	if ( check_saves_spell(ch,victim,DAM_OTHER,SAVE_FORTITUDE) )
	{
		act("Your limbs feel heavy momentarily.",victim,NULL,NULL,TO_CHAR);
		cprintf(ch,"Nothing appears to happen.\n\r");
		return TRUE;
	}

	af.where		= TO_AFFECTS;
	af.type			= sn;
	af.level		= level;
	af.duration		= seconds(24);
	af.location		= APPLY_MOVE_RATE;
	af.modifier		= PULSE_PER_SECOND / 3;
	af.bitvector	= 0;
	af.flags 		= AFF_SPELL;
	spellAffectToChar(victim,&af);

	act("Your limbs feel heavy and lethargic.",victim,NULL,NULL,TO_CHAR);
	act("$n appears slow and lethargic.",victim,NULL,NULL,TO_ROOM);
	return TRUE;
}

bool spell_iceburst( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;
    int   dam;

	dam = calcSpellDamage(ch,sn,lowDam(242),highDam(293));

    if ( check_saves_spell(ch, victim, DAM_COLD, SAVE_REFLEX) )
        dam /= 2;
    else
    {
        af.where        = TO_AFFECTS;
        af.type         = sn;
        af.level        = level;
        af.duration     = minutes(12);
        af.location     = APPLY_SPEED;
        af.modifier     = 132;
        af.bitvector    = 0;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("You feel lethargic.",victim,NULL,NULL,TO_CHAR);
        act("$n appears to be lethargic.",victim,NULL,NULL,TO_ROOM);
    }

    damage( ch, victim, dam, sn, DAM_COLD , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_laden_feet( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch,victim,DAM_OTHER,SAVE_FORTITUDE) )
    {
        act("Your limbs feel heavy momentarily.",victim,NULL,NULL,TO_CHAR);
        cprintf(ch,"Nothing appears to happen.\n\r");
        return TRUE;   
    }

    af.where        = TO_AFFECTS;
    af.type         = sn; 
    af.level        = level;
    af.duration     = seconds(28);
    af.location     = APPLY_MOVE_RATE;
    af.modifier     = PULSE_PER_SECOND / 2;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar(victim,&af);

    act("Your limbs feel heavy and lethargic.",victim,NULL,NULL,TO_CHAR);
    act("$n appears slow and lethargic.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_lamentable_burden( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch,victim,DAM_OTHER,SAVE_FORTITUDE) )
    {
        act("Your limbs feel heavy momentarily.",victim,NULL,NULL,TO_CHAR);
        cprintf(ch,"Nothing appears to happen.\n\r");
        return TRUE;   
    }

    af.where        = TO_AFFECTS;
    af.type         = sn; 
    af.level        = level;
    af.duration     = seconds(36);
    af.location     = APPLY_MOVE_RATE;
    af.modifier     = PULSE_PER_SECOND;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar(victim,&af);

    act("Your limbs feel heavy and lethargic.",victim,NULL,NULL,TO_CHAR);
    act("$n appears slow and lethargic.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_lesser_agility( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(44);
    af.modifier     = 30;
    af.location     = APPLY_DEX;
    af.flags        = AFF_SPELL;
	af.bitvector	= 0;
    spellAffectToChar( victim, &af );

    act("You feel more nimble.",victim,NULL,NULL,TO_CHAR);
    act("$n looks more nimble.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_lesser_health( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(44);
    af.modifier     = 30;
    af.location     = APPLY_CON;
    af.flags        = AFF_SPELL;
	af.bitvector	= 0;
    spellAffectToChar( victim, &af );

    act("You feel more robust.",victim,NULL,NULL,TO_CHAR);
    act("$n looks more robust.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_lesser_alacrity( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(28);
    af.modifier     = 84;
    af.location     = APPLY_SPEED;
    af.bitvector    = AFF_HASTE;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n begins to move more quickly.",victim,NULL,NULL,TO_ROOM);
    act("You begin to move more quickly.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_lesser_surge( int sn, int level, Character *ch,void *vo,int target )
{  
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(38);
    af.modifier     = 30;
    af.location     = APPLY_STR;
    af.flags        = AFF_SPELL;
	af.bitvector	= 0;
    spellAffectToChar( victim, &af );

    act("Your muscles surge with heightened strength!",victim,NULL,NULL,TO_CHAR); 
    act("$n's muscles surges with heightened strength!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_magma_shell( int sn, int level, Character *ch,void *vo,int target )
{   
    Character *victim = (Character *) vo;
    Affect af;
 
    af.where        = DAMAGE_SHIELD;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(12);
    af.modifier     = 10;
    af.location     = 10;   
    af.bitvector    = DAM_FIRE;   
    af.flags        = AFF_SPELL;
    spellAffectToChar(victim,&af);   
    
    act("$n is surrounded by a shell of magma.",victim,NULL,NULL,TO_ROOM);
    act("You are surrounded by a shell of magma.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
} 

bool spell_major_agility( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(56);
    af.modifier     = 60;
    af.location     = APPLY_DEX;
    af.flags        = AFF_SPELL;
	af.bitvector	= 0;
    spellAffectToChar( victim, &af );

    act("You feel more nimble.",victim,NULL,NULL,TO_CHAR);
    act("$n looks more nimble.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_major_alacrity( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(36);
    af.modifier     = 74;
    af.location     = APPLY_SPEED;
    af.bitvector    = AFF_HASTE;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n begins to move more quickly.",victim,NULL,NULL,TO_ROOM);
    act("You begin to move more quickly.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_major_cold_intolerance( int sn, int level, Character *ch,void *vo,int target)
{   
    Character *victim = (Character *) vo;
    Affect af;
    
    if ( check_saves_spell(ch,victim,DAM_COLD,SAVE_FORTITUDE) )
    {
        cprintf(ch,"You failed.\n\r");
        cprintf(victim,"You shiver momentarily.\n\r"); 
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(12);
    af.modifier  = -16;
    af.location  = APPLY_RES_ICE;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );
    
    act("$n shivers uncomfortably.",victim,NULL,NULL,TO_ROOM);
    act("You shiver uncomfortably!",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}   

bool spell_major_cold_vulnerability( int sn, int level, Character *ch,void *vo,int target)
{   
    Character *victim = (Character *) vo;
    Affect af;
    
    if ( check_saves_spell(ch,victim,DAM_COLD,SAVE_FORTITUDE) )
    {
        cprintf(ch,"You failed.\n\r");
        cprintf(victim,"You shiver momentarily.\n\r"); 
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(12);
    af.modifier  = -24;
    af.location  = APPLY_RES_ICE;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );
    
    act("$n shivers uncomfortably.",victim,NULL,NULL,TO_ROOM);
    act("You shiver uncomfortably!",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_major_fire_intolerance( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch,victim,DAM_FIRE,SAVE_FORTITUDE) )
    {
        cprintf(ch,"You failed.\n\r");
        cprintf(victim,"You begin to sweat momentarily.\n\r");
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(12);
    af.modifier  = -14;
    af.location  = APPLY_RES_FIRE;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n begins to sweat profusely.",victim,NULL,NULL,TO_ROOM);
    act("You begin to sweat profusely!",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_major_fire_vulnerability( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch,victim,DAM_FIRE,SAVE_FORTITUDE) )
    {
        cprintf(ch,"You failed.\n\r");
        cprintf(victim,"You begin to sweat momentarily.\n\r");
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(12);
    af.modifier  = -22;
    af.location  = APPLY_RES_FIRE;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );
   
    act("$n begin to sweat profusely.",victim,NULL,NULL,TO_ROOM);
    act("You begin to sweat profusely.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_major_health( int sn, int level, Character *ch,void *vo,int target )
{   
    Character *victim = (Character *) vo;
    Affect af;
    
    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(56);
    af.modifier     = 60; 
    af.location     = APPLY_CON;
    af.flags        = AFF_SPELL;
	af.bitvector		= 0;
    spellAffectToChar( victim, &af );
    
    act("You feel more robust.",victim,NULL,NULL,TO_CHAR);
    act("$n looks more robust.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
} 

bool spell_major_surge( int sn, int level, Character *ch,void *vo,int target )
{  
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(54);
    af.modifier     = 60;
    af.location     = APPLY_STR;
    af.flags        = AFF_SPELL;
	af.bitvector	= 0;
    spellAffectToChar( victim, &af );

    act("Your muscles surge with heightened strength!",victim,NULL,NULL,TO_CHAR); 
    act("$n's muscles surges with heightened strength!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_mana_drop( int sn, int level, Character *ch,void *vo,int target )
{   
    Character *victim = (Character *) vo;
    int dam;
 
    dam = ch->mana / 2.5;
	ch->mana = 0;
    damage( ch, victim, dam, sn, DAM_LIGHTNING , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_mana_purge( int sn, int level, Character *ch,void *vo,int target )
{   
    Character *victim = (Character *) vo;
    int dam;
 
    dam = ch->mana / 2;
	ch->mana = 0;
    damage( ch, victim, dam, sn, DAM_LIGHTNING , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_mana_burn( int sn, int level, Character *ch,void *vo,int target )
{   
    Character *victim = (Character *) vo;
    int dam;
 
    dam = ch->mana / 1.5;
	ch->mana = 0;
    damage( ch, victim, dam, sn, DAM_LIGHTNING , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_mana_surge( int sn, int level, Character *ch,void *vo,int target )
{   
    Character *victim = (Character *) vo;
    int dam;
 
    dam = ch->mana;
	ch->mana = 0;
    damage( ch, victim, dam, sn, DAM_LIGHTNING , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_minor_agility( int sn, int level, Character *ch,void *vo,int target )
{
	Character *victim = (Character *) vo;
	Affect af;

	af.where		= TO_AFFECTS;
	af.type			= sn;
	af.level		= level;
	af.duration		= minutes(38);
	af.modifier		= 15;
	af.location		= APPLY_DEX;
	af.bitvector	= 0;
	af.flags		= AFF_SPELL;
	spellAffectToChar( victim, &af );

	act("You feel more nimble.",victim,NULL,NULL,TO_CHAR);
	act("$n looks more nimble.",victim,NULL,NULL,TO_ROOM);
	return TRUE;
}

bool spell_minor_alacrity( int sn, int level, Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	Affect af;

	af.where		= TO_AFFECTS;
	af.type			= sn;
	af.level		= level;
	af.duration		= minutes(24);
	af.modifier		= 88;
	af.location		= APPLY_SPEED;
	af.bitvector	= AFF_HASTE;
	af.flags		= AFF_SPELL;
	spellAffectToChar( victim, &af );

	act("$n begins to move more quickly.",victim,NULL,NULL,TO_ROOM);
	act("You begin to move more quickly.",victim,NULL,NULL,TO_CHAR);
	return TRUE;
}

bool spell_minor_cold_intolerance( int sn, int level, Character *ch,void *vo,int target)
{   
    Character *victim = (Character *) vo;
    Affect af;
        
    if ( check_saves_spell(ch,victim,DAM_COLD,SAVE_FORTITUDE) )
    {
        cprintf(ch,"You failed.\n\r");
        cprintf(victim,"You shiver momentarily.\n\r");
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(12);
    af.modifier  = -8;
    af.location  = APPLY_RES_ICE;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("$n shivers uncomfortably.",victim,NULL,NULL,TO_ROOM);
    act("You shiver uncomfortably!",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_minor_fire_intolerance( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af; 
    
    if ( check_saves_spell(ch,victim,DAM_FIRE,SAVE_FORTITUDE) )
    {
        cprintf(ch,"You failed.\n\r");   
        cprintf(victim,"You begin to sweat momentarily.\n\r");
        return TRUE;
    }   
    
    af.where     = TO_AFFECTS;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(12);
    af.modifier  = -6; 
    af.location  = APPLY_RES_FIRE;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );
    
    act("$n begins to sweat profusely.",victim,NULL,NULL,TO_ROOM);
    act("You begin to sweat profusely!",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_minor_health( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(38);
    af.modifier     = 15;
    af.location     = APPLY_CON;
	af.bitvector	= 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("You feel more robust.",victim,NULL,NULL,TO_CHAR);
    act("$n looks more robust.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_minor_surge( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(30);
    af.modifier     = 15;
    af.location     = APPLY_STR;
	af.bitvector	= 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your muscles surge with heightened strength!",victim,NULL,NULL,TO_CHAR);
    act("$n's muscles surges with heightened strength!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_rift_of_ice( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;
    int   dam;
    
	dam = calcSpellDamage(ch,sn,lowDam(128),highDam(155));
    
    if ( check_saves_spell(ch, victim, DAM_COLD, SAVE_REFLEX) )
        dam /= 2;   
    else
    {
        af.where        = TO_AFFECTS;
        af.type         = sn;
        af.level        = level;
        af.duration     = minutes(12);
        af.location     = APPLY_SPEED;
        af.modifier     = 124;
        af.bitvector    = 0;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("You feel lethargic.",victim,NULL,NULL,TO_CHAR);
        act("$n appears to be lethargic.",victim,NULL,NULL,TO_ROOM);
    }

    damage( ch, victim, dam, sn, DAM_COLD , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_strength_surge( int sn, int level, Character *ch,void *vo,int target )
{  
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(46);
    af.modifier     = 45;
    af.location     = APPLY_STR;
    af.flags        = AFF_SPELL;
	af.bitvector	= 0;
    spellAffectToChar( victim, &af );

    act("Your muscles surge with heightened strength!",victim,NULL,NULL,TO_CHAR); 
    act("$n's muscles surges with heightened strength!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_weighted_feet( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch,victim,DAM_OTHER,SAVE_FORTITUDE) )
    {
        act("Your limbs feel heavy momentarily.",victim,NULL,NULL,TO_CHAR);
        cprintf(ch,"Nothing appears to happen.\n\r");
        return TRUE;   
    }

    af.where        = TO_AFFECTS;
    af.type         = sn; 
    af.level        = level;
    af.duration     = seconds(32);
    af.location     = APPLY_MOVE_RATE;
    af.modifier     = PULSE_PER_SECOND * 2 / 3;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar(victim,&af);

    act("Your limbs feel heavy and lethargic.",victim,NULL,NULL,TO_CHAR);
    act("$n appears slow and lethargic.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_shadowdraw( int sn, int level, Character *ch, void *vo, int target )
{
	Character *victim = (Character *) vo;
	Character *pet;
	int conj_skill, hp_max;
	int i;

	if( ch->pet != NULL )
	{
		cprintf(ch,"Dismiss the one you have!\n\r");
		return FALSE;
	}

	pet = create_mobile( get_mob_index( MOB_VNUM_SHADOWBEAST ) );
    pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
    char_to_room( pet, ch->in_room );

	pet->class = csn_ranger;
	conj_skill = get_skill(ch,skill_lookup("conjuration"));
	hp_max = conj_skill * 5;
	pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
	pet->max_base_hit = pet->max_stat_hit / 5;
	pet->stat_hit = pet->max_stat_hit;
	pet->base_hit = pet->max_base_hit;
	pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000; /* these guys never exhaust */
	pet->level = conj_skill;

	for( i = 0; i < MAX_STATS ; i++ )
		pet->perm_stat[i] = 100 + (conj_skill*3);

	for( i = 0 ; i < 4 ; i++ )
		pet->armor[i] = conj_skill / 4;
	pet->armor[3] /= 4;

	pet->hitroll = conj_skill / 3;
	pet->damage[0] = 3;
	pet->damage[1] = 4;
	pet->damage[2] = conj_skill / 4;

	act("$n summons forth $N from the Plane of Shadows!", ch,NULL,pet,TO_NOTVICT);
	act("You summon forth $N from the Plane of Shadows!", ch,NULL,pet,TO_CHAR);

    pet_to_group( ch, pet );
	char_to_group( pet, ch->pgroup );
	one_hit( pet, victim, TYPE_UNDEFINED );
	return TRUE;
}

bool spell_shadowcall( int sn, int level, Character *ch, void *vo, int target )
{
	Character *victim = (Character *) vo;
	Character *pet;
	int conj_skill, hp_max;
	int i;

	if( ch->pet != NULL )
	{
		cprintf(ch,"Dismiss the one you have!\n\r");
		return FALSE;
	}

	pet = create_mobile( get_mob_index( MOB_VNUM_SHADOWBEAST ) );
    pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
    char_to_room( pet, ch->in_room );

	pet->class = csn_ranger;
	conj_skill = get_skill(ch,skill_lookup("conjuration"));
	hp_max = conj_skill * 9;
	pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
	pet->max_base_hit = pet->max_stat_hit / 5;
	pet->stat_hit = pet->max_stat_hit;
	pet->base_hit = pet->max_base_hit;
	pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000; /* these guys never exhaust */
	pet->level = conj_skill;

	for( i = 0; i < MAX_STATS ; i++ )
		pet->perm_stat[i] = 100 + (conj_skill*3);

	for( i = 0 ; i < 4 ; i++ )
		pet->armor[i] = conj_skill / 3;
	pet->armor[3] /= 4;

	pet->hitroll = conj_skill / 2;
	pet->damage[0] = 3;
	pet->damage[1] = 6;
	pet->damage[2] = conj_skill / 3;

	act("$n summons forth $N from the Plane of Shadows!", ch,NULL,pet,TO_NOTVICT);
	act("You summon forth $N from the Plane of Shadows!", ch,NULL,pet,TO_CHAR);

    pet_to_group( ch, pet );
	char_to_group( pet, ch->pgroup );
	one_hit( pet, victim, TYPE_UNDEFINED );
	return TRUE;
}

bool spell_shadowbind( int sn, int level, Character *ch, void *vo, int target )
{
	Character *victim = (Character *) vo;
	Character *pet;
	int conj_skill, hp_max;
	int i;

	if( ch->pet != NULL )
	{
		cprintf(ch,"Dismiss the one you have!\n\r");
		return FALSE;
	}

	pet = create_mobile( get_mob_index( MOB_VNUM_SHADOWBEAST ) );
    pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
    char_to_room( pet, ch->in_room );

	pet->class = csn_fighter;
	conj_skill = get_skill(ch,skill_lookup("conjuration"));
	hp_max = conj_skill * 14;
	pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
	pet->max_base_hit = pet->max_stat_hit / 5;
	pet->stat_hit = pet->max_stat_hit;
	pet->base_hit = pet->max_base_hit;
	pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000; /* these guys never exhaust */
	pet->level = conj_skill;

	for( i = 0; i < MAX_STATS ; i++ )
		pet->perm_stat[i] = 100 + (conj_skill*3);

	for( i = 0 ; i < 4 ; i++ )
		pet->armor[i] = conj_skill / 2;
	pet->armor[3] /= 4;

	pet->hitroll = conj_skill * 2 / 3;
	pet->damage[0] = 3;
	pet->damage[1] = 8;
	pet->damage[2] = conj_skill / 2;

	act("$n summons forth $N from the Plane of Shadows!", ch,NULL,pet,TO_NOTVICT);
	act("You summon forth $N from the Plane of Shadows!", ch,NULL,pet,TO_CHAR);

    pet_to_group( ch, pet );
	char_to_group( pet, ch->pgroup );
	one_hit( pet, victim, TYPE_UNDEFINED );
	return TRUE;
}

bool spell_shadowrule( int sn, int level, Character *ch, void *vo, int target )
{
	Character *victim = (Character *) vo;
	Character *pet;
	int conj_skill, hp_max;
	int i;

	if( ch->pet != NULL )
	{
		cprintf(ch,"Dismiss the one you have!\n\r");
		return FALSE;
	}

	pet = create_mobile( get_mob_index( MOB_VNUM_SHADOWBEAST ) );
    pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
    char_to_room( pet, ch->in_room );

	pet->class = csn_fighter;
	conj_skill = get_skill(ch,skill_lookup("conjuration"));
	hp_max = conj_skill * 20;
	pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
	pet->max_base_hit = pet->max_stat_hit / 5;
	pet->stat_hit = pet->max_stat_hit;
	pet->base_hit = pet->max_base_hit;
	pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000; /* these guys never exhaust */
	pet->level = conj_skill;

	for( i = 0; i < MAX_STATS ; i++ )
		pet->perm_stat[i] = 100 + (conj_skill*3);

	for( i = 0 ; i < 4 ; i++ )
		pet->armor[i] = conj_skill * 2 / 3;
	pet->armor[3] /= 4;

	pet->hitroll = conj_skill;
	pet->damage[0] = 3;
	pet->damage[1] = 10;
	pet->damage[2] = conj_skill * 2 / 3;

	act("$n summons forth $N from the Plane of Shadows!", ch,NULL,pet,TO_NOTVICT);
	act("You summon forth $N from the Plane of Shadows!", ch,NULL,pet,TO_CHAR);

    pet_to_group( ch, pet );
	char_to_group( pet, ch->pgroup );
	one_hit( pet, victim, TYPE_UNDEFINED );
	return TRUE;
}

bool spell_shadowlord( int sn, int level, Character *ch, void *vo, int target )
{
	Character *victim = (Character *) vo;
	Character *pet;
	int conj_skill, hp_max;
	int i;

	if( ch->pet != NULL )
	{
		cprintf(ch,"Dismiss the one you have!\n\r");
		return FALSE;
	}

	pet = create_mobile( get_mob_index( MOB_VNUM_SHADOWBEAST ) );
    pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
    char_to_room( pet, ch->in_room );

	pet->class = csn_barbarian;
	conj_skill = get_skill(ch,skill_lookup("conjuration"));
	hp_max = conj_skill * 27;
	pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
	pet->max_base_hit = pet->max_stat_hit / 5;
	pet->stat_hit = pet->max_stat_hit;
	pet->base_hit = pet->max_base_hit;
	pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000; /* these guys never exhaust */
	pet->level = conj_skill;

	for( i = 0; i < MAX_STATS ; i++ )
		pet->perm_stat[i] = 100 + (conj_skill*3);

	for( i = 0 ; i < 4 ; i++ )
		pet->armor[i] = conj_skill;
	pet->armor[3] /= 4;

	pet->hitroll = conj_skill * 3 / 2;
	pet->damage[0] = 3;
	pet->damage[1] = 12;
	pet->damage[2] = conj_skill;

	act("$n summons forth $N from the Plane of Shadows!", ch,NULL,pet,TO_NOTVICT);
	act("You summon forth $N from the Plane of Shadows!", ch,NULL,pet,TO_CHAR);

    pet_to_group( ch, pet );
	char_to_group( pet, ch->pgroup );
	one_hit( pet, victim, TYPE_UNDEFINED );
	return TRUE;
}

