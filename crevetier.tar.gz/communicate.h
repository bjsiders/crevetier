/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#ifndef act_comm_h
#define act_comm_h

/*
    Static global channels
*/
#define CHAN_SAME_CLAN  (A)
#define MAX_CHANNELS    10
#define MAX_SOCIALS     256

struct buf_type
{
    Buffer *  next;
    bool      valid;
    sh_int    state;  /* error state of the buffer */
    sh_int    size;   /* size in k */
    char *    string; /* buffer's string */
};

struct    channel_type
{
    int     *index;
    char*   name;
    char*   verb;
    char*   verb_3rd;
    long    flags;
    int     minimum_level;
    long    on_off_bit;
    char    defaultColor;
};

extern int CHANNEL_HOCKEY;
extern int CHANNEL_OOCTALK;
extern int CHANNEL_GOSSIP;
extern int CHANNEL_GRATS;
extern int CHANNEL_QUESTION;
extern int CHANNEL_ANSWER;
extern int CHANNEL_AUCTION;
extern int CHANNEL_QUEST;
extern int CHANNEL_IMMTALK;
extern int CHANNEL_ADMINTALK;
extern int CHANNEL_CLANTALK;
extern int CHANNEL_MUSIC;
extern int CHANNEL_RT;
extern int CHANNEL_RTSUB;

struct round_table_handler
{
	char allSquelched;
	char rtSubPresent;
	char whoShown;
	char autoAccept;
	char logged;
    //char secret;
	Character *leader;
	Character *currentInLine;
	Character *lastInLine;
	FILE *fp;
	int timeStarted;
	int currentTalkTime; /*Time allowed before it will switch*/
};

struct round_table_pointers
{
    Character *prevChar;
    Character *nextChar;
    Roundtable *handler;
    unsigned char rtvalue;
};

struct rt_type
{
    char    *name;
    void    (*rt_fun)(Character *, char*, char*, bool);
    char    status;
};

struct ignore_tag
{
    char *              name;
    Ignore *            next;
};

/*
 * Structure for a social in the socials table.
 */
struct social_type
{
    char      name[20];
    char *    char_no_arg;
    char *    others_no_arg;
    char *    char_found;
    char *    others_found;
    char *    vict_found;
    char *    char_not_found;
    char *    char_auto;
    char *    others_auto;
};

struct wiznet_type
{
    char *   name;
    long     flag;
    int      level;
};

#define MAX_IGNORE          20

/* RT comm flags -- may be used on both mobs and chars */
#define COMM_QUIET                  (A)
#define COMM_DEAF                   (B)
#define COMM_NOWIZ                  (C)
#define COMM_NOAUCTION              (D)
#define COMM_NOGOSSIP               (E)
#define COMM_NOQUESTION             (F)
#define COMM_NOHOCKEY               (G)
#define COMM_NOMUSIC                (H)
#define COMM_NOCLAN                 (I)
#define COMM_NOQUEST                (I)
#define COMM_WIZCLAN                (J)
#define COMM_NOADMIN                (K)
#define COMM_NOCLANINFO             (L)
#define COMM_NORT                   (M)
#define COMM_NORTSUB                (N)
#define COMM_TELNET_GA              (O)
#define COMM_NOGRATS                (P)
#define COMM_NOOOC                  (Q)
#define COMM_NOEMOTE                (S)
#define COMM_NOSHOUT                (T)
#define COMM_NOTELL                 (U)
#define COMM_NOCHANNELS             (V)
#define COMM_SNOOP_PROOF            (W)
#define COMM_AFK                    (X)

#define WIZ_ON                      (A)
#define WIZ_TICKS                   (B)
#define WIZ_LOGINS                  (C)
#define WIZ_SITES                   (D)
#define WIZ_LINKS                   (E)
#define WIZ_DEATHS                  (F)
#define WIZ_RESETS                  (G)
#define WIZ_MOBDEATHS               (H)
#define WIZ_FLAGS                   (I)
#define WIZ_PENALTIES               (J)
#define WIZ_SACCING                 (K)
#define WIZ_LEVELS                  (L)
#define WIZ_SECURE                  (M)
#define WIZ_SWITCHES                (N)
#define WIZ_SNOOPS                  (O)
#define WIZ_RESTORE                 (P)
#define WIZ_LOAD                    (Q)
#define WIZ_NEWBIE                  (R)
#define WIZ_PREFIX                  (S)
#define WIZ_SPAM                    (T)
#define WIZ_NOTES                   (U)
#define WIZ_NOTRANS                 (V)
#define WIZ_DEBUG                   (W)
#define WIZ_DISPVNUM                (X)
#define WIZ_GUILDS                  (Y)

/*
    Roundtable dynamic channels
*/
#define RTEMPTY         0
#define RTLEADER        (A)
#define RTSUBOFF        (B)
//#define RTINVITED (C)
#define RTBANNED        (D)
//#define RTNOTIFY (E)
#define RTSUBBANNED     (F)
#define RTEXTRAOFF      (G)
#define RTINLINE        (H)
#define RTMASK        (A|B|C|D|E|F|G|H) //maximum if all toggles are on

#define RTINDEXCURRENT  1
#define RTINDEXLAST     2
#define RTINDEXMIDDLE   3
#define RTINDEXAFTER    4

/*round table macros*/
#define RT_ANYONE 0
#define RT_LEADER 1
#define RT_CREATE 2

/*Round Table anyone functions*/
#define DECLARE_RT_FUNCTION(x)  void x ( Character *, char *, char *, bool )
void rtc_create( Character *, char *, char *, bool );
void rtc_accept( Character *, char *, char *, bool );
void rtc_decline( Character *, char *, char *, bool );
void rtc_add( Character *, char *, char *, bool );
void rtc_remove( Character *, char *, char *, bool );
void rtc_done(Character *, char *, char *, bool );
void rtc_current( Character *, char *, char *, bool );
void rtc_list( Character *, char *, char *, bool );
void rtc_listall(Character *, char *, char *, bool );
void rtc_exit( Character *, char *, char *, bool );
/*Round Table leader only functions*/
void rtc_passcontrol(Character *, char *, char *, bool );
void rtc_invite( Character *, char *, char *, bool );
void rtc_logging( Character *, char *, char *, bool );
void rtc_squelch( Character *, char *, char *, bool );
void rtc_squelchsub( Character *, char *, char *, bool );
void rtc_ordername( Character *, char *, char *, bool );
void rtc_ordernumber( Character *, char *, char *, bool );
void rtc_kick( Character *, char *, char *, bool );
void rtc_allsquelched( Character *, char *, char *, bool );
void rtc_subpresent( Character *, char *, char *, bool );
void rtc_whoshown( Character *, char *, char *, bool );
void rtc_autoaccept( Character *, char *, char *, bool );
void rtc_showsettings( Character *, char *, char *, bool );
int  rt_lookup( const char *verb );
Character* rt_checkInTable(Character *ch, char *victimName);
void rt_messageAll(Character *ch, char *message, bool fMain);
void rt_listAdd(Character *ch, int loc, int index);
void rt_listRemove(Character *ch);
bool isIgnoring( Character *ch, char *name );//Other places need this one

void wizprintf( Character *ch, Object *obj,
                long flag, long flag_skip, int min_level,
                const char *fmt, ... );
void pnetprintf( Character *ch, Object *obj,
                long flag, long flag_skip, int min_level,
                const char *fmt, ... );


extern const struct wiznet_type     wiznet_table[];
extern const struct wiznet_type     pnet_table[];
extern const struct channel_type    channel_table[];
extern       struct social_type     social_table[MAX_SOCIALS];

#endif /* act_comm_h*/
