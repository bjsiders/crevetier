/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#include <sys/types.h>
#include <sys/time.h>
#include <dirent.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <ctype.h>
#include <sys/resource.h>
#include <dlfcn.h>
#include "thoc.h"
#include "interp.h"
#include "recycle.h"
#include "olc.h"
#include "tables.h"
#include "lookup.h"
#include "db.h"

/*
 * Local functions.
 */
bool write_to_descriptor ( int desc, char *txt, int length );
bool check_parse_name	( char * );
bool check_being_created_name	( char * );
Room *	find_location	( Character *ch, char *arg );
void do_openvnum_room( Character *ch, int lvalue, int hvalue );
void do_openvnum_obj ( Character *ch, int lvalue, int hvalue );
void do_openvnum_mob ( Character *ch, int lvalue, int hvalue );
DECLARE_DO_FUN( do_spellset 	);
DECLARE_DO_FUN( do_marealist );
DECLARE_DO_FUN( do_rarealist );
DECLARE_DO_FUN( do_oarealist );
DECLARE_DO_FUN( do_qarealist );
DECLARE_DO_FUN( do_darealist );
DECLARE_DO_FUN( do_tsarealist );
DECLARE_DO_FUN( do_farealist );
void do_mload( Character *, char *, unsigned char );
void do_oload( Character *, char *, unsigned char, bool);
void do_rfind( Character *, char * );
void do_qfind( Character *, char * );
void do_sstat( Character *ch, char *argument );
void do_pset( Character *ch, char *argument );
void reward_player(Character* ch, Character* victim, int percent, bool show_output);

void do_pnet( Character *ch, char *argument )
{
    int flag;
    char buf[MAX_STRING_LENGTH];
    char arg[MAX_INPUT_LENGTH];

    one_argument( argument, arg );

	if ( IS_NPC(ch) )
	{
		cprintf(ch,"Foolish MOB!  No pnet for you!\n\r");
		return;
	}

    if ( arg[0] == '\0' )
    {
        send_to_char("Syntax: pnet [on|off|show|flag]\n\r",ch);
        return;
    }
    else
    if ( !str_cmp(arg, "on") )
    {
        SET_BIT(ch->pcdata->pnet,WIZ_ON);
        send_to_char("PlayerNet is now &cON&x.\n\r",ch);
        return;
    }
    else
    if ( !str_cmp(arg, "off") )
    {
        REMOVE_BIT(ch->pcdata->pnet,WIZ_ON);
        send_to_char("PlayerNet is now &rOFF&x.\n\r",ch);
        return;
    }
    else
    if (!str_prefix(argument,"show") || !str_prefix(argument,"status") )
    {
        int col = 0;

        cprintf(ch,"PlayerNet: %s\n\r\n\r",
            IS_SET(ch->pcdata->pnet,WIZ_ON) ? "&GON&x" : "&ROFF&x" );

        for (flag = 1; pnet_table[flag].name != NULL; flag++)
        {
            if ( col++ % 3 == 0 )
                send_to_char("\n\r",ch);

            sprintf(buf,"    %-10s [&g%c&x]",
                pnet_table[flag].name,
                IS_SET(ch->pcdata->pnet,pnet_table[flag].flag) ?
                    'X' : ' ' );
            send_to_char(buf,ch);
        }
        send_to_char("\n\r",ch);
        return;
    }

    flag = pnet_lookup(argument);

    if (flag == -1 )
    {
        send_to_char("No such option.\n\r",ch);
        return;
    }

    if (IS_SET(ch->pcdata->pnet,pnet_table[flag].flag))
    {
        sprintf(buf,"PlayerNet option %s &rdisabled&x.\n\r",
                pnet_table[flag].name);
        send_to_char(buf,ch);
        REMOVE_BIT(ch->pcdata->pnet,pnet_table[flag].flag);
        return;
    }
    else
    {
        sprintf(buf,"PlayerNet option %s &cenabled&x.\n\r",
                pnet_table[flag].name);
        send_to_char(buf,ch);
        SET_BIT(ch->pcdata->pnet,pnet_table[flag].flag);
        return;
    }

}

void do_wiznet( Character *ch, char *argument )
{
    int flag;
    char buf[MAX_STRING_LENGTH];
    char arg[MAX_INPUT_LENGTH];

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
        send_to_char("Syntax: wiznet [on|off|show|flag]\n\r",ch);
        send_to_char("  flag: toggle &cflag&x on|off\n\r",ch);
        return;
    }
    else
    if ( !str_cmp(arg, "on") )
    {
        SET_BIT(ch->wiznet,WIZ_ON);
        send_to_char("Wiznet is now &cON&x.\n\r",ch);
        return;
    }
    else
    if ( !str_cmp(arg, "off") )
    {
        REMOVE_BIT(ch->wiznet,WIZ_ON);
        send_to_char("Wiznet is now &rOFF&x.\n\r",ch);
        return;
    }
    else
    if (!str_prefix(argument,"show") || !str_prefix(argument,"status") )
    {
        int col = 0;

        sprintf(buf,"Wiznet: %s    Transfers: %s\n\r\n\r",
            IS_SET(ch->wiznet,WIZ_ON) ? "&GON&x" : "&ROFF&x",
            !IS_SET(ch->wiznet,WIZ_NOTRANS) ? "&GON&x" : "&ROFF&x");
        send_to_char(buf,ch);

        for (flag = 1; wiznet_table[flag].name != NULL; flag++)
        {
            if ( col++ % 3 == 0 )
                send_to_char("\n\r",ch);

			if (get_trust(ch) < wiznet_table[flag].level)
				sprintf(buf,"    %-10s [%-7s]",
					wiznet_table[flag].name,
					"&D---&x");
			else
				sprintf(buf,"    %-10s [%-7s]",
					wiznet_table[flag].name,
					IS_SET(ch->wiznet,wiznet_table[flag].flag) ?
						"&GON&x" : "&ROFF&x" );
            send_to_char(buf,ch);
        }
        send_to_char("\n\r",ch);
        return;
    }

    flag = wiznet_lookup(argument);

    if (flag == -1 || get_trust(ch) < wiznet_table[flag].level)
    {
        send_to_char("No such option.\n\r",ch);
        return;
    }

    if (IS_SET(ch->wiznet,wiznet_table[flag].flag))
    {
        sprintf(buf,"Wiznet %s &rdisabled&x.\n\r",
                wiznet_table[flag].name);
        send_to_char(buf,ch);
        REMOVE_BIT(ch->wiznet,wiznet_table[flag].flag);
        return;
    }
    else
    {
        sprintf(buf,"Wiznet %s &cenabled&x.\n\r",
                wiznet_table[flag].name);
        send_to_char(buf,ch);
        SET_BIT(ch->wiznet,wiznet_table[flag].flag);
        return;
    }

}

void pnetprintf( Character *ch, Object *obj,
                long flag, long flag_skip, int min_level,
                const char *fmt, ... )
{
    va_list ap;
    char buf[MAX_STRING_LENGTH];

    va_start( ap, fmt );
    vsnprintf(buf,sizeof(buf),fmt,ap);
    va_end( ap );

    pnet( buf, ch, obj, flag, flag_skip, min_level );
}

void pnet(char *string, Character *ch, Object *obj, long flag, long flag_skip , int min_level )
{
    Descriptor *d;

	/* Only use min_level for IMMs */
	if ( min_level <= 51 )
		min_level = 1;

	if ( ch && IS_IMMORTAL(ch) )
		return;

    for ( d = descriptor_list; d != NULL; d = d->next )
    {
        if (d->connected == CON_PLAYING
	&&	!IS_NPC(d->character)
    &&  IS_SET(d->character->pcdata->pnet,WIZ_ON)
    &&  get_trust(d->character) >= min_level 
    &&  (!flag || IS_SET(d->character->pcdata->pnet,flag))
    &&  (!flag_skip || !IS_SET(d->character->pcdata->pnet,flag_skip))
    &&  d->character != ch)
        {
        	send_to_char("--> ",d->character);
            act_ooc(string,d->character,obj,ch,TO_CHAR,POS_DEAD,TRUE);
        }
    }

    return;
}

void wizprintf( Character *ch, Object *obj,
                long flag, long flag_skip, int min_level,
                const char *fmt, ... )
{
    va_list ap;
    char buf[MAX_STRING_LENGTH];

    va_start( ap, fmt );
    vsnprintf(buf,sizeof(buf),fmt,ap);
    va_end( ap );

    wiznet( buf, ch, obj, flag, flag_skip, min_level );
}

void wiznet(char *string, Character *ch, Object *obj,
	    long flag, long flag_skip, int min_level) 
{
    Descriptor *d;

    for ( d = descriptor_list; d != NULL; d = d->next )
    {
        if (d->connected == CON_PLAYING
	&&  IS_IMMORTAL(d->character) 
	&&  IS_SET(d->character->wiznet,WIZ_ON) 
	&&  (!flag || IS_SET(d->character->wiznet,flag))
	&&  (!flag_skip || !IS_SET(d->character->wiznet,flag_skip))
	&&  get_trust(d->character) >= min_level
	&&  d->character != ch)
        {
	    if (IS_SET(d->character->wiznet,WIZ_PREFIX))
	  	send_to_char("--> ",d->character);
            act_new(string,d->character,obj,ch,TO_CHAR,POS_DEAD,TRUE);
        }
    }
 
    return;
}


void do_guild( Character *ch, char *argument )
{
    char arg1[MAX_INPUT_LENGTH],arg2[MAX_INPUT_LENGTH],arg3[MAX_INPUT_LENGTH];
    Character *victim;
    Clan 	* clan;
	int rank;

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );
    argument = one_argument( argument, arg3 );

    if ( arg1[0] == '\0' || (arg2[0] == '\0' && strcmp( arg1, "list")) || (arg3[0] != '\0' && !is_number(arg3)) )
    {
        send_to_char( "Syntax: guild <char> <clan name|none> <clan rank #1-9>\n\r",ch);
		cprintf(ch,   "        guild rank <char> <new rank #1-9>\n\r");
		cprintf(ch,   "        guild rename <old name> <new name>\n\r");
		cprintf(ch,   "        guild list\n\r");
        return;
    }

	if ( !strcmp( arg1, "list" ) )
	{
		Clan *clan;

		for( clan = clan_table ; clan ; clan = clan->next )
			cprintf(ch," * %s\n\r", clan->name);

		return;
	}

	if ( !strcmp( arg1, "rename" ) )
	{
		Clan *clan;

		if ( (clan = clan_lookup( arg2 )) == NULL )
		{
			cprintf(ch,"Could not find a clan called '%s'\n\r",arg2);
			return;
		}

		if ( argument[0] == '\0' )
		{
			cprintf(ch,"Usage: guild rename <old guild> <new guild>\n\r");
			return;
		}

		free_string (clan->name);
		clan->name = str_dup( argument );
		clan_info(clan,ch,"$N has renamed your guild to '%s'.",clan->name);
		cprintf(ch,"Clan has been renamed to '%s'.\n\r",clan->name);
		save_clans( );
		return;
	}

	if ( !strcmp( arg1, "rank" ) )
	{
    	if ( ( victim = get_char_ooc( ch, arg2 ) ) == NULL )
    	{
       	 	send_to_char( "They aren't playing.\n\r", ch );
        	return;
    	}
   
    	if ( IS_NPC(victim) )
    	{
			cprintf(ch,"Not on NPCs.\n\r");
			return;
    	}

		rank = atoi(arg3);

		if(rank < 1 || rank > 9)
		{
			cprintf(ch, "Valid clan rank is 1-9.\n\r");
			return;
		}
		else
		{
			setRank(victim,rank);
			cprintf(ch,"%s set to rank %d.\n\r", victim->name, rank);
			return;
		}
	}

    if ( ( victim = get_char_ooc( ch, arg1 ) ) == NULL )
    {
        send_to_char( "They aren't playing.\n\r", ch );
        return;
    }
   
    if ( IS_NPC(victim) )
    {
        cprintf(ch,"Not on NPCs.\n\r");
		return;
    }

    if (!str_prefix(arg2,"none"))
    {
		if ( victim != ch )
			send_to_char("They are now clanless.\n\r",ch);
		send_to_char("You are now a member of no clan!\n\r",victim);
		victim->clan = NULL;
		return;
    }
    
    if ((clan = clan_lookup(arg2)) == 0)
    {
		send_to_char("No such clan exists.\n\r",ch);
		return;
    }

	victim->clan = clan;	

	/* If the rank argument is blank, set rank to 1 */
    if( arg3[0] == '\0')
	{
	  setRank(victim,1);
	}
	else
	{
		rank = atoi(arg3);

		if(rank < 1 || rank > 9)
		{
			cprintf(ch, "Invalid clan rank.  Ranks must be 1-9.  Rank set to 1.\n\r");
			setRank(victim, 1);
		}
		else
		{
			setRank(victim,rank);
		}
	}

    if ( clan_is_independent( clan ) )
    {
		cprintf(ch,"%s is now a %s.\n\r",victim->name,victim->clan->name);
		cprintf(victim,"You are now a %s.\n\r",victim->clan->name);
    }
    else
    {
		cprintf(ch,"%s is now a member of clan %s at rank %d.\n\r",victim->name,victim->clan->name,getRank(victim));
		cprintf(victim,"You are now a member of clan %s at rank %d.\n\r",victim->clan->name,getRank(victim));
    }

	return;
}

void do_wizclan( Character *ch, char *argument )
{
	char arg[MAX_INPUT_LENGTH];
    Clan *clan;

	if(argument[0] == '\0')
	{
		if(!IS_SET(ch->comm, COMM_WIZCLAN))
		{
			SET_BIT(ch->comm, COMM_WIZCLAN);
			cprintf(ch, "Wizclan channel has been turned on.\n\r");

			if(ch->wizclan == NULL)
			{
				cprintf(ch, "You are currently watching all clan channels.\n\r");
			}
			else
			{
				if ((clan = clan_lookup(ch->wizclan->name)) == 0)
				{
					cprintf(ch, "Previously watched clan not found, wizclan set to watch all channels.\n\r");
					ch->wizclan = NULL;
					return;
				}
			
				if (clan_is_independent(clan))
				{
					cprintf(ch, "You were watching an independent clans channel, wizclan set to watch all channels.\n\r");
					ch->wizclan = NULL;
					return;
				}

				cprintf(ch, "You are currently watching the clan channel of %s.\n\r",clan->name);	
			}
			return;
		}
		else
		{
			REMOVE_BIT(ch->comm, COMM_WIZCLAN);
			cprintf(ch, "Wizclan channel has been turned off.\n\r");
			return;
		}
	}

	argument = one_argument( argument, arg );
	if (!str_prefix(arg,"all"))
	{
		cprintf(ch, "You are now watching all clan channels.\n\r");
		ch->wizclan = NULL;
		return;
	}

	if ((clan = clan_lookup(arg)) == 0)
	{
		cprintf(ch, "There is no clan channel to watch by that name.\n\r");
		return;
	}

	if (clan_is_independent(clan))
	{
		cprintf(ch, "Independent clans do not have a channel.\n\r");
		return;
	}

	ch->wizclan = clan;
	cprintf(ch, "You are now watching clan channel %s.\n\r",clan->name);
}

/* equips a character with a weapon and their stock class equipment */
void do_outfit ( Character *ch, char *argument )
{
	int i;
    Object *obj;

    if (ch->level > 5 || IS_NPC(ch))
		return;

    /* Light */
    if( (obj = create_object( get_obj_index(VNUM_NEWBIE_TORCH))) != NULL )
    {
		obj->cost = 0;
        obj_to_char( obj, ch );
    }

	for( i = 0 ; i < 8 ; i++ )
	{
    	if( get_obj_index(class_table[ch->class].outfit[i]) != NULL )
		{
			obj = create_object( get_obj_index(class_table[ch->class].outfit[i]));
   		    obj->cost = 0;
   		    obj_to_char( obj, ch );
   		}
	}

    return;
}

     
/* RT nochannels command, for those spammers */
void do_nochannels( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH], buf[MAX_STRING_LENGTH];
    Character *victim;
 
    one_argument( argument, arg );
 
    if ( arg[0] == '\0' )
    {
        send_to_char( "Nochannel whom?", ch );
        return;
    }
 
    if ( ( victim = get_char_ooc( ch, arg ) ) == NULL )
    {
        send_to_char( "They aren't here.\n\r", ch );
        return;
    }
 
    if ( get_trust( victim ) >= get_trust( ch ) )
    {
        send_to_char( "You failed.\n\r", ch );
        return;
    }
 
    if ( IS_SET(victim->comm, COMM_NOCHANNELS) )
    {
        REMOVE_BIT(victim->comm, COMM_NOCHANNELS);
        send_to_char( "The gods have restored your channel priviliges.\n\r", 
		      victim );
        send_to_char( "NOCHANNELS removed.\n\r", ch );
	sprintf(buf,"$N restores channels to %s",victim->name);
	wiznet(buf,ch,NULL,WIZ_PENALTIES,WIZ_SECURE,0);
    }
    else
    {
        SET_BIT(victim->comm, COMM_NOCHANNELS);
        send_to_char( "The gods have revoked your channel priviliges.\n\r", 
		       victim );
        send_to_char( "NOCHANNELS set.\n\r", ch );
	sprintf(buf,"$N revokes %s's channels.",victim->name);
	wiznet(buf,ch,NULL,WIZ_PENALTIES,WIZ_SECURE,0);
    }
 
    return;
}


void do_smote(Character *ch, char *argument )
{
    Character *vch;
    char *letter,*name;
    char last[MAX_INPUT_LENGTH], temp[MAX_STRING_LENGTH];
    int matches = 0;
 
    if ( !IS_NPC(ch) && IS_SET(ch->comm, COMM_NOEMOTE) )
    {
        send_to_char( "You can't show your emotions.\n\r", ch );
        return;
    }
 
    if ( argument[0] == '\0' )
    {
        send_to_char( "Emote what?\n\r", ch );
        return;
    }
    
    if (strstr(argument,ch->name) == NULL)
    {
	send_to_char("You must include your name in an smote.\n\r",ch);
	return;
    }
   
    send_to_char(argument,ch);
    send_to_char("\n\r",ch);
 
    for (vch = ch->in_room->people; vch != NULL; vch = vch->next_in_room)
    {
        if (vch->desc == NULL || vch == ch)
            continue;
 
        if ((letter = strstr(argument,vch->name)) == NULL)
        {
	    send_to_char(argument,vch);
	    send_to_char("\n\r",vch);
            continue;
        }
 
        strcpy(temp,argument);
        temp[strlen(argument) - strlen(letter)] = '\0';
        last[0] = '\0';
        name = vch->name;
 
        for (; *letter != '\0'; letter++)
        {
            if (*letter == '\'' && matches == strlen(vch->name))
            {
                strcat(temp,"r");
                continue;
            }
 
            if (*letter == 's' && matches == strlen(vch->name))
            {
                matches = 0;
                continue;
            }
 
            if (matches == strlen(vch->name))
            {
                matches = 0;
            }
 
            if (*letter == *name)
            {
                matches++;
                name++;
                if (matches == strlen(vch->name))
                {
                    strcat(temp,"you");
                    last[0] = '\0';
                    name = vch->name;
                    continue;
                }
                strncat(last,letter,1);
                continue;
            }
 
            matches = 0;
            strcat(temp,last);
            strncat(temp,letter,1);
            last[0] = '\0';
            name = vch->name;
        }
 
	send_to_char(temp,vch);
	send_to_char("\n\r",vch);
    }
 
    return;
}

void do_bamfin( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];

    if ( !IS_NPC(ch) )
    {
	smash_tilde( argument );

	if (argument[0] == '\0')
	{
	    sprintf(buf,"Your poofin is %s\n\r",ch->pcdata->bamfin);
	    send_to_char(buf,ch);
	    return;
	}

	if ( strstr(argument,ch->name) == NULL)
	{
	    send_to_char("You must include your name.\n\r",ch);
	    return;
	}
	     
	free_string( ch->pcdata->bamfin );
	ch->pcdata->bamfin = str_dup( argument );

        sprintf(buf,"Your poofin is now %s\n\r",ch->pcdata->bamfin);
        send_to_char(buf,ch);
    }
    return;
}

void do_bamfout( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
 
    if ( !IS_NPC(ch) )
    {
        smash_tilde( argument );
 
        if (argument[0] == '\0')
        {
            sprintf(buf,"Your poofout is %s\n\r",ch->pcdata->bamfout);
            send_to_char(buf,ch);
            return;
        }
 
        if ( strstr(argument,ch->name) == NULL)
        {
            send_to_char("You must include your name.\n\r",ch);
            return;
        }
 
        free_string( ch->pcdata->bamfout );
        ch->pcdata->bamfout = str_dup( argument );
 
        sprintf(buf,"Your poofout is now %s\n\r",ch->pcdata->bamfout);
        send_to_char(buf,ch);
    }
    return;
}



void do_deny( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH],buf[MAX_STRING_LENGTH];
    Character *victim;

    one_argument( argument, arg );
    if ( arg[0] == '\0' )
    {
	send_to_char( "Deny whom?\n\r", ch );
	return;
    }

    if ( ( victim = get_char_ooc( ch, arg ) ) == NULL )
    {
	send_to_char( "They aren't here.\n\r", ch );
	return;
    }

    if ( IS_NPC(victim) )
    {
	send_to_char( "Not on NPC's.\n\r", ch );
	return;
    }

    if ( get_trust( victim ) >= get_trust( ch ) )
    {
	send_to_char( "You failed.\n\r", ch );
	return;
    }

    SET_BIT(victim->act, PLR_DENY);
    send_to_char( "You are denied access!\n\r", victim );
    sprintf(buf,"$N denies access to %s",victim->name);
    wiznet(buf,ch,NULL,WIZ_PENALTIES,WIZ_SECURE,0);
    send_to_char( "OK.\n\r", ch );
    save_char_obj(victim);
    stop_fighting(victim,TRUE);
    do_function(victim, &do_quit, "" );

    return;
}



void do_disconnect( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Descriptor *d;
    Character *victim;

    one_argument( argument, arg );
    if ( arg[0] == '\0' )
    {
	send_to_char( "Disconnect whom?\n\r", ch );
	return;
    }

    if (is_number(arg))
    {
	int desc;

	desc = atoi(arg);
    	for ( d = descriptor_list; d != NULL; d = d->next )
    	{
            if ( d->descriptor == desc )
            {
            	close_socket( d );
            	send_to_char( "Ok.\n\r", ch );
            	return;
            }
	}
    }

    if ( ( victim = get_char_ooc( ch, arg ) ) == NULL )
    {
	send_to_char( "They aren't here.\n\r", ch );
	return;
    }

    if ( victim->desc == NULL )
    {
	act( "$N doesn't have a descriptor.", ch, NULL, victim, TO_CHAR );
	return;
    }

    for ( d = descriptor_list; d != NULL; d = d->next )
    {
	if ( d == victim->desc )
	{
	    close_socket( d );
	    send_to_char( "Ok.\n\r", ch );
	    return;
	}
    }

    log_bug( "Do_disconnect: desc not found.", 0 );
    send_to_char( "Descriptor not found!\n\r", ch );
    return;
}



void do_pardon( Character *ch, char *argument )
{
    char arg1[MAX_INPUT_LENGTH];
    char arg2[MAX_INPUT_LENGTH];
    Character *victim;

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );

    if ( arg1[0] == '\0' || arg2[0] == '\0' )
    {
	send_to_char( "Syntax: pardon <character> <killer|thief>.\n\r", ch );
	return;
    }

    if ( ( victim = get_char_ooc( ch, arg1 ) ) == NULL )
    {
	send_to_char( "They aren't here.\n\r", ch );
	return;
    }

    if ( IS_NPC(victim) )
    {
	send_to_char( "Not on NPC's.\n\r", ch );
	return;
    }

    if ( !str_cmp( arg2, "killer" ) )
    {
	if ( IS_SET(victim->act, PLR_KILLER) )
	{
	    REMOVE_BIT( victim->act, PLR_KILLER );
	    send_to_char( "Killer flag removed.\n\r", ch );
	    send_to_char( "You are no longer a KILLER.\n\r", victim );
	}
	return;
    }

    if ( !str_cmp( arg2, "thief" ) )
    {
	if ( IS_SET(victim->act, PLR_THIEF) )
	{
	    REMOVE_BIT( victim->act, PLR_THIEF );
	    send_to_char( "Thief flag removed.\n\r", ch );
	    send_to_char( "You are no longer a THIEF.\n\r", victim );
	}
	return;
    }

    send_to_char( "Syntax: pardon <character> <killer|thief>.\n\r", ch );
    return;
}



void do_echo( Character *ch, char *argument )
{
    Descriptor *d;

    if ( argument[0] == '\0' )
    {
		send_to_char( "Global echo what?\n\r", ch );
		return;
    }
    
    for ( d = descriptor_list; d; d = d->next )
    {
		if ( d->connected == CON_PLAYING )
		{
	    	if (get_trust(d->character) >= get_trust(ch))
				send_to_char( "global> ",d->character);
	    
			send_to_char( argument, d->character );
	    	send_to_char( "\n\r",   d->character );
		}
    }
	
    return;
}



void do_recho( Character *ch, char *argument )
{
    Descriptor *d;
    
    if ( argument[0] == '\0' )
    {
	send_to_char( "Local echo what?\n\r", ch );

	return;
    }

    for ( d = descriptor_list; d; d = d->next )
    {
	if ( d->connected == CON_PLAYING
	&&   d->character->in_room == ch->in_room )
	{
            if (get_trust(d->character) >= get_trust(ch))
                send_to_char( "local> ",d->character);
	    send_to_char( argument, d->character );
	    send_to_char( "\n\r",   d->character );
	}
    }

    return;
}

void do_zecho(Character *ch, char *argument)
{
    Descriptor *d;

    if (argument[0] == '\0')
    {
	send_to_char("Zone echo what?\n\r",ch);
	return;
    }

    for (d = descriptor_list; d; d = d->next)
    {
	if (d->connected == CON_PLAYING
	&&  d->character->in_room != NULL && ch->in_room != NULL
	&&  d->character->in_room->area == ch->in_room->area)
	{
	    if (get_trust(d->character) >= get_trust(ch))
		send_to_char("zone> ",d->character);
	    send_to_char(argument,d->character);
	    send_to_char("\n\r",d->character);
	}
    }
}

void do_pecho( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Character *victim;

    argument = one_argument(argument, arg);
 
    if ( argument[0] == '\0' || arg[0] == '\0' )
    {
	send_to_char("Personal echo what?\n\r", ch); 
	return;
    }
   
    if  ( (victim = get_char_ooc(ch, arg) ) == NULL )
    {
	send_to_char("Target not found.\n\r",ch);
	return;
    }

    if (get_trust(victim) >= get_trust(ch) && get_trust(ch) != MAX_LEVEL)
        send_to_char( "personal> ",victim);

    send_to_char(argument,victim);
    send_to_char("\n\r",victim);
    send_to_char( "personal> ",ch);
    send_to_char(argument,ch);
    send_to_char("\n\r",ch);
}


Room *find_location( Character *ch, char *arg )
{
    Character *victim;
    Object *obj;

    if ( is_number(arg) )
	return get_room_index( atoi( arg ) );

    if ( ( victim = get_char_world( ch, arg ) ) != NULL )
	return victim->in_room;

    if ( ( obj = get_obj_world( ch, arg ) ) != NULL )
	return obj->in_room;

    return NULL;
}


bool can_transfer( Character *ch, Character *victim )
{
    if ( IS_SET(victim->wiznet,WIZ_NOTRANS) && ch->level < victim->level )
	return FALSE;

    return TRUE;
}

void do_transfer( Character *ch, char *argument )
{
    char arg1[MAX_INPUT_LENGTH];
    char arg2[MAX_INPUT_LENGTH];
    Room *location;
    Descriptor *d;
    Character *victim;

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );

    if ( arg1[0] == '\0' )
    {
	send_to_char( "Transfer whom (and where)?\n\r", ch );
	return;
    }

    if ( !str_cmp( arg1, "all" ) )
    {
	for ( d = descriptor_list; d != NULL; d = d->next )
	{
	    if ( d->connected == CON_PLAYING
	    &&   d->character != ch
	    &&   d->character->in_room != NULL
	    &&   can_see( ch, d->character ) )
	    {
		char buf[MAX_STRING_LENGTH];
		sprintf( buf, "%s %s", d->character->name, arg2 );
		do_function(ch, &do_transfer, buf );
	    }
	}
	return;
    }

    /*
     * Thanks to Grodyn for the optional location parameter.
     */
    if ( arg2[0] == '\0' )
    {
	location = ch->in_room;
    }
    else
    {
	if ( ( location = find_location( ch, arg2 ) ) == NULL )
	{
	    send_to_char( "No such location.\n\r", ch );
	    return;
	}

	if ( !is_room_owner(ch,location) && room_is_private( location ) 
	&&  get_trust(ch) < MAX_LEVEL)
	{
	    send_to_char( "That room is private right now.\n\r", ch );
	    return;
	}
    }

    if ( ( victim = get_char_ooc( ch, arg1 ) ) == NULL )
    {
	send_to_char( "They aren't here.\n\r", ch );
	return;
    }

    if ( victim->in_room == NULL )
    {
	send_to_char( "They are in limbo.\n\r", ch );
	return;
    }

    if ( !can_transfer(ch,victim) )
    {
	act("You can't transfer $M.",ch,NULL,victim,TO_CHAR);
	return;
    }

    if ( victim->fighting != NULL )
	stop_fighting( victim, TRUE );

    act( "$n disappears in a mushroom cloud.", victim, NULL, NULL, TO_ROOM );
    char_from_room( victim );
    char_to_room( victim, location );
    act( "$n arrives from a puff of smoke.", victim, NULL, NULL, TO_ROOM );
    if ( ch != victim )
	act( "$n has transferred you.", ch, NULL, victim, TO_VICT );
    do_function(victim, &do_look, "auto" );
    send_to_char( "Ok.\n\r", ch );
}



void do_at( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Room *location;
    Room *original;
    Object *on;
    Character *wch;
    
    argument = one_argument( argument, arg );

    if ( arg[0] == '\0' || argument[0] == '\0' )
    {
	send_to_char( "At where what?\n\r", ch );
	return;
    }

    if ( ( location = find_location( ch, arg ) ) == NULL )
    {
	send_to_char( "No such location.\n\r", ch );
	return;
    }

    if (!is_room_owner(ch,location) && room_is_private( location ) 
    &&  get_trust(ch) < MAX_LEVEL)
    {
	send_to_char( "That room is private right now.\n\r", ch );
	return;
    }

    original = ch->in_room;
    on = ch->on;
    char_from_room( ch );
    char_to_room( ch, location );
    interpret( ch, argument );

    /*
     * See if 'ch' still exists before continuing!
     * Handles 'at XXXX quit' case.
     */
    for ( wch = char_list; wch != NULL; wch = wch->next )
    {
	if ( wch == ch )
	{
	    char_from_room( ch );
	    char_to_room( ch, original );
	    ch->on = on;
	    break;
	}
    }

    return;
}



void do_goto( Character *ch, char *argument )
{
    Room *location;
    Character *rch;
    int count = 0;

    if ( argument[0] == '\0' )
    {
	send_to_char( "Goto where?\n\r", ch );
	return;
    }

    if ( ( location = find_location( ch, argument ) ) == NULL )
    {
	send_to_char( "No such location.\n\r", ch );
	return;
    }

    count = 0;
    for ( rch = location->people; rch != NULL; rch = rch->next_in_room )
        count++;

    if (!is_room_owner(ch,location) && room_is_private(location) 
    &&  (count > 1 || get_trust(ch) < MAX_LEVEL))
    {
	send_to_char( "That room is private right now.\n\r", ch );
	return;
    }

    if ( ch->fighting != NULL )
	stop_fighting( ch, TRUE );

    for (rch = ch->in_room->people; rch != NULL; rch = rch->next_in_room)
    {
	if (get_trust(rch) >= ch->invis_level)
	{
	    if (ch->pcdata != NULL && ch->pcdata->bamfout[0] != '\0')
		act("$t",ch,ch->pcdata->bamfout,rch,TO_VICT);
	    else
		act("$n leaves in a swirling mist.",ch,NULL,rch,TO_VICT);
	}
    }

    char_from_room( ch );
    char_to_room( ch, location );


    for (rch = ch->in_room->people; rch != NULL; rch = rch->next_in_room)
    {
        if (get_trust(rch) >= ch->invis_level)
        {
            if (ch->pcdata != NULL && ch->pcdata->bamfin[0] != '\0')
                act("$t",ch,ch->pcdata->bamfin,rch,TO_VICT);
            else
                act("$n appears in a swirling mist.",ch,NULL,rch,TO_VICT);
        }
    }

    do_function(ch, &do_look, "auto" );
    return;
}

void do_violate( Character *ch, char *argument )
{
    Room *location;
    Character *rch;
 
    if ( argument[0] == '\0' )
    {
        send_to_char( "Goto where?\n\r", ch );
        return;
    }
 
    if ( ( location = find_location( ch, argument ) ) == NULL )
    {
        send_to_char( "No such location.\n\r", ch );
        return;
    }

    if (!room_is_private( location ))
    {
        send_to_char( "That room isn't private, use goto.\n\r", ch );
        return;
    }
 
    if ( ch->fighting != NULL )
        stop_fighting( ch, TRUE );
 
    for (rch = ch->in_room->people; rch != NULL; rch = rch->next_in_room)
    {
        if (get_trust(rch) >= ch->invis_level)
        {
            if (ch->pcdata != NULL && ch->pcdata->bamfout[0] != '\0')
                act("$t",ch,ch->pcdata->bamfout,rch,TO_VICT);
            else
                act("$n leaves in a swirling mist.",ch,NULL,rch,TO_VICT);
        }
    }
 
    char_from_room( ch );
    char_to_room( ch, location );
 
 
    for (rch = ch->in_room->people; rch != NULL; rch = rch->next_in_room)
    {
        if (get_trust(rch) >= ch->invis_level)
        {
            if (ch->pcdata != NULL && ch->pcdata->bamfin[0] != '\0')
                act("$t",ch,ch->pcdata->bamfin,rch,TO_VICT);
            else
                act("$n appears in a swirling mist.",ch,NULL,rch,TO_VICT);
        }
    }
 
    do_function(ch, &do_look, "auto" );
    return;
}

/* RT to replace the 3 stat commands */

void do_stat ( Character *ch, char *argument )
{
   char arg[MAX_INPUT_LENGTH];
   char *string;
   Object *obj;
   Room *location;
   Character *victim;

   string = one_argument(argument, arg);
   if ( arg[0] == '\0')
   {
	cprintf(ch, "Syntax:\n\r");
	cprintf(ch, "  stat <name>\n\r");
	cprintf(ch, "  stat obj <name>\n\r");
	cprintf(ch, "  stat mob <name>\n\r");
 	cprintf(ch, "  stat room <vnum>\n\r");
	cprintf(ch, "  stat spell <vnum>\n\r");
	cprintf(ch, "  stat quest <vnum>\n\r");
	cprintf(ch, "  stat clan <clan>\n\r");
	return;
   }

	if (!str_cmp(arg,"clan"))
	{
		do_function(ch,&do_cstat, string);
		return;
	}

	if (!str_cmp(arg,"quest"))
	{
		do_function(ch,&do_qstat, string);
		return;
	}

	if (!str_cmp(arg,"spell"))
	{
		do_function(ch,&do_sstat, string);
		return;
	}

   if (!str_cmp(arg,"room"))
   {
	do_function(ch, &do_rstat, string);
	return;
   }
  
   if (!str_cmp(arg,"obj"))
   {
	do_function(ch, &do_ostat, string);
	return;
   }

   if(!str_cmp(arg,"char")  || !str_cmp(arg,"mob"))
   {
	do_function(ch, &do_mstat, string);
	return;
   }
   
   /* do it the old way */

   obj = get_obj_world(ch,argument);
   if (obj != NULL)
   {
     do_function(ch, &do_ostat, argument);
     return;
   }

  victim = get_char_ooc(ch,argument);
  if (victim != NULL)
  {
    do_function(ch, &do_mstat, argument);
    return;
  }

  location = find_location(ch,argument);
  if (location != NULL)
  {
    do_function(ch, &do_rstat, argument);
    return;
  }

  send_to_char("Nothing by that name found anywhere.\n\r",ch);
}

void do_rstat( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    char arg[MAX_INPUT_LENGTH];
    Room *location;
    Object *obj;
    Character *rch;
    int door;

    one_argument( argument, arg );
    location = ( arg[0] == '\0' ) ? ch->in_room : find_location( ch, arg );
    if ( location == NULL )
    {
	send_to_char( "No such location.\n\r", ch );
	return;
    }

    if (!is_room_owner(ch,location) && ch->in_room != location 
    &&  room_is_private( location ) && !IS_TRUSTED(ch,IMPLEMENTOR))
    {
	send_to_char( "That room is private right now.\n\r", ch );
	return;
    }

    sprintf( buf, "Name: '%s'\n\rArea: '%s'\n\r",
	location->name,
	location->area->name );
    send_to_char( buf, ch );

    sprintf( buf,
	"Vnum: %d  Vers: %d  Sector: %s  Light: %d  Healing: %d  Mana: %d\n\r",
	location->vnum,
	location->version,
	flag_string( sector_flags, location->sector_type ),
	location->light,
	location->heal_rate,
	location->mana_rate );
    send_to_char( buf, ch );

    sprintf( buf,
	"Room flags: %s.\n\rDescription:\n\r%s",
	 flag_string( room_flags, location->room_flags ),
	location->description );
    send_to_char( buf, ch );

    if ( location->extra_descr != NULL )
    {
	ExtraDescr *ed;

	send_to_char( "Extra description keywords: '", ch );
	for ( ed = location->extra_descr; ed; ed = ed->next )
	{
	    send_to_char( ed->keyword, ch );
	    if ( ed->next != NULL )
		send_to_char( " ", ch );
	}
	send_to_char( "'.\n\r", ch );
    }

    send_to_char( "Characters:", ch );
    for ( rch = location->people; rch; rch = rch->next_in_room )
    {
	if (can_see(ch,rch))
        {
	    send_to_char( " ", ch );
	    one_argument( rch->name, buf );
	    send_to_char( buf, ch );
	}
    }

    send_to_char( ".\n\rObjects:   ", ch );
    for ( obj = location->contents; obj; obj = obj->next_content )
    {
	send_to_char( " ", ch );
	one_argument( obj->name, buf );
	send_to_char( buf, ch );
    }
    send_to_char( ".\n\r", ch );

    for ( door = 0; door <= 5; door++ )
    {
	Exit *pexit;

	if ( ( pexit = location->exit[door] ) != NULL )
	{
	    sprintf( buf,
		"Door: %d.  To: %d.  Key: %d.  Exit flags: %d.\n\rKeyword: '%s'.  Description: %s",

		door,
		(pexit->u1.to_room == NULL ? -1 : pexit->u1.to_room->vnum),
	    	pexit->key,
	    	pexit->exit_info,
	    	pexit->keyword,
	    	pexit->description[0] != '\0'
		    ? pexit->description : "(none).\n\r" );
	    send_to_char( buf, ch );
	}
    }

	cprintf(ch,"\n\r");
	/* Check tracking informatoin */
	if ( location->tracking == NULL )
	{
		cprintf(ch,"No tracking information in this room.\n\r");
	}
	else
	{
		Track *t;

		cprintf( ch, " == Tracking Summary ==\n\r" );
		for( t = location->tracking ; t != NULL ; t = t->next_in_room )
		{
			cprintf(ch," * %-18s From: %s %lds ago To: %s %lds Wear: %s Hp: %d Wt: %d\n\r",
				IS_NPC( t->who ) ? t->who->short_descr : t->who->name,
				dir_name[t->arrive_dir], t->arrive_time <= 0 ? 0 : (current_time - t->arrive_time),
				t->depart_dir < 0 ? "N/A" : dir_name[t->depart_dir], t->depart_time <= 0 ? 0 : (current_time - t->depart_time),
				get_obj_index( t->footwear_vnum ) == NULL ? "none" : get_obj_index( t->footwear_vnum )->short_descr,
				t->injury_percent, t->weight_percent );
		}
	}

	if ( location->resources != NULL )
	{
		Resource *rsc;

		cprintf(ch," * Natural Resources\n\r");

		for( rsc = location->resources; rsc != NULL ; rsc = rsc->next )
			cprintf(ch,"  %-18s %d\n\r", 
				capitalize(flag_string( resource_flags, rsc->resource )), rsc->amount );
		cprintf(ch,"\n\r");
	}
	else
		cprintf(ch,"No resources in this room.\n\r");

	if ( location->clan != NULL )
		cprintf(ch,"Land belongs to the clan %s.\n\r", location->clan->name );
	else
		cprintf(ch,"No clan claims lordship over this land.\n\r");

	if ( location->buildings == NULL )
		cprintf(ch,"No clan structures in this room.\n\r");
	else
	{
		Building *bld;

		for( bld = location->buildings; bld != NULL ; bld = bld->next )
		{
			cprintf(ch," * %2d %-18s %4d/%4dhp [%s]\n\r",
				bld->level,
				flag_string( building_flags, bld->type ),
				bld->curr_structure, bld->max_structure,
				bld->clan_owner->name );
		}
	}
    
	return;
}



void do_ostat( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    char arg[MAX_INPUT_LENGTH];
    Affect *paf;
    Object *obj;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Stat what?\n\r", ch );
	return;
    }

    if ( ( obj = get_obj_world( ch, argument ) ) == NULL )
    {
	send_to_char( "Nothing like that in hell, earth, or heaven.\n\r", ch );
	return;
    }

    sprintf( buf, "Name(s): %s Count: %d\n\r",
	obj->name, obj->pIndexData->count );
    send_to_char( buf, ch );

    sprintf( buf, "Vnum: %d  Type: %s.%d  Type: %s  Resets: %d\n\r",
	obj->pIndexData->vnum, obj->pIndexData->new_format ? "new" : "old",
	obj->pIndexData->version,
	item_name(obj->item_type), obj->pIndexData->reset_num );
    send_to_char( buf, ch );

    cprintf(ch,"Material: '%s'\n\r", obj->material );

    sprintf( buf, "Short description: %s\n\rLong description: %s\n\r",
	obj->short_descr, obj->description );
    send_to_char( buf, ch );

    cprintf( ch, "Wear bits: %s\n\r", flag_string(wear_flags,obj->wear_flags));
    cprintf( ch, "Extra bits: %s\n\r", flag_string( extra_flags, obj->extra_flags));

    sprintf( buf, "Number: %d/%d  Weight: %d/%d/%d (10th pounds)\n\r",
	1,           get_obj_number( obj ),
	obj->weight, get_obj_weight( obj ),get_true_weight(obj) );
    send_to_char( buf, ch );

    sprintf( buf, "Level: %d  Cost: %ld  Condition: %d  Timer: %d\n\r",
	obj->level, obj->cost, obj->condition, obj->timer );
    send_to_char( buf, ch );

    sprintf( buf,
	"In room: %d  In object: %s  Carried by: %s  Wear_loc: %d\n\r",
	obj->in_room    == NULL    ?        0 : obj->in_room->vnum,
	obj->in_obj     == NULL    ? "(none)" : obj->in_obj->short_descr,
	obj->carried_by == NULL    ? "(none)" : 
	    can_see(ch,obj->carried_by) ? obj->carried_by->name
				 	: "someone",
	obj->wear_loc );
    send_to_char( buf, ch );
    
    sprintf( buf, "Values: %d %d %d %d %d %d %d %d %d %d\n\r",
	obj->value[0], obj->value[1], obj->value[2], obj->value[3],
	obj->value[4], obj->value[5], obj->value[6], obj->value[7],    
	obj->value[8], obj->value[9] );
    send_to_char( buf, ch );
    
    /* now give out vital statistics as per identify */
    
    switch ( obj->item_type )
    {
    	case ITEM_SCROLL: 
    	case ITEM_POTION:
    	case ITEM_PILL:
	    sprintf( buf, "Level %d spells of:", obj->value[0] );
	    send_to_char( buf, ch );

	    if ( obj->value[1] >= 0 && obj->value[1] < MAX_SKILL )
	    {
	    	send_to_char( " '", ch );
	    	send_to_char( skill_table[obj->value[1]].name, ch );
	    	send_to_char( "'", ch );
	    }

	    if ( obj->value[2] >= 0 && obj->value[2] < MAX_SKILL )
	    {
	    	send_to_char( " '", ch );
	    	send_to_char( skill_table[obj->value[2]].name, ch );
	    	send_to_char( "'", ch );
	    }

	    if ( obj->value[3] >= 0 && obj->value[3] < MAX_SKILL )
	    {
	    	send_to_char( " '", ch );
	    	send_to_char( skill_table[obj->value[3]].name, ch );
	    	send_to_char( "'", ch );
	    }

	    if (obj->value[4] >= 0 && obj->value[4] < MAX_SKILL)
	    {
		send_to_char(" '",ch);
		send_to_char(skill_table[obj->value[4]].name,ch);
		send_to_char("'",ch);
	    }

	    send_to_char( ".\n\r", ch );
	break;

    	case ITEM_WAND: 
    	case ITEM_STAFF: 
	    sprintf( buf, "Has %d(%d) charges of level %d",
	    	obj->value[1], obj->value[2], obj->value[0] );
	    send_to_char( buf, ch );
      
	    if ( obj->value[3] >= 0 && obj->value[3] < MAX_SKILL )
	    {
	    	send_to_char( " '", ch );
	    	send_to_char( skill_table[obj->value[3]].name, ch );
	    	send_to_char( "'", ch );
	    }

	    send_to_char( ".\n\r", ch );
	break;

	case ITEM_DRINK_CON:
	    sprintf(buf,"It holds %s-colored %s.\n\r",
		liq_table[obj->value[2]].liq_color,
		liq_table[obj->value[2]].liq_name);
	    send_to_char(buf,ch);
	    break;
		
      
    	case ITEM_WEAPON:
 	    cprintf(ch,"Weapon type is %s\n\r",weapon_name(obj->value[0]));
	    if (obj->pIndexData->new_format)
	    {
		int average, delay;

		average = (1+obj->value[2]) * obj->value[1] / 2;
		delay   = obj->value[5] == 0 ? 1 : obj->value[5];

	    	sprintf(buf,"Damage is %dd%d (average %d, %d.%d/second)\n\r",
		    obj->value[1],obj->value[2],
		    average, average*10/delay, average*10/delay );
	    }
	    else
	    	sprintf( buf, "Damage is %d to %d (average %d).  Speed is %d.\n\r",
	    	    obj->value[1], obj->value[2],
	    	    ( obj->value[1] + obj->value[2] ) / 2,
		    obj->value[5]  );
	    send_to_char( buf, ch );

	    sprintf(buf,"Damage noun is %s.\n\r",
		(obj->value[3] > 0 && obj->value[3] < MAX_DAMAGE_MESSAGE) ?
		    attack_table[obj->value[3]].noun : "undefined");
	    send_to_char(buf,ch);
	    
	    if (obj->value[4])  /* weapon flags */
	        cprintf(ch,"Weapons flags: %s\n\r", flag_string(weapon_flags,obj->value[4]));
	
        break;

    	case ITEM_ARMOR:
	    sprintf( buf, 
	    "Armor class is %d pierce, %d bash, %d slash, and %d vs. magic\n\r",
	        obj->value[0], obj->value[1], obj->value[2], obj->value[3] );
	    send_to_char( buf, ch );
	break;

        case ITEM_CONTAINER:
            sprintf(buf,"Capacity: %d#  Maximum weight: %d#  flags: %s\n\r",
                obj->value[0], obj->value[3], flag_string(container_flags,obj->value[1]));
            send_to_char(buf,ch);
            if (obj->value[4] != 100)
            {
                sprintf(buf,"Weight multiplier: %d%%\n\r",
		    obj->value[4]);
                send_to_char(buf,ch);
            }
        break;
    }


    if ( obj->extra_descr != NULL || obj->pIndexData->extra_descr != NULL )
    {
	ExtraDescr *ed;

	send_to_char( "Extra description keywords: '", ch );

	for ( ed = obj->extra_descr; ed != NULL; ed = ed->next )
	{
	    send_to_char( ed->keyword, ch );
	    if ( ed->next != NULL )
	    	send_to_char( " ", ch );
	}

	for ( ed = obj->pIndexData->extra_descr; ed != NULL; ed = ed->next )
	{
	    send_to_char( ed->keyword, ch );
	    if ( ed->next != NULL )
		send_to_char( " ", ch );
	}

	send_to_char( "'\n\r", ch );
    }


    if (!obj->enchanted)
    for ( paf = obj->pIndexData->affected; paf != NULL; paf = paf->next )
    {
        if ( paf->location != APPLY_NONE && paf->modifier != 0 )
        {
            formatAffectDescription( ch, paf );
            cprintf(ch,"\n\r");
        }
    }

    for ( paf = obj->affected; paf != NULL; paf = paf->next )
    {
        if ( paf->location != APPLY_NONE && paf->modifier != 0 )
        {
            formatAffectDescription( ch, paf );
            cprintf(ch,"\n\r");
        }
    }


    return;
}

void do_qstat( Character *ch, char *argument )
{
	int quest_vnum, i;
	Quest *q;
	ObjIndex *pObj;
	Character *wch;
	char buf1[MAX_STRING_LENGTH];
	char buf2[MAX_STRING_LENGTH];
	int counter = 0;
	int ingredient_count[MAX_INGREDIENT][2];

	if( !is_number(argument) )
	{
		cprintf(ch,"Usage:  stat quest <#>\n\r");
		return;
	}

	if( (quest_vnum = atoi(argument)) < 0)
	{
		cprintf(ch,"Quest vnum must be larger than 0.\n\r");
		return;
	}

	if( ( q = get_quest_index(quest_vnum) ) != NULL )
	{
		cprintf( ch, "Name: %s [%d]\n\r", q->name == NULL ? "(None)" : q->name, q->vnum);

		cprintf( ch, "Keyword: %s\n\r", q->keyword == NULL ? "(None)" : q->keyword);
		cprintf( ch, "Short Description: %s\n\r", q->short_descr == NULL ? "(None)" : q->short_descr);
		cprintf( ch, "Long Description: %s\n\r", q->long_descr == NULL ? "(None)" : q->long_descr);
		cprintf( ch, "Hint: %s\n\r", q->hint == NULL ? "(None)" : q->hint);
		cprintf( ch, "Goodbye: %s\n\r", q->goodbye == NULL ? "(None)" : q->goodbye);
		cprintf( ch, "Flags: %s\n\r", flag_string(quest_flags,q->flags));

		cprintf( ch, "\n\rRequirements:\n\r" );
		cprintf( ch, "Levels %d - %d\n\r", q->min_level, q->max_level);

		buf1[0] = '\0';
		strcat( buf1, "Race:");
		for(i=0; i < MAX_PC_RACE; i++)
		{
			if(q->race_avail)
			{
				strcat( buf1, "  All");
				break;
			}

			if(q->race_avail[i])
			{
				sprintf(buf2, "  %s", race_table[i].name);
				strcat( buf1, buf2 );
			}
		}
 
		strcat( buf1, "\n\rClass:");
		for(i=0; i < MAX_CLASS; i++)
		{
			if(q->class_avail)
			{
				strcat( buf1, " All");
				break;
			}

			if(q->class_avail[i])
			{
				sprintf(buf2, " %s", class_table[i].name);
				strcat( buf1, buf2 );
			}
		}
 
		strcat( buf1, "\n\rDeity:");
		for(i=0; i < MAX_DEITY; i++)
		{
			if(q->deity_avail)
			{
				strcat( buf1, " All");
				break;
			}

			if(q->deity_avail[i])
			{
				sprintf(buf2, " %s", deity_table[i].name);
				strcat( buf1, buf2 );
			}
		}
		cprintf(ch, buf1);

		counter = 0;
		cprintf( ch, "\n\r\n\rFaction Requirement:\n\r");
		for( i=0; i<8; i++)
		{
			if(q->faction_avail[i].faction != NULL)
			{
				counter++;
				cprintf( ch, "[%d] %s\n\r", q->faction_avail[i].amount, q->faction_avail[i].faction == NULL ? "(None)" : q->faction_avail[i].faction);
			}
		}
		if(counter == 0)
			cprintf( ch, "None\n\r");

		/* Init the array */
		for(i=0; i< MAX_INGREDIENT; i++)
		{
			ingredient_count[i][0] = 0;
			ingredient_count[i][1] = 0;
		}

		for(i=0; i < MAX_INGREDIENT; i++)
		{
			int x = 0;
			bool found = FALSE;

			if(q->required[i] > 0)
			{
				for(x = 0; x < MAX_INGREDIENT; x++)
				{
					if(ingredient_count[x][0] == q->required[i])
					{
						ingredient_count[x][1]++;
						found = TRUE;
						break;
					}
				}
	
				if(!found)
				{
					ingredient_count[i][0] = q->required[i];
					ingredient_count[i][1] = 1;
				}
			}
		}
	
		counter = 0;
		cprintf( ch, "\n\rIngredients required to complete:\n\r");
		for( i=0; i < MAX_INGREDIENT; i++)
		{
			if(ingredient_count[i][0] > 0)
			{
				counter++;
				if( (pObj = get_obj_index(ingredient_count[i][0])) == NULL )
				{
					cprintf(ch, "%d. Could not find required item vnum %d.\n\r", counter, ingredient_count[i][0]);
				}
				else
				{
					if(ingredient_count[i][1] == 1)
						cprintf( ch, "%d. %s [%d]\n\r", counter, pObj->short_descr  == NULL ? "(Unknown)" : pObj->short_descr, pObj->vnum);
					else
						cprintf( ch, "%d. (%d)%s [%d]\n\r", counter, ingredient_count[i][1], pObj->short_descr  == NULL ? "(Unknown)" : pObj->short_descr, pObj->vnum);
				}
			}
		}
		if(counter == 0)
			cprintf( ch, "None\n\r" );

		cprintf(ch, "\n\rQuest Rewards:\n\r");
		if(q->reward_vnum > 0)
		{
			if( (pObj = get_obj_index(q->reward_vnum)) == NULL )
			{
				cprintf(ch, "Item: Could not find reward vnum %d.\n\r", q->reward_vnum);
			}
			else
			{
				cprintf( ch, "Item: %s [%d]\n\r", pObj->short_descr  == NULL ? "(Unknown)" : pObj->short_descr, pObj->vnum);
			}
		}
		else
		{
			cprintf(ch, "Item: None\n\r");
		}

		cprintf(ch, "Coins: Silver[%d] Gold[%d] Electrum[%d] Platinum[%d] Mithril[%d]\n\r",
			q->reward_coins[CUR_SILVER], q->reward_coins[CUR_GOLD], q->reward_coins[CUR_ELECTRUM], q->reward_coins[CUR_PLATINUM], q->reward_coins[CUR_ALATINUM]);

		cprintf(ch, "Experience: %d\n\r", q->reward_experience);

		counter = 0;
		cprintf( ch, "\n\rFaction hits:\n\r");
		for( i=0; i<8; i++)
		{
			if(q->faction_hits[i].faction != NULL)
			{
				counter++;
				cprintf( ch, "[%d] %s\n\r", q->faction_hits[i].amount, q->faction_hits[i].faction == NULL ? "(None)" : q->faction_hits[i].faction);
			}
		}
		if(counter == 0)
			cprintf( ch, "None\n\r");

		counter = 0;
		cprintf( ch, "\n\rFound on mobs:\n\r");
		for ( wch = char_list; wch != NULL ; wch = wch->next )
		{
			Quest *match_quest;

			if(!IS_NPC(wch))
				continue;

			for( match_quest = wch->quests; match_quest != NULL; match_quest = match_quest->next )
			{
				if(match_quest->vnum == q->vnum)
				{
					counter++;
					if(wch->in_room->name != NULL)
						cprintf(ch, "%s [%d] is in %s [%d]\n\r", wch->pIndexData->short_descr == NULL ? "(Unknown" : wch->pIndexData->short_descr,wch->pIndexData->vnum,wch->in_room->name,wch->in_room->vnum);
					else
						cprintf(ch, "%s [%d] is somewhere\n\r", wch->pIndexData->short_descr == NULL ? "(Unknown" : wch->pIndexData->short_descr);
				}
			} 	
		}
		if(counter == 0)
			cprintf( ch, "None\n\r");
	}
	else
	{
		cprintf(ch, "No such quest.\n\r");
	} 
}

void do_cstat( Character *ch, char *argument )
{
	char arg[MAX_INPUT_LENGTH];
	Clan *clan;
	int i;

	argument = one_argument( argument, arg );

	if(arg[0] == '\0')
	{
		cprintf(ch,"Syntax: stat clan <clan> [who]\n\r");
		return;
	}

	if(( clan = clan_lookup(arg)) == 0)
	{
		cprintf(ch, "There is no clan by that name.\n\r");
		return;
	}

	argument = one_argument( argument, arg );
	if(!strcmp(arg,"who"))
	{
		FILE *fp;
		Buffer *buffer;
		char filename[MAX_STRING_LENGTH];
		char buf[128];
		int p, col = 0;

		fclose(fpReserve);
		
		snprintf(filename,sizeof(filename),"%s/roster/%s.roster",
			DATA_DIR, clan->name );

		for( p=0;filename[p] != '\0';p++)
			if(filename[p] == ' ')
				filename[p] = '_';

		if ( (fp = fopen(filename,"r")) == NULL )
		{
			cprintf(ch,"Couldn't open the roster file %s: %s\n\r",
				filename, strerror(errno) );
			return;
		}

		buffer = new_buf();

		bprintf(buffer," == Guild Roster for Clan %s ==\n\r", clan->name);
		while( fgets(buf,sizeof(buf),fp) != NULL )
		{
			stripCRLF(buf);
			bprintf(buffer, "R%-15s", buf);

			if (++col % 5 == 0)
				bprintf(buffer, "\n\r"); 
		}

		if(col % 5 != 0)
			bprintf(buffer, "\n\r");

		page_to_char(buf_string(buffer),ch);
		free_buf(buffer);

		fclose(fp);
		fpReserve = fopen(NULL_FILE,"r");
		
		return;
	}
	else
	{
		bool found = FALSE;
		Building *bld;
		Room *r;
		int count = 0;

		if(clan_is_independent(clan))
		{
			cprintf(ch, "There are only rosters for independent clans.\n\r");
			return;
		}

		cprintf(ch," == Guild Record for Clan %s ==\n\r", clan->name);
		cprintf(ch,"Founder: %s  Creation Date: %s  Members: %d  Guild Points: %d\n\r",
		clan->founder,	format_date( clan->founded, "%d/%b/%Y" ),
		clan->total_players, clan->guild_points );
		cprintf(ch, "Banked: Silver[%d] Gold[%d] Electrum[%d] Platinum[%d] Mithril[%d]\n\r",
			clan->banked[CUR_SILVER], clan->banked[CUR_GOLD], clan->banked[CUR_ELECTRUM],
			clan->banked[CUR_PLATINUM], clan->banked[CUR_ALATINUM]);

		cprintf(ch,"\n\r -- Clan Ranks --\n\r");
		for( i = 0; i < MAX_GUILD_RANK; i++)
			cprintf(ch,"Rank %d : %s : %s\n\r",i+1,clan->ranks[i].name,
				flag_string(rank_flags, clan->ranks[i].flags));

		cprintf(ch,"\n\r -- Clan Buildings --\n\r");
		for(i=0; i<100000; i++ )
		{
			if( (r=get_room_index(i)) == NULL || r->buildings == NULL)
				continue;

			for( bld = r->buildings; bld != NULL; bld = bld->next )
			{
				if(bld->clan_owner == clan)
				{
					count++;

					if(!found)
					{
						cprintf(ch, "   Build/Upgrade Level  Curr/Max   Structure Type     Resources [Vnum ] Room\n\r");
					}

					found = TRUE;

					cprintf(ch, "%2d.  %-11s %5d %5d/%5d %-5s %-12s (%7d) [%5d] %s\n\r",
						count, 
						IS_SET(bld->flags, BUILDING_UNDER_CONSTRUCTION) ? "Building" : 
						IS_SET(bld->flags,BUILDING_UPGRADE) ? "Upgrading" : "Completed", 
						bld->level, bld->curr_structure, bld->max_structure, 
						bld->material == BUILDMAT_WOOD ? "wood" : "stone", 
						flag_string(building_flags, bld->type), bld->available_resources, 
						r->vnum, r->name );
				}
			}
		}

		if(!found)
		{
			cprintf(ch, "None\n\r");
		}
	}
}

void do_sstat( Character *ch, char *argument )
{
	int sn;
	int i;
	SpellIndex* pSpellIndex;

	if( !is_number(argument) )
	{
		cprintf(ch,"Usage:  stat spell <#>\n\r");
		return;
	}

	sn = atoi(argument);
	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		cprintf(ch,"Spell Table Entry #%d\n\r",sn);
		cprintf(ch,"Name: %s   FullName: %s   Series#: %d Power#: %d\n\r",
			pSpellIndex->name, pSpellIndex->full_name,
			pSpellIndex->series, pSpellIndex->series_rank );
	
		for( i = 0 ; i < MAX_CLASS ; i++ )
		{	
			if ( i % 4 == 0 )
				cprintf(ch,"\n\r");
			cprintf(ch," %-15s %d  ", class_table[i].name, pSpellIndex->class_level[i] );
		}
		
		cprintf(ch,"\n\rSkill: %s  CastTime: %d.%d  RecastTime: %d.%d\n\r",
			pSpellIndex->sgsn == NULL ? "<unknown>" :
			skill_table[*(pSpellIndex->sgsn)].name,
			pSpellIndex->beats / PULSE_PER_SECOND,
			pSpellIndex->beats % PULSE_PER_SECOND,
			pSpellIndex->recast / PULSE_PER_SECOND,
			pSpellIndex->recast % PULSE_PER_SECOND );
	
		cprintf(ch,"Type: %s% %s\n\r",
			IS_SET(pSpellIndex->flags,COM_DIVINE) ? "Divine" : "",
			IS_SET(pSpellIndex->flags,COM_ARCANE) ? "Arcane" : "" );

        cprintf(ch,"&WSpell Affects&x:\n\r");
        for( i=0; i < 5; i++ )
        {
            switch( pSpellIndex->spell_type )
            {
            case SPELL_DEBUFF: case SPELL_BUFF:
                formatAffectDescription( ch, &(pSpellIndex->action.generic.affects[i]) ); break;
            default:
                continue;
            }
            //if ( pSpellIndex->affects[i].description != NULL )
                //cprintf(ch," * %s\n\r", pSpellIndex->affects[i].description);
        }
	}
    else
        cprintf(ch,"No such spell.\n\r");

	return;
}

/*
 * Params:
 * -f show factions
 * -p show pathing
 * -d show dispositions
 * -a show affects
 * -q show quests
 * -r show resists
 */
void do_mstat( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    char arg[MAX_INPUT_LENGTH];
    /*Affect *paf;*/
    Character *victim;
	int i;
	bool found = FALSE;
	bool fPathing = FALSE;
	bool fFactions = FALSE;
	bool fAffects = FALSE;
	bool fDispos = FALSE;
	bool fQuest = FALSE;
	bool fResist = FALSE;
    extern void show_resist( Character *ch, Character *showTo );

    argument = one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
		cprintf(ch,"Syntax: stat mob <npc or playername> [-f -p -d -a -q -r]\n\r");
		cprintf(ch,"        -f :: show factions\n\r");
		cprintf(ch,"        -p :: show pathing and pursuit\n\r");
		cprintf(ch,"        -d :: show dispositions\n\r");
		cprintf(ch,"        -a :: show affects\n\r");
		cprintf(ch,"        -q :: show quests\n\r");
		cprintf(ch,"        -r :: show resists\n\r");
		return;
    }

    if ( ( victim = get_char_ooc( ch, arg ) ) == NULL )
    {
	send_to_char( "They aren't here.\n\r", ch );
	return;
    }

	/* Find params */
	while( argument[0] != '\0' )
	{
		argument = one_argument( argument, arg );
	
		if ( arg[0] != '-' )
		{
			cprintf(ch,"Invalid argument: %s\n\r", arg );
			continue;
		}

		switch ( arg[1] )
		{
			case 'f': case 'F': fFactions = TRUE; break;
			case 'a': case 'A': fAffects = TRUE; break;
			case 'p': case 'P': fPathing = TRUE; break;
			case 'd': case 'D': fDispos = TRUE; break;
			case 'q': case 'Q': fQuest = TRUE; break;
			case 'r': case 'R': fResist = TRUE; break;
			default:
				cprintf(ch,"Invalid argument: %s\n\r", arg );
				break;
		}
	}

    sprintf( buf, "Name: %s\n\r",
	victim->name);
    send_to_char( buf, ch );

    sprintf( buf, 
	"Vnum: %d  Type: %s.%d  Race: %s  Subrace: %s  Group: %d  Sex: %s  Room: %d\n\r",
	IS_NPC(victim) ? victim->pIndexData->vnum : 0,
	IS_NPC(victim) ? victim->pIndexData->new_format ? "new" : "old" : "pc",
	IS_NPC(victim) ? victim->pIndexData->version : victim->version,
	race_table[victim->race].name,
	IS_NPC(victim) ? "none" : (victim->pcdata->subrace < 0 ? subrace_table[victim->pcdata->subrace].name : "none"),
	IS_NPC(victim) ? victim->group : 0, sex_table[victim->sex].name,
	victim->in_room == NULL    ?        0 : victim->in_room->vnum
	);
    send_to_char( buf, ch );

    if (IS_NPC(victim))
    {
	sprintf(buf,"Count: %d  Killed: %d\n\r",
	    victim->pIndexData->count,victim->pIndexData->killed);
	send_to_char(buf,ch);
    }

    sprintf( buf, 
   	"Str: %d(%d)  Int: %d(%d)  Wis: %d(%d)  Dex: %d(%d)  Con: %d(%d)\n\r",
	victim->perm_stat[STAT_STR],
	get_curr_stat(victim,STAT_STR),
	victim->perm_stat[STAT_INT],
	get_curr_stat(victim,STAT_INT),
	victim->perm_stat[STAT_WIS],
	get_curr_stat(victim,STAT_WIS),
	victim->perm_stat[STAT_DEX],
	get_curr_stat(victim,STAT_DEX),
	victim->perm_stat[STAT_CON],
	get_curr_stat(victim,STAT_CON) );
    send_to_char( buf, ch );

    cprintf( ch, "(Base)Stat HP: (%d/%d)%d/%d  Mana: %d/%d  Move: %d/%d  Stamina: %d/%d\n\r",
	victim->base_hit,		victim->max_base_hit,
	victim->stat_hit,		max_stat_hit(victim),
	victim->mana,        max_mana(victim),
	victim->move,        victim->max_move,
	victim->stamina,	max_stamina(victim) );

	cprintf(ch, "Trains: %d  Skill Points: %d  Spec Points: %d\n\r",
		victim->train, victim->practice, IS_NPC(victim) ? 0 : victim->pcdata->spec_points );
	
	cprintf(ch,"Lv: %d  Class: %s  Exp: %ld\n\r", 
	victim->level, class_table[victim->class].name, victim->exp);

	for( i=0 ; i< MAX_CURRENCY; i++)
		cprintf(ch,"%s: %ld  ", capitalize(currency_table[i].name), victim->coins[i] );
	cprintf(ch,"\n\r");

    if (!IS_NPC(victim) && victim->level >= 20 )
		cprintf(ch,"Spec Lvl: %d   Spec Exp: %d/%d  Split:  %dxp/%daa\n\r",
			victim->pcdata->spec_level, victim->pcdata->spec_exp, exp_to_level[victim->pcdata->spec_level].tnl,
			100 - victim->pcdata->split, victim->pcdata->split  );

    sprintf(buf,"Armor: pierce: %d  bash: %d  slash: %d  magic: %d\n\r",
	    GET_AC(victim,AC_PIERCE), GET_AC(victim,AC_BASH),
	    GET_AC(victim,AC_SLASH),  GET_AC(victim,AC_EXOTIC));
    send_to_char(buf,ch);

    sprintf( buf, 
	"Hit: %d(%d)  Dam: %d  Saves: %d  Size: %s  Position: %s  Wimpy: %d\n\r",
		GET_HITROLL(victim), _attack_power(victim), GET_DAMROLL(victim), victim->saving_throw,
		size_table[victim->size].name, position_table[victim->position].name,
		victim->wimpy );
    	send_to_char( buf, ch );

    if (IS_NPC(victim) && victim->pIndexData->new_format)
    {
	sprintf(buf, "Damage: %dd%d  Message:  %s\n\r",
	    victim->damage[DICE_NUMBER],victim->damage[DICE_TYPE],
	    attack_table[victim->dam_type].noun);
	send_to_char(buf,ch);
    }
    sprintf( buf, "Fighting: %s\n\r",
	victim->fighting ? victim->fighting->name : "(none)" );
    send_to_char( buf, ch );

    if ( !IS_NPC(victim) )
    {
	sprintf( buf,
	    "Thirst: %d  Hunger: %d  Full: %d  Drunk: %d\n\r",
	    victim->pcdata->condition[COND_THIRST],
	    victim->pcdata->condition[COND_HUNGER],
	    victim->pcdata->condition[COND_FULL],
	    victim->pcdata->condition[COND_DRUNK] );
	send_to_char( buf, ch );
    }

    sprintf( buf, "Carry number: %d  Carry weight: %d\n\r",
	victim->carry_number, get_carry_weight(victim) / 10 );
    send_to_char( buf, ch );


    if (!IS_NPC(victim))
    {
    	sprintf( buf, 
	    "Age: %d  Played: %d  Last Level: %d  Timer: %d\n\r",
	    get_age(victim), 
	    (int) (victim->played + current_time - victim->logon) / 3600, 
	    victim->pcdata->last_level, 
	    victim->timer );
    	send_to_char( buf, ch );
    }

    sprintf(buf, "Act: %s\n\r",flag_string(act_flags,victim->act));
    send_to_char(buf,ch);
    
    if (victim->comm)
    	cprintf(ch,"Comm: %s\n\r",flag_string(comm_flags,victim->comm));

    if (IS_NPC(victim) && victim->off_flags)
    	cprintf(ch, "Offense: %s\n\r",flag_string(off_flags,victim->off_flags));

    if (victim->imm_flags)
	    cprintf(ch, "Immune: %s\n\r",flag_string(imm_flags,victim->imm_flags));
 
    cprintf(ch, "Form: %s\n\r",  flag_string(form_flags,victim->form));
    cprintf(ch, "Parts: %s\n\r", flag_string(part_flags,victim->parts));

    if (victim->affected_by)
	    cprintf(ch, "Affected by %s\n\r", affect_bit_name(victim->affected_by));

    cprintf( ch, "Master: %s  Leader: %s  Pet: %s\n\r",
	    victim->master      ? victim->master->name   : "(none)",
	    victim->leader      ? victim->leader->name   : "(none)",
	    victim->pet 	    ? victim->pet->name	     : "(none)");

    if ( !IS_NPC(victim) )
        cprintf( ch, "Security: %d.\n\r", victim->pcdata->security );	/* OLC */

    sprintf( buf, "Short description: %s\n\rLong  description: %s",
	victim->short_descr,
	victim->long_descr[0] != '\0' ? victim->long_descr : "(none)\n\r" );
    send_to_char( buf, ch );

    if ( IS_NPC(victim) && victim->spec_fun != 0 )
    {
	sprintf(buf,"Mobile has special procedure %s.\n\r",
		spec_name(victim->spec_fun));
	send_to_char(buf,ch);
    }

    if ( !IS_NPC(victim) )
	cprintf(ch,"Experience/Exp To Next Level: %d/%d\n\r",
		victim->exp, exp_to_level[victim->level].tnl );

	/* Show factions */
	if ( fFactions )
	{
		Faction *f;

		cprintf(ch," === Faction ===\n\r");
		found = FALSE;
		for( f = victim->factions ; f != NULL ; f = f->next )
		{
			found = TRUE;
			if ( IS_NPC(victim) )
				cprintf(ch," * %-26s %s\n\r",
					f->name, 
					f->standing == FACTION_MEMBER_OF ? "ally" : "enemy" );
			else
				cprintf(ch," * %-26s %s %ld\n\r",
					f->name, 
					factionDescription( f->counter ), 
					f->counter ); 
		}

		if( !found )
			cprintf(ch,"   None found.\n\r");
	}

	if ( !IS_NPC(victim) && victim->pcdata->journal != NULL )
	{
		Journal *j = victim->pcdata->journal;

		cprintf(ch,"Journal:\n\r  Recipes: [%s]\n\r  Quests: [%s]\n\r",
			j->recipeList ? j->recipeList : "none",
			j->questList ? j->questList : "none" );
	}
	
	if ( fResist )
		show_resist( victim, ch );
		
	if ( IS_NPC(victim) && fQuest )
	{
		Quest *q;

		cprintf(ch," == Quests on this NPC ==\n\r");
		found = FALSE;
		for( q = victim->quests ; q != NULL ; q = q->next )
		{
			found = TRUE;
			cprintf(ch," %5d :: %s\n\r", q->vnum, q->name );
		}
		if( !found )
			cprintf(ch,"   None found.\n\r");
	}

	/* Dispositions */
	if ( IS_NPC(victim) && fDispos )
	{
		Melee *m;

		cprintf(ch," == Melee Dispositions ==\n\r");
		found = FALSE;
		for( m = victim->melee_list ; m != NULL ; m = m->next )
		{
			found = TRUE;
			cprintf(ch," %s: %s for %d seconds\n\r",
				m->group->members[0]->name,
				dispositionName( m->disposition ),
				m->timer * PULSE_MELEE_UPDATE );
		}
		if( !found )
			cprintf(ch,"   None found.\n\r");
	}

	if ( !IS_NPC(victim) )
	{
		cprintf(ch," Current Guild Point Value:  %d\n\r", guild_point_value(victim) );
		cprintf(ch," Player Group: %s [Memory: %p]\n\r", victim->pgroup->members[0]->name, victim->pgroup );
	}


	if( fAffects )
		affects_to_char( victim->affected, ch );

	if( fPathing && IS_NPC(victim) )
	{
		int i;
		bool fAny = FALSE;
	
		cprintf(ch," == Pathing Histry ==\n\r");
		for( i=0 ; i < victim->pathing.index ; i++ )
		{
			Room *r;

			fAny = TRUE;
			r = get_room_index( victim->pathing.array[i] );
			cprintf(ch," %5d %s\n\r", victim->pathing.array[i], r == NULL ? "<bad vnum>" : r->name );
		}

        if( !fAny )
            cprintf(ch,"  (nothing)\n\r");

        fAny = FALSE;
        cprintf(ch,"\n\r == Pursuit Histry ==\n\r");
        for( i=0 ; i < victim->pursuit.index ; i++ )
        {
            Room *r;

            fAny = TRUE;
            r = get_room_index( victim->pursuit.array[i] );
            cprintf(ch," %5d %s\n\r", victim->pursuit.array[i], r == NULL ? "<bad vnum>" : r->name );
        }

		if ( !fAny )
			cprintf(ch,"  (nothing)\n\r");
	}

    return;
}

/* ofind and mfind replaced with vnum, vnum skill also added */

void do_vnum(Character *ch, char *argument)
{
    char arg[MAX_INPUT_LENGTH];
    char *string;

    string = one_argument(argument,arg);
 
    if (arg[0] == '\0')
    {
	send_to_char("Syntax:\n\r",ch);
	send_to_char("  vnum obj <name>\n\r",ch);
	send_to_char("  vnum mob <name>\n\r",ch);
	send_to_char("  vnum skill <skill or spell>\n\r",ch);
	cprintf(ch,  "  vnum recipe <name or 'all'>\n\r");
	cprintf(ch,  "  vnum quest <name of 'all'>\n\r");
	return;
    }

	if ( !str_cmp(arg,"quest"))
	{
	do_function(ch,&do_qfind, string);
	return;
	}

	if ( !str_cmp(arg,"recipe"))
	{
	do_function(ch,&do_rfind, string);
	return;
	}

    if (!str_cmp(arg,"obj"))
    {
	do_function(ch, &do_ofind, string);
 	return;
    }

    if (!str_cmp(arg,"mob") || !str_cmp(arg,"char"))
    { 
	do_function(ch, &do_mfind, string);
	return;
    }

    if (!str_cmp(arg,"skill") )
    {
	do_function (ch, &do_slookup, string);
	return;
    }

    if (!str_cmp(arg,"spell") )
    {
	do_function(ch, &do_spell_lookup, string);
	return;
    }
    /* do both */
    do_function(ch, &do_mfind, argument);
    do_function(ch, &do_ofind, argument);
}

void do_qfind( Character *ch, char *argument )
{
    extern int top_quest_index;
    char arg[MAX_INPUT_LENGTH];
	Quest *q;
    int vnum;
    int nMatch;
    bool fAll;
    bool found;

    one_argument( argument, arg );
    if ( arg[0] == '\0' )
    {
	send_to_char( "Find which?\n\r", ch );
	return;
    }

	fAll = FALSE;
	if ( !str_cmp(arg,"all"))
		fAll = TRUE;
    found	= FALSE;
    nMatch	= 0;

    for ( vnum = 0; nMatch < top_quest_index; vnum++ )
    {
		if ( ( q = get_quest_index( vnum ) ) != NULL )
		{
	    	nMatch++;
	    	if ( fAll || is_name( argument, q->name ) )
	    	{
				found = TRUE;
				cprintf( ch, "[%5d] %s\n\r", q->vnum, q->name );
	    	}
		}
    }

    if ( !found )
		send_to_char( "No such quest.\n\r", ch );

    return;
}

void do_rfind( Character *ch, char *argument )
{
    extern int top_recipe_index;
    char arg[MAX_INPUT_LENGTH];
	Recipe *rec;
    int vnum;
    int nMatch;
    bool fAll;
    bool found;
	Buffer	*buffer;

    one_argument( argument, arg );
    if ( arg[0] == '\0' )
    {
	send_to_char( "Find which?\n\r", ch );
	return;
    }

	fAll = FALSE;
	if ( !str_cmp(arg,"all"))
		fAll = TRUE;
    found	= FALSE;
    nMatch	= 0;

	buffer = new_buf( );

    for ( vnum = 0; nMatch < top_recipe_index; vnum++ )
    {
		if ( ( rec = get_recipe_index( vnum ) ) != NULL )
		{
	    	nMatch++;
	    	if ( fAll || is_name( argument, rec->name ) )
	    	{
				found = TRUE;
				bprintf(buffer, "[%5d] [%2d] %s\n\r",
		    		rec->vnum, rec->difficulty, rec->name );
	    	}
		}
    }

    if ( !found )
		send_to_char( "No such recipes.\n\r", ch );
	else
		page_to_char( buf_string(buffer), ch );
	
	free_buf( buffer );
    return;
}

void do_mfind( Character *ch, char *argument )
{
    extern int top_mob_index;
    char buf[MAX_STRING_LENGTH];
    char arg[MAX_INPUT_LENGTH];
    MobIndex *pMobIndex;
    int vnum;
    int nMatch;
    bool fAll;
    bool found;

    one_argument( argument, arg );
    if ( arg[0] == '\0' )
    {
	send_to_char( "Find whom?\n\r", ch );
	return;
    }

    fAll	= FALSE; /* !str_cmp( arg, "all" ); */
    found	= FALSE;
    nMatch	= 0;

    /*
     * Yeah, so iterating over all vnum's takes 10,000 loops.
     * Get_mob_index is fast, and I don't feel like threading another link.
     * Do you?
     * -- Furey
     */
    for ( vnum = 0; nMatch < top_mob_index; vnum++ )
    {
	if ( ( pMobIndex = get_mob_index( vnum ) ) != NULL )
	{
	    nMatch++;
	    if ( fAll || is_name( argument, pMobIndex->player_name ) )
	    {
		found = TRUE;
		sprintf( buf, "[%5d] [%2d] %s\n\r",
		    pMobIndex->vnum, pMobIndex->level, pMobIndex->short_descr );
		send_to_char( buf, ch );
	    }
	}
    }

    if ( !found )
	send_to_char( "No mobiles by that name.\n\r", ch );

    return;
}



void do_ofind( Character *ch, char *argument )
{
    extern int top_obj_index;
    char buf[MAX_STRING_LENGTH];
    char arg[MAX_INPUT_LENGTH];
    ObjIndex *pObjIndex;
    int vnum;
    int nMatch;
    bool fAll;
    bool found;

    one_argument( argument, arg );
    if ( arg[0] == '\0' )
    {
	send_to_char( "Find what?\n\r", ch );
	return;
    }

    fAll	= FALSE; /* !str_cmp( arg, "all" ); */
    found	= FALSE;
    nMatch	= 0;

    /*
     * Yeah, so iterating over all vnum's takes 10,000 loops.
     * Get_obj_index is fast, and I don't feel like threading another link.
     * Do you?
     * -- Furey
     */
    for ( vnum = 0; nMatch < top_obj_index; vnum++ )
    {
	if ( ( pObjIndex = get_obj_index( vnum ) ) != NULL )
	{
	    nMatch++;
	    if ( fAll || is_name( argument, pObjIndex->name ) )
	    {
		found = TRUE;
		sprintf( buf, "[%5d] [%2d] %s\n\r",
		    pObjIndex->vnum, pObjIndex->level, pObjIndex->short_descr );
		send_to_char( buf, ch );
	    }
	}
    }

    if ( !found )
	send_to_char( "No objects by that name.\n\r", ch );

    return;
}


void do_owhere(Character *ch, char *argument )
{
    char buf[MAX_INPUT_LENGTH];
    Buffer *buffer;
    Object *obj;
    Object *in_obj;
    bool found;
    int number = 0, max_found;

    found = FALSE;
    number = 0;
    max_found = 200;

    buffer = new_buf();

    if (argument[0] == '\0')
    {
		send_to_char("Find what?\n\r",ch);
		return;
    }
 
    for ( obj = object_list; obj != NULL; obj = obj->next )
    {
        if ( !can_see_obj( ch, obj ) || !is_name( argument, obj->name ) ||   ch->level < obj->level)
            continue;
 
        found = TRUE;
        number++;
 
        for ( in_obj = obj; in_obj->in_obj != NULL; in_obj = in_obj->in_obj )
            ;
 
        if ( in_obj->carried_by != NULL && can_see(ch,in_obj->carried_by) && in_obj->carried_by->in_room != NULL)
            sprintf( buf, "%3d) %s is carried by %s [Room %d]\n\r", 
				number,
				obj->short_descr,
				PERS(in_obj->carried_by, ch),
				in_obj->carried_by->in_room->vnum );
        else if (in_obj->in_room != NULL && can_see_room(ch,in_obj->in_room))
            sprintf( buf, "%3d) %s is in %s [Room %d]\n\r",
                number, obj->short_descr,in_obj->in_room->name, 
	   			in_obj->in_room->vnum);
		else
            sprintf( buf, "%3d) %s is somewhere\n\r",number, obj->short_descr);
 
        buf[0] = UPPER(buf[0]);
        add_buf(buffer,buf);
 
        if (number >= max_found)
            break;
    }
 
    if ( !found )
        send_to_char( "Nothing like that in heaven or earth.\n\r", ch );
    else
        page_to_char(buf_string(buffer),ch);

    free_buf(buffer);
}


void do_hwhere( Character *ch, char *argument )
{
    Buffer *buffer;
	Room *r;
	Building *bld;
    bool found;
    int count = 0;
	int i;

    found = FALSE;
    buffer = new_buf();
    for ( i=0; i<100000; i++ )
	{
		if ( (r=get_room_index(i)) == NULL || r->buildings == NULL )
			continue;

	    found = TRUE;

		for( bld = r->buildings; bld != NULL; bld = bld->next )
		{
			++count;
		
			bprintf(buffer,"%3d)%sLv%2d %5d/%5d %-12s %-18s [%5d] %s\n\r",
				count, IS_SET(bld->flags,BUILDING_UNDER_CONSTRUCTION)
				? "*" : " ", bld->level, bld->curr_structure, bld->max_structure,
				flag_string( building_flags, bld->type ),
				bld->clan_owner->name, r->vnum, r->name );
		}
    }

    if ( !found )
		act( "You didn't find any halls.", ch, NULL, NULL, TO_CHAR );
    else
    	page_to_char(buf_string(buffer),ch);

    free_buf(buffer);

    return;
}

void do_mwhere( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    Buffer *buffer;
    Character *victim;
    bool found;
    int count = 0;

    if ( argument[0] == '\0' )
    {
	Descriptor *d;

	/* show characters logged */

	buffer = new_buf();
	for (d = descriptor_list; d != NULL; d = d->next)
	{
	    if (d->character != NULL && d->connected == CON_PLAYING
	    &&  d->character->in_room != NULL && can_see(ch,d->character)
	    &&  can_see_room(ch,d->character->in_room))
	    {
		victim = d->character;
		count++;
		if (d->original != NULL)
		    sprintf(buf,"%3d) %s (in the body of %s) is in %s [%d]\n\r",
			count, d->original->name,victim->short_descr,
			victim->in_room->name,victim->in_room->vnum);
		else
		    sprintf(buf,"%3d) %s is in %s [%d]\n\r",
			count, victim->name,victim->in_room->name,
			victim->in_room->vnum);
		add_buf(buffer,buf);
	    }
	}

        page_to_char(buf_string(buffer),ch);
	free_buf(buffer);
	return;
    }

    found = FALSE;
    buffer = new_buf();
    for ( victim = char_list; victim != NULL; victim = victim->next )
    {
	if ( victim->in_room != NULL
	&&   is_name( argument, victim->name ) )
	{
	    found = TRUE;
	    count++;
	    sprintf( buf, "%3d) [%5d] %-28s [%5d] %s\n\r", count,
		IS_NPC(victim) ? victim->pIndexData->vnum : 0,
		IS_NPC(victim) ? victim->short_descr : victim->name,
		victim->in_room->vnum,
		victim->in_room->name );
	    add_buf(buffer,buf);
	}
    }

    if ( !found )
	act( "You didn't find any $T.", ch, NULL, argument, TO_CHAR );
    else
    	page_to_char(buf_string(buffer),ch);

    free_buf(buffer);

    return;
}



void do_reboo( Character *ch, char *argument )
{
    send_to_char( "If you want to REBOOT, spell it out.\n\r", ch );
    return;
}



#define SAVE_MSG	"(Saving)\n\r"

void do_reboot( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    extern bool merc_down;
    Descriptor *d,*d_next;
    Character *vch;

	if ( *argument )
	{
		int seconds = atoi( argument );
		char buf[MAX_STRING_LENGTH];

		snprintf(buf,sizeof(buf),"[&G***&x] Rebooting in %d %s%s.\n\r",
			seconds < 60 ? seconds : seconds / 60,
			seconds < 60 ? "second" : "minute",
			(seconds == 0 || seconds == 60) ? "" : "s" );
		do_echo(ch,buf);
		return;
	}
	
    save_vaults( );
	write_building_file( );
    if (ch->invis_level < LEVEL_HERO)
    {
    	sprintf( buf, "Reboot by %s.", ch->name );
    	do_function(ch, &do_echo, buf );
		do_function(ch, &do_echo, "[ &WHeirs of Crevetier&x :: Rebooting ]" );
    }

    merc_down = TRUE;
    for ( d = descriptor_list; d != NULL; d = d_next )
    {
		d_next = d->next;
		vch = d->original ? d->original : d->character;
		if (vch != NULL)
		{
			if(vch->pcdata->rtptrs.handler && vch->pcdata->rtptrs.handler->logged)
			{
				rtc_logging(vch, NULL, NULL, FALSE);
				rtc_exit(vch, NULL, NULL, FALSE);
			}
			save_char_obj(vch);
		}
		close_socket(d);
    }

	save_clans( );
	save_vaults( );
    return;
}

void do_shutdow( Character *ch, char *argument )
{
    send_to_char( "If you want to SHUTDOWN, spell it out.\n\r", ch );
    return;
}

void do_shutdown( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    extern bool merc_down;
    Descriptor *d,*d_next;
    Character *vch;

    save_vaults( );
	write_building_file( );
    if (ch->invis_level < LEVEL_HERO)
    sprintf( buf, "Shutdown by %s.", ch->name );
    append_file( SHUTDOWN_FILE, buf );
    strcat( buf, "\n\r" );
    if (ch->invis_level < LEVEL_HERO)
    {
    	do_function(ch, &do_echo, buf );
    }
    merc_down = TRUE;
    for ( d = descriptor_list; d != NULL; d = d_next)
    {
	d_next = d->next;
	vch = d->original ? d->original : d->character;
	if (vch != NULL)
	    save_char_obj(vch);
	close_socket(d);
    }

	save_clans();
    return;
}

void do_protect( Character *ch, char *argument)
{
    Character *victim;

    if (argument[0] == '\0')
    {
	send_to_char("Protect whom from snooping?\n\r",ch);
	return;
    }

    if ((victim = get_char_ooc(ch,argument)) == NULL)
    {
	send_to_char("You can't find them.\n\r",ch);
	return;
    }

    if (IS_SET(victim->comm,COMM_SNOOP_PROOF))
    {
	act_new("$N is no longer snoop-proof.",ch,NULL,victim,TO_CHAR,POS_DEAD,TRUE);
	send_to_char("Your snoop-proofing was just removed.\n\r",victim);
	REMOVE_BIT(victim->comm,COMM_SNOOP_PROOF);
    }
    else
    {
	act_new("$N is now snoop-proof.",ch,NULL,victim,TO_CHAR,POS_DEAD,TRUE);
	send_to_char("You are now immune to snooping.\n\r",victim);
	SET_BIT(victim->comm,COMM_SNOOP_PROOF);
    }
}
  


void do_snoop( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Descriptor *d;
    Character *victim;
    char buf[MAX_STRING_LENGTH];

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Snoop whom?\n\r", ch );
	return;
    }

    if ( ( victim = get_char_ooc( ch, arg ) ) == NULL )
    {
	send_to_char( "They aren't here.\n\r", ch );
	return;
    }

    if ( victim->desc == NULL )
    {
	send_to_char( "No descriptor to snoop.\n\r", ch );
	return;
    }

    if ( victim == ch )
    {
	send_to_char( "Cancelling all snoops.\n\r", ch );
	wiznet("$N stops being such a snoop.",
		ch,NULL,WIZ_SNOOPS,WIZ_SECURE,get_trust(ch));
	for ( d = descriptor_list; d != NULL; d = d->next )
	{
	    if ( d->snoop_by == ch->desc )
		d->snoop_by = NULL;
	}
	return;
    }

    if ( victim->desc->snoop_by != NULL )
    {
	send_to_char( "Busy already.\n\r", ch );
	return;
    }

    if (!is_room_owner(ch,victim->in_room) && ch->in_room != victim->in_room 
    &&  room_is_private(victim->in_room) && !IS_TRUSTED(ch,IMPLEMENTOR))
    {
        send_to_char("That character is in a private room.\n\r",ch);
        return;
    }

    if ( get_trust( victim ) >= get_trust( ch ) 
    ||   IS_SET(victim->comm,COMM_SNOOP_PROOF))
    {
	send_to_char( "You failed.\n\r", ch );
	return;
    }

    if ( ch->desc != NULL )
    {
	for ( d = ch->desc->snoop_by; d != NULL; d = d->snoop_by )
	{
	    if ( d->character == victim || d->original == victim )
	    {
		send_to_char( "No snoop loops.\n\r", ch );
		return;
	    }
	}
    }

    victim->desc->snoop_by = ch->desc;
    sprintf(buf,"$N starts snooping on %s",
	(IS_NPC(ch) ? victim->short_descr : victim->name));
    wiznet(buf,ch,NULL,WIZ_SNOOPS,WIZ_SECURE,get_trust(ch));
    send_to_char( "Ok.\n\r", ch );
    return;
}



void do_switch( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH], buf[MAX_STRING_LENGTH];
    Character *victim;

    one_argument( argument, arg );
    
    if ( arg[0] == '\0' )
    {
	send_to_char( "Switch into whom?\n\r", ch );
	return;
    }

    if ( ch->desc == NULL )
	return;
    
    if ( ch->desc->original != NULL )
    {
	send_to_char( "You are already switched.\n\r", ch );
	return;
    }

    if ( ( victim = get_char_ooc( ch, arg ) ) == NULL )
    {
	send_to_char( "They aren't here.\n\r", ch );
	return;
    }

    if ( victim == ch )
    {
	send_to_char( "Ok.\n\r", ch );
	return;
    }

    if (!IS_NPC(victim))
    {
	send_to_char("You can only switch into mobiles.\n\r",ch);
	return;
    }

    if (!is_room_owner(ch,victim->in_room) && ch->in_room != victim->in_room 
    &&  room_is_private(victim->in_room) && !IS_TRUSTED(ch,IMPLEMENTOR))
    {
	send_to_char("That character is in a private room.\n\r",ch);
	return;
    }

    if ( victim->desc != NULL )
    {
	send_to_char( "Character in use.\n\r", ch );
	return;
    }

    sprintf(buf,"$N switches into %s",victim->short_descr);
    wiznet(buf,ch,NULL,WIZ_SWITCHES,WIZ_SECURE,get_trust(ch));

    ch->desc->character = victim;
    ch->desc->original  = ch;
    victim->desc        = ch->desc;
    ch->desc            = NULL;
    /* change communications to match */
    if (ch->prompt != NULL)
        victim->prompt = str_dup(ch->prompt);
    victim->comm = ch->comm;
    victim->lines = ch->lines;
    send_to_char( "Ok.\n\r", victim );
    return;
}



void do_return( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];

    if ( ch->desc == NULL )
	return;

    if ( ch->desc->original == NULL )
    {
	send_to_char( "You aren't switched.\n\r", ch );
	return;
    }

    send_to_char( 
"You return to your original body. Type replay to see any missed tells.\n\r", 
	ch );
    if (ch->prompt != NULL)
    {
	free_string(ch->prompt);
	ch->prompt = NULL;
    }

    sprintf(buf,"$N returns from %s.",ch->short_descr);
    wiznet(buf,ch->desc->original,0,WIZ_SWITCHES,WIZ_SECURE,get_trust(ch));
    ch->desc->character       = ch->desc->original;
    ch->desc->original        = NULL;
    ch->desc->character->desc = ch->desc; 
    ch->desc                  = NULL;
    return;
}

/* trust levels for load and clone */
bool obj_check (Character *ch, Object *obj)
{
	if ( IS_IMMORTAL(ch) )
		return TRUE;
	else
		return FALSE;
}

/* for clone, to insure that cloning goes many levels deep */
void recursive_clone(Character *ch, Object *obj, Object *clone)
{
    Object *c_obj, *t_obj;


    for (c_obj = obj->contains; c_obj != NULL; c_obj = c_obj->next_content)
    {
	if (obj_check(ch,c_obj))
	{
	    t_obj = create_object(c_obj->pIndexData);
	    clone_object(c_obj,t_obj);
	    obj_to_obj(t_obj,clone);
	    recursive_clone(ch,c_obj,t_obj);
	}
    }
}

/* command that is similar to load */
void do_clone(Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    char *rest;
    Character *mob;
    Object  *obj;

    rest = one_argument(argument,arg);

    if (arg[0] == '\0')
    {
	send_to_char("Clone what?\n\r",ch);
	return;
    }

    if (!str_prefix(arg,"object"))
    {
	mob = NULL;
	obj = get_obj_here(ch,rest);
	if (obj == NULL)
	{
	    send_to_char("You don't see that here.\n\r",ch);
	    return;
	}
    }
    else if (!str_prefix(arg,"mobile") || !str_prefix(arg,"character"))
    {
	obj = NULL;
	mob = get_char_room(ch,rest);
	if (mob == NULL)
	{
	    send_to_char("You don't see that here.\n\r",ch);
	    return;
	}
    }
    else /* find both */
    {
	mob = get_char_room(ch,argument);
	obj = get_obj_here(ch,argument);
	if (mob == NULL && obj == NULL)
	{
	    send_to_char("You don't see that here.\n\r",ch);
	    return;
	}
    }

    /* clone an object */
    if (obj != NULL)
    {
	Object *clone;

	if (!obj_check(ch,obj))
	{
	    send_to_char(
		"Your powers are not great enough for such a task.\n\r",ch);
	    return;
	}

	clone = create_object(obj->pIndexData); 
	clone_object(obj,clone);
	if (obj->carried_by != NULL)
	    obj_to_char(clone,ch);
	else
	    obj_to_room(clone,ch->in_room);
 	recursive_clone(ch,obj,clone);

	act("$n has created $p.",ch,clone,NULL,TO_ROOM);
	act("You clone $p.",ch,clone,NULL,TO_CHAR);
	wiznet("$N clones $p.",ch,clone,WIZ_LOAD,WIZ_SECURE,get_trust(ch));
	return;
    }
    else if (mob != NULL)
    {
	Character *clone;
	Object *new_obj;
	char buf[MAX_STRING_LENGTH];

	if (!IS_NPC(mob))
	{
	    send_to_char("You can only clone mobiles.\n\r",ch);
	    return;
	}

	if ( !IS_IMMORTAL(ch) )
	{
		cprintf(ch,"Only admins can clone.\n\r");
	    return;
	}

	clone = create_mobile(mob->pIndexData);
	clone_mobile(mob,clone); 
	
	for (obj = mob->carrying; obj != NULL; obj = obj->next_content)
	{
	    if (obj_check(ch,obj))
	    {
		new_obj = create_object(obj->pIndexData);
		clone_object(obj,new_obj);
		recursive_clone(ch,obj,new_obj);
		obj_to_char(new_obj,clone);
		new_obj->wear_loc = obj->wear_loc;
	    }
	}
	char_to_room(clone,ch->in_room);
        act("$n has created $N.",ch,NULL,clone,TO_ROOM);
        act("You clone $N.",ch,NULL,clone,TO_CHAR);
	sprintf(buf,"$N clones %s.",clone->short_descr);
	wiznet(buf,ch,NULL,WIZ_LOAD,WIZ_SECURE,get_trust(ch));
        return;
    }
}

/* RT to replace the two load commands */

/*void do_load(Character *ch, char *argument )
{
   char arg[MAX_INPUT_LENGTH];

    argument = one_argument(argument,arg);

    if (arg[0] == '\0')
    {
	send_to_char("Syntax:\n\r",ch);
	send_to_char("  load mob <vnum>\n\r",ch);
	send_to_char("  load obj <vnum> <level>\n\r",ch);
	return;
    }

    if (!str_cmp(arg,"mob") || !str_cmp(arg,"char"))
    {
	do_function(ch, &do_mload, argument);
	return;
    }

    if (!str_cmp(arg,"obj"))
    {
	do_function(ch, &do_oload, argument);
	return;
    }
    do_function(ch, &do_load, "");
}*/

void do_load( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH], arg2[MAX_INPUT_LENGTH];
    unsigned char number;
    argument = one_argument(argument,arg);

    if (arg[0] == '\0')
    {
        send_to_char("Syntax:\n\r",ch);
        send_to_char("  load mob <vnum>\n\r",ch);
        send_to_char("  load obj <vnum>\n\r",ch);
        send_to_char("You may also use number*name to load in multiples.\n\r",ch);
        send_to_char("eg: load mob 10*99999\n\r", ch);
        return;
    }
    number = mult_argument(argument, arg2);

    if ( number < 1 )
        number = 1;
    if (!str_prefix(arg, "mobile") || !str_cmp(arg, "character"))
        do_mload(ch, arg2, number);
    else if (!str_prefix(arg, "object"))
       do_oload(ch, arg2, number, TRUE);
    else
	do_function(ch, &do_load, "" );

    return;
}


void do_oload( Character *ch, char *argument, unsigned char number, bool fLog )
{
    char arg1[MAX_INPUT_LENGTH], buf[MAX_STRING_LENGTH];
    ObjIndex *pObjIndex;
    Object *obj;
    int level;
    unsigned char n;
    
    argument = one_argument( argument, arg1 );
    
    if ( arg1[0] == '\0' || number < 1 || !is_number(arg1))
    {
         do_load(ch, "");
         return;
    }

    level = get_trust(ch); /* default */
    if ( ( pObjIndex = get_obj_index( atoi( arg1 ) ) ) == NULL )
    {
        if (fLog)
            send_to_char( "No object has that vnum.\n\r", ch );
        return;
    }
    n = 0;
    do
    {
	 obj = create_object( pObjIndex );
         if ( CAN_WEAR(obj, ITEM_TAKE) )
             obj_to_char( obj, ch );
         else
             obj_to_room( obj, ch->in_room );
    } while (++n < number);
    
    if (fLog)
    {
        sprintf(buf, "$n has created [&C%d&x] $p!", number);
        act( buf, ch, obj, NULL, TO_ROOM );
        sprintf(buf, "$N loads [&C%d&x] $p.", number);
        wiznet(buf,ch,obj,WIZ_LOAD,WIZ_SECURE,get_trust(ch));
        sprintf(buf, "You load [&C%d&x] $p.", number);
        act(buf, ch, obj, NULL, TO_CHAR);
    }
    return;
}

/*
void do_mload( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    MobIndex *pMobIndex;
    Character *victim;
    char buf[MAX_STRING_LENGTH];
    
    one_argument( argument, arg );

    if ( arg[0] == '\0' || !is_number(arg) )
    {
	send_to_char( "Syntax: load mob <vnum>.\n\r", ch );
	return;
    }

    if ( ( pMobIndex = get_mob_index( atoi( arg ) ) ) == NULL )
    {
	send_to_char( "No mob has that vnum.\n\r", ch );
	return;
    }

    victim = create_mobile( pMobIndex );
    char_to_room( victim, ch->in_room );
    act( "$n has created $N!", ch, NULL, victim, TO_ROOM );
    sprintf(buf,"$N loads %s.",victim->short_descr);
    wiznet(buf,ch,NULL,WIZ_LOAD,WIZ_SECURE,get_trust(ch));
    send_to_char( "Ok.\n\r", ch );
    return;
}*/

void do_mload( Character *ch, char *argument, unsigned char number )
{
    char arg[MAX_INPUT_LENGTH], buf[MAX_STRING_LENGTH];
    MobIndex *pMobIndex;
    Character *victim;
    unsigned char n;
    one_argument( argument, arg );
 
    if ( arg[0] == '\0' || !is_number(arg) || number < 1)
    {
        do_load(ch, "");
        return;
    }

    if ( ( pMobIndex = get_mob_index( atoi( arg ) ) ) == NULL )
    {
        send_to_char( "No mob has that vnum.\n\r", ch );
        return;
    }

    n = 0;
    do
    {
        victim = create_mobile( pMobIndex );
        char_to_room( victim, ch->in_room );
    } while (++n < number);

    sprintf(buf, "$n has created [&C%d&x] $N!", number);
    act( buf, ch, NULL, victim, TO_ROOM );
    sprintf(buf,"$N loads [&C%d&x] %s.",number, victim->short_descr);
    wiznet(buf,ch,NULL,WIZ_LOAD,WIZ_SECURE,get_trust(ch));
    sprintf(buf, "You load [&C%d&x] $N.", number);
    act(buf, ch, NULL, victim, TO_CHAR);
    return;
}

void do_purge( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    char buf[100];
    Character *victim;
    Object *obj;
    Descriptor *d;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	/* 'purge' */
	Character *vnext;
	Object  *obj_next;

	for ( victim = ch->in_room->people; victim != NULL; victim = vnext )
	{
	    vnext = victim->next_in_room;
	    if ( IS_NPC(victim) && !IS_SET(victim->act,ACT_NOPURGE) 
	    &&   victim != ch /* safety precaution */ )
	    {
		act("You purge $N.",ch,NULL,victim,TO_CHAR);
		extract_char( victim, TRUE );
	    }
		
	}

	for ( obj = ch->in_room->contents; obj != NULL; obj = obj_next )
	{
	    obj_next = obj->next_content;
	    if (!IS_OBJ_STAT(obj,ITEM_NOPURGE))
	    {
		act("You purge $p.",ch,obj,NULL,TO_CHAR);
	        extract_obj( obj );
	    }
	}

	act( "$n purges the room!", ch, NULL, NULL, TO_ROOM);
	send_to_char( "Ok.\n\r", ch );
	return;
    }

    if ( ( victim = get_char_ooc( ch, arg ) ) == NULL )
    {
	send_to_char( "They aren't here.\n\r", ch );
	return;
    }

    if ( !IS_NPC(victim) )
    {

	if (ch == victim)
	{
	  send_to_char("Ho ho ho.\n\r",ch);
	  return;
	}

	if (get_trust(ch) <= get_trust(victim))
	{
	  send_to_char("Maybe that wasn't a good idea...\n\r",ch);
	  sprintf(buf,"%s tried to purge you!\n\r",ch->name);
	  send_to_char(buf,victim);
	  return;
	}

	act("$n disintegrates $N.",ch,0,victim,TO_NOTVICT);
	act("You purge $N.",ch,NULL,victim,TO_CHAR);

    	if (victim->level > 1)
	    save_char_obj( victim );
    	d = victim->desc;
    	extract_char( victim, TRUE );
    	if ( d != NULL )
          close_socket( d );

	return;
    }

    act( "$n purges $N.", ch, NULL, victim, TO_NOTVICT );
    extract_char( victim, TRUE );
    return;
}



void do_advance( Character *ch, char *argument )
{
	extern void advance_character( Character *victim, int level );
    char buf[MAX_STRING_LENGTH];
    char arg1[MAX_INPUT_LENGTH];
    char arg2[MAX_INPUT_LENGTH];
    Character *victim;
    int level;

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );

    if ( arg1[0] == '\0' || arg2[0] == '\0' || !is_number( arg2 ) )
    {
	send_to_char( "Syntax: advance <char> <level>.\n\r", ch );
	return;
    }

    if ( ( victim = get_char_ooc( ch, arg1 ) ) == NULL )
    {
	send_to_char( "That player is not here.\n\r", ch);
	return;
    }

    if ( IS_NPC(victim) )
    {
	send_to_char( "Not on NPC's.\n\r", ch );
	return;
    }

    if ( ( level = atoi( arg2 ) ) < 1 || level > MAX_LEVEL )
    {
	sprintf(buf,"Level must be 1 to %d.\n\r", MAX_LEVEL);
	send_to_char(buf, ch);
	return;
    }

    if ( level > get_trust( ch ) )
    {
	send_to_char( "Limited to your trust level.\n\r", ch );
	return;
    }

	advance_character( victim, level );
	return;
}

void advance_character( Character *victim, int level )
{
	int iLevel;

    /*
     * Lower level:
     *   Reset to level 1.
     *   Then raise again.
     *   Currently, an imp can lower another imp.
     *   -- Swiftest
     */
    if ( level <= victim->level )
    {
		send_to_char( "**** OOOOHHHHHHHHHH  NNNNOOOO ****\n\r", victim );
		victim->practice = 10;
		victim->train	 = 10;
		victim->level    = 1;
		victim->exp      = 0;
		victim->max_stat_hit    = victim->pcdata->perm_stat_hit = 20;
		victim->max_base_hit 	= victim->pcdata->perm_base_hit = 5;
		victim->max_mana = victim->pcdata->perm_mana = 20;
		victim->max_move = victim->pcdata->perm_move = 100;
		victim->max_stamina = victim->pcdata->perm_stamina = 100;
		victim->stat_hit	= victim->max_stat_hit;
		victim->base_hit	= victim->max_base_hit;
		victim->mana     = victim->max_mana;
		victim->move     = victim->max_move;
	
		/* If someone gets demoted and cant use wizclan anymore, make sure we turn it off */
		if(IS_SET(victim->comm,COMM_WIZCLAN))
		{
			int cmd;
			for(cmd = 0; cmd_table[cmd].name[0] != '\0';cmd ++ )
			{
				if(!strcmp(cmd_table[cmd].name,"wizclan"))
				{
					if(cmd_table[cmd].level > get_trust(victim))
					{
						REMOVE_BIT(victim->comm, COMM_WIZCLAN);
					}
					break;
				}
			}
		}

		/* Strip wizi and incog from demoted imm's */
		if(victim->invis_level > 0 || victim->incog_level > 0)
		{
			if(level < LEVEL_IMMORTAL && get_trust(victim) < LEVEL_IMMORTAL)
			{
				victim->invis_level = 0;
				victim->incog_level = 0;
			}
			else
			{
				if(victim->invis_level > level)
					victim->invis_level = level;

				if(victim->incog_level > level)
					victim->incog_level = level;
			}
		}	
		/*advance_level( victim, TRUE );*/
    }
    else
		send_to_char( "**** OOOOHHHHHHHHHH  YYYYEEEESSS ****\n\r", victim );

    for ( iLevel = victim->level ; iLevel < level; iLevel++ )
    {
	victim->level += 1;
	advance_level( victim,TRUE);
    }
    cprintf(victim,"You are now level %d.\n\r",victim->level);
    victim->exp   =  0;
		  
    victim->trust = 0;

    save_char_obj(victim);
    return;
}



void do_trust( Character *ch, char *argument )
{
    char arg1[MAX_INPUT_LENGTH];
    char arg2[MAX_INPUT_LENGTH];
    char buf[MAX_STRING_LENGTH];
    Character *victim;
    int level;

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );

    if ( arg1[0] == '\0' || arg2[0] == '\0' || !is_number( arg2 ) )
    {
	send_to_char( "Syntax: trust <char> <level>.\n\r", ch );
	return;
    }

    if ( ( victim = get_char_ooc( ch, arg1 ) ) == NULL )
    {
	send_to_char( "That player is not here.\n\r", ch);
	return;
    }

    if ( ( level = atoi( arg2 ) ) < 0 || level > MAX_LEVEL )
    {
	sprintf(buf, "Level must be 0 (reset) or 1 to %d.\n\r",MAX_LEVEL);
	send_to_char(buf, ch);
	return;
    }

    if ( level > get_trust( ch ) )
    {
	send_to_char( "Limited to your trust.\n\r", ch );
	return;
    }

    victim->trust = level;
    return;
}

void do_restore( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH], buf[MAX_STRING_LENGTH];
    Character *victim;
    Character *vch;
    Descriptor *d;

    one_argument( argument, arg );
    if (arg[0] == '\0' || !str_cmp(arg,"room"))
    {
    /* cure room */
    	
        for (vch = ch->in_room->people; vch != NULL; vch = vch->next_in_room)
        {
            affect_strip(vch,gsn_plague);
            affect_strip(vch,gsn_poison);
            affect_strip(vch,gsn_blindness);
            affect_strip(vch,gsn_sleep);
            affect_strip(vch,gsn_curse);
           
	    	vch->base_hit	= vch->max_base_hit;
	    	vch->stat_hit	= max_stat_hit(vch);
	    	vch->stamina	= max_stamina(vch); 
            vch->mana	= max_mana(vch);
            vch->move	= vch->max_move;
            update_pos( vch);
            act_new("$n has restored you.",ch,NULL,vch,TO_VICT,POS_DEAD,FALSE);
        }

        sprintf(buf,"$N restored room %d.",ch->in_room->vnum);
        wiznet(buf,ch,NULL,WIZ_RESTORE,WIZ_SECURE,get_trust(ch));
        
        send_to_char("Room restored.\n\r",ch);
        return;

    }
    
    if ( !str_cmp(arg,"all"))
    {
    /* cure all */
    	
        for (d = descriptor_list; d != NULL; d = d->next)
        {
	    victim = d->character;

	    if (victim == NULL || IS_NPC(victim))
		continue;
                
            affect_strip(victim,gsn_plague);
            affect_strip(victim,gsn_poison);
            affect_strip(victim,gsn_blindness);
            affect_strip(victim,gsn_sleep);
            affect_strip(victim,gsn_curse);

            victim->base_hit       = victim->max_base_hit;
            victim->stat_hit       = max_stat_hit(victim);
            victim->stamina        = max_stamina(victim);
            victim->mana   = max_mana(victim);
            victim->move   = victim->max_move;
            
            update_pos( victim);
	    if (victim->in_room != NULL)
                act_new("$n has restored you.",ch,NULL,victim,TO_VICT,POS_DEAD,FALSE);
        }
	send_to_char("All active players restored.\n\r",ch);
	return;
    }

    if ( ( victim = get_char_ooc( ch, arg ) ) == NULL )
    {
	send_to_char( "They aren't here.\n\r", ch );
	return;
    }

    affect_strip(victim,gsn_plague);
    affect_strip(victim,gsn_poison);
    affect_strip(victim,gsn_blindness);
    affect_strip(victim,gsn_sleep);
    affect_strip(victim,gsn_curse);

            victim->base_hit       = victim->max_base_hit;
            victim->stat_hit       = max_stat_hit(victim);
            victim->stamina        = max_stamina(victim);
            victim->mana   = max_mana(victim);
            victim->move   = victim->max_move;

    update_pos( victim );
    act_new( "$n has restored you.", ch, NULL, victim, TO_VICT, POS_DEAD,FALSE );
    sprintf(buf,"$N restored %s",
	IS_NPC(victim) ? victim->short_descr : victim->name);
    wiznet(buf,ch,NULL,WIZ_RESTORE,WIZ_SECURE,get_trust(ch));
    send_to_char( "Ok.\n\r", ch );
    return;
}

 	
void do_freeze( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH],buf[MAX_STRING_LENGTH];
    Character *victim;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Freeze whom?\n\r", ch );
	return;
    }

    if ( ( victim = get_char_ooc( ch, arg ) ) == NULL )
    {
	send_to_char( "They aren't here.\n\r", ch );
	return;
    }

    if ( IS_NPC(victim) )
    {
	send_to_char( "Not on NPC's.\n\r", ch );
	return;
    }

    if ( get_trust( victim ) >= get_trust( ch ) )
    {
	send_to_char( "You failed.\n\r", ch );
	return;
    }

    if ( IS_SET(victim->act, PLR_FREEZE) )
    {
	REMOVE_BIT(victim->act, PLR_FREEZE);
	send_to_char( "You can play again.\n\r", victim );
	send_to_char( "FREEZE removed.\n\r", ch );
	sprintf(buf,"$N thaws %s.",victim->name);
	wiznet(buf,ch,NULL,WIZ_PENALTIES,WIZ_SECURE,0);
    }
    else
    {
	SET_BIT(victim->act, PLR_FREEZE);
	send_to_char( "You can't do ANYthing!\n\r", victim );
	send_to_char( "FREEZE set.\n\r", ch );
	sprintf(buf,"$N puts %s in the deep freeze.",victim->name);
	wiznet(buf,ch,NULL,WIZ_PENALTIES,WIZ_SECURE,0);
    }

    save_char_obj( victim );

    return;
}



void do_log( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Character *victim;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Log whom?\n\r", ch );
	return;
    }

    if ( !str_cmp( arg, "all" ) )
    {
	if ( fLogAll )
	{
	    fLogAll = FALSE;
	    send_to_char( "Log ALL off.\n\r", ch );
	}
	else
	{
	    fLogAll = TRUE;
	    send_to_char( "Log ALL on.\n\r", ch );
	}
	return;
    }

    if ( ( victim = get_char_ooc( ch, arg ) ) == NULL )
    {
	send_to_char( "They aren't here.\n\r", ch );
	return;
    }

    if ( IS_NPC(victim) )
    {
	send_to_char( "Not on NPC's.\n\r", ch );
	return;
    }

    /*
     * No level check, gods can log anyone.
     */
    if ( IS_SET(victim->act, PLR_LOG) )
    {
	REMOVE_BIT(victim->act, PLR_LOG);
	send_to_char( "LOG removed.\n\r", ch );
    }
    else
    {
	SET_BIT(victim->act, PLR_LOG);
	send_to_char( "LOG set.\n\r", ch );
    }

    return;
}



void do_noemote( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH],buf[MAX_STRING_LENGTH];
    Character *victim;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Noemote whom?\n\r", ch );
	return;
    }

    if ( ( victim = get_char_ooc( ch, arg ) ) == NULL )
    {
	send_to_char( "They aren't here.\n\r", ch );
	return;
    }


    if ( get_trust( victim ) >= get_trust( ch ) )
    {
	send_to_char( "You failed.\n\r", ch );
	return;
    }

    if ( IS_SET(victim->comm, COMM_NOEMOTE) )
    {
	REMOVE_BIT(victim->comm, COMM_NOEMOTE);
	send_to_char( "You can emote again.\n\r", victim );
	send_to_char( "NOEMOTE removed.\n\r", ch );
	sprintf(buf,"$N restores emotes to %s.",victim->name);
	wiznet(buf,ch,NULL,WIZ_PENALTIES,WIZ_SECURE,0);
    }
    else
    {
	SET_BIT(victim->comm, COMM_NOEMOTE);
	send_to_char( "You can't emote!\n\r", victim );
	send_to_char( "NOEMOTE set.\n\r", ch );
	sprintf(buf,"$N revokes %s's emotes.",victim->name);
	wiznet(buf,ch,NULL,WIZ_PENALTIES,WIZ_SECURE,0);
    }

    return;
}



void do_noshout( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH],buf[MAX_STRING_LENGTH];
    Character *victim;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Noshout whom?\n\r",ch);
	return;
    }

    if ( ( victim = get_char_ooc( ch, arg ) ) == NULL )
    {
	send_to_char( "They aren't here.\n\r", ch );
	return;
    }

    if ( IS_NPC(victim) )
    {
	send_to_char( "Not on NPC's.\n\r", ch );
	return;
    }

    if ( get_trust( victim ) >= get_trust( ch ) )
    {
	send_to_char( "You failed.\n\r", ch );
	return;
    }

    if ( IS_SET(victim->comm, COMM_NOSHOUT) )
    {
	REMOVE_BIT(victim->comm, COMM_NOSHOUT);
	send_to_char( "You can shout again.\n\r", victim );
	send_to_char( "NOSHOUT removed.\n\r", ch );
	sprintf(buf,"$N restores shouts to %s.",victim->name);
	wiznet(buf,ch,NULL,WIZ_PENALTIES,WIZ_SECURE,0);
    }
    else
    {
	SET_BIT(victim->comm, COMM_NOSHOUT);
	send_to_char( "You can't shout!\n\r", victim );
	send_to_char( "NOSHOUT set.\n\r", ch );
	sprintf(buf,"$N revokes %s's shouts.",victim->name);
	wiznet(buf,ch,NULL,WIZ_PENALTIES,WIZ_SECURE,0);
    }

    return;
}



void do_notell( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH],buf[MAX_STRING_LENGTH];
    Character *victim;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Notell whom?", ch );
	return;
    }

    if ( ( victim = get_char_ooc( ch, arg ) ) == NULL )
    {
	send_to_char( "They aren't here.\n\r", ch );
	return;
    }

    if ( get_trust( victim ) >= get_trust( ch ) )
    {
	send_to_char( "You failed.\n\r", ch );
	return;
    }

    if ( IS_SET(victim->comm, COMM_NOTELL) )
    {
	REMOVE_BIT(victim->comm, COMM_NOTELL);
	send_to_char( "You can tell again.\n\r", victim );
	send_to_char( "NOTELL removed.\n\r", ch );
	sprintf(buf,"$N restores tells to %s.",victim->name);
	wiznet(buf,ch,NULL,WIZ_PENALTIES,WIZ_SECURE,0);
    }
    else
    {
	SET_BIT(victim->comm, COMM_NOTELL);
	send_to_char( "You can't tell!\n\r", victim );
	send_to_char( "NOTELL set.\n\r", ch );
	sprintf(buf,"$N revokes %s's tells.",victim->name);
	wiznet(buf,ch,NULL,WIZ_PENALTIES,WIZ_SECURE,0);
    }

    return;
}



void do_peace( Character *ch, char *argument )
{
    Character *rch;

    for ( rch = ch->in_room->people; rch != NULL; rch = rch->next_in_room )
    {
	if ( rch->fighting != NULL )
	    stop_fighting( rch, TRUE );
	if (IS_NPC(rch) && IS_SET(rch->act,ACT_AGGRESSIVE))
	    REMOVE_BIT(rch->act,ACT_AGGRESSIVE);
	if ( rch->casting != NULL )
	{
	    free_casting_data( rch->casting );
	    REMOVE_BIT(rch->act,PLR_IS_CASTING);
	}
    }

    send_to_char( "Ok.\n\r", ch );
    return;
}

void do_enablepk( Character *ch, char *argument )
{
    extern bool pk_enabled;
    pk_enabled = !pk_enabled;

    if ( pk_enabled )
    {
	    wiznet("$N has enabled player killing.",ch,NULL,0,0,0);
	    cprintf(ch,"Player killing is enabled.\n\r");
        do_echo(ch,"[&R!!!&x] &WNOTICE&x: Player-killing is ENABLED!");
    }
    else
    {
	    wiznet("$N has disabled player killing.",ch,NULL,0,0,0);
	    cprintf(ch,"Player killing is disabled.\n\r");
        do_echo(ch,"[&R!!!&x] &WNOTICE&x: Player-killing is DISABLED!");
    }

    return;
}

void do_enablelooting( Character *ch, char *argument )
{
    extern bool loot_enabled;
    loot_enabled = !loot_enabled;

    if ( loot_enabled )
    {
        wiznet("$N has enabled player corpse looting.",ch,NULL,0,0,0);
        cprintf(ch,"Player corpse looting is enabled.\n\r");
        do_echo(ch,"[&R!!!&x] &WNOTICE&x: Player corpse looting is ENABLED!");
    }
    else
    {
        wiznet("$N has disabled player corpse looting.",ch,NULL,0,0,0);
        cprintf(ch,"Player corpse looting is disabled.\n\r");
        do_echo(ch,"[&R!!!&x] &WNOTICE&x: Player corpse looting is DISABLED!");
    }

    return;
}

void do_wizlock( Character *ch, char *argument )
{
    extern bool wizlock;
    wizlock = !wizlock;

    if ( wizlock )
    {
	wiznet("$N has wizlocked the game.",ch,NULL,0,0,0);
	send_to_char( "Game wizlocked.\n\r", ch );
    }
    else
    {
	wiznet("$N removes wizlock.",ch,NULL,0,0,0);
	send_to_char( "Game un-wizlocked.\n\r", ch );
    }

    return;
}

/* RT anti-newbie code */

void do_newlock( Character *ch, char *argument )
{
    extern bool newlock;
    newlock = !newlock;
 
    if ( newlock )
    {
	wiznet("$N locks out new characters.",ch,NULL,0,0,0);
        send_to_char( "New characters have been locked out.\n\r", ch );
    }
    else
    {
	wiznet("$N allows new characters back in.",ch,NULL,0,0,0);
        send_to_char( "Newlock removed.\n\r", ch );
    }
 
    return;
}


void do_spell_lookup( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Buffer *output;
	SpellIndex* pSpellIndex;

    one_argument( argument, arg );
    if ( arg[0] == '\0' )
    {
        send_to_char( "Lookup which spell?\n\r", ch );
        return;
    }

    output = new_buf();
    if ( !str_cmp( arg, "all" ) )
    {
		int vnum, nMatch = 0;

		bprintf(output," == DIVINE SPELLS == \n\r");
        
	    for ( vnum = 0; nMatch <= top_spell_index; vnum++ )
		{
			if ( ( pSpellIndex = get_spell_index( vnum ) ) != NULL )
			{
				nMatch++;
				
				if ( !IS_SET(pSpellIndex->flags,COM_DIVINE) )
					continue;
            
				bprintf( output, "Spell#: %3d  Spell: '%s', Mana %d\n\r",
					pSpellIndex->vnum, pSpellIndex->name, pSpellIndex->base_mana );
			}
		}

		bprintf(output,"\n\r == ARCANE SPELLS ==\n\r");
        
	    nMatch = 0;
		for ( vnum = 0; nMatch < top_spell_index; vnum++ )
		{
			if ( ( pSpellIndex = get_spell_index( vnum ) ) != NULL )
			{
				nMatch++;
				
				if ( !IS_SET(pSpellIndex->flags,COM_ARCANE) )
		            continue;
            
				bprintf( output, "Spell#: %3d  Spell: '%s', Level %d/%d/%d/%d, Mana %d\n\r",
				    pSpellIndex->vnum, pSpellIndex->name,
					pSpellIndex->class_level[0], 
					pSpellIndex->class_level[1],
					pSpellIndex->class_level[2],
					pSpellIndex->class_level[3],
					pSpellIndex->base_mana );
			}
		}
    }
    else
    {	
        int i;

        for ( i=0 ; i <= top_spell_vnum ; i++ )
        {
		    if ( (pSpellIndex = get_spell_index(i)) != NULL )
		    {
                if ( !str_prefix(arg,pSpellIndex->name) )
			    bprintf( output, "[v&G%5d&x] %s\n\r", pSpellIndex->vnum, pSpellIndex->name );
		    }
        }
    }

    page_to_char( buf_string(output), ch );
    free_buf( output );
    return;
}



void do_slookup( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    char arg[MAX_INPUT_LENGTH];
    int sn;

    one_argument( argument, arg );
    if ( arg[0] == '\0' )
    {
	send_to_char( "Lookup which skill or spell?\n\r", ch );
	return;
    }

    if ( !str_cmp( arg, "all" ) )
    {
	for ( sn = 0; sn < MAX_SKILL; sn++ )
	{
	    if ( skill_table[sn].name == NULL )
		break;
	    sprintf( buf, "Sn: %3d  Skill/spell: '%s'\n\r",
		sn, skill_table[sn].name );
	    send_to_char( buf, ch );
	}
    }
    else
    {
	if ( ( sn = skill_lookup( arg ) ) < 0 )
	{
	    send_to_char( "No such skill or spell.\n\r", ch );
	    return;
	}

	sprintf( buf, "Sn: %3d  Skill/spell: '%s'\n\r",
	    sn, skill_table[sn].name );
	send_to_char( buf, ch );
    }

    return;
}

/* RT set replaces sset, mset, oset, and rset */

void do_respecialize( Character *ch, char *argument )
{
	Character *victim;
	int i, total;

	if ( *argument == '\0' )
	{
		cprintf(ch,"Syntax:  respec <victim>\n\r");
		return;
	}

	if ( (victim = get_char_ooc(ch,argument)) == NULL )
	{
		cprintf(ch,"No such player.\n\r");
		return;
	}
	
	if ( victim->level > ch->level || IS_NPC(victim) )
	{
		cprintf(ch,"Can't respec that person (they're either an NPC or above your level).\n\r");
		return;
	}

	/* Reset skills */
	for( i=0 ; skill_table[i].name != NULL ; i++ )
	{
		if ( skill_table[i].type == SKILL_TRADE || skill_table[i].type == SKILL_FOUNDATION )
			continue;

		if (victim->pcdata->learned[i] > 0 )
			victim->pcdata->learned[i] = 1;
	}

	/* Count up points they should have */
	total = 10;
	for( i=2 ; i <= victim->level ; i++ )
 		total += getSkillPoints( victim, i );

	victim->practice = total;
	actprintf(ch,NULL,victim,TO_CHAR,"$N has $S skill points reset to %d.",total);
	act("Your skill points and skills have been reset.",ch,NULL,victim,TO_VICT);
	return;
}

void do_set( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];

    argument = one_argument(argument,arg);

    if (arg[0] == '\0')
    {
	    cprintf(ch,"Syntax:\n\r");
	    cprintf(ch,"  set mob   <name> <field> <value>\n\r");
	    cprintf(ch,"  set obj   <name> <field> <value>\n\r");
	    cprintf(ch,"  set room  <room> <field> <value>\n\r");
	    cprintf(ch,"  set bld   <name> <field> <value>\n\r");
        cprintf(ch,"  set skill <name> <skill> <value>\n\r");
        cprintf(ch,"  set game  <element> <value1> [value2]\n\r");
	    return;
    }

    if (!str_prefix(arg,"game") )
    {
        do_function(ch, &do_gset, argument);
        return;
    }

	if (!str_prefix(arg,"bld") || !str_prefix(arg,"building") )
    {
		do_function(ch, &do_bset, argument);
		return;
    }

    if (!str_prefix(arg,"mobile") || !str_prefix(arg,"character"))
    {
	do_function(ch, &do_mset, argument);
	return;
    }

	if ( !str_prefix(arg,"proficiency") )
    {
	do_function(ch, &do_pset, argument);
	return;
    }

    if (!str_prefix(arg,"skill") )
    {
	do_function(ch, &do_sset, argument);
	return;
    }

    if (!str_prefix(arg,"object"))
    {
	do_function(ch, &do_oset, argument);
	return;
    }

    if (!str_prefix(arg,"room"))
    {
	do_function(ch, &do_rset, argument);
	return;
    }
    /* echo syntax */
    do_function(ch, &do_set, "");
}

void do_spellset( Character *ch, char *argument )
{
    char arg1 [MAX_INPUT_LENGTH];
    char arg2 [MAX_INPUT_LENGTH];
    char arg3 [MAX_INPUT_LENGTH];
    Character *victim;
    int value;
    int sn;
    bool fAll;
	SpellIndex* pSpellIndex;

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );
    argument = one_argument( argument, arg3 );

    if ( arg1[0] == '\0' || arg2[0] == '\0' || arg3[0] == '\0' )
    {
        send_to_char( "Syntax:\n\r",ch);
        send_to_char( "  spellset <name> <spell> on|off\n\r", ch);
        send_to_char( "  spellset <name> all on|off\n\r",ch);
        send_to_char("   (use the name of the spell, not the number)\n\r",ch);
        return;
    }

    if ( ( victim = get_char_ooc( ch, arg1 ) ) == NULL )
    {
        send_to_char( "They aren't here.\n\r", ch );
        return;
    }

    if ( IS_NPC(victim) )
    {
        send_to_char( "Not on NPC's.\n\r", ch );
        return;
    }

    fAll = !str_cmp( arg2, "all" );
    sn   = 0;	/* -1 == search all */
    if ( !fAll && ( sn = spell_lookup( arg2, -1 ) ) < 0 )
    {
        send_to_char( "No such spell.\n\r", ch );
        return;
    }

	if ( !str_cmp(arg3,"on") )
		value = 1;
	else
	if ( !str_cmp(arg3,"off") )
		value = 0;
	else
	{
		cprintf(ch,"Spells must be set to 'on' or 'off'.\n\r");
		return;
	}

    if ( fAll )
    {
	    int vnum, nMatch = 0;

		for ( vnum = 0; nMatch < top_spell_index; vnum++ )
		{
			if ( ( pSpellIndex = get_spell_index( vnum ) ) != NULL )
			{
				nMatch++;
				
				victim->pcdata->spells[pSpellIndex->vnum] = value;
			}
		}
    }
    else
    {
        pSpellIndex = get_spell_index(sn);
		victim->pcdata->spells[pSpellIndex->vnum] = value;
    }

    return;
}

void do_pset( Character *ch, char *argument )
{
    char arg1 [MAX_INPUT_LENGTH];
    char arg2 [MAX_INPUT_LENGTH];
    char arg3 [MAX_INPUT_LENGTH];
    Character *victim;
    int sn;
	int value;
    bool fAll;

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );
    argument = one_argument( argument, arg3 );

    if ( arg1[0] == '\0' || arg2[0] == '\0' || arg3[0] == '\0' )
    {
	send_to_char( "Syntax:\n\r",ch);
	send_to_char( "  set prof <name> <proficiency> <on|off>\n\r", ch);
	send_to_char( "  set prof <name> all <on|off>\n\r",ch);  
	send_to_char("   (use the name of the proficiency, not the number)\n\r",ch);
	return;
    }

    if ( ( victim = get_char_ooc( ch, arg1 ) ) == NULL )
    {
	send_to_char( "They aren't here.\n\r", ch );
	return;
    }

    if ( IS_NPC(victim) )
    {
	send_to_char( "Not on NPC's.\n\r", ch );
	return;
    }

    fAll = !str_cmp( arg2, "all" );
    sn   = 0;
    if ( !fAll && ( sn = proficiency_lookup( arg2 ) ) < 0 )
    {
	send_to_char( "No such proficiency.\n\r", ch );
	return;
    }

    /*
     * Snarf the value.
     */
	if ( !str_cmp(arg3,"on") )
		value = 1;
	else
	if ( !str_cmp(arg3,"off") )
		value = 0;
	else
	{
		cprintf(ch,"Valid values are 'on' and 'off'.\n\r");
		return;
	}

    if ( fAll )
    {
		for ( sn = 0; sn < MAX_PROFICIENCY; sn++ )
		{
	    	if ( prof_table[sn].name != NULL )
				victim->pcdata->profs[sn]	= value;
		}
    }
    else
    {
	victim->pcdata->profs[sn] = value;
    }

	cprintf(ch,"Ok.\n\r");
    return;
}

void do_sset( Character *ch, char *argument )
{
    char arg1 [MAX_INPUT_LENGTH];
    char arg2 [MAX_INPUT_LENGTH];
    char arg3 [MAX_INPUT_LENGTH];
    Character *victim;
    int value;
    int sn;
    bool fAll;

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );
    argument = one_argument( argument, arg3 );

    if ( arg1[0] == '\0' || arg2[0] == '\0' || arg3[0] == '\0' )
    {
	send_to_char( "Syntax:\n\r",ch);
	send_to_char( "  set skill <name> <skill> <value>\n\r", ch);
	send_to_char( "  set skill <name> all <value>\n\r",ch);  
	send_to_char("   (use the name of the skill, not the number)\n\r",ch);
	return;
    }

    if ( ( victim = get_char_ooc( ch, arg1 ) ) == NULL )
    {
	send_to_char( "They aren't here.\n\r", ch );
	return;
    }

    if ( IS_NPC(victim) )
    {
	send_to_char( "Not on NPC's.\n\r", ch );
	return;
    }

    fAll = !str_cmp( arg2, "all" );
    sn   = 0;
    if ( !fAll && ( sn = skill_lookup( arg2 ) ) < 0 )
    {
	send_to_char( "No such skill.\n\r", ch );
	return;
    }

    /*
     * Snarf the value.
     */
    if ( !is_number( arg3 ) )
    {
	send_to_char( "Value must be numeric.\n\r", ch );
	return;
    }

    value = atoi( arg3 );
    if ( value < 0 || value > 255 )
    {
	send_to_char( "Value range is 0 to 255.\n\r", ch );
	return;
    }

    if ( fAll )
    {
	for ( sn = 0; sn < MAX_SKILL; sn++ )
	{
	    if ( skill_table[sn].name != NULL )
		victim->pcdata->learned[sn]	= value;
	}
    }
    else
    {
	victim->pcdata->learned[sn] = value;
    }

    return;
}

void do_gset( Character *ch, char *argument )
{
    char arg1 [MAX_INPUT_LENGTH];
    char arg2 [MAX_INPUT_LENGTH];
    char arg3 [MAX_INPUT_LENGTH];

    smash_tilde( argument );
    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );
    strcpy( arg3, argument );

    if ( arg1[0] == '\0' || arg2[0] == '\0' )
    {
	send_to_char("Syntax:\n\r",ch);
	send_to_char( "  set game <element> <value1> [value2]\n\r",ch); 
	send_to_char( "  Field being one of:\n\r",			ch );
	send_to_char( "    structure level material resources clan\n\r",ch );
	return;
    }

    if ( !str_cmp( arg1, "subrace" ) )
    {
        int subrace;

        if ( (subrace = subrace_lookup( arg2 )) < 0 )
        {
            cprintf(ch,"No subrace like %s.\n\r", arg2);
            return;
        }

        *subrace_table[subrace].next_avail = current_time;
        cprintf(ch,"Subrace %s is now available.\n\r", 
            subrace_table[subrace].name );
        return;
    }

    cprintf(ch,"That element has no implementation in gset.\n\r");
    return;
}

void do_bset( Character *ch, char *argument )
{
    char arg1 [MAX_INPUT_LENGTH];
    char arg2 [MAX_INPUT_LENGTH];
    char arg3 [MAX_INPUT_LENGTH];
	Building *bld;
    int value;

    smash_tilde( argument );
    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );
    strcpy( arg3, argument );

    if ( arg1[0] == '\0' || arg2[0] == '\0' || arg3[0] == '\0' )
    {
	send_to_char("Syntax:\n\r",ch);
	send_to_char( "  set bld <name> <field> <value>\n\r",ch); 
	send_to_char( "  Field being one of:\n\r",			ch );
	send_to_char( "    structure level material resources clan\n\r",ch );
	return;
    }

    if ( ( bld = get_building_room( ch, arg1 ) ) == NULL )
    {
		send_to_char( "It's not here.\n\r", ch );
		return;
    }

    /*
     * Snarf the value (which need not be numeric).
     */
    value = is_number( arg3 ) ? atoi( arg3 ) : -1;

    /*
     * Set something.
     */

	if ( !strcmp( arg2, "structure" ) )
	{
        extern int createBuilding( int type, Clan *clan, Room *room );

		bld->curr_structure = UMIN(bld->max_structure,value);
		cprintf(ch,"Structure points set to %d.\n\r",bld->curr_structure);

        if ( bld->curr_structure >= bld->max_structure &&
             IS_SET(bld->flags, BUILDING_UNDER_CONSTRUCTION) )
        {
            REMOVE_BIT(bld->flags, BUILDING_UNDER_CONSTRUCTION);
            bld->entrance_room = createBuilding( bld->type, ch->clan, ch->in_room );
            actprintf(ch,NULL,NULL,TO_ROOM,"The %s has been completed!",
                flag_string( building_flags, bld->type ) );
            write_building_file( );
        }
		return;
	}

	if ( !strcmp( arg2, "level" ) )
	{
		bld->level = URANGE(1,value,50);
		cprintf(ch,"Structure level set to %d.\n\r", bld->level);
		return;
	}

    if ( !str_cmp( arg2, "material" ) )
    {
		if ( !str_cmp(arg3,"wood") )
			bld->material = BUILDMAT_WOOD;
		else
		if ( !str_cmp(arg3,"stone") )
			bld->material = BUILDMAT_STONE;
		else
		{
			cprintf(ch,"Valid materials are 'wood' or 'stone'.\n\r");
			return;
		}

		cprintf(ch,"Material set.\n\r");
		return;
    }

	if ( !str_cmp( arg2, "resources" ) )
	{
		bld->available_resources = UMIN(bld->max_structure,value);
		cprintf(ch,"Resources set to %d.\n\r",bld->available_resources);
		return;
	}

    do_function(ch, &do_bset, "" );
    return;
}

void do_mset( Character *ch, char *argument )
{
    char arg1 [MAX_INPUT_LENGTH];
    char arg2 [MAX_INPUT_LENGTH];
    char arg3 [MAX_INPUT_LENGTH];
    char buf[100];
    Character *victim;
    int value;
	int cur;

    smash_tilde( argument );
    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );
    strcpy( arg3, argument );

    /*if ( arg1[0] == '\0' || arg2[0] == '\0' || arg3[0] == '\0' )*/
    if ( arg1[0] == '\0' || arg2[0] == '\0' )
    {
	send_to_char("Syntax:\n\r",ch);
	send_to_char("  set char <name> <field> <value>\n\r",ch); 
	send_to_char( "  Field being one of:\n\r",			ch );
	send_to_char( "    str int wis dex con cha sex class level\n\r",ch );
	send_to_char( "    race stamina basehit mana move prac\n\r",ch);
	send_to_char( "    train thirst hunger drunk full security\n\r", ch );
  	send_to_char( "    silver gold electrum platinum mithril role\n\r", ch );
    cprintf( ch,  "    skillpoints specpoints nonclan teamlead subrace\n\r", ch );
	cprintf( ch,  "    deity builder rank enemy deprac\n\r");
	return;
    }

    if ( ( victim = get_char_ooc( ch, arg1 ) ) == NULL )
    {
	send_to_char( "They aren't here.\n\r", ch );
	return;
    }

    /* clear zones for mobs */
    victim->zone = NULL;

    /*
     * Snarf the value (which need not be numeric).
     */
    value = is_number( arg3 ) ? atoi( arg3 ) : -1;

    /*
     * Set something.
     */

    if ( !str_prefix( arg2, "depractice" ) )
    {
        victim->pcdata->deprac[DEPRACTICE] = current_time;
        cprintf(victim,"Your depractice timer has been reset.\n\r");
        act("$N's depractice timer has been reset.",ch,NULL,victim,TO_CHAR);
        return;
    }
 
    if ( !strcmp( arg2, "enemy" ) )
    {
        int race;

        if ( IS_NPC(victim) )
        {
            cprintf(ch,"Only PC's can have a species enemy.\n\r");
            return;
        }

        if ( victim->class != class_lookup("ranger") )
        {
            cprintf(ch,"Only rangers may declare a species enemy.\n\r");
            return;
        }

        if ( arg3[0] == '\0' )
        {
            int race;

            cprintf(ch,"Available enemy races:\n\r");

            for( race=1 ; race_table[race].name != NULL &&
                str_cmp(race_table[race].name,"unique") 
                ; race++ )
            {
                cprintf(ch," * %-16s", race_table[race].name);
                if ( race % 4 == 0 )
                    cprintf(ch,"\n\r");
            }

            cprintf(ch,"\n\r");
            return;
        }

        if ( (race = race_lookup(argument)) < 1 ||
             race == race_lookup("unique") )
        {
            cprintf(ch,"No such race.\n\r");
            return;
        }

        if ( victim->race == race )
        {
            cprintf(ch,"You cannot set someones own race as their species enemy!\n\r");
            return;
        }

        victim->pcdata->class_info.ranger.species_enemy = race;
        cprintf(ch,"You set the %s race as the species enemy of %s.\n\r",
            race_table[race].name, victim->name );
        return;
    }

	if ( !strcmp( arg2, "deity" ) )
	{
		int deity;
 
        if ( arg3[0] == '\0' )
        {
            cprintf(ch,"Available deities:\n\r");

            for ( deity = 0 ; deity_table[deity].name != NULL ; deity++ )
            {
                if ( deity % 3 == 0 && deity > 0)
                    cprintf(ch,"\n\r");

                cprintf(ch," * %-11s %-9s", deity_table[deity].name,
                    deity_table[deity].align == ALIGN_GOOD ? "(Good)" :
                    deity_table[deity].align == ALIGN_EVIL ? "(Evil)" : "(Neutral)");
            }

            cprintf(ch,"\n\r");
            return;
        }

		if ( (deity = deity_lookup( arg3 )) < 0 )
		{
			cprintf(ch,"No deity '%s'.\n\r", arg3 );
			return;
		}
	
        if (class_table[victim->class].group == DIVINE && deity == 0)
        {
            cprintf(ch,"Divine classes cannot be agnostic.\n\r");
            return;
        }

		victim->deity = deity;
        cprintf(ch,"%s's deity set to %s.\n\r",victim->name,deity_table[deity].name);
		return;
	}

	if ( !strcmp( arg2, "specpoints" ) )
	{
		if ( value < 0 || value > 30000 )
		{
			cprintf(ch,"Range is 0 to 30,000.\n\r");
			return;
		}

		victim->pcdata->spec_points = value;
		cprintf(ch,"Spec points for '%s' set to %d.\n\r",victim->name,value);
		return;
	}

    if ( !str_cmp( arg2, "skillpoints" ) )
    {
		if ( value < 0 || value > 30000 )
		{
	    	cprintf(ch,"Range is 0 to 30,000.\n\r");
	    	return;
		}

		victim->practice = value;
		cprintf(ch,"Skill points for '%s' set to %d.\n\r",victim->name,value);
		return;
    }

	if ( !str_cmp( arg2, "nonclan" ) )
	{
		if ( IS_NPC(victim) )
		{
			cprintf(ch,"Only players can be flagged NONCLAN.\n\r");
			return;
		}

		TOGGLE_BIT(victim->act,PLR_NONCLAN);
		if ( IS_SET(victim->act,PLR_NONCLAN) )
		{
			act("$N is now flagged NONCLAN.",ch,NULL,victim,TO_CHAR);
			act("You are now flagged NONCLAN.",ch,NULL,victim,TO_VICT);
		}
		else
		{
			act("$N is no longer flagged NONCLAN.",ch,NULL,victim,TO_CHAR);
			act("You are no longer flagged NONCLAN.",ch,NULL,victim,TO_VICT);
		}
		return;
	}

	if ( !str_cmp( arg2, "teamlead" ) || !str_cmp(arg2,"tl") )
	{
		if ( IS_NPC(victim) )
		{
			cprintf(ch,"Only players can be Team Leads.\n\r");
			return;
		}

		TOGGLE_BIT(victim->act,PLR_TEAM_LEAD);
		if ( IS_SET(victim->act,PLR_TEAM_LEAD) )
		{
			act("$N is now a TEAM LEAD for $S class.",ch,NULL,victim,TO_CHAR);
			act("You are now a TEAM LEAD for your class.",ch,NULL,victim,TO_VICT);
		}
		else
		{
			act("$N is no longer a TEAM LEAD for $S class.",ch,NULL,victim,TO_CHAR);
			act("You are no longer a TEAM LEAD for your class.",ch,NULL,victim,TO_VICT);
		}
		return;
	}

	if ( !str_cmp( arg2, "builder" ))
	{
		if ( IS_NPC(victim) )
		{
			cprintf(ch,"Only players can be Builders.\n\r");
			return;
		}

		TOGGLE_BIT(victim->act,PLR_BUILDER);
		if ( IS_SET(victim->act,PLR_BUILDER) )
		{
			act("$N is now a BUILDER.",ch,NULL,victim,TO_CHAR);
			act("You are now a BUILDER.",ch,NULL,victim,TO_VICT);
		}
		else
		{
			act("$N is no longer a BUILDER.",ch,NULL,victim,TO_CHAR);
			act("You are no longer a BUILDER.",ch,NULL,victim,TO_VICT);
		}
		return;
	}

    if ( !str_cmp( arg2, "role" ) )
    {
		if ( !IS_IMMORTAL(victim) || IS_NPC(victim) )
 		{
	    	cprintf(ch,"This can only be used on immortal PC's.\n\r");
	    	return;
		}
	
        /*if ( arg3[0] == '\0' )
        {
            cprintf(ch, "You must specify a role.\n\r");
	    	cprintf(ch, "Options are: coder admin builder ambience developer\n\r");
            return;
        }*/

        if ( !str_prefix( arg3, "coder" ) )
		{
	    	victim->pcdata->imm_role = IMM_ROLE_CODER;
   	    	cprintf(ch,"Set to CODER.\n\r");
		}
		else
		if ( !str_prefix( arg3, "admin" ) )
		{
	    	victim->pcdata->imm_role = IMM_ROLE_ADMIN;
	    	cprintf(ch,"Set to ADMIN.\n\r");
		}
		else
		if ( !str_prefix( arg3, "builder" ) )
		{
	    	victim->pcdata->imm_role = IMM_ROLE_BUILDER;
 	    	cprintf(ch,"Set to BUILDER.\n\r");
		}
		else
		if ( !str_prefix( arg3, "ambience" ) )
		{
	    	victim->pcdata->imm_role = IMM_ROLE_AMBIENCE;
	    	cprintf(ch,"Set to AMBIENCE.\n\r");
		}
		else
		if ( !str_prefix( arg3, "developer") )
   		{
	    	victim->pcdata->imm_role = IMM_ROLE_DEVELOPER;
   	    	cprintf(ch,"Set to DEVELOPER.\n\r");
		}
		else
	    	cprintf(ch,"Options are: coder admin builder ambience developer\n\r");
	 
  		return;
    }

    if ( !str_cmp( arg2, "basehit") )
    {
        if ( value < 1 || value > 30000 )
        {
	    cprintf(ch,"Range is 1 to 30,000.\n\r");
            return;
        }

		victim->max_base_hit = value;
		if( !IS_NPC(victim) )
	    	victim->pcdata->perm_base_hit = value;
        cprintf(ch,"Max Base Hits for %s set to %d.\n\r",victim->name,victim->max_base_hit);
        return;
    }

    if ( !str_cmp( arg2, "stamina") )
    {
        if ( value < 1 || value > 30000 )
        {
            cprintf(ch,"Range is 1 to 30,000.\n\r");
            return;
        }

        victim->max_stamina = value;
        if( !IS_NPC(victim) )
            victim->pcdata->perm_stamina = value;
        cprintf(ch,"Max Stamina for %s set to %d.\n\r",victim->name,victim->max_stamina);
        return;
    }

    if ( !str_cmp( arg2, "str" ) )
    {
		if ( value < 3 || value > get_max_train(victim,STAT_STR) )
		{
	    	cprintf(ch, "Strength range is 3 to %d.\n\r", get_max_train(victim,STAT_STR));
	    	return;
		}

		victim->perm_stat[STAT_STR] = value;
        cprintf(ch,"%s STR set to %d\n",victim->name,victim->perm_stat[STAT_STR]);
		return;
    }

    if ( !str_cmp( arg2, "int" ) )
    {
        if ( value < 3 || value > get_max_train(victim,STAT_INT) )
        {
            sprintf(buf,
		"Intelligence range is 3 to %d.\n\r",
		get_max_train(victim,STAT_INT));
            send_to_char(buf,ch);
            return;
        }
 
        victim->perm_stat[STAT_INT] = value;
        cprintf(ch,"%s INT set to %d\n",victim->name,victim->perm_stat[STAT_INT]);
        return;
    }

    if ( !str_cmp( arg2, "wis" ) )
    {
	if ( value < 3 || value > get_max_train(victim,STAT_WIS) )
	{
	    sprintf(buf,
		"Wisdom range is 3 to %d.\n\r",get_max_train(victim,STAT_WIS));
	    send_to_char( buf, ch );
	    return;
	}

	victim->perm_stat[STAT_WIS] = value;
        cprintf(ch,"%s WIS set to %d\n",victim->name,victim->perm_stat[STAT_WIS]);
	return;
    }

    if ( !str_cmp( arg2, "dex" ) )
    {
	if ( value < 3 || value > get_max_train(victim,STAT_DEX) )
	{
	    sprintf(buf,
		"Dexterity range is 3 to %d.\n\r",
		get_max_train(victim,STAT_DEX));
	    send_to_char( buf, ch );
	    return;
	}

	victim->perm_stat[STAT_DEX] = value;
        cprintf(ch,"%s DEX set to %d\n",victim->name,victim->perm_stat[STAT_DEX]);
	return;
    }

    if ( !str_cmp( arg2, "con" ) )
    {
	if ( value < 3 || value > get_max_train(victim,STAT_CON) )
	{
	    sprintf(buf,
		"Constitution range is 3 to %d.\n\r",
		get_max_train(victim,STAT_CON));
	    send_to_char( buf, ch );
	    return;
	}

	victim->perm_stat[STAT_CON] = value;
        cprintf(ch,"%s CON set to %d\n",victim->name,victim->perm_stat[STAT_CON]);
	return;
    }

    if ( !str_cmp( arg2, "cha" ) )
    {
        if ( value < 3 || value > get_max_train(victim,STAT_CHA) )
        {
            sprintf(buf,
                "Charisma range is 3 to %d.\n\r",
                get_max_train(victim,STAT_CHA));
            send_to_char( buf, ch );
            return;
        }

        victim->perm_stat[STAT_CHA] = value;
        cprintf(ch,"%s CHA set to %d\n",victim->name,victim->perm_stat[STAT_CHA]);
        return;
    }

    if ( !str_prefix( arg2, "sex" ) )
    {
	if ( value < 0 || value > 2 )
	{
	    send_to_char( "Sex range is 0 to 2.\n\r", ch );
	    return;
	}
	victim->sex = value;
	if (!IS_NPC(victim))
	    victim->pcdata->true_sex = value;
	return;
    }

    if ( !str_prefix( arg2, "class" ) )
    {
	int class;

	if (IS_NPC(victim))
	{
	    send_to_char("Mobiles have no class.\n\r",ch);
	    return;
	}

	class = class_lookup(arg3);
	if ( class == -1 )
	{
       	cprintf(ch, "Possible classes are:\n\r");
       	for ( class = 0; class < MAX_CLASS; class++ )
       	{
            if ( class % 3 == 0 && class > 0)
                cprintf(ch,"\n\r");
            cprintf(ch," * %-16s", class_table[class].name);
        }

        cprintf(ch,"\n\r");
	    return;
	}

	victim->class = class;
	return;
    }

    if ( !str_prefix( arg2, "level" ) )
    {
	if ( !IS_NPC(victim) )
	{
	    send_to_char( "Not on PC's.\n\r", ch );
	    return;
	}

	if ( value < 0 || value > MAX_LEVEL )
	{
	    sprintf(buf, "Level range is 0 to %d.\n\r", MAX_LEVEL);
	    send_to_char(buf, ch);
	    return;
	}
	victim->level = value;
	return;
    }

	if ( (cur = currency_lookup( arg2 )) >= 0 )
	{
        if(arg3[0] == '\0')
        {
            cprintf(ch,"You must specify an amount of %s to set.\n\r",currency_table[cur].name);
            return;
        }

        if(value < 0)
        {
            cprintf(ch,"You must specify an amount of %s that is >= 0.\n\r",
                currency_table[cur].name);
            return;
        }

		victim->coins[cur] = value;
		cprintf(ch,"%s set to %ld for %s.\n\r",capitalize(currency_table[cur].name), value, victim->name );
		return;
	}

    if ( !str_prefix( arg2, "hp" ) )
    {
	if ( value < 0 || value > 30000 )
	{
	    send_to_char( "Stat HP range is 0 to 30,000 hit points.\n\r", ch );
	    return;
	}
	victim->max_stat_hit = value;
        if (!IS_NPC(victim))
            victim->pcdata->perm_stat_hit = value;
	return;
    }

    if ( !str_prefix( arg2, "mana" ) )
    {
	if ( value < 0 || value > 30000 )
	{
	    send_to_char( "Mana range is 0 to 30,000 mana points.\n\r", ch );
	    return;
	}
	victim->max_mana = value;
        if (!IS_NPC(victim))
            victim->pcdata->perm_mana = value;
	return;
    }

    if ( !str_prefix( arg2, "move" ) )
    {
	if ( value < 0 || value > 30000 )
	{
	    send_to_char( "Move range is 0 to 30,000 move points.\n\r", ch );
	    return;
	}
	victim->max_move = value;
        if (!IS_NPC(victim))
            victim->pcdata->perm_move = value;
	return;
    }

    if ( !str_prefix( arg2, "practice" ) )
    {
	if ( value < 0 || value > 250 )
	{
	    send_to_char( "Practice range is 0 to 250 sessions.\n\r", ch );
	    return;
	}
	victim->practice = value;
	return;
    }

    if ( !str_prefix( arg2, "train" ))
    {
	if (value < 0 || value > 50 )
	{
	    send_to_char("Training session range is 0 to 50 sessions.\n\r",ch);
	    return;
	}
	victim->train = value;
	return;
    }

    if ( !str_prefix( arg2, "thirst" ) )
    {
	if ( IS_NPC(victim) )
	{
	    send_to_char( "Not on NPC's.\n\r", ch );
	    return;
	}

	if ( arg3[0] == '\0' || value < -1 || value > 100 )
	{
	    send_to_char( "Thirst range is -1 to 100.\n\r", ch );
	    return;
	}

	victim->pcdata->condition[COND_THIRST] = value;
	return;
    }

    if ( !str_prefix( arg2, "drunk" ) )
    {
	if ( IS_NPC(victim) )
	{
	    send_to_char( "Not on NPC's.\n\r", ch );
	    return;
	}

	if ( arg3[0] == '\0' || value < -1 || value > 100 )
	{
	    send_to_char( "Drunk range is -1 to 100.\n\r", ch );
	    return;
	}

	victim->pcdata->condition[COND_DRUNK] = value;
	return;
    }

    if ( !str_prefix( arg2, "full" ) )
    {
	if ( IS_NPC(victim) )
	{
	    send_to_char( "Not on NPC's.\n\r", ch );
	    return;
	}

	if ( arg3[0] == '\0' || value < -1 || value > 100 )
	{
	    send_to_char( "Full range is -1 to 100.\n\r", ch );
	    return;
	}

	victim->pcdata->condition[COND_FULL] = value;
	return;
    }

    if ( !str_prefix( arg2, "hunger" ) )
    {
        if ( IS_NPC(victim) )
        {
            send_to_char( "Not on NPC's.\n\r", ch );
            return;
        }
 
	    if ( arg3[0] == '\0' || value < -1 || value > 100 )
        {
            send_to_char( "Full range is -1 to 100.\n\r", ch );
            return;
        }
 
        victim->pcdata->condition[COND_HUNGER] = value;
        return;
    }

	if ( !str_prefix( arg2, "subrace" ) )
	{
		int subrace;

		if ( IS_NPC(victim) )
		{
			cprintf(ch,"Not on NPCs.\n\r");
			return;
		}

        if ( arg3[0] == '\0' )
        {
            cprintf(ch,"Available Subraces:\n\r");

            for ( subrace = 1; subrace_table[subrace].name != NULL; subrace++)
            {
                cprintf(ch," * %-16s", subrace_table[subrace].name);
                if ( subrace % 4 == 0 )
                    cprintf(ch,"\n\r");
            }

            cprintf(ch,"\n\r");
            return;
        }

		subrace = subrace_lookup(arg3);

		if ( subrace <= 0 )
		{
			cprintf(ch,"Invalid subrace.\n\r");
			return;
		}

		victim->pcdata->subrace = subrace;
		actprintf(ch,NULL,victim,TO_CHAR,"$N's subrace set to %s.",
			subrace_table[subrace].name );
		return;
	}

    if (!str_prefix( arg2, "race" ) )
    {
    	int race;

        if ( arg3[0] == '\0' )
        {
            if(IS_NPC(victim))
            {
                cprintf(ch,"Available NPC Races:\n\r");

                for ( race = 0; race_table[race].name != NULL; race++)
                {
                    if ( race % 3 == 0 && race > 0)
                        cprintf(ch,"\n\r");
                    cprintf(ch," * %-16s", race_table[race].name);
                }
            }
            else
            {
                int race_count;
                cprintf(ch,"Available PC Races:\n\r");

                for ( race = 0, race_count = 0; race_table[race].name != NULL; race++ )
                {
                    if(!race_table[race].pc_race)
                        continue;

                    if ( race_count % 3 == 0 && race_count > 0)
                        cprintf(ch,"\n\r");
                    cprintf(ch," * %-16s", race_table[race].name);
                    race_count++;
                }
            }

            cprintf(ch,"\n\r");
            return;
        }

	    race = race_lookup(arg3);

	    if ( race == 0 )
	    {
	        send_to_char("That is not a valid race.\n\r",ch);
	        return;
	    }

	    if (!IS_NPC(victim) && !race_table[race].pc_race)
	    {
	        send_to_char("That is not a valid player race.\n\r",ch);
	        return;
	    }

	    victim->race = race;
	    return;
    }
   
    if (!str_prefix(arg2,"group"))
    {
	if (!IS_NPC(victim))
	{
	    send_to_char("Only on NPCs.\n\r",ch);
	    return;
	}
	victim->group = value;
	return;
    }

	if ( !str_cmp( arg2, "rank" ) )
	{
		if ( IS_NPC(victim) )
		{
			cprintf(ch,"NPCs do not have clan ranks.\n\r");
			return;
		}

		if ( value < 1 || value > 9 )
		{
			cprintf(ch,"Valid clan rank is 1-9.\n\r");
			return;
		}
	
		setRank(victim,value);
		cprintf(ch,"%s set to rank %d.\n\r", victim->name, value );
		return;
	}

    if ( !str_cmp( arg2, "security" ) )	/* OLC */
    {
        if ( IS_NPC( victim ) )
        {
            send_to_char( "Not on NPC's.\n\r", ch );
            return;
        }

	if ( value > ch->pcdata->security || value < 0 )
	{
	    if ( ch->pcdata->security != 0 )
	    {
		sprintf( buf, "Valid security is 0-%d.\n\r",
		    ch->pcdata->security );
		send_to_char( buf, ch );
	    }
	    else
	    {
		send_to_char( "Valid security is 0 only.\n\r", ch );
	    }
	    return;
	}
	victim->pcdata->security = value;
	return;
    }


    /*
     * Generate usage message.
     */
    do_function(ch, &do_mset, "" );
    return;
}

void do_string( Character *ch, char *argument )
{
    char type [MAX_INPUT_LENGTH];
    char arg1 [MAX_INPUT_LENGTH];
    char arg2 [MAX_INPUT_LENGTH];
    char arg3 [MAX_INPUT_LENGTH];
    Character *victim;
    Object *obj;

    smash_tilde( argument );
    argument = one_argument( argument, type );
    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );
    strcpy( arg3, argument );

    if ( type[0] == '\0' || arg1[0] == '\0' || arg2[0] == '\0' || arg3[0] == '\0' )
    {
	send_to_char("Syntax:\n\r",ch);
	send_to_char("  string char <name> <field> <string>\n\r",ch);
	send_to_char("    fields: name short long desc title spec\n\r",ch);
	send_to_char("  string obj  <name> <field> <string>\n\r",ch);
	send_to_char("    fields: name short long extended\n\r",ch);
	return;
    }
    
    if (!str_prefix(type,"character") || !str_prefix(type,"mobile"))
    {
    	if ( ( victim = get_char_ooc( ch, arg1 ) ) == NULL )
    	{
	    send_to_char( "They aren't here.\n\r", ch );
	    return;
    	}

	/* clear zone for mobs */
	victim->zone = NULL;

	/* string something */

     	if ( !str_prefix( arg2, "name" ) )
    	{
	    if ( !IS_NPC(victim) )
	    {
	    	send_to_char( "Not on PC's.\n\r", ch );
	    	return;
	    }
	    free_string( victim->name );
	    victim->name = str_dup( arg3 );
	    return;
    	}
    	
    	if ( !str_prefix( arg2, "description" ) )
    	{
    	    free_string(victim->description);
    	    victim->description = str_dup(arg3);
    	    return;
    	}

    	if ( !str_prefix( arg2, "short" ) )
    	{
	    free_string( victim->short_descr );
	    victim->short_descr = str_dup( arg3 );
	    return;
    	}

    	if ( !str_prefix( arg2, "long" ) )
    	{
	    free_string( victim->long_descr );
	    strcat(arg3,"\n\r");
	    victim->long_descr = str_dup( arg3 );
	    return;
    	}

    	if ( !str_prefix( arg2, "title" ) )
    	{
	    if ( IS_NPC(victim) )
	    {
	    	send_to_char( "Not on NPC's.\n\r", ch );
	    	return;
	    }

	    set_title( victim, arg3 );
	    return;
    	}

    	if ( !str_prefix( arg2, "spec" ) )
    	{
	    if ( !IS_NPC(victim) )
	    {
	    	send_to_char( "Not on PC's.\n\r", ch );
	    	return;
	    }

	    if ( ( victim->spec_fun = spec_lookup( arg3 ) ) == 0 )
	    {
	    	send_to_char( "No such spec fun.\n\r", ch );
	    	return;
	    }

	    return;
    	}
    }
    
    if (!str_prefix(type,"object"))
    {
    	/* string an obj */
    	
   	if ( ( obj = get_obj_world( ch, arg1 ) ) == NULL )
    	{
	    send_to_char( "Nothing like that in heaven or earth.\n\r", ch );
	    return;
    	}
    	
        if ( !str_prefix( arg2, "name" ) )
    	{
	    free_string( obj->name );
	    obj->name = str_dup( arg3 );
	    return;
    	}

    	if ( !str_prefix( arg2, "short" ) )
    	{
	    free_string( obj->short_descr );
	    obj->short_descr = str_dup( arg3 );
	    return;
    	}

    	if ( !str_prefix( arg2, "long" ) )
    	{
	    free_string( obj->description );
	    obj->description = str_dup( arg3 );
	    return;
    	}

    	if ( !str_prefix( arg2, "ed" ) || !str_prefix( arg2, "extended"))
    	{
	    ExtraDescr *ed;

	    argument = one_argument( argument, arg3 );
	    if ( argument == NULL )
	    {
	    	send_to_char( "Syntax: oset <object> ed <keyword> <string>\n\r",
		    ch );
	    	return;
	    }

 	    strcat(argument,"\n\r");

	    ed = new_extra_descr();

	    ed->keyword		= str_dup( arg3     );
	    ed->description	= str_dup( argument );
	    ed->next		= obj->extra_descr;
	    obj->extra_descr	= ed;
	    return;
    	}
    }
    
    	
    /* echo bad use message */
    do_function(ch, &do_string, "");
}



void do_oset( Character *ch, char *argument )
{
    char arg1 [MAX_INPUT_LENGTH];
    char arg2 [MAX_INPUT_LENGTH];
    char arg3 [MAX_INPUT_LENGTH];
    Object *obj;
    int value;

    smash_tilde( argument );
    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );
    strcpy( arg3, argument );

    if ( arg1[0] == '\0' || arg2[0] == '\0' || arg3[0] == '\0' )
    {
	send_to_char("Syntax:\n\r",ch);
	send_to_char("  set obj <object> <field> <value>\n\r",ch);
	send_to_char("  Field being one of:\n\r",				ch );
	send_to_char("    value0 value1 value2 value3 value4 (v1-v4)\n\r",	ch );
	send_to_char("    extra wear level weight cost timer\n\r",		ch );
	cprintf(ch,  "    condition quality durability\n\r");
	return;
    }

    if ( ( obj = get_obj_world( ch, arg1 ) ) == NULL )
    {
	send_to_char( "Nothing like that in heaven or earth.\n\r", ch );
	return;
    }

    /*
     * Snarf the value (which need not be numeric).
     */
    value = atoi( arg3 );

    /*
     * Set something.
     */
	if ( !str_cmp( arg2, "condition" ) )
	{
		if ( obj->wear_loc != -1 ) 
		{
			cprintf(ch,"You cannot set this value while the item is being worn.\n\r");
			return;
		}
		obj->condition = URANGE(0,value,100);
		cprintf(ch,"Condition set to %d.\n\r", obj->condition );
		return;
	}

	if ( !str_cmp( arg2, "quality" ) )
	{
		if ( obj->wear_loc != -1 )
		{
			cprintf(ch,"You cannot set this value while the item is being worn.\n\r");
			return;
		}
		obj->quality = URANGE(0,value,100);
		cprintf(ch,"Quality set to %d.\n\r", obj->quality );
		return;
	}

	if ( !str_cmp( arg2, "durability" ) )
	{
		if ( obj->wear_loc != -1 )
		{
			cprintf(ch,"You cannot set this value while the item is being worn.\n\r");
			return;
		}
		obj->durability = URANGE(0,value,100);
		cprintf(ch,"Durability set to %d.\n\r", obj->durability );
		return;
	}

    if ( !str_cmp( arg2, "value0" ) || !str_cmp( arg2, "v0" ) )
    {
		obj->value[0] = value;
		return;
    }

    if ( !str_cmp( arg2, "value1" ) || !str_cmp( arg2, "v1" ) )
    {
		obj->value[1] = value;
		return;
    }

    if ( !str_cmp( arg2, "value2" ) || !str_cmp( arg2, "v2" ) )
    {
	obj->value[2] = value;
	return;
    }

    if ( !str_cmp( arg2, "value3" ) || !str_cmp( arg2, "v3" ) )
    {
	obj->value[3] = value;
	return;
    }

    if ( !str_cmp( arg2, "value4" ) || !str_cmp( arg2, "v4" ) )
    {
	obj->value[4] = value;
	return;
    }

    if ( !str_cmp( arg2, "value5" ) || !str_cmp( arg2, "v5" ) )
    {
        obj->value[5] = value;
        return;
    }

    if ( !str_cmp( arg2, "value6" ) || !str_cmp( arg2, "v6" ) )
    {
        obj->value[6] = value;
        return;
    }

    if ( !str_cmp( arg2, "value7" ) || !str_cmp( arg2, "v7" ) )
    {
        obj->value[7] = value;
        return;
    }

    if ( !str_cmp( arg2, "value8" ) || !str_cmp( arg2, "v8" ) )
    {
        obj->value[8] = value;
        return;
    }

    if ( !str_cmp( arg2, "value9" ) || !str_cmp( arg2, "v9" ) )
    {
        obj->value[9] = value;
        return;
    }

    if ( !str_prefix( arg2, "extra" ) )
    {
	obj->extra_flags = value;
	return;
    }

    if ( !str_prefix( arg2, "wear" ) )
    {
	obj->wear_flags = value;
	return;
    }

    if ( !str_prefix( arg2, "level" ) )
    {
	obj->level = value;
	return;
    }
	
    if ( !str_prefix( arg2, "weight" ) )
    {
	obj->weight = value;
	return;
    }

    if ( !str_prefix( arg2, "cost" ) )
    {
	obj->cost = value;
	return;
    }

    if ( !str_prefix( arg2, "timer" ) )
    {
	obj->timer = value;
	return;
    }
	
    /*
     * Generate usage message.
     */
    do_function(ch, &do_oset, "" );
    return;
}



void do_rset( Character *ch, char *argument )
{
    char arg1 [MAX_INPUT_LENGTH];
    char arg2 [MAX_INPUT_LENGTH];
    char arg3 [MAX_INPUT_LENGTH];
    Room *location;
    int value;

    smash_tilde( argument );
    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );
    strcpy( arg3, argument );

    if ( arg1[0] == '\0' || arg2[0] == '\0' || arg3[0] == '\0' )
    {
	send_to_char( "Syntax:\n\r",ch);
	send_to_char( "  set room <location> <field> <value>\n\r",ch);
	send_to_char( "  Field being one of:\n\r",			ch );
	send_to_char( "    flags sector\n\r",				ch );
	return;
    }

    if ( ( location = find_location( ch, arg1 ) ) == NULL )
    {
	send_to_char( "No such location.\n\r", ch );
	return;
    }

    if (!is_room_owner(ch,location) && ch->in_room != location 
    &&  room_is_private(location) && !IS_TRUSTED(ch,IMPLEMENTOR))
    {
        send_to_char("That room is private right now.\n\r",ch);
        return;
    }

    /*
     * Snarf the value.
     */
    if ( !is_number( arg3 ) )
    {
	send_to_char( "Value must be numeric.\n\r", ch );
	return;
    }
    value = atoi( arg3 );

    /*
     * Set something.
     */
    if ( !str_prefix( arg2, "flags" ) )
    {
	location->room_flags	= value;
	return;
    }

    if ( !str_prefix( arg2, "sector" ) )
    {
	location->sector_type	= value;
	return;
    }

    /*
     * Generate usage message.
     */
    do_function(ch, &do_rset, "");
    return;
}



void do_sockets( Character *ch, char *argument )
{
    char buf[2 * MAX_STRING_LENGTH];
    char buf2[MAX_STRING_LENGTH];
    char arg[MAX_INPUT_LENGTH];
    Descriptor *d;
    int count;

    count	= 0;
    buf[0]	= '\0';

    one_argument(argument,arg);
    for ( d = descriptor_list; d != NULL; d = d->next )
    {
		if ( d->character == NULL )
			continue;

		if ( d->character->level > ch->level )
			continue;

		if ( (arg[0] == '\0' || is_name(arg,d->character->name)
			   || (d->original && is_name(arg,d->original->name))))
		{
	    	count++;
	    	sprintf( buf + strlen(buf), "[%3d %2d] %s@%s\n\r",
			d->descriptor,
			d->connected,
			(d->connected && d->connected < 2) ? "(connecting)" :
			d->original  ? d->original->name  :
			d->character ? d->character->name : "(none)",
			d->host
			);
		}
    }
    if (count == 0)
    {
	send_to_char("No one by that name is connected.\n\r",ch);
	return;
    }

    sprintf( buf2, "%d user%s\n\r", count, count == 1 ? "" : "s" );
    strcat(buf,buf2);
    page_to_char( buf, ch );
    return;
}



/*
 * Thanks to Grodyn for pointing out bugs in this function.
 */
void do_force( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    char arg[MAX_INPUT_LENGTH];
    char arg2[MAX_INPUT_LENGTH];

    argument = one_argument( argument, arg );

    if ( arg[0] == '\0' || argument[0] == '\0' )
    {
	send_to_char( "Force whom to do what?\n\r", ch );
	return;
    }

    one_argument(argument,arg2);
  
    if (!str_cmp(arg2,"delete"))
    {
	send_to_char("That will NOT be done.\n\r",ch);
	return;
    }

    sprintf( buf, "$n forces you to '%s'.", argument );

    if ( !str_cmp( arg, "all" ) )
    {
	Character *vch;
	Character *vch_next;

	if (get_trust(ch) < MAX_LEVEL - 3)
	{
	    send_to_char("Not at your level!\n\r",ch);
	    return;
	}

	for ( vch = char_list; vch != NULL; vch = vch_next )
	{
	    vch_next = vch->next;

	    if ( !IS_NPC(vch) && get_trust( vch ) < get_trust( ch ) )
	    {
		act( buf, ch, NULL, vch, TO_VICT );
		interpret( vch, argument );
	    }
	}
    }
    else if (!str_cmp(arg,"players"))
    {
        Character *vch;
        Character *vch_next;
 
        if (get_trust(ch) < MAX_LEVEL - 2)
        {
            send_to_char("Not at your level!\n\r",ch);
            return;
        }
 
        for ( vch = char_list; vch != NULL; vch = vch_next )
        {
            vch_next = vch->next;
 
            if ( !IS_NPC(vch) && get_trust( vch ) < get_trust( ch ) 
	    &&	 vch->level < LEVEL_HERO)
            {
                act( buf, ch, NULL, vch, TO_VICT );
                interpret( vch, argument );
            }
        }
    }
    else if (!str_cmp(arg,"gods"))
    {
        Character *vch;
        Character *vch_next;
 
        if (get_trust(ch) < MAX_LEVEL - 2)
        {
            send_to_char("Not at your level!\n\r",ch);
            return;
        }
 
        for ( vch = char_list; vch != NULL; vch = vch_next )
        {
            vch_next = vch->next;
 
            if ( !IS_NPC(vch) && get_trust( vch ) < get_trust( ch )
            &&   vch->level >= LEVEL_HERO)
            {
                act( buf, ch, NULL, vch, TO_VICT );
                interpret( vch, argument );
            }
        }
    }
    else
    {
	Character *victim;

	if ( ( victim = get_char_ooc( ch, arg ) ) == NULL )
	{
	    send_to_char( "They aren't here.\n\r", ch );
	    return;
	}

	if ( victim == ch )
	{
	    send_to_char( "Aye aye, right away!\n\r", ch );
	    return;
	}

    	if (!is_room_owner(ch,victim->in_room) 
	&&  ch->in_room != victim->in_room 
        &&  room_is_private(victim->in_room) && !IS_TRUSTED(ch,IMPLEMENTOR))
    	{
            send_to_char("That character is in a private room.\n\r",ch);
            return;
        }

	if ( get_trust( victim ) >= get_trust( ch ) )
	{
	    send_to_char( "Do it yourself!\n\r", ch );
	    return;
	}

	if ( !IS_NPC(victim) && get_trust(ch) < MAX_LEVEL -3)
	{
	    send_to_char("Not at your level!\n\r",ch);
	    return;
	}

	act( buf, ch, NULL, victim, TO_VICT );
	interpret( victim, argument );
    }

    send_to_char( "Ok.\n\r", ch );
    return;
}



/*
 * New routines by Dionysos.
 */
void do_invis( Character *ch, char *argument )
{
    int level;
    char arg[MAX_STRING_LENGTH];

    /* RT code for taking a level argument */
    one_argument( argument, arg );

    if ( arg[0] == '\0' ) 
    /* take the default path */

      if ( ch->invis_level)
      {
	  ch->invis_level = 0;
	  act( "$n slowly fades into existence.", ch, NULL, NULL, TO_ROOM );
	  send_to_char( "You slowly fade back into existence.\n\r", ch );
      }
      else
      {
	  ch->invis_level = get_trust(ch);
	  act( "$n slowly fades into thin air.", ch, NULL, NULL, TO_ROOM );
	  send_to_char( "You slowly vanish into thin air.\n\r", ch );
      }
    else
    /* do the level thing */
    {
      level = atoi(arg);
      if (level < 2 || level > get_trust(ch))
      {
	send_to_char("Invis level must be between 2 and your level.\n\r",ch);
        return;
      }
      else
      {
	  ch->reply = NULL;
          ch->invis_level = level;
          act( "$n slowly fades into thin air.", ch, NULL, NULL, TO_ROOM );
          send_to_char( "You slowly vanish into thin air.\n\r", ch );
      }
    }

    return;
}


void do_incognito( Character *ch, char *argument )
{
    int level;
    char arg[MAX_STRING_LENGTH];
 
    /* RT code for taking a level argument */
    one_argument( argument, arg );
 
    if ( arg[0] == '\0' )
    /* take the default path */
 
      if ( ch->incog_level)
      {
          ch->incog_level = 0;
          act( "$n is no longer cloaked.", ch, NULL, NULL, TO_ROOM );
          send_to_char( "You are no longer cloaked.\n\r", ch );
      }
      else
      {
          ch->incog_level = get_trust(ch);
          act( "$n cloaks $s presence.", ch, NULL, NULL, TO_ROOM );
          send_to_char( "You cloak your presence.\n\r", ch );
      }
    else
    /* do the level thing */
    {
      level = atoi(arg);
      if (level < 2 || level > get_trust(ch))
      {
        send_to_char("Incog level must be between 2 and your level.\n\r",ch);
        return;
      }
      else
      {
          ch->reply = NULL;
          ch->incog_level = level;
          act( "$n cloaks $s presence.", ch, NULL, NULL, TO_ROOM );
          send_to_char( "You cloak your presence.\n\r", ch );
      }
    }
 
    return;
}

/* prefix command: it will put the string typed on each line typed */

void do_pload( Character *ch, char *argument )
{
  Descriptor d;
  bool isChar = FALSE;
  char name[MAX_INPUT_LENGTH];

  if (argument[0] == '\0')
  {
    send_to_char("Load who?\n\r", ch);
    return;
  }

  argument[0] = UPPER(argument[0]);
  argument = one_argument(argument, name);

  /* Don't want to load a second copy of a player who's already online! */
  if ( get_char_ooc( ch, name ) != NULL )
  {
    send_to_char( "That person is already connected!\n\r", ch );
    return;
  }

  isChar = load_char_obj(&d, name); /* char pfile exists? */

  if (!isChar)
  {
    send_to_char("No such pfile (be sure to use the full name).\n\r", ch);
    return;
  }

  d.character->desc     = NULL;
  d.character->next     = char_list;
  char_list             = d.character;
  d.connected           = CON_PLAYING;
  reset_char(d.character);

  /* bring player to imm */
  if ( d.character->in_room != NULL )
  {
    if ( d.character->was_in_room == NULL )
      d.character->was_in_room = d.character->in_room;

    char_from_room( d.character );
    char_to_room( d.character, ch->in_room);
  }

  act("You pull $N from the void.",ch,NULL,d.character,TO_CHAR);

  act( "$n pulls $N from the void.",
        ch, NULL, d.character, TO_ROOM );

  if (d.character->pet != NULL)
   {
     char_to_room(d.character->pet,d.character->in_room);
     act("$n has entered the game.",d.character->pet,NULL,NULL,TO_ROOM);
   }

} /* end do_pload */


void do_punload( Character *ch, char *argument )
{
  Character *victim;
  char who[MAX_INPUT_LENGTH];

  argument = one_argument(argument, who);

  if ( ( victim = get_char_ooc( ch, who ) ) == NULL )
  {
    send_to_char( "They aren't here.\n\r", ch );
    return;
  }

  /** Person is legitimatly logged on... was not ploaded.
    * Can also be used to log out link-dead chars
    */
  if (victim->desc != NULL)
  {
    send_to_char("That player was not pulled.\n\r", ch);
    return;
  }

  if (victim->was_in_room != NULL) /* return player and pet to orig room */
  {
    char_from_room(victim);
    char_to_room(victim, victim->was_in_room);

    if (victim->pet != NULL)
    {
      char_from_room( victim->pet );
      char_to_room(victim->pet, victim->was_in_room);
    }

    victim->was_in_room = NULL;
  }

  act("You release $N to the void.",
       ch, NULL, victim, TO_CHAR);
  act("$n releases $N to the void.",
       ch, NULL, victim, TO_ROOM);

  do_quit(victim,"");
}

void do_rtlist( Character *ch, char *arg )
{//Find each RT leader, and list their tables
    Descriptor *d;
	Character *victim, *walker;
	if(arg[0] == '\0')
	{
		cprintf(ch, "usage: rtlist all     (displays the tables)\n\r"
					"       rtlist members (displays all tables with members)\n\r"
					"       rtlist <char>  (displays members of char's table)\n\r");
		return;
	}

	if(!str_prefix(arg, "all") || !str_prefix(arg, "members"))
	{
		for ( d = descriptor_list; d != NULL; d = d->next )
		{
			victim = d->original ? d->original : d->character;

			if ( !victim )
				continue;
			else
			if ( victim->shapeshifted )
				victim = victim->shapeshifted;
			if(victim->pcdata->rtptrs.handler && victim->pcdata->rtptrs.handler->leader == victim)
			{//Leader found, list them and members
				act_ooc("(Round table leader): $N", ch, NULL, victim, TO_CHAR, POS_SLEEPING,TRUE );
				if(!str_prefix(arg, "members"))
				{
					if(victim->pcdata->rtptrs.nextChar != victim)
					{
						cprintf(ch, "This table has the following members:\n\r");
						for(walker = victim->pcdata->rtptrs.nextChar; walker != victim; walker=walker->pcdata->rtptrs.nextChar)
						{
							act_ooc("$N", ch, NULL, walker, TO_CHAR, POS_SLEEPING,TRUE );
						}
						cprintf(ch, "\n\r");
					}
				}
			}
		}
		return;
	}

	if ( (victim =get_char_ooc(ch,arg)) == NULL || IS_NPC(victim))
	{
		cprintf(ch,"%s is not on-line.\n\r", victim->name);
		return;
	}

	if(!victim->pcdata->rtptrs.handler)
	{
		cprintf(ch,"%s is not in a round table.\n\r", victim->name);
		return;
	}

	act_ooc("(Round table leader): $N", ch, NULL, victim->pcdata->rtptrs.handler->leader, TO_CHAR, POS_SLEEPING,TRUE );
	if(victim->pcdata->rtptrs.nextChar != victim)
	{
		cprintf(ch, "This table has the following members:\n\r");
		for(walker = victim->pcdata->rtptrs.nextChar; walker != victim; walker=walker->pcdata->rtptrs.nextChar)
		{
			act_ooc("$N", ch, NULL, walker, TO_CHAR, POS_SLEEPING,TRUE );
		}
	}
	cprintf(ch, "\n\r");//spacing
	
}

void do_openvnum( Character *ch, char *argument )
{
	char    arg1[MAX_INPUT_LENGTH];
	Area *pArea;
	int vnum = 0;

	argument = one_argument( argument, arg1 );

	if ( arg1[0] == '\0' ||
		argument[0] == '\0' )
	{
		send_to_char("Syntax: openvnum <room|mob|obj> <area_vnum>\n\r", ch);
		return;
	}

	if ( !is_number(argument) )
	{
		do_openvnum(ch,"");
		return;
	}

	vnum = atoi(argument);

	/* get area vnum */
	for( pArea = area_first; pArea; pArea = pArea->next )
		if(pArea->vnum == vnum)
			break;

	if (!pArea)
	{
		send_to_char("No such area (double check the area list).\n\r", ch);
		return;
	}


	if ( !str_cmp( arg1, "room" ) )
	{

		do_openvnum_room(ch, pArea->lvnum, pArea->uvnum );
		return;
	}

	if ( !str_cmp( arg1, "obj" ) )
	{
		do_openvnum_obj (ch, pArea->lvnum, pArea->uvnum );
		return;
	}

	if ( !str_cmp( arg1, "mob" ) )
	{
		do_openvnum_mob(ch, pArea->lvnum, pArea->uvnum );
		return;
	}
	do_openvnum(ch,"");
}

void do_openvnum_mob( Character *ch, int lvalue, int hvalue )
{
	char buf[MAX_INPUT_LENGTH];
	int i;
	int fGap; 
	int tUsed = 0, tAvail = 0;

	send_to_char("\n\rMob Vnum Usage\n\r",ch);
	send_to_char("--------------\n\r",ch);
/* cheap way to space header line */
	sprintf(buf,"%4s%13s%15s%13s\n\r", " ", "&CUsed", " ", "&RAvailable");
	send_to_char(buf,ch);
/* Prime stats and get beginning of report set up */
	if (get_mob_index(lvalue) != NULL)
	{
		sprintf(buf,"    &W%5d &x-" ,lvalue);
		fGap = FALSE;
	}
	else
	{
		sprintf(buf, "                                &W%5d &x-",lvalue);
		fGap = TRUE;
	}       
	send_to_char(buf,ch);

	for ( i = lvalue ; i < hvalue ; i++ )
		if ( get_mob_index(i) != NULL )
		{
			if (!fGap) { tUsed++; continue; }
			else
			{
				sprintf(buf," &W%5d\n\r    %5d &x-", i-1, i);
				send_to_char(buf,ch);
				tAvail++;
				fGap = FALSE;
			}
		}
		else
		{
			if (fGap) { tAvail++; continue; }
			else
			{
				sprintf(buf," &W%5d               %5d &x-",
					i-1, i);
				send_to_char(buf,ch);
				tUsed++;
				fGap = TRUE;
			}
		}
	if (get_mob_index(hvalue) != NULL )
	{
		if (!fGap)
		{
			tUsed++;
			sprintf(buf," &W%5d\n\r",hvalue);
		}       
		else  
		{ 
			sprintf(buf," &W%5d\n\r    %5d\n\r",hvalue-1,hvalue);
			tAvail++;
		}
	}
	else
	{
		if(fGap) 
		{
			tAvail++;
			sprintf(buf," &W%5d\n\r",hvalue);
		}       
		else
		{
			sprintf(buf," &W%5d               %5d\n\r",
				hvalue-1,hvalue);
			tUsed++;
		}
	}
	send_to_char(buf,ch);
	sprintf(buf,"&WTotals&x:&G%10d%15s%13d&W&x\n\r",  tUsed,"",tAvail);
	send_to_char(buf,ch);
}

void do_openvnum_obj( Character *ch, int lvalue, int hvalue )
{
	char buf[MAX_INPUT_LENGTH];
	int i;
	int fGap; 
	int tUsed = 0, tAvail = 0;

	send_to_char("\n\rObject Vnum Usage\n\r",ch);
	send_to_char("-----------------\n\r",ch);
	sprintf(buf,"%4s%13s%15s%13s\n\r", " ", "&CUsed", " ", "&RAvailable");
	send_to_char(buf,ch);
/* Prime stats and get beginning of report set up */
	if (get_obj_index(lvalue) != NULL)
	{
		sprintf(buf,"    &W%5d &x-" ,lvalue);
		fGap = FALSE;
	}
	else
	{
		sprintf(buf, "                                &W%5d &x-",lvalue);
		fGap = TRUE;
	}       
	send_to_char(buf,ch);

	for ( i = lvalue ; i < hvalue ; i++ )
		if ( get_obj_index(i) != NULL )
		{
			if (!fGap) { tUsed++; continue; }
			else
			{
				sprintf(buf," &W%5d\n\r    %5d &x-", i-1, i);
				send_to_char(buf,ch);
				tAvail++;
				fGap = FALSE;
			}
		}
		else
		{
			if (fGap) { tAvail++; continue; }
			else
			{
				sprintf(buf," &W%5d               %5d &x-",
					i-1, i);
				send_to_char(buf,ch);
				tUsed++;
				fGap = TRUE;
			}
		}
	if (get_obj_index(hvalue) != NULL )
	{
		if (!fGap)
		{
			tUsed++;
			sprintf(buf," &W%5d\n\r",hvalue);
		}       
		else  
		{ 
			sprintf(buf," &W%5d\n\r    %5d\n\r",hvalue-1,hvalue);
			tAvail++;
		}
	}
	else
	{
		if(fGap) 
		{
			tAvail++;
			sprintf(buf," &W%5d\n\r",hvalue);
		}       
		else
		{
			sprintf(buf," &W%5d               %5d\n\r",
				hvalue-1,hvalue);
			tUsed++;
		}
	}
	send_to_char(buf,ch);
	sprintf(buf,"&WTotals&x:&G%10d%15s%13d&W&x\n\r",  tUsed,"",tAvail);
	send_to_char(buf,ch);
}

void do_openvnum_room( Character *ch, int lvalue, int hvalue )
{
	char buf[MAX_INPUT_LENGTH];
	int i;
	int fGap; 
	int tUsed = 0, tAvail = 0;

	send_to_char("\n\rRoom Vnum Usage\n\r", ch);
	send_to_char("---------------\n\r",ch);
/* cheap way to space header line */
	sprintf(buf,"%4s%13s%15s%13s\n\r", " ", "&CUsed", " ", "&RAvailable");
	send_to_char(buf,ch);
/* Prime stats and get beginning of report set up */
	if (get_room_index(lvalue) != NULL)
	{
		sprintf(buf,"    &W%5d &x-" ,lvalue);
		fGap = FALSE;
	}
	else
	{
		sprintf(buf, "                                &W%5d &x-",lvalue);
		fGap = TRUE;
	}       
	send_to_char(buf,ch);

	for ( i = lvalue ; i < hvalue ; i++ )
		if ( get_room_index(i) != NULL )
		{
			if (!fGap) { tUsed++; continue; }
			else
			{
				sprintf(buf," &W%5d\n\r    %5d &x-", i-1, i);
				send_to_char(buf,ch);
				tAvail++;
				fGap = FALSE;
			}
		}
		else
		{
			if (fGap) { tAvail++; continue; }
			else
			{
				sprintf(buf," &W%5d               %5d &x-",
					i-1, i);
				send_to_char(buf,ch);
				tUsed++;
				fGap = TRUE;
			}
		}
	if (get_room_index(hvalue) != NULL )
	{
		if (!fGap)
		{
			tUsed++;
			sprintf(buf," &W%5d\n\r",hvalue);
		}       
		else  
		{ 
			sprintf(buf," &W%5d\n\r    %5d\n\r",hvalue-1,hvalue);
			tAvail++;
		}
	}
	else
	{
		if(fGap) 
		{
			tAvail++;
			sprintf(buf," &W%5d\n\r",hvalue);
		}       
		else
		{
			sprintf(buf," &W%5d               %5d\n\r",
				hvalue-1,hvalue);
			tUsed++;
		}
	}
	send_to_char(buf,ch);
	sprintf(buf,"&WTotals&x:&G%10d%15s%13d&W&x\n\r",  tUsed,"",tAvail);
	send_to_char(buf,ch);
}

void do_arealist( Character *ch, char *argument )
{
	char arg[MAX_INPUT_LENGTH*4];

	argument = one_argument(argument,arg);

	if (arg[0] == '\0' )
	{
		cprintf(ch, "Syntax: arealist <field> <area>\n\r");
		cprintf(ch, " Field being one of: room mob obj rec quest door find\n\r");
		return;
	}

	if (!str_cmp(arg,"room"))
	{
		do_rarealist(ch,argument);
		return;
	}
	if (!str_cmp(arg,"obj"))
	{
		do_oarealist(ch,argument);
		return;
	}
	if (!str_cmp(arg,"mob"))
	{
		do_marealist(ch,argument);
		return;
	}
	if (!str_cmp(arg,"rec"))
	{
		do_tsarealist(ch,argument);
		return;
	}
	if ( !str_cmp(arg,"quest"))
	{
		do_qarealist(ch,argument);
		return;
	}
	if ( !str_cmp(arg, "door"))
	{
		do_darealist(ch,argument);
		return;
	}
	if( !str_cmp(arg, "find"))
	{
		do_farealist(ch,argument);
		return;
	}
	do_arealist(ch,"");
}

void do_rarealist(Character *ch, char *argument)
{
	Area *pArea;
	char arg[MAX_INPUT_LENGTH];
	Room *room;
	int vnum, i;
	Buffer *output;

	one_argument(argument,arg);

	if(!is_number(arg))
	{
		cprintf(ch, "Area vnum must be numeric.\n\r");
		return;
	}

	vnum = atoi(arg);

	for( pArea = area_first; pArea; pArea = pArea->next )
		if(pArea->vnum == vnum)
			break;
	
	if (!pArea)
	{
		cprintf(ch, "No such area.\n\r");
		return;
	}

	output = new_buf();
	for ( i = pArea->lvnum ; i <= pArea->uvnum; i++ )
	{
		if((room=get_room_index(i)) == NULL)
			continue;
	 	bprintf(output,"&x[&gv&g%d&x] %s\n\r", room->vnum,room->name);
	}
	page_to_char( buf_string(output), ch );
	free_buf(output);
	return; 
}

void do_darealist( Character *ch, char *argument )
{
	Area *pArea;
	char arg[MAX_INPUT_LENGTH];
	Room *room;
	int vnum, i, j;
	Buffer *output;
	bool fFound = FALSE;

	one_argument(argument,arg);

	if(!is_number(arg))
	{
		cprintf(ch, "Area vnum must be numeric.\n\r");
		return;
	}

	vnum = atoi(arg);

	for( pArea = area_first; pArea; pArea = pArea->next )
		if(pArea->vnum == vnum)
			break;
	
	if (!pArea)
	{
		cprintf(ch, "No such area.\n\r");
		return;
	}

	output = new_buf();
	for ( i = pArea->lvnum ; i <= pArea->uvnum; i++ )
	{
		Exit *pexit;
		if((room=get_room_index(i)) == NULL)
			continue;
		for(j = 0; j<6; j++)
		{
			if ( ( ( pexit = room->exit[j] ) != NULL &&
	 			 pexit->u1.to_room != NULL))
			{
				if( !IS_SET(pexit->exit_info, EX_ISDOOR))
					continue;
				fFound = TRUE;
				bprintf(output,"&x[&gv&g%d&x]", room->vnum);
				if(pexit->keyword[0] != '\0')
					bprintf(output, " %s", pexit->keyword);
				else
					bprintf(output, " no keyword");
				if ( IS_SET(pexit->exit_info, EX_CLOSED))
					bprintf(output, ", closed");
				if ( IS_SET(pexit->exit_info, EX_LOCKED))
					bprintf(output, ", locked");
				if ( IS_SET(pexit->exit_info, EX_PICKPROOF))
					bprintf(output, ", pickproof");
				if ( IS_SET(pexit->exit_info, EX_NOPASS))
					bprintf(output, ", nopass");
				if ( IS_SET(pexit->exit_info, EX_SIMPLE))
					bprintf(output, ", diff: Simple");
				if ( IS_SET(pexit->exit_info, EX_EASY))
					bprintf(output, ", diff: Easy");
				if ( IS_SET(pexit->exit_info, EX_AVERAGE))
					bprintf(output, ", diff: Average");
				if ( IS_SET(pexit->exit_info, EX_DIFFICULT))
					bprintf(output, ", diff: Difficult");
				if ( IS_SET(pexit->exit_info, EX_HARD))
					bprintf(output, ", diff: Hard");
				if ( IS_SET(pexit->exit_info, EX_INFURIATING))
					bprintf(output, ", diff: Infuriating");
				if ( IS_SET(pexit->exit_info, EX_NOCLOSE))
					bprintf(output, ", noclose");
				if ( IS_SET(pexit->exit_info, EX_NOLOCK))
					bprintf(output, ", nolock");
				if ( IS_SET(pexit->exit_info, EX_HOLD_PORTAL))
					bprintf(output, ", holdportal");
				if ( IS_SET(pexit->exit_info, EX_HIDDEN))
					bprintf(output, ", hidden");
				bprintf(output, "\n\r");
			}
		}
	}
	if(!fFound)
		bprintf(output, "No doors found for that area.\n\r");
	page_to_char( buf_string(output), ch );
	free_buf(output);
	return; 
}

void do_oarealist( Character *ch, char *argument )
{
	Area *pArea;
	char arg[MAX_INPUT_LENGTH];
	sh_int vnum, i;
	ObjIndex *pObjIndex; 
	Buffer *output;
	bool fCheckValue = FALSE;

	argument = one_argument(argument,arg);

	if (!is_number(arg))
	{
		cprintf(ch, "Area vnum must be numeric.\n\r");
		return;
	}

	vnum = atoi(arg);

	for (pArea = area_first; pArea; pArea = pArea->next )
		if (vnum == pArea->vnum)
			break;

	if(!pArea)
	{
		cprintf(ch, "No such area.\n\r");
		return;
	}

	// give it 8K to work with
	output = new_buf_size( 2<<13 );

	one_argument(argument,arg);

	if(!strcmp(arg, "value"))
	{
		fCheckValue = TRUE;
	}
	else if(arg[0] != '\0')
	{
		cprintf(ch, "Usage: vlist obj <areanum>\n\r"
					"       vlist obj <areanum> value (Lists objects over standard value for level)\n\r");
		return;
	}

	for( i = pArea->lvnum; i <= pArea->uvnum; i++ )
	{
	   if((pObjIndex=get_obj_index(i))==NULL)
		continue;
		if(!fCheckValue || pObjIndex->cost > pObjIndex->level * pObjIndex->level)
		{
		    bprintf(output,"&x[&gv&g%d&x] [%2d] %s", 
				pObjIndex->vnum, 
				pObjIndex->level,
				pObjIndex->short_descr); 
			if(fCheckValue)
				bprintf(output," %d over.\n\r", pObjIndex->cost - pObjIndex->level * pObjIndex->level);
			else
				bprintf(output,"\n\r");
		}
	}
	page_to_char( buf_string(output), ch );
	free_buf(output);
	return;    
}

void do_qarealist( Character *ch, char *argument )
{
	Area *pArea;
	char arg[MAX_INPUT_LENGTH];
	sh_int vnum, i;
	Quest *q;
	Buffer *output;
	one_argument(argument,arg);

	if(!is_number(arg))
	{
		cprintf(ch, "Area vnum must be numeric.\n\r");
		return;
	}

	vnum = atoi(arg);

	for(pArea=area_first; pArea; pArea = pArea->next)
		if (vnum == pArea->vnum)
			break;

	if(!pArea)
	{
		cprintf(ch, "No such area.\n\r");
		return;
	}

	output = new_buf( );
	for( i = pArea->lvnum; i<= pArea->uvnum; i++)
	{
	    if ((q=get_quest_index(i))==NULL)
		continue;
	    bprintf(output,"&x[&gv&g%d&x] [%2d-%2d] %s\n\r", 
			q->vnum,
			q->min_level, q->max_level,
			q->name);
	}
	page_to_char( buf_string(output), ch );
	free_buf(output);
	return;
}

void do_tsarealist( Character *ch, char *argument )
{
	Area *pArea;
	char arg[MAX_INPUT_LENGTH];
	sh_int vnum, i;
	Recipe *rec;
	Buffer *output;
	one_argument(argument,arg);

	if(!is_number(arg))
	{
		cprintf(ch, "Area vnum must be numeric.\n\r");
		return;
	}

	vnum = atoi(arg);

	for(pArea=area_first; pArea; pArea = pArea->next)
		if (vnum == pArea->vnum)
			break;

	if(!pArea)
	{
		cprintf(ch, "No such area.\n\r");
		return;
	}

	output = new_buf( );
	for( i = pArea->lvnum; i<= pArea->uvnum; i++)
	{
	    if ((rec=get_recipe_index(i))==NULL)
		continue;
	    bprintf(output,"&x[&gv&g%d&x] [%2d] %s\n\r", 
			rec->vnum,
			rec->difficulty,
			rec->name);
	}
	page_to_char( buf_string(output), ch );
	free_buf(output);
	return;
}

void do_marealist( Character *ch, char *argument )
{
	Area *pArea;
	char arg[MAX_INPUT_LENGTH];
	sh_int vnum, i;
	MobIndex *pMobIndex;
	Buffer *output;
	one_argument(argument,arg);

	if(!is_number(arg))
	{
		cprintf(ch, "Area vnum must be numeric.\n\r");
		return;
	}

	vnum = atoi(arg);

	for(pArea=area_first; pArea; pArea = pArea->next)
		if (vnum == pArea->vnum)
			break;

	if(!pArea)
	{
		cprintf(ch, "No such area.\n\r");
		return;
	}

	output = new_buf( );
	for( i = pArea->lvnum; i<= pArea->uvnum; i++)
	{
		int averageHit;//This will sit here until a standard value is available in code
	    if ((pMobIndex=get_mob_index(i))==NULL)
		continue;
		averageHit = (pMobIndex->hit[DICE_TYPE] + 1) * pMobIndex->hit[DICE_NUMBER] / 2 + pMobIndex->hit[DICE_BONUS];
	    bprintf(output,"&x[&gv&g%d&x] [%2d] %s\n\r", 
			pMobIndex->vnum,
			pMobIndex->level,
			pMobIndex->short_descr);
	}
	page_to_char( buf_string(output), ch );
	free_buf(output);
	return;
}

void areaSearchObjSpawn(Character *ch, char *argument, Buffer *output, Spawn *spawn, int vnum, Room *room)
{//specialized function, searches through a spawn tree recursing, looking for a vnum
	ObjIndex	*pObj;
	Spawn *s;
	for( s = spawn ; s != NULL ; s = s->next_in_room )
	{
		switch(s->type)
		{
			case 'o': case 'O':
			case 'e': case 'E':
			case 'i': case 'I':
			case 'p': case 'P':
			case 'c': case 'C':
				if ( (pObj = get_obj_index( s->source )) == NULL )
					cprintf(ch,"[%5d] <broken>\n\r", s->source );
				else
				{
					if(pObj->vnum == vnum)
						bprintf(output, "%d%% chance of appearing in room %d.\n\r", s->frequency, room->vnum);
					else if(s->placeholder == vnum)
						bprintf(output, "%d%% chance of appearing in room %d.\n\r", 100 - s->frequency, room->vnum);
				}
				break;
		}
		areaSearchObjSpawn(ch, argument, output, s->contains, vnum, room);
		areaSearchObjSpawn(ch, argument, output, s->next_content, vnum, room);
	}
//for( s = spawn ; s != NULL ; s = s->next_content )
//s->contains
}

void areaFindVnum(Character *ch, char *argument, Buffer *output, Area *pArea, int vnum, bool fObj, bool fMob)
{//This is a local function so that the section of code only has to be done once, instead of twice
//other bools can be added as more search functionality is designed
	sh_int i;
	Spawn *s;
	Room *room;
	for( i = pArea->lvnum; i<= pArea->uvnum; i++)
	{
		if(fMob)
		{//Mobs just list the rooms and odds of appearing. What else is there?
			MobIndex	*pMob;
			if((room=get_room_index(i)) == NULL)
				continue;
			s = room->spawns;
			if(s == NULL)
				continue;
//	 		bprintf(output,"&x[&gv&g%d&x] %s\n\r", room->vnum,room->name);
			for( ; s != NULL ; s = s->next_in_room )
			{//In here because the object spawn search does this itself
				if(s->type == 'm' || s->type == 'M')
				{
					if ( (pMob = get_mob_index( s->source )) == NULL )
						bprintf(output,"[%5d] <broken>\n\r", s->source );
					else
					{
						if(pMob->vnum == vnum)
							bprintf(output, "%d%% chance of appearing in room %d.\n\r", s->frequency, room->vnum);
						else if(s->placeholder == vnum)
							bprintf(output, "%d%% chance of appearing in room %d.\n\r", 100 - s->frequency, room->vnum);
					}
				}
			}
		}
		else if(fObj)
		{
			Recipe *pRec;
			Quest *pQuest;
			if ((pRec = get_recipe_index(i)) != NULL)
			{
				int j;
				for(j = 0; j < MAX_INGREDIENT; j++)
					if(pRec->components[j] == vnum)
						bprintf(output, "Component %d in recipe %d.\n\r", j, i);
				if(pRec->result_vnum == vnum)
					bprintf(output, "Success result in recipe %d.\n\r", i);
				if(pRec->fail_vnum == vnum)
					bprintf(output, "Fail result in recipe %d.\n\r", i);
			}
			if ((pQuest = get_quest_index( i )) != NULL)
			{
				int j;
				for(j = 0; j < MAX_INGREDIENT; j++)
					if(pQuest->required[j] == vnum)
						bprintf(output, "Requirement %d in quest %d.\n\r", j, i);
				if(pQuest->reward_vnum == vnum)
					bprintf(output, "Reward for quest %d.\n\r", i);
			}
			if((room=get_room_index(i)) == NULL)
				continue;//has to be after recipes, because recipes aren't connected to rooms
			s = room->spawns;
			if(s == NULL)
				continue;
			areaSearchObjSpawn(ch, argument, output, s, vnum, room);
			//search recipes and quests as well
		}
	}
}

void do_farealist(Character *ch, char *argument)
{//find arealist

	Area *pArea;
	char arg[MAX_INPUT_LENGTH];
	sh_int avnum, vnum, i;
//	MobIndex *pMobIndex;
	Buffer *output;
	bool fAll = FALSE;
	bool fMob = FALSE;
	bool fObj = FALSE;

	pArea = NULL;

	argument = one_argument(argument,arg);

	if(!is_number(arg))
	{
		if(!strcmp(arg, "all"))
			fAll = TRUE;
		else
		{
			cprintf(ch, "Area vnum must be numeric, or 'all'.\n\r");
			return;
		}
	}

	if(!fAll)
	{
		avnum = atoi(arg);

		for(pArea=area_first; pArea; pArea = pArea->next)
			if (avnum == pArea->vnum)
				break;

		if(!pArea)
		{
			cprintf(ch, "No such area.\n\r");
			return;
		}
	}

	argument = one_argument(argument, arg);

	if(!strcmp(arg, "mob"))
		fMob = TRUE;
	else if(!strcmp(arg, "obj"))
		fObj = TRUE;
	else
	{
		cprintf(ch, "Usage: vlist find <area num/all> mob <vnum>\n\r"
				    "       vlist find <area num/all> obj <vnum>\n\r"
					"       Please be careful with all as it involves a large search.\n\r");
		return;
	}

	one_argument(argument, arg);

	if(!is_number(arg))
	{
		cprintf(ch, "Usage: vlist find <area num/all> mob <vnum>\n\r"
				    "       vlist find <area num/all> obj <vnum>\n\r"
					"       Please be careful with all as it involves a large search.\n\r");
		return;
	}

	vnum = atoi(arg);
	
	if(fMob)
		if (!get_mob_index( vnum ))
		{
			cprintf(ch, "Mob %d does not exist.\n\r", vnum);
			return;
		}

	if(fObj)
		if (!get_obj_index( vnum ))
		{
			cprintf(ch, "Obj %d does not exist.\n\r", vnum);
			return;
		}

	output = new_buf( );
	if(fAll)
	{
		for ( i = 0 ; i < 100000 ; i += 100 )
		{
			for ( pArea = area_first; pArea; pArea = pArea->next )
			{
				if ( pArea->lvnum < i && !pArea->shown )
				{
					pArea->shown = TRUE;
					areaFindVnum(ch, argument, output, pArea, vnum, fObj, fMob);
				}
				else if ( pArea->lvnum >= i )
				pArea->shown = FALSE;
			}
		}
	}
	else
		areaFindVnum(ch, argument, output, pArea, vnum, fObj, fMob);
	page_to_char( buf_string(output), ch );
	free_buf(output);

}

void do_average( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    bool fTotal = FALSE;
    ObjIndex	*obj;
    int i;
	float	total_damage = 0;
	long	total_weapons = 0;

    argument = one_argument( argument, arg );

    if ( arg[0] == '\0' || !is_number(arg) )
    {
	cprintf(ch,"Usage:  average <level>\n\r",
                   "        average <level> total\n\r");
  	return;
    }

    if ( argument[0] != '\0' && !str_cmp(argument,"total") )
	fTotal = TRUE;

    for ( i=1 ; i < 35000 ; i++ )
    {
		if ( (obj = get_obj_index(i) ) == NULL || obj->level != atoi(arg) || obj->item_type != ITEM_WEAPON )
			continue;

		total_damage += getDPS(obj->value[1],obj->value[2],obj->value[5]);
		++total_weapons;

		if ( !fTotal )
	    	cprintf(ch,"vnum %5d %-35s %dd%d, delay %d.%d, dam/sec %f\n\r",
				obj->vnum, obj->short_descr, obj->value[1], obj->value[2],
				obj->value[5]/10, obj->value[5]%10,
				getDPS( obj->value[1],obj->value[2],obj->value[5] ) );

    }

    cprintf(ch,"\n\rLevel %d weapon total dam/sec ratio: %f.\n\r",	
					atoi(arg), total_damage / (float) total_weapons );
    return;
}

void do_rename ( Character* ch, char* argument )
{
    char old_name[MAX_INPUT_LENGTH];
    char new_name[MAX_INPUT_LENGTH];
    char strsave [MAX_INPUT_LENGTH];

    Character* victim;
    FILE* file;

    argument = one_argument_cs( argument, old_name );
    one_argument_cs( argument, new_name );

    if (!old_name[0])
    {
        cprintf (ch, "Rename who?\n\r");
        return;
    }

    if ( ( victim = get_char_ooc (ch, old_name) ) == NULL || IS_NPC(victim) )
    {
        cprintf (ch, "There is no such person online.\n\r");
        return;
    }

    if ( (victim != ch) && (get_trust (victim) >= get_trust (ch)) )
    {
        cprintf (ch, "You failed.\n\r");
        return;
    }

    if (!victim->desc || (victim->desc->connected != CON_PLAYING) )
    {
        cprintf (ch, "Player has no active descriptor.\n\r");
        return;
    }

    if (!new_name[0])
    {
        cprintf (ch, "Rename to what new name?\n\r");
        return;
    }

    if (!check_parse_name(new_name) || !check_being_created_name(new_name))
    {
        cprintf (ch, "The new name is illegal.\n\r");
        return;
    }

    sprintf( strsave, "%s%s", getDirectory(PLAYER_DIR), capitalize( new_name ) );

    fclose (fpReserve);
    file = fopen (strsave, "r");
    if (file)
    {
        cprintf (ch, "A player with that name already exists!\n\r");
        fclose (file);
        fpReserve = fopen( NULL_FILE, "r" );
        return;
    }

    fpReserve = fopen( NULL_FILE, "r" );  /* reopen the extra file */

    if (get_char_ooc(ch,new_name)) /* check for playing level-1 non-saved */
    {
        cprintf (ch, "A player with the name you specified already exists!\n\r");
        return;
    }

    /* Save the filename of the old name */

    sprintf( strsave, "%s%s", getDirectory(PLAYER_DIR), capitalize( victim->name ) );

    /* Rename the character and save him to a new file */
    /* NOTE: Players who are level 1 do NOT get saved under a new name */

    free_string (victim->name);
    new_name[0] = UPPER(new_name[0]);
    victim->name = str_dup (new_name);

    save_char_obj (victim);

    /* unlink the old file */
    unlink (strsave); /* unlink does return a value.. but we do not care */

    /* That's it! */

    cprintf (ch, "Character renamed.\n\r");

    victim->position = POS_STANDING; /* I am laaazy */

    act("$n has renamed you to $N!",ch,NULL,victim,TO_VICT);
}

void dummy2( Character *ch, char *argument )
{
	Buffer	*buf;
    ObjIndex *pObjIndex;
	int vnum;

	buf = new_buf( );
    for ( vnum = 13900; vnum < 20000; vnum++ )
	{
    	if ( ( pObjIndex = get_obj_index( vnum ) ) != NULL && pObjIndex->item_type == ITEM_ARMOR )
		{
        	bprintf( buf, "[%5d] [%2d] [%s] %s\n\r",
            	pObjIndex->vnum, pObjIndex->level, 
				pObjIndex->value[5] < 0 || pObjIndex->value[5] > 8 ? "unknown" :
				armor_table[pObjIndex->value[5]].name,
				pObjIndex->short_descr );
		}
	}
	page_to_char( buf_string(buf), ch );
	free_buf( buf );
	return;
}

void dummy( Character *ch, char *argument )
{
	Buffer	*buf;
    ObjIndex *pObjIndex;
	int vnum;

	buf = new_buf( );
    for ( vnum = 10000; vnum < 35000; vnum++ )
    if ( ( pObjIndex = get_obj_index( vnum ) ) != NULL &&
		   pObjIndex->item_type == ITEM_WEAPON &&
		   ( pObjIndex->value[0] == WEAPON_EXOTIC || *argument == 'a') )
	{
        bprintf( buf, "[%5d] [%2d] [%s] %s\n\r",
            pObjIndex->vnum, pObjIndex->level, 
			weapon_name( pObjIndex->value[0] ), pObjIndex->short_descr );
	}

	page_to_char( buf_string(buf), ch );
	free_buf( buf );
	return;
}

#define lprint(name)	limshow(ch,#name,name)
static void limshow(Character *ch,char *name,int resource)
{
	struct rlimit	limit;

	if ( getrlimit(resource,&limit) < 0)
	{
		log_string("Error retrieving resource limits for %s: %s\n",
			name, strerror(errno) );
		return;
	}

	cprintf(ch,"%-14s    ",name);
	if (limit.rlim_cur == RLIM_INFINITY)
		cprintf(ch,"(unlimited)   ");
	else
		cprintf(ch,"%10ld   ", limit.rlim_cur);
	if (limit.rlim_max == RLIM_INFINITY)
		cprintf(ch,"(unlimited)\n\r");
	else
		cprintf(ch,"%10ld\n\r",limit.rlim_max);

	return;
}

void do_limits( Character *ch, char *argument )
{
	cprintf(ch,"%-14s  %-10s  %-10s\n\r","Limit","Soft","Hard");
	lprint(RLIMIT_CORE);
	lprint(RLIMIT_CPU);
	lprint(RLIMIT_DATA);
	lprint(RLIMIT_FSIZE);
	lprint(RLIMIT_MEMLOCK);
	lprint(RLIMIT_NOFILE);
#if defined( RLIMIT_OFILE )
	lprint(RLIMIT_OFILE);
#endif
	lprint(RLIMIT_NPROC);
	lprint(RLIMIT_RSS);
	lprint(RLIMIT_STACK);
}

void do_passwd( Character *ch, char *argument )
{
	Character *victim;
	char arg[MAX_STRING_LENGTH];
	char *pwdnew;
	char *p;

	argument = one_argument( argument, arg );

	if ( arg[0] == '\0' || *argument == '\0' )
	{
		cprintf(ch,"Usage: passwd <victim> <newpass|reset>\n\r");
		return;
	}

	if ( (victim = get_char_ooc(ch,arg)) == NULL )
	{
		cprintf(ch,"No such person logged on.\n\r");
		return;
	}

	if ( IS_NPC(victim) )
	{
		cprintf(ch,"Not on NPCs.\n\r");
		return;
	}

	if ( !str_cmp(argument,"reset") )
	{
		free_string(victim->pcdata->pwd);
		victim->pcdata->pwd = NULL;
		act("Password cleared for $N.",ch,NULL,victim,TO_CHAR);
		act("Your password has been cleared.",ch,NULL,victim,TO_VICT);
		save_char_obj(victim);
		return;
	}

    if ( strlen(argument) < 5 )
    {
		cprintf(ch,"Passwords must be at least 5 bytes.\n\r");
		return;
    }

    pwdnew = crypt( argument, ch->name );
    for ( p = pwdnew; *p != '\0'; p++ )
    {
        if ( *p == '~' )
        {
			cprintf(ch,"Passwords may not contain a tilde.\n\r");
        	return;
        }
    }

    free_string( victim->pcdata->pwd );
    victim->pcdata->pwd = str_dup( pwdnew );
	cprintf(ch,"Password for %s changed to '%s'.\n\r", victim->name, argument );
	cprintf(ch,"Your password has been changed to '%s'.\n\r", argument );
	save_char_obj(victim);
	return;
}

typedef struct lib_type Lib;
struct lib_type
{
	char *name;
	int level;
	int school;
	int cast_time;
};	

/* Sort functions */
int sortAlpha( const void *s1, const void *s2 )
{
	Lib *lib1 = (Lib *) s1;
	Lib *lib2 = (Lib *) s2;

	return strcmp(lib1->name,lib2->name);
}

int sortSchool( const void *s1, const void *s2 )
{
	Lib *lib1 = (Lib *) s1;
	Lib *lib2 = (Lib *) s2;

	return lib1->school - lib2->school;
}

int sortLevel( const void *s1, const void *s2 )
{
	Lib *lib1 = (Lib *) s1;
	Lib *lib2 = (Lib *) s2;

	return lib1->level - lib2->level;
}

void do_spell_stat(Character *ch, char *spell_name )
{
	int sn;
	int wait, redux;
	char color;
	SpellIndex* pSpellIndex;
    int i;

	if ( IS_NPC(ch) )
		return;

	if( (sn = spell_lookup( spell_name, -1 )) < 0 )
	{
		cprintf(ch,"No such spell.\n\r");
		return;
	}

	pSpellIndex = get_spell_index( sn );

	if ( !IS_IMMORTAL(ch) && !ch->pcdata->spells[pSpellIndex->vnum] )
	{
		cprintf(ch,"You don't know how to cast '%s'.\n\r", pSpellIndex->full_name );
		return;
	}

	cprintf(ch,"&WFull name&x:            %s\n\r", pSpellIndex->full_name );
	cprintf(ch,"&WLevel&x:                %d\n\r", pSpellIndex->class_level[ch->class] );
	cprintf(ch,"&WMana cost&x:            %d\n\r", pSpellIndex->base_mana );
	cprintf(ch,"&WBase casting time&x:    %d.%d\n\r",  pSpellIndex->beats / 10, pSpellIndex->beats % 10 );

    wait = pSpellIndex->beats;
    /* For every 5 points of dex over 125, you get a 1/10th second time reduction */
    redux = UMAX(0,(get_curr_stat(ch,STAT_DEX) - 100) / 5);
    redux = UMIN(redux,pSpellIndex->beats/3);
    wait = UMAX(PULSE_PER_SECOND*2,wait-redux);
	if ( redux == pSpellIndex->beats/3 )
		color = 'B';
	else
		color = 'W';

	cprintf(ch,"&WEffective cast time:&x  &%c%d.%d&x\n\r", color, wait / 10, wait % 10 );

    cprintf(ch,"&WSpell Affects&x:\n\r");
    for( i=0; i < 5; i++ )
    {
        switch( pSpellIndex->spell_type )
        {
            case SPELL_DEBUFF: case SPELL_BUFF:
                formatAffectDescription( ch, &(pSpellIndex->action.generic.affects[i]) ); break;
            default:
                continue;
        }
        //if ( pSpellIndex->affects[i].description != NULL )
            //cprintf(ch," * %s\n\r", pSpellIndex->affects[i].description);
    }

	return;
}

// Use a global space for this since malloc'ing on the fly is slow and
// giving us grief.
static Lib lib[MAX_SPELL];
void do_library( Character *ch, char *argument )
{
	char	arg[MAX_INPUT_LENGTH];
	int		class, i, index, totalSpells;
	int		(*sortFunction)( const void *, const void *);
	Buffer	*buf;
	char	test;
	int vnum;
	SpellIndex* pSpellIndex;

	argument = one_argument( argument, arg );

	if ( arg[0] == '\0' )
	{
		if ( IS_IMMORTAL(ch) )
			cprintf(ch,"Usage: library <class> [sort_type]\n\r"
                       "       library info <spell_name>\n\r");
		else
			cprintf(ch,"Usage: library [sort_type]\n\r"
                       "       library info <spell_name>\n\r");
		cprintf(ch,"  Valid sorts: alpha level school\n\r");
		return;
	}

	if ( !str_cmp(arg,"info") )
	{
		do_spell_stat(ch, argument );
		return;
	}

	/* Verify class */
	if ( !IS_IMMORTAL(ch) )
		class = ch->class;
	else
	if ( (class = class_lookup(arg)) < 0 )
	{
		cprintf(ch,"%s isn't a valid class.\n\r", arg );
		return;
	}

    /* Count how many spells we'll have */
    totalSpells = 0;

    for( vnum = 0; vnum < top_spell_index; vnum++ )
        if ( ( pSpellIndex = get_spell_index( vnum ) ) != NULL &&
         	   pSpellIndex->class_level[class] > 0 &&
               pSpellIndex->class_level[class] <= 51 )
            ++totalSpells;

    memset(&lib,0,sizeof(lib));

	/* OK, we've got it, fill it in */
	index = 0;
	for ( vnum = 0; vnum < top_spell_index; vnum++ )
	{
        if ( ( pSpellIndex = get_spell_index( vnum ) ) != NULL &&
               pSpellIndex->class_level[class] > 0 &&
               pSpellIndex->class_level[class] <= 51 )
		{
				lib[index].name = pSpellIndex->name;
				lib[index].level = pSpellIndex->class_level[class];
				lib[index].school = *(pSpellIndex->sgsn);
				lib[index].cast_time = pSpellIndex->beats;
				++index;
		}
	}

	/* Ok we've got the list, now we need to sort it */		
	if ( IS_IMMORTAL(ch) )
		test = *argument;
	else
		test = arg[0];

	switch( test )
	{
		default:
		case 'a': case 'A': case '\0':
			sortFunction = sortAlpha; break;
		case 'l': case 'L': 
			sortFunction = sortLevel; break;
		case 's': case 'S':
			sortFunction = sortSchool; break;
	}

	/* Sort it */
	qsort( (void *) lib, totalSpells, sizeof(Lib), sortFunction );

	/* and now display it */
	buf = new_buf( );

	for( i = 0 ; i < totalSpells ; i++ )
		bprintf(buf," * [%-28s] [%-2d] [%-12s] [%d.%ds]\n\r",
            lib[i].name,
            lib[i].level,
            skill_table[lib[i].school].name,
            lib[i].cast_time / 10,
            lib[i].cast_time % 10 );

	page_to_char( buf_string(buf), ch );
	free_buf( buf );
	memset(&lib,0,sizeof(lib));
	return;
}

/*
 * Command to re-exec the game and refresh the process image with the latest
 * version of the binary.
 */
void do_refres( Character *ch, char *argument )
{
	cprintf(ch,"If you want to refresh, type it out.\n\r");
	return;
}

void do_refresh( Character *ch, char *argument )
{
	extern	void initiate_refresh( void );
	int num, pulse;
	extern	int refresh_pulse;

	if ( *argument == '\0' )
	{
		cprintf(ch,"Syntax:  refresh now\n\r"
                   "         refresh [num]m\n\r"
                   "         refresh [num]s\n\r\n\r"
                   "Example: refresh 5m (refresh in 5 minutes)\n\r"
                   "         refresh 45s (refresh in 45 seconds)\n\r");
		return;
	}

	if ( !str_cmp( argument, "now" ) )
	{
		initiate_refresh( );
		cprintf(ch,"Refresh failed for %s: %s\n\r", BIN_IMAGE, strerror(errno) );
		return;
	}

	if ( !str_cmp(argument, "cancel" ) )
	{
		if ( refresh_pulse <= 0 )
		{
			cprintf(ch,"No refresh is pending.\n\r");
			return;
		}

		refresh_pulse = -1;
		cprintf(ch,"Refresh cancelled.\n\r");
		do_echo(ch,"&G[&WREFRESH&G]&x Refresh cancelled.");
		return;
	}

	num = atoi(argument);
	if ( num < 1 )
	{
		cprintf(ch,"You cannot give a negative amount of time.\n\r");
		return;
	}

	while( isdigit(*argument) )
		++argument;

	switch( *argument )
	{
		case 'm': case 'M':
			pulse = num * 60; break;
		case 's': case 'S':
			pulse = num; break;
		default:
			do_refresh(ch,""); return;
	}

	cprintf(ch,"We will refresh in %d %s%s.\n\r",
		num, UPPER(*argument) == 'M' ? "minute" : "second",
		num == 1 ? "" : "s" );
	refresh_pulse = pulse * PULSE_PER_SECOND + 1;
	return;
}

#define REFRESH_MESSAGE "A new version of the game is being loaded right now.  Please try back in a few minutes.\n\r"

#define REFRESH_STARTED "[REFRESH] THOC is loading the latest and greatest version of the MUD.  Please wait...\n\r"

void initiate_refresh( void )
{
	/* Save all descriptors to the refresh file */
	char port[MAX_STRING_LENGTH];
	extern void initiate_reboot( void );
	extern int webSocket;
	FILE *fp;
	Descriptor *d, *d_next;
	Character *ch;

	/* Restore all characters first */
    for (d = descriptor_list; d != NULL; d = d->next)
    {
		ch = d->character;

	    if (ch == NULL || IS_NPC(ch))
		continue;
                
        affect_strip(ch,gsn_plague);
        affect_strip(ch,gsn_poison);
        affect_strip(ch,gsn_blindness);
        affect_strip(ch,gsn_sleep);
        affect_strip(ch,gsn_curse);

        ch->base_hit       = ch->max_base_hit;
        ch->stat_hit       = max_stat_hit(ch);
        ch->stamina        = max_stamina(ch);
        ch->mana   = max_mana(ch);
        ch->move   = ch->max_move;
            
        update_pos(ch);

		write_to_descriptor(d->descriptor,"You have been restored.\n\r",0);
    }

	if ( (fp = fopen( REFRESH_FILE, "w" )) == NULL )
	{
		log_string("Unable to refresh - could not write refresh file: %s", strerror(errno) );
		/*initiate_reboot( );*/
	}

	/* Ok, the file's open and, presumable, empty.  Write out descriptors and characters.
 	*/

	save_clans( );
	save_vaults( );
	write_building_file( );

	fprintf(fp,"%d control no-host 0\n", global_control);

	for( d = descriptor_list ; d != NULL ; d = d_next )
	{
		d_next = d->next;

		if ( d->connected != CON_PLAYING )
		{
			write_to_descriptor(d->descriptor,REFRESH_MESSAGE,strlen(REFRESH_MESSAGE));
			close_socket( d );
			continue;
		}

		ch = d->original ? d->original : d->character;	
		save_char_obj(ch);
		write_to_descriptor(d->descriptor,REFRESH_STARTED,0);
		fprintf(fp,"%d %s %s %d\n", d->descriptor, ch->name, d->host, (d->mxp ? 1 : 0) );
	}

	fprintf(fp,"-1\n");
	fclose(fp);
	fclose(fpReserve);
	close(webSocket);

	snprintf(port,sizeof(port),"%d",global_port);
	execl(BIN_IMAGE,BIN_NAME,port,"refresh",(char *)NULL);

	perror("image refresh failed in execl");
    fpReserve = fopen( NULL_FILE, "r" );
	return;
}

void do_version( Character *ch, char *argument )
{
	cprintf(ch,"Version   : %s\n\r", print_version );
	cprintf(ch,"Port      : %s\n\r", 
#if defined(__ARPENS)
		"Live Server"
#elif defined(__OLC)
		"OLC Builder Server"
#elif defined(__TEST)
		"Test Server"
#else
		"Unknown Server Type"
#endif
	);

	return;
}

void do_petitio( Character *ch, char *argument )
{
	cprintf(ch,"To use petition, you must spell it out completely.\n\r");
	return;
}

void do_petition( Character *ch, char *argument )
{
	Character *victim;
	Descriptor *d;

	if ( *argument == '\0' )
	{
		cprintf(ch,"Syntax:  petition <message>\n\r");
		return;
	}

	cprintf(ch,"&R(&xPetition Sent&R)&x %s\n\r", argument );
	cprintf(ch," &C*&x Note that petitions cannot be turned off like a channel.  Thus, Admins are all\n\r"
               " &C*&x forced to see them all.  Spamming petitions is therefor a serious offense and\n\r"
   			   " &C*&x will not be tolerated.  Please use good judgment in deciding when and what to\n\r"
			   " &C*&x petition.  See 'help petition' for more information.\n\r" );

	for( d = descriptor_list ; d != NULL ; d = d->next )
	{
		if ( d->connected != CON_PLAYING )
			continue;
	
		victim = d->original ? d->original : d->character;
		if ( !IS_IMMORTAL(victim) )
			continue;

		cprintf(victim,"&R(&xPetition from %s&R)&x %s\n\r", ch->name, argument );
	}

	return;
}

void do_finger( Character *ch, char *argument )
{
  	Descriptor d;
  	bool isChar = FALSE;
  	char name[MAX_INPUT_LENGTH], buf[MAX_INPUT_LENGTH];
	Character *victim;
	struct stat	charstat;

  	if (argument[0] == '\0')
  	{
		cprintf(ch,"Syntax:  finger <full name of player>\n\r");
    	return;
  	}
	
  	argument[0] = UPPER(argument[0]);
  	argument = one_argument(argument, name);

  	if ( !(isChar = load_char_obj(&d, name)) )
  	{
    	cprintf(ch,"No such pfile (be sure to use the full name).\n\r");
    	return;
  	}

	victim = d.character;
	d.original = NULL;

	if ( victim->level <= 51 )
	{
		cprintf(ch,"%s is a %s level %d %s %s",
				victim->name, sex_table[victim->sex].name, victim->level,
				subrace_table[victim->pcdata->subrace].name,
				capitalize( class_table[victim->class].name) );
		if(victim->clan)
			cprintf(ch, " in the guild %s", capitalize(victim->clan->name));
		if((IS_IMMORTAL(ch) || ch->clan == victim->clan) && !clan_is_independent(ch->clan))
			cprintf(ch, " ranked %d.\n\r", victim->pcdata->guild_rank + 1);
		else
			cprintf(ch, ".\n\r");
	}
	else
		cprintf(ch,"%s is a member of the development team: %s (%d)\n\r",
				victim->name, rolename[victim->pcdata->imm_role], victim->level );

	if ( IS_IMMORTAL(ch) )
	{
		cprintf(ch,"Created at %s.\n\r",
    		format_date( victim->created, "%H:%M on %A, %d/%b/%Y") );
		cprintf(ch,"Played time: %d hour%s, %d minute%s.\n\r",
			victim->played / 3600, victim->played / 3600 == 1 ? "" : "s",
			victim->played % 3600 / 60, victim->played % 3600 / 60 == 1 ? "" : "s" );
	}

	if ( IS_SET(victim->act,PLR_TEAM_LEAD) )
		cprintf(ch," * This player is the Team Leader for the %s class.\n\r",
			capitalize( class_table[victim->class].name ) );

	snprintf(buf,sizeof(buf),"%s%s",getDirectory(PLAYER_DIR),capitalize(name));
    if ( stat( buf, &charstat ) < 0 )
    {
        cprintf(ch,"Unable to stat player file for %s.\n\r", buf );
        return;
    }

    cprintf(ch,"That character logged off at %s.\n\r",
         format_date( charstat.st_mtime, "%H:%M on %A, %d/%b/%Y") );
    if ( IS_IMMORTAL(ch) )
	{
        cprintf(ch,"Player file is %d bytes.\n\r", charstat.st_size);
		cprintf(ch,"Logged in from %s\n\r",
						victim->pcdata->host == NULL ? "<unknown>" :
							victim->pcdata->host );
	}

    victim->desc = NULL;
	free_char( victim );
	return;
}

void do_reward( Character *ch, char *argument )
{
	Character *victim;
	char arg[MAX_INPUT_LENGTH];
	int percent;

	argument = one_argument( argument, arg );

	if ( *argument == '\0' || arg[0] == '\0' )
	{
		cprintf(ch,"Syntax:  reward <player> <%% of XP to level>\n\r");
		return;
	}

	percent = atoi(argument);
	if ( percent <= 0 || percent > 100 )
	{
		cprintf(ch,"You must reward between and 1 and 100%.\n\r");
		return;
	}

	if ( !strcmp(arg,"all") )
	{
		DIR *dirp;
		struct dirent *direntp;

		if(ch->desc)
			write_to_descriptor(ch->desc->descriptor, "This may take a few moments...\n\r",0);

		dirp = opendir( getDirectory(PLAYER_DIR) );
 
		while ( (direntp = readdir( dirp )) != NULL )
		{
			if(str_infix(".",direntp->d_name))
			{
				Character *rch;
				victim = NULL;

				/* Player is connected */
				/* Find char, dont use get_char_ooc because that could
				   match an NPC */
				for ( rch = char_list; rch != NULL; rch = rch->next )
				{
					if(is_name(direntp->d_name,
						(!is_affected(rch,gsn_shapeshifting,AFF_SKILL) ? rch->name :
						rch->desc->original->name)) && !IS_NPC(rch))
					{
						victim = rch;
						if(!IS_IMMORTAL(victim))
							reward_player(ch, victim, percent, TRUE);
						break;
					}
				}

				/* Player isn't on, pull him from file */
				if(victim == NULL)
				{
					/* Load the char */
					bool isChar = FALSE;
					Descriptor d;

					isChar = load_char_obj(&d, direntp->d_name);

					if(!isChar)
					{
						log_bug("do_reward: Couldn't find pfile for %s",direntp->d_name);
						continue;
					}

					d.character->desc = NULL;
					d.character->next = char_list;
					char_list = d.character;
					/* Just in case, they can't login while getting a reward */
					d.connected = CON_GET_REWARD;

					victim = d.character;
					reset_char(victim);

					/* Bring the char to us just in case */
					if(victim->in_room != NULL)
					{
						if(victim->was_in_room == NULL)
							victim->was_in_room = victim->in_room;
		
						char_from_room(victim);
						char_to_room(victim, ch->in_room);
					}

					if(victim->pet != NULL)
					{
						char_to_room(victim->pet, victim->in_room);
					}

					/* Reward the player */
					reward_player(ch, victim, percent, FALSE);

					/* Unload the player */
					if(victim->desc != NULL)
					{
						log_bug("do_reward: Pulled player (%s)is in the game, cant unload him", 
							direntp->d_name);
					}
	
					/* Send the player back where we got him */
					if(victim->was_in_room != NULL)
					{
						char_from_room(victim);
						char_to_room(victim, victim->was_in_room);

						if(victim->pet != NULL)
						{
							char_from_room(victim->pet);
							char_to_room(victim->pet, victim->was_in_room);
						}

						victim->was_in_room = NULL;
					}
					do_quit(victim,"");
				}
			}
		}

		closedir( dirp );
		return;
	}

	if ( ( victim = get_char_ooc( ch, arg ) ) == NULL )
	{
		cprintf(ch,"You don't see anybody like '%s' in the game.\n\r", arg );	
		return;
	}

	reward_player(ch, victim, percent, TRUE);
}	

void reward_player(Character* ch, Character* victim, int percent, bool show_output)
{
	int amount;

	if ( IS_IMMORTAL(victim) || IS_NPC(victim) )
	{
		if(show_output)
			cprintf(ch,"%s isn't mortal, You can only reward mortal PC's.\n\r", victim->name);
		return;
	}

	amount = exp_to_level[ victim->level ].tnl * percent / 100;

	if(show_output)
	{
		actprintf(ch,NULL,victim,TO_CHAR,"You reward $N with %d%% (%d) experience.",percent,amount);
		actprintf(ch,NULL,victim,TO_VICT,"$n rewards you with %d%% (%d) experience.",percent,amount);
	}

	gain_exp( victim, amount, FALSE );
	log_string("Rewarding player %s with %d%% xp (%d)", victim->name, percent, amount);
}

#if !defined(__ARPENS)
void do_ski( Character *ch, char *argument )
{
	cprintf(ch,
"The 'skiptolevel' command must be spelled out in full.  IMPORTANT:  Know\n\r"
"that by using this command, your character will be permanently flagged as\n\r"
"a 'fake' character and your character will be deleted when gamma testing\n\r"
"ends.  You also agree not to hand out money and equipment that you've\n\r"
"earned with this character to others.  Your good faith cooperation is\n\r"
"appreciated.\n\r");
	return;
}

void do_skip( Character *ch, char *argument )
{
	int level;

	if ( argument[0] == '\0' )
	{
		cprintf(ch,"Syntax:  skipto <level>\n\r");
		return;
	}

	level = atoi (argument);
	if ( level <= ch->level )
	{
		cprintf(ch,"You can only skip ahead.\n\r");
		return;
	}

	if ( level > 51 )
	{
		cprintf(ch,"You can't skip to IMM levels!\n\r");
		return;
	}

	advance_character( ch, level );
	return;
}
#endif

void do_dummy( Character *ch, char *argument )
{
    int i;

    for( i=1; subrace_table[i].name != NULL ; i++ )
    {
        if ( subrace_table[i].next_avail != NULL )
        {
            cprintf(ch," * %-12s next available %s\n\r",
                subrace_table[i].name, 
                format_date( *subrace_table[i].next_avail, "%A, %d %b, %Y, %H:%M" ) );
        }
    }
}

void do_dummy1( Character *ch, char *argument )
{
	Descriptor *d;
	Character *wch;

	cprintf(ch,"*** Descriptors ***\n\r");
	for( d = descriptor_list ;d ; d= d->next )
	{
		cprintf(ch,"Desc %d:\n\r", d->descriptor );
		if ( d->character )
		{
			cprintf(ch,"   Character:  %s %p\n\r",d->character->name,d->character);
			if ( d->character->shapeshifted )
				cprintf(ch,"   Ch SS:      %s %p\n\r",d->character->shapeshifted->name,d->character->shapeshifted );
		}

		if ( d->original )
		{
			cprintf(ch,"   Original:   %s %p\n\r",d->original->name,d->original);
			if ( d->original->shapeshifted )
				cprintf(ch,"   Orig SS:    %s %p\n\r",d->original->shapeshifted->name,d->original->shapeshifted);
		}
	}

	cprintf(ch,"*** Characters ***\n\r");
	/* Characters */
	for( wch = char_list ; wch ; wch = wch->next )
	{
		if ( IS_NPC(wch) )
			continue;

		cprintf(ch," Character:  %s %p\n\r", wch->name, wch );
		if ( wch->shapeshifted )
			cprintf(ch,"    Char SS:    %s %p\n\r", wch->shapeshifted->name, wch->shapeshifted );
	}
}

void do_analyze( Character *ch, char *argument )
{
	ObjIndex *obj;
	int vnum;
	int armorArray[MAX_ARMOR+1][MAX_LEVEL+1];
	int i, j;

	memset(armorArray,0,sizeof(armorArray));

	for( vnum=1; vnum < 35000 ; vnum++ )
	{
		if ( (obj = get_obj_index(vnum)) == NULL )
			continue;

		if ( obj->item_type != ITEM_ARMOR )
			continue;

		armorArray[ obj->value[5] ][ obj->level ]++;
	}

	for( i=0; i< MAX_ARMOR;i++)
	{
		cprintf(ch,"\n\r\n\r== Distribution Summary for %s ==\n\r", armor_table[i].name );
		for(j=1;j<=MAX_LEVEL;j++)
			if ( armorArray[i][j] > 0 )
				cprintf(ch,"Level %d :: %d items.\n\r", j, armorArray[i][j]);
	}

	return;
}

void do_dload( Character *ch, char *argument )
{
    /*
     * ArpensMUD / THOC
     * Read in spell data
     */
    FILE *fpList;
    FILE *fpSpell;
    extern char            shortFilename[MAX_INPUT_LENGTH];
    extern                 void load_spells( FILE *fp );

    if ( dlclose( libspells ) < 0 )	
	{
		cprintf(ch,"The libary could not be closed: %s.\n\r",dlerror());
		log_string("Failed to close libspell: %s", dlerror() );
		return;
	}

    libspells = dlopen( LIBSPELLS, RTLD_LAZY | RTLD_GLOBAL );

    if ( libspells == NULL )
        log_string("Failed to open libspell: %s", dlerror() );
	else
		cprintf(ch,"Libspells re-opened successfully.\n\r");

    log_string("Loading spell file %s",SPELL_LIST);
    if ( ( fpList = fopen( SPELL_LIST, "r" ) ) == NULL )
    {
        log_error( SPELL_LIST );
        exit( 1 );
    }

    for ( ; ; )
    {
        char *tmp;
        char strSpell[MAX_INPUT_LENGTH];
        tmp = fread_word( fpList );

        /* If we find a '$' we're done loading */
        if ( *tmp == '$' )
            break;
        else
        {
            snprintf(strSpell,sizeof(strSpell),"%s/%s", getDirectory(SPELL_DIR), tmp );
            snprintf(shortFilename,sizeof(shortFilename),"%s", tmp );
        }

        if ( strSpell[0] == '-' )
        {
            fpSpell = stdin;
        }
        else
        {
            if ( ( fpSpell = fopen( strSpell, "r" ) ) == NULL )
            {
                log_error( strSpell );
                exit( 1 );
            }
        }

        log_string("Reloading spells '%s'",strSpell);
        for ( ; ; )
        {
            char *word;
            if ( fread_letter( fpSpell ) != '#' )
            {
                log_bug( "Boot_db: # not found.", 0 );
                exit( 1 );
            }
            word = fread_word( fpSpell );
           /*log_string("Arpens_Boot: Process section '%s'", word );*/
            if ( word[0] == '$' )
                break;
            else if ( !str_cmp( word, "SPELLS"     ) ) load_spells(fpSpell);
            else
            {
                log_bug( "Boot_db: bad section name.", 0 );
                exit( 1 );
            }
        }
        if ( fpSpell != stdin )
            fclose( fpSpell );
        fpSpell = NULL;
    }
    fclose( fpList );

    cprintf(ch,"Spells reloaded from file.\n\r");
}

