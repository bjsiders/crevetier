/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/** System Include Files **/
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/** Custom Header Files **/
#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "tables.h"
#include "recycle.h"

/** The library of Arcanist spells, arranged alphabetically */
bool spell_shout( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(2),highDam(4));

    if ( check_saves_spell(ch, victim, DAM_SOUND, SAVE_FORTITUDE) )
	{
		act("$N shakes off the stunning affect.",ch,NULL,victim,TO_CHAR);
        dam /= 2;   
	}
	else
	{
		DAZE_STATE(victim,PULSE_PER_SECOND*3);
		act("$n is stunned!",victim,NULL,NULL,TO_ROOM);
		act("You are stunned!",victim,NULL,NULL,TO_CHAR);
	}

    damage( ch, victim, dam, sn, DAM_SOUND , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_din( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    int   dam;
    
    dam = calcSpellDamage(ch,sn,lowDam(4),highDam(8));  
    
    if ( check_saves_spell(ch, victim, DAM_SOUND, SAVE_FORTITUDE) )
	{
		act("$N shakes off the stunning affect.",ch,NULL,victim,TO_CHAR);
        dam /= 2;   
	}
    else
    {
        DAZE_STATE(victim,PULSE_PER_SECOND*5);
		act("$n is stunned!",victim,NULL,NULL,TO_ROOM);
        act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    }

    damage( ch, victim, dam, sn, DAM_SOUND , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_sonic_blast( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    int   dam;
    
    dam = calcSpellDamage(ch,sn,lowDam(8),highDam(16));  
    
    if ( check_saves_spell(ch, victim, DAM_SOUND, SAVE_FORTITUDE) )
	{
		act("$N shakes off the stunning affect.",ch,NULL,victim,TO_CHAR);
        dam /= 2;   
	}
    else
    {
        DAZE_STATE(victim,PULSE_PER_SECOND*7);
		act("$n is stunned!",victim,NULL,NULL,TO_ROOM);
        act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    }

    damage( ch, victim, dam, sn, DAM_SOUND , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_deafening_burst( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    int   dam;
    
    dam = calcSpellDamage(ch,sn,lowDam(16),highDam(32));  
    
    if ( check_saves_spell(ch, victim, DAM_SOUND, SAVE_FORTITUDE) )
	{
		act("$N shakes off the stunning affect.",ch,NULL,victim,TO_CHAR);
        dam /= 2;   
	}
    else
    {
        DAZE_STATE(victim,PULSE_PER_SECOND*9);
		act("$n is stunned!",victim,NULL,NULL,TO_ROOM);
        act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    }

    damage( ch, victim, dam, sn, DAM_SOUND , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_cacophony( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    int   dam;
    
    dam = calcSpellDamage(ch,sn,lowDam(32),highDam(64));  
    
    if ( check_saves_spell(ch, victim, DAM_SOUND, SAVE_FORTITUDE) )
	{
		act("$N shakes of the stunning affect.",ch,NULL,victim,TO_CHAR);
        dam /= 2;   
	}
    else
    {
        DAZE_STATE(victim,PULSE_PER_SECOND*11);
		act("$n is stunned!",victim,NULL,NULL,TO_ROOM);
        act("You are stunned!",victim,NULL,NULL,TO_CHAR);
    }

    damage( ch, victim, dam, sn, DAM_SOUND , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_minor_regeneration( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(18);
    af.location     = APPLY_REGEN_HP;
    af.modifier     = 2;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

	af.location		= APPLY_REGEN_BASE;
	af.modifier		= 1;
	spellAffectToChar( victim, &af );

	act("You begin to regenerate more rapidly.",victim,NULL,NULL,TO_CHAR);
	act("$n begins to regenerate more rapidly.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_lesser_regeneration( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(18);
    af.location     = APPLY_REGEN_HP;
    af.modifier     = 4;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
    
    af.location     = APPLY_REGEN_BASE;
    af.modifier     = 2;
    spellAffectToChar( victim, &af );
    
    act("You begin to regenerate more rapidly.",victim,NULL,NULL,TO_CHAR);
    act("$n begins to regenerate more rapidly.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_regeneration( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(18);
    af.location     = APPLY_REGEN_HP;
    af.modifier     = 8;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
    
    af.location     = APPLY_REGEN_BASE;
    af.modifier     = 4;
    spellAffectToChar( victim, &af );
    
    act("You begin to regenerate more rapidly.",victim,NULL,NULL,TO_CHAR);
    act("$n begins to regenerate more rapidly.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_major_regeneration( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(18);
    af.location     = APPLY_REGEN_HP;
    af.modifier     = 16;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
    
    af.location     = APPLY_REGEN_BASE;
    af.modifier     = 8;
    spellAffectToChar( victim, &af );
    
    act("You begin to regenerate more rapidly.",victim,NULL,NULL,TO_CHAR);
    act("$n begins to regenerate more rapidly.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_greater_regeneration( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(18);
    af.location     = APPLY_REGEN_HP;
    af.modifier     = 32;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
    
    af.location     = APPLY_REGEN_BASE;
    af.modifier     = 16;
    spellAffectToChar( victim, &af );
    
    act("You begin to regenerate more rapidly.",victim,NULL,NULL,TO_CHAR);
    act("$n begins to regenerate more rapidly.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_acuity( int sn, int level, Character *ch, void *vo, int target )
{
	Character *victim = (Character *) vo;
	Affect af;

	af.where		= TO_AFFECTS;
	af.type			= sn;
	af.level		= level;
	af.duration		= minutes(32);
	af.location		= APPLY_INT;
	af.modifier		= 25;
	af.bitvector	= 0;
	af.flags		= AFF_SPELL;

	spellAffectToChar( victim, &af );
	act("Your mind clears and you feel sharper.",victim,NULL,NULL,TO_CHAR);
	if ( victim != ch )
		act("$N appears more thoughtful.",ch,NULL,victim,TO_CHAR);

	return TRUE;
}

bool spell_flare( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
	Affect af;
    int dam;
	bool fSave;

    dam = calcSpellDamage(ch,sn,lowDam(6),highDam(8));

    if ( (fSave = check_saves_spell(ch, victim, DAM_LIGHT, SAVE_REFLEX)) )
    	dam /= 2;
	else
	{
		af.where		= TO_AFFECTS;
		af.bitvector	= AFF_BLIND;
		af.type			= sn;
		af.level		= level;
		af.duration		= seconds(20);
		af.location		= APPLY_HITROLL;
		af.modifier		= -10;
		af.flags		= AFF_SPELL;
		spellAffectToChar( victim, &af );

		act("You are struck blind by a flash of light!",victim,NULL,NULL,TO_CHAR);
		act("$n appears to be struck blind!",victim,NULL,NULL,TO_ROOM);
	}

    damage( ch, victim, dam, sn, DAM_LIGHT , DF_SHOW | DF_SPELL ); 
    return TRUE;
}

bool spell_sunflash( int sn, int level, Character *ch,void *vo,int target)
{   
    Character *victim = (Character *) vo;
    Affect af;
    int dam;
    bool fSave;

    dam = calcSpellDamage(ch,sn,lowDam(19),highDam(23));
    
    if ( (fSave = check_saves_spell(ch, victim, DAM_LIGHT, SAVE_REFLEX)) )
        dam /= 2;
    else 
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = AFF_BLIND;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(31);
        af.location     = APPLY_HITROLL;
        af.modifier     = -30;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );
    
        act("You are struck blind by a flash of light!",victim,NULL,NULL,TO_CHAR);
        act("$n appears to be struck blind!",victim,NULL,NULL,TO_ROOM);
    }   
 
    damage( ch, victim, dam, sn, DAM_LIGHT , DF_SHOW | DF_SPELL ); 
    return TRUE;
}

bool spell_solar_burst( int sn, int level, Character *ch,void *vo,int target)
{   
    Character *victim = (Character *) vo;
    Affect af;
    int dam;
    bool fSave;

    dam = calcSpellDamage(ch,sn,lowDam(39),highDam(48));
    
    if ( (fSave = check_saves_spell(ch, victim, DAM_LIGHT, SAVE_REFLEX)) )
        dam /= 2;
    else 
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = AFF_BLIND;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(43);
        af.location     = APPLY_HITROLL;
        af.modifier     = -60;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );
    
        act("You are struck blind by a flash of light!",victim,NULL,NULL,TO_CHAR);
        act("$n appears to be struck blind!",victim,NULL,NULL,TO_ROOM);
    }   
 
    damage( ch, victim, dam, sn, DAM_LIGHT , DF_SHOW | DF_SPELL ); 
    return TRUE;
}

bool spell_flash_of_light( int sn, int level, Character *ch,void *vo,int target)
{   
    Character *victim = (Character *) vo;
    Affect af;
    int dam;
    bool fSave;

    dam = calcSpellDamage(ch,sn,lowDam(71),highDam(88));
 
    if ( (fSave = check_saves_spell(ch, victim, DAM_LIGHT, SAVE_REFLEX)) )
        dam /= 2;
    else 
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = AFF_BLIND;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(55);
        af.location     = APPLY_HITROLL;
        af.modifier     = -90;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );
    
        act("You are struck blind by a flash of light!",victim,NULL,NULL,TO_CHAR);
        act("$n appears to be struck blind!",victim,NULL,NULL,TO_ROOM);
    }   
 
    damage( ch, victim, dam, sn, DAM_LIGHT , DF_SHOW | DF_SPELL ); 
    return TRUE;
}

bool spell_sunburst( int sn, int level, Character *ch,void *vo,int target)
{   
    Character *victim = (Character *) vo;
    Affect af;
    int dam;
    bool fSave;

    dam = calcSpellDamage(ch,sn,lowDam(120),highDam(148));
 
    if ( (fSave = check_saves_spell(ch, victim, DAM_LIGHT, SAVE_REFLEX)) )
        dam /= 2;
    else 
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = AFF_BLIND;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(67);
        af.location     = APPLY_HITROLL;
        af.modifier     = -30;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );
    
        act("You are struck blind by a flash of light!",victim,NULL,NULL,TO_CHAR);
        act("$n appears to be struck blind!",victim,NULL,NULL,TO_ROOM);
    }   
 
    damage( ch, victim, dam, sn, DAM_LIGHT , DF_SHOW | DF_SPELL ); 
    return TRUE;
}

bool spell_solar_flare( int sn, int level, Character *ch,void *vo,int target)
{   
    Character *victim = (Character *) vo;
    Affect af;
    int dam;
    bool fSave;

    dam = calcSpellDamage(ch,sn,lowDam(188),highDam(232));
 
    if ( (fSave = check_saves_spell(ch, victim, DAM_LIGHT, SAVE_REFLEX)) )
        dam /= 2;
    else 
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = AFF_BLIND;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(91);
        af.location     = APPLY_HITROLL;
        af.modifier     = -130;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );
    
        act("You are struck blind by a flash of light!",victim,NULL,NULL,TO_CHAR);
        act("$n appears to be struck blind!",victim,NULL,NULL,TO_ROOM);
    }   
 
    damage( ch, victim, dam, sn, DAM_LIGHT , DF_SHOW | DF_SPELL ); 
    return TRUE;
}

bool spell_intellect( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_INT;
    af.modifier     = 40;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your mind clears and you feel sharper.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N appears more thoughtful.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_sagacity( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(48);
    af.location     = APPLY_INT;
    af.modifier     = 55;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your mind clears and you feel sharper.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N appears more thoughtful.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_acumen( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(56);
    af.location     = APPLY_INT;
    af.modifier     = 70;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your mind clears and you feel sharper.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N appears more thoughtful.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_alluring_aura( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(32);
    af.location     = APPLY_CHA;
    af.modifier     = 25;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You feel charismatic and personable.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N appears more charismatic.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_affable_aura( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_CHA;
    af.modifier     = 40;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You feel charismatic and personable.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N appears more charismatic.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_amiable_aura( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(48);
    af.location     = APPLY_CHA;
    af.modifier     = 55;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You feel charismatic and personable.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N appears more charismatic.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_charismatic_aura( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(56);
    af.location     = APPLY_CHA;
    af.modifier     = 70;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You feel charismatic and personable.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N appears more charismatic.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_cats_feet( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(32);
    af.location     = APPLY_DEX;
    af.modifier     = 15;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You feel agile and quick.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N appears more coordinated.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_cougers_feet( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_DEX;
    af.modifier     = 30;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You feel agile and quick.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N appears more coordinated.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_panthers_feet( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(48);
    af.location     = APPLY_DEX;
    af.modifier     = 45;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You feel agile and quick.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N appears more coordinated.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_tigers_feet( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(56);
    af.location     = APPLY_DEX;
    af.modifier     = 60;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You feel agile and quick.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N appears more coordinated.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_lions_feet( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(64);
    af.location     = APPLY_DEX;
    af.modifier     = 75;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You feel agile and quick.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N appears more coordinated.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_cheetahs_feet( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(72);
    af.location     = APPLY_DEX;
    af.modifier     = 90;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You feel agile and quick.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N appears more coordinated.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_orc_strength( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(32);
    af.location     = APPLY_STR;
    af.modifier     = 15;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You feel powerful and strong.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N appears stronger.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_ogre_strength( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;
 
    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_STR;
    af.modifier     = 30;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You feel powerful and strong.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N appears stronger.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_ettin_strength( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;
 
    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(48);
    af.location     = APPLY_STR;
    af.modifier     = 45;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You feel powerful and strong.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N appears stronger.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_cyclops_strength( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;
 
    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(56);
    af.location     = APPLY_STR;
    af.modifier     = 60;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You feel powerful and strong.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N appears stronger.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_giant_strength( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;
 
    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(64);
    af.location     = APPLY_STR;
    af.modifier     = 75;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You feel powerful and strong.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N appears stronger.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_titan_strength( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;
 
    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(72);
    af.location     = APPLY_STR;
    af.modifier     = 90;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You feel powerful and strong.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N appears stronger.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_minor_defense( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;
 
    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(32);
    af.location     = APPLY_AC;
    af.modifier     = 25;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are surrounded by a protective aura of defense.",victim,NULL,NULL,TO_CHAR);
	act("$n is surrounded by a protective aura of defense.",victim,NULL,NULL,TO_ROOM);

    return TRUE;
}

bool spell_lesser_defense( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(44);
    af.location     = APPLY_AC; 
    af.modifier     = 50;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are surrounded by a protective aura of defense.",victim,NULL,NULL,TO_CHAR);
    act("$n is surrounded by a protective aura of defense.",victim,NULL,NULL,TO_ROOM);
    
    return TRUE;
}

bool spell_defense( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(56);
    af.location     = APPLY_AC; 
    af.modifier     = 90;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are surrounded by a protective aura of defense.",victim,NULL,NULL,TO_CHAR);
    act("$n is surrounded by a protective aura of defense.",victim,NULL,NULL,TO_ROOM);
    
    return TRUE;
}

bool spell_major_defense( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(68);
    af.location     = APPLY_AC; 
    af.modifier     = 140;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are surrounded by a protective aura of defense.",victim,NULL,NULL,TO_CHAR);
    act("$n is surrounded by a protective aura of defense.",victim,NULL,NULL,TO_ROOM);
    
    return TRUE;
}

bool spell_greater_defense( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(80);
    af.location     = APPLY_AC; 
    af.modifier     = 190;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are surrounded by a protective aura of defense.",victim,NULL,NULL,TO_CHAR);
    act("$n is surrounded by a protective aura of defense.",victim,NULL,NULL,TO_ROOM);
    
    return TRUE;
}

bool spell_superior_defense( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(92);
    af.location     = APPLY_AC; 
    af.modifier     = 250;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are surrounded by a protective aura of defense.",victim,NULL,NULL,TO_CHAR);
    act("$n is surrounded by a protective aura of defense.",victim,NULL,NULL,TO_ROOM);
    
    return TRUE;
}

bool spell_endure_acid( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(28);
    af.location     = APPLY_RES_ACID;
    af.modifier     = 10;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are protected from acid.",victim,NULL,NULL,TO_CHAR);
	if( ch != victim )
		act("$N is protected from acid.",ch,NULL,victim,TO_CHAR);
    
    return TRUE;
}

bool spell_resist_acid( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;   

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_RES_ACID;   
    af.modifier     = 20;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are protected from acid.",victim,NULL,NULL,TO_CHAR); 
    if( ch != victim )
        act("$N is protected from acid.",ch,NULL,victim,TO_CHAR);
    
    return TRUE;
}

bool spell_repulse_acid( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;   

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(52);
    af.location     = APPLY_RES_ACID;   
    af.modifier     = 30;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are protected from acid.",victim,NULL,NULL,TO_CHAR); 
    if( ch != victim )
        act("$N is protected from acid.",ch,NULL,victim,TO_CHAR);
    
    return TRUE;
}

bool spell_endure_cold( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;   

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(28);
    af.location     = APPLY_RES_ICE;   
    af.modifier     = 10;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are protected from ice.",victim,NULL,NULL,TO_CHAR); 
    if( ch != victim )
        act("$N is protected from ice.",ch,NULL,victim,TO_CHAR);
    
    return TRUE;
}

bool spell_resist_cold( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_RES_ICE; 
    af.modifier     = 20;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are protected from ice.",victim,NULL,NULL,TO_CHAR);
    if( ch != victim )
        act("$N is protected from ice.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_repulse_cold( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(52);
    af.location     = APPLY_RES_ICE; 
    af.modifier     = 30;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are protected from ice.",victim,NULL,NULL,TO_CHAR);
    if( ch != victim )
        act("$N is protected from ice.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_endure_energy( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(28);
    af.location     = APPLY_RES_ELECTRICITY; 
    af.modifier     = 10;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are protected from energy.",victim,NULL,NULL,TO_CHAR);
    if( ch != victim )
        act("$N is protected from energy.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_resist_energy( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_RES_ELECTRICITY;
    af.modifier     = 20;
    af.bitvector    = 0;  
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are protected from energy.",victim,NULL,NULL,TO_CHAR);
    if( ch != victim )      
        act("$N is protected from energy.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_repulse_energy( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(52);
    af.location     = APPLY_RES_ELECTRICITY;
    af.modifier     = 30;
    af.bitvector    = 0;  
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are protected from energy.",victim,NULL,NULL,TO_CHAR);
    if( ch != victim )      
        act("$N is protected from energy.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_endure_fire( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(28);
    af.location     = APPLY_RES_FIRE;
    af.modifier     = 10;
    af.bitvector    = 0;  
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are protected from fire.",victim,NULL,NULL,TO_CHAR);
    if( ch != victim )      
        act("$N is protected from fire.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_resist_fire( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(40);
    af.location     = APPLY_RES_FIRE;
    af.modifier     = 20;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are protected from fire.",victim,NULL,NULL,TO_CHAR);
    if( ch != victim )
        act("$N is protected from fire.",ch,NULL,victim,TO_CHAR); 

    return TRUE;
}

bool spell_repulse_fire( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(52);
    af.location     = APPLY_RES_FIRE;
    af.modifier     = 30;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("You are protected from fire.",victim,NULL,NULL,TO_CHAR);
    if( ch != victim )
        act("$N is protected from fire.",ch,NULL,victim,TO_CHAR); 

    return TRUE;
}

bool spell_enhanced_fortitude( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(60);
    af.location     = APPLY_SAVE_FORTITUDE;
    af.modifier     = 10;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your fortitude is enhanced.",victim,NULL,NULL,TO_CHAR);
    if( ch != victim )
        act("$N's fortitude is enhanced.",ch,NULL,victim,TO_CHAR); 

    return TRUE;
}

bool spell_enhanced_reflexes( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(60);
    af.location     = APPLY_SAVE_REFLEX;
    af.modifier     = 10;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your reflexes are enhanced.",victim,NULL,NULL,TO_CHAR); 
    if( ch != victim )
        act("$N's reflexes are enhanced.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_enhanced_willpower( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(60);
    af.location     = APPLY_SAVE_WILLPOWER;
    af.modifier     = 10;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );
    act("Your willpower is enhanced.",victim,NULL,NULL,TO_CHAR); 
    if( ch != victim )
        act("$N's willpower is enhanced.",ch,NULL,victim,TO_CHAR);

    return TRUE;
}

bool spell_orb_of_sand( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = number_range(1,3);
    af.modifier     = 0;
    af.location     = APPLY_BLADETURN;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your skin becomes as gritty as sand.",victim,NULL,NULL,TO_CHAR);
    act("$n's skin becomes as gritty as sand.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_orb_of_rock( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = number_range(3,5); 
    af.modifier     = 0;
    af.location     = APPLY_BLADETURN;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your skin becomes as hard as rock.",victim,NULL,NULL,TO_CHAR); 
    act("$n's skin becomes as hard as rock.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_orb_of_steel( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = number_range(5,7); 
    af.modifier     = 0;
    af.location     = APPLY_BLADETURN;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your skin becomes as hard as steel.",victim,NULL,NULL,TO_CHAR); 
    act("$n's skin becomes as hard as steel.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_orb_of_diamond( int sn, int level, Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = number_range(7,9); 
    af.modifier     = 0;
    af.location     = APPLY_BLADETURN;
    af.bitvector    = 0;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

    act("Your skin becomes as hard as diamond.",victim,NULL,NULL,TO_CHAR); 
    act("$n's skin becomes as hard as diamond.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_minor_shock( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;   

    dam = calcSpellDamage(ch,sn,lowDam(10),highDam(13));

    if ( check_saves_spell(ch, victim, DAM_LIGHTNING, SAVE_REFLEX) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_LIGHTNING , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_major_shock( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(23),highDam(28));   

    if ( check_saves_spell(ch, victim, DAM_LIGHTNING, SAVE_REFLEX) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_LIGHTNING , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_jolt_of_lightning( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(42),highDam(51));   

    if ( check_saves_spell(ch, victim, DAM_LIGHTNING, SAVE_REFLEX) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_LIGHTNING , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_burst_of_lightning( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(71),highDam(87));   

    if ( check_saves_spell(ch, victim, DAM_LIGHTNING, SAVE_REFLEX) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_LIGHTNING , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_blast_of_lightning( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(115),highDam(140));   

    if ( check_saves_spell(ch, victim, DAM_LIGHTNING, SAVE_REFLEX) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_LIGHTNING , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_electrocution( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(148),highDam(184));   

    if ( check_saves_spell(ch, victim, DAM_LIGHTNING, SAVE_REFLEX) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_LIGHTNING , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_mending( int sn, int level, Character *ch, void *vo, int target )
{
	Object *o = (Object *) vo;

	if ( o->condition > 90 )
	{
		cprintf(ch,"This object cannot be repaired further.\n\r");
		return FALSE;
	}

	o->condition = UMIN(100, o->condition + (o->condition / 5) );
	act("$p is mended.",ch,o,NULL,TO_CHAR);
	return TRUE;
}

bool spell_minor_weapon_enchantment(int sn,int level,Character *ch,void *vo,int target)
{
	Object *obj = (Object *) vo;

	if ( obj->item_type != ITEM_WEAPON )
	{
		act("$p is not a weapon.",ch,obj,NULL,TO_CHAR);
		return FALSE;
	}

	if ( obj->wear_loc >= 0 )
	{
		act("You must be holding whatever you wish to enchant.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

    if ( !enchant_weapon( obj, SET_HITROLL(1), SET_DAMROLL(0), sn, level ) )
	{
		act("Your enchantment is not powerful enough.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

	act("$p emits a dim blue glow briefly.",ch,obj,NULL,TO_CHAR);
	act("$p emits a dim blue glow briefly.",ch,obj,NULL,TO_ROOM);
	return TRUE;
}

bool spell_lesser_weapon_enchantment(int sn,int level,Character *ch,void *vo,int target)
{
	Object *obj = (Object *) vo;

	if ( obj->item_type != ITEM_WEAPON )
	{
		act("$p is not a weapon.",ch,obj,NULL,TO_CHAR);
		return FALSE;
	}

	if ( obj->wear_loc >= 0 )
	{
		act("You must be holding whatever you wish to enchant.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

    if ( !enchant_weapon( obj, SET_HITROLL(1), SET_DAMROLL(1), sn, level ) )
	{
		act("Your enchantment is not powerful enough.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

	act("$p emits a dim blue glow briefly.",ch,obj,NULL,TO_CHAR);
	act("$p emits a dim blue glow briefly.",ch,obj,NULL,TO_ROOM);
	return TRUE;
}

bool spell_weapon_enchantment(int sn,int level,Character *ch,void *vo,int target)
{
	Object *obj = (Object *) vo;

	if ( obj->item_type != ITEM_WEAPON )
	{
		act("$p is not a weapon.",ch,obj,NULL,TO_CHAR);
		return FALSE;
	}

	if ( obj->wear_loc >= 0 )
	{
		act("You must be holding whatever you wish to enchant.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

    if ( !enchant_weapon( obj, SET_HITROLL(2), SET_DAMROLL(2), sn, level ) )
	{
		act("Your enchantment is not powerful enough.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

	act("$p emits a dim blue glow briefly.",ch,obj,NULL,TO_CHAR);
	act("$p emits a dim blue glow briefly.",ch,obj,NULL,TO_ROOM);
	return TRUE;
}

bool spell_major_weapon_enchantment(int sn,int level,Character *ch,void *vo,int target)
{
	Object *obj = (Object *) vo;

	if ( obj->item_type != ITEM_WEAPON )
	{
		act("$p is not a weapon.",ch,obj,NULL,TO_CHAR);
		return FALSE;
	}

	if ( obj->wear_loc >= 0 )
	{
		act("You must be holding whatever you wish to enchant.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

    if ( !enchant_weapon( obj, SET_HITROLL(3), SET_DAMROLL(3), sn, level ) )
	{
		act("Your enchantment is not powerful enough.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

	act("$p emits a dim blue glow briefly.",ch,obj,NULL,TO_CHAR);
	act("$p emits a dim blue glow briefly.",ch,obj,NULL,TO_ROOM);
	return TRUE;
}

bool spell_greater_weapon_enchantment(int sn,int level,Character *ch,void *vo,int target)
{
	Object *obj = (Object *) vo;

	if ( obj->item_type != ITEM_WEAPON )
	{
		act("$p is not a weapon.",ch,obj,NULL,TO_CHAR);
		return FALSE;
	}

	if ( obj->wear_loc >= 0 )
	{
		act("You must be holding whatever you wish to enchant.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

    if ( !enchant_weapon( obj, SET_HITROLL(4), SET_DAMROLL(4), sn, level ) )
	{
		act("Your enchantment is not powerful enough.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

	act("$p emits a dim blue glow briefly.",ch,obj,NULL,TO_CHAR);
	act("$p emits a dim blue glow briefly.",ch,obj,NULL,TO_ROOM);
	return TRUE;
}

bool spell_superior_weapon_enchantment(int sn,int level,Character *ch,void *vo,int target)
{
	Object *obj = (Object *) vo;

	if ( obj->item_type != ITEM_WEAPON )
	{
		act("$p is not a weapon.",ch,obj,NULL,TO_CHAR);
		return FALSE;
	}

	if ( obj->wear_loc >= 0 )
	{
		act("You must be holding whatever you wish to enchant.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

    if ( !enchant_weapon( obj, SET_HITROLL(5), SET_DAMROLL(5), sn, level ) )
	{
		act("Your enchantment is not powerful enough.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

	act("$p emits a dim blue glow briefly.",ch,obj,NULL,TO_CHAR);
	act("$p emits a dim blue glow briefly.",ch,obj,NULL,TO_ROOM);
	return TRUE;
}


bool spell_minor_armor_enchantment(int sn,int level,Character *ch,void *vo,int target)
{
	Object *obj = (Object *) vo;

	if ( obj->item_type != ITEM_ARMOR )
	{
		act("$p is not a piece of armor.",ch,obj,NULL,TO_CHAR);
		return FALSE;
	}

	if ( obj->wear_loc >= 0 )
	{
		act("You must be holding whatever you wish to enchant.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

    if ( !enchant_armor( obj, SET_AC(1), SET_ABSORB(0), sn, level ) )
	{
		act("Your enchantment is not powerful enough.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

	act("$p emits a dim blue glow briefly.",ch,obj,NULL,TO_CHAR);
	act("$p emits a dim blue glow briefly.",ch,obj,NULL,TO_ROOM);
	return TRUE;
}

bool spell_lesser_armor_enchantment(int sn,int level,Character *ch,void *vo,int target)
{
    Object *obj = (Object *) vo;
 
    if ( obj->item_type != ITEM_ARMOR )
    {
        act("$p is not a piece of armor.",ch,obj,NULL,TO_CHAR);
        return FALSE;
    }

    if ( obj->wear_loc >= 0 )
    {
        act("You must be holding whatever you wish to enchant.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( !enchant_armor( obj, SET_AC(1), SET_ABSORB(1), sn, level ) )
    {
        act("Your enchantment is not powerful enough.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    act("$p emits a dim blue glow.",ch,obj,NULL,TO_CHAR);
    act("$p emits a dim blue glow.",ch,obj,NULL,TO_ROOM);
    return TRUE;   
}

bool spell_armor_enchantment(int sn,int level,Character *ch,void *vo,int target)
{
    Object *obj = (Object *) vo;
 
    if ( obj->item_type != ITEM_ARMOR )
    {
        act("$p is not a piece of armor.",ch,obj,NULL,TO_CHAR);
        return FALSE;
    }

    if ( obj->wear_loc >= 0 )
    {
        act("You must be holding whatever you wish to enchant.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( !enchant_armor( obj, SET_AC(2), SET_ABSORB(2), sn, level ) )
    {
        act("Your enchantment is not powerful enough.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    act("$p emits a blue glow.",ch,obj,NULL,TO_CHAR);
    act("$p emits a blue glow.",ch,obj,NULL,TO_ROOM);
    return TRUE;   
}

bool spell_major_armor_enchantment(int sn,int level,Character *ch,void *vo,int target)
{
    Object *obj = (Object *) vo;
 
    if ( obj->item_type != ITEM_ARMOR )
    {
        act("$p is not a piece of armor.",ch,obj,NULL,TO_CHAR);
        return FALSE;
    }

    if ( obj->wear_loc >= 0 )
    {
        act("You must be holding whatever you wish to enchant.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( !enchant_armor( obj, SET_AC(3), SET_ABSORB(3), sn, level ) )
    {
        act("Your enchantment is not powerful enough.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    act("$p emits a bright blue glow.",ch,obj,NULL,TO_CHAR);
    act("$p emits a bright blue glow.",ch,obj,NULL,TO_ROOM);
    return TRUE;   
}

bool spell_greater_armor_enchantment(int sn,int level,Character *ch,void *vo,int target)
{
    Object *obj = (Object *) vo;
 
    if ( obj->item_type != ITEM_ARMOR )
    {
        act("$p is not a piece of armor.",ch,obj,NULL,TO_CHAR);
        return FALSE;
    }

    if ( obj->wear_loc >= 0 )
    {
        act("You must be holding whatever you wish to enchant.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( !enchant_armor( obj, SET_AC(4), SET_ABSORB(4), sn, level ) )
    {
        act("Your enchantment is not powerful enough.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    act("$p emits a brilliant blue glow!",ch,obj,NULL,TO_CHAR);
    act("$p emits a brilliant blue glow!",ch,obj,NULL,TO_ROOM);
    return TRUE;   
}

bool spell_superior_armor_enchantment(int sn,int level,Character *ch,void *vo,int target)
{
    Object *obj = (Object *) vo;
 
    if ( obj->item_type != ITEM_ARMOR )
    {
        act("$p is not a piece of armor.",ch,obj,NULL,TO_CHAR);
        return FALSE;
    }

    if ( obj->wear_loc >= 0 )
    {
        act("You must be holding whatever you wish to enchant.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( !enchant_armor( obj, SET_AC(5), SET_ABSORB(5), sn, level ) )
    {
        act("Your enchantment is not powerful enough.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    act("$p emits a radiant blue glow!",ch,obj,NULL,TO_CHAR);
    act("$p emits a radiant blue glow!",ch,obj,NULL,TO_ROOM);
    return TRUE;   
}

bool spell_ward_summoned( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    int   dam;

	if ( !IS_SET( victim->form, FORM_SUMMONED ) )
	{
		act("$N is not a summoned creature.",ch,NULL,victim,TO_CHAR);
		return FALSE;
	}

    dam = calcSpellDamage(ch,sn,lowDam(32),highDam(40));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;

    damage( ch, victim, dam, sn, DAM_SPIRIT, DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_repel_summoned( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    int   dam;

    if ( !IS_SET( victim->form, FORM_SUMMONED ) )
    {
        act("$N is not a summoned creature.",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,lowDam(66),highDam(80));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;

    damage( ch, victim, dam, sn, DAM_SPIRIT, DF_SHOW | DF_SPELL ); 
    return TRUE;
}

bool spell_dismiss_summoned( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    int   dam;

    if ( !IS_SET( victim->form, FORM_SUMMONED ) )
    {
        act("$N is not a summoned creature.",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,lowDam(117),highDam(142));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;

    damage( ch, victim, dam, sn, DAM_SPIRIT, DF_SHOW | DF_SPELL ); 
    return TRUE;
}

bool spell_banish_summoned( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    int   dam;

    if ( !IS_SET( victim->form, FORM_SUMMONED ) )
    {
        act("$N is not a summoned creature.",ch,NULL,victim,TO_CHAR);
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,lowDam(190),highDam(233));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;

    damage( ch, victim, dam, sn, DAM_SPIRIT, DF_SHOW | DF_SPELL ); 
    return TRUE;
}

/* Golems
 * flesh    paladin
 * clay     paladin
 * wood     paladin
 * glass    fighter
 * stone    fighter
 * iron     barbarian
 * mithril	barbarian
 */
bool spell_flesh_golem( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet;
    int i;
	int ench_skill;
	int hp_max;
    char buf[MAX_STRING_LENGTH];

    if( ch->pet != NULL )
    {
        cprintf(ch,"Dismiss the one you have!\n\r");
        return FALSE;
    }

    pet = create_mobile( get_mob_index( VNUM_GOLEM ) );
    SET_BIT(pet->act, ACT_PET);
    SET_BIT(pet->affected_by, AFF_CHARM);
    SET_BIT(pet->form, FORM_CONSTRUCTED);
    pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
    char_to_room( pet, ch->in_room );
    ch->pet = pet;

    pet->class = csn_paladin;
    ench_skill = get_skill(ch,skill_lookup("enchantment"));
    hp_max = ench_skill * 10;
    pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
    pet->max_base_hit = pet->max_stat_hit / 5;
    pet->stat_hit = pet->max_stat_hit;
    pet->base_hit = pet->max_base_hit;
    pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000; /* these guys never exhaust */
    pet->level = ch->level;

    for( i = 0; i < MAX_STATS ; i++ )
        pet->perm_stat[i] = 100 + (ench_skill*3);

    for( i = 0 ; i < 4 ; i++ )
        pet->armor[i] = ench_skill * 5 / 10;
    pet->armor[3] /= 4;

    pet->hitroll = ench_skill * 6 / 10;
    pet->damage[0] = 1;
    pet->damage[1] = 6;
    pet->damage[2] = ench_skill * 2 / 10;

	/* Golem resists */
	setResist( pet, RESIST_FIRE, 	ench_skill / 2 - 50 );
	setResist( pet, RESIST_ICE,  	ench_skill / 2 - 50 );
	setResist( pet, RESIST_EARTH, 	ench_skill / 2 - 50 );
	setResist( pet, RESIST_AIR,		ench_skill / 2 - 50 );
	setResist( pet, RESIST_LIGHT,	0 );
	setResist( pet, RESIST_DARK,	0 );
	setResist( pet, RESIST_POISON,	ench_skill / 2 - 50 );
	setResist( pet, RESIST_DISEASE,	ench_skill / 2 - 50 );
	setResist( pet, RESIST_MENTAL,	RESIST_IMMUNE );
	setResist( pet, RESIST_ACID, 	ench_skill / 2 - 50 );
	setResist( pet, RESIST_ELECTRICITY,	ench_skill / 2 - 50 );
	setResist( pet, RESIST_SPIRIT,	0 );
	setResist( pet, RESIST_SOUND,	ench_skill / 2 - 50 );
	setResist( pet, RESIST_WATER,	ench_skill / 2 - 50 );
	setResist( pet, RESIST_BODY,	RESIST_IMMUNE );
	setResist( pet, RESIST_SLASH,	0 );
	setResist( pet, RESIST_CONCUSSION,	0 );
	setResist( pet, RESIST_PIERCE,	0 );

    snprintf(buf,sizeof(buf),"flesh golem");
    free_string( pet->name );
    pet->name = str_dup( buf );

    snprintf(buf,sizeof(buf),"a flesh golem");
    free_string( pet->short_descr );
    pet->short_descr = str_dup( buf );

    snprintf(buf,sizeof(buf),"A flesh golem stands at attention here.\n\r");
    free_string( pet->long_descr );
    pet->long_descr = str_dup( buf );

    act("$n is woven into existance from the fabric of magic.", pet,NULL,NULL,TO_ROOM);
    act("$N gazes at $n with empty eyes, awaiting instructions.", ch,NULL,pet,TO_NOTVICT);
    act("$N gazes at you with empty eyes, awaiting instructions.", ch,NULL,pet,TO_CHAR);
    add_follower( pet, ch );
    pet->leader = ch;
    pet_to_group( ch, pet );
	return TRUE;
}

bool spell_clay_golem( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet;
    int i;
	int ench_skill;
	int hp_max;
    char buf[MAX_STRING_LENGTH];

    if( ch->pet != NULL )
    {
        cprintf(ch,"Dismiss the one you have!\n\r");
        return FALSE;
    }

    pet = create_mobile( get_mob_index( VNUM_GOLEM ) );
    SET_BIT(pet->act, ACT_PET);
    SET_BIT(pet->affected_by, AFF_CHARM);
    SET_BIT(pet->form, FORM_CONSTRUCTED);
    pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
    char_to_room( pet, ch->in_room );
    ch->pet = pet;

    pet->class = csn_paladin;
    ench_skill = get_skill(ch,skill_lookup("enchantment"));
    hp_max = ench_skill * 17;
    pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
    pet->max_base_hit = pet->max_stat_hit / 5;
    pet->stat_hit = pet->max_stat_hit;
    pet->base_hit = pet->max_base_hit;
    pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000; /* these guys never exhaust */
    pet->level = ch->level;

    for( i = 0; i < MAX_STATS ; i++ )
        pet->perm_stat[i] = 100 + (ench_skill*3);

    for( i = 0 ; i < 4 ; i++ )
        pet->armor[i] = ench_skill * 75 / 100;
    pet->armor[3] /= 4;

    pet->hitroll = ench_skill * 8 / 10;
    pet->damage[0] = 2;
    pet->damage[1] = 6;
    pet->damage[2] = ench_skill * 25 / 100;

	/* Golem resists */
	setResist( pet, RESIST_FIRE, 	ench_skill - 25 );
	setResist( pet, RESIST_ICE,  	ench_skill - 25 );
	setResist( pet, RESIST_EARTH, 	ench_skill + 40 );
	setResist( pet, RESIST_AIR,		ench_skill /  2 );
	setResist( pet, RESIST_LIGHT,	0 );
	setResist( pet, RESIST_DARK,	0 );
	setResist( pet, RESIST_POISON,	RESIST_IMMUNE );
	setResist( pet, RESIST_DISEASE, RESIST_IMMUNE );
	setResist( pet, RESIST_MENTAL,	RESIST_IMMUNE );
	setResist( pet, RESIST_ACID, 	ench_skill / 2 - 25 );
	setResist( pet, RESIST_ELECTRICITY,	ench_skill / 2 - 75 );
	setResist( pet, RESIST_SPIRIT,	0 );
	setResist( pet, RESIST_SOUND,	ench_skill / 2 );
	setResist( pet, RESIST_WATER,	ench_skill / 2 - 25 );
	setResist( pet, RESIST_BODY,	RESIST_IMMUNE );
	setResist( pet, RESIST_SLASH,	ench_skill - 50 );
	setResist( pet, RESIST_CONCUSSION,	ench_skill - 25 );
	setResist( pet, RESIST_PIERCE,	ench_skill );

    snprintf(buf,sizeof(buf),"clay golem");
    free_string( pet->name );
    pet->name = str_dup( buf );

    snprintf(buf,sizeof(buf),"a clay golem");
    free_string( pet->short_descr );
    pet->short_descr = str_dup( buf );

    snprintf(buf,sizeof(buf),"A clay golem stands at attention here.\n\r");
    free_string( pet->long_descr );
    pet->long_descr = str_dup( buf );

    act("$n is woven into existance from the fabric of magic.", pet,NULL,NULL,TO_ROOM);
    act("$N gazes at $n with empty eyes, awaiting instructions.", ch,NULL,pet,TO_NOTVICT);
    act("$N gazes at you with empty eyes, awaiting instructions.", ch,NULL,pet,TO_CHAR);
    add_follower( pet, ch );
    pet->leader = ch;
    pet_to_group( ch, pet );
	return TRUE;
}

bool spell_wood_golem( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet;
    int i;
	int ench_skill;
	int hp_max;
    char buf[MAX_STRING_LENGTH];

    if( ch->pet != NULL )
    {
        cprintf(ch,"Dismiss the one you have!\n\r");
        return FALSE;
    }

    pet = create_mobile( get_mob_index( VNUM_GOLEM ) );
    SET_BIT(pet->act, ACT_PET);
    SET_BIT(pet->affected_by, AFF_CHARM);
    SET_BIT(pet->form, FORM_CONSTRUCTED);
    pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
    char_to_room( pet, ch->in_room );
    ch->pet = pet;

    pet->class = csn_paladin;
    ench_skill = get_skill(ch,skill_lookup("enchantment"));
    hp_max = ench_skill * 24;
    pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
    pet->max_base_hit = pet->max_stat_hit / 5;
    pet->stat_hit = pet->max_stat_hit;
    pet->base_hit = pet->max_base_hit;
    pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000; /* these guys never exhaust */
    pet->level = ch->level;

    for( i = 0; i < MAX_STATS ; i++ )
        pet->perm_stat[i] = 100 + (ench_skill*3);

    for( i = 0 ; i < 4 ; i++ )
        pet->armor[i] = ench_skill;
    pet->armor[3] /= 4;

    pet->hitroll = ench_skill;
    pet->damage[0] = 3;
    pet->damage[1] = 6;
    pet->damage[2] = ench_skill * 30 / 100;

	/* Golem resists */
	setResist( pet, RESIST_FIRE, 	ench_skill - 100 );
	setResist( pet, RESIST_ICE,  	ench_skill );
	setResist( pet, RESIST_EARTH, 	ench_skill );
	setResist( pet, RESIST_AIR,		ench_skill / 2 );
	setResist( pet, RESIST_LIGHT,	0 );
	setResist( pet, RESIST_DARK,	0 );
	setResist( pet, RESIST_POISON,	ench_skill );
	setResist( pet, RESIST_DISEASE, ench_skill );
	setResist( pet, RESIST_MENTAL,	RESIST_IMMUNE );
	setResist( pet, RESIST_ACID, 	ench_skill / 2 - 50 );
	setResist( pet, RESIST_ELECTRICITY,	ench_skill / 2 - 25 );
	setResist( pet, RESIST_SPIRIT,	0 );
	setResist( pet, RESIST_SOUND,	ench_skill );
	setResist( pet, RESIST_WATER,	ench_skill );
	setResist( pet, RESIST_BODY,	RESIST_IMMUNE );
	setResist( pet, RESIST_SLASH,	ench_skill - 75 );
	setResist( pet, RESIST_CONCUSSION,	ench_skill / 2 );
	setResist( pet, RESIST_PIERCE,	ench_skill * 2 / 3 );

    snprintf(buf,sizeof(buf),"wood golem");
    free_string( pet->name );
    pet->name = str_dup( buf );

    snprintf(buf,sizeof(buf),"a wood golem");
    free_string( pet->short_descr );
    pet->short_descr = str_dup( buf );

    snprintf(buf,sizeof(buf),"A wood golem stands at attention here.\n\r");
    free_string( pet->long_descr );
    pet->long_descr = str_dup( buf );

    act("$n is woven into existance from the fabric of magic.", pet,NULL,NULL,TO_ROOM);
    act("$N gazes at $n with empty eyes, awaiting instructions.", ch,NULL,pet,TO_NOTVICT);
    act("$N gazes at you with empty eyes, awaiting instructions.", ch,NULL,pet,TO_CHAR);
    add_follower( pet, ch );
    pet->leader = ch;
    pet_to_group( ch, pet );
	return TRUE;
}

bool spell_glass_golem( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet;
    int i;
	int ench_skill;
	int hp_max;
    char buf[MAX_STRING_LENGTH];

    if( ch->pet != NULL )
    {
        cprintf(ch,"Dismiss the one you have!\n\r");
        return FALSE;
    }

    pet = create_mobile( get_mob_index( VNUM_GOLEM ) );
    SET_BIT(pet->act, ACT_PET);
    SET_BIT(pet->affected_by, AFF_CHARM);
    SET_BIT(pet->form, FORM_CONSTRUCTED);
    pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
    char_to_room( pet, ch->in_room );
    ch->pet = pet;

    pet->class = csn_fighter;
    ench_skill = get_skill(ch,skill_lookup("enchantment"));
    hp_max = ench_skill * 36;
    pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
    pet->max_base_hit = pet->max_stat_hit / 5;
    pet->stat_hit = pet->max_stat_hit;
    pet->base_hit = pet->max_base_hit;
    pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000; /* these guys never exhaust */
    pet->level = ch->level;

    for( i = 0; i < MAX_STATS ; i++ )
        pet->perm_stat[i] = 100 + (ench_skill*3);

    for( i = 0 ; i < 4 ; i++ )
        pet->armor[i] = ench_skill * 125 / 100;
    pet->armor[3] /= 4;

    pet->hitroll = ench_skill * 12 / 10;
    pet->damage[0] = 4;
    pet->damage[1] = 6;
    pet->damage[2] = ench_skill * 35 / 100;

	/* Golem resists */
	setResist( pet, RESIST_FIRE, 	ench_skill + 40 );
	setResist( pet, RESIST_ICE,  	ench_skill + 40 );
	setResist( pet, RESIST_EARTH, 	ench_skill  * 3 / 2 - 75 );
	setResist( pet, RESIST_AIR,		ench_skill + 40 );
	setResist( pet, RESIST_LIGHT,	ench_skill + 40 );
	setResist( pet, RESIST_DARK,	ench_skill + 40 );
	setResist( pet, RESIST_POISON,	RESIST_IMMUNE );
	setResist( pet, RESIST_DISEASE, RESIST_IMMUNE );
	setResist( pet, RESIST_MENTAL,	RESIST_IMMUNE );
	setResist( pet, RESIST_ACID, 	RESIST_IMMUNE );
	setResist( pet, RESIST_ELECTRICITY,	ench_skill + 40 );
	setResist( pet, RESIST_SPIRIT,	0 );
	setResist( pet, RESIST_SOUND,	ench_skill + 40 );
	setResist( pet, RESIST_WATER,	ench_skill + 40 );
	setResist( pet, RESIST_BODY,	RESIST_IMMUNE );
	setResist( pet, RESIST_SLASH,	ench_skill - 100 );
	setResist( pet, RESIST_CONCUSSION,	ench_skill - 100 );
	setResist( pet, RESIST_PIERCE,	ench_skill - 100 );

    snprintf(buf,sizeof(buf),"glass golem");
    free_string( pet->name );
    pet->name = str_dup( buf );

    snprintf(buf,sizeof(buf),"a glass golem");
    free_string( pet->short_descr );
    pet->short_descr = str_dup( buf );

    snprintf(buf,sizeof(buf),"A glass golem stands at attention here.\n\r");
    free_string( pet->long_descr );
    pet->long_descr = str_dup( buf );

    act("$n is woven into existance from the fabric of magic.", pet,NULL,NULL,TO_ROOM);
    act("$N gazes at $n with empty eyes, awaiting instructions.", ch,NULL,pet,TO_NOTVICT);
    act("$N gazes at you with empty eyes, awaiting instructions.", ch,NULL,pet,TO_CHAR);
    add_follower( pet, ch );
    pet->leader = ch;
    pet_to_group( ch, pet );
	return TRUE;
}

bool spell_stone_golem( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet;
    int i;
	int ench_skill;
	int hp_max;
    char buf[MAX_STRING_LENGTH];

    if( ch->pet != NULL )
    {
        cprintf(ch,"Dismiss the one you have!\n\r");
        return FALSE;
    }

    pet = create_mobile( get_mob_index( VNUM_GOLEM ) );
    SET_BIT(pet->act, ACT_PET);
    SET_BIT(pet->affected_by, AFF_CHARM);
    SET_BIT(pet->form, FORM_CONSTRUCTED);
    pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
    char_to_room( pet, ch->in_room );
    ch->pet = pet;

    pet->class = csn_fighter;
    ench_skill = get_skill(ch,skill_lookup("enchantment"));
    hp_max = ench_skill * 48;
    pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
    pet->max_base_hit = pet->max_stat_hit / 5;
    pet->stat_hit = pet->max_stat_hit;
    pet->base_hit = pet->max_base_hit;
    pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000; /* these guys never exhaust */
    pet->level = ch->level;

    for( i = 0; i < MAX_STATS ; i++ )
        pet->perm_stat[i] = 100 + (ench_skill*3);

    for( i = 0 ; i < 4 ; i++ )
        pet->armor[i] = ench_skill * 150 / 100;
    pet->armor[3] /= 4;

    pet->hitroll = ench_skill * 14 / 10;
    pet->damage[0] = 4;
    pet->damage[1] = 6;
    pet->damage[2] = ench_skill * 40 / 100;

	/* Golem resists */
	setResist( pet, RESIST_FIRE, 	0 );
	setResist( pet, RESIST_ICE,  	ench_skill / 2 - 25 );
	setResist( pet, RESIST_EARTH, 	ench_skill - 75 );
	setResist( pet, RESIST_AIR,		ench_skill );
	setResist( pet, RESIST_LIGHT,	0 );
	setResist( pet, RESIST_DARK,	0 );
	setResist( pet, RESIST_POISON,	RESIST_IMMUNE );
	setResist( pet, RESIST_DISEASE, RESIST_IMMUNE );
	setResist( pet, RESIST_MENTAL,	RESIST_IMMUNE );
	setResist( pet, RESIST_ACID, 	ench_skill - 100 );
	setResist( pet, RESIST_ELECTRICITY,	ench_skill / 2 );
	setResist( pet, RESIST_SPIRIT,	0 );
	setResist( pet, RESIST_SOUND,	ench_skill / 2 + 25 );
	setResist( pet, RESIST_WATER,	ench_skill / 2 + 25 );
	setResist( pet, RESIST_BODY,	RESIST_IMMUNE );
	setResist( pet, RESIST_SLASH,	ench_skill / 2 );
	setResist( pet, RESIST_CONCUSSION,	0 );
	setResist( pet, RESIST_PIERCE,	ench_skill / 2 );

    snprintf(buf,sizeof(buf),"stone golem");
    free_string( pet->name );
    pet->name = str_dup( buf );

    snprintf(buf,sizeof(buf),"a stone golem");
    free_string( pet->short_descr );
    pet->short_descr = str_dup( buf );

    snprintf(buf,sizeof(buf),"A stone golem stands at attention here.\n\r");
    free_string( pet->long_descr );
    pet->long_descr = str_dup( buf );

    act("$n is woven into existance from the fabric of magic.", pet,NULL,NULL,TO_ROOM);
    act("$N gazes at $n with empty eyes, awaiting instructions.", ch,NULL,pet,TO_NOTVICT);
    act("$N gazes at you with empty eyes, awaiting instructions.", ch,NULL,pet,TO_CHAR);
    add_follower( pet, ch );
    pet->leader = ch;
    pet_to_group( ch, pet );

	return TRUE;
}

bool spell_iron_golem( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet;
    int i;
	int ench_skill;
	int hp_max;
    char buf[MAX_STRING_LENGTH];

    if( ch->pet != NULL )
    {
        cprintf(ch,"Dismiss the one you have!\n\r");
        return FALSE;
    }

    pet = create_mobile( get_mob_index( VNUM_GOLEM ) );
    SET_BIT(pet->act, ACT_PET);
    SET_BIT(pet->affected_by, AFF_CHARM);
    SET_BIT(pet->form, FORM_CONSTRUCTED);
    pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
    char_to_room( pet, ch->in_room );
    ch->pet = pet;

    pet->class = csn_barbarian;
    ench_skill = get_skill(ch,skill_lookup("enchantment"));
    hp_max = ench_skill * 70;
    pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
    pet->max_base_hit = pet->max_stat_hit / 5;
    pet->stat_hit = pet->max_stat_hit;
    pet->base_hit = pet->max_base_hit;
    pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000; /* these guys never exhaust */
    pet->level = ch->level;

    for( i = 0; i < MAX_STATS ; i++ )
        pet->perm_stat[i] = 100 + (ench_skill*3);

    for( i = 0 ; i < 4 ; i++ )
        pet->armor[i] = ench_skill * 175 / 100;
    pet->armor[3] /= 4;

    pet->hitroll = ench_skill * 16 / 10;
    pet->damage[0] = 4;
    pet->damage[1] = 6;
    pet->damage[2] = ench_skill * 45 / 100;

	/* Golem resists */
	setResist( pet, RESIST_FIRE, 	ench_skill / 2 - 25 );
	setResist( pet, RESIST_ICE,  	ench_skill / 2 - 25 );
	setResist( pet, RESIST_EARTH, 	0 );
	setResist( pet, RESIST_AIR,		ench_skill /2 + 25 );
	setResist( pet, RESIST_LIGHT,	0 );
	setResist( pet, RESIST_DARK,	0 );
	setResist( pet, RESIST_POISON,	RESIST_IMMUNE );
	setResist( pet, RESIST_DISEASE, RESIST_IMMUNE );
	setResist( pet, RESIST_MENTAL,	RESIST_IMMUNE );
	setResist( pet, RESIST_ACID, 	ench_skill - 100 );
	setResist( pet, RESIST_ELECTRICITY,	ench_skill - 100 );
	setResist( pet, RESIST_SPIRIT,	0 );
	setResist( pet, RESIST_SOUND,	ench_skill / 2 + 25 );
	setResist( pet, RESIST_WATER,	ench_skill / 2 + 25 );
	setResist( pet, RESIST_BODY,	RESIST_IMMUNE );
	setResist( pet, RESIST_SLASH,	ench_skill / 2 );
	setResist( pet, RESIST_CONCUSSION,	ench_skill / 2 );
	setResist( pet, RESIST_PIERCE,	ench_skill / 2 + 25 );

    snprintf(buf,sizeof(buf),"iron golem");
    free_string( pet->name );
    pet->name = str_dup( buf );

    snprintf(buf,sizeof(buf),"a iron golem");
    free_string( pet->short_descr );
    pet->short_descr = str_dup( buf );

    snprintf(buf,sizeof(buf),"A iron golem stands at attention here.\n\r");
    free_string( pet->long_descr );
    pet->long_descr = str_dup( buf );

    act("$n is woven into existance from the fabric of magic.", pet,NULL,NULL,TO_ROOM);
    act("$N gazes at $n with empty eyes, awaiting instructions.", ch,NULL,pet,TO_NOTVICT);
    act("$N gazes at you with empty eyes, awaiting instructions.", ch,NULL,pet,TO_CHAR);
    add_follower( pet, ch );
    pet->leader = ch;
    pet_to_group( ch, pet );
	return TRUE;
}

bool spell_mithril_golem( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet;
    int i;
	int ench_skill;
	int hp_max;
    char buf[MAX_STRING_LENGTH];

    if( ch->pet != NULL )
    {
        cprintf(ch,"Dismiss the one you have!\n\r");
        return FALSE;
    }

    pet = create_mobile( get_mob_index( VNUM_GOLEM ) );
    SET_BIT(pet->act, ACT_PET);
    SET_BIT(pet->affected_by, AFF_CHARM);
    SET_BIT(pet->form, FORM_CONSTRUCTED);
    pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
    char_to_room( pet, ch->in_room );
    ch->pet = pet;

    pet->class = csn_barbarian;
    ench_skill = get_skill(ch,skill_lookup("enchantment"));
    hp_max = ench_skill * 85;
    pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
    pet->max_base_hit = pet->max_stat_hit / 5;
    pet->stat_hit = pet->max_stat_hit;
    pet->base_hit = pet->max_base_hit;
    pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000; /* these guys never exhaust */
    pet->level = ch->level;

    for( i = 0; i < MAX_STATS ; i++ )
        pet->perm_stat[i] = 100 + (ench_skill*3);

    for( i = 0 ; i < 4 ; i++ )
        pet->armor[i] = ench_skill * 2 / 1;
    pet->armor[3] /= 4;

    pet->hitroll = ench_skill * 18 / 10;
    pet->damage[0] = 4;
    pet->damage[1] = 6;
    pet->damage[2] = ench_skill * 5 / 10;

	/* Golem resists */
	setResist( pet, RESIST_FIRE, 	50 );
	setResist( pet, RESIST_ICE,  	50 );
	setResist( pet, RESIST_EARTH, 	50 );
	setResist( pet, RESIST_AIR,		50 );
	setResist( pet, RESIST_LIGHT,	50 );
	setResist( pet, RESIST_DARK,	50 );
	setResist( pet, RESIST_POISON,	RESIST_IMMUNE );
	setResist( pet, RESIST_DISEASE, RESIST_IMMUNE );
	setResist( pet, RESIST_MENTAL,	RESIST_IMMUNE );
	setResist( pet, RESIST_ACID, 	ench_skill / 2 );
	setResist( pet, RESIST_ELECTRICITY,	50 );
	setResist( pet, RESIST_SPIRIT,	0 );
	setResist( pet, RESIST_SOUND,	50 );
	setResist( pet, RESIST_WATER,	50 );
	setResist( pet, RESIST_BODY,	RESIST_IMMUNE );
	setResist( pet, RESIST_SLASH,	50 );
	setResist( pet, RESIST_CONCUSSION,	50 );
	setResist( pet, RESIST_PIERCE,	50 );

    snprintf(buf,sizeof(buf),"mithril golem");
    free_string( pet->name );
    pet->name = str_dup( buf );

    snprintf(buf,sizeof(buf),"a mithril golem");
    free_string( pet->short_descr );
    pet->short_descr = str_dup( buf );

    snprintf(buf,sizeof(buf),"A mithril golem stands at attention here.\n\r");
    free_string( pet->long_descr );
    pet->long_descr = str_dup( buf );

    act("$n is woven into existance from the fabric of magic.", pet,NULL,NULL,TO_ROOM);
    act("$N gazes at $n with empty eyes, awaiting instructions.", ch,NULL,pet,TO_NOTVICT);
    act("$N gazes at you with empty eyes, awaiting instructions.", ch,NULL,pet,TO_CHAR);
    add_follower( pet, ch );
    pet->leader = ch;
    pet_to_group( ch, pet );
	return TRUE;
}
