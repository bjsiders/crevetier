/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
****************************************************************************/

/*
    This file.h is merely an organization of all of our header files, ensuring
    that they're all loaded in the proper order into the game for happy
    compiling.

    Eventually, including thoc.h should be all that's needed for any thoc
    build, although it will mean included some headers you don't technically
    need.
*/

#ifndef thoc_h /* begin thoc_h */
#define thoc_h

#define Version "$Name: crev-1-11-414 $"
#define NO_MMCHECK

/*
    System headers
*/
#include <ctype.h>
#include <dirent.h>
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <netdb.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

/*
    Garbage Collector header
*/
#include "gc.h"

/*
    THOC Defintions, Typedefs, etc
*/
#include "bits.h"
#include "defines.h"
#include "thoctype.h"
#include "vnums.h"

/*
    THOC Basic Structures, Globals, etc
*/
#include "init.h"
#include "game.h"
#include "global.h"
#include "thocerror.h"

#include "area.h"
#include "interp.h"
#include "npc_ai.h"
#include "tables.h"
#include "world.h"
#include "area.h"
#include "affect.h"
#include "communicate.h"
#include "class.h"
#include "currency.h"
#include "combat.h"
#include "craft.h"
#include "magic.h"
#include "network.h"
#include "notes.h"
#include "skills.h"
#include "stack.h"
#include "faction.h"
#include "guild.h"
#include "journal.h"
#include "resist.h"
#include "stack.h"
#include "race.h"
#include "quest.h"
#include "account.h"
#include "character.h"
#include "object.h"
#include "room.h"
#include "ban.h"
#include "track.h"
#include "proto.h"
#include "recycle.h"
#include "olc.h"

extern void *rgFreeList[MAX_MEM_LIST];
extern const int rgSizeList[MAX_MEM_LIST];
extern int nAllocString;
extern int sAllocString;
extern int nAllocPerm;
extern int sAllocPerm;

#define fread_letter(fp)      (thoc_fread_letter(__FILE__,__LINE__,(fp)))
#define fread_number(fp)      (thoc_fread_number(__FILE__,__LINE__,(fp)))
#define fread_long(fp)        (thoc_fread_long(__FILE__,__LINE__,(fp)))
#define fread_longflag(fp)    (thoc_fread_longflag(__FILE__,__LINE__,(fp)))
#define fread_flag(fp)        (thoc_fread_flag(__FILE__,__LINE__,(fp)))
#define fread_string(fp)      (thoc_fread_string(__FILE__,__LINE__,(fp)))
#define fread_string_eol(fp)  (thoc_fread_string_eol(__FILE__,__LINE__,(fp)))
#define fread_to_eol(fp)      (thoc_fread_to_eol(__FILE__,__LINE__,(fp)))
#define fread_to_char(fp,ch)  (thoc_fread_to_char(__FILE__,__LINE__,(fp),(ch)))
#define fread_word(fp)        (thoc_fread_word(__FILE__,__LINE__,(fp)))
#define free_mem(pMem,sMem)   (thoc_free_mem(pMem,sMem,__FILE__,__LINE__))
#define convertTimeString(s)  (thoc_convertTimeString(s))
#define dice(n,s)             (thoc_dice((n),(s)))
#define str_cmp(a,b)          (thoc_str_cmp((a),(b)))
#define str_prefix(a,b)       (thoc_str_prefix((a),(b)))
#define str_infix(a,b)        (thoc_str_infix((a),(b)))
#define str_suffix(a,b)       (thoc_str_suffix((a),(b)))
#define capitalize(s)         (thoc_capitalize(s))
#define getFileName(d,f)      (thoc_getFileName((d),(f)))
#define append_file(f,d)      (thoc_append_file((f),(d)))
#define str_dup(s)            (thoc_str_dup(s))
#define number_fuzzy(n)       (thoc_number_fuzzy(n))
#define number_range(f,t)     (thoc_number_range((f),(t)))
#define number_percent()      (thoc_number_percent())
#define number_door()         (thoc_number_door())
#define number_bits(w)        (thoc_number_bits(w))
#define free_string(p)        (thoc_free_string(p))
#define alloc_mem(s)          (thoc_alloc_mem(s))
#define alloc_perm(s)         (thoc_alloc_perm(s))
#define smash_tilde(s)        (thoc_smash_tilde(s))
#define init_mm()             (thoc_init_mm())
#define number_mm()           (thoc_number_mm())

char thoc_fread_letter          ( char *sourceFile, int lineNumber, FILE *fp );
int thoc_fread_number           ( char *sourceFile, int lineNumber, FILE *fp );
long thoc_fread_long            ( char *srcFile, int line, FILE *fp );
long long thoc_fread_longflag   ( char *srcFile, int line, FILE *fp);
long thoc_fread_flag            ( char *srcFile, int line, FILE *fp);
long long thoc_longflag_convert (char letter);
long thoc_flag_convert          (char letter );
char *thoc_fread_string         ( char *srcF, int line, FILE *fp );
char *thoc_fread_string_eol     ( char *srcF, int line, FILE *fp );
void thoc_fread_to_eol          ( char *srcF, int line, FILE *fp );
char *thoc_fread_to_char        ( char *srcF, int line, FILE *fp, char whichChar );
char *thoc_fread_word           ( char *srcF, int line, FILE *fp );
void *thoc_alloc_mem            ( int sMem );
void thoc_free_mem              ( void *pMem, int sMem, char *file, int line );
void *thoc_alloc_perm           ( int sMem );
char *thoc_str_dup              ( const char *str );
void thoc_free_string           ( char *pstr );
int thoc_number_fuzzy           ( int number );
int thoc_number_range           ( int from, int to );
int thoc_number_percent         ( void );
int thoc_number_door            ( void );
int thoc_number_bits            ( int width );
void thoc_init_mm               ( );
long thoc_number_mm             ( void );
int thoc_dice                   ( int number, int size );
int thoc_interpolate            ( int level, int value_00, int value_32 );
void thoc_smash_tilde           ( char *str );
bool thoc_str_cmp               ( const char *astr, const char *bstr );
bool thoc_str_prefix            ( const char *astr, const char *bstr );
bool thoc_str_infix             ( const char *astr, const char *bstr );
bool thoc_str_suffix            ( const char *astr, const char *bstr );
char *thoc_capitalize           ( const char *str );
void bug                        ( const char *str, ... );
void log_error                  ( const char *str, ... );
void log_string                 ( const char *str, ... );
char * thoc_getFileName         ( char *dir, char *file );
time_t thoc_convertTimeString   ( const char *string );
void thoc_append_file           ( char *file, char *str );
void tail_chain                 ( );
bool is_number                  ( char *arg );
int number_argument             ( char *argument, char *arg );
char *one_argument_cs           ( char *argument, char *arg_first );
char *one_argument              ( char *argument, char *arg_first );
int mult_argument               ( char *argument, char *arg);
char *format_date               ( time_t string, const char *fmt );
bool is_name                    ( char *str, char *namelist );
bool is_exact_name              (char *str, char *namelist );
char *ratio_color               ( int cur, int max, bool fMANA  );
int con_diff                    ( int level1, int level2 );
char get_con_color              ( int level1, int level2 );
int strlen_nocol                ( char *x );
void applySkillAdjust           ( int *val, int base, int numer, int denom );
float getDPS                    ( int numDice, int typeDice, int tSecs );
long set10Bits                  ( long vector, long value );
long set20Bits                  ( long vector, long value );
long get10Bits                  ( long vector );
long get20Bits                  ( long vector );


#endif /* thoc_h */
