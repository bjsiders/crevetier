/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include <sys/types.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "thoc.h"
#include "olc.h"
#include "tables.h"
#include "lookup.h"
#include "recycle.h"
#include "spawn.h"

bool change_exit( Character *ch, char *argument, int door );

int getNextOpenVnum( Area *area )
{
	int lvnum = area->lvnum;
	int uvnum = area->uvnum;
	int i;

	for ( i = lvnum ; i <= uvnum ; i++ )
		if ( get_room_index( i ) == NULL )
			return i;

	return -1;
}

void walkBuild( Character *ch, int door, Area *area )
{
	int vnum;
	char buf[MAX_STRING_LENGTH];

	/* If an exit exists, just follow it */
	if ( ch->in_room->exit[door] != NULL )
		return;

	if ( ( vnum = getNextOpenVnum( area )) <= 0 )
	{
		cprintf(ch,"Your area is out of open vnums!\n\r");
		return;
	}

	snprintf(buf,sizeof(buf),"%d",vnum);
	redit_create( ch, buf );
	snprintf(buf,sizeof(buf),"link %d",vnum);
	change_exit( ch, buf, door);
	cprintf(ch," &R**&x WalkBuild created room %d for you\n\r", vnum );
	return;
}

REDIT( redit_mlist )
{
    MobIndex	*pMobIndex;
    Area		*pArea;
    char		buf  [ MAX_STRING_LENGTH   ];
    char		buf1 [ MAX_STRING_LENGTH*2 ];
    char		arg  [ MAX_INPUT_LENGTH    ];
    bool fAll, found;
    int vnum;
    int  col = 0;

    one_argument( argument, arg );
    if ( arg[0] == '\0' )
    {
	send_to_char( "Syntax:  mlist <all/name>\n\r", ch );
	return FALSE;
    }

    pArea = ch->in_room->area;
    buf1[0] = '\0';
    fAll    = !str_cmp( arg, "all" );
    found   = FALSE;

    for ( vnum = pArea->lvnum; vnum <= pArea->uvnum; vnum++ )
    {
	if ( ( pMobIndex = get_mob_index( vnum ) ) )
	{
	    if ( fAll || is_name( arg, pMobIndex->player_name ) )
	    {
		found = TRUE;
		sprintf( buf, "[%5d] %-17.16s",
		    pMobIndex->vnum, capitalize( pMobIndex->short_descr ) );
		strcat( buf1, buf );
		if ( ++col % 3 == 0 )
		    strcat( buf1, "\n\r" );
	    }
	}
    }

    if ( !found )
    {
	send_to_char( "Mobile(s) not found in this area.\n\r", ch);
	return FALSE;
    }

    if ( col % 3 != 0 )
	strcat( buf1, "\n\r" );

    send_to_char( buf1, ch );
    return FALSE;
}



REDIT( redit_olist )
{
    ObjIndex	*pObjIndex;
    Area		*pArea;
    char		buf  [ MAX_STRING_LENGTH   ];
    char		buf1 [ MAX_STRING_LENGTH*2 ];
    char		arg  [ MAX_INPUT_LENGTH    ];
    bool fAll, found;
    int vnum;
    int  col = 0;

    one_argument( argument, arg );
    if ( arg[0] == '\0' )
    {
	send_to_char( "Syntax:  olist <all/name/item_type>\n\r", ch );
	return FALSE;
    }

    pArea = ch->in_room->area;
    buf1[0] = '\0';
    fAll    = !str_cmp( arg, "all" );
    found   = FALSE;

    for ( vnum = pArea->lvnum; vnum <= pArea->uvnum; vnum++ )
    {
	if ( ( pObjIndex = get_obj_index( vnum ) ) )
	{
	    if ( fAll || is_name( arg, pObjIndex->name )
	    || flag_value( type_flags, arg ) == pObjIndex->item_type )
	    {
		found = TRUE;
		sprintf( buf, "[%5d] %-17.16s",
		    pObjIndex->vnum, capitalize( pObjIndex->short_descr ) );
		strcat( buf1, buf );
		if ( ++col % 3 == 0 )
		    strcat( buf1, "\n\r" );
	    }
	}
    }

    if ( !found )
    {
	send_to_char( "Object(s) not found in this area.\n\r", ch);
	return FALSE;
    }

    if ( col % 3 != 0 )
	strcat( buf1, "\n\r" );

    send_to_char( buf1, ch );
    return FALSE;
}



REDIT( redit_mshow )
{
    MobIndex *pMob;
    int value;

    if ( argument[0] == '\0' )
    {
	send_to_char( "Syntax:  mshow <vnum>\n\r", ch );
	return FALSE;
    }

    if ( is_number( argument ) )
    {
	value = atoi( argument );
	if ( !( pMob = get_mob_index( value ) ))
	{
	    send_to_char( "REdit:  That mobile does not exist.\n\r", ch );
	    return FALSE;
	}

	ch->desc->pEdit = (void *)pMob;
    }
 
    medit_show( ch, argument );
    ch->desc->pEdit = (void *)ch->in_room;
    return FALSE; 
}



REDIT( redit_oshow )
{
    ObjIndex *pObj;
    int value;

    if ( argument[0] == '\0' )
    {
	send_to_char( "Syntax:  oshow <vnum>\n\r", ch );
	return FALSE;
    }

    if ( is_number( argument ) )
    {
	value = atoi( argument );
	if ( !( pObj = get_obj_index( value ) ))
	{
	    send_to_char( "REdit:  That object does not exist.\n\r", ch );
	    return FALSE;
	}

	ch->desc->pEdit = (void *)pObj;
    }
 
    oedit_show( ch, argument );
    ch->desc->pEdit = (void *)ch->in_room;
    return FALSE; 
}

/*
 * Room Editor Functions.
 */
REDIT( redit_show )
{
    Room	    *pRoom;
    Object		*obj;
    Character	*rch;
    int			door;
    bool		fcnt;
    char        buf[MAX_STRING_LENGTH];
    
    EDIT_ROOM(ch, pRoom);

    cprintf( ch, "Description:\n\r%s\n\r", pRoom->description );
    cprintf( ch, "Name:         [%s]\n\r"
                 "Area:         [%5d] %s\n\r",
	    pRoom->name, pRoom->area->vnum, pRoom->area->name );
    cprintf( ch, "Vnum:         [%5d]\n\r"
                 "Sector:       [%s]\n\r",
	    pRoom->vnum, flag_string( sector_flags, pRoom->sector_type ) );
    cprintf( ch, "Heal Rate:    [%d]\n\r"
                 "Mana Rate:    [%d]\n\r",
	    pRoom->heal_rate, pRoom->mana_rate );
    cprintf( ch, "Room flags:   [%s]\n\r",
	    flag_string( room_flags, pRoom->room_flags ) );
    cprintf( ch, "Clan owner:   [%s]\n\r", pRoom->clan == NULL  ? "none" : pRoom->clan->name );
    cprintf( ch, "Class allow:  [%s]\n\r", pRoom->guild < 0 ? "any" : class_table[pRoom->guild].name);

    if ( pRoom->extra_descr )
    {
	    ExtraDescr *ed;

	    cprintf( ch, "Desc Kwds:    [ " );
	    for ( ed = pRoom->extra_descr; ed; ed = ed->next )
	        cprintf( ch, "%s ", ed->keyword );
	    cprintf( ch, "]\n\r" );
    }

    cprintf( ch, "Characters:   [ " );
    fcnt = FALSE;
    for ( rch = pRoom->people; rch; rch = rch->next_in_room )
    {
	    one_argument( rch->name, buf );
	    cprintf(ch,"%s ",buf);
	    fcnt = TRUE;
    }

    if ( fcnt )
	    cprintf(ch,"]\n\r");
    else
        cprintf(ch,"none ]\n\r");

    cprintf(ch, "Objects:      [ " );
    fcnt = FALSE;
    for ( obj = pRoom->contents; obj; obj = obj->next_content )
    {
	    one_argument( obj->name, buf );
        cprintf(ch,"%s ",buf);
	    fcnt = TRUE;
    }

    if ( fcnt )
	    cprintf(ch," ]\n\r");
    else
	    cprintf(ch,"none ]\n\r");

    cprintf(ch,"Exits:\n\r");
    for ( door = 0; door < MAX_DIR; door++ )
    {
	    Exit *pexit;

	    if ( ( pexit = pRoom->exit[door] ) )
	    {
            ObjIndex *o = pexit->key > 0 ? get_obj_index( pexit->key ) : NULL;

            cprintf(ch,"  %-5s\n\r"
                       "    Destination Room:   [%5d: %s]\n\r"
                       "    Key:                [%5d: %s]\n\r"
                       "    Current Exit Flags: [%s]\n\r",
		        capitalize(dir_name[door]),
		        pexit->u1.to_room ? pexit->u1.to_room->vnum : 0,
                pexit->u1.to_room ? pexit->u1.to_room->name : "none",
                pexit->key, o ? o->short_descr : "none",
		        flag_string(exit_flags,pexit->exit_info ) );
        
            cprintf(ch,"    RSInfo Flags:       [%s]\n\r"
                       "    Keywords:           [%s]\n\r"
                       "    Long Description:   [%s]\n\r",
                flag_string(exit_flags,pexit->rs_flags),
                pexit->keyword != NULL && str_cmp(pexit->keyword,"(null)") ? pexit->keyword : "none",
                pexit->description != NULL && str_cmp(pexit->keyword,"(null)") ? pexit->description : "none");
        }
    }

    return FALSE;
}


REDIT( redit_flag )
{
    Room *pRoom;
    int value;

    if ( argument[0] != '\0' )
    {
	EDIT_ROOM(ch, pRoom);

	if ( ( value = flag_value( room_flags, argument ) ) != NO_FLAG )
	{
	    if ( value == ROOM_IMP_ONLY && ch->level < 59 )
	    {
		cprintf(ch,"You must be at least level 59 to set this flag.\n\r");
		return FALSE;
	    }

	    TOGGLE_BIT(pRoom->room_flags, value);

	    send_to_char( "Room flag toggled.\n\r", ch);
	    return TRUE;
	}
    }

    send_to_char( "Syntax:  flag [flag]\n\r"
		  "Type '? room' for a list of flags.\n\r", ch );
    return FALSE;
}

REDIT( redit_class )
{
    Room *pRoom;
    int value;

    if ( argument[0] != '\0' )
    {
        EDIT_ROOM(ch, pRoom);

        if ( ( value =  class_lookup( argument ) ) >= 0 )
        {
            pRoom->guild = value;
	    	cprintf(ch,"CLASS ALLOWED set to '%s'.\n\r", class_table[value].name);
            return TRUE;
        }

		if ( !strcmp(argument,"none") || !strcmp(argument,"any") )
		{
			pRoom->guild = -1;
			cprintf(ch,"CLASS ALLOWED set to any.\n\r");
			return TRUE;
		}

    }

    send_to_char( "Syntax:  class [class_name]\n\r", ch );
    return FALSE;
}

REDIT( redit_clan )
{
    Room *pRoom;
    Clan * value;

    if ( argument[0] != '\0' )
    {
        EDIT_ROOM(ch, pRoom);

		if ( !str_cmp(argument,"none") )
		{
			pRoom->clan = NULL;
			cprintf(ch,"CLAN OWNER set to none.\n\r");
			return FALSE;
		}

        if ( ( value =  clan_lookup( argument ) ) > 0 )
        {
	    	if ( clan_is_independent( value ) )
 	    	{
	        	cprintf(ch,"Independent clans don't get to own halls.\n\r");
				return FALSE;
	    	}

            pRoom->clan = value;

            cprintf(ch,"CLAN OWNER set to '%s'.\n\r", value->name );

            return TRUE;
        }
    }

    send_to_char( "Syntax:  clan [clan_name] (none to reset it)\n\r"
                  "Type '? clan' for a list of clans.\n\r", ch );
    return FALSE;
}

REDIT( redit_sector )
{
    Room *pRoom;
    int value;

    if ( argument[0] != '\0' )
    {
	EDIT_ROOM(ch, pRoom);

	if ( ( value = flag_value( sector_flags, argument ) ) != NO_FLAG )
	{
	    pRoom->sector_type = value;

	    send_to_char( "Sector set.\n\r", ch);
	    return TRUE;
	}
    }

    send_to_char( "Syntax:  sector [flag]\n\r"
		  "Type '? sector' for a list of flags.\n\r", ch );
    return FALSE;
}


REDIT( redit_hp )
{
    Room *pRoom;

    if ( argument[0] != '\0' )
    {
        EDIT_ROOM(ch, pRoom);

	pRoom->heal_rate = atoi( argument );
	cprintf(ch,"Heal rate set.\n\r");
        return TRUE;
    }

    send_to_char( "Syntax:  hp [heal_rate]\n\r", ch );
    return FALSE;
}

REDIT( redit_mana )
{
    Room *pRoom;

    if ( argument[0] != '\0' )
    {
        EDIT_ROOM(ch, pRoom);

        pRoom->mana_rate = atoi( argument );
        cprintf(ch,"Mana rate set.\n\r");
        return TRUE;
    }

    send_to_char( "Syntax:  mana [mana_rate]\n\r", ch );
    return FALSE;
}

/* Local function. */
bool change_exit( Character *ch, char *argument, int door )
{
    Room *pRoom;
    char command[MAX_INPUT_LENGTH];
    char arg[MAX_INPUT_LENGTH];
    int  value;

    EDIT_ROOM(ch, pRoom);

    /*
     * Now parse the arguments.
     */
    argument = one_argument( argument, command );
    one_argument( argument, arg );

    if ( command[0] == '\0' && argument[0] == '\0' )	/* Move command. */
    {
		if ( IS_SET( ch->pcdata->olc_flags, OLC_BUILD_AS_I_WALK ))
			walkBuild( ch, door, pRoom->area );

		move_char( ch, door, TRUE );                    /* ROM OLC */
		return FALSE;
    }

    if ( command[0] == '?' )
    {
		do_help( ch, "EXIT" );
		return FALSE;
    }

    if ( !str_cmp( command, "delete" ) )
    {
		Room *pToRoom;
		sh_int rev;                                     /* ROM OLC */
		Spawn *s;

		if ( !pRoom->exit[door] )
		{
	    	send_to_char( "REdit:  Cannot delete a null exit.\n\r", ch );
	    	return FALSE;
		}

		/*
	 	* Remove ToRoom Exit.
	 	*/
		rev = rev_dir[door];
		pToRoom = pRoom->exit[door]->u1.to_room;       /* ROM OLC */
	
		if ( pToRoom->exit[rev] )
		{
	    	free_exit( pToRoom->exit[rev] );
	    	pToRoom->exit[rev] = NULL;
		}

		/*
	 	* Remove this exit.
	 	*/
		free_exit( pRoom->exit[door] );
		pRoom->exit[door] = NULL;
	
		send_to_char( "Exit unlinked.\n\r", ch );

		/* check for any spawns with this exit */
		for( s = pRoom->spawns ; s != NULL ; s = s->next_in_room )
		{
			if ( s->source == door )
			{
				extractSpawnFromRoom( s, pRoom );
				break;
			}
		}
		return TRUE;
    }

    if ( !str_cmp( command, "link" ) )
    {
		Exit *pExit;

		if ( arg[0] == '\0' || !is_number( arg ) )
		{
	    	send_to_char( "Syntax:  [direction] link [vnum]\n\r", ch );
	    	return FALSE;
		}

		value = atoi( arg );

		if ( !get_room_index( value ) )
		{
	    	send_to_char( "REdit:  Cannot link to non-existant room.\n\r", ch );
	    	return FALSE;
		}

		if ( !IS_BUILDER( ch, get_room_index( value )->area ) )
		{
	    	send_to_char( "REdit:  Cannot link to that area.\n\r", ch );
	    	return FALSE;
		}
	
		if ( get_room_index( value )->exit[rev_dir[door]] )
		{
	    	send_to_char( "REdit:  Remote side's exit already exists.\n\r", ch );
	    	return FALSE;
		}
	
		if ( !pRoom->exit[door] )
		{
	    	pRoom->exit[door] = new_exit();
		}
	
		pRoom->exit[door]->u1.to_room = get_room_index( value );   /* ROM OLC */
		pRoom->exit[door]->orig_door 	= door;
		/*	pRoom->exit[door]->vnum = value;                Can't set vnum in ROM */
	
		pRoom                   = get_room_index( value );
	
		door                    = rev_dir[door];
		pExit                   = new_exit();
		pExit->u1.to_room       = ch->in_room;
		/*	pExit->vnum             = ch->in_room->vnum;    Can't set vnum in ROM */
		pExit->orig_door	= door;
		pRoom->exit[door]       = pExit;
	
		send_to_char( "Two-way link established.\n\r", ch );
	
		return TRUE;
    }
       	 
    if ( !str_cmp( command, "dig" ) )
    {
		char buf[MAX_STRING_LENGTH];
	
		if ( arg[0] == '\0' || !is_number( arg ) )
		{
	    	send_to_char( "Syntax: [direction] dig <vnum>\n\r", ch );
	    	return FALSE;
		}
		
		redit_create( ch, arg );
		sprintf( buf, "link %s", arg );
		change_exit( ch, buf, door);
		return TRUE;
    }

    if ( !str_cmp( command, "room" ) )
    {
		if ( arg[0] == '\0' || !is_number( arg ) )
		{
	    	send_to_char( "Syntax:  [direction] room [vnum]\n\r", ch );
	    	return FALSE;
		}
	
		if ( !pRoom->exit[door] )
		{
	    	pRoom->exit[door] = new_exit();
		}
	
		value = atoi( arg );
	
		if ( !get_room_index( value ) )
		{
	    	send_to_char( "REdit:  Cannot link to non-existant room.\n\r", ch );
	    	return FALSE;
		}

		pRoom->exit[door]->u1.to_room = get_room_index( value );    /* ROM OLC */
       	pRoom->exit[door]->orig_door    = door;
	/*	pRoom->exit[door]->vnum = value;                 Can't set vnum in ROM */
	
		send_to_char( "One-way link established.\n\r", ch );
		return TRUE;
    }
	
    if ( !str_cmp( command, "key" ) )
    {
		if ( arg[0] == '\0' || !is_number( arg ) )
		{
	    	send_to_char( "Syntax:  [direction] key [vnum]\n\r", ch );
	    	return FALSE;
		}
	
		if ( !pRoom->exit[door] )
		{
	    	pRoom->exit[door] = new_exit();
		}
	
		value = atoi( arg );
	
		if ( !get_obj_index( value ) )
		{
	    	send_to_char( "REdit:  Item doesn't exist.\n\r", ch );
	    	return FALSE;
		}
	
		if ( get_obj_index( atoi( argument ) )->item_type != ITEM_KEY )
		{
	    	send_to_char( "REdit:  Key doesn't exist.\n\r", ch );
	    	return FALSE;
		}
	
		pRoom->exit[door]->key = value;
	
		send_to_char( "Exit key set.\n\r", ch );
		return TRUE;
   	}
	
    if ( !str_cmp( command, "name" ) )
    {
		if ( arg[0] == '\0' )
		{
	    	send_to_char( "Syntax:  [direction] name [string]\n\r", ch );
	    	return FALSE;
		}
	
		if ( !pRoom->exit[door] )
		{
	    	pRoom->exit[door] = new_exit();
		}
	
		free_string( pRoom->exit[door]->keyword );
		pRoom->exit[door]->keyword = str_dup( arg );
	
		send_to_char( "Exit name set.\n\r", ch );
		return TRUE;
    }

    if ( !str_prefix( command, "sync" ) )
    {
        Spawn *s;
        sh_int rev;
        Room *pToRoom;

        if ( !pRoom->exit[door] )
        {
            cprintf(ch,"There is no exit in this direction.\n\r");
            return FALSE;
        }

        s = findExitSpawn( pRoom, door );
        s->misc = pRoom->exit[door]->rs_flags;
    	if ( pRoom->exit[door]->spawn == NULL )
			pRoom->exit[door]->spawn = s;
        pRoom->exit[door]->exit_info = pRoom->exit[door]->rs_flags;
        cprintf(ch,"Spawn flags synchronized with exit flags.\n\r");

        /* Hit the other side */
        if ( (pToRoom = pRoom->exit[door]->u1.to_room) != NULL )
        {
			rev = rev_dir[door];
	
			if ( (s = findExitSpawn( pToRoom, rev )) != NULL )
                s->misc = pToRoom->exit[rev]->rs_flags;
            pToRoom->exit[rev]->exit_info = pToRoom->exit[rev]->rs_flags;
            cprintf(ch,"Other side synchronized, too.\n\r");
		}

        return TRUE;
    }

    if ( !str_prefix( command, "flag1way" ) )
    {
    	/*
     	* Set the exit flags, needs full argument.
     	* ----------------------------------------
     	*/
    	if ( ( value = flag_value( exit_flags, argument ) ) != NO_FLAG )
    	{
			Spawn *s;
	
			if ( !pRoom->exit[door] )
            {
                cprintf(ch,"No exit in this direction, creating...\n\r");
	    		pRoom->exit[door] = new_exit();
            }
		
			/*
	 		* This room.
	 		*/
			TOGGLE_BIT(pRoom->exit[door]->rs_flags,  value);

			/* Don't use toggle on exit_info because it can be changed by players. */
			pRoom->exit[door]->exit_info = pRoom->exit[door]->rs_flags;

			s = findExitSpawn( pRoom, door );
			TOGGLE_BIT( s->misc, value );

			if ( pRoom->exit[door]->spawn == NULL )
				pRoom->exit[door]->spawn = s;
		
			cprintf( ch, "Exit flags toggled: [%s]\n\r", flag_string(exit_flags,value) );
            cprintf( ch, "  Exit flags (rs):  [%s]\n\r", flag_string(exit_flags,pRoom->exit[door]->rs_flags) );
            cprintf( ch, "  Exit info flags:  [%s]\n\r", flag_string(exit_flags,pRoom->exit[door]->exit_info) );
            cprintf( ch, "  Spawn flags:      [%s]\n\r", flag_string(exit_flags,s->misc) );

			return TRUE;
    	}
    }

    if ( !str_prefix( command, "flag" ) )
    {
    	/*
     	* Set the exit flags, needs full argument.
     	* ----------------------------------------
     	*/
    	if ( ( value = flag_value( exit_flags, argument ) ) != NO_FLAG )
    	{
			Room *pToRoom;
			sh_int rev;                                    /* ROM OLC */
			Spawn *s;
	
			if ( !pRoom->exit[door] )
            {
                cprintf(ch,"No exit in this direction, creating...\n\r");
	    		pRoom->exit[door] = new_exit();
            }
		
			/*
	 		* This room.
	 		*/
			TOGGLE_BIT(pRoom->exit[door]->rs_flags,  value);

			/* Don't use toggle on exit_info because it can be changed by players. */
			pRoom->exit[door]->exit_info = pRoom->exit[door]->rs_flags;

			s = findExitSpawn( pRoom, door );
			TOGGLE_BIT( s->misc, value );

			if ( pRoom->exit[door]->spawn == NULL )
				pRoom->exit[door]->spawn = s;
		
			/*
	 		* Connected room.
	 		*/
			if ( (pToRoom = pRoom->exit[door]->u1.to_room) != NULL )       /* ROM OLC */
			{
				rev = rev_dir[door];
	
				TOGGLE_BIT(pToRoom->exit[rev]->rs_flags,  value);

			    /* Don't use toggle on exit_info because it can be changed by players. */
			    pToRoom->exit[rev]->exit_info = pToRoom->exit[rev]->rs_flags;

				/* Hit the other side */
				if( (s = findExitSpawn( pToRoom, rev )) != NULL )
					TOGGLE_BIT( s->misc, value );
			}

			cprintf( ch, "Exit flags toggled: [%s]\n\r", flag_string(exit_flags,value) );
            cprintf( ch, "  Exit flags (rs):  [%s]\n\r", flag_string(exit_flags,pRoom->exit[door]->rs_flags) );
            cprintf( ch, "  Exit info flags:  [%s]\n\r", flag_string(exit_flags,pRoom->exit[door]->exit_info) );
            cprintf( ch, "  Spawn flags:      [%s]\n\r", flag_string(exit_flags,s->misc) );

			return TRUE;
    	}
    }

    if ( !str_prefix( command, "description" ) )
    {
		if ( arg[0] != '\0' )
		{
	    	if ( !pRoom->exit[door] )
	    	{
	        	pRoom->exit[door] = new_exit();
	    	}

            free_string( pRoom->exit[door]->description );
            pRoom->exit[door]->description = str_dup( arg );
            cprintf(ch,"Exit description set to [%s].\n\r", pRoom->exit[door]->description);

	    	return TRUE;
		}

		send_to_char( "Syntax:  [direction] desc 'description of door'\n\r", ch );
		return FALSE;
    }

    return FALSE;
}



REDIT( redit_north )
{
    if ( change_exit( ch, argument, DIR_NORTH ) )
	return TRUE;

    return FALSE;
}



REDIT( redit_south )
{
    if ( change_exit( ch, argument, DIR_SOUTH ) )
	return TRUE;

    return FALSE;
}



REDIT( redit_east )
{
    if ( change_exit( ch, argument, DIR_EAST ) )
	return TRUE;

    return FALSE;
}



REDIT( redit_west )
{
    if ( change_exit( ch, argument, DIR_WEST ) )
	return TRUE;

    return FALSE;
}



REDIT( redit_up )
{
    if ( change_exit( ch, argument, DIR_UP ) )
	return TRUE;

    return FALSE;
}



REDIT( redit_down )
{
    if ( change_exit( ch, argument, DIR_DOWN ) )
	return TRUE;

    return FALSE;
}



REDIT( redit_ed )
{
    Room *pRoom;
    ExtraDescr *ed;
    char command[MAX_INPUT_LENGTH];
    char keyword[MAX_INPUT_LENGTH];

    EDIT_ROOM(ch, pRoom);

    argument = one_argument( argument, command );
    one_argument( argument, keyword );

    if ( command[0] == '\0' || keyword[0] == '\0' )
    {
	send_to_char( "Syntax:  ed add [keyword]\n\r", ch );
	send_to_char( "         ed edit [keyword]\n\r", ch );
	send_to_char( "         ed delete [keyword]\n\r", ch );
	send_to_char( "         ed format [keyword]\n\r", ch );
	return FALSE;
    }

    if ( !str_cmp( command, "add" ) )
    {
	if ( keyword[0] == '\0' )
	{
	    send_to_char( "Syntax:  ed add [keyword]\n\r", ch );
	    return FALSE;
	}

	ed			=   new_extra_descr();
	ed->keyword		=   str_dup( keyword );
	ed->description		=   str_dup( "" );
	ed->next		=   pRoom->extra_descr;
	pRoom->extra_descr	=   ed;

	string_append( ch, &ed->description );

	return TRUE;
    }


    if ( !str_cmp( command, "edit" ) )
    {
	if ( keyword[0] == '\0' )
	{
	    send_to_char( "Syntax:  ed edit [keyword]\n\r", ch );
	    return FALSE;
	}

	for ( ed = pRoom->extra_descr; ed; ed = ed->next )
	{
	    if ( is_name( keyword, ed->keyword ) )
		break;
	}

	if ( !ed )
	{
	    send_to_char( "REdit:  Extra description keyword not found.\n\r", ch );
	    return FALSE;
	}

	string_append( ch, &ed->description );

	return TRUE;
    }


    if ( !str_cmp( command, "delete" ) )
    {
	ExtraDescr *ped = NULL;

	if ( keyword[0] == '\0' )
	{
	    send_to_char( "Syntax:  ed delete [keyword]\n\r", ch );
	    return FALSE;
	}

	for ( ed = pRoom->extra_descr; ed; ed = ed->next )
	{
	    if ( is_name( keyword, ed->keyword ) )
		break;
	    ped = ed;
	}

	if ( !ed )
	{
	    send_to_char( "REdit:  Extra description keyword not found.\n\r", ch );
	    return FALSE;
	}

	if ( !ped )
	    pRoom->extra_descr = ed->next;
	else
	    ped->next = ed->next;

	free_extra_descr( ed );

	send_to_char( "Extra description deleted.\n\r", ch );
	return TRUE;
    }


    if ( !str_cmp( command, "format" ) )
    {
	if ( keyword[0] == '\0' )
	{
	    send_to_char( "Syntax:  ed format [keyword]\n\r", ch );
	    return FALSE;
	}

	for ( ed = pRoom->extra_descr; ed; ed = ed->next )
	{
	    if ( is_name( keyword, ed->keyword ) )
		break;
	}

	if ( !ed )
	{
	    send_to_char( "REdit:  Extra description keyword not found.\n\r", ch );
	    return FALSE;
	}

	ed->description = format_string( ed->description );

	send_to_char( "Extra description formatted.\n\r", ch );
	return TRUE;
    }

    redit_ed( ch, "" );
    return FALSE;
}



REDIT( redit_create )
{
    Area *pArea;
    Room *pRoom;
    int value;
    int iHash;
    
    EDIT_ROOM(ch, pRoom);

    value = atoi( argument );

    if ( argument[0] == '\0' || value <= 0 )
    {
	send_to_char( "Syntax:  create [vnum > 0]\n\r", ch );
	return FALSE;
    }

    pArea = get_vnum_area( value );
    if ( !pArea )
    {
	send_to_char( "REdit:  That vnum is not assigned an area.\n\r", ch );
	return FALSE;
    }

    if ( !IS_BUILDER( ch, pArea ) )
    {
	send_to_char( "REdit:  Vnum in an area you cannot build in.\n\r", ch );
	return FALSE;
    }

    if ( get_room_index( value ) )
    {
	send_to_char( "REdit:  Room vnum already exists.\n\r", ch );
	return FALSE;
    }

    pRoom			= new_room_index();
    pRoom->area			= pArea;
    pRoom->vnum			= value;

    if ( value > top_vnum_room )
        top_vnum_room = value;

    iHash			= value % MAX_KEY_HASH;
    pRoom->next			= room_index_hash[iHash];
    room_index_hash[iHash]	= pRoom;

	pRoom->guild = -1;
    ch->desc->pEdit		= (void *)pRoom;

    send_to_char( "Room created.\n\r", ch );
    return TRUE;
}



REDIT( redit_name )
{
    Room *pRoom;

    EDIT_ROOM(ch, pRoom);

    if ( argument[0] == '\0' )
    {
	send_to_char( "Syntax:  name [name]\n\r", ch );
	return FALSE;
    }

    free_string( pRoom->name );
    pRoom->name = str_dup( argument );

    send_to_char( "Name set.\n\r", ch );
    return TRUE;
}



REDIT( redit_desc )
{
    Room *pRoom;

    EDIT_ROOM(ch, pRoom);

    if ( argument[0] == '\0' )
    {
	string_append( ch, &pRoom->description );
	return TRUE;
    }

    send_to_char( "Syntax:  desc\n\r", ch );
    return FALSE;
}

REDIT( redit_delspawn )
{
	Room *pRoom;
	Spawn *s;
	int spawnIndex;

	EDIT_ROOM(ch,pRoom);

	/* See if the spawn is even in this room */
	if ( argument[0] == '\0' )
	{
		cprintf(ch,"Syntax:  delspawn [spawn index #]\n\r");
		return FALSE;
	}

	spawnIndex = atoi( argument );
	for( s = pRoom->spawns ; s != NULL ; s = s->next_in_room )
		if ( s->index == spawnIndex )
		{
			cprintf(ch,"Spawn #%d removed.\n\r", s->index );
			extractSpawnFromRoom( s, pRoom );
			return TRUE;
		}

	cprintf(ch,"Spawn #%d not found in this room.\n\r",spawnIndex);
	return FALSE;
}


REDIT( redit_format )
{
    Room *pRoom;

    EDIT_ROOM(ch, pRoom);

    pRoom->description = format_string( pRoom->description );

    send_to_char( "String formatted.\n\r", ch );
    return TRUE;
}

REDIT( redit_mreset )
{
    Room		*pRoom;
    MobIndex		*pMobIndex;
    char				arg [ MAX_INPUT_LENGTH ];
    int					interval;
    int					frequency;
    int					placeholder;
    int					despawn;
    int					max;
    int					maxroom;
	Spawn				*spawn;

    EDIT_ROOM(ch, pRoom);

    argument = one_argument( argument, arg );

    if ( arg[0] == '\0' || !is_number( arg ) )
    {
		send_to_char ( "Syntax:  mreset <vnum> -i<interval> -f<frequency> -p<placeholder> -d<despawn>\n\r", ch );
		cprintf(ch,    "    Options with a - in front of them are ... optional.  If you don't specify them,\n\r"
	   	           	"    defaults will be used.  See 'help spawn' for details.\n\r");
		return FALSE;
    }

    if ( !( pMobIndex = get_mob_index( atoi( arg ) ) ) )
    {
		send_to_char( "REdit: No mobile has that vnum.\n\r", ch );
		return FALSE;
    }

    if ( pMobIndex->area != pRoom->area )
    {
		send_to_char( "REdit: No such mobile in this area.\n\r", ch );
		return FALSE;
    }

    /* Set up some defaults */
    interval = 15; /* default is 15 minutes */  
    frequency = 100; /* always */
    placeholder = 0; /* none */
    despawn = 0;   /* doesn't */

    /* Parse any additional arguments */
    while ( argument[0] != '\0' )
    {
		char cSwitch;

		argument = one_argument( argument, arg );

		if (arg[0] != '-' || strlen(arg) < 3 )
		{
	    	cprintf(ch,"Optional arguments to resets must be prefaced by a dash (-).\n\r");
	    	return FALSE;
		}

		cSwitch = arg[1];
		if (!is_number(arg+2))
		{
	    	cprintf(ch,"Argument [%s] must be numeric.\n\r");
	    	return FALSE;
		}

		switch( cSwitch )
		{
			case 'r':case 'R': maxroom = atoi(arg+2); break;
			case 'm':case 'M': max = atoi(arg+2); break;
			case 'd':case 'D': 
	    		despawn = atoi(arg+2); 
	    		if ( despawn == 0 )
					--despawn;
	    		break;

			case 'i':case 'I': interval = atoi(arg+2); break;
			case 'f':case 'F': frequency = atoi(arg+2);
	    		if ( frequency < 0 )
	    		{
					cprintf(ch,"Negative frequencies are not allowed.\n\r");
					return FALSE;
	    		}

	    		if ( frequency > 100 )
					frequency = 100;
	    		break;

			case 'p':case 'P': placeholder = atoi(arg+2); break;
			    if ( get_mob_index( placeholder ) == NULL )
	   		 	{
					cprintf(ch,"No mob with placeholder vnum %d exists.\n\r",placeholder);
					return FALSE;
	    		}
	    		break;

			default:
				cprintf(ch,"No such reset switch %c.\n\r",cSwitch);
	        	break;
		}
    }

    /*
     * Create the mobile reset.
     */
	
	/* 1. Get the next available index */
	spawn 				= get_new_spawn( );
	spawn->type			= 'M';
	spawn->source		= pMobIndex->vnum;
	spawn->target		= pRoom->vnum;
    spawn->interval		= interval;
    spawn->frequency	= frequency;
    spawn->placeholder	= placeholder;
    spawn->despawn		= despawn;

	spawnToRoom( pRoom, spawn );	
	SET_BIT(spawn->flags,SPAWN_READY);
	cprintf( ch, "Spawn added.  Type 'ready' to test this spawn.\n\r");
    return TRUE;
}



struct wear_type
{
    int	wear_loc;
    int	wear_bit;
};



const struct wear_type wear_table[] =
{
    {	WEAR_NONE,	ITEM_TAKE		},
    {	WEAR_LIGHT,	ITEM_LIGHT		},
    {	WEAR_FINGER_L,	ITEM_WEAR_FINGER	},
    {	WEAR_FINGER_R,	ITEM_WEAR_FINGER	},
    {	WEAR_NECK_1,	ITEM_WEAR_NECK		},
    {	WEAR_NECK_2,	ITEM_WEAR_NECK		},
    {	WEAR_BODY,	ITEM_WEAR_BODY		},
    {	WEAR_HEAD,	ITEM_WEAR_HEAD		},
    {	WEAR_LEGS,	ITEM_WEAR_LEGS		},
    {	WEAR_FEET,	ITEM_WEAR_FEET		},
    {	WEAR_HANDS,	ITEM_WEAR_HANDS		},
    {	WEAR_ARMS,	ITEM_WEAR_ARMS		},
    {	WEAR_SHIELD,	ITEM_WEAR_SHIELD	},
    {	WEAR_ABOUT,	ITEM_WEAR_ABOUT		},
    {	WEAR_WAIST,	ITEM_WEAR_WAIST		},
    {	WEAR_WRIST_L,	ITEM_WEAR_WRIST		},
    {	WEAR_WRIST_R,	ITEM_WEAR_WRIST		},
    {	WEAR_WIELD,	ITEM_WIELD		},
    {	WEAR_HOLD,	ITEM_HOLD		},
    {   WEAR_FACE,	ITEM_WEAR_FACE		},
    {   WEAR_SHOULDERS, ITEM_WEAR_SHOULDERS	},
    {   WEAR_EAR_L,	ITEM_WEAR_EAR		},
    {   WEAR_EAR_R,	ITEM_WEAR_EAR		},
    {   WEAR_FLOAT,	ITEM_WEAR_FLOAT		},
    {	WEAR_OFFHAND, ITEM_WEAR_OFFHAND	},
	{	WEAR_RANGED, ITEM_WEAR_RANGED	},
	{ 	WEAR_INSTRUMENT, ITEM_WEAR_INSTRUMENT	},
    {	NO_FLAG,	NO_FLAG			}
};



/*****************************************************************************
 Name:		wear_loc
 Purpose:	Returns the location of the bit that matches the count.
 		1 = first match, 2 = second match etc.
 Called by:	oedit_reset(olc_act.c).
 ****************************************************************************/
int wear_loc(int bits, int count)
{
    int flag;
 
    for (flag = 0; wear_table[flag].wear_bit != NO_FLAG; flag++)
    {
        if ( IS_SET(bits, wear_table[flag].wear_bit) && --count < 1)
            return wear_table[flag].wear_loc;
    }
 
    return NO_FLAG;
}



/*****************************************************************************
 Name:		wear_bit
 Purpose:	Converts a wear_loc into a bit.
 Called by:	redit_oreset(olc_act.c).
 ****************************************************************************/
int wear_bit(int loc)
{
    int flag;
 
    for (flag = 0; wear_table[flag].wear_loc != NO_FLAG; flag++)
    {
        if ( loc == wear_table[flag].wear_loc )
            return wear_table[flag].wear_bit;
    }
 
    return 0;
}

REDIT( redit_sreset )
{
	Spawn			*spawn;
	Character		*to_mob;
	ScriptIndex			*pScriptIndex;
	char			arg[MAX_INPUT_LENGTH];
	int				vnum;
	Room			*pRoom;

   	EDIT_ROOM(ch,pRoom);

	/* Format:  qreset <quest vnum> <npc> */	
	argument = one_argument( argument, arg );

	if ( arg[0] == '\0' || *argument == '\0' )
	{
		cprintf(ch,"Usage:  qreset <quest vnum> <NPC in this room>\n\r");
		return FALSE;
	}

	if ( !is_number(arg) )
	{
		cprintf(ch,"Vnum must be numeric.\n\r");
		return FALSE;
	}

	if ( (vnum = atoi(arg)) < 0 || vnum > 35000 )
	{
		cprintf(ch,"Vnum must be between 1 and 35,000.\n\r");
		return FALSE;
	}

	if ( (pScriptIndex = get_script_index(vnum)) == NULL )
	{
		cprintf(ch,"ScriptIndex vnum %d doesn't exist.\n\r", vnum );
		return FALSE;
	}

	if ( (to_mob = get_char_room(ch,argument)) == NULL )
	{
		cprintf(ch,"No such NPC in this room.\n\r");
		return FALSE;
	}

	/* Add reset */
    spawn           = get_new_spawn( );
    spawn->source   = pScriptIndex->vnum;
    spawn->target   = to_mob->spawn->index;
    spawn->misc     = 0;
    spawn->type 	= 'S';
    spawn->interval        = 1;
    spawn->frequency       = 100;
    spawn->placeholder     = -1;
    spawn->despawn         = 0;

	spawnToContents( to_mob->spawn, spawn );
	cprintf( ch, "ScriptIndex spawn added.  Type 'ready' to test this spawn.\n\r");

	return TRUE;
}

REDIT( redit_qreset )
{
	Spawn			*spawn;
	Character		*to_mob;
	Quest			*pQuest;
	char			arg[MAX_INPUT_LENGTH];
	int				vnum;
	Room			*pRoom;

   	EDIT_ROOM(ch,pRoom);

	/* Format:  qreset <quest vnum> <npc> */	
	argument = one_argument( argument, arg );

	if ( arg[0] == '\0' || *argument == '\0' )
	{
		cprintf(ch,"Usage:  qreset <quest vnum> <NPC in this room>\n\r");
		return FALSE;
	}

	if ( !is_number(arg) )
	{
		cprintf(ch,"Vnum must be numeric.\n\r");
		return FALSE;
	}

	if ( (vnum = atoi(arg)) < 0 || vnum > 35000 )
	{
		cprintf(ch,"Vnum must be between 1 and 35,000.\n\r");
		return FALSE;
	}

	if ( (pQuest = get_quest_index(vnum)) == NULL )
	{
		cprintf(ch,"Quest vnum %d doesn't exist.\n\r", vnum );
		return FALSE;
	}

	if ( (to_mob = get_char_room(ch,argument)) == NULL )
	{
		cprintf(ch,"No such NPC in this room.\n\r");
		return FALSE;
	}

	/* Add reset */
    spawn           = get_new_spawn( );
    spawn->source   = pQuest->vnum;
    spawn->target   = to_mob->spawn->index;
    spawn->misc     = 0;
    spawn->type 	= 'Q';
    spawn->interval        = 1;
    spawn->frequency       = 100;
    spawn->placeholder     = -1;
    spawn->despawn         = 0;

	spawnToContents( to_mob->spawn, spawn );
	cprintf( ch, "Spawn added.  Type 'ready' to test this spawn.\n\r");

	return TRUE;
}

REDIT( redit_oreset )
{
    Room			*pRoom;
    ObjIndex			*pObjIndex;
    char					*tArg;
    char					vnum [ MAX_INPUT_LENGTH ];
    char					type [ MAX_INPUT_LENGTH ];
    char					loc [ MAX_INPUT_LENGTH ];
    int						interval;
    int						frequency;
    int						despawn;
    int						placeholder;
	Spawn					*spawn;
    char					output [ MAX_STRING_LENGTH ];
	Object					*to_obj;
	Character				*to_mob;

    EDIT_ROOM(ch, pRoom);

    argument = one_argument( argument, vnum );
    argument = one_argument( argument, type );
    tArg = one_argument( argument, loc );

    if ( loc[0] != '-' )
		argument = tArg;

    if ( vnum[0] == '\0' || !is_number( vnum ) )
    {
		cprintf( ch, "Syntax:  oreset <vnum> <args> -i<int> -f<freq> -d<despawn> -p<placeholder>\n\r", ch );
		cprintf( ch, "         <args can be>\n\r");
 		cprintf( ch, "         'room'                 = into room\n\r");
		cprintf( ch, "         <obj_spawn>            = into obj in room\n\r");
	    cprintf( ch, "         into <obj_spawn#>      = into obj on NPC\n\r");
		cprintf( ch, "         <mob_spawn> <wear_loc> = into mob\n\r");
        cprintf( ch, "\n\r     Options with a - in front of them are ... optional.  If you don't specify them,\n\r"
                       "    defaults will be used.  See 'help spawn' for details.\n\r");
		return FALSE;
    }

    if ( !( pObjIndex = get_obj_index( atoi( vnum ) ) ) )
    {
		send_to_char( "REdit: No object has that vnum.\n\r", ch );
		return FALSE;
    }

    if ( pObjIndex->area != pRoom->area )
    {
		send_to_char( "REdit: No such object in this area.\n\r", ch );
		return FALSE;
    }

    interval 	= 15;
    frequency	= 100;
    placeholder	= 0;
    despawn	= -1;

    while ( argument[0] != '\0' )
    {
        char cSwitch;
		char arg[ MAX_INPUT_LENGTH ];

        argument = one_argument( argument, arg );

        if (arg[0] != '-' )
        {
            cprintf(ch,"Optional arguments to resets must be prefaced by a dash (-).\n\r");
            return FALSE;
        }

        cSwitch = arg[1];
        if (!is_number(arg+2))
        {
            cprintf(ch,"Argument [%s] must be numeric.\n\r");
            return FALSE;
        }

        switch( cSwitch )
        {
        	case 'd':case 'D':
            	despawn = atoi(arg+2);
            	if ( despawn == 0 )
                	--despawn;
            	break;
        	case 'i':case 'I': interval = atoi(arg+2); break;
        	case 'f':case 'F': frequency = atoi(arg+2);
            	if ( frequency < 0 )
            	{
                	cprintf(ch,"Negative frequencies are not allowed.\n\r");
                	return FALSE;
            	}
            	if ( frequency > 100 )
                	frequency = 100;
            	break;
        	case 'p':case 'P': placeholder = atoi(arg+2); break;
            	if ( get_mob_index( placeholder ) == NULL )
            	{
                	cprintf(ch,"No mob with placeholder vnum %d exists.\n\r",placeholder);
                	return FALSE;
            	}
            	break;
        	default:
                cprintf(ch,"No such reset switch %c.\n\r",cSwitch);
                break;
        }
    }


    /*
     * Load into room.
     */
    if ( !strcmp(type,"room") )
    {
		spawn		= get_new_spawn( );
		spawn->type			= 'O';
		spawn->source		= pObjIndex->vnum;
		spawn->target		= pRoom->vnum;
   		spawn->interval		= interval;
		spawn->frequency	= frequency;
		spawn->placeholder	= placeholder;
		spawn->despawn		= despawn;

		spawnToRoom( pRoom, spawn );
		cprintf( ch, "Spawn added.  Type 'ready' to test this spawn.\n\r");
    }
	else
	/*
	 * Load into carried object
	 */
	if ( !strcmp(type,"into") )
	{
		int index = atoi( loc );
		Spawn *tmp;

		if ( index <= 0 || index > MAX_SPAWN )
		{
			cprintf(ch,"Valid spawn range is 1 to %d\n\r", MAX_SPAWN );
			return FALSE;
		}
		
		if( (tmp = &spawnTable[index]) == NULL )
		{
			cprintf(ch,"No such spawn %d\n\r",index);
			return FALSE;
		}

		spawn				= get_new_spawn( );
		spawn->type			= 'C';
		spawn->source		= pObjIndex->vnum;
		spawn->target 		= index;
		spawn->interval		= interval;
		spawn->frequency	= frequency;
		spawn->placeholder	= placeholder;
		spawn->despawn		= despawn;

		spawnToContents( tmp, spawn );
		cprintf( ch, "Content spawn added.\n\r");
		cprintf( ch,"\n\r *** Note that there's no sanity check to ensure that the spawn\n\r"
				   "you indicated is actually in this room.  It doesn't hurt to\n\r"
					"double check. ***\n\r");
		return TRUE;
	}
    else
    /*
     * Load into object's inventory.
     */
    if ( argument[0] == '\0' && ( ( to_obj = get_obj_list( ch, type, pRoom->contents ) ) != NULL ) )
    {
		spawn				= get_new_spawn( );
		spawn->type			= 'P';
		spawn->source		= pObjIndex->vnum;
		spawn->target		= to_obj->spawn->index;
        spawn->interval     = interval;
        spawn->frequency    = frequency;
        spawn->placeholder  = placeholder;
        spawn->despawn      = despawn;

		spawnToContents( to_obj->spawn, spawn );
		cprintf( ch, "Spawn added.  Type 'ready' to test this spawn.\n\r");
    }
    else
    /*
     * Load into mobile's inventory.
     */
    if ( ( to_mob = get_char_room( ch, type ) ) != NULL )
    {
		int	wear_loc;

		/*
	 	* Make sure the location on mobile is valid.
	 	*/
		if ( (wear_loc = flag_value( wear_loc_flags, loc )) == NO_FLAG )
		{
	    	send_to_char( "REdit: Invalid wear_loc.  '? wear-loc'\n\r", ch );
	    	return FALSE;
		}

		/*
	 	* Disallow loading a sword(WEAR_WIELD) into WEAR_HEAD.
	 	*/
		if ( !IS_SET( pObjIndex->wear_flags, wear_bit(wear_loc) ) )
		{
	    	sprintf( output,
	        	"oreset Error: %s (%d) has wear flags: [%s].  Your flag was [%s]\n\r",
	        	capitalize( pObjIndex->short_descr ),
	        	pObjIndex->vnum,
			flag_string( wear_flags, pObjIndex->wear_flags ),
			flag_string( wear_loc_flags, wear_loc ) );
	    	send_to_char( output, ch );
	    	return FALSE;
		}

		/*
	 	* Can't load into same position.
	 	*/
		if ( get_eq_char( to_mob, wear_loc ) && wear_loc != flag_value( wear_loc_flags, "none" ) )
		{
	    	send_to_char( "REdit:  Object already equipped.\n\r", ch );
	    	return FALSE;
		}

		if ( to_mob->spawn == NULL )
		{
			cprintf(ch,"The target NPC has no spawn information.\n\r");
			return FALSE;
		}

		spawn			= get_new_spawn ( );	
		spawn->source	= pObjIndex->vnum;
		spawn->target	= to_mob->spawn->index;
		spawn->misc		= wear_loc;
		if ( spawn->misc == WEAR_NONE )
	    	spawn->type	= 'I';
		else
	    	spawn->type = 'E';
       	spawn->interval        = interval;
        spawn->frequency       = frequency;
        spawn->placeholder     = placeholder;
        spawn->despawn         = despawn;

		spawnToContents( to_mob->spawn, spawn );
		cprintf( ch, "Spawn added.  Type 'ready' to test this spawn.\n\r");
    }
    else	/* Display Syntax */
    {
		send_to_char( "REdit:  That mobile isn't here.\n\r", ch );
		return FALSE;
    }

	SET_BIT(spawn->flags,SPAWN_READY);
    return TRUE;
}

Spawn *get_new_spawn ( void )
{
	/* find the newest available spawn */
	int i;

	for( i = 1 ; i < MAX_SPAWN ; i++ )
	{
		if ( spawnTable[i].index <= 0 )
		{
			memset(&spawnTable[i],0,sizeof(spawnTable[i]));
			spawnTable[i].index = i;
			return &spawnTable[i];
		}
	}

	return NULL;
}

void spawnToRoom( Room *r, Spawn *s )
{
	s->next_in_room = r->spawns;
	r->spawns = s;
}

void spawnToContents( Spawn *parent, Spawn *new )
{
	new->next_content = parent->contains;
	parent->contains = new;
}

Spawn *findExitSpawn( Room *room, int door )
{
	Spawn *s;

	for( s = room->spawns ; s != NULL ; s = s->next_in_room )
		if ( toupper(s->type) == 'D' && s->source == door )
			return s;

	s = get_new_spawn( );
	s->next_in_room = room->spawns;
	room->spawns = s;

	s->source = door;
	s->target = room->vnum;
	s->misc = 0;
	s->placeholder = 0;
	s->despawn = 0;
	s->frequency = 100;
	s->interval = 10;
	s->type = 'D';

	return s;
}

void removeSpawnContent( Spawn *s )
{
	if ( s->next_content )
		removeSpawnContent( s->next_content );

	s->next_content = NULL;
	return;
}

void extractSpawnFromRoom( Spawn *spawn, Room *pRoom )
{
	Spawn *s;

	if ( pRoom->spawns == spawn )
		pRoom->spawns = spawn->next_in_room;
	else
	{
		for( s = pRoom->spawns ; s != NULL ; s = s->next_in_room )
		{
			if ( s->next_in_room == spawn )
			{
				s->next_in_room = spawn->next_in_room;
				break;
			}
		}
	}

	if ( spawn->next_content )
	{
		removeSpawnContent( spawn->next_content );
		spawn->next_content = NULL;
	}

	spawn->index = 0;
	return;
}

