/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#ifndef styles_h
#define styles_h

/*
 * Combat style table
 */
typedef struct style_aff_type
{
    int        apply_loc;
    int        amount;
    int        duration;
} StyleAff;

struct style_type
{
    char *          name;            /* name of the style */
    sh_int          stamina;        /* stamina this style costs to use */
    int *           weapon_sn;        /* Weapon skill this style belongs to */
    sh_int          class_level[MAX_CLASS];    /* when which classes get and use it */
    sh_int          opening;        /* required opening */
    sh_int          flags;            /* flags */
    char *          msg_1st;        /* attacker's message */
    char *          msg_2nd;        /* victim's message */
    char *          msg_3rd;        /* obserer's message */
    int             attack;            /* attack bonus */
    int             damage;            /* damage bonus */
    int             defense;        /* defense change */
    StyleFun *      fun_ptr;        /* style fucntion pointer */
    char *          affect;        /* description */
    char *          opening_style;    /* req style */
    int             dam_type;        /* 0 means default */
    char *          dam_noun;        /* doesn't need to be defined */
};

#define DECLARE_STYLE_FUN( fun )    StyleFun  fun
#define Style( fun )                DECLARE_STYLE_FUN( style_##fun );

#define		STYLE_PARRY		-1
#define		STYLE_EVADE		-2
#define		STYLE_BLOCK		-3
#define		STYLE_TRIP		-4
#define		STYLE_LEGSWEEP	-5
#define		STYLE_STARTER   -6
#define		STYLE_FAIL		-7
#define		STYLE_STYLE		-8

#define		OPENING_NONE		0

#define		SF_SHIELD			(A)

Style( side_thrust );
Style( belly_stab );
Style( separate_shoulder );
Style( kidney_stab );
Style( rib_splitter );
Style( flatblade_bash );
Style( thigh_stab );
Style( spin_thrust );
Style( carpus_shatter );
Style( heart_stab );
Style( spider_bite );
Style( scorpion_sting );
Style( wasp_sting );
Style( coil );
Style( hornet_sting );
Style( black_widow );
Style( asp );
Style( diamondback );
Style( cobra );
Style( dragonbite );
Style( tesulors_quarter );
Style( hounds_maw );
Style( manikovs_quarter );
Style( taihrs_finale );
Style( wolfs_maw );
Style( crippler );
Style( griffonclaw );
Style( vesikurs_quarter );
Style( wyrmfang );
Style( half_moon );
Style( snare );
Style( gibbous_moon );
Style( iron_retort );
Style( full_moon );
Style( rupture );
Style( painbringer );
Style( blades_anguish );
Style( bloodbringer );
Style( instigator );
Style( cleave );
Style( gash );
Style( hew );
Style( decapitate );
Style( moderate_pain );
Style( rive );
Style( sunder );
Style( severe_pain );
Style( chine );
Style( behead );
Style( executioner );
Style( legbreaker );
Style( bludgeon );
Style( bruiser );
Style( concussion );
Style( contusions );
Style( basher );
Style( entrenchment );
Style( devastator );
Style( bonecrusher );
Style( mauler );
Style( pulverizer );
Style( pound );
Style( ruiner );
Style( rifthammer );
Style( provoker );
Style( demolish );
Style( smithys_fury );
Style( crumble );
Style( conqueror );
Style( smithys_retort );
Style( lambast );
Style( widowmaker );
Style( deaths_cradle );
Style( daze );
Style( crusher );
Style( destroyer );
Style( skullcrusher );
Style( anvil );
Style( blast );
Style( slam );
Style( smithysfury );
Style( smithysretort );
Style( deathscradle );
Style( prod );
Style( perforate );
Style( bore );
Style( penetrate );
Style( spit );
Style( jab );
Style( pierce );
Style( skewer );
Style( brace );
Style( spike );
Style( discard );
Style( lance );
Style( pin );
Style( gore );
Style( impale );

extern sh_int vnum_slow;
extern sh_int vnum_root;
extern sh_int vnum_snare;
extern sh_int vnum_positioning;
extern sh_int vnum_pain;
extern sh_int vnum_bleeding;

extern const struct style_type      style_table[];

#endif /* styles_h */
