/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2004 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 **************************************************************************/

/***************************************************************************
*    ROM 2.4 is copyright 1993-1998 Russ Taylor                            *
*    ROM has been brought to you by the ROM consortium                     *
*        Russ Taylor (rtaylor@hypercube.org)                               *
*        Gabrielle Taylor (gtaylor@hypercube.org)                          *
*        Brian Moore (zump@rom.org)                                        *
*    By using this code, you have agreed to follow the terms of the        *
*    ROM license, in the file Rom24/doc/rom.license                        *
***************************************************************************/

#include <sys/types.h>
#include <sys/time.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <time.h>
#include "thoc.h"
#include "interp.h"
#include "recycle.h"
#include "tables.h"
#include "color.h"
#include "communicate.h"
#include "thoc.h"
#include "options.h"

void visible(Character *ch, char *argument, bool fEcho );
void quit( Character *ch, char *argument,bool fDelete );
void log_channel( Character *ch, int channel, char *argument );

void do_delet( Character *ch, char *argument)
{
    cprintf(ch,"You must type the full command to delete yourself.\n\r");
}

void do_delete( Character *ch, char *argument)
{
    char strsave[MAX_INPUT_LENGTH];

    if (IS_NPC(ch))
    {
        cprintf(ch,"NPCs cannot delete.\n\r");
        return;
    }
  
   if (ch->pcdata->confirm_delete)
   {
        if (argument[0] != '\0')
        {
            cprintf(ch,"Delete status removed.\n\r");
            ch->pcdata->confirm_delete = FALSE;
            return;
        }
        else
        {
            char backup_name[80];
            char time_str[80];
            struct tm *time_tm;

            time_tm = localtime( &current_time );
            strftime(time_str,sizeof(time_str),"%Y%m%d-%H%M%S",time_tm);

            snprintf(backup_name,sizeof(backup_name),"%s/deleted/%s.%s", 
                "/mud/crevetier/archive/inactive_pfiles",
                capitalize( ch->name ), time_str );
            sprintf( strsave, "%s%s", getDirectory(PLAYER_DIR),
                                      capitalize( ch->name ) );

            if ( rename( strsave, backup_name ) < 0 )
                log_error("Could not move %s to %s",  strsave,
                                                          backup_name );

            wiznet("$N deletes $Mself.",ch,NULL,0,0,0);

            stop_fighting(ch,TRUE);
            act("$N deletes $Mself.",ch,NULL,NULL,TO_ROOM);
            cprintf(ch,"&RNotice&x: deleted characters are backed up.\n\r"
              "If you change your mind later, email admin@www.crevetier.com\n\r"
              "and request that your deleted character be restored.\n\r");
            quit(ch,argument,TRUE);
            unlink(strsave);

            GameInfo.totalDeleted++;    
            GameInfo.totalCurrent--;

            save_game_info();
            return;
        }
    }

    if (argument[0] != '\0')
    {
        cprintf(ch,"To delete, just type 'delete' by itself, twice.\n\r");
        return;
    }

    cprintf(ch,"Type 'delete' again to confirm this command.\n\r");
    cprintf(ch,"Type 'delete cancel' to undo your delete status.\n\r");
    ch->pcdata->confirm_delete = TRUE;
    wiznet("$N is contemplating deletion.",ch,NULL,0,0,get_trust(ch));
    return;
}

/* RT code to display channel status */
void do_channels( Character *ch, char *argument)
{
    /* lists all channels and their status */
    cprintf(ch," Channel       Status\n\r");
    cprintf(ch,"---------------------\n\r");
 
    cprintf(ch,"gossip         ");
    if (!IS_SET(ch->comm,COMM_NOGOSSIP))
        cprintf(ch,"On\n\r");
    else
        cprintf(ch,"Off\n\r");

    cprintf(ch,"auction        ");
    if (!IS_SET(ch->comm,COMM_NOAUCTION))
        cprintf(ch,"On\n\r");
    else
        cprintf(ch,"Off\n\r");

    cprintf(ch,"music          ");
    if (!IS_SET(ch->comm,COMM_NOMUSIC))
        cprintf(ch,"On\n\r");
    else
        cprintf(ch,"Off\n\r");

    cprintf(ch,"advice         ");
    if (!IS_SET(ch->comm,COMM_NOQUESTION))
        cprintf(ch,"On\n\r");
    else
        cprintf(ch,"Off\n\r");

    cprintf(ch,"quest          ");
    if (!IS_SET(ch->comm,COMM_NOQUEST))
        cprintf(ch,"On\n\r");
    else
        cprintf(ch,"Off\n\r");

    cprintf(ch,"grats          ");
    if (!IS_SET(ch->comm,COMM_NOGRATS))
      cprintf(ch,"On\n\r");
    else
      cprintf(ch,"Off\n\r");

    if(ch->clan != NULL && !clan_is_independent(ch->clan))
    {
        cprintf(ch,"clan           ");
        if (!IS_SET(ch->comm, COMM_NOCLAN))
            cprintf(ch,"On\n\r");
        else
            cprintf(ch,"Off\n\r");
    }

    if(IS_IMMORTAL(ch))
    {
        int cmd;
        for(cmd = 0; cmd_table[cmd].name[0] != '\0';cmd++)
        {
            if(!strcmp(cmd_table[cmd].name,"wizclan"))
            {
                if(cmd_table[cmd].level <= ch->level)
                {
                    cprintf(ch,"wizclan        ");
                    if (IS_SET(ch->comm, COMM_WIZCLAN))
                        cprintf(ch,"On");
                    else
                        cprintf(ch,"Off");

                    cprintf(ch, " [%s]\n\r", ch->wizclan != NULL ? 
                                             ch->wizclan->name : "All");
                }
                break;
            }
        }
    }

    cprintf(ch,"ooc            ");
    if (!IS_SET(ch->comm,COMM_NOOOC))
        cprintf(ch,"On\n\r");
    else
        cprintf(ch,"Off\n\r");

    if (IS_IMMORTAL(ch))
    {
      cprintf(ch,"immtalk        ");
      if(!IS_SET(ch->comm,COMM_NOWIZ))
            cprintf(ch,"On\n\r");
      else
            cprintf(ch,"Off\n\r");
    }

    cprintf(ch,"tells          ");
    if (!IS_SET(ch->comm,COMM_DEAF))
        cprintf(ch,"On\n\r");
    else
        cprintf(ch,"Off\n\r");

    cprintf(ch,"quiet mode     ");
    if (IS_SET(ch->comm,COMM_QUIET))
        cprintf(ch,"On\n\r");
    else
        cprintf(ch,"Off\n\r");

    if (IS_SET(ch->comm,COMM_AFK))
        cprintf(ch,"You are [Away].\n\r");

    if (IS_SET(ch->comm,COMM_SNOOP_PROOF))
        cprintf(ch,"You are immune to snooping.\n\r");

    if (ch->lines != PAGELEN)
    {
        if (ch->lines)
        {
            cprintf(ch,"You display %d lines of scroll.\n\r",ch->lines+2);
        }
        else
            cprintf(ch,"Scroll buffering is off.\n\r");
    }

    if (ch->prompt != NULL)
    {
        cprintf(ch,"Your current prompt is: %s\n\r",ch->prompt);
    }

    if (IS_SET(ch->comm,COMM_NOSHOUT))
        cprintf(ch,"You cannot shout.\n\r");
  
    if (IS_SET(ch->comm,COMM_NOTELL))
        cprintf(ch,"You cannot use tell.\n\r");
 
    if (IS_SET(ch->comm,COMM_NOCHANNELS))
        cprintf(ch,"You cannot use channels.\n\r");

    if (IS_SET(ch->comm,COMM_NOEMOTE))
        cprintf(ch,"You cannot show emotions.\n\r");

    return;
}

/* RT deaf blocks out all shouts */
void do_deaf( Character *ch, char *argument)
{
   if (IS_SET(ch->comm,COMM_DEAF))
   {
        cprintf(ch,"You can now hear tells again.\n\r");
        REMOVE_BIT(ch->comm,COMM_DEAF);
   }
   else 
   {
        cprintf(ch,"From now on, you won't hear tells.\n\r");
        SET_BIT(ch->comm,COMM_DEAF);
   }
}

/* RT quiet blocks out all communication */
void do_quiet ( Character *ch, char * argument)
{
    if (IS_SET(ch->comm,COMM_QUIET))
    {
        cprintf(ch,"Quiet mode removed.\n\r");
        REMOVE_BIT(ch->comm,COMM_QUIET);
    }
    else
    {
        cprintf(ch,"From now on, you will only hear says and emotes.\n\r");
        SET_BIT(ch->comm,COMM_QUIET);
    }
}

/* afk command */
void do_afk( Character *ch, char * argument)
{
    if (IS_SET(ch->comm,COMM_AFK))
    {
        if(buf_string(ch->pcdata->buffer)[0] == '\0')
            cprintf(ch,"[Away] mode removed.  You have no tells to replay.\n\r");
        else
            cprintf(ch,"[Away] mode removed.  Type 'replay' to see tells.\n\r");

        act("$n returns from being [Away].",ch,NULL,NULL,TO_ROOM);
        REMOVE_BIT(ch->comm,COMM_AFK);
    }
    else
    {
        cprintf(ch,"You are now in [Away] mode.\n\r");
        act("$n goes [Away].",ch,NULL,NULL,TO_ROOM);
        SET_BIT(ch->comm,COMM_AFK);
    }
}

void do_reveal( Character *ch, char *argument )
{
    Character *victim;

    if ( argument[0] == '\0' )
    {
        cprintf(ch,"Usage: reveal <character>\n\r");
        return;
    }

    if ( (victim = get_char_room(ch,argument)) == NULL )
    {
        cprintf(ch,"You don't see that person here.\n\r");
        return;
    }

    if ( !IS_AFFECTED(victim,AFF_SNEAK) )
    {
        act("$N is not in stealth mode.",ch,NULL,victim,TO_CHAR);
        return;
    }

    visible(victim,"",ECHO_OFF);
    act("$n reveals the presence of $N!",ch,NULL,victim,TO_NOTVICT);
    act("You reveal the presence of $N.",ch,NULL,victim,TO_CHAR);
    act("$n reveals your presence to the room.",ch,NULL,victim,TO_VICT);
    return;
}

void do_replay (Character *ch, char *argument)
{
    if (IS_NPC(ch))
    {
        cprintf(ch,"NPC: You can't replay.\n\r");
        return;
    }

    if (buf_string(ch->pcdata->buffer)[0] == '\0')
    {
        cprintf(ch,"You have no tells to replay.\n\r");
        return;
    }

    page_to_char(buf_string(ch->pcdata->buffer),ch);
    clear_buf(ch->pcdata->buffer);
}

void channel_use( Character *ch, char *argument, int channel )
{
    Descriptor *d;
    char wizi[20];
    char incog[20];

    // Shifters and switchers    
    if ( ch->desc && ch->desc->original )
        ch = ch->desc->original;

    if (argument[0] == '\0' )
    {
        TOGGLE_BIT(ch->comm,channel_table[channel].on_off_bit);
        cprintf(ch,"%s channel is now %s.\n\r",
                capitalize(channel_table[channel].name),
                IS_SET(ch->comm,channel_table[channel].on_off_bit) ? "Off" 
                                                                   : "On" );
    }
    else  
    {
        if (IS_SET(ch->comm,COMM_QUIET))
        {
            cprintf(ch,"You must turn off quiet mode first.\n\r",ch);
            return;
        }
 
        if (IS_SET(ch->comm,COMM_NOCHANNELS))
        {
            cprintf(ch,"The Administrators have revoked your channel priviliges.\n\r");
            return;
        }

        REMOVE_BIT(ch->comm,channel_table[channel].on_off_bit);
        wizi[0] = '\0';
        incog[0] = '\0';

        if ( !IS_IMMORTAL(ch) && IS_SET(channel_table[channel].flags,CHAN_SAME_CLAN)
          && !has_permission(ch,GCOP_USE_GUILDCHAT) )
        {
            cprintf(ch,"Your guild rank lacks permissons to speak on clan chat.\n\r");
            return;
        }

        /* Immortals at least level 55 get their color left alone */
        if ( ch->level < 55 )
            stripColorInline( argument );

        if ( ch->invis_level )
            sprintf(wizi,"(Wizi@%d) ",ch->invis_level);
        if ( ch->incog_level )
            sprintf(incog,"(Incog@%d) ",ch->incog_level);
    
        if ( channel_table[channel].minimum_level > 51 )
            cprintf(ch,"%s%s(&%c%s&x) You: %s\n\r",
                    wizi[0] != '\0' ? wizi : "",
                    incog[0] != '\0' ? incog : "",
                    !IS_NPC(ch) ? ch->pcdata->customChannelColor[channel] : 'W',
                    capitalize(channel_table[channel].name),
                    argument);
        else
            cprintf(ch,"%s%sYou %s '&%c%s&x'\n\r",
                    wizi[0] != '\0' ? wizi : "",
                    incog[0] != '\0' ? incog : "",
                    channel_table[channel].verb,
                    !IS_NPC(ch) ? ch->pcdata->customChannelColor[channel] : 'W',
                    argument);

        if ( ch->shapeshifted )
            ch = ch->shapeshifted;

        log_channel( ch, channel, argument );

        for ( d = descriptor_list; d != NULL; d = d->next )
        {
            Character *victim;

            victim = d->original ? d->original : d->character;

            if ( !victim )
                continue;
            else
            if ( victim->shapeshifted )
                victim = victim->shapeshifted;
 
            if ( d->connected == CON_PLAYING &&
                 d->character != ch &&
                 !IS_SET(victim->comm,channel_table[channel].on_off_bit) &&
                 !IS_SET(victim->comm,COMM_QUIET) &&
                 victim->level >= channel_table[channel].minimum_level )
            {
                char buf[MAX_INPUT_LENGTH];

                if( !IS_SET(channel_table[channel].flags,CHAN_SAME_CLAN) ||

                    // All one boolean from here down
                    (IS_SET(channel_table[channel].flags,CHAN_SAME_CLAN) && 
                      (is_same_clan(ch,victim) ||
                        (  IS_IMMORTAL(ch) &&
                           IS_SET(ch->comm,COMM_WIZCLAN) &&
                           ch->wizclan == victim->clan &&
                           ch->wizclan != NULL &&
                           victim->clan != NULL
                        ) ||
                        (  IS_IMMORTAL(victim) && 
                           IS_SET(victim->comm,COMM_WIZCLAN) &&
                           (victim->wizclan == NULL ||
                               (victim->wizclan == ch->clan &&
                                victim->wizclan != NULL &&
                                ch->clan != NULL)
                           )
                        ) ||
                        (  IS_IMMORTAL(victim) &&
                           IS_IMMORTAL(ch) &&
                           IS_SET(victim->comm,COMM_WIZCLAN) &&
                           IS_SET(ch->comm,COMM_WIZCLAN) &&
                           (victim->wizclan == NULL ||
                               (ch->wizclan == victim->wizclan &&
                                ch->wizclan != NULL &&
                                victim->wizclan != NULL)
                            )
                        ) 
                      ) // end of is_same_clan( ) ||
                    ) // end of IS_SET(channel)...
                  ) // end of if conditional
                {
                if ( channel_table[channel].minimum_level > 51 )
                {
                    //Imms can't shift, no need to check.
                    sprintf(buf,"%s%s(&%c%s&x) $n: $t", 
                        wizi[0] != '\0' && ch->invis_level <= victim->level ? wizi : "",
                        incog[0] != '\0' && (ch->incog_level <= victim->level ||
                                             victim->in_room == ch->in_room) ? incog : "",
                        !IS_NPC(victim) ? victim->pcdata->customChannelColor[channel] : 'W',
                        capitalize(channel_table[channel].name) );
                    act_ooc(buf, ch,argument, d->character, TO_VICT,POS_SLEEPING,TRUE );
                }
                else
                if ( isIgnoring( victim, 
                                 !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name
                                                                              : ch->desc->original->name ) )
                {
                    if ( !IS_SET(victim->display,DISP_SUPPRESS_IGNORES) )
                        cprintf(victim,"&G<&xIgnoring %s: %s&G>&x\n\r",
                            !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name,
                            channel_table[channel].name );
                }
                else
                {
                    if(channel == CHANNEL_CLANTALK && IS_IMMORTAL(victim) && IS_SET(victim->comm,COMM_WIZCLAN))
                    {
                        char wizclan[20];
                        wizclan[0] = '\0';
                        if(ch->wizclan && ch->clan == NULL)
                        {
                            sprintf(wizclan,"<WizClan:%s> ",ch->wizclan->name);
                        }
    
                        sprintf(buf,"%s%s%s%s$n %s '&%c$t&x'",
                        wizi[0] != '\0' && ch->invis_level <= victim->level ? wizi : "",
                        incog[0] != '\0' && (ch->incog_level <= victim->level || victim->in_room == ch->in_room) ? incog : "",
                        wizclan[0] != '\0' ? wizclan : "", 
                        get_clan_name(ch,victim),
                        channel_table[channel].verb_3rd,
                        !IS_NPC(victim) ? victim->pcdata->customChannelColor[channel] : 'W' );
                        act_ooc(buf, ch,argument, d->character, TO_VICT,POS_SLEEPING,TRUE );
                    }
                    else
                    {
                        sprintf(buf,"%s%s$n %s '&%c$t&x'",
                        wizi[0] != '\0' && ch->invis_level <= victim->level ? wizi : "",
                        incog[0] != '\0' && (ch->incog_level <= victim->level || victim->in_room == ch->in_room) ? incog : "",
                        channel_table[channel].verb_3rd,
                        !IS_NPC(victim) ? victim->pcdata->customChannelColor[channel] : 'W' );
                        act_ooc(buf, ch,argument, d->character, TO_VICT,POS_SLEEPING,TRUE );
                    }
                }
            }
            }
        }
    }
}


void do_auction( Character *ch, char *argument )
{
    channel_use(ch,argument, CHANNEL_AUCTION );
    return;
}

/* RT chat replaced with ROM gossip */
void do_gossip( Character *ch, char *argument )
{
    channel_use(ch,argument,CHANNEL_GOSSIP);
    return;
}

void do_admin( Character *ch, char *argument )
{
    channel_use(ch,argument,CHANNEL_ADMINTALK);
    return;
}

void do_grats( Character *ch, char *argument )
{
    channel_use(ch,argument,CHANNEL_GRATS);
    return;
}

void do_hockey( Character *ch, char *argument )
{
    channel_use(ch,argument,CHANNEL_HOCKEY);
    return;
}

void do_ooctalk( Character *ch, char *argument )
{
    channel_use(ch,argument,CHANNEL_OOCTALK);
    return;
}

void do_quest( Character *ch, char *argument )
{
    channel_use(ch,argument,CHANNEL_QUEST);
    return;
}

/* RT question channel */
void do_question( Character *ch, char *argument )
{
    channel_use(ch,argument,CHANNEL_QUESTION);
    return;
}

/* RT answer channel - uses same line as questions */
void do_answer( Character *ch, char *argument )
{    
    channel_use(ch,argument,CHANNEL_ANSWER);
    return;
}

/* RT music channel */
void do_music( Character *ch, char *argument )
{
    channel_use(ch,argument,CHANNEL_MUSIC);
    return;
}

void do_clantalk( Character *ch, char *argument )
{
    if( IS_IMMORTAL(ch))
    {
        int cmd, wizclan_level = 60;

        /* If immortal and in a non independent clan, send message now */
        if(ch->clan != NULL && !clan_is_independent(ch->clan))
        {
            channel_use(ch,argument,CHANNEL_CLANTALK);
            return;
        }

        if(IS_SET(ch->comm,COMM_WIZCLAN))
        {
            if(ch->wizclan == NULL)
            {
                cprintf(ch, "You need to set wizclan to a channel before you can talk on it.\n\r");
                return;
            }
            else if(ch->wizclan != NULL && clan_is_independent(ch->wizclan))
            {
                cprintf(ch, "You must set wizclan to a non-independent clan channel.\n\r");
                return;
            }

            channel_use(ch,argument,CHANNEL_CLANTALK);
            return;
        }

        for(cmd = 0; cmd_table[cmd].name[0] != '\0';cmd++)
        {
            if(!strcmp(cmd_table[cmd].name,"wizclan"))
            {
                wizclan_level = cmd_table[cmd].level;
                break;
            }
        }

        if(!IS_SET(ch->comm,COMM_WIZCLAN))
        {
            if ( ch->clan != NULL && clan_is_independent(ch->clan) )
            {
                cprintf(ch,"Independent clans have no clan channels.\n\r");
                return;
            }

            if(ch->clan == NULL)
            {
                if(ch->level >= wizclan_level)
                    cprintf(ch, "You must turn on wizclan or join a clan to use the 'clan' channel.\n\r");
                else
                    cprintf(ch,"You must be in a clan to use the 'clan' channel.\n\r");
                return;
            }
        }
    }
    else
    {    
        if( ch->clan == NULL )
        {
            cprintf(ch,"You must be in a clan to use the 'clan' channel.\n\r");
            return;
        }
        else if ( clan_is_independent(ch->clan) )
        {
            cprintf(ch,"Independent clans have no clan channels.\n\r");
            return;
        }
    }

    channel_use(ch,argument,CHANNEL_CLANTALK);
    return;
}

void do_immtalk( Character *ch, char *argument )
{
    channel_use(ch,argument,CHANNEL_IMMTALK);
    return;
}

void do_say( Character *ch, char *argument )
{
    Character *victim;

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Say what?\n\r", ch );
        return;
    }

    if ( ch->level < 55 )
    stripColorInline( argument );

    for( victim = ch->in_room->people ; victim != NULL ; victim = victim->next_in_room )
        if ( isIgnoring( victim, !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name ) )
        {
            if ( !IS_IMMORTAL(ch) )
            {
                if ( !IS_SET(victim->display,DISP_SUPPRESS_IGNORES) && IS_AWAKE(victim) )
                    cprintf(victim,"&G<&xIgnoring %s: say&G>&x\n\r", !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name );
            }
            else
            {
                act("You bypassed an ignore setting for $N.",ch,NULL,victim,TO_CHAR);
                actprintf(ch,argument,victim,TO_VICT,"$n says '&%c$t&x'", !IS_NPC(victim) ? victim->pcdata->customSayColor : 'x' );
            }
        }
        else
            actprintf(ch,argument,victim,TO_VICT,"$n says '&%c$t&x'", !IS_NPC(victim) ? victim->pcdata->customSayColor : 'x' );

    actprintf(ch,NULL,argument,TO_CHAR,"You say '&%c$T&x'", !IS_NPC(ch) ? ch->pcdata->customSayColor : 'x' );
    return;
}

void do_tell( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH],buf[MAX_STRING_LENGTH];
    Character *victim;

    if ( IS_SET(ch->comm, COMM_NOTELL) || IS_SET(ch->comm,COMM_DEAF))
    {
        cprintf(ch, "Your message didn't get through.\n\r", ch );
        return;
    }

    if ( IS_SET(ch->comm, COMM_QUIET) )
    {
        cprintf(ch, "You must turn off quiet mode first.\n\r", ch);
        return;
    }

    if (IS_SET(ch->comm,COMM_DEAF))
    {
        cprintf(ch,"You must turn off deaf mode first.\n\r",ch);
        return;
    }

    argument = one_argument( argument, arg );

    if ( arg[0] == '\0' || argument[0] == '\0' )
    {
        cprintf(ch, "Tell whom what?\n\r", ch );
        return;
    }

     //Can't tell to NPC's at all -- Andaron
    if ( ( victim = get_char_ooc( ch, arg ) ) == NULL
    || ( IS_NPC(victim)/* && victim->in_room != ch->in_room */) )
    {
        cprintf(ch, "They aren't here.\n\r", ch );
        return;
    }

    if ( ch->level < 55 )
    stripColorInline( argument );

    if ( isIgnoring( ch, !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name ) )
    {
        cprintf(ch,"You cannot send tells to people you are ignoring.\n\r");
        return;
    }

    if ( victim->desc == NULL && !IS_NPC(victim))
    {
        bool fIgnore = FALSE;

        act("$N is linkdead, your message has been queued in $S replay buffer.", ch,NULL,victim,TO_CHAR);
     
        if ( isIgnoring( victim, !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name) )
        {
            if ( !IS_IMMORTAL(ch) )
            {
                if ( !IS_SET(victim->display,DISP_SUPPRESS_IGNORES) )
                    sprintf(buf,"&G<&xIgnoring %s: tell&G>&x\n\r", !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name );
                else
                    buf[0] = '\0';
                fIgnore = TRUE;
            }
            else
            {
                char arg2[MAX_INPUT_LENGTH];
                argument = one_argument( argument, arg2 );
                if(!strcmp(arg2, "io"))
                    cprintf(ch,"(You are bypassing an Ignore setting.)\n\r");
                else
                {
                    cprintf(ch, "They are currently ignoring you. Use tell <char> io <message> to get through.\n\r");
                    fIgnore = TRUE;
                }
            }
        }

        if ( !fIgnore )
        {
              if(IS_SET(victim->gui,GUI_FRIENDS))
                sprintf(buf,"<FriendsTell>%s tells you '%s'\n\r",PERS_OOC(ch,victim),argument);
              else
                sprintf(buf,"[%s] %s tells you '&%c%s&x'\n\r",
                    format_date( current_time, "%H:%M" ),
                    PERS_OOC(ch,victim),victim->pcdata->customTellColor,argument);
        }
        if ( strlen(buf) )
        {
            buf[0] = UPPER(buf[0]);
            add_buf(victim->pcdata->buffer,buf);
        }
        return;
    }

    if ((IS_SET(victim->comm,COMM_QUIET) || IS_SET(victim->comm,COMM_DEAF))
    && !IS_IMMORTAL(ch))
    {
        act( "$E is not receiving tells.", ch, 0, victim, TO_CHAR );
        return;
    }

    if (IS_SET(victim->comm,COMM_AFK))
    {
        bool fIgnore = FALSE;

        if (IS_NPC(victim))
        {
            act("$E is away, and not receiving tells.",ch,NULL,victim,TO_CHAR);
            return;
        }
    
        act("$E is away, but your tell will go through when $E returns.", ch,NULL,victim,TO_CHAR);
       
        if ( isIgnoring( victim, !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name ) )
        {
            if ( !IS_IMMORTAL(ch) )
            {
                if ( !IS_SET(victim->display,DISP_SUPPRESS_IGNORES) )
                    sprintf(buf,"&G<&xIgnoring %s: tell&G>&x\n\r", !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name );
                else
                    buf[0] = '\0';
                fIgnore = TRUE;
            }
            else
            {
                char arg2[MAX_INPUT_LENGTH];
                argument = one_argument( argument, arg2 );
                if(!strcmp(arg2, "io"))
                    cprintf(ch,"(You are bypassing an Ignore setting.)\n\r");
                else
                {
                    cprintf(ch, "They are currently ignoring you. Use tell <char> io <message> to get through.\n\r");
                    fIgnore = TRUE;
                }
            }
        }

        if ( !fIgnore )
        {
            if(IS_SET(victim->gui,GUI_FRIENDS))
                sprintf(buf,"<FriendsTell>%s tells you '%s'\n\r",PERS_OOC(ch,victim),argument);
            else
                sprintf(buf,"[%s] %s tells you '&%c%s&x'\n\r",
                  format_date( current_time, "%H:%M" ),
                  PERS_OOC(ch,victim),victim->pcdata->customTellColor,argument);
        }
        if ( strlen(buf) )
        {
            buf[0] = UPPER(buf[0]);
            add_buf(victim->pcdata->buffer,buf);
        }
        return;
    }

    if(IS_SET(ch->gui,GUI_FRIENDS))
    {
        act( "<FriendsTell>You tell $N '$t'", ch, argument, victim, TO_CHAR );
    }
    else
    {
        char buf[MAX_STRING_LENGTH];
        sprintf(buf, "You tell $N '&%c$t&x'", IS_NPC(ch) ? 'x' : ch->pcdata->customTellColor);
        act_ooc(buf, ch, argument, victim, TO_CHAR, POS_DEAD, TRUE);
    }

    {
        bool fIgnore = FALSE;

        if ( isIgnoring( victim, !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name) )
        {
            if ( !IS_IMMORTAL(ch) )
            {
                if ( !IS_SET(victim->display,DISP_SUPPRESS_IGNORES) )
                    cprintf(victim,"&G<&xIgnoring %s: tell&G>&x\n\r", !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name );
                fIgnore = TRUE;
            }
            else
            {
                char arg2[MAX_INPUT_LENGTH];
                argument = one_argument( argument, arg2 );
                if(!strcmp(arg2, "io"))
                    cprintf(ch,"(You are bypassing an Ignore setting.)\n\r");
                else
                {
                    cprintf(ch, "They are currently ignoring you. Use tell <char> io <message> to get through.\n\r");
                    fIgnore = TRUE;
                }
            }
        }
    
        if ( !fIgnore )
        {
            if(IS_SET(victim->gui,GUI_FRIENDS))
            {
                SET_BIT(victim->gui, GUI_RECEIVING_TELL);
                act_new("<FriendsTell>$n tells you '$t'",ch,argument,victim,TO_VICT,POS_DEAD,TRUE);
            }
            else
            {
                char buf[MAX_STRING_LENGTH];
                if( HAS_COMMOPT(victim, COMM_OPT_BEEPTELL) )
                {
                    /* If beep tell is on make it beep with a \7 */
                    sprintf(buf, "$n tells you '&%c$t&x'\7", IS_NPC(victim) ? 'x' : victim->pcdata->customTellColor);
                }
                else
                {
                    sprintf(buf, "$n tells you '&%c$t&x'", IS_NPC(victim) ? 'x' : victim->pcdata->customTellColor);
                }

                act_ooc(buf, ch, argument, victim, TO_VICT, POS_DEAD, TRUE);
//                actnprintf(ch,argument,victim,TO_VICT,POS_DEAD,TRUE,"$n tells you '&%c$t&x'", IS_NPC(victim) ? 'x' : victim->pcdata->customTellColor );
            }    
        }
    }

    victim->reply    = ch;
    return;
}



void do_reply( Character *ch, char *argument )
{
    Character *victim;
    char buf[MAX_STRING_LENGTH];

    if ( IS_SET(ch->comm, COMM_NOTELL) )
    {
        cprintf(ch, "Your message didn't get through.\n\r", ch );
        return;
    }

    if ( ( victim = ch->reply ) == NULL )
    {
        cprintf(ch, "They aren't here.\n\r", ch );
        return;
    }

    if ( ch->level < 55 )
        stripColorInline( argument );

    if ( victim->desc == NULL && !IS_NPC(victim))
    {
        bool fIgnore = FALSE;

        act("$N is linkdead, your message has been queued in $S replay buffer.",ch,NULL,victim,TO_CHAR);

        if ( isIgnoring( victim, !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name ) )
        {
            if ( !IS_IMMORTAL(ch) )
            {
                if ( !IS_SET(victim->display,DISP_SUPPRESS_IGNORES) )
                    sprintf(buf,"&G<&xIgnoring %s: reply&G>&x\n\r", !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name );
                else
                    buf[0] = '\0';
                fIgnore = TRUE;
            }
            else
            {
                char arg2[MAX_INPUT_LENGTH];
                argument = one_argument( argument, arg2 );
                if(!strcmp(arg2, "io"))
                    cprintf(ch,"(You are bypassing an Ignore setting.)\n\r");
                else
                {
                    cprintf(ch, "They are currently ignoring you. Use reply io <message> to get through.\n\r");
                    fIgnore = TRUE;
                }
            }
        }

        if ( !fIgnore ) 
        {
            if(IS_SET(victim->gui,GUI_FRIENDS))
                sprintf(buf,"<FriendsTell>%s tells you '%s'\n\r",PERS_OOC(ch,victim),argument);
            else
                sprintf(buf,"%s tells you '&%c%s&x'\n\r",PERS_OOC(ch,victim),!IS_NPC(victim)?victim->pcdata->customTellColor:'x',argument);
        }
        if ( strlen(buf) )
        {
            buf[0] = UPPER(buf[0]);
            add_buf(victim->pcdata->buffer,buf);
        }
        return;
    }

    if ((IS_SET(victim->comm,COMM_QUIET) || IS_SET(victim->comm,COMM_DEAF))
    &&  !IS_IMMORTAL(ch) && !IS_IMMORTAL(victim))
    {
        act_new( "$E is not receiving tells.", ch, 0, victim, TO_CHAR,POS_DEAD,TRUE);
        return;
    }

    if (IS_SET(victim->comm,COMM_AFK))
    {
        bool fIgnore = FALSE;

        if (IS_NPC(victim))
        {
            act_new("$E is away, and not receiving tells.", ch,NULL,victim,TO_CHAR,POS_DEAD,TRUE);
            return;
        }
 
        act_new("$E is away, but your tell will go through when $E returns.",ch,NULL,victim,TO_CHAR,POS_DEAD,TRUE);

        if ( isIgnoring( victim, !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name ) )
        {
            if ( !IS_IMMORTAL(ch) )
            {
                if ( !IS_SET(victim->display,DISP_SUPPRESS_IGNORES) )
                    sprintf(buf,"&G<&xIgnoring %s: reply&G>&x\n\r", !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name );
                else
                    buf[0] = '\0';
                fIgnore = TRUE;
            }
            else
            {
                char arg2[MAX_INPUT_LENGTH];
                argument = one_argument( argument, arg2 );
                if(!strcmp(arg2, "io"))
                    cprintf(ch,"(You are bypassing an Ignore setting.)\n\r");
                else
                {
                    cprintf(ch, "They are currently ignoring you. Use reply io <message> to get through.\n\r");
                    fIgnore = TRUE;
                }
            }
        }

        if ( !fIgnore )
        {
            if(IS_SET(victim->gui,GUI_FRIENDS))
                sprintf(buf,"<FriendsTell>%s tells you '%s'\n\r",PERS_OOC(ch,victim),argument);
            else
                sprintf(buf,"%s tells you '&%c%s&x'\n\r",PERS_OOC(ch,victim),!IS_NPC(victim)?victim->pcdata->customTellColor:'x',argument);
        }
        if ( strlen(buf) )
        {
            buf[0] = UPPER(buf[0]);
            add_buf(victim->pcdata->buffer,buf);
        }
        return;
    }

    
    if(IS_SET(ch->gui,GUI_FRIENDS))
        act_new("<FriendsTell>You tell $N '$t'",ch,argument,victim,TO_CHAR,POS_DEAD,TRUE);
    else
    {
        char buf[MAX_STRING_LENGTH];
        sprintf(buf, "You tell $N '&%c$t&x'", IS_NPC(ch) ? 'x' : ch->pcdata->customTellColor);
        act_ooc(buf, ch, argument, victim, TO_CHAR, POS_DEAD, TRUE);
    }

    {
        bool fIgnore = FALSE;

        if ( isIgnoring( victim, !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name ) )
        {
            if ( !IS_IMMORTAL(ch) )
            {
                if ( !IS_SET(victim->display,DISP_SUPPRESS_IGNORES) )
                    cprintf(victim,"&G<&xIgnoring %s: reply&G>&x\n\r", !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name );
                fIgnore = TRUE;
            }
            else
            {
                char arg2[MAX_INPUT_LENGTH];
                argument = one_argument( argument, arg2 );
                if(!strcmp(arg2, "io"))
                    cprintf(ch,"(You are bypassing an Ignore setting.)\n\r");
                else
                {
                    cprintf(ch, "They are currently ignoring you. Use reply io <message> to get through.\n\r");
                    fIgnore = TRUE;
                }
            }
        }

        if ( !fIgnore )
        {
            if(IS_SET(victim->gui,GUI_FRIENDS))
            {
                SET_BIT(victim->gui, GUI_RECEIVING_TELL);
                act_new("<FriendsTell>$n tells you '$t'",ch,argument,victim,TO_VICT,POS_DEAD,TRUE);
            }
            else
            {
                char buf[MAX_STRING_LENGTH];
                if( HAS_COMMOPT(victim, COMM_OPT_BEEPTELL) )
                {
                    /* If beep tell is on make it beep with a \7 */
                    sprintf(buf, "$n tells you '&%c$t&x'\7", IS_NPC(victim) ? 'x' : victim->pcdata->customTellColor);
                }
                else
                {
                    sprintf(buf, "$n tells you '&%c$t&x'", IS_NPC(victim) ? 'x' : victim->pcdata->customTellColor);
                }
                act_ooc(buf, ch, argument, victim, TO_VICT, POS_DEAD, TRUE);
//                actnprintf(ch,argument,victim,TO_VICT,POS_DEAD,TRUE,"$n tells you '&%c$t&x'", IS_NPC(victim) ? 'x' : victim->pcdata->customTellColor );
            }
        }
    }

    victim->reply = ch;
    return;
}



void do_yell( Character *ch, char *argument )
{
    Descriptor *d;

    if ( IS_SET(ch->comm, COMM_NOSHOUT) )
    {
        cprintf(ch, "You can't yell.\n\r", ch );
        return;
    }
 
    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Yell what?\n\r", ch );
        return;
    }

    if ( ch->level < 55 )
        stripColorInline( argument );

    act("You yell '$t'",ch,argument,NULL,TO_CHAR);
    for ( d = descriptor_list; d != NULL; d = d->next )
    {
        if ( d->connected == CON_PLAYING
        &&   d->character != ch
        &&   d->character->in_room != NULL
        &&   d->character->in_room->area == ch->in_room->area 
            &&   !IS_SET(d->character->comm,COMM_QUIET) )
        {
            if ( isIgnoring( d->character, !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name ) )
            {
                if ( !IS_SET(d->character->display,DISP_SUPPRESS_IGNORES) )
                    cprintf(d->character,"&G<&xIgnoring %s: yell&G>&x\n\r", !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name );
            }
            else
                act("$n yells '$t'",ch,argument,d->character,TO_VICT);
        }
    }

    return;
}


void do_emote( Character *ch, char *argument )
{
    Character *victim;
    if ( !IS_NPC(ch) && IS_SET(ch->comm, COMM_NOEMOTE) )
    {
        cprintf(ch, "You can't show your emotions.\n\r", ch );
        return;
    }
 
    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Emote what?\n\r", ch );
        return;
    }

    if( ch->level < 55 )
        stripColorInline( argument );

    for( victim = ch->in_room->people ; victim != NULL ; victim = victim->next_in_room )
    {
        if ( isIgnoring( victim, !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name ) )
        {
            if ( !IS_IMMORTAL(ch) )
            {
                if ( !IS_SET(victim->display,DISP_SUPPRESS_IGNORES) && IS_AWAKE(victim) )
                    cprintf(victim,"&G<&xIgnoring %s: emote&G>&x\n\r", !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name );
            }
            else
            {
                act("You bypassed an ignore setting for $N.",ch,NULL,victim,TO_CHAR);
                if(IS_SET(victim->display,DISP_NO_EMOTE_MARKS))
                    act("$N $t",victim,argument,ch,TO_CHAR);
                else
                    act("* $N $t",victim,argument,ch,TO_CHAR);
            }
        }
        else
        {
            if(IS_NPC(ch) || IS_SET(victim->display,DISP_NO_EMOTE_MARKS))
                act("$N $t",victim,argument,ch,TO_CHAR);
            else
                act("* $N $t",victim,argument,ch,TO_CHAR);
        }
    }
    return;
}


void do_pmote( Character *ch, char *argument )
{
    Character *vch;
    char *letter,*name;
    char last[MAX_INPUT_LENGTH], temp[MAX_STRING_LENGTH];
    int matches = 0;

    if ( !IS_NPC(ch) && IS_SET(ch->comm, COMM_NOEMOTE) )
    {
        cprintf(ch, "You can't show your emotions.\n\r", ch );
        return;
    }

    if ( argument[0] == '\0' )
    {
        cprintf(ch, "Emote what?\n\r", ch );
        return;
    }

    if ( ch->level < 55 )
        stripColorInline( argument );

    //No ignore check needed here, you can't ignore yourself!
    if(IS_NPC(ch) || IS_SET(ch->display,DISP_NO_EMOTE_MARKS))
        act( "$n $t", ch, argument, NULL, TO_CHAR );
    else
        act( "* $n $t", ch, argument, NULL, TO_CHAR );

    for (vch = ch->in_room->people; vch != NULL; vch = vch->next_in_room)
    {
        if (vch->desc == NULL || vch == ch)
            continue;

        if ((letter = strstr(argument,vch->name)) == NULL)
        {
            if ( isIgnoring( vch, !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name ) )
            {
                if ( !IS_IMMORTAL(ch) )
                {
                    if ( !IS_SET(vch->display,DISP_SUPPRESS_IGNORES) && IS_AWAKE(vch) )
                        cprintf(vch,"&G<&xIgnoring %s: pmote&G>&x\n\r", !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name );
                }
                else
                {
                    act("You bypassed an ignore setting for $N.",ch,NULL,vch,TO_CHAR);
                    if(IS_SET(vch->display,DISP_NO_EMOTE_MARKS))
                        act("$N $t",vch,argument,ch,TO_CHAR);
                    else
                        act("* $N $t",vch,argument,ch,TO_CHAR);
                }
            }
            else
            {
                if(IS_NPC(ch) || IS_SET(vch->display,DISP_NO_EMOTE_MARKS))
                    act("$N $t",vch,argument,ch,TO_CHAR);
                else
                    act("* $N $t",vch,argument,ch,TO_CHAR);
            }
            continue;
        }
    
        strcpy(temp,argument);
        temp[strlen(argument) - strlen(letter)] = '\0';
        last[0] = '\0';
        name = vch->name;

        for (; *letter != '\0'; letter++)
        { 
            if (*letter == '\'' && matches == strlen(vch->name))
            {
                strcat(temp,"r");
                continue;
            }
    
            if (*letter == 's' && matches == strlen(vch->name))
            {
                matches = 0;
                continue;
            }
            
            if (matches == strlen(vch->name))
            {
                matches = 0;
            }

            if (*letter == *name)
            {
                matches++;
                name++;
                if (matches == strlen(vch->name))
                {
                    strcat(temp,"you");
                    last[0] = '\0';
                    name = vch->name;
                    continue;
                }
                strncat(last,letter,1);
                continue;
            }
    
            matches = 0;
            strcat(temp,last);
            strncat(temp,letter,1);
            last[0] = '\0';
            name = vch->name;
        }

        if ( isIgnoring( vch, !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name ) )
        {
            if ( !IS_IMMORTAL(ch) )
            {
                if ( !IS_SET(vch->display,DISP_SUPPRESS_IGNORES) && IS_AWAKE(vch) )
                    cprintf(vch,"&G<&xIgnoring %s: pmote&G>&x\n\r", !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name );
            }
            else
            {
                act("You bypassed an ignore setting for $N.",ch,NULL,vch,TO_CHAR);
                if(IS_SET(vch->display,DISP_NO_EMOTE_MARKS))
                    act("$N $t",vch,temp,ch,TO_CHAR);
                else
                    act("* $N $t",vch,temp,ch,TO_CHAR);
            }
        }
        else
        {
            if(IS_NPC(ch) || IS_SET(vch->display,DISP_NO_EMOTE_MARKS))
                act("$N $t",vch,temp,ch,TO_CHAR);
            else
                act("* $N $t",vch,temp,ch,TO_CHAR);
        }
    }

    return;
}




void do_typo( Character *ch, char *argument )
{
    append_file( TYPO_FILE, argument );
    cprintf(ch, "Typo logged.\n\r", ch );
    return;
}

void do_rent( Character *ch, char *argument )
{
    cprintf(ch, "There is no rent here.  Just save and quit.\n\r", ch );
    return;
}

void do_qui( Character *ch, char *argument )
{
    cprintf(ch, "If you want to QUIT, you have to spell it out.\n\r", ch );
    return;
}

void do_quit( Character *ch, char *argument )
{
    quit(ch,argument,FALSE);
    return;
}

void quit( Character *ch, char *argument,bool fDelete )
{
    Descriptor *d,*d_next;
    int id;

    if ( IS_NPC(ch) )
        return;

    if( !fDelete && ch->pcdata->combat_timer > 0 && !IS_IMMORTAL(ch) )
    {
        cprintf(ch,"You were recently in combat, you can't quit for %d more seconds.\n\r",
            ch->pcdata->combat_timer * 6 );
        return;
    }

    if ( ch->position == POS_FIGHTING )
    {
        cprintf(ch, "No way!  You are fighting.\n\r", ch );
        return;
    }

    if ( !fDelete && ch->position  < POS_STUNNED  )
    {
        cprintf(ch, "You're not DEAD yet.\n\r", ch );
        return;
    }

    if ( ch->pcdata->rtptrs.handler )
        rtc_exit(ch, NULL, NULL, FALSE);

    cprintf(ch,"Thank you for playing.  See our website at http://www.crevetier.com/\n\r",ch);

    if(ch->desc && ch->desc->connected != CON_GET_REWARD)
    {
        act( "$n has left the game.", ch, NULL, NULL, TO_ROOM );
        log_string("%s has quit.", ch->name );
        wizprintf(ch,NULL,WIZ_LOGINS,0,get_trust(ch),
            "$N@%s rejoins the real world.", ch->desc != NULL ?
                                             ch->desc->host : "linkdead" );

        pnet("$N rejoins the real world.",ch,NULL,WIZ_LOGINS,0,get_trust(ch));
    }
    updateLastLogin( ch );

    /*
     * After extract_char the ch is no longer valid!
     */
    save_char_obj( ch );
    id = ch->id;
    d = ch->desc;
    /* If this character is shapeshifted, we need to extract the character
     * and the shifted.
     */
    if ( is_affected(ch,gsn_shapeshifting,AFF_SKILL) )
    {
        Character *wch;

        /* Find the character who shapeshifted into this one */
        for( wch = char_list ; wch != NULL ; wch = wch->next )
            if ( wch->shapeshifted == ch )
                break;

        if ( wch != NULL )
            extract_char( wch, TRUE );
        else
            log_bug("Could not find original character for a shapeshifted.");
    }
        
    extract_char( ch, TRUE );

    if ( d != NULL )
        close_socket( d );

    /* toast evil cheating bastards */
    for (d = descriptor_list; d != NULL; d = d_next)
    {
        Character *tch;

        d_next = d->next;
        tch = d->original ? d->original : d->character;
        if (tch && tch->id == id)
        {
            extract_char(tch,TRUE);
            close_socket(d);
        } 
    }

    return;
}



void do_save( Character *ch, char *argument )
{
    if ( IS_NPC(ch) )
        return;

    if ( !str_cmp(argument,"vaults") && IS_IMMORTAL(ch) )
    {
        save_vaults( );
        cprintf(ch,"Vaults saved.\n\r");
        return;
    }

    save_char_obj( ch );
    cprintf(ch,"Saving (your player is automatically saved every few minutes).\n\r", ch);
    if ( !IS_IMMORTAL(ch) )
        WAIT_STATE(ch,4 * PULSE_VIOLENCE);
    return;
}


void do_follow( Character *ch, char *argument )
{
/* RT changed to allow unlimited following and follow the NOFOLLOW rules */
    char arg[MAX_INPUT_LENGTH];
    Character *victim;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
        cprintf(ch, "Follow whom?\n\r", ch );
        return;
    }

    if ( ( victim = get_char_room( ch, arg ) ) == NULL )
    {
        cprintf(ch, "They aren't here.\n\r", ch );
        return;
    }

    if ( IS_AFFECTED(ch, AFF_CHARM) && ch->master != NULL )
    {
        act( "But you'd rather follow $N!", ch, NULL, ch->master, TO_CHAR );
        return;
    }

    if ( victim == ch )
    {
        if ( ch->master == NULL )
        {
            cprintf(ch, "You already follow yourself.\n\r");
            return;
        }
        stop_follower( ch, FALSE );
        return;
    }

    if (!IS_NPC(victim) && HAS_OPT(victim, OPT_NOFOLLOW) && !IS_IMMORTAL(ch))
    {
        act("$N doesn't seem to want any followers.",ch,NULL,victim,TO_CHAR);
        return;
    }

    if (ch->master == victim)
    {
        act("You are already following $N.",ch,NULL,victim,TO_CHAR);
        return;
    }

    if(!IS_NPC(victim))
        REMOVE_BIT(ch->pcdata->options,OPT_NOFOLLOW);
    
    if ( ch->master != NULL )
        stop_follower( ch, FALSE );

    add_follower( ch, victim );
    return;
}


void add_follower( Character *ch, Character *master )
{
    if ( ch->master != NULL )
    {
        log_bug( "Add_follower: non-null master.", 0 );
        return;
    }

    ch->master        = master;
    ch->leader        = NULL;

    if ( can_see( master, ch ) )
        act( "$n now follows you.", ch, NULL, master, TO_VICT );

    act( "You now follow $N.",  ch, NULL, master, TO_CHAR );
    return;
}


void stop_follower( Character *ch, bool fRemove )
{
    if ( ch->master == NULL )
    {
        log_bug( "Stop_follower: null master.", 0 );
        return;
    }

    if ( IS_AFFECTED(ch, AFF_CHARM) )
    {
        REMOVE_BIT( ch->affected_by, AFF_CHARM );
        affect_strip( ch, gsn_charm_person );
    }

    if ( can_see( ch->master, ch ) && ch->in_room != NULL)
    {
        act( "$n stops following you.",     ch, NULL, ch->master, TO_VICT    );
        act( "You stop following $N.",      ch, NULL, ch->master, TO_CHAR    );
    }
    if (ch->master->pet == ch)
        ch->master->pet = NULL;

    ch->master = NULL;
    ch->leader = NULL;

    if ( ch->pgroup != NULL && fRemove )
        char_from_group(ch,ch->pgroup);

    return;
}

/* nukes charmed monsters and pets */
void nuke_pets( Character *ch )
{    
    Character *pet;

    if ((pet = ch->pet) != NULL)
    {
        stop_follower(pet,TRUE);
    /*
        if (pet->in_room != NULL)
            act("$N slowly fades away.",ch,NULL,pet,TO_NOTVICT);
        extract_char(pet,TRUE);*/
    }
    ch->pet = NULL;

    return;
}

void die_follower( Character *ch )
{
    Character *fch, *fch_next;

    if ( ch->master != NULL )
    {
        if (ch->master->pet == ch)
            ch->master->pet = NULL;
        stop_follower( ch, TRUE );
    }

    ch->leader = NULL;

    for ( fch = char_list; fch != NULL; fch = fch->next )
    {
        fch_next = fch->next;

        if ( fch == ch->pet )
            continue;

        if ( fch->master == ch )
            stop_follower( fch, TRUE );
        if ( fch->leader == ch )
            fch->leader = fch;

        /*if ( IS_NPC(fch) && IS_SET(fch->act,ACT_PET) )
        {
            extract_char( fch, TRUE );
            act("$n shimmers and vanishes in a cloud of swirling mist.",fch,NULL,NULL,TO_ROOM);
        }*/
    }

    return;
}



void do_order( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    char arg[MAX_INPUT_LENGTH],arg2[MAX_INPUT_LENGTH];
    Character *victim;
    Character *och;
    Character *och_next;
    bool found = FALSE;
    bool fAll;
    int cmd;

    argument = one_argument( argument, arg );
    one_argument(argument,arg2);

    for ( cmd = 0; cmd_table[cmd].name[0] != '\0'; cmd++ )
    {
        if ( arg2[0] == cmd_table[cmd].name[0]
        &&   !str_prefix( arg2, cmd_table[cmd].name ) 
        &&     cmd_table[cmd].level <= ch->level )
        {
            found = TRUE;
            break;
        }
    }

    if ( !found )
    {
        cprintf(ch,"No such command!\n\r");
        return;
    }

    if ( IS_SET(cmd_table[cmd].flags,NOCHARM) )
    {
        cprintf(ch,"You cannot order others to execute this command.");
        return;
    }

    if ( arg[0] == '\0' || argument[0] == '\0' )
    {
    cprintf(ch, "Order whom to do what?\n\r", ch );
    return;
    }

    if ( IS_AFFECTED( ch, AFF_CHARM ) )
    {
        cprintf(ch, "You feel like taking, not giving, orders.\n\r", ch );
        return;
    }

    if ( !str_cmp( arg, "all" ) )
    {
        fAll   = TRUE;
        victim = NULL;
    }
    else
    {
        fAll   = FALSE;
        if ( ( victim = get_char_room( ch, arg ) ) == NULL )
        {
            cprintf(ch, "They aren't here.\n\r", ch );
            return;
        }
    
        if ( victim == ch )
        {
            cprintf(ch, "Aye aye, right away!\n\r", ch );
            return;
        }

        if (!IS_AFFECTED(victim, AFF_CHARM) || victim->master != ch 
        ||  (IS_IMMORTAL(victim) && victim->trust >= ch->trust))
        {
            cprintf(ch, "Do it yourself!\n\r", ch );
            return;
        }
    }

    found = FALSE;
    for ( och = ch->in_room->people; och != NULL; och = och_next )
    {
        och_next = och->next_in_room;

        if ( IS_AFFECTED(och, AFF_CHARM)
        &&   och->master == ch
        && ( fAll || och == victim ) )
        {
            found = TRUE;
            sprintf( buf, "$n orders you to '%s'.", argument );
            act( buf, ch, NULL, och, TO_VICT );
            if ( fAll )
                cprintf(ch,"You order your follower to '%s'.\n\r", argument );
            else
                actprintf(ch,NULL,victim,TO_CHAR,"You order $N to '%s'.", argument );
            interpret( och, argument );
        }
    }

    if ( found )
    {
        WAIT_STATE(ch,PULSE_VIOLENCE);
        cprintf(ch, "Ok.\n\r", ch );
    }
    else
        cprintf(ch, "You have no followers here.\n\r", ch );
    return;
}



void do_group( Character *ch, char *argument )
{
    int i;
    Character *gch;
    Character *leader;

    leader = ch;
    if ( ch->pgroup->members[0] == NULL )
    {
        cprintf(ch,"[**] Bug: do_group: leader slot is NULL, please report this to the IMMs!\n\r");
        return;
    }
    else
        leader = ch->pgroup->members[0];

    act_ooc("$N's group:",ch,NULL,ch->pgroup->members[0],TO_CHAR,POS_SLEEPING,TRUE);

    for ( i=0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
    {
        if ( (gch = ch->pgroup->members[i]) == NULL )
            continue;

        if ( is_same_group( gch, ch ) )
        {
        cprintf( ch,
        "[%2d %s] &W%-12s&x %s%3d&x%% base, %s%3d&x%% stat, %s%3d&x%% mana, %s%3d&x%% stamina, %s%3d&x%% moves\n\r",
            gch->level,
            IS_NPC(gch) ? "NPC " : class_table[gch->class].who_name,
            capitalize( PERS_OOC(gch, ch) ),
            ratio_color(gch->base_hit,gch->max_base_hit,FALSE), gch->base_hit*100/gch->max_base_hit,
            ratio_color(gch->stat_hit,max_stat_hit(gch),FALSE), gch->stat_hit*100/max_stat_hit(gch),
            ratio_color(gch->mana,max_mana(gch),TRUE), max_mana(gch) == 0 ? 0 : gch->mana*100/max_mana(gch),
            ratio_color(gch->stamina,max_stamina(gch),FALSE), gch->stamina*100/max_stamina(gch),
            ratio_color(gch->move,gch->max_move,FALSE), gch->move*100/gch->max_move );
        }
    }
    return;
}


bool char_to_group( Character *newbie, Group *group )
{
    int i;

    if ( is_in_group(newbie) ) 
    {
        log_bug("char_to_group: newbie is already in a group",0);
        return FALSE;
    }
    
    for ( i = 0 ; i < MAX_PLAYER_IN_GROUP ; i++ )
    if ( group->members[i] == NULL )
    {
        group->members[i] = newbie;
        free_group(newbie->pgroup);
        newbie->pgroup = group;
        return TRUE;
    }

    return FALSE;
}

void shuffleGroupies( Group *group )
{
    int i;

    /* we just find the last person in the group and make them leader */
    i = MAX_PLAYERS_IN_GROUP - 1;
    for( ; i > 0 ; i-- )
    {
        if ( group->members[i] != NULL )
        {
            group->members[0] = group->members[i];
            group->members[i] = NULL;
            return;
        }
    }

    return;
}

void char_from_group( Character *yank, Group *group )
{
    int i;

    /* If this guy was the group leader in his old group, we
     * need to shuffle people around
     */
    for ( i=0 ; i < MAX_PLAYER_IN_GROUP ; i++ )
    {
        if ( group->members[i] == yank )
        {
            group->members[i] = NULL;
            yank->pgroup = NULL;
            yank->pgroup = new_group( );    
            yank->pgroup->members[0] = yank; /* group stuff */
            if ( i == 0 )
                shuffleGroupies( group );
            return;
        }
    }

    log_bug("char_from_group: yank isn't in group",0);
    return;
}


/*
 * 'Split' originally by Gnort, God of Chaos.
 */
void do_split( Character *ch, char *argument )
{
    char arg1[MAX_INPUT_LENGTH],arg2[MAX_INPUT_LENGTH];
    Character *gch;
    int members;
    int amt, cur, share, extra;

    argument = one_argument( argument, arg1 );
    one_argument( argument, arg2 );

    if ( arg1[0] == '\0' || arg2[0] == '\0' || !is_number(arg1) )
    {
        cprintf(ch,"Syntax:  split <amount> <type>\n\r");
        return;
    }

    if ( (cur = currency_lookup(arg2)) < 0 )
    {
        cprintf(ch,"No such currency type '%s'.\n",arg2);
        return;
    }

    amt = atoi(arg1);
    if ( amt < 0 || amt > ch->coins[cur] )
    {
        cprintf(ch,"You must enter a number between 0 and %d.\n\r", ch->coins[cur]);
        return;
    }

    /* Splitting 'amt 'cur' */
    members = 0;
    for ( gch = ch->in_room->people; gch != NULL; gch = gch->next_in_room )
    {
        if ( is_same_group( gch, ch ) && !IS_AFFECTED(gch,AFF_CHARM))
            members++;
    }

    if ( members < 2 )
    {
        cprintf(ch, "Just keep it all.\n\r", ch );
        return;
    }
       
    share = amt / members;
    extra = amt % members;

    if ( share == 0 )
    {
        cprintf(ch, "That's not really worth your time.\n\r", ch );
        return;
    }

    ch->coins[cur]    -= amt;
    ch->coins[cur]    += ( share + extra );

    actprintf(ch,NULL,NULL,TO_CHAR,"You split %d %s coins, keeping %d for yourself.",
        amt, currency_table[cur].name, (share+extra) );

    for ( gch = ch->in_room->people; gch != NULL; gch = gch->next_in_room )
    {
        if ( gch != ch && is_same_group(gch,ch) && !IS_AFFECTED(gch,AFF_CHARM))
        {
            actprintf(ch,NULL,gch,TO_VICT,"$n splits %d %s coins.  Your share is %d %s.",
                amt, currency_table[cur].name,
                share, currency_table[cur].name );
            gch->coins[cur] += share;
        }
    }

    return;
}



void do_gtell( Character *ch, char *argument )
{
    Character *gch;

    if ( argument[0] == '\0' )
    {
    cprintf(ch, "Tell your group what?\n\r", ch );
    return;
    }

    if ( IS_SET( ch->comm, COMM_NOTELL ) )
    {
    cprintf(ch, "Your message didn't get through!\n\r", ch );
    return;
    }

    actnprintf(ch,argument,NULL,TO_CHAR,POS_SLEEPING,TRUE,"You tell the group '&%c$t&x'",
        IS_NPC(ch) ? 'x' : ch->pcdata->customGTellColor );

    for ( gch = char_list; gch != NULL; gch = gch->next )
    {
        if ( is_same_group( gch, ch ) )
        {
            char buf[MAX_STRING_LENGTH];
            sprintf(buf, "$n tells the group '&%c$t&x'", IS_NPC(gch) ? 'x' : gch->pcdata->customGTellColor);
            act_ooc(buf, ch, argument, gch, TO_VICT, POS_SLEEPING, TRUE);
//            actnprintf(ch,argument,gch,TO_VICT,POS_SLEEPING,TRUE,"$n tells the group '&%c$t&x'",
//                IS_NPC(gch) ? 'x' : gch->pcdata->customGTellColor );
        }
    }

    return;
}



/*
 * It is very important that this be an equivalence relation:
 * (1) A ~ A
 * (2) if A ~ B then B ~ A
 * (3) if A ~ B  and B ~ C, then A ~ C
 */
bool is_same_group( Character *ach, Character *bch )
{
    int i;

    if ( ach == NULL || bch == NULL)
    return FALSE;

    if ( ach->pgroup == NULL || bch->pgroup == NULL )
    return FALSE;

    for ( i=0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
     if ( ach->pgroup->members[i] == bch )
        return TRUE;

    return FALSE;

/*
    if ( ach->leader != NULL ) ach = ach->leader;
    if ( bch->leader != NULL ) bch = bch->leader;
    return ach == bch;
 */
}

bool is_in_group( Character *ch )
{
    int i;

    if ( ch->pgroup == NULL )
    {
    log_bug("is_in_group: NULL pgroup pointer",0);
    return FALSE;
    }

    for ( i=1 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
    if ( ch->pgroup->members[i] != NULL )
        return TRUE;

    return FALSE;
}


void do_invite( Character *ch, char *argument )
{
    Character *victim;
    char arg[MAX_INPUT_LENGTH];

    one_argument(argument,arg);

    if ( arg[0] == '\0' )
    {
    cprintf(ch,"Invite who?\n\r");
    return;
    }

    if ( ( victim = get_char_room( ch, arg ) ) == NULL )
    {
        cprintf(ch, "They aren't here.\n\r", ch );
        return;
    }

/*
    if ( ch->master != NULL || ( ch->leader != NULL && ch->leader != ch ) )
    {
        cprintf(ch, "But you are following someone else!\n\r", ch );
        return;
    }
*/
    if ( ch == victim )
    {
        cprintf(ch,"You can't invite yourself, you're already in your group.\n\r");
        return;
    }

    if ( ch->pgroup == NULL )
    {
        cprintf(ch,"[** Game Error **] Your pgroup pointer is NULL.\n\r");
        return;
    }

    if ( !is_leader(ch,ch->pgroup) )
    {
        cprintf(ch,"Only your group leader can invite somebody.\n\r");
        return;
    }

    if ( is_same_group( victim, ch ) )
    {
        act("$N is already in your group.",ch,NULL,victim,TO_CHAR);
        return;
    }

    act_ooc("$n invites you to join $s group.",ch,NULL,victim,TO_VICT,POS_RESTING,TRUE);
    act_ooc("You invite $N to join your group.",ch,NULL,victim,TO_CHAR,POS_RESTING,TRUE);

    if ( victim->invite != NULL )
    {
    act("But $E is considering joining another group.",ch,NULL,victim,TO_CHAR);
    act("But you are considering joining another group.",ch,NULL,victim,TO_VICT);
    return;
    }

    victim->invite = ch->pgroup;
    return;
}

void do_disband( Character *ch, char *argument )
{
    Character *other;

    if( ch->invite != NULL )
    {
        if ( (other = ch->invite->members[0] ) == NULL )
        {
           cprintf(ch,"[** GAME ERROR **] invitee leader is NULL\n\r");
           ch->invite = NULL;
           return;
        }

        act("You decline the invitation from $N.",ch,NULL,other,TO_CHAR);
        act("$n declines your invitation.",ch,NULL,other,TO_VICT);
        ch->invite = NULL;
        return;
    }

    /* Now, see if they're a member of another group */
    if ( !is_leader(ch,ch->pgroup) )
    {
        int i;

        act("You leave your group.",ch,NULL,NULL,TO_CHAR);
        for ( i = 1 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
        {
            if ( ch->pgroup->members[i] != NULL &&
             ch->pgroup->members[i] != ch )
            {
                act("$n has left the group.",ch,NULL,ch->pgroup->members[i],TO_VICT);
            }
         }    
            char_from_group(ch,ch->pgroup);
        return;
    }
    
    if ( is_leader(ch,ch->pgroup) )
    {
        int i;
        bool found=FALSE;

        /* Group leader. */
        for ( i = 1 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
          {
            if ( ch->pgroup->members[i] != NULL )
            {
                found = TRUE;
                act("$n has disbanded the group.",ch,NULL,ch->pgroup->members[i],TO_VICT);
                char_from_group( ch->pgroup->members[i], ch->pgroup );
            }
        }

        if ( !found )
            cprintf(ch,"Your group is empty.\n\r");
        else
            cprintf(ch,"You disband the group.\n\r");
        return;
    }

    log_bug("do_disband: end of function, shouldn't be able to get here",0);
}

void do_accept( Character *ch, char *argument )
{
    Character *other;

    if( ch->invite != NULL )
    {
        if ( (other = ch->invite->members[0] ) == NULL )
        {
           cprintf(ch,"[** GAME ERROR **] invitee leader is NULL\n\r");
           ch->invite = NULL;
           return;
        }

        if ( !char_to_group(ch,ch->invite) )
        {
            cprintf(ch,"That group is already full, or you're already grouped.\n\r");
            ch->invite = NULL;
            return;
        }

    ch->invite = NULL;
        act("You accept the invitation from $N.",ch,NULL,other,TO_CHAR);
        act("$n accepts your invitation.",ch,NULL,other,TO_VICT);
    }
    else
    {
    cprintf(ch,"You haven't been invited to any groups.\n\r");
    return;
    }
 
    return;
}

bool isIgnoring( Character *ch, char *name )
{
    Ignore *i;
    char buf[MAX_STRING_LENGTH];
    Character *check;

    if ( IS_NPC(ch) )
        return FALSE;

    check = get_char_ooc(ch,name);

    if(check && check->clan)
    {
        strcpy(buf, "guild ");
        strcat(buf, check->clan->name);
    }
    else
        strcpy(buf, "");
    
    for( i = ch->pcdata->ignore_list ; i ; i = i->next )
        if ( !str_cmp( i->name, name ) || !str_cmp(i->name, buf))
            return TRUE;

    return FALSE;
}

void do_ignore( Character *ch, char *argument )
{
    if ( IS_NPC(ch) )
        return;
    
    if ( argument[0] == '\0' )
    {
        cprintf(ch,"Syntax:    ignore <name>\n\r"
                   "           ignore <name>\n\r"
                "           ignore clear (Will erase your whole list)\n\r"
                   "           ignore show\n\r"
                "           ignore guild <guildname>\n\r");
        return;
    }

    if ( !str_cmp( argument, "list" ) || !str_cmp( argument, "show" ) )
    {
        Ignore *i;

        cprintf(ch,"You are ignoring the following players:\n\r");
        for( i = ch->pcdata->ignore_list ; i ; i = i->next )
            cprintf(ch," * %s\n\r", i->name );
        return;
    }

    if( !str_cmp( argument, "clear" ))
    {
        if(ch->pcdata->ignore_list)
        {
            Ignore *i, *tmp;
            cprintf(ch, "Ignore list cleared.\n\r");
            tmp = ch->pcdata->ignore_list;
            for ( i = ch->pcdata->ignore_list ; i->next != NULL ; i = i->next )
            {
                if(tmp != i)
                {//makes sure that i has scrolled to the one after tmp
                    free_ignore(tmp);
                    tmp = i;
                }
            }
            if(tmp)
                free_ignore(tmp);
            ch->pcdata->ignore_list = NULL;
        }
        else
            cprintf(ch, "Your ignore list is already empty.\n\r");
        return;
    }

    if ( isIgnoring( ch, argument ) )
    {
        Ignore *i, *tmp;
        /* Find element */
        for( i = ch->pcdata->ignore_list ; i ; i = i->next )
            if ( !str_cmp(i->name,argument) )
                break;

        if ( i == NULL )
        {
            char buf[MAX_STRING_LENGTH];
            argument = one_argument(argument, buf);
            if(strcmp(buf, "guild"))
                cprintf(ch, "You're already ignoring their guild.\n\r");
            else
            {
                cprintf(ch,"&RError&x: %s not found in your ignore list.\n\r", buf);
                log_bug("%s not in %s's ignore list",argument,ch->name);
            }
            return;
        }

        tmp = i;
        if ( tmp == ch->pcdata->ignore_list )
            ch->pcdata->ignore_list = tmp->next;
        else
        {
            for ( i = ch->pcdata->ignore_list ; i->next != NULL ; i = i->next )
                if ( i->next == tmp )
                    break;
    
            if ( i->next != tmp )
            {
                log_bug("ignore remove: tmp not in list",0);
                return;
            }
    
            i->next = tmp->next;
        }
    
        free_ignore( tmp );
        cprintf(ch,"'%s' removed from your ignore list.\n\r", argument );
        return;
    }
    else
    {
        /* Add this person */
        Ignore *i;
        Character *victim;
        i = new_ignore( );
        if ( (victim = get_char_ooc(ch,argument)) == NULL )
        {
            char buf[MAX_INPUT_LENGTH];
            argument = one_argument(argument, buf);
            if(!strcmp(buf, "guild"))
            {
                Clan *guild;
                if((guild = clan_lookup( argument )) != NULL )
                {
                    strcat(buf, " ");
                    strcat(buf, guild->name);
                    i->name = str_dup(buf);
                }
                else
                {
                    cprintf(ch, "&RWarning&x: That guild does not exist.\n\r");
                    return;
                }
            }
            else
            {
                cprintf(ch,
    "&RWarning&x: Could not find %s logged in.  We'll add that name to your ignore\n\r"
    "list, but if it doesn't match exactly the name of the person you want to\n\r"
    "ignore, you'll continue to see their communications.\n\r", buf );
                i->name = str_dup( buf );//argument has been moved into buf
            }
        }
        else
        if ( IS_NPC(victim) )
        {
            cprintf(ch,"That's an NPC.\n\r");
            return;
        }
        else
        {
            if ( victim == ch )
            {
                cprintf(ch,"You can't ignore yourself!\n\r");
                return;
            }
            i->name = str_dup( !is_affected(victim,gsn_shapeshifting,AFF_SKILL) ? victim->name : victim->desc->original->name );
        }

           i->next = ch->pcdata->ignore_list;
           ch->pcdata->ignore_list = i;
        cprintf(ch,"'%s' added to your ignore list.\n\r", i->name );
        return;
    }

    /* Shouldn't ever get here */
    return;
}

void log_channel( Character *ch, int channel, char *argument )
{
    fprintf( fpChannel, "[%s] [%s] %s: %s\n",
        format_date( current_time, "%d/%b/%Y %H:%M" ),
        channel_table[channel].name,
        ch->name, argument );
    fflush( fpChannel );
}
