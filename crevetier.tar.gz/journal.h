/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#ifndef journal_h
#define journal_h

/* Journals */
struct journal_event
{
    time_t    when;
    char      *description;
    JEvent    *next;
};

struct journal
{
    JEvent  *eventList;
    char    *recipeList;
    char    *questList;
};

Journal *   newJournal( void );
void        freeJournal( Journal *j );
JEvent *    newJEvent( void );
void        freeJEvent( JEvent *je );
void        eventToJournal( JEvent *je, Journal *j );
void        recipeToJournal( Recipe *r, Journal *j );
void        questToJournal( Quest *q, Journal *j );

void        showQuestJournal( Journal *j, Buffer *buffer );
void        showRecipeJournal( Journal *j, Buffer *buffer );
void        showEventJournal( Journal *j, Buffer *buffer );

void        freeEventList( JEvent *je );
void        addEventToJournal( Journal *j, const char *description, ... );

#endif /* journal_h */
