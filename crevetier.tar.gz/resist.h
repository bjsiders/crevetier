#ifndef resist_h
#define resist_h

#define RESIST_IMMUNE       10000

#define RESIST_FIRE             0
#define RESIST_ICE              1
#define RESIST_EARTH            2
#define RESIST_AIR              3
#define RESIST_LIGHT            4
#define RESIST_DARK             5
#define RESIST_POISON           6
#define RESIST_DISEASE          7
#define RESIST_MENTAL           8
#define RESIST_ACID             9
#define RESIST_ELECTRICITY      10
#define RESIST_SPIRIT           11
#define RESIST_SOUND            12
#define RESIST_WATER            13
#define RESIST_BODY             14
#define MAX_PC_RESISTS          15

#define RESIST_SLASH            15
#define RESIST_PIERCE           16
#define RESIST_CONCUSSION       17
#define MAX_RESIST              18

#define DF_MELEE                (A)
#define DF_MAGIC                (B)
#define DF_SUMMON               (C)
#define DF_CHARM                (D)

struct resist_tag
{
    int             value;
    int             mod;
    bool            immune;
};

#endif /* resist_h */
