#ifndef race_h
#define race_h

#include "resist.h"
#include "character.h"

#define MAX_PC_RACE                        8

struct race_type
{
    char *  name;                   // call name of the race
    bool    pc_race;                // can be chosen by pcs
    long    act;                    // act bits for the race
    long    aff;                    // aff bits for the race
    long    off;                    // off bits for the race
    long    imm;                    // imm bits for the race
    long    res;                    // res bits for the race
    long    vuln;                   // vuln bits for the race
    long    form;                   // default form flag for the race
    long    parts;                  // default parts for the race
    int     resists[MAX_RESIST];    // race resists
};

struct pc_race_type  /* additional data for pc races */
{
    char *    name;            /* MUST be in race_type */
    char      who_name[9];
    sh_int    class_mult[MAX_CLASS];    /* exp multiplier for class, * 100 */
    char *    skills[5];        /* bonus skills for the race */
    sh_int    stats[MAX_STATS];    /* starting stats */
    sh_int    max_stats[MAX_STATS];    /* maximum stats */
    sh_int    size;            /* aff bits for the race */
    short *   race_index;
    long      flags;
    int       tier;
};

struct pc_subrace_type
{
    char *      name;
    char *      who_name;
    short *     race_index;
    sh_int      stat_adj[MAX_STATS];
    short       class_mult[MAX_CLASS];
    int         exp_adj;
    short *     gsn;
    time_t *    next_avail;
    time_t *    last_avail;
    int         rarity;
    char *      patron_deity;
    char *      skills[5]; // free skills
};

extern time_t na_kevjordhur;
extern time_t na_tayana;
extern time_t na_ashinth;
extern time_t na_kutath;
extern time_t na_brombachol;
extern time_t na_gnome;
extern time_t na_halfling;
extern time_t na_halforc;

extern time_t la_kevjordhur;
extern time_t la_tayana;
extern time_t la_ashinth;
extern time_t la_kutath;
extern time_t la_brombachol;
extern time_t la_gnome;
extern time_t la_halfling;
extern time_t la_halforc;

extern short grn_human;
extern short grn_elf;
extern short grn_dwarf;
extern short grn_gnome;
extern short grn_halfling;
extern short grn_half_elf;
extern short grn_half_orc;

extern short gsn_ancois;
extern short gsn_kevjordhur;
extern short gsn_tayana;
extern short gsn_ashinth;
extern short gsn_elashod;
extern short gsn_kutath;
extern short gsn_abrainon;
extern short gsn_brombachol;
extern short gsn_gnome;
extern short gsn_halfling;
extern short gsn_halfelf;
extern short gsn_halforc;

/*
    OFF Flags
*/
#define OFF_AREA_ATTACK         (A)
#define OFF_BACKSTAB            (B)
#define OFF_BASH                (C)
#define OFF_BERSERK             (D)
#define OFF_DISARM              (E)
#define OFF_DODGE               (F)
#define OFF_FADE                (G)
#define OFF_KICK                (I)
#define OFF_PARRY               (K)
#define OFF_RESCUE              (L)
#define OFF_TRIP                (N)
#define OFF_DRAIN_TOUCH         (V)
#define ASSIST_ALL              (P)
#define ASSIST_ALIGN            (Q)
#define ASSIST_RACE             (R)
#define ASSIST_PLAYERS          (S)
#define ASSIST_GUARD            (T)
#define ASSIST_VNUM             (U)
#define ASSIST_FACTION          (W)

/*
    IMM bits
*/
#define IS_NORMAL               0
#define IS_IMMUNE               1
#define IS_RESISTANT            2
#define IS_VULNERABLE           3

/*
    IMM bits for mobs
*/
#define IMM_SUMMON              (A)
#define IMM_MAGIC               (B)
#define IMM_WEAPON              (C)
#define IMM_CHARM               (D)

/*
    FORM and PART flags
*/
#define FORM_EDIBLE             (A)
#define FORM_POISON             (B)
#define FORM_MAGICAL            (C)
#define FORM_INSTANT_DECAY      (D)
#define FORM_HAS_HIDE           (E)
#define FORM_BLESSED            (F)
#define FORM_UNHOLY             (G)
#define FORM_CONSTRUCTED        (H)
#define FORM_UNDEAD             (I)
#define FORM_INTANGIBLE         (J)
#define FORM_ANIMAL             (K)
#define FORM_HUMANOID           (L)
#define FORM_PLANT              (M)
#define FORM_SUMMONED           (N)
#define FORM_EXTRAPLANER        (O)
#define FORM_GILLS              (P)
#define FORM_VIS_NIGHT          (Q)

#define PART_HEAD               (A)
#define PART_ARMS               (B)
#define PART_LEGS               (C)
#define PART_HEART              (D)
#define PART_BRAINS             (E)
#define PART_GUTS               (F)
#define PART_HANDS              (G)
#define PART_FEET               (H)
#define PART_FINGERS            (I)
#define PART_EAR                (J)
#define PART_EYE                (K)
#define PART_LONG_TONGUE        (L)
#define PART_EYESTALKS          (M)
#define PART_TENTACLES          (N)
#define PART_FINS               (O)
#define PART_WINGS              (P)
#define PART_TAIL               (Q)
#define PART_CLAWS              (U)
#define PART_FANGS              (V)
#define PART_HORNS              (W)
#define PART_SCALES             (X)
#define PART_TUSKS              (Y)

/*
    AFF flags
*/
#define AFF_BLIND               (A)
#define AFF_INVISIBLE           (B)
#define AFF_DETECT_EVIL         (C)
#define AFF_DETECT_INVIS        (D)
#define AFF_DETECT_MAGIC        (E)
#define AFF_DETECT_HIDDEN       (F)
#define AFF_DETECT_GOOD         (G)
#define AFF_FAERIE_FIRE         (I)
#define AFF_INFRARED            (J)
#define AFF_CURSE               (K)
#define AFF_MESMERIZE           (L)
#define AFF_POISON              (M)
#define AFF_PROTECT_EVIL        (N)
#define AFF_PROTECT_GOOD        (O)
#define AFF_SNEAK               (P)
#define AFF_SLEEP               (R)
#define AFF_CHARM               (S)
#define AFF_FLYING              (T)
#define AFF_PASS_DOOR           (U)
#define AFF_HASTE               (V)
#define AFF_CALM                (W)
#define AFF_PLAGUE              (X)
#define AFF_DISEASE             (X)
#define AFF_WEAKEN              (Y)
#define AFF_DARK_VISION         (Z)
#define AFF_BERSERK             (aa)
#define AFF_SWIM                (bb)
#define AFF_REGENERATION        (cc)
#define AFF_SLOW                (dd)
#define AFF_DETECT_UNDEAD       (ee)

/*
    Size defines
*/
#define SIZE_TINY               0
#define SIZE_SMALL              1
#define SIZE_MEDIUM             2
#define SIZE_LARGE              3
#define SIZE_HUGE               4
#define SIZE_GIANT              5

#define RACE_NO_SUBRACES        (A)

#define SUBRACE_COMMON          0   // always
#define SUBRACE_UNCOMMON        1   // once every few days
#define SUBRACE_RARE            2   // once every week
#define SUBRACE_VERY_RARE       3   // once every few weeks
#define SUBRACE_LEGENDARY       4   // once every month

#define MINTIME_UNCOMMON        (60*60*24)
#define MINTIME_RARE            (MINTIME_UNCOMMON*7)
#define MINTIME_VERY_RARE       (MINTIME_RARE*2)
#define MINTIME_LEGENDARY       (MINTIME_VERY_RARE*2)

extern const   struct  race_type         race_table  [];  
extern const   struct  pc_subrace_type   subrace_table [];
extern const   struct  pc_race_type      pc_race_table   [];

#endif /* race_h */
