/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,	   *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *									   *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael	   *
 *  Chastain, Michael Quan, and Mitchell Tse.				   *
 *									   *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc	   *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.						   *
 *									   *
 *  Much time and thought has gone into this software and you are	   *
 *  benefitting.  We hope that you share your changes too.  What goes	   *
 *  around, comes around.						   *
 ***************************************************************************/
 
/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#if defined(macintosh)
#include <types.h>
#include <time.h>
#else
#include <sys/types.h>
#include <sys/time.h>
#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "thoc.h"
#include "magic.h"

bool gate( Character *ch, int vnum );

void do_teleport(Character *ch, char *argument)
{
    Character *mob;
    int cost;
	int vnum;

    /* check for healer */
    for ( mob = ch->in_room->people; mob; mob = mob->next_in_room )
    {
        if ( IS_NPC(mob) && IS_SET(mob->act, ACT_TELEPORTER) )
            break;
    }
 
    if ( mob == NULL )
    {
        cprintf(ch, "There is no <Teleporter> here.\n\r" );
        return;
    }

	if ( argument[0] == '\0' )
	{
		act("$N informs you of the services $E offers:",ch,NULL,mob,TO_CHAR);
		cprintf(ch," Type:  teleport <location> where location is one of the following:\n\r");
		cprintf(ch,	"    Lokjavek:       50&Yg&x (remote wood southeast of Kevjordhur)\n\r"
					"    Selith:         10&Yg&x (plains north of Khavanov)\n\r" );

		return;
	}

	if ( !str_prefix(argument,"lokjavek") )
	{
		cost = 5000;
		vnum = 20047;
	}
	else
	if ( !str_prefix(argument,"selith") )
	{
		cost = 1000;
		vnum = 447;
	}
	else
	{
		act("$N says 'I'm not sure what you're asking.'",ch,NULL,mob,TO_CHAR);
		return;
	}

    if (cost > money_total(ch) )
    {
		act("$N says 'You do not have enough money for my services.'", ch,NULL,mob,TO_CHAR);
		return;
    }

    WAIT_STATE(ch,PULSE_PER_SECOND * 5);

    deduct_cost(ch,cost);
    coins_to_merchant( mob, cost );

	actprintf(ch,NULL,mob,TO_CHAR,"$N teleports your group!");
	gate( ch, vnum );
	return;
}

void do_heal(Character *ch, char *argument)
{
    Character *mob;
    int cost;
	int sn;
	SpellIndex* pSpellIndex;

    /* check for healer */
    for ( mob = ch->in_room->people; mob; mob = mob->next_in_room )
    {
        if ( IS_NPC(mob) && IS_SET(mob->act, ACT_IS_HEALER) )
            break;
    }
 
    if ( mob == NULL )
    {
        cprintf(ch, "There is no <Healer> here.\n\r" );
        return;
    }

	if ( argument[0] == '\0' )
	{
		act("$N informs you of the services $E offers:",ch,NULL,mob,TO_CHAR);
		cprintf(ch," Type: heal <type> where type is one of the following:\n\r");
		cprintf(ch,	"    minor:       1&Yg&x\n\r"
					"    light:       2&Yg&x\n\r"
					"    moderate:    4&Yg&x\n\r"
					"    serious:     10&Yg&x\n\r"
					"    critical:    20&Yg&x\n\r\n\r"
					"    poison:      5&Yg&x\n\r"
					"    disease:     5&Yg&x\n\r\n\r"
					"    resurrect:   %s\n\r",
						money_breakdown( ch->pcdata->lost_xp * 2 * 75 / 100 ) );

		return;
	}

	if( !str_prefix(argument,"resurrect") )
	{
		if ( ch->pcdata->lost_xp <= 0 )
		{
			act("You are in no need of resurrection.",ch,NULL,NULL,TO_CHAR);
			return;
		}
		cost = ch->pcdata->lost_xp * 2 * 75 / 100;
		sn = vnum_rejuvenate;
	}
	else
	if ( !str_prefix(argument,"minor") )
	{
		cost = 100;
		sn = vnum_cure_minor_wounds;
	}
	else
	if ( !str_prefix(argument,"light") )
	{
		cost = 200;
		sn = vnum_cure_light_wounds;
	}
	else
	if ( !str_prefix(argument,"moderate") )
	{
		cost = 400;
		sn = vnum_cure_moderate_wounds;
	}
	else
	if ( !str_prefix(argument,"serious") )
	{
		cost = 1000;
		sn = vnum_cure_serious_wounds;
	}
	else
	if ( !str_prefix(argument,"critical") )
	{
		cost = 2000;
		sn = vnum_cure_critical_wounds;
	}
	else	
	if ( !str_prefix(argument,"poison") )
	{
		cost = 500;
		sn = vnum_cure_poison;
	}
	else
	if ( !str_prefix(argument,"disease") )
	{
		cost = 500;
		sn = vnum_cure_disease;
	}
	else
	{
		act("$N says 'I'm not sure what you're asking.'",ch,NULL,mob,TO_CHAR);
		return;
	}

    if (cost > money_total(ch) )
    {
		act("$N says 'You do not have enough money for my services.'", ch,NULL,mob,TO_CHAR);
		return;
    }

    WAIT_STATE(ch,PULSE_PER_SECOND * 5);

	if( (pSpellIndex = get_spell_index(sn)) != NULL)
	{
		deduct_cost(ch,cost);
		coins_to_merchant( mob, cost );

		actprintf(ch,NULL,mob,TO_CHAR,"$N casts %s.",pSpellIndex->name );
		(*(pSpellIndex->spell_fun))( sn, mob->level, mob, (void *) ch, TARGET_CHAR);
	}
	else
	{
		log_bug("do_heal: Spell index not found(%d)",sn);
	}

	return;
}

void processNewbieHealer( Character *ch )
{
	Character *victim;

	for( victim = ch->in_room->people ; victim != NULL ; victim = victim->next_in_room )
	{
		if ( IS_NPC(victim) || victim->clan != NULL || victim->level > 10 )
			continue;

		if( victim->stat_hit < max_stat_hit( victim ) ||
			victim->base_hit < victim->max_base_hit )
		{
			/* cast 'cure light' */
			int sn;
			SpellIndex* pSpellIndex;

			if( (sn = spell_lookup("cure light wounds",-1)) <= 0 )
			{
				log_bug("healer: no sn for cure light wounds");
				return;
			}

			if( (pSpellIndex = get_spell_index(sn)) != NULL)
			{
				actprintf(victim,NULL,ch,TO_CHAR,"$N casts %s.",pSpellIndex->name );
				actprintf(victim,NULL,ch,TO_ROOM,"$N casts %s.",pSpellIndex->name );
				(*(pSpellIndex->spell_fun))(sn,ch->level,ch,(void *)victim,TARGET_CHAR);
				return;
			}
			else
			{
				log_bug("processNewbieHealer: Spell index not found(%d)",sn);
			}
		}
	}

	return;
}
