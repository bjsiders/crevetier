/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  File: olc_act.c                                                        *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 *                                                                         *
 *  This code was freely distributed with the The Isles 1.1 source code,   *
 *  and has been used here for OLC - OLC would not be what it is without   *
 *  all the previous coders who released their source code.                *
 *                                                                         *
 ***************************************************************************/



#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "thoc.h"
#include "olc.h"
#include "tables.h"
#include "lookup.h"
#include "recycle.h"


struct olc_help_type
{
    char *command;
    const void *structure;
    char *desc;
};

bool show_version( Character *ch, char *argument )
{
    send_to_char( OLCVERSION, ch );
    send_to_char( "\n\r", ch );
    send_to_char( AUTHOR, ch );
    send_to_char( "\n\r", ch );
    send_to_char( DATE, ch );
    send_to_char( "\n\r", ch );
    send_to_char( CREDITS, ch );
    send_to_char( "\n\r", ch );

    return FALSE;
}    

/*
 * This table contains help commands and a brief description of each.
 * ------------------------------------------------------------------
 */
const struct olc_help_type help_table[] =
{
    {	"area",		area_flags,	 "Area attributes."		 },
    {	"room",		room_flags,	 "Room attributes."		 },
    {	"sector",	sector_flags,	 "Sector types, terrain."	 },
    {	"exit",		exit_flags,	 "Exit types."			 },
    {	"type",		type_flags,	 "Types of objects."		 },
    {	"extra",	extra_flags,	 "Object attributes."		 },
    {	"wear",		wear_flags,	 "Where to wear object."	 },
    {	"spec",		spec_table,	 "Available special programs." 	 },
    {	"sex",		sex_flags,	 "Sexes."			 },
    {	"act",		act_flags,	 "Mobile attributes."		 },
    {	"affect",	affect_flags,	 "Mobile affects."		 },
    {   "apply",	apply_flags,	 "Affect apply locations."	},
    {	"wear-loc",	wear_loc_flags,	 "Where mobile wears object."	 },
    {   "furniture",	furniture_flags, "Positions at furniture."	 },
    {   "portal",	portal_flags,	 "Portal/gate flags."		 },
    {	"spells",	skill_table,	 "Names of current spells." 	 },
    {	"weapon",	weapon_flags,	 "Type of weapon." 		 },
    {	"container",	container_flags, "Container status."		 },
    {	"liquid",	liq_table,	 "Types of liquids."		},
    {   "damtypes",	weapon_flags,	 "Attack/damage types."		},

/* ROM specific bits: */

    {	"ac",		ac_type,	 "Ac for different attacks."	 },
    {	"form",		form_flags,	 "Mobile body form."	         },
    {	"part",		part_flags,	 "Mobile body parts."		 },
    {	"imm",		imm_flags,	 "Mobile immunity."		 },
    {	"resists",		resist_flags,	 "Mobile resistance."	         },
    {	"off",		off_flags,	 "Mobile offensive behaviour."	 },
    {	"size",		size_flags,	 "Mobile size."			 },
    {   "position",     position_flags,  "Mobile positions."             },
    {	"material",	material_type,	 "Material mob/obj is made from."},
    {   "wclass",       weapon_class,    "Weapon class."                 }, 
    {   "wtype",        weapon_type_olc,  "Special weapon type."	 },
    {	"",		0,		 ""				 }
};



/*
 * List all bits in-line
 */
char *show_bit_list(  const struct flag_type *flag_table )
{
    static char buf  [ MAX_STRING_LENGTH ];
    int  flag;
 
    buf[0] = '\0';
    for (flag = 0; flag_table[flag].name != NULL && flag_table[flag].name[0] != '\0'; flag++)
    {
		if ( flag_table[flag].settable )
		{
			strcat( buf, " ");
	    	strcat( buf, flag_table[flag].name );
		}
    }

	if ( buf[0] == '\0' )
		return buf;
	else
		return buf + 1; 
}

/*****************************************************************************
 Name:		show_flag_cmds
 Purpose:	Displays settable flags and stats.
 Called by:	show_help(olc_act.c).
 ****************************************************************************/
void show_flag_cmds( Character *ch, const struct flag_type *flag_table )
{
    char buf  [ MAX_STRING_LENGTH ];
    char buf1 [ MAX_STRING_LENGTH ];
    int  flag;
    int  col;
 
    buf1[0] = '\0';
    col = 0;
    for (flag = 0; flag_table[flag].name != NULL && flag_table[flag].name[0] != '\0'; flag++)
    {
	if ( flag_table[flag].settable )
	{
	    sprintf( buf, "%-19.18s", flag_table[flag].name );
	    strcat( buf1, buf );
	    if ( ++col % 4 == 0 )
		strcat( buf1, "\n\r" );
	}
    }
 
    if ( col % 4 != 0 )
	strcat( buf1, "\n\r" );

    send_to_char( buf1, ch );
    return;
}


/*****************************************************************************
 Name:		show_skill_cmds
 Purpose:	Displays all skill functions.
 		Does remove those damn immortal commands from the list.
 		Could be improved by:
 		(1) Adding a check for a particular class.
 		(2) Adding a check for a level range.
 Called by:	show_help(olc_act.c).
 ****************************************************************************/
void show_skill_cmds( Character *ch, int tar )
{
    char buf  [ MAX_STRING_LENGTH ];
    char buf1 [ MAX_STRING_LENGTH*2 ];
    int  sn;
    int  col;
 
    buf1[0] = '\0';
    col = 0;
    for (sn = 0; sn < MAX_SKILL; sn++)
    {
	if ( !skill_table[sn].name )
	    break;

	if ( !str_cmp( skill_table[sn].name, "reserved" )
	  || skill_table[sn].spell_fun == NULL 
	  || skill_table[sn].type == SKILL_WEAPON )
	    continue;

	if ( tar == -1 || skill_table[sn].target == tar )
	{
	    sprintf( buf, "%-19.18s", skill_table[sn].name );
	    strcat( buf1, buf );
	    if ( ++col % 4 == 0 )
		strcat( buf1, "\n\r" );
	}
    }
 
    if ( col % 4 != 0 )
	strcat( buf1, "\n\r" );

    send_to_char( buf1, ch );
    return;
}



/*****************************************************************************
 Name:		show_spec_cmds
 Purpose:	Displays settable special functions.
 Called by:	show_help(olc_act.c).
 ****************************************************************************/
void show_spec_cmds( Character *ch )
{
    char buf  [ MAX_STRING_LENGTH ];
    char buf1 [ MAX_STRING_LENGTH ];
    int  spec;
    int  col;
 
    buf1[0] = '\0';
    col = 0;
    send_to_char( "Preceed special functions with 'spec_'\n\r\n\r", ch );
    for (spec = 0; spec_table[spec].name != NULL; spec++)
    {
	sprintf( buf, "%-19.18s", &spec_table[spec].name[5] );
	strcat( buf1, buf );
	if ( ++col % 4 == 0 )
	    strcat( buf1, "\n\r" );
    }
 
    if ( col % 4 != 0 )
	strcat( buf1, "\n\r" );

    send_to_char( buf1, ch );
    return;
}

void show_liquids( Character *ch )
{
    char buf  [ MAX_STRING_LENGTH ];
    char buf1 [ MAX_STRING_LENGTH ];
    int  liq;
    int  col;
 
    buf1[0] = '\0';
    col = 0;
    for (liq = 0; liq_table[liq].liq_name != NULL ; liq++)
    {
	sprintf( buf, "%-19.18s", &liq_table[liq].liq_name[0] );
	strcat( buf1, buf );
	if ( ++col % 4 == 0 )
	    strcat( buf1, "\n\r" );
    }
 
    if ( col % 4 != 0 )
	strcat( buf1, "\n\r" );

    send_to_char( buf1, ch );
    return;
}



/*****************************************************************************
 Name:		show_help
 Purpose:	Displays help for many tables used in OLC.
 Called by:	olc interpreters.
 ****************************************************************************/
bool show_help( Character *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    char arg[MAX_INPUT_LENGTH];
    char spell[MAX_INPUT_LENGTH];
    int cnt;

    argument = one_argument( argument, arg );
    one_argument( argument, spell );

    /*
     * Display syntax.
     */
    if ( arg[0] == '\0' )
    {
	send_to_char( "Syntax:  ? [command]\n\r\n\r", ch );
	send_to_char( "[command]  [description]\n\r", ch );
	for (cnt = 0; help_table[cnt].command[0] != '\0'; cnt++)
	{
	    sprintf( buf, "%-10.10s -%s\n\r",
	        capitalize( help_table[cnt].command ),
		help_table[cnt].desc );
	    send_to_char( buf, ch );
	}
	return FALSE;
    }

    /*
     * Find the command, show changeable data.
     * ---------------------------------------
     */
    for (cnt = 0; help_table[cnt].command[0] != '\0'; cnt++)
    {
        if (  arg[0] == help_table[cnt].command[0]
          && !str_prefix( arg, help_table[cnt].command ) )
	{
	    if ( help_table[cnt].structure == spec_table )
	    {
		show_spec_cmds( ch );
		return FALSE;
	    }
	    else
	    if ( help_table[cnt].structure == liq_table )
	    {
		show_liquids( ch );
		return FALSE;
	    }
	    else
	    if ( help_table[cnt].structure == skill_table )
	    {

		if ( spell[0] == '\0' )
		{
		    send_to_char( "Syntax:  ? spells "
		        "[ignore/attack/defend/self/object/all]\n\r", ch );
		    return FALSE;
		}

		if ( !str_prefix( spell, "all" ) )
		    show_skill_cmds( ch, -1 );
		else if ( !str_prefix( spell, "ignore" ) )
		    show_skill_cmds( ch, TAR_IGNORE );
		else if ( !str_prefix( spell, "attack" ) )
		    show_skill_cmds( ch, TAR_CHAR_OFFENSIVE );
		else if ( !str_prefix( spell, "defend" ) )
		    show_skill_cmds( ch, TAR_CHAR_DEFENSIVE );
		else if ( !str_prefix( spell, "self" ) )
		    show_skill_cmds( ch, TAR_CHAR_SELF );
		else if ( !str_prefix( spell, "object" ) )
		    show_skill_cmds( ch, TAR_OBJ_INV );
		else
		    send_to_char( "Syntax:  ? spell "
		        "[ignore/attack/defend/self/object/all]\n\r", ch );
		    
		return FALSE;
	    }
	    else
	    {
		show_flag_cmds( ch, help_table[cnt].structure );
		return FALSE;
	    }
	}
    }

    show_help( ch, "" );
    return FALSE;
}


/*****************************************************************************
 Name:		check_range( lower vnum, upper vnum )
 Purpose:	Ensures the range spans only one area.
 Called by:	aedit_vnum(olc_act.c).
 ****************************************************************************/
bool check_range( int lower, int upper )
{
    Area *pArea;
    int cnt = 0;

    for ( pArea = area_first; pArea; pArea = pArea->next )
    {
	/*
	 * lower < area < upper
	 */
        if ( ( lower <= pArea->lvnum && pArea->lvnum <= upper )
	||   ( lower <= pArea->uvnum && pArea->uvnum <= upper ) )
	    ++cnt;

	if ( cnt > 1 )
	    return FALSE;
    }
    return TRUE;
}



Area *get_vnum_area( int vnum )
{
    Area *pArea;

    for ( pArea = area_first; pArea; pArea = pArea->next )
    {
        if ( vnum >= pArea->lvnum
          && vnum <= pArea->uvnum )
            return pArea;
    }

    return 0;
}



/*
 * Area Editor Functions.
 */
AEDIT( aedit_show )
{
    Area *pArea;
    char buf  [MAX_STRING_LENGTH];

    EDIT_AREA(ch, pArea);

    sprintf( buf, "Name:     [%5d] %s\n\r", pArea->vnum, pArea->name );
    send_to_char( buf, ch );

#if 0  /* ROM OLC */
    sprintf( buf, "Recall:   [%5d] %s\n\r", pArea->recall,
	get_room_index( pArea->recall )
	? get_room_index( pArea->recall )->name : "none" );
    send_to_char( buf, ch );
#endif /* ROM */

    cprintf( ch, "File:     %s\n\r", pArea->filename );
    cprintf( ch, "Vnums:    [%d-%d]\n\r", pArea->lvnum, pArea->uvnum );
    cprintf( ch, "Age:      [%d]\n\r",	pArea->age );
    cprintf( ch, "Players:  [%d]\n\r", pArea->nplayer );
    cprintf( ch, "Security: [%d]\n\r", pArea->security );
    cprintf( ch, "Builders: [%s]\n\r", pArea->builders );
    cprintf( ch, "Flags:    [%s]\n\r", flag_string( area_flags, pArea->area_flags ) );
	cprintf( ch, "Levels:   [%d-%d]\n\r", pArea->llevel, pArea->ulevel );
	cprintf( ch, "Exp Mod:  [%+d%%]\n\r", pArea->exp_mod );
	cprintf( ch, "Show:     [%s]\n\r", pArea->hide_area ? "No" : "Yes");

    if ( pArea->echoes )
    {
    	ExtraDescr *ed;
		cprintf( ch, " == Area-Wide Random Echoes ==\n\r");
    	for ( ed = pArea->echoes; ed; ed = ed->next )
			cprintf(ch," * %s\n\r", ed->keyword );
    }

    return FALSE;
}

AEDIT( aedit_create )
{
    Area *pArea;

    pArea               =   new_area();
    area_last->next     =   pArea;
    area_last			=   pArea;	/* Thanks, Walker. */
    ch->desc->pEdit     =   (void *)pArea;

    pArea->security	= 	9;
    SET_BIT( pArea->area_flags, AREA_ADDED );
    send_to_char( "Area Created.\n\r", ch );
    return FALSE;
}



AEDIT( aedit_name )
{
    Area *pArea;

    EDIT_AREA(ch, pArea);

    if ( argument[0] == '\0' )
    {
	send_to_char( "Syntax:   name [$name]\n\r", ch );
	return FALSE;
    }

    free_string( pArea->name );
    pArea->name = str_dup( argument );

    send_to_char( "Name set.\n\r", ch );
    return TRUE;
}



AEDIT( aedit_file )
{
    Area *pArea;
    char file[MAX_STRING_LENGTH];
    char fullfile[MAX_STRING_LENGTH];
    int i, length;

    EDIT_AREA(ch, pArea);

    one_argument( argument, file );	/* Forces Lowercase */

    if ( argument[0] == '\0' )
    {
	send_to_char( "Syntax:  filename [$file]\n\r", ch );
	return FALSE;
    }

    /*
     * Simple Syntax Check.
     */
    length = strlen( argument );
    if ( length > 8 )
    {
	send_to_char( "No more than eight characters allowed.\n\r", ch );
	return FALSE;
    }
    
    /*
     * Allow only letters and numbers.
     */
    for ( i = 0; i < length; i++ )
    {
	if ( !isalnum( file[i] ) )
	{
	    send_to_char( "Only letters and numbers are valid.\n\r", ch );
	    return FALSE;
	}
    }    

    /* Changed 13/Jul/2001 for our run system */
    free_string( pArea->filename );
    strcat( file, ".are" );

    sprintf(fullfile,"%s",file);
    pArea->filename = str_dup( fullfile );

    /* Siders 13/July/01 - compliant with our OLC system */

    send_to_char( "Filename set.\n\r", ch );
    return TRUE;
}

AEDIT( aedit_ed )
{
	Area *pArea;
    ExtraDescr *ed;
    char command[MAX_INPUT_LENGTH];
    char keyword[MAX_INPUT_LENGTH];

    EDIT_AREA(ch, pArea);

    argument = one_argument( argument, command );
    one_argument( argument, keyword );

    if ( command[0] == '\0' || keyword[0] == '\0' )
    {
	send_to_char( "Syntax:  echo add [keyword]\n\r", ch );
	send_to_char( "         echo edit [keyword]\n\r", ch );
	send_to_char( "         echo delete [keyword]\n\r", ch );
	send_to_char( "         echo format [keyword]\n\r", ch );
	return FALSE;
    }

    if ( !str_cmp( command, "add" ) )
    {
	if ( keyword[0] == '\0' )
	{
	    send_to_char( "Syntax:  echo add [keyword]\n\r", ch );
	    return FALSE;
	}

	ed			=   new_extra_descr();
	ed->keyword		=   str_dup( keyword );
	ed->description		=   str_dup( "" );
	ed->next		=   pArea->echoes;
	pArea->echoes	=   ed;

	string_append( ch, &ed->description );

	return TRUE;
    }


    if ( !str_cmp( command, "edit" ) )
    {
	if ( keyword[0] == '\0' )
	{
	    send_to_char( "Syntax:  echo edit [keyword]\n\r", ch );
	    return FALSE;
	}

	for ( ed = pArea->echoes; ed; ed = ed->next )
	{
	    if ( is_name( keyword, ed->keyword ) )
		break;
	}

	if ( !ed )
	{
	    send_to_char( "AEdit:  Extra description keyword not found.\n\r", ch );
	    return FALSE;
	}

	string_append( ch, &ed->description );

	return TRUE;
    }


    if ( !str_cmp( command, "delete" ) )
    {
	ExtraDescr *ped = NULL;

	if ( keyword[0] == '\0' )
	{
	    send_to_char( "Syntax:  echo delete [keyword]\n\r", ch );
	    return FALSE;
	}

	for ( ed = pArea->echoes; ed; ed = ed->next )
	{
	    if ( is_name( keyword, ed->keyword ) )
		break;
	    ped = ed;
	}

	if ( !ed )
	{
	    send_to_char( "AEdit:  Extra description keyword not found.\n\r", ch );
	    return FALSE;
	}

	if ( !ped )
	    pArea->echoes = ed->next;
	else
	    ped->next = ed->next;

	free_extra_descr( ed );

	send_to_char( "Extra description deleted.\n\r", ch );
	return TRUE;
    }


    if ( !str_cmp( command, "format" ) )
    {
	if ( keyword[0] == '\0' )
	{
	    send_to_char( "Syntax:  echo format [keyword]\n\r", ch );
	    return FALSE;
	}

	for ( ed = pArea->echoes; ed; ed = ed->next )
	{
	    if ( is_name( keyword, ed->keyword ) )
		break;
	}

	if ( !ed )
	{
	    send_to_char( "AEdit:  Extra description keyword not found.\n\r", ch );
	    return FALSE;
	}

	ed->description = format_string( ed->description );

	send_to_char( "Extra description formatted.\n\r", ch );
	return TRUE;
    }

    redit_ed( ch, "" );
    return FALSE;
}

AEDIT( aedit_age )
{
    Area *pArea;
    char age[MAX_STRING_LENGTH];

    EDIT_AREA(ch, pArea);

    one_argument( argument, age );

    if ( !is_number( age ) || age[0] == '\0' )
    {
	send_to_char( "Syntax:  age [#age]\n\r", ch );
	return FALSE;
    }

    pArea->age = atoi( age );

    send_to_char( "Age set.\n\r", ch );
    return TRUE;
}


#if 0 /* ROM OLC */
AEDIT( aedit_recall )
{
    Area *pArea;
    char room[MAX_STRING_LENGTH];
    int  value;

    EDIT_AREA(ch, pArea);

    one_argument( argument, room );

    if ( !is_number( argument ) || argument[0] == '\0' )
    {
	send_to_char( "Syntax:  recall [#rvnum]\n\r", ch );
	return FALSE;
    }

    value = atoi( room );

    if ( !get_room_index( value ) )
    {
	send_to_char( "AEdit:  Room vnum does not exist.\n\r", ch );
	return FALSE;
    }

    pArea->recall = value;

    send_to_char( "Recall set.\n\r", ch );
    return TRUE;
}
#endif /* ROM OLC */

AEDIT( aedit_exp )
{
    Area *pArea;
    char buf[MAX_STRING_LENGTH];
    int  value;

    EDIT_AREA(ch, pArea);

    one_argument( argument, buf );

    if ( !is_number( buf ) || buf[0] == '\0' )
    {
		cprintf( ch, "Syntax:  exp [#buf]\n\r"
				     "   A value of 0 means standard experience.\n\r"
				     "   A value of 10 would give +10% experience.\n\r" );
		return FALSE;
    }

    value = atoi( buf );
    pArea->exp_mod = value;

    cprintf(ch,"Experience modifier set to %d.\n\r",pArea->exp_mod);
    return TRUE;
}

AEDIT( aedit_security )
{
    Area *pArea;
    char sec[MAX_STRING_LENGTH];
    char buf[MAX_STRING_LENGTH];
    int  value;

    EDIT_AREA(ch, pArea);

    one_argument( argument, sec );

    if ( !is_number( sec ) || sec[0] == '\0' )
    {
	send_to_char( "Syntax:  security [#level]\n\r", ch );
	return FALSE;
    }

    value = atoi( sec );

    if ( value > ch->pcdata->security || value < 0 )
    {
	if ( ch->pcdata->security != 0 )
	{
	    sprintf( buf, "Security is 0-%d.\n\r", ch->pcdata->security );
	    send_to_char( buf, ch );
	}
	else
	    send_to_char( "Security is 0 only.\n\r", ch );
	return FALSE;
    }

    pArea->security = value;

    send_to_char( "Security set.\n\r", ch );
    return TRUE;
}



AEDIT( aedit_builder )
{
    Area *pArea;
    char name[MAX_STRING_LENGTH];
    char buf[MAX_STRING_LENGTH];

    EDIT_AREA(ch, pArea);

    one_argument( argument, name );

    if ( name[0] == '\0' )
    {
	send_to_char( "Syntax:  builder [$name]  -toggles builder\n\r", ch );
	send_to_char( "Syntax:  builder All      -allows everyone\n\r", ch );
	return FALSE;
    }

    name[0] = UPPER( name[0] );

    if ( strstr( pArea->builders, name ) != '\0' )
    {
	pArea->builders = string_replace( pArea->builders, name, "\0" );
	pArea->builders = string_unpad( pArea->builders );

	if ( pArea->builders[0] == '\0' )
	{
	    free_string( pArea->builders );
	    pArea->builders = str_dup( "None" );
	}
	send_to_char( "Builder removed.\n\r", ch );
	return TRUE;
    }
    else
    {
	buf[0] = '\0';
	if ( strstr( pArea->builders, "None" ) != '\0' )
	{
	    pArea->builders = string_replace( pArea->builders, "None", "\0" );
	    pArea->builders = string_unpad( pArea->builders );
	}

	if (pArea->builders[0] != '\0' )
	{
	    strcat( buf, pArea->builders );
	    strcat( buf, " " );
	}
	strcat( buf, name );
	free_string( pArea->builders );
	pArea->builders = string_proper( str_dup( buf ) );

	send_to_char( "Builder added.\n\r", ch );
	return TRUE;
    }

    return FALSE;
}

AEDIT( aedit_levels )
{
    Area *pArea;
    char lower[MAX_STRING_LENGTH];
    char upper[MAX_STRING_LENGTH];
    int  ilower;
    int  iupper;

    EDIT_AREA(ch, pArea);

    argument = one_argument( argument, lower );
    one_argument( argument, upper );

    if ( !is_number( lower ) || lower[0] == '\0'
    || !is_number( upper ) || upper[0] == '\0' )
    {
	send_to_char( "Syntax:  level [#lower] [#upper]\n\r", ch );
	return FALSE;
    }

    if ( ( ilower = atoi( lower ) ) > ( iupper = atoi( upper ) ) )
    {
	send_to_char( "AEdit:  Upper must be larger then lower.\n\r", ch );
	return FALSE;
    }
    
    pArea->llevel = ilower;
    send_to_char( "Lower level set.\n\r", ch );

    pArea->ulevel = iupper;
    send_to_char( "Upper level set.\n\r", ch );

    return TRUE;
}

AEDIT( aedit_hideinlist )
{
    Area *pArea;
    char hide[MAX_STRING_LENGTH];

    EDIT_AREA(ch, pArea);

    argument = one_argument( argument, hide );

	if ( hide[0] != '\0')
	{
		cprintf( ch, "Syntax: hideinlist\n\r" );
		return FALSE;
	}

	if (!pArea->hide_area)
	{
		pArea->hide_area = 0;
		cprintf( ch, "This area will now be hidden in the area list.\n\r" );
	}
	else
	{
		pArea->hide_area = 1;
		cprintf( ch, "This area will now be displayed in the area list.\n\r" );
	}
    
    return TRUE;
}

AEDIT( aedit_vnum )
{
    Area *pArea;
    char lower[MAX_STRING_LENGTH];
    char upper[MAX_STRING_LENGTH];
    int  ilower;
    int  iupper;

    EDIT_AREA(ch, pArea);

    argument = one_argument( argument, lower );
    one_argument( argument, upper );

    if ( !is_number( lower ) || lower[0] == '\0'
    || !is_number( upper ) || upper[0] == '\0' )
    {
	send_to_char( "Syntax:  vnum [#lower] [#upper]\n\r", ch );
	return FALSE;
    }

    if ( ( ilower = atoi( lower ) ) > ( iupper = atoi( upper ) ) )
    {
	send_to_char( "AEdit:  Upper must be larger then lower.\n\r", ch );
	return FALSE;
    }
    
    if ( !check_range( atoi( lower ), atoi( upper ) ) )
    {
	send_to_char( "AEdit:  Range must include only this area.\n\r", ch );
	return FALSE;
    }

    if ( get_vnum_area( ilower )
    && get_vnum_area( ilower ) != pArea )
    {
	send_to_char( "AEdit:  Lower vnum already assigned.\n\r", ch );
	return FALSE;
    }

    pArea->lvnum = ilower;
    send_to_char( "Lower vnum set.\n\r", ch );

    if ( get_vnum_area( iupper )
    && get_vnum_area( iupper ) != pArea )
    {
	send_to_char( "AEdit:  Upper vnum already assigned.\n\r", ch );
	return TRUE;	/* The lower value has been set. */
    }

    pArea->uvnum = iupper;
    send_to_char( "Upper vnum set.\n\r", ch );

    return TRUE;
}



AEDIT( aedit_lvnum )
{
    Area *pArea;
    char lower[MAX_STRING_LENGTH];
    int  ilower;
    int  iupper;

    EDIT_AREA(ch, pArea);

    one_argument( argument, lower );

    if ( !is_number( lower ) || lower[0] == '\0' )
    {
	send_to_char( "Syntax:  lvnum [#lower]\n\r", ch );
	return FALSE;
    }

    if ( ( ilower = atoi( lower ) ) > ( iupper = pArea->uvnum ) )
    {
	send_to_char( "AEdit:  Value must be less than the uvnum.\n\r", ch );
	return FALSE;
    }
    
    if ( !check_range( ilower, iupper ) )
    {
	send_to_char( "AEdit:  Range must include only this area.\n\r", ch );
	return FALSE;
    }

    if ( get_vnum_area( ilower )
    && get_vnum_area( ilower ) != pArea )
    {
	send_to_char( "AEdit:  Lower vnum already assigned.\n\r", ch );
	return FALSE;
    }

    pArea->lvnum = ilower;
    send_to_char( "Lower vnum set.\n\r", ch );
    return TRUE;
}



AEDIT( aedit_uvnum )
{
    Area *pArea;
    char upper[MAX_STRING_LENGTH];
    int  ilower;
    int  iupper;

    EDIT_AREA(ch, pArea);

    one_argument( argument, upper );

    if ( !is_number( upper ) || upper[0] == '\0' )
    {
	send_to_char( "Syntax:  uvnum [#upper]\n\r", ch );
	return FALSE;
    }

    if ( ( ilower = pArea->lvnum ) > ( iupper = atoi( upper ) ) )
    {
	send_to_char( "AEdit:  Upper must be larger then lower.\n\r", ch );
	return FALSE;
    }
    
    if ( !check_range( ilower, iupper ) )
    {
	send_to_char( "AEdit:  Range must include only this area.\n\r", ch );
	return FALSE;
    }

    if ( get_vnum_area( iupper )
    && get_vnum_area( iupper ) != pArea )
    {
	send_to_char( "AEdit:  Upper vnum already assigned.\n\r", ch );
	return FALSE;
    }

    pArea->uvnum = iupper;
    send_to_char( "Upper vnum set.\n\r", ch );

    return TRUE;
}

void do_fedit( Character *ch, char *argument )
{
	Faction *f;
	char	arg[MAX_STRING_LENGTH];
	extern Faction *classDefaultLists[MAX_CLASS];
	extern Faction *raceDefaultLists[MAX_PC_RACE];
	extern Faction *deityDefaultLists[MAX_DEITY];

	argument = one_argument( argument, arg );

	if ( arg[0] == '\0' )
	{
		cprintf(ch,"Usage:  fedit <default|list|delete|add> faction_name\n\r"
                   "        fedit rename old_name new_name\n\r"
				   "        fedit save  <== You must SAVE changes before rebooting!\n\r");
		return;
	}

#if defined(__OLC)
	if ( !str_cmp(arg,"save") )
	{	
		save_factions( );
		cprintf(ch,"Faction file saved.\n\r");
		return;
	}
#endif

	if ( !str_cmp(arg,"default") )
	{
		int i;
		
		cprintf(ch," == Class Default Factions ==\n\r");
		for( i = 0 ; i < MAX_CLASS ; i++ )
		{
			cprintf(ch,"[%s] ",class_table[i].name);
			for( f = classDefaultLists[i] ; f != NULL ; f = f->next )
				cprintf(ch,"<%s> ", f->name);
			cprintf(ch,"\n\r");
		}       
		        
		cprintf(ch,"\n\r == Race Default Factions ==\n\r");
		for( i = 0 ; i < MAX_PC_RACE ; i++ )
		{       
			cprintf(ch,"[%s] ",race_table[i].name);
			for( f = raceDefaultLists[i] ; f != NULL ; f = f->next )
				cprintf(ch,"<%s> ", f->name);
			cprintf(ch,"\n\r");
		}       
		        
		cprintf(ch,"\n\r == Deity Default Factions ==\n\r");
		for( i = 0 ; i < MAX_DEITY ; i++ )
		{       
			cprintf(ch,"[%s] ",deity_table[i].name);
			for( f = deityDefaultLists[i] ; f != NULL ; f = f->next )
				cprintf(ch,"<%s> ",f->name);
			cprintf(ch,"\n\r");
		}       
		        
		return; 
	}           

	if ( !str_cmp(arg,"list") || !str_cmp(arg,"show") )
	{
		cprintf(ch," === Global Faction List ===\n\r");
		for( f = factionList; f != NULL; f = f->next )
			cprintf(ch," * %-18s\n\r", f->name );
		return;
	}

#if defined(__OLC)
	if ( !str_cmp(arg,"remove") || !str_cmp(arg,"delete"))
	{
		Faction *f, *fi;

		if ( (f = factionLookup(argument)) == NULL )
		{
			cprintf(ch,"No such faction to remove\n\r");
			return;
		}

		if ( factionList == f )
		{
			factionList = f->next;
			f->next = NULL;
			goto success;
		}
		else
		for( fi = factionList; fi != NULL ; fi = fi->next )
		{
			if ( fi->next == f )
			{
				fi->next = f->next;
				f->next = NULL;
				goto success;
			}
		}

		cprintf(ch,"Unable to find faction %s in global list.\n\r");
		return;
success:
		cprintf(ch,"Faction [%s] removed.\n\r", f->name);
		return;
	}

	if ( !str_cmp(arg,"create") || !str_cmp(arg,"add") || !str_cmp(arg,"new") )
	{
		Faction *f, *fi;

		if ( (f = factionLookup(argument)) != NULL )
		{
			cprintf(ch,"Such a faction already exists.\n\r");
			return;
		}

		f = new_faction();
		f->name = str_dup(argument);
		f->factionID = ++topFactionID * -1;
		/* We want to insert in order */
		if ( factionList == NULL || strcasecmp(f->name,factionList->name) < 0 )
		{
			f->next = factionList;
			factionList = f;	
		}
		else
		{
			for( fi = factionList; fi != NULL ; fi = fi->next )
			{
				if ( fi->next == NULL )
				{
					fi->next = f;
					f->next = NULL;
					break;
				}
				else
				if ( strcasecmp(f->name,fi->next->name) < 0 )
				{
					f->next = fi->next;
					fi->next = f;
					break;
				}
			}
		}
			
		cprintf(ch,"Faction [%s] added to global list.\n\r", f->name);
		return;
	}

	if ( !str_cmp(arg,"rename") )
	{
		Faction *f;
		char	oldname[MAX_INPUT_LENGTH];

		argument = one_argument( argument, oldname );
		if ( (f = factionLookup(oldname)) == NULL )
		{
			cprintf(ch,"No such faction in global list.\n\r");
			return;
		}

		free_string(f->name);
		f->name = str_dup( argument );
		cprintf(ch,"Faction group [%s] renamed to [%s].\n\r", oldname, argument );
		return;
	}
#endif

	do_fedit(ch,"");
	return;
}


// Wilderness vnums must be over 50,000
int assign_vnums_to_map( int vnum )
{
    int i,j;
    int vnum_save = vnum;

    for( i=0 ; i< MAPSIZE ; i++ )
        for( j=0 ; j< MAPSIZE ; j++ )
            if ( map[i][j].exists && get_room_index(vnum++) != NULL )
                return FALSE;

	vnum = vnum_save;
    for( i=0 ; i< MAPSIZE ; i++ )
        for( j=0 ; j< MAPSIZE ; j++ )
            if ( map[i][j].exists )
                map[i][j].vnum = vnum++;

    return vnum;
}

// Field and forest have randoms - 10 to pick from
const char *randomDescription( int sector )
{
	int n;

	n = dice(1,10)-1;

	if ( sector == SECT_FOREST )
		return randomDescriptions[0][n];
	else
	if ( sector == SECT_FIELD )
		return randomDescriptions[1][n];
	else
		return "Generic room description";
}

AEDIT( aedit_generate )
{
	int i,j,k;
	Area *pArea;
	Room *room;
    int lvnum, uvnum, sector, vnum;
    char arg1[MAX_INPUT_LENGTH];
    char arg2[MAX_INPUT_LENGTH];

	EDIT_AREA(ch,pArea);

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );

    if ( arg1[0] == '\0' || arg2[0] == '\0' || argument[0] == '\0' )
    {
        cprintf(ch,"generate <starting_vnum> <sector> '<room title>'\n\r");
        return FALSE;
    }

    if ( (sector = flag_value( sector_flags, arg2 )) == NO_FLAG )
    {
        cprintf(ch,"You didn't provide a valid sector.\n\r");
        return FALSE;
    }

    lvnum = atoi(arg1);
    if ( lvnum < 50000 )
    {
        cprintf(ch,"Generated wilderness areas must have a vnum range over 50,000.\n\r");
        return FALSE;
    }

    if ( (sector = flag_value( sector_flags, arg2 )) == NO_FLAG )
    {
        cprintf(ch,"You didn't provide a valid sector (must use plains or forest).\n\r");
        return FALSE;
    }

	if ( sector != SECT_FIELD && sector != SECT_FOREST )
    {
        cprintf(ch,"You didn't provide a valid sector (must use plains or forest).\n\r");
        return FALSE;
    }

    uvnum = assign_vnums_to_map( lvnum );
    if ( uvnum <= 0 )
    {
        cprintf(ch,"There are not enough vnums available in that range for the area.\n\r");
        return FALSE;
    }

	if ( uvnum == lvnum )
	{
		cprintf(ch,"The map has no rooms!\n\r");
		return FALSE;
	}

	SET_BIT(pArea->area_flags,AREA_GENERATED);
	pArea->lvnum=lvnum;
	pArea->uvnum=UMAX(pArea->uvnum,uvnum);

	// Start making rooms
	for( i=0 ; i< MAPSIZE;i++)
		for(j=0;j<MAPSIZE;j++)
			if ( map[j][i].exists )
			{
				char tmp[10];
		
				snprintf(tmp,sizeof(tmp),"%d",map[j][i].vnum);
				redit_create(ch,tmp);
				if ( (room=get_room_index(map[j][i].vnum)) == NULL )
					cprintf(ch,"Error creating ro m #%d.\n\r", map[j][i].vnum );
				else
				{
					room->sector_type = sector;
					room->room_flags |= ROOM_ZONED;
					room->name = str_dup( argument );
					room->description = str_dup( randomDescription( sector ) );
				}
			}

	// And now hook up rooms
	for( i=0 ; i< MAPSIZE;i++)
        for(j=0;j<MAPSIZE;j++)
            if ( (room = get_room_index(map[j][i].vnum)) != NULL )
			{
				// add any doors we need
				for( k=0; k<4; k++)
				{
					if ( !map[j][i].links[k] )
						continue;

					switch(k){
					case DIR_NORTH:
						if ( i>0 ) {vnum = map[j][i-1].vnum;break;}
						else continue;
					case DIR_EAST:
						if ( j<MAPSIZE-1 ) {vnum = map[j+1][i].vnum;break;}
						else continue;
					case DIR_SOUTH:
						if ( i<MAPSIZE-1) {vnum = map[j][i+1].vnum;break;}
						else continue;
					case DIR_WEST:
						if ( j>0 ) {vnum = map[j-1][i].vnum;break;}
						else continue;
					default:
						cprintf(ch,"Error!  Bad direction.\n\r");
						continue;
					}

					if ( get_room_index(vnum) == NULL )
					{
						cprintf(ch,"** No room with vnum %d\n\r", vnum );
						continue;
					}

					// have room vnum, now add one-way link
					if ( room->exit[k] == NULL )
						room->exit[k] = new_exit();

					room->exit[k]->u1.to_room = get_room_index(vnum);
					room->exit[k]->orig_door = k;
				}
			}

	cprintf(ch,"Rooms created.\n\r");
	return TRUE;
}


AEDIT( aedit_flags )
{
    Area *pArea;
    int value;

    if ( argument[0] != '\0' )
    {
    EDIT_AREA(ch, pArea);

    if ( ( value = flag_value( area_flags, argument ) ) != NO_FLAG )
    {
        TOGGLE_BIT(pArea->area_flags, value);

        send_to_char( "Area flag toggled.\n\r", ch);
        return TRUE;
    }
    }

    send_to_char( "Syntax:  flag [flag]\n\r"
          "Type '? area' for a list of flags.\n\r", ch );
    return FALSE;
}

