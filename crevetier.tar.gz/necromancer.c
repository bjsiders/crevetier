/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/** System Include Files **/
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/** Custom Header Files **/
#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "tables.h"
#include "recycle.h"

/** Relevent GSN's **/
sh_int gsn_life_tap;
sh_int gsn_life_touch;
sh_int gsn_life_hit;
sh_int gsn_life_spike;
sh_int gsn_life_take;
sh_int gsn_life_steal;
sh_int gsn_life_siphon;
sh_int gsn_life_drain;
sh_int gsn_life_exhaust;

/** The library of Sorcerer spells, arranged alphabetically */

bool spell_empty( int sn, int level, Character *ch, void *vo, int target)
{
	Character *victim = (Character *) vo;
	Affect af;

	if ( victim == ch )
	{
		cprintf(ch,"You cannot cast this spell on yourself.\n\r");
		return FALSE;
	}

	/* Steal 15 AC points from victim */
	if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_WILLPOWER) )
	{
		act("$n shudders briefly.",victim,NULL,NULL,TO_ROOM);
		act("You shudder briefly.",victim,NULL,NULL,TO_CHAR);
		return TRUE;
	}

	/* failed, apply affect */
	af.where			= TO_AFFECTS;
	af.type				= sn;
	af.level			= level;
	af.duration			= minutes(15);
	af.location			= APPLY_AC;
	af.modifier			= -15;
	af.bitvector		= 0;
	af.flags			= AFF_SPELL;
	spellAffectToChar( victim, &af );
 
	af.modifier 		= 15;
	spellAffectToChar( ch, &af );

	act("You shudder as your life force bolsters $n.",ch,NULL,victim,TO_VICT);
	act("$N shudders as $S life force bolsters you.",ch,NULL,victim,TO_CHAR);
	act("$N shudders as $S life force bolsters $n.",ch,NULL,victim,TO_NOTVICT);
	return TRUE;
}

bool spell_vacant( int sn, int level, Character *ch, void *vo, int target)
{
    Character *victim = (Character *) vo; 
    Affect af;
 
    if ( victim == ch )
    {
        cprintf(ch,"You cannot cast this spell on yourself.\n\r");
        return FALSE; 
    }

    /* Steal 25 AC points from victim */
    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_WILLPOWER) )
    {
        act("$n shudders briefly.",victim,NULL,NULL,TO_ROOM);
        act("You shudder briefly.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    /* failed, apply affect */
    af.where            = TO_AFFECTS;
    af.type             = sn;
    af.level            = level;
    af.duration         = minutes(20);
    af.location         = APPLY_AC; 
    af.modifier         = -25;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar( victim, &af );

    af.modifier         = 25;
    spellAffectToChar( ch, &af );

    act("You shudder as your life force bolsters $n.",ch,NULL,victim,TO_VICT);
    act("$N shudders as $S life force bolsters you.",ch,NULL,victim,TO_CHAR);
    act("$N shudders as $S life force bolsters $n.",ch,NULL,victim,TO_NOTVICT);
    return TRUE;
}

bool spell_absence( int sn, int level, Character *ch, void *vo, int target)
{
    Character *victim = (Character *) vo; 
    Affect af;
 
    if ( victim == ch )
    {
        cprintf(ch,"You cannot cast this spell on yourself.\n\r");
        return FALSE; 
    }

    /* Steal 40 AC points from victim */
    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_WILLPOWER) )
    {
        act("$n shudders briefly.",victim,NULL,NULL,TO_ROOM);
        act("You shudder briefly.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    /* failed, apply affect */
    af.where            = TO_AFFECTS;
    af.type             = sn;
    af.level            = level;
    af.duration         = minutes(25);
    af.location         = APPLY_AC; 
    af.modifier         = -40;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar( victim, &af );

    af.modifier         = 40;
    spellAffectToChar( ch, &af );

    act("You shudder as your life force bolsters $n.",ch,NULL,victim,TO_VICT);
    act("$N shudders as $S life force bolsters you.",ch,NULL,victim,TO_CHAR);
    act("$N shudders as $S life force bolsters $n.",ch,NULL,victim,TO_NOTVICT);
    return TRUE;
}

bool spell_barren( int sn, int level, Character *ch, void *vo, int target)
{
    Character *victim = (Character *) vo; 
    Affect af;
 
    if ( victim == ch )
    {
        cprintf(ch,"You cannot cast this spell on yourself.\n\r");
        return FALSE; 
    }

    /* Steal 60 AC points from victim */
    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_WILLPOWER) )
    {
        act("$n shudders briefly.",victim,NULL,NULL,TO_ROOM);
        act("You shudder briefly.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    /* failed, apply affect */
    af.where            = TO_AFFECTS;
    af.type             = sn;
    af.level            = level;
    af.duration         = minutes(30);
    af.location         = APPLY_AC; 
    af.modifier         = -60;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar( victim, &af );

    af.modifier         = 60;
    spellAffectToChar( ch, &af );

    act("You shudder as your life force bolsters $n.",ch,NULL,victim,TO_VICT);
    act("$N shudders as $S life force bolsters you.",ch,NULL,victim,TO_CHAR);
    act("$N shudders as $S life force bolsters $n.",ch,NULL,victim,TO_NOTVICT);
    return TRUE;
}

bool spell_vacuum( int sn, int level, Character *ch, void *vo, int target)
{
    Character *victim = (Character *) vo; 
    Affect af;
 
    if ( victim == ch )
    {
        cprintf(ch,"You cannot cast this spell on yourself.\n\r");
        return FALSE; 
    }

    /* Steal 90 AC points from victim */
    if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_WILLPOWER) )
    {
        act("$n shudders briefly.",victim,NULL,NULL,TO_ROOM);
        act("You shudder briefly.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    /* failed, apply affect */
    af.where            = TO_AFFECTS;
    af.type             = sn;
    af.level            = level;
    af.duration         = minutes(35);
    af.location         = APPLY_AC; 
    af.modifier         = -90;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar( victim, &af );

    af.modifier         = 90;
    spellAffectToChar( ch, &af );

    act("You shudder as your life force bolsters $n.",ch,NULL,victim,TO_VICT);
    act("$N shudders as $S life force bolsters you.",ch,NULL,victim,TO_CHAR);
    act("$N shudders as $S life force bolsters $n.",ch,NULL,victim,TO_NOTVICT);
    return TRUE;
}

bool spell_release_life( int sn, int level, Character *ch, void *vo, int target)
{
	Character *victim = (Character *) vo;
	Affect af;

	if ( victim == ch )
	{
		cprintf(ch,"You cannot cast this spell on yourself.\n\r");
		return FALSE;
	}

	/* Lop offf 40% of caster's hp and give to victim */
   	af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(52);
    af.location     = APPLY_HIT;
    af.modifier     = max_stat_hit( ch ) * 2 / 10;
    af.flags        = AFF_SPELL;
	af.bitvector	= 0;
    spellAffectToChar( victim, &af );

	/* Yank hp from caster */
	af.modifier	*= -1;
	spellAffectToChar( ch, &af );

	ch->stat_hit = UMIN( max_stat_hit( ch ), ch->stat_hit );
	act("You transfer part of your life force to $N.",ch,NULL,victim,TO_CHAR);
	act("$n transfers part of $s life force to you.",ch,NULL,victim,TO_VICT);
	act("$n transfer part of $s life force to $N.",ch,NULL,victim,TO_NOTVICT);
	return TRUE;
}

bool spell_forfeit_life( int sn, int level, Character *ch, void *vo, int target)
{
	Character *victim = (Character *) vo;
	Affect af;

	if ( victim == ch )
	{
		cprintf(ch,"You cannot cast this spell on yourself.\n\r");
		return FALSE;
	}

	/* Lop offf 40% of caster's hp and give to victim */
   	af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(52);
    af.location     = APPLY_HIT;
    af.modifier     = max_stat_hit( ch ) * 6 / 10;
    af.flags        = AFF_SPELL;
	af.bitvector	= 0;
    spellAffectToChar( victim, &af );

	/* Yank hp from caster */
	af.modifier	*= -1;
	spellAffectToChar( ch, &af );

	ch->stat_hit = UMIN( max_stat_hit( ch ), ch->stat_hit );
	act("You transfer part of your life force to $N.",ch,NULL,victim,TO_CHAR);
	act("$n transfers part of $s life force to you.",ch,NULL,victim,TO_VICT);
	act("$n transfer part of $s life force to $N.",ch,NULL,victim,TO_NOTVICT);
	return TRUE;
}

bool spell_sacrifice_life( int sn, int level, Character *ch, void *vo, int target)
{
	Character *victim = (Character *) vo;
	Affect af;

	if ( victim == ch )
	{
		cprintf(ch,"You cannot cast this spell on yourself.\n\r");
		return FALSE;
	}

	/* Lop offf 40% of caster's hp and give to victim */
   	af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(52);
    af.location     = APPLY_HIT;
    af.modifier     = max_stat_hit( ch ) * 8 / 10;
    af.flags        = AFF_SPELL;
	af.bitvector	= 0;
    spellAffectToChar( victim, &af );

	/* Yank hp from caster */
	af.modifier	*= -1;
	spellAffectToChar( ch, &af );

	ch->stat_hit = UMIN( max_stat_hit( ch ), ch->stat_hit );
	act("You transfer part of your life force to $N.",ch,NULL,victim,TO_CHAR);
	act("$n transfers part of $s life force to you.",ch,NULL,victim,TO_VICT);
	act("$n transfer part of $s life force to $N.",ch,NULL,victim,TO_NOTVICT);
	return TRUE;
}

bool spell_abandon_life( int sn, int level, Character *ch, void *vo, int target)
{
	Character *victim = (Character *) vo;
	Affect af;

	if ( victim == ch )
	{
		cprintf(ch,"You cannot cast this spell on yourself.\n\r");
		return FALSE;
	}

	/* Lop offf 40% of caster's hp and give to victim */
   	af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(52);
    af.location     = APPLY_HIT;
    af.modifier     = max_stat_hit( ch ) * 4 / 10;
    af.flags        = AFF_SPELL;
	af.bitvector	= 0;
    spellAffectToChar( victim, &af );

	/* Yank hp from caster */
	af.modifier	*= -1;
	spellAffectToChar( ch, &af );

	ch->stat_hit = UMIN( max_stat_hit( ch ), ch->stat_hit );
	act("You transfer part of your life force to $N.",ch,NULL,victim,TO_CHAR);
	act("$n transfers part of $s life force to you.",ch,NULL,victim,TO_VICT);
	act("$n transfer part of $s life force to $N.",ch,NULL,victim,TO_NOTVICT);
	return TRUE;
}

bool spell_banish_undead( int sn, int level, Character *ch, void *vo, int target)
{
	Character *victim = (Character *) vo;
	int dam;

	if ( !IS_SET(victim->form,FORM_UNDEAD) )
	{
		cprintf(ch,"This spell can only damage undead creatures.\n\r");
		return FALSE;
	}

	dam = calcSpellDamage(ch,sn,lowDam(147),highDam(179));
 
    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
	return TRUE;
}

bool spell_rebuke_undead( int sn, int level, Character *ch, void *vo, int target)
{
    Character *victim = (Character *) vo;
    int dam;

    if ( !IS_SET(victim->form,FORM_UNDEAD) )
    {
        cprintf(ch,"This spell can only damage undead creatures.\n\r");
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,lowDam(22),highDam(26));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_repulse_undead( int sn, int level, Character *ch, void *vo, int target)
{
    Character *victim = (Character *) vo;
    int dam;

    if ( !IS_SET(victim->form,FORM_UNDEAD) )
    {
        cprintf(ch,"This spell can only damage undead creatures.\n\r");
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,lowDam(35),highDam(43));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_strike_undead( int sn, int level, Character *ch, void *vo, int target)
{
    Character *victim = (Character *) vo;
    int dam;

    if ( !IS_SET(victim->form,FORM_UNDEAD) )
    {
        cprintf(ch,"This spell can only damage undead creatures.\n\r");
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,lowDam(55),highDam(68));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_maim_undead( int sn, int level, Character *ch, void *vo, int target)
{
    Character *victim = (Character *) vo;
    int dam;

    if ( !IS_SET(victim->form,FORM_UNDEAD) )
    {
        cprintf(ch,"This spell can only damage undead creatures.\n\r");
        return FALSE;
    }

    dam = calcSpellDamage(ch,sn,lowDam(93),highDam(114));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_blight( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
	Affect af;
    
	if ( check_saves_spell(ch, victim, DAM_DISEASE, SAVE_FORTITUDE) )
	{
		act("The Blight fails to take hold.",victim,NULL,NULL,TO_ROOM);
		act("The Blight fails to take hold.",victim,NULL,NULL,TO_CHAR);
		return TRUE;
	}
	else
	{
		af.where		= DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
		af.bitvector	= DAM_DISEASE;
		af.type			= sn;
		af.level		= level;
		af.duration		= seconds(60);
		af.location		= 12;
		af.modifier		= 22;
		af.flags		= AFF_SPELL;
		spellAffectToChar( victim, &af );

        af.bitvector    = AFF_DISEASE;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

		act("You are stricken with the Blight!",victim,NULL,NULL,TO_CHAR);
		act("$n is stricken with the Blight.",victim,NULL,NULL,TO_ROOM);
	}

    damage( ch, victim, 0, sn, DAM_DISEASE , DF_SPELL );
    return TRUE;
}

bool spell_taint( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
	Affect af;
    
	if ( check_saves_spell(ch, victim, DAM_DISEASE, SAVE_FORTITUDE) )
	{
		act("$n briefly appears sick, but quickly recovers.",victim,NULL,NULL,TO_ROOM);
		act("You briefly feel sick, but quickly recover.",victim,NULL,NULL,TO_CHAR);
		return TRUE;
	}
	else
	{
		af.where		= DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
		af.bitvector	= DAM_DISEASE;
		af.type			= sn;
		af.level		= level;
		af.duration		= seconds(60);
		af.location		= 2;
		af.modifier		= 3;
		af.flags		= AFF_SPELL;
		spellAffectToChar( victim, &af );

        af.bitvector    = AFF_DISEASE;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

		act("A disgusting rot begins to crawl over your flesh.",victim,NULL,NULL,TO_CHAR);
		act("A disgusting rot begins to crawl over $n's flesh.",victim,NULL,NULL,TO_ROOM);
	}

    damage( ch, victim, 0, sn, DAM_DISEASE , DF_SPELL );
    return TRUE;
}

bool spell_infection( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;
   
    if ( check_saves_spell(ch, victim, DAM_DISEASE, SAVE_FORTITUDE) )
    {
        act("$n briefly appears sick, but quickly recovers.",victim,NULL,NULL,TO_ROOM);
		act("You briefly feel sick, but quickly recover.",victim,NULL,NULL,TO_CHAR);

        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_DISEASE;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = 3;
        af.modifier     = 6;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_DISEASE;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("A disgusting rot begins to crawl over your flesh.",victim,NULL,NULL,TO_CHAR);
        act("A disgusting rot begins to crawl over $n's flesh.",victim,NULL,NULL,TO_ROOM);
    }

    damage( ch, victim, 0, sn, DAM_DISEASE , DF_SPELL );
    return TRUE;
}

bool spell_infestation( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;
   
    if ( check_saves_spell(ch, victim, DAM_DISEASE, SAVE_FORTITUDE) )
    {
        act("$n briefly appears sick, but quickly recovers.",victim,NULL,NULL,TO_ROOM);
        act("You briefly feel sick, but quickly recover.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_DISEASE;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = 6;
        af.modifier     = 12;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_DISEASE;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("A disgusting rot begins to crawl over your flesh.",victim,NULL,NULL,TO_CHAR);
        act("A disgusting rot begins to crawl over $n's flesh.",victim,NULL,NULL,TO_ROOM);
    }

    damage( ch, victim, 0, sn, DAM_DISEASE , DF_SPELL );
    return TRUE;
}

bool spell_pox( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;
   
    if ( check_saves_spell(ch, victim, DAM_DISEASE, SAVE_FORTITUDE) )
    {
        act("$n briefly appears sick, but quickly recovers.",victim,NULL,NULL,TO_ROOM);
        act("You briefly feel sick, but quickly recover.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_DISEASE;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = 22;
        af.modifier     = 45;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_DISEASE;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("A disgusting rot begins to crawl over your flesh.",victim,NULL,NULL,TO_CHAR);
        act("A disgusting rot begins to crawl over $n's flesh.",victim,NULL,NULL,TO_ROOM);
    }

    damage( ch, victim, 0, sn, DAM_DISEASE , DF_SPELL );
    return TRUE;
}

bool spell_disease( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;
   
    if ( check_saves_spell(ch, victim, DAM_DISEASE, SAVE_FORTITUDE) )
    {
        act("$n briefly appears sick, but quickly recovers.",victim,NULL,NULL,TO_ROOM);
        act("You briefly feel sick, but quickly recover.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_DISEASE;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = 45;
        af.modifier     = 75;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_DISEASE;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("A disgusting rot begins to crawl over your flesh.",victim,NULL,NULL,TO_CHAR);
        act("A disgusting rot begins to crawl over $n's flesh.",victim,NULL,NULL,TO_ROOM);
    }

    damage( ch, victim, 0, sn, DAM_DISEASE , DF_SPELL );
    return TRUE;
}

bool spell_epidemic( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;
   
    if ( check_saves_spell(ch, victim, DAM_DISEASE, SAVE_FORTITUDE) )
    {
        act("$n briefly appears sick, but quickly recovers.",victim,NULL,NULL,TO_ROOM);
        act("You briefly feel sick, but quickly recover.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_DISEASE;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = 75;
        af.modifier     = 112;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        af.bitvector    = AFF_DISEASE;
        af.where        = TO_AFFECTS;
        af.location     = 0;
        af.modifier     = 0;
        spellAffectToChar( victim, &af );

        act("A disgusting rot begins to crawl over your flesh.",victim,NULL,NULL,TO_CHAR);
        act("A disgusting rot begins to crawl over $n's flesh.",victim,NULL,NULL,TO_ROOM);
    }

    damage( ch, victim, 0, sn, DAM_DISEASE , DF_SPELL );
    return TRUE;
}

bool spell_life_tap( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(1),highDam(6));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;  
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );

	/* Player gets 40% of it */
	cprintf(ch,"You absorb %d hit points!\n\r",dam*40/100);
    apply_healing( ch, dam * 40 / 100 );
    return TRUE;
}

bool spell_life_touch( int sn, int level, Character *ch, void *vo, int target )
{   
    Character *victim = (Character *) vo;
    int   dam;
 
    dam = calcSpellDamage(ch,sn,lowDam(6),highDam(10));   

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );

	/* Player gets 44% of it */
	cprintf(ch,"You absorb %d hit points!\n\r",dam*44/100);
	apply_healing( ch, dam * 44 / 100 );
    return TRUE;
}

bool spell_life_hit( int sn, int level, Character *ch, void *vo, int target )
{  
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(10),highDam(17));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    
    /* Player gets 44% of it */
    cprintf(ch,"You absorb %d hit points!\n\r",dam*48/100);
    apply_healing( ch, dam * 48 / 100 );
    return TRUE;
}

bool spell_life_spike( int sn, int level, Character *ch, void *vo, int target )
{  
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(17),highDam(27));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    
    /* Player gets 44% of it */
    cprintf(ch,"You absorb %d hit points!\n\r",dam*52/100);
    apply_healing( ch, dam * 52 / 100 );
    return TRUE;
}

bool spell_life_take( int sn, int level, Character *ch, void *vo, int target )
{  
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(27),highDam(42));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    
    cprintf(ch,"You absorb %d hit points!\n\r",dam*56/100);
    apply_healing( ch, dam * 56 / 100 );
    return TRUE;
}

bool spell_life_steal( int sn, int level, Character *ch, void *vo, int target )
{  
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(42),highDam(64));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    
    cprintf(ch,"You absorb %d hit points!\n\r",dam*60/100);
    apply_healing( ch, dam * 60 / 100 );
    return TRUE;
}

bool spell_life_siphon( int sn, int level, Character *ch, void *vo, int target )
{  
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(64),highDam(92));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    
    cprintf(ch,"You absorb %d hit points!\n\r",dam*64/100);
    apply_healing( ch, dam * 64 / 100 );
    return TRUE;
}

bool spell_life_drain( int sn, int level, Character *ch, void *vo, int target )
{  
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(96),highDam(140));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    
    cprintf(ch,"You absorb %d hit points!\n\r",dam*68/100);
    apply_healing( ch, dam * 68 / 100 );
    return TRUE;
}

bool spell_life_exhaust( int sn, int level, Character *ch, void *vo, int target )
{  
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(140),highDam(182));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SPIRIT , DF_SHOW | DF_SPELL );
    
    cprintf(ch,"You absorb %d hit points!\n\r",dam*72/100);
    apply_healing( ch, dam * 72 / 100 );
    return TRUE;
}

bool spell_shroud_of_khal( int sn, int level, Character *ch, void *vo, int target )
{
	Character *victim = (Character *) vo;
	Affect af;

    af.where            = DAMAGE_SHIELD;
    af.level            = level;
    af.type             = sn;
    af.duration         = minutes(6);
    af.location         = 2;
    af.modifier         = 2;
    af.bitvector        = DAM_SPIRIT;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);
	
	act("$n is surrounded by a shroud of darkness.",ch,NULL,NULL,TO_ROOM);
	act("You are surrounded by a shroud of darkness.",ch,NULL,NULL,TO_CHAR);
	return TRUE;
}

bool spell_shroud_of_khel( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where            = DAMAGE_SHIELD;
    af.level            = level;
    af.type             = sn;
    af.duration         = minutes(6);
    af.location         = 5;
    af.modifier         = 5;
    af.bitvector        = DAM_SPIRIT;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);
    
    act("$n is surrounded by a shroud of darkness.",ch,NULL,NULL,TO_ROOM);
    act("You are surrounded by a shroud of darkness.",ch,NULL,NULL,TO_CHAR);
    return TRUE;
}   

bool spell_shroud_of_khil( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where            = DAMAGE_SHIELD;
    af.level            = level;
    af.type             = sn;
    af.duration         = minutes(6);
    af.location         = 9;
    af.modifier         = 9;
    af.bitvector        = DAM_SPIRIT;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);
    
    act("$n is surrounded by a shroud of darkness.",ch,NULL,NULL,TO_ROOM);
    act("You are surrounded by a shroud of darkness.",ch,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_shroud_of_khol( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where            = DAMAGE_SHIELD;
    af.level            = level;
    af.type             = sn;
    af.duration         = minutes(6);
    af.location         = 15;
    af.modifier         = 15;
    af.bitvector        = DAM_SPIRIT;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);
    
    act("$n is surrounded by a shroud of darkness.",ch,NULL,NULL,TO_ROOM);
    act("You are surrounded by a shroud of darkness.",ch,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_shroud_of_khul( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where            = DAMAGE_SHIELD;
    af.level            = level;
    af.type             = sn;
    af.duration         = minutes(6);
    af.location         = 24;
    af.modifier         = 24;
    af.bitvector        = DAM_SPIRIT;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);
    
    act("$n is surrounded by a shroud of darkness.",ch,NULL,NULL,TO_ROOM);
    act("You are surrounded by a shroud of darkness.",ch,NULL,NULL,TO_CHAR);
    return TRUE;
}   

bool spell_clinging_cloud( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_DARK, SAVE_WILLPOWER) )
    {
        act("An aura of darkness envelopes $n but then lifts.",victim,NULL,NULL,TO_ROOM);
		act("An aura of darkness envelopes you, but quickly lifts.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }

    af.where        = DAMAGE_OVER_TIME;
	af.caster_id	= ch->id;
    af.bitvector    = DAM_DARK;
    af.type         = sn;
    af.level        = level;
    af.duration     = seconds(30);
    af.location     = 4;
    af.modifier     = 8;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );

	af.where		= TO_AFFECTS;
	af.bitvector	= AFF_BLIND;
	af.location		= APPLY_HITROLL;
	af.modifier		= -40;
	spellAffectToChar( victim, &af );

    act("A blinding cloud of darkness surrounds you!",victim,NULL,NULL,TO_CHAR);
    act("A blinding cloud of darkness surrounds $n!",victim,NULL,NULL,TO_ROOM);

    damage( ch, victim, 0, sn, DAM_DARK , DF_SPELL );
	return TRUE;
}

bool spell_obscuring_cloud( int sn, int level, Character *ch,void *vo,int target) 
{
    Character *victim = (Character *) vo;
    Affect af;
 
    if ( check_saves_spell(ch, victim, DAM_DARK, SAVE_WILLPOWER) )   
    {
        act("An aura of darkness envelopes $n but then lifts.",victim,NULL,NULL,TO_ROOM);
        act("An aura of darkness envelopes you, but quickly lifts.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }
    
    af.where        = DAMAGE_OVER_TIME;
	af.caster_id	= ch->id;
    af.bitvector    = DAM_DARK;
    af.type         = sn; 
    af.level        = level;
    af.duration     = seconds(36);
    af.location     = 5;
    af.modifier     = 10;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
 
    af.where        = TO_AFFECTS;
    af.bitvector    = AFF_BLIND;
    af.location     = APPLY_HITROLL;
    af.modifier     = -64;
    spellAffectToChar( victim, &af );
 
    act("A blinding cloud of darkness surrounds you!",victim,NULL,NULL,TO_CHAR);
    act("A blinding cloud of darkness surrounds $n!",victim,NULL,NULL,TO_ROOM);
 
    damage( ch, victim, 0, sn, DAM_DARK , DF_SPELL );
    return TRUE;
}

bool spell_blinding_cloud( int sn, int level, Character *ch,void *vo,int target) 
{
    Character *victim = (Character *) vo;
    Affect af;
 
    if ( check_saves_spell(ch, victim, DAM_DARK, SAVE_WILLPOWER) )   
    {
        act("An aura of darkness envelopes $n but then lifts.",victim,NULL,NULL,TO_ROOM);
        act("An aura of darkness envelopes you, but quickly lifts.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }
    
    af.where        = DAMAGE_OVER_TIME;
	af.caster_id	= ch->id;
    af.bitvector    = DAM_DARK;
    af.type         = sn; 
    af.level        = level;
    af.duration     = seconds(42);
    af.location     = 6;
    af.modifier     = 12;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
 
    af.where        = TO_AFFECTS;
    af.bitvector    = AFF_BLIND;
    af.location     = APPLY_HITROLL;
    af.modifier     = -92;
    spellAffectToChar( victim, &af );
 
    act("A blinding cloud of darkness surrounds you!",victim,NULL,NULL,TO_CHAR);
    act("A blinding cloud of darkness surrounds $n!",victim,NULL,NULL,TO_ROOM);
 
    damage( ch, victim, 0, sn, DAM_DARK , DF_SPELL );
    return TRUE;
}

bool spell_clinging_darkness( int sn, int level, Character *ch,void *vo,int target) 
{
    Character *victim = (Character *) vo;
    Affect af;
 
    if ( check_saves_spell(ch, victim, DAM_DARK, SAVE_WILLPOWER) )   
    {
        act("An aura of darkness envelopes $n but then lifts.",victim,NULL,NULL,TO_ROOM);
        act("An aura of darkness envelopes you, but quickly lifts.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }
    
    af.where        = DAMAGE_OVER_TIME;
	af.caster_id	= ch->id;
    af.bitvector    = DAM_DARK;
    af.type         = sn; 
    af.level        = level;
    af.duration     = seconds(48);
    af.location     = 7;
    af.modifier     = 14;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
 
    af.where        = TO_AFFECTS;
    af.bitvector    = AFF_BLIND;
    af.location     = APPLY_HITROLL;
    af.modifier     = -124;
    spellAffectToChar( victim, &af );
 
    act("A blinding cloud of darkness surrounds you!",victim,NULL,NULL,TO_CHAR);
    act("A blinding cloud of darkness surrounds $n!",victim,NULL,NULL,TO_ROOM);
 
    damage( ch, victim, 0, sn, DAM_DARK , DF_SPELL );
    return TRUE;
}

bool spell_obscuring_darkness( int sn, int level, Character *ch,void *vo,int target) 
{
    Character *victim = (Character *) vo;
    Affect af;
 
    if ( check_saves_spell(ch, victim, DAM_DARK, SAVE_WILLPOWER) )   
    {
        act("An aura of darkness envelopes $n but then lifts.",victim,NULL,NULL,TO_ROOM);
        act("An aura of darkness envelopes you, but quickly lifts.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }
    
    af.where        = DAMAGE_OVER_TIME;
	af.caster_id	= ch->id;
    af.bitvector    = DAM_DARK;
    af.type         = sn; 
    af.level        = level;
    af.duration     = seconds(54);
    af.location     = 8;
    af.modifier     = 16;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
 
    af.where        = TO_AFFECTS;
    af.bitvector    = AFF_BLIND;
    af.location     = APPLY_HITROLL;
    af.modifier     = -160;
    spellAffectToChar( victim, &af );
 
    act("A blinding cloud of darkness surrounds you!",victim,NULL,NULL,TO_CHAR);
    act("A blinding cloud of darkness surrounds $n!",victim,NULL,NULL,TO_ROOM);
 
    damage( ch, victim, 0, sn, DAM_DARK , DF_SPELL );
    return TRUE;
}

bool spell_blinding_darkness( int sn, int level, Character *ch,void *vo,int target) 
{
    Character *victim = (Character *) vo;
    Affect af;
 
    if ( check_saves_spell(ch, victim, DAM_DARK, SAVE_WILLPOWER) )   
    {
        act("An aura of darkness envelopes $n but then lifts.",victim,NULL,NULL,TO_ROOM);
        act("An aura of darkness envelopes you, but quickly lifts.",victim,NULL,NULL,TO_CHAR);
        return TRUE;
    }
    
    af.where        = DAMAGE_OVER_TIME;
	af.caster_id	= ch->id;
    af.bitvector    = DAM_DARK;
    af.type         = sn; 
    af.level        = level;
    af.duration     = seconds(60);
    af.location     = 10;
    af.modifier     = 20;
    af.flags        = AFF_SPELL;
    spellAffectToChar( victim, &af );
 
    af.where        = TO_AFFECTS;
    af.bitvector    = AFF_BLIND;
    af.location     = APPLY_HITROLL;
    af.modifier     = -200;
    spellAffectToChar( victim, &af );
 
    act("A blinding cloud of darkness surrounds you!",victim,NULL,NULL,TO_CHAR);
    act("A blinding cloud of darkness surrounds $n!",victim,NULL,NULL,TO_ROOM);
 
    damage( ch, victim, 0, sn, DAM_DARK , DF_SPELL );
    return TRUE;
}

bool spell_boost_minion( int sn, int level, Character *ch,void *vo,int target) 
{
    Character *pet = (Character *) vo;
    Affect af;
 
    af.where        = TO_AFFECTS;
	af.caster_id	= ch->id;
    af.bitvector    = 0;
    af.type         = sn; 
    af.level        = level;
    af.duration     = -1;
    af.location     = APPLY_HIT;
    af.modifier     = max_stat_hit( pet ) / 10;
    af.flags        = AFF_SPELL;
    spellAffectToChar( pet, &af );

	act("A swirling black cloud envelops $n.",pet,NULL,NULL,TO_ROOM);
	act("A swirling black cloud envelops you.",pet,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_bolster_minion( int sn, int level, Character *ch,void *vo,int target)
{
    Character *pet = (Character *) vo;
    Affect af;


    af.where        = TO_AFFECTS;;
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = -1;
    af.location     = APPLY_HIT;
    af.modifier     = max_stat_hit( pet ) / 10;
    af.flags        = AFF_SPELL;
    spellAffectToChar( pet, &af );

	af.location		= APPLY_AC;
	af.modifier		= 20;
	spellAffectToChar( pet, &af );

    act("A swirling black cloud envelops $n.",pet,NULL,NULL,TO_ROOM);
    act("A swirling black cloud envelops you.",pet,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_improve_minion( int sn, int level, Character *ch,void *vo,int target)
{
    Character *pet = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = -1;
    af.location     = APPLY_HIT;
    af.modifier     = max_stat_hit( pet ) / 10;
    af.flags        = AFF_SPELL;
    spellAffectToChar( pet, &af );

    af.location     = APPLY_AC;
    af.modifier     = 20;
    spellAffectToChar( pet, &af );

	af.location		= APPLY_SPEED;
	af.modifier		= 88;
	spellAffectToChar( pet, &af );

    act("A swirling black cloud envelops $n.",pet,NULL,NULL,TO_ROOM);
    act("A swirling black cloud envelops you.",pet,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_enhance_minion( int sn, int level, Character *ch,void *vo,int target)
{
    Character *pet = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = -1;
    af.location     = APPLY_HIT;
    af.modifier     = max_stat_hit( pet ) * 15 / 100;
    af.flags        = AFF_SPELL;
    spellAffectToChar( pet, &af );

    af.location     = APPLY_AC;
    af.modifier     = 40;
    spellAffectToChar( pet, &af );

    af.location     = APPLY_SPEED;
    af.modifier     = 82;
    spellAffectToChar( pet, &af );

    act("A swirling black cloud envelops $n.",pet,NULL,NULL,TO_ROOM);
    act("A swirling black cloud envelops you.",pet,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_augment_minion( int sn, int level, Character *ch,void *vo,int target)
{
    Character *pet = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = -1;
    af.location     = APPLY_HIT;
    af.modifier     = max_stat_hit( pet ) * 20 / 100;
    af.flags        = AFF_SPELL;
    spellAffectToChar( pet, &af );

    af.location     = APPLY_AC;
    af.modifier     = 80;
    spellAffectToChar( pet, &af );

    af.location     = APPLY_SPEED;
    af.modifier     = 76;
    spellAffectToChar( pet, &af );

    act("A swirling black cloud envelops $n.",pet,NULL,NULL,TO_ROOM);
    act("A swirling black cloud envelops you.",pet,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_minor_conversion( int sn, int level, Character *ch, void *vo, int target )
{       
    Character *victim = (Character *) vo;
    Affect af;
    
    af.where            = TO_AFFECTS;
    af.level            = level;
    af.type             = sn;
    af.duration         = seconds(150);
    af.location         = APPLY_CONVERT_HP_TO_MANA;
    af.modifier         = 4;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

    act("Your mana pool begins to siphon your life force.",ch,NULL,NULL,TO_CHAR);
	act("Groaning with pain, $n doubles over.",ch,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_major_conversion( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;
   
    af.where            = TO_AFFECTS;
    af.level            = level;
    af.type             = sn;
    af.duration         = seconds(150);
    af.location         = APPLY_CONVERT_HP_TO_MANA;
    af.modifier         = 8;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

    act("Your mana pool begins to siphon your life force.",ch,NULL,NULL,TO_CHAR);
    act("Groaning with pain, $n doubles over.",ch,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_greater_conversion( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;
   
    af.where            = TO_AFFECTS;
    af.level            = level;
    af.type             = sn;
    af.duration         = seconds(150);
    af.location         = APPLY_CONVERT_HP_TO_MANA;
    af.modifier         = 16;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

    act("Your mana pool begins to siphon your life force.",ch,NULL,NULL,TO_CHAR);
    act("Groaning with pain, $n doubles over.",ch,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_superior_conversion( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;
   
    af.where            = TO_AFFECTS;
    af.level            = level;
    af.type             = sn;
    af.duration         = seconds(150);
    af.location         = APPLY_CONVERT_HP_TO_MANA;
    af.modifier         = 32;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

    act("Your mana pool begins to siphon your life force.",ch,NULL,NULL,TO_CHAR);
    act("Groaning with pain, $n doubles over.",ch,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_patch( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet = (Character *) vo;

	apply_healing( pet, number_range(4,12) );
	act("$N is mended.",ch,NULL,pet,TO_CHAR);
	act("You are mended.",ch,NULL,pet,TO_VICT);
	return FALSE;
}

bool spell_mend( int sn, int level, Character *ch, void *vo, int target )
{
    Character *pet = (Character *) vo;

    apply_healing( pet, number_range(10,30) );
    act("$N is mended.",ch,NULL,pet,TO_CHAR);
    act("You are mended.",ch,NULL,pet,TO_VICT);
    return FALSE;
}

bool spell_fix( int sn, int level, Character *ch, void *vo, int target )
{
    Character *pet = (Character *) vo;

    apply_healing( pet, number_range(25,75) );
    act("$N is mended.",ch,NULL,pet,TO_CHAR);
    act("You are mended.",ch,NULL,pet,TO_VICT);
    return FALSE;
}

bool spell_repair( int sn, int level, Character *ch, void *vo, int target )
{
    Character *pet = (Character *) vo;

    apply_healing( pet, number_range(62,186) );
    act("$N is mended.",ch,NULL,pet,TO_CHAR);
    act("You are mended.",ch,NULL,pet,TO_VICT);
    return FALSE;
}

bool spell_restore( int sn, int level, Character *ch, void *vo, int target )
{
    Character *pet = (Character *) vo;

    apply_healing( pet, number_range(150,450) );
    act("$N is mended.",ch,NULL,pet,TO_CHAR);
    act("You are mended.",ch,NULL,pet,TO_VICT);
    return FALSE;
}

bool spell_replenish( int sn, int level, Character *ch, void *vo, int target )
{
    Character *pet = (Character *) vo;

    apply_healing( pet, number_range(325,750) );
    act("$N is mended.",ch,NULL,pet,TO_CHAR);
    act("You are mended.",ch,NULL,pet,TO_VICT);
    return FALSE;
}

bool spell_shield_of_salika( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where            = TO_AFFECTS;
    af.level            = level;
    af.type             = sn;
    af.duration         = minutes(40);
    af.location         = APPLY_HIT;
    af.modifier         = 10;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

	af.location			= APPLY_AC;
	af.modifier			= 5;
	spellAffectToChar(victim,&af);

	act("You are protected by the Shield of Salika.",victim,NULL,NULL,TO_CHAR);
	if ( victim != ch )
		act("$N is protected by the Shield of Salika.",ch,NULL,victim,TO_CHAR);
    return TRUE; 
}

bool spell_shield_of_selika( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where            = TO_AFFECTS;
    af.level            = level;
    af.type             = sn; 
    af.duration         = minutes(48);
    af.location         = APPLY_HIT;
    af.modifier         = 20;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

    af.location         = APPLY_AC;
    af.modifier         = 10;
    spellAffectToChar(victim,&af);

    act("You are protected by the Shield of Selika.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N is protected by the Shield of Selika.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_shield_of_silika( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where            = TO_AFFECTS;
    af.level            = level;
    af.type             = sn; 
    af.duration         = minutes(56);
    af.location         = APPLY_HIT;
    af.modifier         = 30;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

    af.location         = APPLY_AC;
    af.modifier         = 20;
    spellAffectToChar(victim,&af);

    act("You are protected by the Shield of Silika.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N is protected by the Shield of Silika.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_shield_of_solika( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where            = TO_AFFECTS;
    af.level            = level;
    af.type             = sn; 
    af.duration         = minutes(64);
    af.location         = APPLY_HIT;
    af.modifier         = 40;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

    af.location         = APPLY_AC;
    af.modifier         = 30;
    spellAffectToChar(victim,&af);

    act("You are protected by the Shield of Solika.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N is protected by the Shield of Solika.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_shield_of_sulika( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where            = TO_AFFECTS;
    af.level            = level;
    af.type             = sn; 
    af.duration         = minutes(72);
    af.location         = APPLY_HIT;
    af.modifier         = 50;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

    af.location         = APPLY_AC;
    af.modifier         = 40;
    spellAffectToChar(victim,&af);

    act("You are protected by the Shield of Sulika.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N is protected by the Shield of Sulika.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_shield_of_sylika( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where            = TO_AFFECTS;
    af.level            = level;
    af.type             = sn; 
    af.duration         = minutes(80);
    af.location         = APPLY_HIT;
    af.modifier         = 75;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

    af.location         = APPLY_AC;
    af.modifier         = 50;
    spellAffectToChar(victim,&af);

    act("You are protected by the Shield of Sylika.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N is protected by the Shield of Sylika.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_shield_of_aelika( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where            = TO_AFFECTS;
    af.level            = level;
    af.type             = sn; 
    af.duration         = minutes(88);
    af.location         = APPLY_HIT;
    af.modifier         = 100;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

    af.location         = APPLY_AC;
    af.modifier         = 75;
    spellAffectToChar(victim,&af);

    act("You are protected by the Shield of Aelika.",victim,NULL,NULL,TO_CHAR);
    if ( victim != ch )
        act("$N is protected by the Shield of Aelika.",ch,NULL,victim,TO_CHAR);
    return TRUE;
}

bool spell_animate_bones( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet;
	int conj_skill, hp_max;
	int i;
	char buf[MAX_STRING_LENGTH];

	if( ch->pet != NULL )
	{
		cprintf(ch,"Dismiss the one you have!\n\r");
		return FALSE;
	}

	pet = create_mobile( get_mob_index( MOB_VNUM_SKELETAL_PET ) );
    SET_BIT(pet->act, ACT_PET);
    SET_BIT(pet->affected_by, AFF_CHARM);
	SET_BIT(pet->form, FORM_SUMMONED);
    pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
    char_to_room( pet, ch->in_room );
    ch->pet = pet;

	pet->class = csn_paladin;
	conj_skill = get_skill(ch,skill_lookup("conjuration"));
	hp_max = conj_skill * 10;
	pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
	pet->max_base_hit = pet->max_stat_hit / 5;
	pet->stat_hit = pet->max_stat_hit;
	pet->base_hit = pet->max_base_hit;
	pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000; /* these guys never exhaust */
	pet->level = ch->level;

	for( i = 0; i < MAX_STATS ; i++ )
		pet->perm_stat[i] = 100 + (conj_skill*3);

	for( i = 0 ; i < 4 ; i++ )
		pet->armor[i] = conj_skill * 5 / 10;
	pet->armor[3] /= 4;

	pet->hitroll = conj_skill * 6 / 10;
	pet->damage[0] = 1;
	pet->damage[1] = 6;
	pet->damage[2] = conj_skill * 2 / 10;

	snprintf(buf,sizeof(buf),"animated bones");
	free_string( pet->name );
	pet->name = str_dup( buf );

	snprintf(buf,sizeof(buf),"some animated bones");
	free_string( pet->short_descr );
	pet->short_descr = str_dup( buf );

	snprintf(buf,sizeof(buf),"Some animated bones stand at attention here.\n\r");
	free_string( pet->long_descr );
	pet->long_descr = str_dup( buf );

	act("A black hole swirls into existance, and $n steps through.", pet,NULL,NULL,TO_ROOM);
	act("$N gazes at $n with empty eyes, awaiting instructions.", ch,NULL,pet,TO_NOTVICT);
	act("$N gazes at you with empty eyes, awaiting instructions.", ch,NULL,pet,TO_CHAR);
	add_follower( pet, ch );	
 	pet->leader = ch;
	return TRUE;
}

bool spell_summon_skeletal_minion( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet;
	int conj_skill, hp_max;
	int i;
	char buf[MAX_STRING_LENGTH];

	if( ch->pet != NULL )
	{
		cprintf(ch,"Dismiss the one you have!\n\r");
		return FALSE;
	}

	pet = create_mobile( get_mob_index( MOB_VNUM_SKELETAL_PET ) );
    SET_BIT(pet->act, ACT_PET);
    SET_BIT(pet->affected_by, AFF_CHARM);
	SET_BIT(pet->form, FORM_SUMMONED);
    pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
	pet->off_flags |= OFF_PARRY;
    char_to_room( pet, ch->in_room );
    pet->leader = ch;
    ch->pet = pet;

	pet->class = csn_paladin;
	conj_skill = get_skill(ch,skill_lookup("conjuration"));
	hp_max = conj_skill * 15;
	pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
	pet->max_base_hit = pet->max_stat_hit / 5;
	pet->stat_hit = pet->max_stat_hit;
	pet->base_hit = pet->max_base_hit;
	pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000; /* these guys never exhaust */
	pet->level = ch->level;

	for( i = 0; i < MAX_STATS ; i++ )
		pet->perm_stat[i] = 100 + (conj_skill*3);

	for( i = 0 ; i < 4 ; i++ )
		pet->armor[i] = conj_skill * 75 / 100;
	pet->armor[3] /= 4;

	pet->hitroll = conj_skill * 8 / 10;
	pet->damage[0] = 2;
	pet->damage[1] = 6;
	pet->damage[2] = conj_skill * 25 / 100;

	snprintf(buf,sizeof(buf),"skeletal minion");
	free_string( pet->name );
	pet->name = str_dup( buf );

	snprintf(buf,sizeof(buf),"a skeletal minion");
	free_string( pet->short_descr );
	pet->short_descr = str_dup( buf );

	snprintf(buf,sizeof(buf),"A skeletal minion stands at attention here.\n\r");
	free_string( pet->long_descr );
	pet->long_descr = str_dup( buf );

	act("A black hole swirls into existance, and $n steps through.", pet,NULL,NULL,TO_ROOM);
	act("$N gazes at $n with empty eyes, awaiting instructions.", ch,NULL,pet,TO_NOTVICT);
	act("$N gazes at you with empty eyes, awaiting instructions.", ch,NULL,pet,TO_CHAR);
	add_follower( pet, ch );
	pet->leader = ch;
    pet_to_group( ch, pet );
	return TRUE;
}

bool spell_summon_skeletal_soldier( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet;
	int conj_skill, hp_max;
	int i;
	char buf[MAX_STRING_LENGTH];

	if( ch->pet != NULL )
	{
		cprintf(ch,"Dismiss the one you have!\n\r");
		return FALSE;
	}

	pet = create_mobile( get_mob_index( MOB_VNUM_SKELETAL_PET ) );
    SET_BIT(pet->act, ACT_PET);
    SET_BIT(pet->affected_by, AFF_CHARM);
	SET_BIT(pet->form, FORM_SUMMONED);
    pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
	pet->off_flags |= OFF_PARRY;
	pet->off_flags |= OFF_DODGE;
    char_to_room( pet, ch->in_room );
    pet->leader = ch;
    ch->pet = pet;

	pet->class = csn_fighter;
	conj_skill = get_skill(ch,skill_lookup("conjuration"));
	hp_max = conj_skill * 20;
	pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
	pet->max_base_hit = pet->max_stat_hit / 5;
	pet->stat_hit = pet->max_stat_hit;
	pet->base_hit = pet->max_base_hit;
	pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000; /* these guys never exhaust */
	pet->level = ch->level;

	for( i = 0; i < MAX_STATS ; i++ )
		pet->perm_stat[i] = 100 + (conj_skill*3);

	for( i = 0 ; i < 4 ; i++ )
		pet->armor[i] = conj_skill;
	pet->armor[3] /= 4;

	pet->hitroll = conj_skill;
	pet->damage[0] = 3;
	pet->damage[1] = 6;
	pet->damage[2] = conj_skill * 3 / 10;

	snprintf(buf,sizeof(buf),"skeletal soldier");
	free_string( pet->name );
	pet->name = str_dup( buf );

	snprintf(buf,sizeof(buf),"a skeletal soldier");
	free_string( pet->short_descr );
	pet->short_descr = str_dup( buf );

	snprintf(buf,sizeof(buf),"A skeletal soldier stands at attention here.\n\r");
	free_string( pet->long_descr );
	pet->long_descr = str_dup( buf );

	act("A black hole swirls into existance, and $n steps through.", pet,NULL,NULL,TO_ROOM);
	act("$N gazes at $n with empty eyes, awaiting instructions.", ch,NULL,pet,TO_NOTVICT);
	act("$N gazes at you with empty eyes, awaiting instructions.", ch,NULL,pet,TO_CHAR);
	add_follower( pet, ch );
	pet->leader = ch;
    pet_to_group( ch, pet );
	return TRUE;
}

bool spell_summon_skeletal_warrior( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet;
	int conj_skill, hp_max;
	int i;
	char buf[MAX_STRING_LENGTH];

	if( ch->pet != NULL )
	{
		cprintf(ch,"Dismiss the one you have!\n\r");
		return FALSE;
	}

	pet = create_mobile( get_mob_index( MOB_VNUM_SKELETAL_PET ) );
    SET_BIT(pet->act, ACT_PET);
    SET_BIT(pet->affected_by, AFF_CHARM);
	SET_BIT(pet->form, FORM_SUMMONED);
    pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
	pet->off_flags |= ( OFF_PARRY | OFF_DODGE | OFF_BASH );
    char_to_room( pet, ch->in_room );
    pet->leader = ch;
    ch->pet = pet;

	pet->class = csn_fighter;
	conj_skill = get_skill(ch,skill_lookup("conjuration"));
	hp_max = conj_skill * 30;
	pet->max_stat_hit = number_range( hp_max * 7/10, hp_max ); 
	pet->max_base_hit = pet->max_stat_hit / 5;
	pet->stat_hit = pet->max_stat_hit;
	pet->base_hit = pet->max_base_hit;
	pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000; /* these guys never exhaust */
	pet->level = ch->level;

	for( i = 0; i < MAX_STATS ; i++ )
		pet->perm_stat[i] = 100 + (conj_skill*3);

	for( i = 0 ; i < 4 ; i++ )
		pet->armor[i] = conj_skill * 125 / 100;
	pet->armor[3] /= 4;

	pet->hitroll = conj_skill * 12 / 10;
	pet->damage[0] = 3;
	pet->damage[1] = 6;
	pet->damage[2] = conj_skill * 35 / 100;

	snprintf(buf,sizeof(buf),"skeletal warrior");
	free_string( pet->name );
	pet->name = str_dup( buf );

	snprintf(buf,sizeof(buf),"a skeletal warrior");
	free_string( pet->short_descr );
	pet->short_descr = str_dup( buf );

	snprintf(buf,sizeof(buf),"A skeletal warrior stands at attention here.\n\r");
	free_string( pet->long_descr );
	pet->long_descr = str_dup( buf );

	act("A black hole swirls into existance, and $n steps through.", pet,NULL,NULL,TO_ROOM);
	act("$N gazes at $n with empty eyes, awaiting instructions.", ch,NULL,pet,TO_NOTVICT);
	act("$N gazes at you with empty eyes, awaiting instructions.", ch,NULL,pet,TO_CHAR);
	add_follower( pet, ch );
	pet->leader = ch;
    pet_to_group( ch, pet );
	return TRUE;
}

bool spell_summon_skeletal_captain( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet;
	int conj_skill, hp_max;
	int i;
	char buf[MAX_STRING_LENGTH];

	if( ch->pet != NULL )
	{
		cprintf(ch,"Dismiss the one you have!\n\r");
		return FALSE;
	}

	pet = create_mobile( get_mob_index( MOB_VNUM_SKELETAL_PET ) );
    SET_BIT(pet->act, ACT_PET);
    SET_BIT(pet->affected_by, AFF_CHARM);
	SET_BIT(pet->form, FORM_SUMMONED);
    pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
	pet->off_flags |= ( OFF_PARRY | OFF_DODGE | OFF_BASH | OFF_DRAIN_TOUCH );
    char_to_room( pet, ch->in_room );
    pet->leader = ch;
    ch->pet = pet;

	pet->class = csn_barbarian;;
	conj_skill = get_skill(ch,skill_lookup("conjuration"));
	hp_max = conj_skill * 40;
	pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
	pet->max_base_hit = pet->max_stat_hit / 5;
	pet->stat_hit = pet->max_stat_hit;
	pet->base_hit = pet->max_base_hit;
	pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000; /* these guys never exhaust */
	pet->level = ch->level;

	for( i = 0; i < MAX_STATS ; i++ )
		pet->perm_stat[i] = 100 + (conj_skill*3);

	for( i = 0 ; i < 4 ; i++ )
		pet->armor[i] = conj_skill * 15 / 10;
	pet->armor[3] /= 4;

	pet->hitroll = conj_skill * 14 / 10;
	pet->damage[0] = 3;
	pet->damage[1] = 6;
	pet->damage[2] = conj_skill * 4 / 10;

	snprintf(buf,sizeof(buf),"skeletal captain");
	free_string( pet->name );
	pet->name = str_dup( buf );

	snprintf(buf,sizeof(buf),"a skeletal captain");
	free_string( pet->short_descr );
	pet->short_descr = str_dup( buf );

	snprintf(buf,sizeof(buf),"A skeletal captain stands at attention here.\n\r");
	free_string( pet->long_descr );
	pet->long_descr = str_dup( buf );

	act("A black hole swirls into existance, and $n steps through.", pet,NULL,NULL,TO_ROOM);
	act("$N gazes at $n with empty eyes, awaiting instructions.", ch,NULL,pet,TO_NOTVICT);
	act("$N gazes at you with empty eyes, awaiting instructions.", ch,NULL,pet,TO_CHAR);
	add_follower( pet, ch );
	pet->leader = ch;
    pet_to_group( ch, pet );
	return TRUE;
}

bool spell_summon_skeletal_general( int sn, int level, Character *ch, void *vo, int target )
{
	Character *pet;
	int conj_skill, hp_max;
	int i;
	char buf[MAX_STRING_LENGTH];

	if( ch->pet != NULL )
	{
		cprintf(ch,"Dismiss the one you have!\n\r");
		return FALSE;
	}

	pet = create_mobile( get_mob_index( MOB_VNUM_SKELETAL_PET ) );
    SET_BIT(pet->act, ACT_PET);
    SET_BIT(pet->affected_by, AFF_CHARM);
	SET_BIT(pet->form, FORM_SUMMONED);
    pet->comm = COMM_NOTELL|COMM_NOSHOUT|COMM_NOCHANNELS;
	pet->off_flags = ( OFF_PARRY | OFF_DODGE | OFF_BASH | OFF_DRAIN_TOUCH );
    char_to_room( pet, ch->in_room );
    pet->leader = ch;
    ch->pet = pet;

	pet->class = csn_barbarian;
	conj_skill = get_skill(ch,skill_lookup("conjuration"));
	hp_max = conj_skill * 75;
	pet->max_stat_hit = number_range( hp_max * 7/10, hp_max );
	pet->max_base_hit = pet->max_stat_hit / 5;
	pet->stat_hit = pet->max_stat_hit;
	pet->base_hit = pet->max_base_hit;
	pet->max_stamina = pet->stamina = pet->move = pet->max_move = 30000; /* these guys never exhaust */
	pet->level = ch->level;

	for( i = 0; i < MAX_STATS ; i++ )
		pet->perm_stat[i] = 100 + (conj_skill*3);

	for( i = 0 ; i < 4 ; i++ )
		pet->armor[i] = conj_skill * 20 / 10;
	pet->armor[3] /= 4;

	pet->hitroll = conj_skill * 16 / 10;
	pet->damage[0] = 3;
	pet->damage[1] = 6;
	pet->damage[2] = conj_skill * 45 / 100;

	snprintf(buf,sizeof(buf),"skeletal general");
	free_string( pet->name );
	pet->name = str_dup( buf );

	snprintf(buf,sizeof(buf),"a skeletal general");
	free_string( pet->short_descr );
	pet->short_descr = str_dup( buf );

	snprintf(buf,sizeof(buf),"A skeletal general stands at attention here.\n\r");
	free_string( pet->long_descr );
	pet->long_descr = str_dup( buf );

	act("A black hole swirls into existance, and $n steps through.", pet,NULL,NULL,TO_ROOM);
	act("$N gazes at $n with empty eyes, awaiting instructions.", ch,NULL,pet,TO_NOTVICT);
	act("$N gazes at you with empty eyes, awaiting instructions.", ch,NULL,pet,TO_CHAR);
	add_follower( pet, ch );
	pet->leader = ch;
    pet_to_group( ch, pet );
	return TRUE;
}

bool spell_improved_senses( int sn, int level, Character *ch, void *vo, int target )
{   
    Character *victim = (Character *) vo;
    Affect af;

    af.where            = TO_AFFECTS;;
    af.level            = level;
    af.type             = sn;
    af.duration         = minutes(60);
    af.location         = APPLY_HITROLL;
    af.modifier         = 10;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

	act("Your senses are heightened.",ch,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_heightened_senses( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where            = TO_AFFECTS;;
    af.level            = level;
    af.type             = sn;
    af.duration         = minutes(60);
    af.location         = APPLY_HITROLL;
    af.modifier         = 35;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

    act("Your senses are heightened.",ch,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_raised_senses( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where            = TO_AFFECTS;;
    af.level            = level;
    af.type             = sn;
    af.duration         = minutes(60);
    af.location         = APPLY_HITROLL;
    af.modifier         = 70;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

    act("Your senses are heightened.",ch,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_uncanny_senses( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where            = TO_AFFECTS;;
    af.level            = level;
    af.type             = sn;
    af.duration         = minutes(60);
    af.location         = APPLY_HITROLL;
    af.modifier         = 110;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

    act("Your senses are heightened.",ch,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_foresight( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where            = TO_AFFECTS;;
    af.level            = level;
    af.type             = sn;
    af.duration         = minutes(60);
    af.location         = APPLY_HITROLL;
    af.modifier         = 155;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

    act("Your senses are heightened.",ch,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_precognition( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where            = TO_AFFECTS;;
    af.level            = level;
    af.type             = sn;
    af.duration         = minutes(60);
    af.location         = APPLY_HITROLL;
    af.modifier         = 205;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

    act("Your senses are heightened.",ch,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_spirit_armor( int sn, int level, Character *ch, void *vo, int target )
{   
    Character *victim = (Character *) vo;
    Affect af;
    
    af.where            = TO_AFFECTS;;
    af.level            = level;  
    af.type             = sn;
    af.duration         = minutes(level);
    af.location         = APPLY_AC;
    af.modifier         = max_stat_hit(victim) / 10;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

	af.modifier			*= -1;
	af.location			= APPLY_HIT;
	spellAffectToChar(victim,&af);
   
	act("You wince as the spirit armor surrounds you.",victim,NULL,NULL,TO_CHAR);
	act("$n winces as spirit armor surrounds $m.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_soul_armor( int sn, int level, Character *ch, void *vo, int target )
{   
    Character *victim = (Character *) vo;
    Affect af;
    
    af.where            = TO_AFFECTS;;
    af.level            = level;  
    af.type             = sn;
    af.duration         = minutes(level);
    af.location         = APPLY_AC;
    af.modifier         = max_stat_hit(victim) / 5;
    af.bitvector        = 0;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

	af.modifier			*= -1;
	af.location			= APPLY_HIT;
	spellAffectToChar(victim,&af);
   
	act("You wince as the soul armor surrounds you.",victim,NULL,NULL,TO_CHAR);
	act("$n winces as soul armor surrounds $m.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_minor_rot( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;   
  
    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
    {
        act("A flash of pain shakes $n but leaves no mark.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else 
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_SPIRIT;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = 2;
        af.modifier     = 4;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("Your flesh begins to rot and fall away.",victim,NULL,NULL,TO_CHAR);
        act("The flesh begins to rot and fall away from $n.",victim,NULL,NULL,TO_ROOM);
    }

    damage( ch, victim, 12, sn, DAM_SPIRIT , DF_SPELL|DF_SHOW );
    return TRUE;
}

bool spell_rot( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
    {
        act("A flash of pain shakes $n but leaves no mark.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_SPIRIT;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = 3;
        af.modifier     = 6;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("Your flesh begins to rot and fall away.",victim,NULL,NULL,TO_CHAR);
        act("The flesh begins to rot and fall away from $n.",victim,NULL,NULL,TO_ROOM);
    }
    
    damage( ch, victim, 18, sn, DAM_SPIRIT , DF_SPELL|DF_SHOW );
    return TRUE;
}

bool spell_decay( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
    {
        act("A flash of pain shakes $n but leaves no mark.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_SPIRIT;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = 5;
        af.modifier     = 10;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("Your flesh begins to rot and fall away.",victim,NULL,NULL,TO_CHAR);
        act("The flesh begins to rot and fall away from $n.",victim,NULL,NULL,TO_ROOM);
    }
    
    damage( ch, victim, 30, sn, DAM_SPIRIT , DF_SPELL|DF_SHOW );
    return TRUE;
}

bool spell_decompose( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
    {
        act("A flash of pain shakes $n but leaves no mark.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_SPIRIT;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = 9;
        af.modifier     = 18;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("Your flesh begins to rot and fall away.",victim,NULL,NULL,TO_CHAR);
        act("The flesh begins to rot and fall away from $n.",victim,NULL,NULL,TO_ROOM);
    }
    
    damage( ch, victim, 54, sn, DAM_SPIRIT , DF_SPELL|DF_SHOW );
    return TRUE;
}

bool spell_deteriorate( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
    {
        act("A flash of pain shakes $n but leaves no mark.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_SPIRIT;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = 15;
        af.modifier     = 30;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("Your flesh begins to rot and fall away.",victim,NULL,NULL,TO_CHAR);
        act("The flesh begins to rot and fall away from $n.",victim,NULL,NULL,TO_ROOM);
    }
    
    damage( ch, victim, 90, sn, DAM_SPIRIT , DF_SPELL|DF_SHOW );
    return TRUE;
}

bool spell_disintigrate( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_FORTITUDE) )
    {
        act("A flash of pain shakes $n but leaves no mark.",victim,NULL,NULL,TO_ROOM);
        return TRUE;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
		af.caster_id	= ch->id;
        af.bitvector    = DAM_SPIRIT;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(60);
        af.location     = 23;
        af.modifier     = 46;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("Your flesh begins to rot and fall away.",victim,NULL,NULL,TO_CHAR);
        act("The flesh begins to rot and fall away from $n.",victim,NULL,NULL,TO_ROOM);
    }
    
    damage( ch, victim, 138, sn, DAM_SPIRIT , DF_SPELL|DF_SHOW );
    return TRUE;
}

bool spell_control_undead( int sn, int level, Character *ch,void *vo,int target)
{
	Character *undead = (Character *) vo;;

	if( ch->pet != NULL )
	{
		cprintf(ch,"Dismiss the one you have!\n\r");
		return FALSE;
	}

	if ( !IS_SET(undead->form,FORM_UNDEAD) )
	{
		act("$N isn't undead.",ch,NULL,undead,TO_CHAR);
		return FALSE;
	}

	/* Cannot charm anything over your 'necromancy' ability */
	if ( undead->level > get_skill(ch,skill_lookup("necromancy")) )
	{
		act("$N is too powerful for you to control.",ch,NULL,undead,TO_CHAR);
		return FALSE;
	}
	
	if ( check_saves_spell(ch,undead,DAM_MENTAL,SAVE_WILLPOWER)) 
	{
		cprintf(ch,"You failed.\n\r");
		return TRUE;
	}

    add_follower( undead, ch );
    undead->leader = ch;
    ch->pet = undead;
	SET_BIT( undead->affected_by, AFF_CHARM );
	SET_BIT( undead->act, ACT_PET );
	REMOVE_BIT( undead->act, ACT_AGGRESSIVE );
	act("$N shudders and then bows before you.",ch,NULL,undead,TO_CHAR);
	act("$N shudders and then bows before $n.",ch,NULL,undead,TO_NOTVICT);
	act("You shudder and then bow before $n.",ch,NULL,undead,TO_VICT);
    pet_to_group( ch, undead );
	return TRUE;
}

bool spell_summon_corpse( int sn, int level, Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
 	Object *corpse;
 
	if ( IS_NPC(victim) )
	{
		cprintf(ch,"This spell does'nt work on NPCs.\n\r");
		return FALSE;
	}

	if( !is_same_group(ch,victim) )
	{
		act("You must be grouped with $N to use this spell.",ch,NULL,victim,TO_CHAR);
		return FALSE;
	}

	for ( corpse = object_list ; corpse ; corpse = corpse->next )
	{
		if ( corpse->item_type != ITEM_CORPSE_PC || corpse->in_room == NULL )
			continue;

		if ( !str_cmp(corpse->owner,victim->name) )
		{
			Room *save;

			save = ch->in_room;
			ch->in_room = corpse->in_room;
			act("$P vanishes in a puff of smoke!",ch,NULL,corpse,TO_ROOM);
			ch->in_room = save;

			obj_from_room( corpse );
			obj_to_room( corpse, ch->in_room );
			act("$P materializes in a puff of smoke.",ch,NULL,corpse,TO_ROOM);
			act("$P materializes in a puff of smoke.",ch,NULL,corpse,TO_CHAR);
			return TRUE;
		}
			
	}

	act("$N doesn't have a corpse that you can locate.",ch,NULL,victim,TO_CHAR);
	return FALSE;
}

bool spell_reclaim_energy( int sn, int level, Character *ch,void *vo,int target)
{
    Character *pet = (Character *) vo;
	int mana;

	act("$N crumbles to the ground in a cloud of dust!",ch,NULL,pet,TO_CHAR);
	act("$n crumbles to the ground in a cloud of dust!",pet,NULL,NULL,TO_ROOM);
    ch->pet = NULL;
	mana = pet->level * 10;
	mana = number_range( mana * 7/8, mana *9/8 );
	ch->mana = UMIN( (ch->mana + mana), max_mana( ch ) );
	extract_char( pet, TRUE );
	
	return TRUE;
}

