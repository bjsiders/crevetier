/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,	   *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *									   *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael	   *
 *  Chastain, Michael Quan, and Mitchell Tse.				   *
 *									   *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc	   *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.						   *
 *									   *
 *  Much time and thought has gone into this software and you are	   *
 *  benefitting.  We hope that you share your changes too.  What goes	   *
 *  around, comes around.						   *
 ***************************************************************************/
 
/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#ifndef recycle_h
#define recycle_h

/* externs */
extern char str_empty[1];
extern int mobile_count;

/* stuff for providing a crash-proof buffer */

#define MAX_BUF		16384
#define MAX_BUF_LIST 	10
#define BASE_BUF 	1024

/* valid states */
#define Buffer_SAFE	0
#define Buffer_OVERFLOW	1
#define Buffer_FREED 	2

Alliance		*new_alliance	( void );
void			free_alliance	( Alliance *alliance );
Account			*new_account	( void );
void			free_account	( Account *acco );
Artifact		*new_artifact	( void );
void			free_artifact	( Artifact *art );
Building		*new_building	( void );
void			free_building	( Building * );
Resource		*new_resource	( void );
void			free_resource	( Resource * );
Script			*new_script		( void );
void			free_script		( Script * );
Track			*new_tracking	( void );
void			free_tracking	( Track * );
Faction			*new_faction	(void);
void			free_faction	( Faction *f );
Casting		    *new_casting_data (void );
void            free_casting_data ( Casting *spell );
Firing          *new_firing_data (void );
void            free_firing_data ( Firing *fire );

Reuse_wait		*new_reuse( void );
void			free_reuse( Reuse_wait * );

struct make_guild	*new_make_guild( void );
void				free_make_guild( struct make_guild *ptr );
void				free_clan( Clan * );
Clan 	*new_clan( void );


Ignore	*new_ignore( void );
void	free_ignore( Ignore *ignore );

/* group data */
#define GD Group
GD      *new_group (void);
void    free_group (Group *group);
#undef GD

/* melee data */
#define MD Melee
MD	*new_melee (void);
void	free_melee (Melee *melee);
#undef MD

/* note recycling */
#define ND Note
ND	*new_note (void);
void	free_note (Note *note);
#undef ND

/* ban data recycling */
#define BD BAN_DATA
BD	*new_ban (void);
void	free_ban (BAN_DATA *ban);
#undef BD

/* descriptor recycling */
#define DD Descriptor
DD	*new_descriptor (void);
void	free_descriptor (Descriptor *d);
#undef DD

/* char gen data recycling */
#define GD NewbieData
GD 	*new_gen_data (void);
void	free_gen_data (NewbieData * gen);
#undef GD

/* extra descr recycling */
#define ED ExtraDescr
ED	*new_extra_descr (void);
void	free_extra_descr (ExtraDescr *ed);
#undef ED

/* affect recycling */
#define AD Affect
AD	*new_affect (void);
void	free_affect (Affect *af);
#undef AD

/* object recycling */
#define OD Object
OD	*new_obj (void);
void	free_obj (Object *obj);
#undef OD

/* character recyling */
#define CD Character
#define PD PCData
CD	*new_char (void);
void	free_char (Character *ch);
PD	*new_pcdata (void);
void	free_pcdata (PCData *pcdata);
#undef PD
#undef CD


/* mob id and memory procedures */
#define MD NPCMemory
long 	get_pc_id (void);
long	get_mob_id (void);
MD	*new_mem_data (void);
void	free_mem_data ( NPCMemory *memory);
MD	*find_memory (NPCMemory *memory, long id);
#undef MD

/* buffer procedures */

Buffer	*new_buf (void);
Buffer  *new_buf_size (int size);
void	free_buf (Buffer *buffer);
bool	add_buf (Buffer *buffer, char *string);
void	clear_buf (Buffer *buffer);
char	*buf_string (Buffer *buffer);

#endif /* reecycle_h */
