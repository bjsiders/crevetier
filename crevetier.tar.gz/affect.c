/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include <math.h> 
#include <sys/types.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "thoc.h"
#include "affect.h"

#include "interp.h"
#include "magic.h"
#include "recycle.h"
#include "tables.h"

void affect_enchant( Object *obj)
{
    /* okay, move all the old flags into new vectors if we have to */
    if (!obj->enchanted)
    {
        Affect *paf, *af_new;
        obj->enchanted = TRUE;

        for (paf = obj->pIndexData->affected; paf != NULL; paf = paf->next)
        {
	    	af_new 				= new_affect();

            af_new->next 		= obj->affected;
            obj->affected 		= af_new;
 
	    	af_new->where		= paf->where;
            af_new->type        = UMAX(0,paf->type);
            af_new->level       = paf->level;
            af_new->duration    = paf->duration;
            af_new->location    = paf->location;
            af_new->modifier    = paf->modifier;
            af_new->bitvector   = paf->bitvector;
        }
    }
}
     
void obj_affect_modify( Object *obj, Affect *paf, bool fAdd )
{
    int mod;

    // This isn't an object affect
    if ( !IS_SET(paf->flags,AFF_OBJ) )
        return;

    mod = paf->modifier;

    if ( !fAdd )
		mod = 0 - mod;

    switch ( paf->location )
    {
    	default:
			log_bug( "Affect_modify: unknown location %d.", paf->location );
			return;

		case APPLY_WEIGHT:
            obj->weight += mod;
            /* Some special handling is necessary here.  If the item's weight
            changes, we have to recalculate the carrying character's total
            weight and if it'll be too heavy, drop it. */
            if ( obj->carried_by != NULL )
            {
                Character *tmp = obj->carried_by;
                obj_from_char( obj );

                if ( get_carry_weight(tmp) + get_obj_weight(obj) > can_carry_w(tmp) )
                {
                    act("$p becomes too heavy and you are forced to drop it!",tmp,obj,NULL,TO_CHAR);
                    obj_to_char( obj, tmp );
                    drop_obj( tmp, obj );
                }
                else
                    obj_to_char( obj, tmp );
            }
            break;
    }

    return;
}     

void affect_modify( Character *ch, Affect *paf, bool fAdd )
{
    int mod,i;

    // This is an object-only affect
    if ( IS_SET(paf->flags,AFF_OBJ) )
        return;

    /* DOTs just handle damage. */
    if ( paf->where == DAMAGE_OVER_TIME || paf->where == SAVES_BONUS ||
		 paf->where == DAMAGE_SHIELD )
        return;

    mod = paf->modifier;

    if ( fAdd )
    {
		switch (paf->where)
		{
		case TO_AFFECTS: 	SET_BIT(ch->affected_by, paf->bitvector); break;
		case TO_IMMUNE: 	SET_BIT(ch->imm_flags,paf->bitvector); break;
		}
    }
    else
    {
        switch (paf->where)
        {
        case TO_AFFECTS:	REMOVE_BIT(ch->affected_by, paf->bitvector); break;
        case TO_IMMUNE: 	REMOVE_BIT(ch->imm_flags,paf->bitvector); break;
        }
		mod = 0 - mod;
    }

    switch ( paf->location )
    {
    	default:
			log_bug( "Affect_modify: unknown location %d.", paf->location );
			return;

		case APPLY_REGEN_STAMINA:
		case APPLY_REGEN_HP:
		case APPLY_REGEN_BASE:
    	case APPLY_NONE:	
			break;
		case APPLY_SKILL:	
			if( IS_NPC(ch)) 
				break;
			ch->pcdata->skill_mod[paf->misc] += mod; break;
		case APPLY_ABSORB:		ch->absorb				+= mod; break;
		case APPLY_STAMINA:		ch->max_stamina			+= mod; break;
		case APPLY_BASE_HITS:	ch->max_base_hit		+= mod; break;
    	case APPLY_STR:			ch->mod_stat[STAT_STR]	+= mod;	break;
    	case APPLY_DEX:       	ch->mod_stat[STAT_DEX]	+= mod;	break;
    	case APPLY_INT:         ch->mod_stat[STAT_INT]	+= mod;	break;
    	case APPLY_WIS:         ch->mod_stat[STAT_WIS]	+= mod;	break;
    	case APPLY_CON:         ch->mod_stat[STAT_CON]	+= mod;	break;
    	case APPLY_CHA:	      	ch->mod_stat[STAT_CHA]	+= mod; break;
    	case APPLY_SEX:         ch->sex			+= mod;	break;
    	case APPLY_CLASS:						break;
    	case APPLY_LEVEL:						break;
    	case APPLY_AGE:			 				break;
    	case APPLY_HEIGHT:						break;
    	case APPLY_WEIGHT:                      break;
    	case APPLY_MANA:        ch->max_mana			+= mod;	break;
    	case APPLY_HIT:         ch->max_stat_hit		+= mod;	break;
    	case APPLY_MOVE:        ch->max_move			+= mod;	break;
    	case APPLY_GOLD:						break;
    	case APPLY_EXP:							break;
    	case APPLY_AC:
        						for (i = 0; i < 4; i ++)
            						ch->armor[i] += mod;
        						break;
    	case APPLY_HITROLL:     ch->hitroll		+= mod;	break;
    	case APPLY_DAMROLL:     ch->damroll		+= mod;	break;
    	case APPLY_SAVE_REFLEX:         ch->saves[SAVE_REFLEX] += mod; break;
    	case APPLY_SAVE_FORTITUDE:      ch->saves[SAVE_FORTITUDE] += mod; break;
    	case APPLY_SAVE_WILLPOWER:      ch->saves[SAVE_WILLPOWER] += mod; break;
    	case APPLY_RES_FIRE:    	ch->resists[RESIST_FIRE].mod += mod; break;
    	case APPLY_RES_ICE:	    	ch->resists[RESIST_ICE].mod += mod; break;
    	case APPLY_RES_EARTH:	ch->resists[RESIST_EARTH].mod += mod; break;
    	case APPLY_RES_AIR:		ch->resists[RESIST_AIR].mod += mod; break;
    	case APPLY_RES_LIGHT:	ch->resists[RESIST_LIGHT].mod += mod; break;
		case APPLY_RES_DARK:	ch->resists[RESIST_DARK].mod += mod; break;
    	case APPLY_RES_WATER:	ch->resists[RESIST_WATER].mod += mod; break;
		case APPLY_RES_BODY:	ch->resists[RESIST_BODY].mod += mod; break;
    	case APPLY_RES_POISON:	ch->resists[RESIST_POISON].mod += mod; break;
    	case APPLY_RES_DISEASE:	ch->resists[RESIST_DISEASE].mod += mod; break;
    	case APPLY_RES_MENTAL:	ch->resists[RESIST_MENTAL].mod += mod; break;
    	case APPLY_RES_ACID:	ch->resists[RESIST_ACID].mod += mod ; break;
    	case APPLY_RES_ELECTRICITY: ch->resists[RESIST_ELECTRICITY].mod += mod; break;
    	case APPLY_RES_SPIRIT:	ch->resists[RESIST_SPIRIT].mod += mod; break;
		case APPLY_RES_SOUND:	ch->resists[RESIST_SOUND].mod += mod; break;
		case APPLY_SPEED:
		case APPLY_MOVE_RATE:
		case APPLY_BLADETURN:
    	case APPLY_SPELL_AFFECT:  					break;

    }

    /*
     * Check for weapon wielding.
     * Guard against recursion (for weapons with affects).
     */

    /*
    if ( !IS_NPC(ch) && ( wield = get_eq_char( ch, WEAR_WIELD ) ) != NULL
    &&   get_obj_weight(wield) > (str_app[get_curr_stat(ch,STAT_STR)].wield*10))
    {
		static int depth;

		if ( depth == 0 )
		{
	    	depth++;
	    	act( "You drop $p.", ch, wield, NULL, TO_CHAR );
	    	act( "$n drops $p.", ch, wield, NULL, TO_ROOM );
	    	obj_from_char( wield );
	    	obj_to_room( wield, ch->in_room );
	    	depth--;
		}
    }
    */

    return;
}

/* find an effect in an affect list */
Affect  *affect_find(Affect *paf, int sn)
{
    Affect *paf_find;
    
    for ( paf_find = paf; paf_find != NULL; paf_find = paf_find->next )
    {
        if ( paf_find->type == sn )
			return paf_find;
    }

    return NULL;
}

/* fix object affects when removing one */
void affect_check(Character *ch,int where,int vector)
{
    Affect *paf;
    Object *obj;

    if (where == TO_OBJECT || where == TO_WEAPON || vector == 0)
		return;

    for (paf = ch->affected; paf != NULL; paf = paf->next)
	{
		if (paf->where == where && paf->bitvector == vector)
		{
	    	switch (where)
	    	{
	        case TO_AFFECTS: SET_BIT(ch->affected_by,vector); break;
	        case TO_IMMUNE: SET_BIT(ch->imm_flags,vector);   break;
	    	}
	    	return;
		}
	}

    for (obj = ch->carrying; obj != NULL; obj = obj->next_content)
    {
		if (obj->wear_loc == -1)
	    	continue;

		for (paf = obj->affected; paf != NULL; paf = paf->next)
		{
       		if (paf->where == where && paf->bitvector == vector)
            {
                switch (where)
                {
                    case TO_AFFECTS: SET_BIT(ch->affected_by,vector); break;
                    case TO_IMMUNE: SET_BIT(ch->imm_flags,vector); break;
                }
                return;
            }
		}

        if (obj->enchanted)
	    	continue;

        for (paf = obj->pIndexData->affected; paf != NULL; paf = paf->next)
		{
            if (paf->where == where && paf->bitvector == vector)
            {
                switch (where)
                {
                    case TO_AFFECTS: SET_BIT(ch->affected_by,vector); break;
                    case TO_IMMUNE: SET_BIT(ch->imm_flags,vector); break;
                }
                return;
            }
		}
    }
}

/*
 * Return TRUE if the affect should be added
 * to the character.
 *
 * Return FALSE if there's another affect of
 * the same slot# with a higher level.
 */

bool check_skill( Character *ch, Affect *paf )
{	
	Affect *lp;

	for ( lp = ch->affected ; lp ; lp = lp->next )
	{
		if ( !IS_SET(lp->flags,AFF_SKILL) )
			continue;

		if ( lp->type != paf->type || lp->location != paf->location )
			continue;

		/* if the existing affeect is lower level,
		 * yank it and return true, otherwise
		 * return false.
		 */
		if ( lp->level < paf->level )
		{
			skill_affect_strip( ch, lp->type );
			return TRUE;
		}
		else
			return FALSE;
	}

	return TRUE;
}

/* 
 * If there's another spell of the same series
 * that is a lower level, replace it.
 *
 * Return TRUE if the affect in question should be
 * added to the character.
 */
bool check_replace( Character *ch, Affect *paf )
{
    Affect *lp;
	SpellIndex* pSpellIndex;

	pSpellIndex = get_spell_index( paf->type );
	if(!pSpellIndex)
	{
		log_bug("check_replace: Spell index not found(%d)",paf->type);
		return TRUE;
	}

    if ( pSpellIndex->series == 0 )
		return TRUE;

    for ( lp=ch->affected ; lp!=NULL ; lp = lp->next )
    {
		SpellIndex* pLoopSpellIndex;

		if ( !IS_SET(lp->flags,AFF_SPELL) )
     	    continue;

		/* Under what condition do we yank an affect based on the current?
		   Well, check the series first. */

		/* If they're not the same series they can't overwrite - this covers the same
		 * spell overwriting, since a spell is in the same series as itself  */
		pLoopSpellIndex = get_spell_index( lp->type );
		if(!pLoopSpellIndex)
		{
			log_bug("check_replace: Loop spell index not found(%d)",lp->type);
			continue;
		}

        /* Not in a series */
        if ( pLoopSpellIndex->series == 0 )
            continue;

        if ( !sameSeries(pSpellIndex,pLoopSpellIndex) ) //->series != pLoopSpellIndex->series )
			continue;

		/* Only check if they're the same affect location */
		if ( paf->location != lp->location && paf->where != DAMAGE_OVER_TIME)
	    	continue;

		/* For spells that use 'misc', check it */
		if ( paf->location == lp->location && paf->location == APPLY_SKILL && paf->misc != lp->misc )
			continue;

		if ( paf->location != lp->location )
			continue;

		/*
	 	 * 2. If they are the same series, we yank if the new rank is > the old rank
	 	 */
	    if ( pSpellIndex->series_rank > pLoopSpellIndex->series_rank ||

		/* 
	 	 * 3. If the ranks are equal, we go by casting level 
     	 */
		  	    ( pSpellIndex->series_rank == pLoopSpellIndex->series_rank && 
				  paf->level > lp->level) )

	    {
			affect_strip(ch,lp->type);
		 	return TRUE;
	    }
//		else if(spell_table[paf->type]->series == spell_table[lp->type]->series && paf->where == DAMAGE_OVER_TIME)
//			return FALSE;//Cancel out weaker versions, if it'll overwrite it's already done so
	    else
		{
			return FALSE;
		}
   }

   return TRUE;
} 

/*
 * Give an affect to a char.
 */
bool affect_to_char( Character *ch, Affect *paf )
{
    Affect *paf_new;

    if ( IS_SPELL(paf) && !check_replace( ch, paf ) )
		return FALSE;
	else
	if ( IS_SKILL(paf) && !check_skill( ch, paf ) )
		return FALSE;

    paf_new = new_affect();

    *paf_new		= *paf;

    // Convert absolute times into epoch-seconds
    if ( IS_SET(paf_new->flags,AFF_ABSOLUTE_TIME) )
        paf_new->duration = seconds( paf_new->duration );

    VALIDATE(paf);	/* in case we missed it when we set up paf */
    paf_new->next	= ch->affected;
    ch->affected	= paf_new;

    affect_modify( ch, paf_new, TRUE );
	if ( paf_new->type != gsn_encumbered )
		check_encumbrance(ch);
    return TRUE;
}

/* give an affect to an object */
void affect_to_obj(Object *obj, Affect *paf)
{
    Affect *paf_new;

    paf_new = new_affect();

    *paf_new		= *paf;

    VALIDATE(paf);	/* in case we missed it when we set up paf */
    paf_new->next	= obj->affected;
    obj->affected	= paf_new;

    /* apply any affect vectors to the object's extra_flags */
    if (paf->bitvector)
	{
        switch (paf->where)
        {
        	case TO_OBJECT:
    			SET_BIT(obj->extra_flags,paf->bitvector);
		    	break;
        	case TO_WEAPON:
	    		if (obj->item_type == ITEM_WEAPON)
	       			SET_BIT(obj->value[4],paf->bitvector);
	    		break;
            default:
				break;
        }
	}

    if ( IS_SET(paf->flags,AFF_OBJ) )
        obj_affect_modify(obj,paf,TRUE);

    return;
}

/*
 * Remove an affect from a char.
 */
void affect_remove( Character *ch, Affect *paf )
{
    int where;
    int vector;
	int sn = paf->type;

    if ( ch->affected == NULL )
    {
		log_bug( "Affect_remove: no affect.", 0 );
		return;
    }

    affect_modify( ch, paf, FALSE );
    where = paf->where;
    vector = paf->bitvector;

    if ( paf == ch->affected )
    {
		ch->affected	= paf->next;
    }
    else
    {
		Affect *prev;

		for ( prev = ch->affected; prev != NULL; prev = prev->next )
		{
	    	if ( prev->next == paf )
	    	{
				prev->next = paf->next;
				break;
	    	}
		}

		if ( prev == NULL )
		{
	    	log_bug( "Affect_remove: cannot find paf.", 0 );
	    	return;
		}
    }

    free_affect(paf);
    affect_check(ch,where,vector);
	if ( sn != gsn_encumbered )
		check_encumbrance(ch);
    return;
}

void affect_remove_obj( Object *obj, Affect *paf)
{
    int where, vector;

    if ( obj->affected == NULL )
    {
        log_bug( "Affect_remove_object: no affect.", 0 );
        return;
    }

    if (obj->carried_by != NULL && obj->wear_loc != -1)
		affect_modify( obj->carried_by, paf, FALSE );

    obj_affect_modify( obj, paf, FALSE );

    where = paf->where;
    vector = paf->bitvector;

    /* remove flags from the object if needed */
    if (paf->bitvector)
	{
		switch( paf->where)
        {
        case TO_OBJECT: 
			REMOVE_BIT(obj->extra_flags,paf->bitvector); 
			break;
        case TO_WEAPON: 
			if (obj->item_type == ITEM_WEAPON)
                REMOVE_BIT(obj->value[4],paf->bitvector);
            break;
        }
	}

    if ( paf == obj->affected )
    {
       	obj->affected    = paf->next;
    }
    else
    {
       	Affect *prev;

       	for ( prev = obj->affected; prev != NULL; prev = prev->next )
       	{
           	if ( prev->next == paf )
           	{
               	prev->next = paf->next;
               	break;
           	}
       	}

       	if ( prev == NULL )
       	{
           	log_bug( "Affect_remove_object: cannot find paf.", 0 );
           	return;
       	}
   	}

   	free_affect(paf);

    if (obj->carried_by != NULL && obj->wear_loc != -1)
		affect_check(obj->carried_by,where,vector);
    return;
}

/*
 * Strip all affects of a given sn.
 */
void skill_affect_strip( Character *ch, int sn )
{
    Affect *paf;
    Affect *paf_next;

    for ( paf = ch->affected; paf != NULL; paf = paf_next )
    {
        paf_next = paf->next;
        if ( paf->type == sn && IS_SET(paf->flags,AFF_SKILL) )
            affect_remove( ch, paf );
    }

    return;
}

/*
 * Strip all affects of a given sn.
 */
void affect_strip( Character *ch, int sn )
{
    Affect *paf;
    Affect *paf_next;

    for ( paf = ch->affected; paf != NULL; paf = paf_next )
    {
		paf_next = paf->next;
		if ( paf->type == sn && IS_SET(paf->flags,AFF_SPELL) )
	    	affect_remove( ch, paf );
    }

    return;
}

/*
 * Return true if a char is affected by a spell.
 */
bool is_affected( Character *ch, int sn, int type )
{
    Affect *paf;

    for ( paf = ch->affected; paf != NULL; paf = paf->next )
    {
		if ( paf->type == sn && IS_SET(paf->flags,type) )
	    	return TRUE;
    }

    return FALSE;
}

/*
 * Add or enhance an affect.
 */
void affect_join( Character *ch, Affect *paf )
{
    Affect *paf_old;
    bool found;

    found = FALSE;
    for ( paf_old = ch->affected; paf_old != NULL; paf_old = paf_old->next )
    {
		if ( paf_old->type == paf->type )
		{
	    	paf->level = (paf->level += paf_old->level) / 2;
	    	paf->duration += UMAX(0,paf_old->duration - current_time);
	    	paf->modifier += paf_old->modifier;
	    	affect_remove( ch, paf_old );
	    	break;
		}
    }

    affect_to_char( ch, paf );
    return;
}

char *affect_loc_name( int location, int misc )
{
    switch ( location )
    {
    case APPLY_NONE:		    return "none";
	case APPLY_SKILL:	
		if ( misc < 0 || misc > sizeof( skill_table ) / sizeof( struct skill_type ) )
			return "<unknown skill error>";
		else
			return skill_table[misc].name;
	case APPLY_ABSORB:		    return "absorb";
	case APPLY_STAMINA:		    return "stamina";
	case APPLY_BASE_HITS:	    return "base hits";
    case APPLY_STR:			    return "strength";
    case APPLY_DEX:			    return "dexterity";
    case APPLY_INT:			    return "intelligence";
    case APPLY_WIS:			    return "wisdom";
    case APPLY_CON:			    return "constitution";
    case APPLY_CHA:			    return "charisma";
    case APPLY_SPEED:		    return "attack speed";
    case APPLY_MANA:		    return "mana";
    case APPLY_HIT:			    return "stat hits";
    case APPLY_MOVE:		    return "moves";
    case APPLY_AC:			    return "armor class";
    case APPLY_HITROLL:		    return "hit roll";
    case APPLY_DAMROLL:		    return "damage roll";
    case APPLY_SAVE_REFLEX:		return "reflex saves";
    case APPLY_SAVE_FORTITUDE: 	return "fortitude saves";
    case APPLY_SAVE_WILLPOWER: 	return "willpower saves";
    case APPLY_RES_FIRE:		return "fire resist";
    case APPLY_RES_ICE:	    	return "ice resist";
    case APPLY_RES_EARTH:		return "earth resist";
    case APPLY_RES_AIR:			return "air resist";
    case APPLY_RES_LIGHT:		return "light resist";
	case APPLY_RES_DARK:		return "dark resists";
    case APPLY_RES_WATER:		return "water resist";
	case APPLY_RES_BODY:		return "body resist";
    case APPLY_RES_POISON:		return "poison resist";
    case APPLY_RES_DISEASE:		return "disease resist";
    case APPLY_RES_MENTAL:		return "mind resist";
    case APPLY_RES_ACID:		return "acid resist";
    case APPLY_RES_ELECTRICITY: return "energy resist";
    case APPLY_RES_SPIRIT:		return "spirit resist";
	case APPLY_RES_SOUND:		return "sound resist";
    case APPLY_SPELL_AFFECT:	return "affect flags";
	case APPLY_REGEN_BASE:		return "base hit regen";
	case APPLY_REGEN_HP:		return "stat hit regen";
	case APPLY_REGEN_STAMINA:	return "stamina regen";

    // Object affects
    case APPLY_WEIGHT:          return "weight";
    }

    log_bug( "Affect_location_name: unknown location %d.", location );
    return "(unknown)";
}

/*
 * Return ascii name of an affect bit vector.
 */
char *affect_bit_name( int vector )
{
    static char buf[512];

    buf[0] = '\0';
    if ( vector & AFF_BLIND         ) strcat( buf, " blind"         );
    if ( vector & AFF_INVISIBLE     ) strcat( buf, " invisible"     );
    if ( vector & AFF_DETECT_EVIL   ) strcat( buf, " detect_evil"   );
    if ( vector & AFF_DETECT_GOOD   ) strcat( buf, " detect_good"   );
    if ( vector & AFF_DETECT_INVIS  ) strcat( buf, " detect_invis"  );
    if ( vector & AFF_DETECT_MAGIC  ) strcat( buf, " detect_magic"  );
    if ( vector & AFF_DETECT_HIDDEN ) strcat( buf, " detect_hidden" );
    if ( vector & AFF_FAERIE_FIRE   ) strcat( buf, " faerie_fire"   );
    if ( vector & AFF_INFRARED      ) strcat( buf, " infrared"      );
    if ( vector & AFF_CURSE         ) strcat( buf, " curse"         );
    if ( vector & AFF_POISON        ) strcat( buf, " poison"        );
    if ( vector & AFF_PROTECT_EVIL  ) strcat( buf, " prot_evil"     );
    if ( vector & AFF_PROTECT_GOOD  ) strcat( buf, " prot_good"     );
    if ( vector & AFF_SLEEP         ) strcat( buf, " sleep"         );
    if ( vector & AFF_SNEAK         ) strcat( buf, " sneak"         );
    if ( vector & AFF_CHARM         ) strcat( buf, " charm"         );
    if ( vector & AFF_FLYING        ) strcat( buf, " flying"        );
    if ( vector & AFF_PASS_DOOR     ) strcat( buf, " pass_door"     );
    if ( vector & AFF_BERSERK	    ) strcat( buf, " berserk"	    );
    if ( vector & AFF_CALM	    	) strcat( buf, " calm"	    );
    if ( vector & AFF_HASTE	    	) strcat( buf, " haste"	    );
    if ( vector & AFF_SLOW          ) strcat( buf, " slow"          );
    if ( vector & AFF_PLAGUE	    ) strcat( buf, " plague" 	    );
    if ( vector & AFF_DARK_VISION   ) strcat( buf, " dark_vision"   );
    return ( buf[0] != '\0' ) ? buf+1 : "none";
}

void spellAffectToChar( Character *ch, Affect *af )
{
	af->flags |= AFF_SPELL;
	affect_to_char(ch,af);
}

void skillAffectToChar( Character *ch, Affect *af )
{
	af->flags |= AFF_SKILL;
	affect_to_char(ch,af);
}

char *getAffectDurationString( Affect *paf )
{
    static char duration[128];

    if ( IS_SET( paf->flags,AFF_PULSE ) )
        snprintf(duration,sizeof(duration),"pulse spell");
    else
    switch( paf->duration )
    {
        case DUR_PERMANENT: snprintf(duration,sizeof(duration),"permanent affect"); break;
        case DUR_SPECIAL:   snprintf(duration,sizeof(duration),"special duration"); break;
        default:
            if ( IS_SET(paf->flags,AFF_ABSOLUTE_TIME) )
            {
                if ( paf->duration < 60 )
                    snprintf(duration,sizeof(duration),"%d second%s",
                        (int)paf->duration, paf->duration == 1 ? "" : "s" );
                else
                    snprintf(duration,sizeof(duration),"%d minute%s",
                        (int)paf->duration / 60, paf->duration / 60 == 1 ? "" : "s" );
            }
            else
            if ( paf->location == APPLY_BLADETURN )
                snprintf(duration,sizeof(duration),"special duration");
            else
            if ( paf->duration - current_time < 60 )
                snprintf(duration,sizeof(duration),"%d second%s", 
                    (int)UMAX(0,paf->duration - current_time),
                    UMAX(0,paf->duration - current_time) == 1 ? "" : "s" );
            else
                snprintf(duration,sizeof(duration),"%d minute%s",
                    (int)(paf->duration - current_time) / 60,
                    (paf->duration - current_time) / 60 == 1 ? "" : "s" );
    }

    return duration;
}
