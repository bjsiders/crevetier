/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,	   *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *									   *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael	   *
 *  Chastain, Michael Quan, and Mitchell Tse.				   *
 *									   *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc	   *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.						   *
 *									   *
 *  Much time and thought has gone into this software and you are	   *
 *  benefitting.  We hope that you share your changes too.  What goes	   *
 *  around, comes around.						   *
 ***************************************************************************/
 
/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#ifndef magic_h
#define magic_h

#define SPELL_UNKNOWN       0
#define SPELL_BUFF          1
#define SPELL_DEBUFF        2
#define SPELL_NUKE          3
#define SPELL_COMBO_NUKE    4
#define SPELL_BOLT          5

// Generic spells
// This case handles buffs, debuffs, nukes, and combo nukes
struct generic_spell_type
{
    Affect  affects[5];
    int     lowDamage;
    int     highDamage;
    int     saveType;
    long    damType;
    int     range;  // for bolts
    char    *okRoomEcho;
    char    *okVictimEcho;
    char    *failRoomEcho;
    char    *failVictimEcho;
};

struct summon_spell_type
{
    int     vnum;
};

union spell_action_union
{
    struct generic_spell_type   generic;
    struct summon_spell_type    summon;
};

/*
 * Spell prototypes
 */
struct spell_index_data
{
    char *          name;                   // Name for casting/searching
    char *          full_name;              // Display name
    char *          short_descr;            // Short description
    char *          description;            // Long description
    int             spell_type;             // Buff/debuff/nuke/summon/etc
    SpellAction     action;                 // What it actually does

    sh_int          base_mana;              // Base mana for casting cost computing
    int             series;                 // Which series don't stack           
    sh_int          series_rank;            // Spell power in series             
    sh_int          class_level[MAX_CLASS]; // For divine spells                
    sh_int          target;                 // Valid targets for the spell     
    int *           sgsn;                   // Pointer to skill this spell uses
    SpellFun *      spell_fun;              // Appropriate function           
    sh_int          beats;                  // Delay                         
    int             recast;                 // Recast delay, generally 0    
    char *          msg_damage;             // Damage message              
    char *          incantation;            // Words for spell            
    char *          gesture;                // Movements                 
    char *          msg_off;                // Wear off message         
    char *          msg_obj;                // Wear off message for objects            
    long            flags;                  // Components and other informatino       
    sh_int          vnum;
    SpellIndex *    next;
    char *          func_name;              // must be stored for read/write to file
    char *          filename;
};

/*
 * For casting
 */
struct casting_data
{
    Casting*    next;
    bool        valid;
    sh_int      timer;
    sh_int      spell_sn;
    sh_int      level;
    void *      vo;
    sh_int      target;
    long        flags;
    int         mana;
    int         misc;
};

extern void * libspells;

/*
 * Spell flags
 */
#define DUR_NORMAL               0
#define DUR_PERMANENT            -1
#define DUR_SPECIAL              -2
#define DUR_PULSE                -3

#define COM_VER                 (A)
#define COM_SOM                 (B)
#define COM_MAT                 (C)

#define COM_DIVINE              (aa)
#define COM_ARCANE              (cc)
#define COM_SAME_DEITY          (bb)
#define COM_SAME_ALIGN          (dd)
#define COM_NOT_SAME_DEITY      (Z)

#define MAX_SPELL       901
#define lowDam(x)		(x)
#define	highDam(x)		(x)
#define SET_AC(x)       x
#define SET_ABSORB(x)   x
#define SET_HITROLL(x)  x
#define SET_DAMROLL(x)  x

#define	QUICKCAST		(A)
#define	SILENTCAST		(B)

#define DECLARE_SPELLFUN( fun )     SpellFun fun
#define Spell( fun )                DECLARE_SPELLFUN( spell_##fun )

/*
    20-page spellbooks
*/
#define BITS10      (0x000003ff)
#define BITS20      (0x000ffc00)
#define BITS10MASK  (~BITS10)
#define BITS20MASK  (~BITS20)

#define SAVE_REFLEX                 0
#define SAVE_FORTITUDE              1
#define SAVE_WILLPOWER              2

/*
 *  Target types.
 */
#define TAR_IGNORE                  0
#define TAR_CHAR_OFFENSIVE          1
#define TAR_CHAR_DEFENSIVE          2
#define TAR_CHAR_SELF               3
#define TAR_OBJ_INV                 4
#define TAR_OBJ_CHAR_DEF            5
#define TAR_OBJ_CHAR_OFF            6
#define TAR_CHAR_SELF_PET           7
#define TAR_PET                     8
#define TAR_RANGED                  9

#define TARGET_CHAR                 0
#define TARGET_OBJ                  1
#define TARGET_ROOM                 2
#define TARGET_NONE                 3
#define TARGET_RANGED               4

bool handle_saves_spell( Character *ch, Character *victim, int dam_type, int save_type, int damage_bonus );
int  calcSpellDamage( Character *, int, int, int );
int  calcHealAmount( Character *, int, int, int );
bool enchant_armor( Object *obj, int set_ac, int set_absorb, int sn, int level );
bool enchant_weapon( Object *obj, int set_hitroll, int set_damroll, int sn, int level );

/*
    Macros
*/
#define check_saves_spell(ch,victim,dt,st) _saves_spell(ch,victim,dt,st,sn)
#define minutes(n)                  ( current_time + ( 60 * (n) ) )
#define seconds(n)                  ( current_time + (n) )
#define ticksToMinutes(n)           ( (n) / ( PULSE_AFFECT_UPDATE / PULSE_PER_SECOND ) )
#define ticksToSeconds(n)           ( (n) * ( PULSE_AFFECT_UPDATE / PULSE_PER_SECOND ) )

/*
    Externals
*/
/** Spell vnum globals **/
extern sh_int vnum_phantasmal_protector;
extern sh_int vnum_phantasmal_defender;
extern sh_int vnum_phantasmal_guardian;
extern sh_int vnum_detect_summoned;
extern sh_int vnum_detect_summoned_d;
extern sh_int vnum_detect_animals;
extern sh_int vnum_detect_plants;
extern sh_int vnum_detect_humanoids;
extern sh_int vnum_detect_animals_d;
extern sh_int vnum_detect_humanoids_d;
extern sh_int vnum_death_knell;
extern sh_int vnum_snake_venom;
extern sh_int vnum_amphibian_venom;
extern sh_int vnum_spider_venom;
extern sh_int vnum_insect_venom;
extern sh_int vnum_lizard_venom;
extern sh_int vnum_plant_venom;
extern sh_int vnum_scorpion_venom;
extern sh_int vnum_rejuvenate;
extern sh_int vnum_cure_minor_wounds;
extern sh_int vnum_cure_light_wounds;
extern sh_int vnum_cure_moderate_wounds;
extern sh_int vnum_cure_major_wounds;
extern sh_int vnum_cure_serious_wounds;
extern sh_int vnum_cure_critical_wounds;
extern sh_int vnum_natural_venom;
extern sh_int vnum_food_poisoning;
extern sh_int vnum_swamp_gas;
extern sh_int vnum_cure_poison;
extern sh_int vnum_cure_disease;
extern sh_int vnum_minor_hallucination;
extern sh_int vnum_major_hallucination;
extern sh_int vnum_camouflage;
extern sh_int vnum_water_breathing;
extern sh_int vnum_treeform;
extern sh_int vnum_pass_without_trace;
extern sh_int vnum_levitation;
extern sh_int vnum_life_tap;
extern sh_int vnum_life_touch;
extern sh_int vnum_life_hit;
extern sh_int vnum_life_spike;
extern sh_int vnum_life_take;
extern sh_int vnum_life_steal;
extern sh_int vnum_life_siphon;
extern sh_int vnum_life_drain;
extern sh_int vnum_life_exhaust;

extern sh_int gsn_blindness;
extern sh_int gsn_charm_person;
extern sh_int gsn_curse;
extern sh_int gsn_invis;
extern sh_int gsn_mass_invis;
extern sh_int gsn_plague;
extern sh_int vnum_natural_venom;
extern sh_int vnum_food_poisoning;
extern sh_int vnum_noxious_fumes;
extern sh_int gsn_poison;
extern sh_int gsn_sleep;
extern sh_int gsn_fly;
extern sh_int gsn_sanctuary;

bool spell_generic_buff  ( SpellIndex *sp, int sn, int level, Character *ch, void * vo, int target);
bool spell_generic_debuff( SpellIndex *sp, int sn, int level, Character *ch, void * vo, int target);
bool spell_generic_nuke  ( SpellIndex *sp, int sn, int level, Character *ch, void * vo, int target);
bool spell_generic_combo ( SpellIndex *sp, int sn, int level, Character *ch, void * vo, int target);
bool spell_generic_bolt  ( SpellIndex *sp, int sn, int level, Character *ch, void * vo, int target);

Spell( generic_driver );

#endif
