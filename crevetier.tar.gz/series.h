/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#ifndef series_h
#define series_h

#define SERIES_MAGE_SELF_SHIELDING      1
#define SERIES_COLD_INTOL          2
#define SERIES_FIRE_INTOL          3
#define SERIES_DEX_BUFF            4
#define SERIES_CON_BUFF            5
#define SERIES_CONSTITUTION_BUFF        6
#define SERIES_HASTE               7
#define SERIES_SLOW                8
#define SERIES_STR_BUFF            9
#define SERIES_SNARE               10
#define SERIES_BLADETURN           11
#define SERIES_ABSORB                   12
#define SERIES_BLIND                    13
#define SERIES_WISDOM_BUFF              14
#define SERIES_REGEN_HP                 15
#define SERIES_AC_BUFF                  16
#define SERIES_ACID_RESIST              17
#define SERIES_FIRE_RESIST              18
#define SERIES_COLD_RESIST              19
#define SERIES_ENERGY_RESIST            20
#define SERIES_CHARISMA_BUFF            21
#define SERIES_DEXTERITY_BUFF           22
#define SERIES_STRENGTH_BUFF            23
#define SERIES_INTELLIGENCE_BUFF        24
#define SERIES_CHARM                    25
#define SERIES_DAMAGE_BUFF              26
#define SERIES_SELF_AC_BUFF             27
#define SERIES_DISTRACT                 28
#define SERIES_CURSE                    29
#define SERIES_WEAKEN                   30
#define SERIES_ROOT                     31
#define SERIES_PET_BUFF                 32
#define SERIES_CONVERT_HP_TO_MANA       33
#define SERIES_AC_TAP                   34
#define SERIES_HITROLL_BUFF             35
#define SERIES_NEGATIVE_DOT             36
#define SERIES_CLERIC_FAITH             37
#define SERIES_BASE_HIT_BUFF            38
#define SERIES_RAGE_STRENGTH            39
#define SERIES_DISPEL_UNDEAD            40
#define SERIES_SPIRIT_RESIST_DEBUFF     41
#define SERIES_SPIRIT_RESIST_BUFF       42
#define SERIES_DISEASE_RESIST_BUFF      43
#define SERIES_POISON_RESIST_BUFF       44
#define SERIES_STUN                     45
#define SERIES_SPIRIT_DOT               46
#define SERIES_SAVES_DEBUFF             47
#define SERIES_REGEN_STAMINA            48
#define SERIES_DISEASE_DOT              49
#define SERIES_POISON_DOT               50
#define SERIES_HP_BUFF                  51
#define SERIES_HITROLL_POSTCURVE        52
#define SERIES_HITROLL_DEBUFF			54
#define SERIES_RESIST_DEBUFF			55
#define SERIES_FIRE_RESIST_BUFF			56
#define SERIES_COLD_RESIST_BUFF			57
#define SERIES_AC_DEBUFF				58
#define SERIES_FLY						59
#define SERIES_WATER_BREATH				60
#define SERIES_INVISIBILITY				61
#define SERIES_STAMINA_BUFF				62
#define SERIES_FIRE_DOT					63
#define SERIES_PIERCE_DOT				64
#define SERIES_WEAK						65
#define SERIES_MESMERIZE				66
#define SERIES_CALL_TO_ARMS				67
#define SERIES_INT_WIS_BUFF				68
#define SERIES_LIFE_TAP					69
#define SERIES_SOUND_NUKE				70
#define SERIES_SNAKE_VENOM				71
#define SERIES_AMPHIBIAN_VENOM			72
#define SERIES_SPIDER_VENOM				73
#define SERIES_PLANT_VENOM				74
#define SERIES_SCORPION_VENOM			75
#define SERIES_LIZARD_VENOM				76
#define SERIES_INSECT_VENOM				77
#define SERIES_WILLPOWER_BUFF			78
#define SERIES_REFLEX_BUFF				79
#define SERIES_FORTITUDE_BUFF 			80
#define SERIES_NATURAL_VENOM			81
#define SERIES_WEAPON_SKILL				82
#define SERIES_DEFENSE_SKILL			83
#define SERIES_HP_TRANSFER				84
#define SERIES_HP_TO_AC					85
#define SERIES_SHADOWBEAST				86
#define SERIES_SWAMP_GAS				87
#define SERIES_CONSECRATE				88
#define SERIES_DEATH_KNELL				89
#define SERIES_BLEEDING					90
#define SERIES_POSITIONING				91
#define SERIES_PAIN						92
#define SERIES_INVIS					93
#define SERIES_ACID_DOT					94
#define SERIES_HEAT_METAL				95
#define SERIES_POIS_DISEASE_BUFF		96
#define SERIES_FIRE_ICE_BUFF			97
#define SERIES_SAVES_BUFF				98
#define SERIES_MANA_REGEN				99
#define SERIES_BARD_HERO				100
#define SERIES_ENCHANT_ARMOR			101
#define SERIES_ENCHANT_WEAPON			102
#define SERIES_REGROWTH					103
#define SERIES_PHANTASMAL_GUARD			104

#define SERIES_BLESSING     1000
#define SERIES_MAGE_ARMOR   1001
#define SERIES_FRIENDS      1002
#define SERIES_SHAMAN_STR   1003
#define SERIES_SHAMAN_DEX   1004
#define SERIES_SHAMAN_CON   1005
#define SERIES_DIVINE_FAVOR 1006
#define SERIES_HOLY_ARMOR   1008
#define SERIES_COURAGE      1009
#define SERIES_GIANT_STRENGTH   1010
#define SERIES_BARKSKIN     1011
#define SERIES_DAMAGE_SHIELD    1012
#define SERIES_ENDURE_FIRE  1013
#define SERIES_ENDURE_COLD  1014
#define SERIES_ENDURE_DISEASE   1015
#define SERIES_ENDURE_POISON    1016
#define SERIES_SWARM        1017
#define SERIES_CAMOUFLAGE   1018
#define SERIES_DIVINE_IMMUNITY  1019

#endif /* series_h */
