#ifndef skills_h
#define skills_h

#define MAX_IN_GROUP                      30

/*
    Skill/spell reuse structure
 */
struct _reuse_wait
{
    Reuse_wait *        next;
    int                 timer;
    int                 type;
    sh_int              gsn;
};

struct prof_type
{
    char *    name;
    sh_int    class_avail[MAX_CLASS];
    sh_int    gain_cost[MAX_CLASS];
    sh_int *  pgpn;
    sh_int *  prereq;
    sh_int    practice_cost;
};

struct skill_type
{
    char *          name;            /* Name of skill        */
    sh_int          skill_level[MAX_CLASS];    /* Level needed by class    */
    sh_int          gain_cost[MAX_CLASS];    /* Cost for class to gain it */
    SpellFun *      spell_fun;        /* Spell pointer (for spells)    */
    sh_int          target;            /* Legal targets        */
    sh_int          minimum_position;    /* Position for caster / user    */
    sh_int *        pgsn;            /* Pointer to associated gsn    */
    sh_int          min_mana;        /* Minimum mana used        */
    sh_int          beats;            /* Waiting time after use    */
    char *          noun_damage;        /* Damage message        */
    char *          msg_off;        /* Wear off message        */
    char *          msg_obj;        /* Wear off message for obects    */
    int             type;
    sh_int *        prereq;            /* prereq skill if requipred */
    long            flags;
};

struct group_type
{
    char *    name;
    char *    spells[MAX_IN_GROUP];
};

struct venom_type
{
    char *      race;
    int         vnum;
    int         frequency;
};

#define MAX_SKILL                        150
#define MAX_PROFICIENCY                  100
#define MAX_GROUP                         30

#define SKILL_NO_REUSE_ALERT        (A)
#define SKILL_SPELL_GROUP           (B)
#define SKILL_SECONDARY             (C)

#define SKILL_TRADE         0
#define SKILL_FALSE         1
#define SKILL_WEAPON        2
#define SKILL_GENERAL       3
#define SKILL_FOUNDATION    4

#define GET_WEAPON_SN           1
#define GET_OFFHAND_SN          2
#define GET_RANGED_SN           3

/*
 * These are skill_lookup return values for common skills and spells.
 */
extern sh_int gpn_marksmanship_1;
extern sh_int gpn_marksmanship_2;
extern sh_int gpn_marksmanship_3;
extern sh_int gpn_marksmanship_4;
extern sh_int gpn_marksmanship_5;

extern sh_int gpn_elusive_1;
extern sh_int gpn_elusive_2;
extern sh_int gpn_elusive_3;
extern sh_int gpn_elusive_4;
extern sh_int gpn_elusive_5;

extern sh_int gpn_craftsmanship_1;
extern sh_int gpn_craftsmanship_2;
extern sh_int gpn_craftsmanship_3;
extern sh_int gpn_craftsmanship_4;
extern sh_int gpn_craftsmanship_5;

extern sh_int gpn_meditation_1;
extern sh_int gpn_meditation_2;
extern sh_int gpn_meditation_3;
extern sh_int gpn_meditation_4;
extern sh_int gpn_meditation_5;

extern sh_int gpn_regeneration_1;
extern sh_int gpn_regeneration_2;
extern sh_int gpn_regeneration_3;
extern sh_int gpn_regeneration_4;
extern sh_int gpn_regeneration_5;

extern sh_int gpn_pack_mule;

extern sh_int gpn_tireless_1;
extern sh_int gpn_tireless_2;
extern sh_int gpn_tireless_3;
extern sh_int gpn_tireless_4;
extern sh_int gpn_tireless_5;

extern sh_int gsn_mining;
extern sh_int gsn_shapeshifting;
extern sh_int gsn_chicanery;
extern sh_int gsn_concentration;
extern sh_int gsn_quick_cast;
extern sh_int gpn_bestiary;
extern sh_int gpn_monk_skill;
extern sh_int gpn_concentration;
extern sh_int gpn_improved_shield;
extern sh_int gpn_improved_shield_2;

extern sh_int gsn_paeans;

extern sh_int gsn_double_strike;
extern sh_int gsn_first_aid;
extern sh_int gpn_weapon_finesse;
extern sh_int gpn_endurance;
extern sh_int gpn_protect;
extern sh_int gpn_guard;
extern sh_int gpn_intercept;
extern sh_int gsn_lay_on_hands;
extern sh_int gpn_tracking;
extern sh_int gpn_backstab;

extern sh_int gpn_silent_casting;
extern sh_int gpn_shield_usage;
extern sh_int gpn_blind_fighting;
extern sh_int gpn_combat_casting;
extern sh_int gpn_critical_casting;
extern sh_int gpn_mounted_casting;
extern sh_int gpn_mounted_combat;
extern sh_int gpn_swimming;
extern sh_int gpn_two_weapon_fighting;
extern sh_int gpn_combat_casting;
extern sh_int gpn_weapon_finesse;
extern sh_int gpn_alertness;
extern sh_int gpn_enhanced_damage;
extern sh_int gpn_savagery;
extern sh_int gpn_enhanced_critical;
extern sh_int gpn_superior_critical;
extern sh_int gpn_improved_critical;
extern sh_int gpn_cloth_armor;
extern sh_int gpn_leather_armor;
extern sh_int gpn_studded_leather_armor;
extern sh_int gpn_chain_mail_armor;
extern sh_int gpn_scale_mail_armor;
extern sh_int gpn_plate_mail_armor;
extern sh_int gpn_buckler_shields;
extern sh_int gpn_small_shields;
extern sh_int gpn_medium_shields;
extern sh_int gpn_large_shields;

extern sh_int gsn_amelioration;
extern sh_int gsn_augmentation;
extern sh_int gsn_benediction;
extern sh_int gsn_destruction;
extern sh_int gsn_detection;
extern sh_int gsn_deterioration;
extern sh_int gsn_maladiction;
extern sh_int gsn_nature;
extern sh_int gsn_protection;
extern sh_int gsn_rejuvenation;
extern sh_int gsn_supression;
extern sh_int gsn_transportation;
extern sh_int gsn_spirituality;

extern sh_int gsn_percussion;
extern sh_int gsn_strings;
extern sh_int gsn_winds;
extern sh_int gsn_vocal;

extern sh_int gsn_abjuration;
extern sh_int gsn_alteration;
extern sh_int gsn_conjuration;
extern sh_int gsn_divination;
extern sh_int gsn_enchantment;
extern sh_int gsn_evocation;
extern sh_int gsn_illusion;
extern sh_int gsn_necromancy;
extern sh_int gsn_nethermancy;

extern sh_int gsn_thaumaturgy;
extern sh_int gsn_theology;
extern sh_int gsn_encumbered;
extern sh_int gsn_recall;

extern sh_int gsn_apothecary;
extern sh_int gsn_brewing;
extern sh_int gsn_cooking;
extern sh_int gsn_armorsmithing;
extern sh_int gsn_fletching;
extern sh_int gsn_jewelcraft;
extern sh_int gsn_pottery;
extern sh_int gsn_weaponsmithing;
extern sh_int gsn_tailoring;
extern sh_int gsn_spellcrafting;

extern sh_int gsn_woodworking;
extern sh_int gsn_metalworking;
extern sh_int gsn_leatherworking;
extern sh_int gsn_stoneworking;
extern sh_int gsn_clothworking;

extern sh_int gsn_oration;
extern sh_int gsn_backstab;
extern sh_int gsn_dodge;
extern sh_int gsn_envenom;
extern sh_int gsn_unarmed_combat;
extern sh_int gsn_instruments;
extern sh_int gsn_kirijutsu;
extern sh_int gsn_dual_wield;
extern sh_int gsn_stealth;

// Thief Skills 2.0
extern sh_int gsn_open_lock;    // Thieves, bards
extern sh_int gsn_traps;        // Thieves, assassins
extern sh_int gsn_pick_pocket;  // Thieves
extern sh_int gsn_stealth;      // Thieves, assassins, rangers

// Thief abilities
extern sh_int gsn_case;         // Thief only
extern sh_int gsn_appraise;     // gainable by all, thief default
extern sh_int gsn_climb;        // gainable by all, thief default
extern sh_int gsn_safe_fall;    // thief/monk

extern sh_int gsn_disarm;
extern sh_int gsn_enhanced_damage;
extern sh_int gsn_kick;
extern sh_int gsn_parry;
extern sh_int gsn_rescue;
extern sh_int gsn_intercept;
extern sh_int gsn_guard;
extern sh_int gsn_double_attack;
extern sh_int gsn_second_attack;
extern sh_int gsn_third_attack;

/* new gsns */
extern sh_int gsn_axe;
extern sh_int gsn_thrusting_shortblades;
extern sh_int gsn_thrusting_longblades;
extern sh_int gsn_1h_concussion;
extern sh_int gsn_2h_concussion;;
extern sh_int gsn_polearm;
extern sh_int gsn_whip;
extern sh_int gsn_staff;
extern sh_int gsn_shield_block;
extern sh_int gsn_spear;
extern sh_int gsn_slashing_shortblades;
extern sh_int gsn_slashing_longblades;
extern sh_int gsn_crossbow;
extern sh_int gsn_shortbow;
extern sh_int gsn_longbow;
extern sh_int gsn_composite_longbow;

extern sh_int gsn_bash;
extern sh_int gsn_berserk;
extern sh_int gsn_dirt;
extern sh_int gsn_hand_to_hand;
extern sh_int gsn_legsweep;
extern sh_int gsn_palmattack;
extern sh_int gsn_mending;
extern sh_int gsn_paralyze;
extern sh_int gsn_precognition;
extern sh_int gsn_kistrike;
extern sh_int gsn_firewithin;
extern sh_int gsn_purge;
extern sh_int gsn_pall;
extern sh_int gsn_trip;

extern sh_int gsn_fast_healing;
extern sh_int gsn_haggle;
extern sh_int gsn_lore;
extern sh_int gsn_meditation;

extern sh_int gsn_scrolls;
extern sh_int gsn_staves;
extern sh_int gsn_wands;
extern sh_int gsn_recall;

extern sh_int gsn_channeling;

extern sh_int gsn_offense;
extern sh_int gsn_defense;

extern sh_int gpn_pack_mule;

extern int gsn_mind;
extern int gsn_body;
extern int gsn_spirit;

extern const struct venom_type      venom_table [];
extern const struct prof_type       prof_table[MAX_PROFICIENCY];
extern const struct skill_type      skill_table[MAX_SKILL];
extern const struct group_type      group_table[MAX_GROUP];

#endif /* skills_h */
