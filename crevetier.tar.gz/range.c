/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "thoc.h"
#include "recycle.h"
#include "interp.h"
#include "tables.h"
#include "styles.h"
#include "options.h"

Object *findAmmo( Character *ch, bool fPull );
bool isAmmoFor( Object *ammo, int gsn );
Character *get_char_direction( Character *ch, char *argument, int dir, int range );
Character *get_char_direction2( Character *ch, Character *victim, int dir, int range );
int     modifyDamageForSkill( int dam, int ratio );

void do_aim( Character *ch, char *argument )
{
	Object *weapon, *ammo;
	Character *victim = NULL;
	char arg[MAX_INPUT_LENGTH];
	int dir, range, wait, redux;
    Firing *firing;

	argument = one_argument( argument, arg );

	if ( arg[0] == '\0' || *argument == '\0' )
	{
		cprintf(ch,"Syntax:   aim <direction> <victim_name>\n\r");
		return;
	}

	if ( (weapon = get_eq_char( ch, WEAR_RANGED )) == NULL )
	{
		cprintf(ch,"You cannot aim any ranged or thrown weapons - you don't have one equipped!\n\r");
		return;
	}

    /* Ok, we've got a valid target, do we actually have any ammmo? */
    if ( (ammo = findAmmo(ch,FALSE)) == NULL )
    {
        cprintf(ch,"You're out of ammo!\n\r");
        return;
    }

	/* have weapon, find victim */
	switch( arg[0] )
	{
		case 'n': case 'N': dir = DIR_NORTH; break;
		case 'e': case 'E': dir = DIR_EAST; break;
		case 'w': case 'W': dir = DIR_WEST; break;
		case 's': case 'S': dir = DIR_SOUTH; break;
		default:
			cprintf(ch,"You can only fire to the north, south, east, and west.\n\r");
			return;
	}

	range = weapon->value[6];
	if ( !ch->in_room->exit[dir] )
	{
		cprintf(ch,"There's no exit in that direction!\n\r");
		return;
	}

	if ( (victim = get_char_direction(ch,argument,dir,range)) == NULL )
	{
		cprintf(ch,"No such target in range in that direction.\n\r");
		return;
	}

    if ( is_safe(ch, victim) )
    {
        act("$N is safe from you.",ch,NULL,victim,TO_CHAR);
        return;
    }

	/* Ok, we've got ammo, we've got a target, figure out the "draw" time */
	/* You fire a tenth of a second faster per 5 points of dex over 100 */
	/* Caps at a 33% overall speed improvement */
	wait = weapon->value[5];
	redux = UMAX(0,(get_curr_stat(ch,STAT_DEX)-100)/5);
	redux = UMIN(redux,wait/3);
	wait -= redux;

	actprintf(ch,weapon,NULL,TO_CHAR,"You draw $p and aim %s.",dir_name[dir]);
	actprintf(ch,weapon,ammo,TO_ROOM,"$n draws $p and aims %s.",dir_name[dir]);

    firing              = new_firing_data( );
    firing->victim      = victim;
    firing->direction   = dir;
    firing->ammo        = ammo;
    firing->range       = range;
    ch->firing          = firing;

	WAIT_STATE(ch,wait);
	SET_BIT(ch->act,PLR_IS_FIRING);
	return;
}

Object *findAmmo( Character *ch, bool fPull )
{
	Object *quiver;
	Object *weapon = get_eq_char(ch,WEAR_RANGED);
	Object *ammo;
	int *gsn;

	if ( !weapon )
		return NULL;

    gsn = weapon_table[get_weapon_index(weapon->value[0])].gsn;

	/* Check all worn quivers for ammo */
	for( quiver = ch->carrying; quiver; quiver = quiver->next_content )
	{
		if ( quiver->wear_loc == -1 || 
             quiver->item_type != ITEM_CONTAINER || 
             !IS_SET(quiver->value[0],CONT_QUIVER) 
           )
			continue;
		else
		{
			Object *ammo;

			for( ammo = quiver->contains; ammo; ammo = ammo->next_content )
			{
				if ( isAmmoFor( ammo, *gsn ) )
				{
					if ( fPull )
						obj_from_obj( ammo );
					return ammo;
				}
			}
		}
	}

    /* Check all carried quivers for ammo */
    for( quiver = ch->carrying; quiver; quiver = quiver->next_content )
    {
        if ( quiver->item_type != ITEM_CONTAINER ||
             !IS_SET(quiver->value[0],CONT_QUIVER)
           )
            continue;
        else
        {
            Object *ammo;

            for( ammo = quiver->contains; ammo; ammo = ammo->next_content )
            {
                if ( isAmmoFor( ammo, *gsn ) )
                {
                    if ( fPull )
                        obj_from_obj( ammo );
                    return ammo;
                }
            }
        }
    }

	/* Check all carried items */
	for( ammo = ch->carrying; ammo; ammo = ammo->next_content )
	{
		if ( isAmmoFor( ammo, *gsn ) )
		{
			if ( fPull )
				obj_from_char( ammo );
			return ammo;
		}
	}
		
	return NULL;
}

bool isAmmoFor( Object *ammo, int gsn )
{
	if ( ammo->item_type != ITEM_PROJECTILE )
		return FALSE;

	if ( gsn == gsn_crossbow && IS_SET(ammo->value[0],RANGE_CROSSBOW) )
		return TRUE;
	if ( gsn == gsn_shortbow && IS_SET(ammo->value[0],RANGE_SHORTBOW) )
		return TRUE;
	if ( gsn == gsn_longbow && IS_SET(ammo->value[0],RANGE_LONGBOW) )
		return TRUE;
	if ( gsn == gsn_composite_longbow && IS_SET(ammo->value[0],RANGE_COMPOSITE_LONGBOW) )
		return TRUE;

	return FALSE;
}

bool validateTarget( Character *ch, Character *victim, int dir, int range )
{
    if ( (victim = get_char_direction2(ch,victim,dir,range)) == NULL )
        return FALSE;

    return TRUE;
}

void fireWeapon( Character *ch )
{
	Character *victim;
	Object *weapon, *ammo;
    Room *room, *save, *lastRoom;
    Exit *pexit, *pback;
    int dir, range, i, victim_ac;
    int sn, skill, tohit, topDiceRange;
    int dt, dam_type, dam;

    if ( ch->firing == NULL )
    {
        log_bug("No firing data!");
        return;
    }

    victim = ch->firing->victim;
    dir    = ch->firing->direction;
    range  = ch->firing->range;
    ammo   = ch->firing->ammo;

	if ( (weapon = get_eq_char(ch,WEAR_RANGED)) == NULL )
	{
		cprintf(ch,"What happened to your weapon?\n\r");
		return;
	}

    dt = TYPE_HIT;
    if ( weapon->item_type != ITEM_WEAPON )
    {
        cprintf(ch,"You can't fire something without a weapon!\n\r");
        return;
    }

    dt += weapon->value[3];
    dam_type = attack_table[weapon->value[3]].damage;

    if (dam_type == -1)
        dam_type = DAM_PIERCE;


    // Get weapon skill
    sn = get_weapon_sn( ch, GET_RANGED_SN );

	if ( !validateTarget( ch, victim, dir, range ) )
	{
		cprintf(ch,"&R*** Your target is no longer in range or line-of-sight.&x\n\r");
		return;
	}

	act("You fire $p at $N.",ch,weapon,victim,TO_CHAR);
	act("$n fires $p.",ch,weapon,NULL,TO_ROOM);
    act("You hear the twang of a bow string from $D.",ch,NULL,NULL,TO_RADIUS);

	// Show projectile flying in intermediate rooms
    save        = ch->in_room;
    lastRoom    = ch->in_room;
    pexit       = save->exit[dir];
    room        = pexit->u1.to_room;
    ch->in_room = room;

    for( i=0 ; i < range ; i++ )
    {
        if( char_is_in_room(ch->in_room,victim) )
            break;

        if( (pexit = room->exit[dir]) == NULL )
            break;

        actprintf(ch,ammo,NULL,TO_ROOM,"$p whistles past you going from %s to %s.",
            dir_name[rev_dir[dir]], dir_name[dir] );

        lastRoom = room;
        if ( (room = pexit->u1.to_room) == NULL )
            break;

        if ( (pback = room->exit[rev_dir[dir]]) == NULL )
            break;

        if ( pback->u1.to_room != lastRoom )
            break;

        if ( room == lastRoom )
            break;

        ch->in_room = room;
    }

    ch->in_room = save;

	// Hit target
    sn = get_weapon_sn(ch,GET_RANGED_SN);
    skill = get_weapon_skill(ch,sn);
    tohit = ch->level + (skill*4);
    tohit = get_curr_stat(ch,STAT_DEX)-100/2;

    // Randomness
    if ( ch->level <= 30 )
        topDiceRange = (ch->level*5)+50;
    else
        topDiceRange = (int)(((float)(ch->level-30))*2.5)+200;

    tohit += dice(1,topDiceRange);
    tohit += GET_HITROLL(ch);
    tohit = (100+(getAbilitySeries(ch,"marksmanship")*6))*tohit/100;

    // Apply RAW AC only - no dex bonus 
    // Some arrows may have different damage types
    switch( attack_table[ammo->value[3]].damage )
    {
        case(DAM_PIERCE): victim_ac = GET_AC(victim,AC_PIERCE); break;
        case(DAM_BASH):   victim_ac = GET_AC(victim,AC_BASH);   break;
        case(DAM_SLASH):  victim_ac = GET_AC(victim,AC_SLASH);  break;
        default:          victim_ac = GET_AC(victim,AC_EXOTIC); break;
    }

    // Hard to hit somebody in combat
    if ( victim->position == POS_FIGHTING )
        tohit /= 2;
    else
    if ( victim->position <= POS_FIGHTING )
        victim_ac /= 2;

    if ( tohit < victim_ac )
    {
        actprintf(victim,ammo,NULL,TO_ROOM,"$p, incoming from the %s, just misses $n.",dir_name[rev_dir[dir]]);
        actprintf(victim,ammo,NULL,TO_CHAR,"$p, incoming from the %s, just misses you.",dir_name[rev_dir[dir]]);
        damage( ch, victim, 0, dt, dam_type, DF_SHOW | DF_RANGED ); 
        obj_from_char( ammo );
        obj_to_room( ammo, victim->in_room );
        return;
    }

    // Calculate damage
    dam = dice(weapon->value[1],weapon->value[2]) * dice(ammo->value[1],ammo->value[2]);
    if (IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"Base damage roll %d\n\r", dam);
    
    /* Adjust for level difference */
    dam += URANGE(-100,applyLevelDifference(ch->level,victim->level),100) / 2;
    if (IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"Modified for level %d\n\r", dam);

    /* Adjust for object condition */
    dam = modForCondition( weapon, dam );
    if (IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"Modified for condition roll %d\n\r", dam);

    /* Adjust for skill *
     * 0 = 10%
     * 10% of level = 25%
     * interpolate from 10::25 to 75::100 and from 75::100 to 100:110
     */
    dam = modifyDamageForSkill( dam, skill*100/ch->level );
    if (IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"Modified for skill %d\n\r", dam);

    dam = dam * (100 + getAbilitySeries(ch,"marksmanship")*6) / 100;
    if (IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"Modified for marksmanship %d\n\r", dam);
    // Handle damage
    actprintf(victim,ammo,NULL,TO_ROOM,"$p, incoming from the %s, impacts $n.",dir_name[rev_dir[dir]]);
    actprintf(victim,ammo,NULL,TO_CHAR,"$p, incoming from the %s, impacts you!",dir_name[rev_dir[dir]]);

    damage( ch, victim, dam, dt, dam_type, DF_SHOW | DF_RANGED );

    // each strike can weaken the arrow - 25% chance
    if ( dice(1,4) == 1 )
        ammo->condition--;

    obj_from_char( ammo );

    // todo: We have to deal here with fatal damage, the victim may be a corpse now!
    obj_to_char( ammo, victim );

	// For NPCs, set up pursuit pathing if that shot didn't kill 'em
    if ( IS_NPC(victim) && victim->in_room != NULL && victim->pursuit.index == 0 )
    {
        // Queue 'em up, this part sucks
        // Start in the room the victim is in and go backwards.
        Room *room;
        Exit *pexit;
        int total;

        if ( (room = ch->in_room) == NULL )
        {
            log_bug("could not find room that ranged victim is in");
            return;
        }

        if ( (pexit = room->exit[dir]) == NULL )
        {
            log_bug("could not find exit in ranged victim's room");
            return;
        }

        victim->pursuit.array[victim->pursuit.index++] = room->vnum;
        // Go one room back towards the shooter
        if ( (room = pexit->u1.to_room) == NULL )
        {
            log_bug("could not back up 1 room");
            return;
        }

        total = 0;
        while( room != victim->in_room && total++ <= range && victim->pursuit.index < MAX_STACK )
        {
            victim->pursuit.array[victim->pursuit.index++] = room->vnum;
            if ( (pexit = room->exit[dir]) == NULL )
            {
                log_bug("could not find exit in ranged victim's room");
                return;
            }

            if ( (room = pexit->u1.to_room) == NULL )
            {
                log_bug("could not find exit in ranged victim's room");
                return;
            }
        }
    }
    return;
}

// Cheap ANSI C overloading
Character *get_char_direction2( Character *ch, Character *victim, int dir, int range )
{
	Room *room, *lastRoom, *save;
	Exit *pexit, *pback;
	int i;

    save = ch->in_room;
    lastRoom = ch->in_room;
    if ( (pexit = save->exit[dir]) == NULL )
        return NULL;

 	if ( (room = pexit->u1.to_room) == NULL )
        return NULL;

    ch->in_room = room;
    
    for( i=0 ; i< range ; i++ )
    {
        if( char_is_in_room(ch->in_room,victim) )
            break;
     
        if( (pexit = room->exit[dir]) == NULL )
            break;
     
        lastRoom = room;
        if ( (room = pexit->u1.to_room) == NULL )
            break;
        
        if ( (pback = room->exit[rev_dir[dir]]) == NULL )
            break;

        if ( pback->u1.to_room != lastRoom )
            break;
     
        if ( room == lastRoom )
            break;

        ch->in_room = room;
    }

    ch->in_room = save;
	return i < range ? victim : NULL;
}

Character *get_char_direction( Character *ch, char *argument, int dir, int range )
{
	Room *room, *lastRoom, *save;
	Exit *pexit, *pback;
	int i;
	Character *victim = NULL;

    save = ch->in_room;
    lastRoom = ch->in_room;
    pexit = save->exit[dir];
 	room = pexit->u1.to_room;
    ch->in_room = room;
    
    for( i=0 ; i< range ; i++ )
    {
        if( (victim = get_char_room(ch,argument)) != NULL )
            break;
     
        if( (pexit = room->exit[dir]) == NULL )
            break;
     
        lastRoom = room;
        if ( (room = pexit->u1.to_room) == NULL )
            break;
        
        if ( (pback = room->exit[rev_dir[dir]]) == NULL )
            break;

        if ( pback->u1.to_room != lastRoom )
            break;
     
        if ( room == lastRoom )
            break;

        ch->in_room = room;
    }

    ch->in_room = save;
	return victim;
}
