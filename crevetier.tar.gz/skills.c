/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,	   *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *									   *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael	   *
 *  Chastain, Michael Quan, and Mitchell Tse.				   *
 *									   *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc	   *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.						   *
 *									   *
 *  Much time and thought has gone into this software and you are	   *
 *  benefitting.  We hope that you share your changes too.  What goes	   *
 *  around, comes around.						   *
 ***************************************************************************/
 
/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#if defined(macintosh)
#include <types.h>
#include <time.h>
#else
#include <sys/types.h>
#include <sys/time.h>
#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "recycle.h"
#include "tables.h"
#include "options.h"

Character *createShifted( Character *ch, int vnum, int skill );
int getFib( int which );
int weaponProfAdj( Character *ch, int fDual );

/* used to get new skills */
void do_gain(Character *ch, char *argument)
{
    char arg[MAX_INPUT_LENGTH];
    Character *trainer;
    int sn = 0;

    if (IS_NPC(ch))
	{
		cprintf(ch,"Foolish NPC!\n\r");
		return;
	}

    /* find a trainer */
    for ( trainer = ch->in_room->people; trainer != NULL; trainer = trainer->next_in_room)
		if (IS_NPC(trainer) && IS_SET(trainer->act,ACT_TRAIN))
	    	break;

    if (trainer == NULL || !can_see(ch,trainer))
    {
		cprintf(ch,"You must be near a <Gain> trainer to gain new skills.\n\r");
		return;
    }

    one_argument(argument,arg);

    if (arg[0] == '\0')
    {
		do_function(trainer, &do_say, "You can &Wlist&x the available skills, or just gain them.");
		return;
    }

    if (!str_prefix(arg,"list"))
    {
		int col;

		col = 0;
		cprintf(ch," === SKILLS ===\n\r");
		cprintf(ch," [Lv] [SP] %-24s  [Lv] [SP] %-24s\n\r", "Skill", "Skill" );
        cprintf(ch," ---- ---- %-24s  ---- ---- %-24s\n\r",
                   "------------------------", "------------------------");
        for (sn = 0; sn < MAX_SKILL; sn++)
        {
            if (skill_table[sn].name == NULL)
                break;
 
            if (!ch->pcdata->learned[sn]
	    	&&  skill_table[sn].type != SKILL_FALSE
			&&  skill_table[sn].gain_cost[ch->class] > 0 )
            {
				cprintf(ch," [&g%2d&x] [&g%2d&x] &W%-24s&x  ", 
					skill_table[sn].skill_level[ch->class],
					skill_table[sn].gain_cost[ch->class],
					skill_table[sn].name);
                if (++col % 2 == 0)
					cprintf(ch,"\n\r");
            }
        }
        if (col % 2 != 0)
       		cprintf(ch,"\n\r");


		cprintf(ch,"\n\r === ABILITIIES ===\n\r");
		cprintf(ch," [Lv] [SP] %-24s  [Lv] [SP] %-24s\n\r",
                   "Ability", "Ability" );
        cprintf(ch," ---- ---- %-24s  ---- ---- %-24s\n\r",
                   "------------------------", "------------------------");
		col = 0;

		for(sn = 0 ; sn < MAX_PROFICIENCY ; sn++)
		{
            if (prof_table[sn].name == NULL)
                break;

            if (prof_table[sn].prereq != NULL &&
                !HAS_PROF(ch,*prof_table[sn].prereq))
                continue;

            if (!ch->pcdata->profs[sn] && prof_table[sn].gain_cost[ch->class] > 0 )
            {
                cprintf(ch," [&g%2d&x] [&g%2d&x] &W%-24s&x ", 
					prof_table[sn].class_avail[ch->class],
					prof_table[sn].gain_cost[ch->class], 
					prof_table[sn].name);

                if (++col % 2 == 0)
                    cprintf(ch,"\n\r");
            }
        }


		cprintf(ch,"You have %d specialization points available.\n\r", 
						ch->pcdata->spec_points );
		return;
    }

    sn = skill_lookup(argument);
    if (sn > -1 && skill_table[sn].type != SKILL_FALSE )
    {
        if ( skill_table[sn].gain_cost[ch->class] <= 0 )
		{
			act("$N tells you 'You cannot gain that skill.'",ch,NULL,trainer,TO_CHAR);
			return;
		}

        if (ch->pcdata->learned[sn])
        {
            act("$N tells you 'You already know that skill!'", ch,NULL,trainer,TO_CHAR);
            return;
        }

		if ( ch->pcdata->spec_points < skill_table[sn].gain_cost[ch->class] )
		{
			act("$N tells you 'You are short on specialization points.",ch,NULL,trainer,TO_CHAR); 
			return;
		}

        /* add the skill */
		ch->pcdata->learned[sn] = 1;
		ch->pcdata->spec_points -= skill_table[sn].gain_cost[ch->class];
        act("$N trains you in the art of $t", ch,skill_table[sn].name,trainer,TO_CHAR);
        return;
    }

	sn = proficiency_lookup(argument);
	if ( sn > - 1)
	{
		if ( prof_table[sn].gain_cost[ch->class] <= 0 )
		{
			act("$N tells you 'You cannot learn that ability.'",ch,NULL,trainer,TO_CHAR);
			return;
		}

        if (ch->pcdata->profs[sn])
        {
            act("$N tells you 'You already know that ability!'",
                ch,NULL,trainer,TO_CHAR);
            return;
        }

		if ( ch->pcdata->spec_points < prof_table[sn].gain_cost[ch->class] )
		{
			act("$N tells you 'You are short on specialization points.",ch,NULL,trainer,TO_CHAR); 
			return;
		}

        // Do you have the prerequisite
        if ( prof_table[sn].prereq != NULL &&
             !HAS_PROF(ch,*prof_table[sn].prereq) )
        {
            cprintf(ch,"You must have %s to learn this ability.\n\r",
                prof_table[ *prof_table[sn].prereq ].name );
            return;
        }

        /* add the ability */
		ch->pcdata->profs[sn] = 1;
		ch->pcdata->spec_points -= prof_table[sn].gain_cost[ch->class];
        act("$N trains you in the art of $t", ch,prof_table[sn].name,trainer,TO_CHAR);
        return;
	}

    act("$N tells you 'I do not understand...'",ch,NULL,trainer,TO_CHAR);
}
    



/* RT spells and skills show the players spells (or skills) */

void do_spells(Character *ch, char *argument)
{
    Buffer *buffer;
    char arg[MAX_INPUT_LENGTH];
    char spell_list[LEVEL_HERO + 1][MAX_STRING_LENGTH];
    char spell_columns[LEVEL_HERO + 1];
    int sn, level, min_lev = 1, max_lev = LEVEL_HERO, mana;
    bool fAll = FALSE, found = FALSE;
    char buf[MAX_STRING_LENGTH];
	int nMatch = 0;
	SpellIndex* pSpellIndex;
 
    if (IS_NPC(ch))
	{
		cprintf(ch,"You're an NPC!\n\r");
      	return;
	}

    if (argument[0] != '\0')
    {
	fAll = TRUE;

	if (str_prefix(argument,"all"))
	{
	    argument = one_argument(argument,arg);
	    if (!is_number(arg))
	    {
		send_to_char("Arguments must be numerical or all.\n\r",ch);
		return;
	    }
	    max_lev = atoi(arg);

	    if (max_lev < 1 || max_lev > LEVEL_HERO)
	    {
		sprintf(buf,"Levels must be between 1 and %d.\n\r",LEVEL_HERO);
		send_to_char(buf,ch);
		return;
	    }

	    if (argument[0] != '\0')
	    {
		argument = one_argument(argument,arg);
		if (!is_number(arg))
		{
		    send_to_char("Arguments must be numerical or all.\n\r",ch);
		    return;
		}
		min_lev = max_lev;
		max_lev = atoi(arg);

		if (max_lev < 1 || max_lev > LEVEL_HERO)
		{
		    sprintf(buf,
			"Levels must be between 1 and %d.\n\r",LEVEL_HERO);
		    send_to_char(buf,ch);
		    return;
		}

		if (min_lev > max_lev)
		{
		    send_to_char("That would be silly.\n\r",ch);
		    return;
		}
	    }
	}
    }


    /* initialize data */
    for (level = 0; level < LEVEL_HERO + 1; level++)
    {
        spell_columns[level] = 0;
        spell_list[level][0] = '\0';
    }
 
    for ( sn = 0; nMatch < top_spell_index; sn++ )
	{
		if ( ( pSpellIndex = get_spell_index( sn ) ) != NULL )
		{
			nMatch++;

			if ((level = pSpellIndex->class_level[ch->class]) < LEVEL_HERO + 1
			&&  (fAll || level <= ch->level)
			&&  level >= min_lev && level <= max_lev
			&&  pSpellIndex->spell_fun != NULL
			&&  ch->pcdata->spells[sn] > 0)
			{
				char color_code = 'x';

				/* Determine color code, what it should be */
                if ( HAS_COLOROPT(ch, COLOR_SPELLS) )
                {
                    if( class_table[ch->class].group == DIVINE &&
                        str_cmp(class_table[ch->class].name,"paladin"))
                    {
				        int 	theo_skill;
				        theo_skill = get_skill( ch, gsn_theology );
				
                        if ( theo_skill < pSpellIndex->class_level[ch->class] )
					        color_code = 'r';
                    }
                    else
                    {
					    if( get_skill(ch,(*(pSpellIndex->sgsn))) < pSpellIndex->class_level[ch->class] )
					        color_code = 'r';
                    }
                }
	
				found = TRUE;
				level = pSpellIndex->class_level[ch->class];
				mana = pSpellIndex->base_mana;
				sprintf(buf,"&%c%-22s&x  %3d mana  ",color_code, pSpellIndex->full_name,mana);
 
				if (spell_list[level][0] == '\0')
          			sprintf(spell_list[level],"\n\rLevel %2d: %s",level,buf);
				else /* append */
				{
          			if ( ++spell_columns[level] % 2 == 0)
					strcat(spell_list[level],"\n\r          ");
          			strcat(spell_list[level],buf);
				}
			}
		}
	}

    /* return results */
 
    if (!found)
    {
      	send_to_char("No spells found.\n\r",ch);
      	return;
    }

    buffer = new_buf();
    for (level = 0; level < LEVEL_HERO + 1; level++)
      	if (spell_list[level][0] != '\0')
	    add_buf(buffer,spell_list[level]);
    add_buf(buffer,"\n\r");
    page_to_char(buf_string(buffer),ch);
    free_buf(buffer);
}

void do_abilities(Character *ch, char *argument )
{
    Buffer *buffer;
    char arg[MAX_INPUT_LENGTH];
    char skill_list[LEVEL_HERO + 1][MAX_STRING_LENGTH];
    char skill_columns[LEVEL_HERO + 1];
    int sn, level, min_lev = 1, max_lev = LEVEL_HERO;
    bool fAll = FALSE, found = FALSE;
    char buf[MAX_STRING_LENGTH];
 
    if (IS_NPC(ch))
      return;

    if (argument[0] != '\0')
    {
	fAll = TRUE;

	if (str_prefix(argument,"all"))
	{
	    argument = one_argument(argument,arg);
	    if (!is_number(arg))
	    {
		send_to_char("Arguments must be numerical or all.\n\r",ch);
		return;
	    }
	    max_lev = atoi(arg);

	    if (max_lev < 1 || max_lev > LEVEL_HERO)
	    {
		sprintf(buf,"Levels must be between 1 and %d.\n\r",LEVEL_HERO);
		send_to_char(buf,ch);
		return;
	    }

	    if (argument[0] != '\0')
	    {
		argument = one_argument(argument,arg);
		if (!is_number(arg))
		{
		    send_to_char("Arguments must be numerical or all.\n\r",ch);
		    return;
		}
		min_lev = max_lev;
		max_lev = atoi(arg);

		if (max_lev < 1 || max_lev > LEVEL_HERO)
		{
		    sprintf(buf,
			"Levels must be between 1 and %d.\n\r",LEVEL_HERO);
		    send_to_char(buf,ch);
		    return;
		}

		if (min_lev > max_lev)
		{
		    send_to_char("That would be silly.\n\r",ch);
		    return;
		}
	    }
	}
    }


    /* initialize data */
    for (level = 0; level < LEVEL_HERO + 1; level++)
    {
        skill_columns[level] = 0;
        skill_list[level][0] = '\0';
    }
 
    for (sn = 0; sn < MAX_PROFICIENCY; sn++)
    {
        if (prof_table[sn].name == NULL )
	    break;

	if ((level = prof_table[sn].class_avail[ch->class]) < LEVEL_HERO + 1
	&&  (fAll || level <= ch->level || IS_SET(ch->display,DISP_SHOW_ALL_SKILL_LEVELS) )
	&&  level >= min_lev && level <= max_lev
	&&  ch->pcdata->profs[sn] > 0)
        {
	    found = TRUE;
	    level = prof_table[sn].class_avail[ch->class];
 	    sprintf(buf,"%-22s        ", prof_table[sn].name);
 
	    if (skill_list[level][0] == '\0')
          	sprintf(skill_list[level],"\n\rLevel %2d: %s",level,buf);
	    else /* append */
	    {
          	if ( ++skill_columns[level] % 2 == 0)
		    strcat(skill_list[level],"\n\r          ");
          	strcat(skill_list[level],buf);
	    }
	}
    }
 
    /* return results */
 
    if (!found)
    {
      	send_to_char("No skills found.\n\r",ch);
      	return;
    }

    buffer = new_buf();
    for (level = 0; level < LEVEL_HERO + 1; level++)
      	if (skill_list[level][0] != '\0')
	    add_buf(buffer,skill_list[level]);
    add_buf(buffer,"\n\r");
    page_to_char(buf_string(buffer),ch);
    free_buf(buffer);
}

void do_skills(Character *ch, char *argument)
{
    Buffer *buffer;
    char arg[MAX_INPUT_LENGTH];
    int i;

    char skill_list[LEVEL_HERO + 1][MAX_STRING_LENGTH];
    char foundation_list[LEVEL_HERO + 1][MAX_STRING_LENGTH];
	char trade_list[LEVEL_HERO + 1][MAX_STRING_LENGTH];

    char skill_columns[LEVEL_HERO + 1];
    char foundation_columns[LEVEL_HERO + 1];
    char trade_columns[LEVEL_HERO + 1];

    int sn, level, min_lev = 1, max_lev = LEVEL_HERO;
    bool fAll = FALSE, found = FALSE;
    char buf[MAX_STRING_LENGTH];
 
    if (IS_NPC(ch))
      return;

    if (argument[0] != '\0')
    {
		fAll = TRUE;

		if (str_prefix(argument,"all"))
		{
	    	argument = one_argument(argument,arg);
	    	if (!is_number(arg))
	    	{
				cprintf(ch,"Arguments must be numerical or all.\n\r");
				return;
	    	}
	    	max_lev = atoi(arg);
	
	    	if (max_lev < 1 || max_lev > LEVEL_HERO)
	    	{
				cprintf(ch,"Levels must be between 1 and %d.\n\r",LEVEL_HERO);
				return;
	    	}
	
	    	if (argument[0] != '\0')
	    	{
				argument = one_argument(argument,arg);
				if (!is_number(arg))
				{
		    		cprintf(ch,"Arguments must be numerical or all.\n\r");
		    		return;
				}
				min_lev = max_lev;
				max_lev = atoi(arg);
	
				if (max_lev < 1 || max_lev > LEVEL_HERO)
				{
		    		cprintf(ch, "Levels must be between 1 and %d.\n\r",LEVEL_HERO);
		    		return;
				}
	
				if (min_lev > max_lev)
				{
		    		cprintf(ch,"That would be silly.\n\r");
		    		return;
				}
	    	}
		}
    }


    /* initialize data */
    for (level = 0; level < LEVEL_HERO + 1; level++)
    {
        skill_columns[level] = 0;
        skill_list[level][0] = '\0';

		foundation_columns[level] = 0;
		foundation_list[level][0] = '\0';
	
		trade_columns[level] = 0;
		trade_list[level][0] = '\0';
    }

	// Show foundation skills
	for (sn = 0; sn < MAX_SKILL; sn++)
	{
		if (skill_table[sn].name == NULL )
			break; 

		if (     (level=skill_table[sn].skill_level[ch->class]) < LEVEL_HERO + 1
             &&  (fAll || level <= ch->level || IS_SET(ch->display,DISP_SHOW_ALL_SKILL_LEVELS) )
             &&  level >= min_lev && level <= max_lev
             &&  skill_table[sn].type == SKILL_FOUNDATION
             &&  ch->pcdata->learned[sn] > 0 )
        {
	    	found = TRUE;
	    	level = skill_table[sn].skill_level[ch->class];
	    	if (ch->level < level)
	    		sprintf(buf,"%-22s n/a    ", skill_table[sn].name);
	    	else
			{
				char tmp[15];
				int max;
	
				max = ch->pcdata->learned[sn] + ( ch->level / 10 ) + 1;
	
				/* Check for max'd skill */
				if ( ch->pcdata->learned[sn] + ch->pcdata->skill_mod[sn] >= max )
					snprintf(tmp,sizeof(tmp),"(&B%+d&x)", max - ch->pcdata->learned[sn] );
				else
					snprintf(tmp,sizeof(tmp),"(%+d)", ch->pcdata->skill_mod[sn]);
	
	    		sprintf(buf,"%-22s &%c%3d&x %-5s  ",
					skill_table[sn].name,
					ch->pcdata->skill_mod[sn] < 0 ? 'R' : (ch->pcdata->skill_mod[sn] > 0 ? 'G' : 'x'),
		    		UMIN(ch->pcdata->learned[sn] + ch->pcdata->skill_mod[sn],max),
					ch->pcdata->skill_mod[sn] == 0 ? "" : tmp );
 			}
	
	    	if (foundation_list[level][0] == '\0')
          		sprintf(foundation_list[level],"\n\rLevel %2d: %s",level,buf);
	    	else /* append */
	    	{
          		if ( ++foundation_columns[level] % 2 == 0)
		    		strcat(foundation_list[level],"\n\r          ");
          		strcat(foundation_list[level],buf);
	    	}
		}
	}	

    // Show trade skills
    for (sn = 0; sn < MAX_SKILL; sn++)
    {
        if (skill_table[sn].name == NULL )
            break;

        if (     (level=skill_table[sn].skill_level[ch->class]) < LEVEL_HERO + 1
             &&  (fAll || level <= ch->level || IS_SET(ch->display,DISP_SHOW_ALL_SKILL_LEVELS) )
             &&  level >= min_lev && level <= max_lev
             &&  skill_table[sn].type == SKILL_TRADE
             &&  ch->pcdata->learned[sn] > 0 )
        {
            found = TRUE;
            level = skill_table[sn].skill_level[ch->class];
            if (ch->level < level)
                sprintf(buf,"%-22s n/a    ", skill_table[sn].name);
            else
            {
                char tmp[15];
				int max = ch->pcdata->learned[sn] + (ch->level/10) + 1;

                /* Check for max'd skill */
                if ( ch->pcdata->learned[sn] + ch->pcdata->skill_mod[sn] >= max )
                    snprintf(tmp,sizeof(tmp),"(&B%+d&x)", max - ch->pcdata->learned[sn] );
                else
                    snprintf(tmp,sizeof(tmp),"(%+d)", ch->pcdata->skill_mod[sn]);

                sprintf(buf,"%s%-22s &%c%3d&x %-5s  ",
                    IS_SET(skill_table[sn].flags,SKILL_SECONDARY) ? "&Y*&x" : " ",
                    skill_table[sn].name,
                    ch->pcdata->skill_mod[sn] < 0 ? 'R' : (ch->pcdata->skill_mod[sn] > 0 ? 'G' : 'x'),
                    UMIN(ch->pcdata->learned[sn] + ch->pcdata->skill_mod[sn],max),
                    ch->pcdata->skill_mod[sn] == 0 ? "" : tmp );
            }

            if (trade_list[level][0] == '\0')
                sprintf(trade_list[level],"\n\rLevel %2d: %s",level,buf);
            else /* append */
            {
                if ( ++trade_columns[level] % 2 == 0)
                    strcat(trade_list[level],"\n\r          ");
                strcat(trade_list[level],buf);
            }
        }
    }

    for (sn = 0; sn < MAX_SKILL; sn++)
    {
        if (skill_table[sn].name == NULL )
	    	break;

		if (      (level=skill_table[sn].skill_level[ch->class]) < LEVEL_HERO + 1
	         &&  (fAll || level <= ch->level || IS_SET(ch->display,DISP_SHOW_ALL_SKILL_LEVELS) )
	         &&  level >= min_lev && level <= max_lev
	         &&  (skill_table[sn].spell_fun == NULL || skill_table[sn].type == SKILL_WEAPON)
   	         &&  skill_table[sn].type != SKILL_TRADE
	         &&  skill_table[sn].type != SKILL_FOUNDATION
	         &&  ch->pcdata->learned[sn] > 0 )
        {
	    	found = TRUE;
	    	level = skill_table[sn].skill_level[ch->class];
	    	if (ch->level < level)
	    		sprintf(buf,"%-22s n/a    ", skill_table[sn].name);
	    	else
			{
				char tmp[15];
				int max;
	
				max = ch->level + ( ch->level / 10 + 1 );
	
				/* Check for max'd skill */
				if ( ch->pcdata->learned[sn] + ch->pcdata->skill_mod[sn] >= max )
					snprintf(tmp,sizeof(tmp),"(&B%+d&x)", max - ch->pcdata->learned[sn] );
				else
					snprintf(tmp,sizeof(tmp),"(%+d)", ch->pcdata->skill_mod[sn]);
	
	    		sprintf(buf,"%-22s &%c%3d&x %-5s  ",
					skill_table[sn].name,
					ch->pcdata->skill_mod[sn] < 0 ? 'R' : (ch->pcdata->skill_mod[sn] > 0 ? 'G' : 'x'),
		    		UMIN(ch->pcdata->learned[sn] + ch->pcdata->skill_mod[sn],max),
					ch->pcdata->skill_mod[sn] == 0 ? "" : tmp );
 			}
	
	    	if (skill_list[level][0] == '\0')
          		sprintf(skill_list[level],"\n\rLevel %2d: %s",level,buf);
	    	else /* append */
	    	{
          		if ( ++skill_columns[level] % 2 == 0)
		    		strcat(skill_list[level],"\n\r          ");
          		strcat(skill_list[level],buf);
	    	}
		}
    }
 
    /* return results */
 
    if (!found)
    {
      	send_to_char("No skills found.\n\r",ch);
      	return;
    }

    buffer = new_buf();

	bprintf(buffer,"&B[&x &WFoundation Skills &B]&x");
    for (level = 0; level < LEVEL_HERO + 1; level++)
      	if (foundation_list[level][0] != '\0')
	    	add_buf(buffer,foundation_list[level]);

	bprintf(buffer,"\n\r\n\r&B[&x &WTrade Skills &B]&x");
    for (level = 0; level < LEVEL_HERO + 1; level++)
      	if (trade_list[level][0] != '\0')
	    	add_buf(buffer,trade_list[level]);

	bprintf(buffer,"\n\r\n\r&B[&x &WGeneral Skills &B]&x");
    for (level = 0; level < LEVEL_HERO + 1; level++)
      	if (skill_list[level][0] != '\0')
	    	add_buf(buffer,skill_list[level]);

    add_buf(buffer,"\n\r\n\r");
	bprintf(buffer,"Skill Points: %d\n\r",ch->practice);
	bprintf(buffer,"Trade Points: %d/%d\n\r",calcTotalTradePoints(ch),CRAFTING_CAP);
    
    // Check for weapon specs
    for( i=0 ; i<MAX_WEAPONS ;i++)
        if ( ch->pcdata->specialized[i] > 0 )
            bprintf(buffer,"Specialization: Rank %d in %s (%s)\n\r",
                ch->pcdata->specialized[i],
                weapon_table[i].name,
                specTitle[ch->pcdata->specialized[i]] );

    page_to_char(buf_string(buffer),ch);
    free_buf(buffer);
}

int exp_per_level(Character *ch, int points)
{
    int expl,inc;

    if (IS_NPC(ch))
	return 1000; 

    expl = 1000;
    inc = 500;

    if (points < 40)
	return 1000 * (pc_race_table[ch->race].class_mult[ch->class] ?
		       pc_race_table[ch->race].class_mult[ch->class]/100 : 1);

    /* processing */
    points -= 40;

    while (points > 9)
    {
	expl += inc;
        points -= 10;
        if (points > 9)
	{
	    expl += inc;
	    inc *= 2;
	    points -= 10;
	}
    }

    expl += points * inc / 10;  

    return expl * pc_race_table[ch->race].class_mult[ch->class]/100;
}

/* shows all groups, or the sub-members of a group */
void do_groups(Character *ch, char *argument)
{
    char buf[100];
    int gn,sn,col;

    if (IS_NPC(ch))
	return;

    col = 0;

    if (argument[0] == '\0')
    {   /* show all groups */
	
	for (gn = 0; gn < MAX_GROUP; gn++)
        {
	    if (group_table[gn].name == NULL)
		break;
	    if (ch->pcdata->group_known[gn])
	    {
		sprintf(buf,"%-20s ",group_table[gn].name);
		send_to_char(buf,ch);
		if (++col % 3 == 0)
		    send_to_char("\n\r",ch);
	    }
        }
        if ( col % 3 != 0 )
            send_to_char( "\n\r", ch );
	send_to_char(buf,ch);
	return;
     }

     if (!str_cmp(argument,"all"))    /* show all groups */
     {
        for (gn = 0; gn < MAX_GROUP; gn++)
        {
            if (group_table[gn].name == NULL)
                break;
	    sprintf(buf,"%-20s ",group_table[gn].name);
            send_to_char(buf,ch);
	    if (++col % 3 == 0)
            	send_to_char("\n\r",ch);
        }
        if ( col % 3 != 0 )
            send_to_char( "\n\r", ch );
	return;
     }
	
     
     /* show the sub-members of a group */
     gn = group_lookup(argument);
     if (gn == -1)
     {
	send_to_char("No group of that name exist.\n\r",ch);
	send_to_char(
	    "Type 'groups all' or 'info all' for a full listing.\n\r",ch);
	return;
     }

     for (sn = 0; sn < MAX_IN_GROUP; sn++)
     {
	if (group_table[gn].spells[sn] == NULL)
	    break;
	sprintf(buf,"%-20s ",group_table[gn].spells[sn]);
	send_to_char(buf,ch);
	if (++col % 3 == 0)
	    send_to_char("\n\r",ch);
     }
    if ( col % 3 != 0 )
        send_to_char( "\n\r", ch );
}

/* checks for skill improvement */
void check_improve( Character *ch, int sn, bool success, int multiplier )
{
	return;
}


/* returns a group index number given the name */
int group_lookup( const char *name )
{
    int gn;
 
    for ( gn = 0; gn < MAX_GROUP; gn++ )
    {
        if ( group_table[gn].name == NULL )
            break;
        if ( LOWER(name[0]) == LOWER(group_table[gn].name[0])
        &&   !str_prefix( name, group_table[gn].name ) )
            return gn;
    }
 
    return -1;
}

/* recursively adds a group given its number -- uses group_add */
void gn_add( Character *ch, int gn)
{
    int i;
    
    ch->pcdata->group_known[gn] = TRUE;
    for ( i = 0; i < MAX_IN_GROUP; i++)
    {
        if (group_table[gn].spells[i] == NULL)
            break;
        group_add(ch,group_table[gn].spells[i],FALSE);
    }
}

/* recusively removes a group given its number -- uses group_remove */
void gn_remove( Character *ch, int gn)
{
    int i;

    ch->pcdata->group_known[gn] = FALSE;

    for ( i = 0; i < MAX_IN_GROUP; i ++)
    {
	if (group_table[gn].spells[i] == NULL)
	    break;
	group_remove(ch,group_table[gn].spells[i]);
    }
}
	
/* use for processing a skill or group for addition  */
void group_add( Character *ch, const char *name, bool deduct)
{
    int sn,gn;
    sh_int	*array;

    if (IS_NPC(ch)) /* NPCs do not have skills */
	return;

    array = ch->pcdata->learned;
    if ( (sn = skill_lookup(name) ) < 0 )
    {
        SpellIndex *sp;

	    sn = spell_lookup(name,(class_table[ch->class].group == DIVINE));
	    array = ch->pcdata->spells;
        if ( sn > 0 && (sp=get_spell_index(sn)))
            cprintf(ch,"Adding spell %s\n\r", sp->name );
    }

    if ( sn < 0 )
    {
	    sn = proficiency_lookup(name);
	    array = ch->pcdata->profs;
    }

    if (sn != -1)
    {
	    if ( array[sn] == 0 )
	        array[sn] = 1;
	
	    return;
    }
	
    /* now check groups */
    gn = group_lookup(name);

    if (gn != -1)
    {
	if (ch->pcdata->group_known[gn] == FALSE)  
	{
	    ch->pcdata->group_known[gn] = TRUE;
	}
	gn_add(ch,gn); /* make sure all skills in the group are known */
    }
}

/* used for processing a skill or group for deletion -- no points back! */

void group_remove(Character *ch, const char *name)
{
    int sn, gn;
    
     sn = skill_lookup(name);

    if (sn != -1)
    {
	ch->pcdata->learned[sn] = 0;
	return;
    }
 
    /* now check groups */
 
    gn = group_lookup(name);
 
    if (gn != -1 && ch->pcdata->group_known[gn] == TRUE)
    {
	ch->pcdata->group_known[gn] = FALSE;
	gn_remove(ch,gn);  /* be sure to call gn_add on all remaining groups */
    }
}

void reuseListAdd( Character *ch, Reuse_wait *new )
{
	new->next = ch->reuse_wait;
	ch->reuse_wait = new;
	return;
}

void setReuseTimer( Reuse_wait *reuse, int pulses )
{
	reuse->timer = pulses;
	return;
}

void reuseListRemove( Character *ch, Reuse_wait *new )
{
	Reuse_wait *r;

	if ( ch->reuse_wait == new )
		ch->reuse_wait = new->next;
	else	
	{
		for( r = ch->reuse_wait ; r ; r = r->next )
			if ( r->next == new )
				break;

		if ( !r )
		{
			log_string("reuseListRemove: element not found");
			return;
		}

		r->next = new->next;
	}
	free_reuse(new);
	return;
}

void setSkillReuseWait( Character *ch, int sn, int pulses )
{
	Reuse_wait	*new, *r;
	
	for( r = ch->reuse_wait ; r ; r=r->next )
	{
		if ( r->type == AFF_SKILL && r->gsn == sn )
		{
			setReuseTimer(r,pulses);
			return;
		}
	}
		
	new = new_reuse( );
	new->type = AFF_SKILL;
	new->gsn = sn;
	setReuseTimer(new,pulses);
	reuseListAdd(ch,new);
	return;
}

void setSpellReuseWait( Character *ch, int sn, int pulses )
{
    Reuse_wait  *new, *r;
   
    for( r = ch->reuse_wait ; r ; r=r->next )
    {
        if ( r->type == AFF_SPELL && r->gsn == sn )
        {
            setReuseTimer(r,pulses);
            return;
        }
    }

    new = new_reuse( );
    new->type = AFF_SPELL;
    new->gsn = sn;
    setReuseTimer(new,pulses);
    reuseListAdd(ch,new);
    return;
}

void setAbilReuseWait( Character *ch, int sn, int pulses )
{
    Reuse_wait  *new, *r;

    for( r = ch->reuse_wait ; r ; r=r->next )
    {
        if ( r->type == AFF_ABIL && r->gsn == sn )
        {
            setReuseTimer(r,pulses);
            return;
        }
    }

    new = new_reuse( );
    new->type = AFF_ABIL;
    new->gsn = sn;
    setReuseTimer(new,pulses);
    reuseListAdd(ch,new);
    return;
}

int check_reuse_wait( Character *ch, int sn, int type )
{
	Reuse_wait *r;

	if ( ch->reuse_wait == NULL )
		return FALSE;
	else
	for( r = ch->reuse_wait ; r ; r = r->next )
		if ( r->type == type && r->gsn == sn )
			return r->timer;

	return FALSE;
}

int check_reuse_line( Character *ch, int sn )
{
	Reuse_wait *r;

	if ( ch->reuse_wait == NULL )
		return FALSE;
	else
	{
		SpellIndex* pSpellIndex = get_spell_index( sn );

		if(!pSpellIndex)
		{
			log_bug("check_reuse_line(spellindex): Spell index not found(%d)",sn);
			return FALSE;
		}

		for( r = ch->reuse_wait ; r ; r = r->next )
		{
			SpellIndex* pReuseSpellIndex;
			
			if(r->type == AFF_SPELL)
			{
				pReuseSpellIndex = get_spell_index(r->gsn);
				if(!pReuseSpellIndex)
				{
					log_bug("check_reuse_line(reusespellindex): Spell index not found(%d)",r->gsn);
					return FALSE;
				}

				if ( sameSeries(pReuseSpellIndex,pSpellIndex) || r->gsn == sn )
					return r->timer;
			}
		}
	}

	return FALSE;
}


void do_first_aid(Character *ch, char *argument)
{
	Character *victim;
	int		amount;
	int		skill;

	if ( IS_NPC(ch) )
	{
		cprintf(ch,"You're an NPC, you can't use first aid.\n\r");
		return;
	}

	if ( (skill = get_skill(ch,gsn_first_aid)) < 1 )
	{
		cprintf(ch,"You do not know how to administer first aid.\n\r");	
		return;
	}

	if ( ch->fighting != NULL )
	{
		cprintf(ch,"Not while you're fighting!\n\r");
		return;
	}

	if ( *argument == '\0' )
	{
		cprintf(ch,"Usage: firstaid <victim>\n");
		return;
	}

	if ( (victim=get_char_room(ch,argument)) == NULL )
	{
		cprintf(ch,"There's nobody like that nearby.\n\r");
		return;
	}

	if ( victim->fighting != NULL )
	{
		act("$N is a little busy right now!",ch,NULL,victim,TO_CHAR);
		return;
	}

	if ( REUSE_SKILL(ch,gsn_first_aid) )
    {
        cprintf(ch,"Not yet, it takes a while to prepare.\n\r");
        return;
    }

	amount = ch->level;
	applySkillAdjust(&amount,50,skill,ch->level);

	apply_healing(victim,amount);
	if ( ch == victim )
	{
		act("You administer first aid to yourself.",ch,NULL,NULL,TO_CHAR);
		act("$n administers first aid to $mself.",ch,NULL,NULL,TO_ROOM);
	}
	else
	{
		act("You administer first aid to $N.",ch,NULL,victim,TO_CHAR);
		act_new("$n administers first aid to you.",ch,NULL,victim,TO_VICT,POS_SLEEPING,FALSE);
		act("$n administers first aid to $N.",ch,NULL,victim,TO_NOTVICT);
	}

    setSkillReuseWait(ch,gsn_first_aid,PULSE_PER_SECOND * 10);
	return;
}

int getWeaponReuse( Character *ch )
{
	Reuse_wait *r;
	int top = 0;

	for( r = ch->reuse_wait ; r ; r = r->next )
	{
		if ( r->type != AFF_SKILL )
			continue;

		if ( skill_table[r->gsn].type == SKILL_WEAPON )
			top = UMAX(top,r->timer);
	}

	return top;
}


void update_npc_reuse( Character *npc )
{
    Reuse_wait  *r, *r_next;
	Character *master;

	master = npc->master;

    for( r = npc->reuse_wait ; r ; r = r_next )
    {
        r_next = r->next;

		/* We don't print to NPCs */
        if ( (r->timer = UMAX(0,r->timer-1)) == 0 )
		{
			if ( master != NULL && !IS_NPC(master) )
			{
	        	if( IS_SET(master->display,DISP_ALERT_REUSE)
             		&& ( r->type != AFF_SKILL || ( r->type == AFF_SKILL && !IS_SET(skill_table[r->gsn].flags,SKILL_NO_REUSE_ALERT) ) )
             		&& ( (r->type == AFF_SKILL && skill_table[r->gsn].type != SKILL_WEAPON ) || r->type == AFF_SPELL) )
                {
                	SpellIndex* pSpellIndex = get_spell_index(r->gsn);

					actprintf(master,NULL,npc,TO_CHAR,"&yYour follower $N&y may %s %s again.&x", 
						r->type == AFF_SPELL ? "cast" : "use",
                        r->type == AFF_SPELL ? (pSpellIndex ? pSpellIndex->name : "(null)") :
                        (r->type == AFF_SKILL ? skill_table[r->gsn].name : prof_table[r->gsn].name ) );
                }
			}
            reuseListRemove(npc,r);
		}
    }
}

/* 
 * 10+ Mountain Lion
 * 17+ Wolf
 * 25+ Tiger
 * 34+ Bear
 * 44+ Treant
 */
Character *createShiftedStats( Character *ch, int vnum, int skill, 
							int max_hp, int hp,
							int max_base_hp, int base_hp,
							int max_stamina, int stamina,
							int max_move, int move )
{
	Character *shifted = createShifted( ch, vnum, skill );

	shifted->max_stat_hit = max_hp;
	shifted->stat_hit = hp;

	shifted->max_base_hit = max_base_hp;
	shifted->base_hit = base_hp;

	shifted->max_stamina = max_stamina;
	shifted->stamina = stamina;

	shifted->max_move = max_move;
	shifted->move = move;

	return shifted;
}

Character *createShifted( Character *ch, int vnum, int skill )
{
	Character *shifted;
	int hp_max;
	int i;

	if ( (shifted = create_mobile(get_mob_index(vnum))) == NULL )
        return NULL;

	/* Set up stats */
	shifted->level = ch->level;
	shifted->sex = ch->sex;
	shifted->deity = ch->deity;
	shifted->hitroll = UMAX(ch->hitroll,skill);
	shifted->comm = ch->comm;
	shifted->act = ch->act;

	/* set up stats */
	for( i=0; i<MAX_STATS; i++ )
    {
		shifted->perm_stat[i] = 150 + skill * 2;
        shifted->mod_stat[i] = 0;
    }

	/* Set up hit points */
	shifted->max_base_hit = skill * 4;
	shifted->base_hit = shifted->max_base_hit;
	hp_max = skill * 25;
	shifted->max_stat_hit = number_range( hp_max * 3/4, hp_max );
	shifted->stat_hit = max_stat_hit( shifted );
	shifted->max_stamina = skill * 15;
	shifted->stamina = max_stamina( shifted );

	shifted->saves[SAVE_WILLPOWER] = ch->saves[SAVE_WILLPOWER];
	shifted->saves[SAVE_REFLEX] = ch->saves[SAVE_REFLEX];
	shifted->saves[SAVE_FORTITUDE] = ch->saves[SAVE_FORTITUDE];

	shifted->prompt = str_dup( ch->prompt );
	shifted->display = ch->display;
	shifted->created = ch->created;
	shifted->clan = ch->clan;
	shifted->played = ch->played;
	shifted->lines = ch->lines;
	shifted->logon = ch->logon;
	shifted->timer = ch->timer;
	shifted->wait = ch->wait;
	shifted->daze = ch->daze;
	shifted->move = ch->move;
	shifted->max_move = ch->max_move;

	shifted->damage[0] = 3;
	shifted->damage[1] = 6;
	shifted->damage[2] = skill/2*3;

	shifted->absorb = skill/2;

	for( i=0; i<4 ; i++ )
		shifted->armor[i] = skill * 15;

	shifted->armor[3] /= 4;

	shifted->pcdata = ch->pcdata;
	shifted->desc   = ch->desc;
	shifted->version = ch->version;

	return shifted;
}

void do_shapeshift( Character *ch, char *argument )
{
	Descriptor *d;
 	int 		skill;
	int			vnum;
	Affect		*paf, *paf_next;
	Character	*shifted;
	Affect		af;

    cprintf(ch,"Temporarily disabled\n\r");
    return;

	if ( IS_IMMORTAL(ch) )
	{
		cprintf(ch,"Please don't play around with it.  Make a mortal! :)\n\r");
		return;
	}

	if ( *argument == NULL )
	{
		cprintf(ch,"Syntax:   shapeshift <wolf|lion|treant>\n\r"
                   "          shapeshift return\n\r");
		return;
	}

	if ( !str_cmp(argument,"return") && 
		 is_affected(ch,gsn_shapeshifting,AFF_SKILL) )
	{
		Room *r = ch->in_room;
		Character *orig = ch->desc->original;

		act("You shift back into your normal form.",ch,NULL,NULL,TO_CHAR);
		act("$n shifts back into $N.",ch,NULL,orig,TO_ROOM);

		for ( d = descriptor_list; d != NULL; d = d->next )
		{
			Character *victim;

			victim = d->original ? d->original : d->character;

			if ( !victim )
				continue;
			if(victim->reply == ch)
				victim->reply =ch->desc->original;
		}

		if(ch->pcdata->rtptrs.handler)
		{
			Roundtable *handler = ch->pcdata->rtptrs.handler;
			if(handler->leader == ch)
				handler->leader = ch->desc->original;
			if(handler->lastInLine == ch)
				handler->lastInLine = ch->desc->original;
			if(handler->currentInLine == ch)
				handler->currentInLine = ch->desc->original;
			ch->pcdata->rtptrs.prevChar->pcdata->rtptrs.nextChar = ch->desc->original;
			ch->pcdata->rtptrs.nextChar->pcdata->rtptrs.prevChar = ch->desc->original;
			ch->desc->original->pcdata->rtptrs.prevChar = ch->pcdata->rtptrs.prevChar;
			ch->desc->original->pcdata->rtptrs.nextChar = ch->pcdata->rtptrs.nextChar;
			ch->desc->original->pcdata->rtptrs.rtvalue = ch->pcdata->rtptrs.rtvalue;
		}
		ch->desc->original->reply = ch->reply;
     	ch->desc->character       = ch->desc->original;
    	ch->desc->original        = NULL;
    	ch->desc->character->desc = ch->desc;
    	ch->desc                  = NULL;
		extract_char( ch, TRUE );

		char_to_room( orig, r );
		skill = get_skill(orig,gsn_shapeshifting);

		/* Shapeshifting hangover */
    	af.where    = TO_AFFECTS;
    	af.type     = skill_lookup("shapeshift sickness");
    	af.level    = orig->level;     
    	af.duration = minutes(skill / 3);
    	af.location = APPLY_CON;
    	af.modifier = -skill;
    	af.bitvector = 0;
    	af.flags = AFF_SKILL;
    	af.misc = 0;
    	skillAffectToChar( orig, &af );
		af.location = APPLY_STR;
		skillAffectToChar( orig, &af );
		af.location = APPLY_DEX;
		skillAffectToChar( orig, &af );
		orig->shapeshifted = NULL;

		orig->pcdata->condition[COND_HUNGER] = 0;
		return;
	}

    if ( is_affected(ch,gsn_shapeshifting,AFF_SKILL) )
    {
        cprintf(ch,"You are already shifted.  Type 'shapeshift return' to cancel it.\n\r");
        return;     
    }

	if ( is_affected(ch,skill_lookup("shapeshift sickness"),AFF_SKILL) )
	{
		cprintf(ch,"You cannot shift again until the sickness wears off.\n\r");
		return;
	}

    if ( (skill = get_skill(ch,gsn_shapeshifting)) < 1 )
    {
        cprintf(ch,"You really want to be somebody else...\n\r");
        return;
    }

	if ( !str_cmp(argument,"lion") )
		vnum = SHIFT_VNUM_LION;
	else
	if ( !str_cmp(argument,"wolf") )
		vnum = SHIFT_VNUM_WOLF;
	else
	if ( !str_cmp(argument,"treant") )
		vnum = SHIFT_VNUM_TREANT;
	else
	{
		cprintf(ch,"Valid forms to shift to are lion, wolf, and treant.\n\r");
		return;
	}

	for( paf = ch->affected; paf; paf = paf_next )
	{
		paf_next = paf->next;
		affect_remove( ch, paf );
	}

	shifted = createShifted( ch, vnum, skill );
    if ( shifted == NULL )
    {
        cprintf(ch,"You failed (there's a bug in the game, report it to James).\n\r");
        log_bug("shapeshift: unable to create shifted character");
        return;
    }

	act("You shapeshift into $N.",ch,NULL,shifted,TO_CHAR);
	act("$n shapeshifts into $N.",ch,NULL,shifted,TO_ROOM);
	
	shifted->pcdata = ch->pcdata;
	shifted->desc   = ch->desc;
	shifted->reply = ch->reply;

	for ( d = descriptor_list; d != NULL; d = d->next )
	{
		Character *victim;

		victim = d->original ? d->original : d->character;

		if ( !victim )
			continue;
		if(victim->reply == ch)
			victim->reply =shifted;
	}

	if(ch->pcdata->rtptrs.handler)
	{
		Roundtable *handler = ch->pcdata->rtptrs.handler;
		if(handler->leader == ch)
			handler->leader = shifted;
		if(handler->lastInLine == ch)
			handler->lastInLine = shifted;
		if(handler->currentInLine == ch)
			handler->currentInLine = shifted;
		ch->pcdata->rtptrs.prevChar->pcdata->rtptrs.nextChar = shifted;
		ch->pcdata->rtptrs.nextChar->pcdata->rtptrs.prevChar = shifted;
		shifted->pcdata->rtptrs.prevChar = ch->pcdata->rtptrs.prevChar;
		shifted->pcdata->rtptrs.nextChar = ch->pcdata->rtptrs.nextChar;
		shifted->pcdata->rtptrs.rtvalue = ch->pcdata->rtptrs.rtvalue;
	}

	ch->shapeshifted = shifted;
	ch->desc->original = ch;
	ch->desc->character = shifted;
	char_to_room( shifted, ch->in_room );
	char_from_room( ch );


	af.where    = TO_AFFECTS;
    af.type     = gsn_shapeshifting;
    af.level    = ch->level;
    af.duration = DUR_PERMANENT;
    af.location = 0;
    af.modifier = 0;
    af.bitvector = 0;
    af.flags = AFF_SKILL;
	af.misc = 0;
    skillAffectToChar( shifted, &af );
}

int getAbilitySeries( Character *ch, char *series )
{
    int i, sn;
    char tmp[MAX_STRING_LENGTH];

    for( i=10 ; i>0 ; i-- )
    {
        snprintf(tmp,sizeof(tmp),"%s %d",series,i);
        if ( (sn = proficiency_lookup(tmp)) > 0 && HAS_PROF(ch,sn))
        {
            return i;
        }
    }

    return 0;
}

// Specialize in a weapon.
void do_focus( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    int weapon;
    int slots, spec, i;
    int total;
    int max, divisor;
    int aa_points;
    Character *trainer;

    if ( !IS_SET(class_table[ch->class].flags,CLA_CAN_FOCUS))
    {
        cprintf(ch,"Your class cannot specialize in weapon training.\n\r");
        return;
    }

    for ( trainer = ch->in_room->people; trainer != NULL; trainer = trainer->next_in_room)
		if (IS_NPC(trainer) && IS_SET(trainer->act,ACT_TRAIN))
	    	break;

    if ( !trainer )
    {
        cprintf(ch,"There is no trainer here.\n\r");
        return;
    }

    argument = one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
        cprintf(ch,"Syntax:  focus <weapon> [undo]\n\r"
               "Sample usage:\n\r"
               "   > focus katana           // adds 1 focus point to katana\n\r"
               "   > focus broadsword undo  // de-focuses in broadsword by 1 point\n\r");
        return;
    }

    if( (weapon = weapon_lookup(arg)) < 0 )
    {
        cprintf(ch,"There is no weapon called '%s' that you can focus on.\n\r", arg);
        return;
    }

    // Make sure you haven't used your 6 specializations yet
    total = 0;
    for( i=0;i<MAX_WEAPONS;i++)
        total += ch->pcdata->specialized[i];

    // Check for an 'undo'
    if ( argument[0] != '\0' )
    {
        if ( str_cmp(argument,"undo") )
        {
            cprintf(ch,"If you want to de-focus, type:  focus weapon_type undo\n\r");
            return;
        }

        if ( ch->pcdata->specialized[weapon] < 1 )
        {
            cprintf(ch,"You aren't focused with the %s.\n\r", weapon_table[weapon].name );
            return;
        }

        cprintf(ch,"You rescind your title as a%s %s wielder of the %s.\n\r",
            IS_VOWEL(specTitle[ch->pcdata->specialized[weapon]][0]) ? "n" : "",
            specTitle[ch->pcdata->specialized[weapon]], weapon_table[weapon].name );
        ch->pcdata->specialized[weapon]--;
        cprintf(ch,"You are now merely %s with the %s.\n\r",
            specTitle[ch->pcdata->specialized[weapon]], weapon_table[weapon].name );

        // Return spent points 
        aa_points = getFib( total );
        cprintf(ch,"(%d Specialization Points have been returned to you.)\n\r", aa_points );
        ch->pcdata->spec_points += aa_points;

        act("$n de-focuses $s weapon training.",ch,NULL,NULL,TO_ROOM);
        return;
    }

    if ( ch->pcdata->subrace == subrace_lookup("tayana") )
    {
        max = 7;
        divisor = 8;
    }
    else
    {
        max = 6;
        divisor = 9;
    }

    // Make sure they have enough skill in that weapon to focus
    slots = get_skill(ch, *weapon_table[weapon].gsn ) / divisor;
    spec  = ch->pcdata->specialized[weapon];
    
    if ( spec >= slots )
    {
        cprintf(ch,"You cannot focus further with the %s.\n\r", weapon_table[weapon].name );
        return;
    }

    if ( total > max )
    {
        cprintf(ch,"You cannot focus more than %d times.\n\r", max);
        return;
    }

    aa_points = getFib( total + 1 );
    if ( ch->pcdata->spec_points < aa_points )
    {
        cprintf(ch,"You need %d Specialization Points for further weapon focus.\n\r", aa_points );
        return;
    }
        
    // Ok, we can specialize in this.
    ch->pcdata->specialized[weapon]++;
    cprintf(ch,"You now rank as a%s %s wielder of the %s.\n\r",
            IS_VOWEL(specTitle[ch->pcdata->specialized[weapon]][0]) ? "n" : "",
            specTitle[ch->pcdata->specialized[weapon]], weapon_table[weapon].name );
    cprintf(ch,"*This training cost you %d Specialization Points.\n\r",aa_points);
    ch->pcdata->spec_points -= aa_points;
    act("$n trains in weapon focus.",ch,NULL,NULL,TO_ROOM);
    return;
}

int attack_roll( Character *ch, bool fOffhand )
{
    int stat = STAT_STR;
    int sn, skill;
    int topDiceRange;
    int total;
    int focusMod;

    if ( HAS_PROF(ch,gpn_weapon_finesse) && get_curr_stat(ch,STAT_STR) < get_curr_stat(ch,STAT_DEX) )
        stat = STAT_DEX;

    sn = get_weapon_sn(ch,fOffhand ? GET_OFFHAND_SN : GET_WEAPON_SN);
    skill = get_weapon_skill(ch,sn);

    total = ch->level + skill * 4 + ((get_curr_stat(ch,stat)-100) /2);

    // Randomness
    if ( ch->level <= 30 )
        topDiceRange = (ch->level*5)+50;
    else
        topDiceRange = (int)(((float)(ch->level-30))*2.5)+200;

    focusMod = weaponProfAdj( ch, FALSE );
    total = focusMod * (total + (topDiceRange/2)) / 100;
    return total + GET_HITROLL(ch);
}

int getFib( int which )
{
    int last, last2, current, i;

    if (which < 0)
        return 0;

    if (which < 3)
        return 1;

    last2 = 1;
    last = 1;

    current = last + last2; // stifle compiler warnings
    for( i=3;i<=which;i++)
    {
        current = last + last2;
        last2 = last;
        last = current;
    }

    return current;
}
    
void do_combat( Character *ch, char *argument )
{
    int stat = STAT_STR;
    int sn, skill;
    int topDiceRange;
    int total;
    int focusMod;
    Object *obj;

    if ( HAS_PROF(ch,gpn_weapon_finesse) && get_curr_stat(ch,STAT_STR) < get_curr_stat(ch,STAT_DEX) )
        stat = STAT_DEX;

    sn = get_weapon_sn(ch,GET_WEAPON_SN);
    skill = get_weapon_skill(ch,sn);
    obj = get_eq_char( ch, WEAR_WIELD );
    focusMod = weaponProfAdj( ch, FALSE );

    cprintf(ch,"Attack Value (Swordarm, %s)\n\r", 
                        obj == NULL ? "no weapon equipped" : 
                        weapon_table[ get_weapon_index(obj->value[0]) ].name );

    cprintf(ch,"  Level:      %3d\n\r"
               "  Skill:      %3d (%s of %d x 4)\n\r"
               "  Attribute:  %3d (%s - 100 / 2)\n\r",
        ch->level, skill*4, skill_table[sn].name, skill,
        (get_curr_stat(ch,stat)-100)/2, statnames[stat] );

    total = ch->level + skill * 4 + ((get_curr_stat(ch,stat)-100) /2);

    // Randomness
    if ( ch->level <= 30 )
        topDiceRange = (ch->level*5)+50;
    else
        topDiceRange = (int)(((float)(ch->level-30))*2.5)+200;
    cprintf(ch,"  Random:     %3d (1d%-3d average roll)\n\r",
        topDiceRange/2, topDiceRange);
    cprintf(ch,"  -------------------------\n\r");
    cprintf(ch,"  Subtotal:   %3d\n\r", total+topDiceRange/2 );
    cprintf(ch,"  Focus:      %3d%%\n\r", focusMod );
    cprintf(ch,"  Hitroll:    %+3d\n\r", GET_HITROLL(ch) );
    cprintf(ch,"  AAR:        &g%3d&x (%d x %d%% + %d)\n\r",
        focusMod * (total + topDiceRange/2) / 100 + GET_HITROLL(ch),
        total+topDiceRange/2, focusMod, GET_HITROLL(ch) );
    cprintf(ch,"  Max:        %3d&n\n\r", focusMod * (total + topDiceRange) / 100  + GET_HITROLL(ch));

    if ( get_skill(ch,gsn_dual_wield) > 1 )
    {
        sn = get_weapon_sn(ch,GET_OFFHAND_SN);
        skill = get_weapon_skill(ch,sn);
        focusMod = weaponProfAdj( ch, TRUE );
        obj = get_eq_char( ch, WEAR_OFFHAND );

        cprintf(ch,"\n\rAttack Value (Offhand, %s)\n\r",
                        obj == NULL ? "no weapon equipped" :
                        weapon_table[ get_weapon_index(obj->value[0]) ].name );

        cprintf(ch,"  Level:      %3d\n\r"
                   "  Skill:      %3d (%s of %d x 4)\n\r"
                   "  Attribute:  %3d (%s - 100 / 2)\n\r",
            ch->level, skill*4, skill_table[sn].name, skill,
            (get_curr_stat(ch,stat)-100)/2, statnames[stat] );

        total = ch->level + skill * 4 + ((get_curr_stat(ch,stat)-100) /2);   
        cprintf(ch,"  Random:     %3d (1d%-3d average roll)\n\r", topDiceRange/2, topDiceRange);
        cprintf(ch,"  -------------------------\n\r");
        cprintf(ch,"  Subtotal:   %3d\n\r", total+topDiceRange/2 );
        cprintf(ch,"  Focus:      %3d%%\n\r", focusMod );
        cprintf(ch,"  Hitroll:    %+3d\n\r", GET_HITROLL(ch) );
        cprintf(ch,"  AAR:        &g%3d&x (%d x %d%% + %d)\n\r",
            focusMod * (total + topDiceRange/2) / 100 + GET_HITROLL(ch),
            total+topDiceRange/2, focusMod, GET_HITROLL(ch) );
        cprintf(ch,"  Max:        %3d\n\r", total + topDiceRange );
    }

    cprintf(ch,"\n\r*You will be completely unable to hit characters whose AC\n\r"
               "is above your Max unless there are multiple attackers on that\n\r"
               "character.\n\r");
}

bool canUseSkill( Character *ch, int sn )
{
    Reuse_wait *r;

    for( r = ch->reuse_wait ; r != NULL ; r = r->next )
        if ( r->gsn == sn )
            return FALSE;

    return TRUE;
}

void do_depractice( Character *ch, char *argument )
{
    Character *trainer;
    int sn, skill_points, i;
    char arg[MAX_INPUT_LENGTH];

    if ( IS_NPC(ch) )
    {
        cprintf(ch,"Only PC's can depractice.\n\r");
        return;
    }

    for( trainer = ch->in_room->people ; trainer ; trainer = trainer->next_in_room )
        if ( IS_NPC(trainer) && IS_SET(trainer->act,ACT_TRAIN) )
            break;

    if ( trainer == NULL )
    {
        cprintf(ch,"There is no <Trainer> here.\n\r");
        return;
    }

    argument = one_argument( argument, arg );
    if ( arg[0] == '\0' )
    {
        cprintf(ch,"Syntax:  depractice <skill>\n\r"
                   "         depractice <skill> full\n\r");
        return;
    }

    if ( (sn = skill_lookup(arg)) < 1 )
    {
        cprintf(ch,"No such skill.\n\r");
        return;
    }

    if ( skill_table[sn].type == SKILL_FOUNDATION ||
         skill_table[sn].type == SKILL_TRADE )
    {
        cprintf(ch,"You cannot depractice a trade skill.\n\r");
        return;
    }

    if ( ch->pcdata->deprac[DEPRACTICE] > current_time )
    {
        cprintf(ch,"You may not depractice again until %s.\n\r",
            format_date( ch->pcdata->deprac[DEPRACTICE], "%H:%M on %A, %d/%b/%Y" ) );
        return;
    }

    if ( ch->pcdata->learned[sn] <= 1 )
    {
        cprintf(ch,"You cannot depractice that skill.\n\r");
        return;
    }

    skill_points = 0;
    if ( argument[0] != '\0' && !str_prefix(argument,"full") )
    {
        for( i = ch->pcdata->learned[sn] ; i > 1 ; i-- )
            skill_points += i;
        ch->pcdata->deprac[DEPRACTICE] = current_time + (60*60*24*7); // one week
        ch->pcdata->learned[sn] = 1;
    }
    else
    {
        ch->pcdata->deprac[DEPRACTICE] = current_time + (60*60*24);
        skill_points = ch->pcdata->learned[sn];
        ch->pcdata->learned[sn]--;
    }

    ch->practice += skill_points;
    cprintf(ch,"You depractice your %s skill to %d, gaining back %d skill points.\n\r",
        skill_table[sn].name, ch->pcdata->learned[sn], skill_points );
    cprintf(ch,"You cannot depractice again until %s.\n\r",
                    format_date( ch->pcdata->deprac[DEPRACTICE], "%H:%M on %A, %d/%b/%Y" ) );
    return;
}

void do_detrain( Character *ch, char *argument )
{
    cprintf(ch,"This command is not yet implemented.\n\r");
    return;
}

void do_degain( Character *ch, char *argument )
{
    cprintf(ch,"This command is not yet implemented.\n\r");
    return;
}

void do_enemy( Character *ch, char *argument )
{
    Character *trainer;
    int race;

    if ( IS_NPC(ch) )
    {
        cprintf(ch,"Only PC's can declare a species enemy.\n\r");
        return;
    }

    if ( ch->class != class_lookup("ranger") )
    {
        cprintf(ch,"Only rangers may declare a species enemy.\n\r");
        return;
    }

    for( trainer = ch->in_room->people ; trainer ; trainer = trainer->next_in_room )
        if ( IS_NPC(trainer) && IS_SET(trainer->act,ACT_TRAIN) )
            break;

    if ( trainer == NULL )
    {
        cprintf(ch,"There is no <Trainer> here.\n\r");
        return;
    }

    if ( argument[0] == '\0' )
    {
        cprintf(ch,"Syntax:  enemy <race>\n\r"
                   "         enemy list (show all races)\n\r");
        return;
    }

    if ( !str_prefix(argument,"list") )
    {
        int race;

        for( race=1 ; race_table[race].name != NULL &&
                      str_cmp(race_table[race].name,"unique") 
                    ; race++ )
        {
            cprintf(ch," * %-16s", race_table[race].name);
            if ( race % 4 == 0 )
                cprintf(ch,"\n\r");
        }

        cprintf(ch,"\n\r");
        return;
    }

    if ( (race = race_lookup(argument)) < 1 ||
         race == race_lookup("unique") )
    {
        cprintf(ch,"No such race.\n\r");
        return;
    }

    if ( ch->race == race )
    {
        cprintf(ch,"You cannot declare your own race as your species enemy!\n\r");
        return;
    }

    if ( ch->pcdata->class_info.ranger.last_species_enemy + 60*60*24*7 > current_time )
    {
        cprintf(ch,"You may only change your species enemy once a week.\n\r");
        cprintf(ch,"You last changed at %s.\n\r", 
            format_date( ch->pcdata->class_info.ranger.last_species_enemy,
                         "%H:%M on %A, %d/%b/%Y" ) );
        return;
    }

    ch->pcdata->class_info.ranger.species_enemy = race;
    ch->pcdata->class_info.ranger.last_species_enemy = current_time;
    cprintf(ch,"You declare the %s race as your species enemy.\n\r",
        race_table[race].name );
    return;
}

bool isSpeciesEnemy( Character *victim, Character *ch )
{
    if ( !IS_NPC(victim) )
        return FALSE;

    if ( ch->class != csn_ranger )
        return FALSE;

    if ( ch->pcdata->class_info.ranger.species_enemy > 0 &&
         ch->pcdata->class_info.ranger.species_enemy == victim->race )
        return TRUE;

    return FALSE;
}

