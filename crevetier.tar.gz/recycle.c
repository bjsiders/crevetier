/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/
 
/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#if defined(macintosh)
#include <types.h>
#include <time.h>
#else
#include <sys/types.h>
#include <sys/time.h>
#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include "thoc.h"
#include "recycle.h"
#include "journal.h"

Faction *faction_data_free;

Faction *new_faction(void)
{
    static Faction faction_data_zero;
    Faction *faction_data;

    if (faction_data_free == NULL)
        faction_data = alloc_perm(sizeof(*faction_data));
    else
    {
        faction_data = faction_data_free;
        faction_data_free = faction_data_free->next;
    }

    *faction_data = faction_data_zero;
    VALIDATE(faction_data);
	faction_data->counter = 0;
	faction_data->standing = 0;
	faction_data->name = &str_empty[0];

    return faction_data;
}

void free_faction(Faction *faction_data)
{
    if (!IS_VALID(faction_data))
        return;

 	INVALIDATE(faction_data);
	free_string( faction_data->name );
    faction_data->next = faction_data_free;
    faction_data_free = faction_data;

    return;
}

Ignore 		*ignore_free;

Ignore *new_ignore( void )
{
    static Ignore ignore_zero;
    Ignore *ignore;

    if (ignore_free == NULL)
	    ignore = alloc_perm(sizeof(*ignore));
    else
    {
   		 ignore = ignore_free;
   		 ignore_free = ignore_free->next;
    }

    *ignore = ignore_zero;

	ignore->name = NULL;
	ignore->next = NULL;
    return ignore;
}

void free_ignore(Ignore *ignore)
{
    ignore->next = ignore_free;
    ignore_free = ignore;

    return;
}

Casting *casting_data_free;

Casting *new_casting_data(void)
{
    static Casting casting_data_zero;
    Casting *casting_data;

    if (casting_data_free == NULL)
    casting_data = alloc_perm(sizeof(*casting_data));
    else
    {
    casting_data = casting_data_free;
    casting_data_free = casting_data_free->next;
    }

    *casting_data = casting_data_zero;
    VALIDATE(casting_data);

    return casting_data;
}

void free_casting_data(Casting *casting_data)
{
    if (!IS_VALID(casting_data))
        return;

    INVALIDATE(casting_data);
    casting_data->next = casting_data_free;
    casting_data_free = casting_data;

    return;
}

Melee *melee_free;

Melee *new_melee( void )
{
    Melee *melee;

    if ( melee_free == NULL )
		melee = alloc_perm(sizeof(*melee));
    else
    {
		melee = melee_free;
		melee_free = melee_free->next;
    }

    melee->group = NULL;
    melee->damage = 0;
    melee->timer = 0;
	melee->disposition = 0;

	VALIDATE(melee);
    return melee;
}

void free_melee( Melee *melee )
{
    melee->group = NULL;
    melee->damage = 0;
    melee->timer = 0;
	melee->disposition = 0;

	INVALIDATE(melee);
    melee->next= melee_free;
    melee_free = melee;
}


Group *group_free;

Group *new_group( void  )
{
    Group *group;
    int i;

    if ( group_free == NULL )
        group = alloc_perm(sizeof(*group));
    else
    {
        group = group_free;
        group_free = group_free->next;
    }

    for ( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
	group->members[i] = NULL;

    VALIDATE(group);

    return group;
}

void free_group( Group *group )
{
    int i;

    if (!IS_VALID(group) )
	return;

    INVALIDATE(group);
    for ( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
        group->members[i] = NULL;

    group->next= group_free;
    group_free = group;
}

/* stuff for recyling notes */
Note *note_free;

Note *new_note()
{
    Note *note;

    if (note_free == NULL)
	note = alloc_perm(sizeof(*note));
    else
    { 
	note = note_free;
	note_free = note_free->next;
    }

	note->id = ++top_note_id;
    VALIDATE(note);
    return note;
}

void free_note(Note *note)
{
    if (!IS_VALID(note))
	return;

    free_string( note->text    );
    free_string( note->subject );
    free_string( note->to_list );
    free_string( note->date    );
    free_string( note->sender  );
    INVALIDATE(note);

    note->next = note_free;
    note_free   = note;
}

    
/* stuff for recycling ban structures */
BAN_DATA *ban_free;

BAN_DATA *new_ban(void)
{
    static BAN_DATA ban_zero;
    BAN_DATA *ban;

    if (ban_free == NULL)
	ban = alloc_perm(sizeof(*ban));
    else
    {
	ban = ban_free;
	ban_free = ban_free->next;
    }

    *ban = ban_zero;
    VALIDATE(ban);
    ban->name = &str_empty[0];
    return ban;
}

void free_ban(BAN_DATA *ban)
{
    if (!IS_VALID(ban))
	return;

    free_string(ban->name);
    INVALIDATE(ban);

    ban->next = ban_free;
    ban_free = ban;
}

/* stuff for recycling descriptors */
Descriptor *descriptor_free;

Descriptor *new_descriptor(void)
{
    static Descriptor d_zero;
    Descriptor *d;

    if (descriptor_free == NULL)
	d = alloc_perm(sizeof(*d));
    else
    {
	d = descriptor_free;
	descriptor_free = descriptor_free->next;
    }
	
    *d = d_zero;
	d->character = NULL;
	d->original  = NULL;
    VALIDATE(d);
    return d;
}

void free_descriptor(Descriptor *d)
{
    if (!IS_VALID(d))
	return;

    free_string( d->host );
    free_mem( d->outbuf, d->outsize );
    INVALIDATE(d);
    d->next = descriptor_free;
    descriptor_free = d;
}

/* stuff for recycling gen_data */
NewbieData *gen_data_free;

NewbieData *new_gen_data(void)
{
    static NewbieData gen_zero;
    NewbieData *gen;

    if (gen_data_free == NULL)
	gen = alloc_perm(sizeof(*gen));
    else
    {
	gen = gen_data_free;
	gen_data_free = gen_data_free->next;
    }
    *gen = gen_zero;
    VALIDATE(gen);
    return gen;
}

void free_gen_data(NewbieData *gen)
{
    if (!IS_VALID(gen))
	return;

    INVALIDATE(gen);

    gen->next = gen_data_free;
    gen_data_free = gen;
} 

/* stuff for recycling extended descs */
ExtraDescr *extra_descr_free;

ExtraDescr *new_extra_descr(void)
{
    ExtraDescr *ed;

    if (extra_descr_free == NULL)
	ed = alloc_perm(sizeof(*ed));
    else
    {
	ed = extra_descr_free;
	extra_descr_free = extra_descr_free->next;
    }

    ed->keyword = &str_empty[0];
    ed->description = &str_empty[0];
    VALIDATE(ed);
    return ed;
}

void free_extra_descr(ExtraDescr *ed)
{
    if (!IS_VALID(ed))
	return;

    free_string(ed->keyword);
    free_string(ed->description);
    INVALIDATE(ed);
    
    ed->next = extra_descr_free;
    extra_descr_free = ed;
}


/* stuff for recycling affects */
Affect *affect_free;

Affect *new_affect(void)
{
    static Affect af_zero;
    Affect *af;

    if (affect_free == NULL)
		af = alloc_perm(sizeof(*af));
    else
    {
		af = affect_free;
		affect_free = affect_free->next;
    }

    *af = af_zero;


	af->caster_id		= 0;
	af->bitvector		= 0;
	af->flags			= 0;
	af->misc			= 0;
    VALIDATE(af);
    return af;
}

void free_affect(Affect *af)
{
    if (!IS_VALID(af))
	return;

    INVALIDATE(af);
    af->next = affect_free;
    affect_free = af;
}

/* stuff for recycling objects */
Object *obj_free;

Object *new_obj(void)
{
    static Object obj_zero;
    Object *obj;

    if (obj_free == NULL)
		obj = alloc_perm(sizeof(*obj));
    else
    {
		obj = obj_free;
		obj_free = obj_free->next;
    }
    *obj = obj_zero;
    VALIDATE(obj);

	obj->artifact = NULL;
    return obj;
}

void free_obj(Object *obj)
{
    Affect *paf, *paf_next;
    ExtraDescr *ed, *ed_next;

    if (!IS_VALID(obj))
	return;

    for (paf = obj->affected; paf != NULL; paf = paf_next)
    {
	paf_next = paf->next;
	free_affect(paf);
    }
    obj->affected = NULL;

    for (ed = obj->extra_descr; ed != NULL; ed = ed_next )
    {
	ed_next = ed->next;
	free_extra_descr(ed);
     }
     obj->extra_descr = NULL;
   
    free_string( obj->name        );
    free_string( obj->description );
    free_string( obj->short_descr );
    free_string( obj->owner     );
	if ( obj->artifact != NULL )
		free_artifact( obj->artifact );
	obj->artifact = NULL;
    INVALIDATE(obj);

    obj->next   = obj_free;
    obj_free    = obj; 
}


/* stuff for recyling characters */
Character *char_free;

Character *new_char (void)
{
    static Character ch_zero;
    Character *ch;
    int i;

    if (char_free == NULL)
	ch = alloc_perm(sizeof(*ch));
    else
    {
	ch = char_free;
	char_free = char_free->next;
    }

    *ch				= ch_zero;
    VALIDATE(ch);
    ch->name                    = &str_empty[0];
    ch->short_descr             = &str_empty[0];
    ch->long_descr              = &str_empty[0];
    ch->description             = &str_empty[0];
    ch->prompt                  = &str_empty[0];
    ch->logon                   = current_time;
    ch->lines                   = PAGELEN;
    for (i = 0; i < 4; i++)
        ch->armor[i]            = 0;
    ch->position                = POS_STANDING;
    ch->stat_hit                     = 20;
    ch->max_stat_hit                 = 20;
	ch->base_hit					= 5;
	ch->max_base_hit				= 5;
    ch->mana                    = 20;
    ch->max_mana                = 20;
    ch->move                    = 100;
    ch->max_move                = 100;
    ch->melee_list		= NULL;
	ch->reuse_wait		= NULL;
	ch->wizclan = NULL;
    ch->pgroup			= new_group( );
    ch->pgroup->members[0] = ch;
	ch->shapeshifted = NULL;

    for (i = 0; i < MAX_STATS; i ++)
    {
        ch->perm_stat[i] = 13;
        ch->mod_stat[i] = 0;
    }

	memset( &(ch->pathing), 0, sizeof(ch->pathing) );
    return ch;
}


void free_char (Character *ch)
{
    Object *obj;
    Object *obj_next;
    Affect *paf;
    Affect *paf_next;

    if (!IS_VALID(ch))
		return;

    if (IS_NPC(ch))
		mobile_count--;

    for (obj = ch->carrying; obj != NULL; obj = obj_next)
    {
		obj_next = obj->next_content;
		extract_obj(obj);
    }

    for (paf = ch->affected; paf != NULL; paf = paf_next)
    {
		paf_next = paf->next;
		affect_remove(ch,paf);
    }

    if ( ch->pgroup != NULL )
		char_from_group(ch,ch->pgroup);

    free_group(ch->pgroup);
    free_string(ch->name);
    free_string(ch->short_descr);
    free_string(ch->long_descr);
    free_string(ch->description);
    free_string(ch->prompt);
    free_note  (ch->pnote);
    free_pcdata(ch->pcdata);

    ch->next = char_free;
    char_free  = ch;

    INVALIDATE(ch);
    return;
}

PCData *pcdata_free;

PCData *new_pcdata(void)
{
    int alias,friends_count;

    static PCData pcdata_zero;
    PCData *pcdata;

    if (pcdata_free == NULL)
	pcdata = alloc_perm(sizeof(*pcdata));
    else
    {
	pcdata = pcdata_free;
	pcdata_free = pcdata_free->next;
    }

    *pcdata = pcdata_zero;

    for (alias = 0; alias < MAX_ALIAS; alias++)
    {
	pcdata->alias[alias] = NULL;
	pcdata->alias_sub[alias] = NULL;
    }

    /* Null out friends list */
	for (friends_count = 0; friends_count < MAX_FRIENDS; friends_count++)
    {
	  pcdata->friends[friends_count] = NULL;
    }

	pcdata->consent = NULL;
	pcdata->journal = NULL;
	pcdata->ignore_list = NULL;
    pcdata->buffer = new_buf();
    VALIDATE(pcdata);
    return pcdata;
}
	

void free_pcdata(PCData *pcdata)
{
    int alias,friends_count;
	Ignore *ig, *ig_next;

    if (!IS_VALID(pcdata))
	return;

	free_make_guild(pcdata->pGuild );
    free_string(pcdata->pwd);
    free_string(pcdata->bamfin);
    free_string(pcdata->bamfout);
    free_string(pcdata->title);
	free_string(pcdata->note_signature);
    free_buf(pcdata->buffer);
   
	if ( pcdata->journal != NULL )
		freeJournal( pcdata->journal );
 
    for (alias = 0; alias < MAX_ALIAS; alias++)
    {
	free_string(pcdata->alias[alias]);
	free_string(pcdata->alias_sub[alias]);
    }

    /* Clean up friends list */
	for (friends_count = 0; friends_count < MAX_FRIENDS; friends_count++)
    {
	  free_string(pcdata->friends[friends_count]);
    }

	for( ig = pcdata->ignore_list ; ig ; ig = ig_next )
	{
		ig_next = ig->next;
		free_ignore( ig );
	}

	pcdata->ignore_list = NULL;

    INVALIDATE(pcdata);
    pcdata->next = pcdata_free;
    pcdata_free = pcdata;

    return;
}

	


/* stuff for setting ids */
long	last_pc_id;
long	last_mob_id;

long get_pc_id(void)
{
    int val;

    val = (current_time <= last_pc_id) ? last_pc_id + 1 : current_time;
    last_pc_id = val;
    return val;
}

long get_mob_id(void)
{
    last_mob_id++;
    return last_mob_id;
}

NPCMemory *mem_data_free;

/* procedures and constants needed for buffering */

Buffer *buf_free;

NPCMemory *new_mem_data(void)
{
    NPCMemory *memory;
  
    if (mem_data_free == NULL)
	memory = alloc_mem(sizeof(*memory));
    else
    {
	memory = mem_data_free;
	mem_data_free = mem_data_free->next;
    }

    memory->next = NULL;
    memory->id = 0;
    memory->reaction = 0;
    memory->when = 0;
    VALIDATE(memory);

    return memory;
}

void free_mem_data(NPCMemory *memory)
{
    if (!IS_VALID(memory))
	return;

    memory->next = mem_data_free;
    mem_data_free = memory;
    INVALIDATE(memory);
}



/* buffer sizes */
const int buf_size[MAX_BUF_LIST] =
{
    16,32,64,128,256,1024,2048,4096,8192,16384
};

/* local procedure for finding the next acceptable size */
/* -1 indicates out-of-boundary error */
int get_size (int val)
{
    int i;

    for (i = 0; i < MAX_BUF_LIST; i++)
	if (buf_size[i] >= val)
	{
	    return buf_size[i];
	}
    
    return -1;
}

Buffer *new_buf()
{
    Buffer *buffer;

    if (buf_free == NULL) 
	buffer = alloc_perm(sizeof(*buffer));
    else
    {
	buffer = buf_free;
	buf_free = buf_free->next;
    }

    buffer->next	= NULL;
    buffer->state	= Buffer_SAFE;
    buffer->size	= get_size(BASE_BUF);

    buffer->string	= alloc_mem(buffer->size);
    buffer->string[0]	= '\0';
    VALIDATE(buffer);

    return buffer;
}

Buffer *new_buf_size(int size)
{
    Buffer *buffer;
 
    if (buf_free == NULL)
        buffer = alloc_perm(sizeof(*buffer));
    else
    {
        buffer = buf_free;
        buf_free = buf_free->next;
    }
 
    buffer->next        = NULL;
    buffer->state       = Buffer_SAFE;
    buffer->size        = get_size(size);
    if (buffer->size == -1)
    {
        log_bug("new_buf: buffer size %d too large.",size);
        exit(1);
    }
    buffer->string      = alloc_mem(buffer->size);
    buffer->string[0]   = '\0';
    VALIDATE(buffer);
 
    return buffer;
}


void free_buf(Buffer *buffer)
{
    if (!IS_VALID(buffer))
	return;

    free_mem(buffer->string,buffer->size);
    buffer->string = NULL;
    buffer->size   = 0;
    buffer->state  = Buffer_FREED;
    INVALIDATE(buffer);

    buffer->next  = buf_free;
    buf_free      = buffer;
}

bool bprintf(Buffer *buffer, const char *str, ... )
{
    char        outbuf[MAX_STRING_LENGTH*2];
    va_list     ap;

    va_start( ap, str );
    vsnprintf(outbuf,sizeof(outbuf),str,ap);
    va_end( ap );

    return ( add_buf(buffer,outbuf) );
}
 
bool add_buf(Buffer *buffer, char *string)
{
    int len;
    char *oldstr;
    int oldsize;

    oldstr = buffer->string;
    oldsize = buffer->size;

    if (buffer->state == Buffer_OVERFLOW) /* don't waste time on bad strings! */
	return FALSE;

    len = strlen(buffer->string) + strlen(string) + 1;

    while (len >= buffer->size) /* increase the buffer size */
    {
	buffer->size 	= get_size(buffer->size + 1);
	{
	    if (buffer->size == -1) /* overflow */
	    {
		buffer->size = oldsize;
		buffer->state = Buffer_OVERFLOW;
		log_bug("buffer overflow past size %d",buffer->size);
		return FALSE;
	    }
  	}
    }

    if (buffer->size != oldsize)
    {
	buffer->string	= alloc_mem(buffer->size);

	strcpy(buffer->string,oldstr);
	free_mem(oldstr,oldsize);
    }

    strcat(buffer->string,string);
    return TRUE;
}


void clear_buf(Buffer *buffer)
{
    buffer->string[0] = '\0';
    buffer->state     = Buffer_SAFE;
}


char *buf_string(Buffer *buffer)
{
    return buffer->string;
}

struct make_guild *new_make_guild( void )
{
	struct make_guild *new;
	int i;

	if ( (new = (struct make_guild *) GC_MALLOC( sizeof(struct make_guild) )) == NULL )
		log_error("make_guild");

	new->name = NULL;
	new->leader = NULL;
	for( i = 0 ; i < GUILD_START_SIZE ; i++ )
		new->approve[i] = 0;

	return new;
}

void free_clan ( Clan *c )
{
	int i;

	free_string( c->name );
	free_string( c->founder );
	c->guild_points = 0;
	c->total_players = 0;
	c->founded = 0;
	c->hall = 0;
	c->flags = 0;
	for( i = 0; i < MAX_GUILD_RANK ; i++ )
	{
		if ( c->ranks[i].name )
			free_string( c->ranks[i].name );
		c->ranks[i].name = &str_empty[0];
		c->ranks[i].flags = 0;
	}

	return;
}

Reuse_wait	*reuse_free;
Reuse_wait *new_reuse( void )
{
    static Reuse_wait reuse_zero;
    Reuse_wait *reuse;
                                                                                                         
    if (reuse_free == NULL)
    	reuse = alloc_perm(sizeof(*reuse));
    else
    {
    	reuse = reuse_free;
    	reuse_free = reuse_free->next;
    }
                                                                                                         
    *reuse = reuse_zero;
                                                                                                         
    return reuse;
}


void free_reuse( Reuse_wait *reuse )
{
    reuse->next = reuse_free;
    reuse_free = reuse;
	return;
}

Clan *new_clan( void )
{
	Clan *new;
	int i;

	if ( (new = (Clan *) GC_MALLOC( sizeof(Clan) )) == NULL )
	{
		log_error("new_guild");
		return NULL;
	}

	new->name = &str_empty[0];
	new->founder = &str_empty[0];
	new->guild_points = 0;
	new->total_players = 0;
	new->founded = 0;
	new->hall = 0;
	new->flags = 0;
	for( i = 0; i < MAX_GUILD_RANK; i++ )
	{
		new->ranks[i].name = &str_empty[0];
		new->ranks[i].flags = 0;
	}

	return new;
}

void free_make_guild( struct make_guild *obj )
{
	if (obj == NULL )
		return;

	free_string( obj->name );
	obj->leader = NULL;
	GC_FREE( obj );
}


Track *track_data_free;

Track *new_tracking(void)
{
    static Track track_data_zero;
    Track *track_data;

    if (track_data_free == NULL)
    track_data = alloc_perm(sizeof(*track_data));
    else
    {
    track_data = track_data_free;
    track_data_free = track_data_free->next;
    }

    *track_data = track_data_zero;
    VALIDATE(track_data);

    track_data->who = NULL;
    track_data->arrive_dir = track_data->depart_dir = -1;
    track_data->arrive_time = track_data->arrive_time = 0;
    track_data->flags = 0;
    track_data->injury_percent = 0;
    track_data->weight_percent = 0;
    track_data->footwear_vnum = 0;

    return track_data;
}

void free_tracking(Track *track_data)
{
    if (!IS_VALID(track_data))
        return;   

    INVALIDATE(track_data);
    track_data->next = track_data_free;
    track_data_free = track_data;

    return;
}

Script *script_data_free;

Script *new_script(void)
{
    static Script script_data_zero;
    Script *script_data;

    if (script_data_free == NULL)
    	script_data = alloc_perm(sizeof(*script_data));
    else
    {
    	script_data = script_data_free;
    	script_data_free = script_data_free->next;
    }

    *script_data = script_data_zero;
    VALIDATE(script_data);
    script_data->name = &str_empty[0];
	script_data->script = &str_empty[0];

    return script_data;
}

void free_script(Script *script_data)
{
    if (!IS_VALID(script_data))
        return;

    if ( script_data->name != NULL )
        free_string( script_data->name );
	if ( script_data->script != NULL )
		free_string( script_data->script );

    INVALIDATE(script_data);
    script_data->next = script_data_free;
    script_data_free = script_data;

    return;
}

Resource *resource_data_free;

Resource *new_resource(void)
{
    static Resource resource_data_zero;
    Resource *resource_data;

    if (resource_data_free == NULL)
        resource_data = alloc_perm(sizeof(*resource_data));
    else
    {
        resource_data = resource_data_free;
        resource_data_free = resource_data_free->next;
    }

    *resource_data = resource_data_zero;

    return resource_data;
}

void free_resource(Resource *resource_data)
{
    resource_data->next = resource_data_free;
    resource_data_free = resource_data;

    return;
}

Building *building_data_free;

Building *new_building(void)
{
    static Building building_data_zero;
    Building *building_data;

    if (building_data_free == NULL)
    	building_data = alloc_perm(sizeof(*building_data));
    else
    {
    	building_data = building_data_free;
    	building_data_free = building_data_free->next;
    }

    *building_data = building_data_zero;
    VALIDATE(building_data);

    return building_data;
}

void free_building(Building *building_data)
{
    if (!IS_VALID(building_data))
        return;

    INVALIDATE(building_data);
    building_data->next = building_data_free;
    building_data_free = building_data;

    return;
}

Artifact *artifact_data_free;

Artifact *new_artifact(void)
{
    static Artifact artifact_data_zero;
    Artifact *artifact_data;

    if (artifact_data_free == NULL)
        artifact_data = alloc_perm(sizeof(*artifact_data));
    else
    {
         artifact_data = artifact_data_free;
         artifact_data_free = artifact_data_free->next;
    }

    *artifact_data = artifact_data_zero;
    VALIDATE(artifact_data);

    return artifact_data;
}

void free_artifact(Artifact *artifact_data)
{
    if (!IS_VALID(artifact_data))
        return;

    INVALIDATE(artifact_data);
    artifact_data->next = artifact_data_free;
    artifact_data_free = artifact_data;

    return;
}

Account *account_data_free;

Account *new_account(void)
{
    static Account account_data_zero;
    Account *account_data;

    if (account_data_free == NULL)
    	account_data = alloc_perm(sizeof(*account_data));
    else
    {
    	account_data = account_data_free;
    	account_data_free = account_data_free->next;
    }

    *account_data = account_data_zero;
    VALIDATE(account_data);

	memset( account_data->characters, 0, sizeof(account_data->characters) );
	account_data->name = &str_empty[0];
	account_data->flags = 0;
	account_data->create_date = 0;

    return account_data;
}

void free_account(Account *account_data)
{
    if (!IS_VALID(account_data))
        return;

    INVALIDATE(account_data);

	if ( account_data->name != &str_empty[0] )
		free_string( account_data->name );

	memset( account_data->characters, 0, sizeof(account_data->characters) );
 
    account_data->next = account_data_free;
    account_data_free = account_data;

    return;
}

Firing *firing_data_free;

Firing *new_firing_data(void)
{
    static Firing firing_data_zero;
    Firing *firing_data;

    if (firing_data_free == NULL)
        firing_data = alloc_perm(sizeof(*firing_data));
    else
    {
        firing_data = firing_data_free;
        firing_data_free = firing_data_free->next;
    }

    *firing_data = firing_data_zero;
    VALIDATE(firing_data);

    return firing_data;
}

void free_firing_data(Firing *firing_data)
{
    if (!IS_VALID(firing_data))
        return;

    INVALIDATE(firing_data);
    firing_data->next = firing_data_free;
    firing_data_free = firing_data;

    return;
}

