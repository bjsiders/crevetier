/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <sys/stat.h>
#include "thoc.h"
#include "recycle.h"
#include "lookup.h"
#include "tables.h"
#include "journal.h"
#include "olc.h"
#include "options.h"
#include "db.h"

#define SAVE_MODE (S_IRWXU|S_IRWXG|S_IROTH|S_IXOTH)

#if !defined(macintosh)
extern  int     _filbuf         (FILE *);
#endif

char *globalSaving;

Journal *readJournal( FILE *fp );
void writeJournal( FILE *fp, Journal *j );
void writeJEvents( FILE *fp, JEvent *je );
int rewardExtraSkillPoints( Character *ch );
int rename(const char *oldfname, const char *newfname);
void writeAffectList( FILE *fp, Affect *paf );
void writeAffectListPrefixed( FILE *fp, Affect *paf, char *prefix );
Character *createShifted( Character *ch, int vnum, int skill );
Character *createShiftedStats( Character *ch, int vnum, int skill,
                            int hp, int max_hp,
                            int base, int max_base_hp,
                            int stamina, int max_stamina,
                            int move, int max_move );


void assignSubrace( Character *ch )
{
	/* Assign to first subrace that can be that class */
	int i;

	for( i = 1 ; subrace_table[i].name != NULL ; i++ )
	{
		if ( subrace_table[i].race_index != NULL &&
			*subrace_table[i].race_index == ch->race &&
			subrace_table[i].class_mult[ch->class] == TRUE )
		{
			ch->pcdata->subrace = i;
			return;
		}
	}

	log_bug("Unable to assign a new subrace for %s",ch->name);
	return;
}

char *print_longflags(long long flag)
{
    int count, pos = 0;
    static char buf[100];

	// A-Z, a-z 26 + 26 = 52 flags
    for (count = 0; count < 52;  count++)
    {
        if (IS_SET(flag,1<<count))
        {
            if (count < 26)
                buf[pos] = 'A' + count;
            else
                buf[pos] = 'a' + (count - 26);
            pos++;
        }
    }

    if (pos == 0)
    {
        buf[pos] = '0';
        pos++;
    }

    buf[pos] = '\0';

    return buf;
}

char *print_flags(int flag)
{
    int count, pos = 0;
    static char buf[52];

    for (count = 0; count < 32;  count++)
    {
        if (IS_SET(flag,1<<count))
        {
            if (count < 26)
                buf[pos] = 'A' + count;
            else
                buf[pos] = 'a' + (count - 26);
            pos++;
        }
    }

    if (pos == 0)
    {
        buf[pos] = '0';
        pos++;
    }

    buf[pos] = '\0';

    return buf;
}


/*
 * Array of containers read for proper re-nesting of objects.
 */
#define MAX_NEST	100
static	Object *	rgObjNest	[MAX_NEST];



/*
 * Local functions.
 */
void	save_vaults	( void );
void	fwrite_vault	( Room *r  );
void	fwrite_vault_list	( void  );

void	fwrite_char	( Character *ch,  FILE *fp  );
void	fwrite_obj	( void * vo, Object  *obj,
			    FILE *fp, int iNest, bool fBank, bool fVault  );
void	fwrite_pet	( Character *pet, FILE *fp );
void	fread_char	( Character *ch,  FILE *fp  );
void    fread_pet	( Character *ch,  FILE *fp  );
void	fread_obj	( void *vo,  FILE *fp, bool fBank, bool fVault  );
void	obj_to_bank	( Character *ch, Object *obj  );

/*
 * Save clan vaults 
 *
 * The list of vaults is kept in vault.lst.  Each of those files
 * is then loaded.  Vault files are named like:  R<vnum>.vault
 *
 */
void save_vaults( void )
{
    static bool saving;
    int i;

    if ( saving == TRUE )
		return;
    else
		saving = TRUE;

    fwrite_vault_list( );

    for ( i = 0 ; i < 35000 ; i++ )
    {
        Room *r;

        if ( (r=get_room_index(i)) != NULL && r->contents != NULL &&
			(IS_SET(r->room_flags,ROOM_CLAN_VAULT) || room_has_pc_corpse(r)) )
               fwrite_vault( r );
    }

    saving = FALSE;
    return;
}

void fwrite_vault_list( void )
{
    char strsave[MAX_INPUT_LENGTH];
    FILE *fp;
    int i;
    Room *r;

    fclose( fpReserve );
    sprintf( strsave, "%s", VAULT_LIST );
    if ( ( fp = fopen( strsave, "w" ) ) == NULL )
    {
        log_bug( "fwrite_vault_list: fopen", 0 );
        log_error( strsave );
    }

    for ( i=1 ; i<35000 ; i++ )
    {
		if ( (r = get_room_index(i) ) != NULL && r->contents != NULL &&
	     	(IS_SET(r->room_flags,ROOM_CLAN_VAULT) || room_has_pc_corpse(r)) )
	    fprintf(fp,"%sR%d.vault\n",getDirectory(AREA_DIR), r->vnum);
    }

    fprintf(fp,"$\n");
    fclose( fp );
    rename(TEMP_FILE,strsave);
    fpReserve = fopen( NULL_FILE, "r" );
    return;
}

void fwrite_vault( Room *r )
{
    char strsave[MAX_INPUT_LENGTH];
    FILE *fp;

    fclose( fpReserve );
    sprintf( strsave, "%sR%d.vault", getDirectory(AREA_DIR), r->vnum );
    if ( ( fp = fopen( strsave, "w" ) ) == NULL )
    {
        log_bug( "save_vaults: fopen", 0 );
        log_error( strsave );
    }
    else
    {
        fwrite_obj( r, r->contents, fp, 0, FALSE, TRUE );
        fprintf( fp, "#END\n" );
    }
    fclose( fp );
    rename(TEMP_FILE,strsave);
    fpReserve = fopen( NULL_FILE, "r" );
    return;
}

void writeFactionsToPFile( Faction *f, FILE *fp )
{
	if ( f->next != NULL )
		writeFactionsToPFile( f->next, fp );

	fprintf(fp,"Fact %d %ld\n", f->factionID, f->counter );
}

/*
 * Save a character and inventory.
 * Would be cool to save NPC's too for quest purposes,
 *   some of the infrastructure is provided.
 */
void save_char_obj( Character *ch )
{
    char strsave[MAX_INPUT_LENGTH];
    FILE *fp;

    if ( IS_NPC(ch) )
		return;

	if ( globalSaving != NULL )
		return;

#if defined(__OLC)  || defined(__TEST)
    return;
#endif

	// Handle crashes during pfile saves
	globalSaving = ch->name;

	log_string("[Saving] %s", ch->name);
    if ( ch->desc != NULL && ch->desc->original != NULL )
		ch = ch->desc->original;

    fclose( fpReserve );
    sprintf( strsave, "%s/%s", getDirectory(PLAYER_DIR), capitalize( ch->name ) );

	/* Back it up */
	{
		char command[MAX_INPUT_LENGTH];
		snprintf(command,sizeof(command),"cp %s %s.bak",strsave,strsave);
		system(command);
	}

    if ( ( fp = fopen( strsave, "w" ) ) == NULL )
    {
	log_bug( "Save_char_obj: fopen", 0 );
	log_error( strsave );
    }
    else
    {
		log_string("  * writing character");
		fwrite_char( ch, fp );
		log_string("  * writing inventory");
		if ( ch->carrying != NULL )
	    	fwrite_obj( ch, ch->carrying, fp, 0, FALSE, FALSE );
		log_string("  * writing bank");
		if ( ch->pcdata->bank != NULL )
	    	fwrite_obj( ch, ch->pcdata->bank, fp, 0, TRUE, FALSE );

	fprintf( fp, "#END\n" );
    }
    fclose( fp );
    rename(TEMP_FILE,strsave);
	chmod( strsave, SAVE_MODE );
    fpReserve = fopen( NULL_FILE, "r" );
	globalSaving = NULL;
    return;
}

void writeIgnores( FILE *fp, Ignore *i )
{
	if ( i->next != NULL )
		writeIgnores( fp, i->next );

	fprintf( fp, "Ignore %s~\n", i->name );
	return;
}

/*
 * Write the char.
 */
void fwrite_char( Character *ch, FILE *fp )
{
    int sn, gn, pos, friends_count;
	Reuse_wait	*r;
	int i, nMatch = 0;

    fprintf( fp, "#%s\n", IS_NPC(ch) ? "MOB" : "PLAYER"	);

    fprintf( fp, "Name %s~\n",	ch->name		);
    fprintf( fp, "Id   %ld\n", ch->id			);
    fprintf( fp, "LogO %ld\n",	(long) current_time		);
    fprintf( fp, "Vers %d\n",   27 );
    if ( ch->pcdata->email != NULL )
        fprintf( fp, "Email %s~\n", ch->pcdata->email );
    if (ch->short_descr[0] != '\0')
      	fprintf( fp, "ShD  %s~\n",	ch->short_descr	);
    if( ch->long_descr[0] != '\0')
	fprintf( fp, "LnD  %s~\n",	ch->long_descr	);
    if (ch->description[0] != '\0')
    	fprintf( fp, "Desc %s~\n",	ch->description	);
    if (ch->prompt != NULL || !str_cmp(ch->prompt,"<%bbase %hhits %mmana %sstam %vmoves> "))
        fprintf( fp, "Prom %s~\n",      ch->prompt  	);
    fprintf( fp, "Cla  %d\n",	ch->class		);
    fprintf( fp, "Race %s~\n", pc_race_table[ch->race].name );
	if ( ch->pcdata->subrace > 0 )
		fprintf( fp, "SubR %s~\n", subrace_table[ch->pcdata->subrace].name);

    if (ch->clan)
    {
    	fprintf( fp, "Clan %s~\n",ch->clan->name );
    	fprintf( fp, "CFlag %s\n", print_flags( ch->pcdata->clan_flags ) );
    }
	fprintf( fp, "LPD %ld\n", (long) ch->pcdata->last_pdeath );
	fprintf( fp, "LL %ld\n", (long) ch->pcdata->date_last_level );
	fprintf( fp, "GuiF %s\n", print_flags(ch->gui) );
	fprintf( fp, "GuildP %ld\n", ch->pcdata->guild_points );
	fprintf( fp, "ClanR %d\n", ch->pcdata->guild_rank );
    fprintf( fp, "TZI %d\n", ch->pcdata->tzindex );
    fprintf( fp, "Sex  %d\n",	ch->sex			);
    fprintf( fp, "Levl %d\n",	ch->level		);
	if( ch->pcdata->lost_xp > 0 )
		fprintf(fp, "XPL %ld\n", ch->pcdata->lost_xp );
	if( ch->pcdata->deaths > 0 )
		fprintf(fp, "PDth %d\n", ch->pcdata->deaths );
	if( ch->pcdata->kills > 0 )
		fprintf(fp, "PKls %d\n", ch->pcdata->kills );
    if (ch->trust != 0)
	fprintf( fp, "Tru  %d\n",	ch->trust	);
    fprintf( fp, "Sec  %d\n",    ch->pcdata->security	);	/* OLC */
	fprintf( fp, "Host %s~\n", ch->pcdata->host );
	fprintf( fp, "RV %d\n",	ch->pcdata->recall_vnum );
    fprintf( fp, "Plyd %d\n", ch->played + (int) (current_time - ch->logon)	);
    fprintf( fp, "Not  %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld\n",
		(long) ch->pcdata->last_reads[NOTE_NOTE],
		(long) ch->pcdata->last_reads[NOTE_IDEA],
		(long) ch->pcdata->last_reads[NOTE_PENALTY],
		(long) ch->pcdata->last_reads[NOTE_NEWS],
		(long) ch->pcdata->last_reads[NOTE_CHANGES],
		(long) ch->pcdata->last_reads[NOTE_BUG],
		(long) ch->pcdata->last_reads[NOTE_APPEAL],
		(long) ch->pcdata->last_reads[NOTE_ADMIN],
		(long) ch->pcdata->last_reads[NOTE_CLAN],
		(long) ch->pcdata->last_reads[NOTE_FIX],
		(long) ch->pcdata->last_reads[NOTE_TODO],
		(long) ch->pcdata->last_reads[NOTE_PATCH],
		(long) ch->pcdata->last_reads[NOTE_SYSTEM],
		(long) ch->pcdata->last_reads[NOTE_WORLD],
		(long) ch->pcdata->last_reads[NOTE_OFFLINE] );
    fprintf( fp, "Scro %d\n", 	ch->lines		);
    fprintf( fp, "Room %d\n",
        (  ch->in_room == get_room_index( ROOM_VNUM_LIMBO )
        && ch->was_in_room != NULL )
            ? ch->was_in_room->vnum
            : ch->in_room == NULL ? 3001 : ch->in_room->vnum );

	/* Write perm stats */
	fprintf( fp, "PST %d %d %d %d %d\n",
		ch->pcdata->perm_base_hit,
		ch->pcdata->perm_stat_hit,
		ch->pcdata->perm_mana,
		ch->pcdata->perm_move,
		ch->pcdata->perm_stamina );

    fprintf( fp, "MV  %d %d %d %d\n",
		 ch->mana, ch->max_mana, ch->move, ch->max_move );
    fprintf( fp, "SSS %d %d %d %d %d %d\n",
		ch->base_hit, ch->max_base_hit, ch->stat_hit, ch->max_stat_hit,
		ch->stamina, ch->max_stamina );

	fprintf( fp, "BuildDead %ld\n",(long)ch->pcdata->build_deadline );
	fprintf( fp, "BuildDM %s~\n",ch->pcdata->build_daymonth );
		
	/* Write equipment ordering out */
	fprintf( fp, "Elo ");
	for( i = 0 ; i < MAX_WEAR ; i++ )
		fprintf(fp, "%d ", ch->pcdata->eq_list_order[i] );
	fprintf( fp, "\n");

    fprintf( fp, "Deity %s~\n", deity_table[ch->deity].name	);

	if ( ch->playing > 0 )
	{
		SpellIndex* pSpellIndex;

		if( (pSpellIndex = get_spell_index(ch->playing)) != NULL)
			fprintf( fp, "Playing %s~\n", pSpellIndex->name );
		else
			log_bug("fwrite_char(playing): Spell index not found(%d)",ch->playing);
	}

    /* Class specific information */
    if( ch->class == class_lookup("ranger") )
    {
        fprintf(fp, "SpecEnemy %s~\n", 
            race_table[ch->pcdata->class_info.ranger.species_enemy].name );

        fprintf(fp, "LastSpecEnemy %d\n", 
            ch->pcdata->class_info.ranger.last_species_enemy );
    }

    fprintf( fp, "Bounty %ld\n", ch->pcdata->bounty	);
    fprintf( fp, "Gold %ld %ld\n",	ch->coins[CUR_GOLD],ch->pcdata->coins_bank[CUR_GOLD]	);
    fprintf( fp, "Silv %ld %ld\n",	ch->coins[CUR_SILVER],ch->pcdata->coins_bank[CUR_SILVER] );
    fprintf( fp, "Elect %ld %ld\n", ch->coins[CUR_ELECTRUM], ch->pcdata->coins_bank[CUR_ELECTRUM] );
    fprintf( fp, "Plati %ld %ld\n", ch->coins[CUR_PLATINUM], ch->pcdata->coins_bank[CUR_PLATINUM] );
    fprintf( fp, "Alati %ld %ld\n",	ch->coins[CUR_ALATINUM], ch->pcdata->coins_bank[CUR_ALATINUM]	);

    fprintf( fp, "Exp  %ld\n",	ch->exp			);
    fprintf( fp, "SExp %ld\n",	ch->pcdata->spec_exp );
	fprintf( fp, "SLvl %d\n", ch->pcdata->spec_level );
    fprintf( fp, "SSpl %d\n",	ch->pcdata->split );
	fprintf( fp, "SpecP %d\n",	ch->pcdata->spec_points );
    /*fprintf( fp, "SkP  %ld\n",	ch->skill_points	);*/
    if (ch->act != 0)
	fprintf( fp, "Act  %s\n",   print_flags(ch->act));
    if (ch->affected_by != 0)
	fprintf( fp, "AfBy %s\n",   print_flags(ch->affected_by));
    fprintf( fp, "Comm %s\n",       print_flags(ch->comm));
    fprintf( fp, "Disp %s\n",	    print_flags(ch->display));
	fprintf( fp, "Opt %s\n",		print_flags(ch->pcdata->options));
	fprintf( fp, "ScoreOpt %s\n",	print_flags(ch->pcdata->score_options));
	fprintf( fp, "AutoOpt %s\n",	print_flags(ch->pcdata->auto_options));
	fprintf( fp, "ColorOpt %s\n",	print_flags(ch->pcdata->color_options));
	fprintf( fp, "CommOpt %s\n",	print_flags(ch->pcdata->comm_options));
    if (ch->pcdata->worth_columns > 0 )
   	fprintf(fp,"WoCo %d\n",	ch->pcdata->worth_columns);

    fprintf( fp, "Creat %ld\n", (long) ch->created );
    if (ch->wiznet)
    	fprintf( fp, "Wizn %s\n",   print_flags(ch->wiznet));
	if ( ch->pcdata->pnet)
		fprintf( fp, "Pnet %s\n",	print_flags(ch->pcdata->pnet));
    if (ch->invis_level)
	fprintf( fp, "Invi %d\n", 	ch->invis_level	);
    if (IS_IMMORTAL(ch))
	fprintf( fp, "IRole %d\n",	ch->pcdata->imm_role );
    if (ch->incog_level)
	fprintf(fp,"Inco %d\n",ch->incog_level);
    fprintf( fp, "Pos  %d\n",	
	ch->position == POS_FIGHTING ? POS_STANDING : ch->position );
    if (ch->practice != 0)
    	fprintf( fp, "Prac %d\n",	ch->practice	);
    if (ch->train != 0)
	fprintf( fp, "Trai %d\n",	ch->train	);
    if (ch->saving_throw != 0)
	fprintf( fp, "Save  %d\n",	ch->saving_throw);
    if (ch->hitroll != 0)
	fprintf( fp, "Hit   %d\n",	ch->hitroll	);
    if (ch->damroll != 0)
	fprintf( fp, "Dam   %d\n",	ch->damroll	);
    fprintf( fp, "ACs %d %d %d %d\n",	
	ch->armor[0],ch->armor[1],ch->armor[2],ch->armor[3]);
    if (ch->wimpy !=0 )
	fprintf( fp, "Wimp  %d\n",	ch->wimpy	);
    fprintf( fp, "Attr %d %d %d %d %d %d\n",
	ch->perm_stat[STAT_STR],
	ch->perm_stat[STAT_DEX],
	ch->perm_stat[STAT_CON],
	ch->perm_stat[STAT_INT],
	ch->perm_stat[STAT_WIS],
	ch->perm_stat[STAT_CHA] );

    fprintf (fp, "AMod %d %d %d %d %d %d\n",
	ch->mod_stat[STAT_STR],
	ch->mod_stat[STAT_DEX],
	ch->mod_stat[STAT_CON],
	ch->mod_stat[STAT_INT],
	ch->mod_stat[STAT_WIS],
	ch->mod_stat[STAT_CHA] );

	fprintf( fp, "AStart %d %d %d %d %d %d\n",
		ch->pcdata->start_stat[STAT_STR],
		ch->pcdata->start_stat[STAT_DEX],
		ch->pcdata->start_stat[STAT_CON],
		ch->pcdata->start_stat[STAT_INT],
		ch->pcdata->start_stat[STAT_WIS],
		ch->pcdata->start_stat[STAT_CHA] );

    fprintf(fp, "LastBhG %d\n", ch->pcdata->last_basegain );
    fprintf(fp, "LastShG %d\n", ch->pcdata->last_statgain );
    fprintf(fp, "LastMaG %d\n", ch->pcdata->last_managain );
    fprintf(fp, "LastMvG %d\n", ch->pcdata->last_movegain );
    fprintf(fp, "LastStG %d\n", ch->pcdata->last_stamgain );
    fprintf(fp, "LastPrG %d\n", ch->pcdata->last_primegain );
    fprintf(fp, "LastSeG %d\n", ch->pcdata->last_secondgain );
    fprintf(fp, "LastTrG %d\n", ch->pcdata->last_traingain );
    fprintf(fp, "LastSkG %d\n", ch->pcdata->last_skillgain );

    if ( ch->factions != NULL )
		writeFactionsToPFile( ch->factions, fp );

	/* Write out any re-use states we have pending */
	for( r = ch->reuse_wait ; r ; r = r->next )
		fprintf( fp, "RuW %d %d %d\n", r->gsn, r->type, r->timer );

    if ( IS_NPC(ch) )
    {
		fprintf( fp, "Vnum %d\n",	ch->pIndexData->vnum	);
    }
    else
    {
	int pn;

	fprintf( fp, "Pass %s~\n",	ch->pcdata->pwd		);
	if (ch->pcdata->bamfin[0] != '\0')
	    fprintf( fp, "Bin  %s~\n",	ch->pcdata->bamfin);
	if (ch->pcdata->bamfout[0] != '\0')
		fprintf( fp, "Bout %s~\n",	ch->pcdata->bamfout);
	fprintf( fp, "Titl %s~\n",	ch->pcdata->title	);
	fprintf( fp, "NSig %s~\n",  ch->pcdata->note_signature );
	fprintf( fp, "TSex %d\n",	ch->pcdata->true_sex	);
	fprintf( fp, "LLev %d\n",	ch->pcdata->last_level	);
	fprintf( fp, "Cnd  %d %d %d %d\n",
	    ch->pcdata->condition[0],
	    ch->pcdata->condition[1],
	    ch->pcdata->condition[2],
	    ch->pcdata->condition[3] );

    fprintf( fp, "Dptg %d %d %d\n",
        ch->pcdata->deprac[DEPRACTICE],
        ch->pcdata->deprac[DETRAIN],
        ch->pcdata->deprac[DEGAIN] );

	fprintf(fp,"CCC ");
	for( pos = 0 ; pos < MAX_CHANNELS; pos++ )
	    fprintf(fp,"%d ",(int) ch->pcdata->customChannelColor[pos] );
	fprintf(fp,"CSayC %d\n",(int) ch->pcdata->customSayColor );
	fprintf(fp,"CTellC %d\n",(int) ch->pcdata->customTellColor );
	fprintf(fp,"CGTellC %d\n",(int) ch->pcdata->customGTellColor );
	fprintf(fp,"CRoundTableC %d\n",(int) ch->pcdata->customRoundTableColor );
	fprintf(fp,"CRTSubC %d\n",(int) ch->pcdata->customRTSubColor );

	fprintf(fp,"\n");
	for ( pos=0 ; pos < MAX_RESIST; pos++ )
	    fprintf(fp,"Rz %d %d %d\n",pos,ch->resists[pos].value,
		ch->resists[pos].mod);

	if ( ch->pcdata->ignore_list != NULL )
		writeIgnores( fp, ch->pcdata->ignore_list );

	for( i=0; i<MAX_SPELL_SLOT; i++ )
	{
		if ( ch->pcdata->spell_slots[i] > 0 )
		{
			SpellIndex* pSpellIndex;

			if( (pSpellIndex = get_spell_index(ch->pcdata->spell_slots[i])) != NULL)
				fprintf(fp,"SpellSlot %d %s~\n", i, pSpellIndex->name );
			else
				log_bug("fwrite_char(spell_slots): Spell index not found(%d)",ch->pcdata->spell_slots[i]);
		}
	}

	/* write alias */
    for (pos = 0; pos < MAX_ALIAS; pos++)
	{
	    if (ch->pcdata->alias[pos] == NULL
	    ||  ch->pcdata->alias_sub[pos] == NULL)
		break;

	    fprintf(fp,"Alias %s %s~\n",ch->pcdata->alias[pos],
		    ch->pcdata->alias_sub[pos]);
	}

	
	/* write friends */
	for(friends_count = 0; friends_count < MAX_FRIENDS; friends_count++)
	{
		if(ch->pcdata->friends[friends_count] == NULL)
			break;
		fprintf(fp,"Friend %s\n",ch->pcdata->friends[friends_count]);
	}

    for( sn =0 ; sn < MAX_WEAPONS ; sn++ )
        if ( ch->pcdata->specialized[sn] > 0 )
            fprintf(fp,"WF '%s' %d\n", weapon_table[sn].name, ch->pcdata->specialized[sn] );

    for ( sn = 0; nMatch < top_spell_index; sn++ )
	{
		SpellIndex* pSpellIndex;

		if ( ( pSpellIndex = get_spell_index( sn ) ) != NULL )
		{
			nMatch++;
			
			if ( pSpellIndex->name != NULL && ch->pcdata->spells[sn] > 0 )
			{
				fprintf( fp, "Sp %d '%s'\n", ch->pcdata->spells[sn], pSpellIndex->name );
			}
		}
	}
		
	for ( sn = 0; sn < MAX_SKILL; sn++ )
	{
	    if ( skill_table[sn].name != NULL && ch->pcdata->learned[sn] > 0 )
	    {
		fprintf( fp, "Sk %d '%s'\n",
		    ch->pcdata->learned[sn], skill_table[sn].name );
	    }
	}

	for ( pn = 0 ; pn < MAX_PROFICIENCY ; pn++ )
   	{
	    if ( prof_table[pn].name != NULL  && ch->pcdata->profs[pn] > 0 )
	    {
	 	fprintf( fp, "Pr '%s'\n", prof_table[pn].name );
	    }
	}

	for ( gn = 0; gn < MAX_GROUP; gn++ )
        {
            if ( group_table[gn].name != NULL && ch->pcdata->group_known[gn])
            {
                fprintf( fp, "Gr '%s'\n",group_table[gn].name);
            }
        }

    }

	if ( ch->pcdata->journal )
		writeJournal( fp, ch->pcdata->journal );

	writeAffectList( fp, ch->affected );

	if ( ch->shapeshifted != NULL )
	{
		Character *sh = ch->shapeshifted;

		fprintf(fp,"ShapeShift %d %d %d %d %d %d %d %d %d\n", 
						sh->pIndexData->vnum,
						sh->max_stat_hit, sh->stat_hit,
						sh->max_base_hit, sh->base_hit,
						sh->max_stamina, sh->stamina,
						sh->max_move, sh->move );
		writeAffectListPrefixed( fp, sh->affected, "SS" );
	}

    fprintf( fp, "End\n\n" );
    return;
}

/* write a pet */
void fwrite_pet( Character *pet, FILE *fp)
{
    Affect *paf;
    
    fprintf(fp,"#PET\n");
    
    fprintf(fp,"Vnum %d\n",pet->pIndexData->vnum);
    
    fprintf(fp,"Name %s~\n", pet->name);
    fprintf(fp,"LogO %ld\n", (long) current_time);
    if (pet->short_descr != pet->pIndexData->short_descr)
    	fprintf(fp,"ShD  %s~\n", pet->short_descr);
    if (pet->long_descr != pet->pIndexData->long_descr)
    	fprintf(fp,"LnD  %s~\n", pet->long_descr);
    if (pet->description != pet->pIndexData->description)
    	fprintf(fp,"Desc %s~\n", pet->description);
    if (pet->race != pet->pIndexData->race)
    	fprintf(fp,"Race %s~\n", race_table[pet->race].name);
    if (pet->clan)
        fprintf( fp, "Clan %s~\n",pet->clan->name );
    fprintf(fp,"Sex  %d\n", pet->sex);
    if (pet->level != pet->pIndexData->level)
    	fprintf(fp,"Levl %d\n", pet->level);
    fprintf(fp, "MV  %d %d %d %d\n",
    	 pet->mana, pet->max_mana, pet->move, pet->max_move);
    if (pet->exp > 0)
    	fprintf(fp, "Exp  %ld\n", pet->exp);
    if (pet->act != pet->pIndexData->act)
    	fprintf(fp, "Act  %s\n", print_flags(pet->act));
    if (pet->affected_by != pet->pIndexData->affected_by)
    	fprintf(fp, "AfBy %s\n", print_flags(pet->affected_by));
    if (pet->comm != 0)
    	fprintf(fp, "Comm %s\n", print_flags(pet->comm));
    fprintf(fp,"Pos  %d\n", pet->position = POS_FIGHTING ? POS_STANDING : pet->position);
    if (pet->saving_throw != 0)
    	fprintf(fp, "Save %d\n", pet->saving_throw);
    if (pet->hitroll != pet->pIndexData->hitroll)
    	fprintf(fp, "Hit  %d\n", pet->hitroll);
    if (pet->damroll != pet->pIndexData->damage[DICE_BONUS])
    	fprintf(fp, "Dam  %d\n", pet->damroll);
    fprintf(fp, "ACs  %d %d %d %d\n",
    	pet->armor[0],pet->armor[1],pet->armor[2],pet->armor[3]);
    fprintf(fp, "Attr %d %d %d %d %d\n",
    	pet->perm_stat[STAT_STR], pet->perm_stat[STAT_INT],
    	pet->perm_stat[STAT_WIS], pet->perm_stat[STAT_DEX],
    	pet->perm_stat[STAT_CON]);
    fprintf(fp, "AMod %d %d %d %d %d\n",
    	pet->mod_stat[STAT_STR], pet->mod_stat[STAT_INT],
    	pet->mod_stat[STAT_WIS], pet->mod_stat[STAT_DEX],
    	pet->mod_stat[STAT_CON]);
    for ( paf = pet->affected; paf != NULL; paf = paf->next )
    {
    	if (paf->type < 0 || paf->type >= MAX_SKILL)
    	    continue;
    
    	fprintf(fp, "Affc '%s' %3d %3d %d %3d %3d %10d\n",
    	    skill_table[paf->type].name,
    	    paf->where, paf->level, 
			paf->location == APPLY_BLADETURN ?  paf->duration : UMAX(0,paf->duration-current_time), paf->modifier,paf->location,
    	    paf->bitvector);
    }
    
    fprintf(fp,"End\n");
    return;
}
   
 
/*
 * Write an object and its contents.
    fpri
 */
void fwrite_obj( void *vo, Object *obj, FILE *fp, int iNest, bool fBank, bool fVault )
{
    Character *ch=NULL;
    Room *r;
    ExtraDescr *ed;
    extern bool fCrashing;

    if ( !fVault )
		ch = (Character *) vo;
    else
		r = (Room *) vo;

    /*
     * Slick recursion to write lists backwards,
     *   so loading them will load in forwards order.
     */
    if ( obj->next_content != NULL )
		fwrite_obj( vo, obj->next_content, fp, iNest, fBank, fVault );

    /*
     * Castrate storage characters.
     */
    if ( !fVault )
    {
        if ( obj->item_type == ITEM_KEY )
	    	return;
    }

    if ( IS_SET(obj->extra_flags,ITEM_NORENT) && !fCrashing )
	{
		log_string("Not saving %s, it's no rent!", obj->short_descr );
		return;
	}

    fprintf( fp, "#%c\n", fBank ? 'B' : 'O'  );
    fprintf( fp, "Vnum %d\n",   obj->pIndexData->vnum        );
	fprintf( fp, "Vers %d\n", 2 );
    if (!obj->pIndexData->new_format)
		fprintf( fp, "Oldstyle\n");
    if (obj->enchanted)
		fprintf( fp,"Enchanted\n");
    fprintf( fp, "Nest %d\n",	iNest	  	     );

    /* these data are only used if they do not match the defaults */

	if ( obj->crafter != NULL )
		fprintf( fp, "Crafter %s~\n", obj->crafter );
    if ( obj->name != obj->pIndexData->name)
    	fprintf( fp, "Name %s~\n",	obj->name		     );
    if ( obj->short_descr != obj->pIndexData->short_descr)
        fprintf( fp, "ShD  %s~\n",	obj->short_descr	     );
    if ( obj->description != obj->pIndexData->description)
        fprintf( fp, "Desc %s~\n",	obj->description	     );
    if ( obj->extra_flags != obj->pIndexData->extra_flags)
        fprintf( fp, "ExtF %d\n",	obj->extra_flags	     );
    if ( obj->wear_flags != obj->pIndexData->wear_flags)
        fprintf( fp, "WeaF %d\n",	obj->wear_flags		     );
    if ( obj->item_type != obj->pIndexData->item_type)
        fprintf( fp, "Ityp %d\n",	obj->item_type		     );
    if ( obj->weight != obj->pIndexData->weight)
        fprintf( fp, "Wt   %d\n",	obj->weight		     );
    if ( obj->condition != obj->pIndexData->condition)
		fprintf( fp, "Cond %d\n",	obj->condition		     );
	if ( obj->durability != obj->pIndexData->durability )
		fprintf( fp, "Dur %d\n", obj->durability );
	if ( obj->quality != obj->pIndexData->quality )
		fprintf( fp, "Qua %d\n", obj->quality );

	if ( obj->absorb != 0 )
		fprintf( fp, "Absorb %d\n", obj->absorb );

    /* variable data */

    fprintf( fp, "Wear %d\n",   obj->wear_loc                );
    if (obj->level != obj->pIndexData->level)
        fprintf( fp, "Lev  %d\n",	obj->level		     );
    if (obj->timer != 0)
        fprintf( fp, "Time %d\n",	obj->timer	     );
    fprintf( fp, "Cost %ld\n",	obj->cost		     );
    if (obj->value[0] != obj->pIndexData->value[0]
    ||  obj->value[1] != obj->pIndexData->value[1]
    ||  obj->value[2] != obj->pIndexData->value[2]
    ||  obj->value[3] != obj->pIndexData->value[3]
    ||  obj->value[4] != obj->pIndexData->value[4] )
    	fprintf( fp, "Val  %d %d %d %d %d\n",
	    obj->value[0], obj->value[1], obj->value[2], obj->value[3],
	    obj->value[4]	     );

	if ( obj->value[5] != obj->pIndexData->value[5]
	||    obj->value[6] != obj->pIndexData->value[6]
	||    obj->value[7] != obj->pIndexData->value[7]
	||    obj->value[8] != obj->pIndexData->value[8]
	||    obj->value[9] != obj->pIndexData->value[9] )
		fprintf( fp, "HVal %d %d %d %d %d\n",
		obj->value[5], obj->value[6], obj->value[7], 
		obj->value[8], obj->value[9] );

    switch ( obj->item_type )
    {
    case ITEM_SPELLBOOK:
    {
		int i;
		int sn;
		SpellIndex* pSpellIndex;
		
		for ( i=0 ; i < 10 ; i++ )
		{
			sn = get10Bits( obj->value[i] );
			sn = UMAX(0,sn);
	    	
			if( (pSpellIndex = get_spell_index(sn)) != NULL)
				fprintf( fp,"SpellB %d '%s'\n", i, pSpellIndex->name );
			else
				log_bug("fwrite_obj(item_spellbook): Spell index not found(%d)",sn);
		}

        for ( i=0 ; i < 10 ; i++ )
        {
            sn = get20Bits( obj->value[i] );
            sn = UMAX(0,sn);

			if( (pSpellIndex = get_spell_index(sn)) != NULL)
				fprintf( fp,"SpellB %d '%s'\n", 10+i, pSpellIndex->name );
			else
				log_bug("fwrite_obj(item_spellbook): Spell index not found(%d)",sn);
        }

		break;
    }
    case ITEM_POTION:
    case ITEM_SCROLL:
    case ITEM_PILL:
	if ( obj->value[1] > 0 )
	{
	    fprintf( fp, "Spell 1 '%s'\n", 
		skill_table[obj->value[1]].name );
	}

	if ( obj->value[2] > 0 )
	{
	    fprintf( fp, "Spell 2 '%s'\n", 
		skill_table[obj->value[2]].name );
	}

	if ( obj->value[3] > 0 )
	{
	    fprintf( fp, "Spell 3 '%s'\n", 
		skill_table[obj->value[3]].name );
	}

	break;

    case ITEM_STAFF:
    case ITEM_WAND:
	if ( obj->value[3] > 0 )
	{
	    fprintf( fp, "Spell 3 '%s'\n", 
		skill_table[obj->value[3]].name );
	}

	break;
    }

	writeAffectList( fp, obj->affected );

    for ( ed = obj->extra_descr; ed != NULL; ed = ed->next )
    {
	fprintf( fp, "ExDe %s~ %s~\n",
	    ed->keyword, ed->description );
    }

    fprintf( fp, "End\n\n" );

    if ( obj->contains != NULL )
	fwrite_obj( vo, obj->contains, fp, iNest + 1, fBank, fVault );

    return;
}

void load_vaults( void )
{
    FILE *fpList;
    FILE *fpVault;
    char  strArea[MAX_INPUT_LENGTH];

    if ( ( fpList = fopen( VAULT_LIST, "r" ) ) == NULL )
    {
        log_error( VAULT_LIST );
	log_bug("Unable to open vault list.",0);
	return;
    }

    for ( ; ; )
    {
		char	room_vnum[MAX_INPUT_LENGTH];

        strcpy( strArea, fread_word( fpList ) );

		if ( !str_cmp( strArea, "$" ) || strArea[0] == '\0' )
		{
	    	log_bug("Empty vault file.  Skipping.",0);
	    	return;
   		}

        if ( strArea[0] == '$' )
            break;

        if ( ( fpVault = fopen( strArea, "r" ) ) == NULL )
        {
	    log_bug("Unable to open vault file.",0);
            log_error( strArea );
 	    continue;
        }

 	/* Get room name */
	strcpy(room_vnum,strArea+strlen(getDirectory(AREA_DIR))+1);
	log_string("Loading vault [%s], room vnum %d",strArea,atoi(room_vnum));
	
        for ( ; ; )
        {
            char *word;
	    Room *r;

            if ( fread_letter( fpVault ) != '#' )
            {
                log_bug( "Load_vaults: # not found.", 0 );
                break;
            }
            word = fread_word( fpVault );

	    if ( (r=get_room_index(atoi(room_vnum))) == NULL )
	    {
	 	log_bug("No such room %d",atoi(room_vnum));
		break;
	    }

                 if ( word[0] == '$'               )                 break;
            else if ( !str_cmp( word, "OBJECT" ) ) fread_obj  ( r, fpVault, FALSE, TRUE );
            else if ( !str_cmp( word, "O"      ) ) fread_obj  ( r, fpVault, FALSE, TRUE );
            else if ( !str_cmp( word, "END"    ) ) break;
            else
            {
                log_bug( "Lod_vault: bad section name.", 0 );
                break;
            }
        }
        
        fclose( fpVault );
        fpVault = NULL;
    }
    fclose( fpList );
}

/*
 * Load a char and inventory into a new ch structure.
 */
bool load_char_obj( Descriptor *d, char *name )
{
    char strsave[MAX_INPUT_LENGTH];
    char buf[100];
    Character *ch;
    FILE *fp;
    bool found;
    int stat, last_note_read;
	int i;
	extern	int const where_order [] ;

    ch = new_char();
    ch->pcdata = new_pcdata();

    d->character			= ch;
    ch->desc				= d;
    ch->name				= str_dup( name );
    ch->id				= get_pc_id();
    ch->race				= race_lookup("human");
    ch->act				= 0;
    ch->comm				= COMM_NOOOC;
    ch->prompt 				= str_dup("<%bbase %hhits %mmana %sstam %vmoves> ");
    ch->pcdata->confirm_delete		= FALSE;
    ch->pcdata->pwd			= str_dup( "" );
    ch->pcdata->bamfin			= str_dup( "" );
    ch->pcdata->bamfout			= str_dup( "" );
    ch->pcdata->title			= str_dup( "" );
	ch->pcdata->note_signature	= str_dup( "" );
	ch->pcdata->date_last_level	= 0;
    for (stat =0; stat < MAX_STATS; stat++)
		ch->perm_stat[stat]		= 13;
	for (last_note_read = 0; last_note_read < MAX_NOTES; last_note_read++)
		ch->pcdata->last_note_read[last_note_read] = 0;
    ch->pcdata->condition[COND_THIRST]	= 48; 
    ch->pcdata->condition[COND_FULL]	= 48;
    ch->pcdata->condition[COND_HUNGER]	= 48;
	ch->pcdata->customSayColor = 'x';
	ch->pcdata->customTellColor = 'x';
	ch->pcdata->customGTellColor = 'x';
	ch->pcdata->customRoundTableColor = 'x';
	ch->pcdata->customRTSubColor = 'x';
    ch->pcdata->security		= 0;	/* OLC */
	ch->pcdata->recall_vnum		= 3001;
	ch->pcdata->rtptrs.handler  = NULL; /*Round table*/
	ch->pcdata->rtptrs.rtvalue  = 0;
    ch->pcdata->options         = OPT_NOSUMMON;
    ch->pcdata->score_options   = SCORE_OPT_SHOW_BANK | SCORE_OPT_SHOW_XP;
    ch->pcdata->auto_options    = AUTO_EXIT | AUTO_LOOT | AUTO_SAC | AUTO_GOLD;
    ch->pcdata->color_options   = 0;
    ch->pcdata->comm_options    = COMM_OPT_COMBINE | COMM_OPT_PROMPT;

    ch->display		= DISP_FULL_EQUIPMENT |
					  DISP_SHOW_AUTOSAVES |
					  DISP_ALERT_REUSE |
					  DISP_SHOW_WHEN_FULL |
					  DISP_SHOW_HUNGER;

	/* Reset equipment list */
	for( i = 0 ; i < MAX_WEAR ; i++ )
		ch->pcdata->eq_list_order[i] = where_order[i];

    /* Reset all gui info because this is set after logging in */
    ch->gui = 0;
    ch->gui_check_timer = PULSE_GUI_CHECK;

    /* Set custom colors to default values */
    resetCustomColorData( ch );

    found = FALSE;
    fclose( fpReserve );
    
    #if defined(unix)
    /* decompress if .gz file exists */
    sprintf( strsave, "%s/%s%s", getDirectory(PLAYER_DIR), capitalize(name),".gz");
    if ( ( fp = fopen( strsave, "r" ) ) != NULL )
    {
	fclose(fp);
	sprintf(buf,"gzip -dfq %s",strsave);
	system(buf);
    }
    #endif

    sprintf( strsave, "%s/%s", getDirectory(PLAYER_DIR), capitalize( name ) );
    if ( ( fp = fopen( strsave, "r" ) ) != NULL )
    {
	int iNest;

	for ( iNest = 0; iNest < MAX_NEST; iNest++ )
	    rgObjNest[iNest] = NULL;

	found = TRUE;
	for ( ; ; )
	{
	    char letter;
	    char *word;

	    letter = fread_letter( fp );
	    if ( letter == '*' )
	    {
		fread_to_eol( fp );
		continue;
	    }

	    if ( letter != '#' )
	    {
		log_bug( "Load_char_obj: # not found.", 0 );
		break;
	    }

	    word = fread_word( fp );
	    if      ( !str_cmp( word, "PLAYER" ) ) fread_char ( ch, fp );
	    else if ( !str_cmp( word, "OBJECT" ) ) fread_obj  ( ch, fp, FALSE, FALSE );
	    else if ( !str_cmp( word, "O"      ) ) fread_obj  ( ch, fp, FALSE, FALSE );
	    else if ( !str_cmp( word, "B"      ) ) fread_obj  ( ch, fp, TRUE, FALSE );
	    else if ( !str_cmp( word, "PET"    ) ) fread_pet  ( ch, fp );
	    else if ( !str_cmp( word, "END"    ) ) break;
	    else
	    {
		log_bug( "Load_char_obj: bad section.", 0 );
		break;
	    }
	}
	fclose( fp );
    }

    fpReserve = fopen( NULL_FILE, "r" );


    /* initialize race */
    if (found)
    {
	int i;

	if (ch->race == 0)
	    ch->race = race_lookup("human");

	ch->size = pc_race_table[ch->race].size;
	ch->dam_type = 17; /*punch */

	for (i = 0; i < 5; i++)
	{
	    if (pc_race_table[ch->race].skills[i] == NULL)
		break;
	    group_add(ch,pc_race_table[ch->race].skills[i],FALSE);
	}

    for(i=0;i<5;i++)
        if ( subrace_table[ch->pcdata->subrace].skills[i] == NULL )
            break;
        else
            group_add(ch,subrace_table[ch->pcdata->subrace].skills[i],FALSE);
    
	ch->affected_by = ch->affected_by|race_table[ch->race].aff;
	ch->imm_flags	= ch->imm_flags | race_table[ch->race].imm;
	ch->form	= race_table[ch->race].form;
	ch->parts	= race_table[ch->race].parts;
    }
	else
	
	
    /* RT initialize skills */

    if (found && ch->version < 2)  /* need to add the new skills */
    {
	group_add(ch,"rom basics",FALSE);
	group_add(ch,class_table[ch->class].base_group,FALSE);
	group_add(ch,class_table[ch->class].default_group,TRUE);
	ch->pcdata->learned[gsn_recall] = 50;
    }
 
    /* fix levels */
    if (found && ch->version < 3 && (ch->level > 35 || ch->trust > 35))
    {
	switch (ch->level)
	{
	    case(40) : ch->level = 60;	break;  /* imp -> imp */
	    case(39) : ch->level = 58; 	break;	/* god -> supreme */
	    case(38) : ch->level = 56;  break;	/* deity -> god */
	    case(37) : ch->level = 53;  break;	/* angel -> demigod */
	}

        switch (ch->trust)
        {
            case(40) : ch->trust = 60;  break;	/* imp -> imp */
            case(39) : ch->trust = 58;  break;	/* god -> supreme */
            case(38) : ch->trust = 56;  break;	/* deity -> god */
            case(37) : ch->trust = 53;  break;	/* angel -> demigod */
            case(36) : ch->trust = 51;  break;	/* hero -> hero */
        }
    }

	/* Fix thaumaturgy and theology */
	if ( ch->version < 13 )
	{
		switch( class_table[ch->class].group )
		{
		case ARCANE:
			ch->pcdata->learned[gsn_thaumaturgy] = ch->level ; break;
		case DIVINE:
			ch->pcdata->learned[gsn_theology] = ch->level ; break;
		default:
			break;
		}
	}

	if ( found )
	{
		applyDefaultFactions( ch );
		ch->practice += rewardExtraSkillPoints( ch );
	}

	if ( ch->pcdata->journal == NULL )
		ch->pcdata->journal = newJournal( );

    if ( ch->pcdata->customSayColor == 0 )
		ch->pcdata->customSayColor = 'x';

	if ( ch->pcdata->customTellColor == 0 )
    	ch->pcdata->customTellColor = 'x';

	if ( ch->pcdata->customGTellColor == 0 )
    	ch->pcdata->customGTellColor = 'x';

	if ( ch->pcdata->customRoundTableColor == 0 )
    	ch->pcdata->customRoundTableColor = 'x';

	if ( ch->pcdata->customRTSubColor == 0 )
    	ch->pcdata->customRTSubColor = 'x';

	REMOVE_BIT(ch->act,PLR_IS_CASTING);
	REMOVE_BIT(ch->act,PLR_IS_CRAFTING);

	if ( ch->version < 22 && ch->class == class_lookup("paladin") )
	{
		int ret_amt = 0;
		
		do {
			ret_amt += ch->pcdata->learned[gsn_theology];
		} while( --ch->pcdata->learned[gsn_theology] > 1 );

		if ( ret_amt > 1 )
			ch->practice += ret_amt;

		ch->pcdata->learned[gsn_theology] = 0;
	}

	if ( ch->version < 27 )
		ch->pcdata->guild_points = 0;

    return found;
}

/* Will return any player character, if they are not online they are pulled
 * from file.  NOTE: It is the calling functions responsibility to do_quit
 * a character if it is pulled from file!
 * Return TRUE is the char is online and FALSE if pulled from file or victim isnt found
 */
bool get_any_char(Character* ch, char* name, Character** victim)
{
    Character *rch;

    /* Player is connected */
    /* Find char, dont use get_char_ooc because that could
       match an NPC */
    for ( rch = char_list; rch != NULL; rch = rch->next )
    {
        if(is_name(name,
            (!is_affected(rch,gsn_shapeshifting,AFF_SKILL) ? rch->name :
             rch->desc->original->name)) && !IS_NPC(rch))
        {
            *victim = rch;
            return TRUE;
        }
    } 

    /* Player isn't on, pull him from file */
    if(*victim == NULL)
    {
        /* Load the char */
        bool isChar = FALSE;
        Descriptor d;

        isChar = load_char_obj(&d, name);

        if(!isChar)
        {
            cprintf(ch,"Player %s does not exist.\n\r",name);
            return FALSE;
        }

        d.character->desc = NULL;
        d.character->next = char_list;
        char_list = d.character;
        /* Just in case, they can't login while getting a reward */
        d.connected = CON_GET_REWARD;

        *victim = d.character;
        reset_char(*victim);
    }

    return FALSE;
}

/*
 * Read in a char.
 */

#if defined(KEY)
#undef KEY
#endif

#define KEY( literal, field, value )					\
				if ( !str_cmp( word, literal ) )	\
				{					\
				    field  = value;			\
				    fMatch = TRUE;			\
				    break;				\
				}

/* provided to free strings */
#if defined(KEYS)
#undef KEYS
#endif

#define KEYS( literal, field, value )					\
				if ( !str_cmp( word, literal ) )	\
				{					\
				    free_string(field);			\
				    field  = value;			\
				    fMatch = TRUE;			\
				    break;				\
				}

void fread_char( Character *ch, FILE *fp )
{
    char buf[MAX_STRING_LENGTH];
    char *word;
    bool fMatch;
    int count = 0;
	int friends_count = 0;
    int lastlogoff = current_time;

    sprintf(buf,"Loading %s.",ch->name);
    log_string(buf);
    for ( ; ; )
    {
	word   = feof( fp ) ? "End" : fread_word( fp );
	fMatch = FALSE;

	switch ( UPPER(word[0]) )
	{
	case '*':
	    fMatch = TRUE;
	    fread_to_eol( fp );
	    break;

	case 'A':
        if(ch->version >= 26)
	    KEY( "Act",		ch->act,		fread_flag( fp ) );
	    KEY( "AffectedBy",	ch->affected_by,	fread_flag( fp ) );
	    KEY( "AfBy",	ch->affected_by,	fread_flag( fp ) );
		KEY( "AutoOpt",	ch->pcdata->auto_options,	fread_flag( fp ) );

	    if (!str_cmp( word, "Alati") && ch->version >= 7 )
 	    {
		ch->coins[CUR_ALATINUM]	= fread_number(fp);
		ch->pcdata->coins_bank[CUR_ALATINUM]	= fread_number(fp);
		fMatch = TRUE;
		break;
	    }

	    if (!str_cmp( word, "Alia"))
	    {
		if (count >= MAX_ALIAS)
		{
		    fread_to_eol(fp);
		    fMatch = TRUE;
		    break;
		}

		ch->pcdata->alias[count] 	= str_dup(fread_word(fp));
		ch->pcdata->alias_sub[count]	= str_dup(fread_word(fp));
		count++;
		fMatch = TRUE;
		break;
	    }

            if (!str_cmp( word, "Alias"))
            {
                if (count >= MAX_ALIAS)
                {
                    fread_to_eol(fp);
                    fMatch = TRUE;
                    break;
                }
 
                ch->pcdata->alias[count]        = str_dup(fread_word(fp));
                ch->pcdata->alias_sub[count]    = fread_string(fp);
                count++;
                fMatch = TRUE;
                break;
            }

	    if (!str_cmp( word, "AC") || !str_cmp(word,"Armor"))
	    {
		fread_to_eol(fp);
		fMatch = TRUE;
		break;
	    }

	    if (!str_cmp(word,"ACs"))
	    {
		int i;

		for (i = 0; i < 4; i++)
		    ch->armor[i] = fread_number(fp);
		fMatch = TRUE;
		break;
	    }

	    if (!str_cmp(word, "AffD"))
	    {
		Affect *paf;
		int sn;

		paf = new_affect();

		sn = skill_lookup(fread_word(fp));
		if (sn < 0)
		    log_bug("Fread_char: unknown skill.",0);
		else
		    paf->type = sn;

		paf->level	= fread_number( fp );
		paf->duration	= current_time + fread_long( fp );
		paf->modifier	= fread_number( fp );
		paf->location	= fread_number( fp );
		paf->bitvector	= fread_number( fp );
		paf->next	= ch->affected;
		ch->affected	= paf;
		fMatch = TRUE;
		break;
	    }

            if (!str_cmp(word, "Affc") || !str_cmp(word,"AffcSp") )
            {
                Affect *paf;
                int sn;
 				bool fSp = !str_cmp(word,"AffcSp");
				char *tmp;
				long dur;

				tmp = fread_word(fp);
                paf = new_affect();
 
                sn = fSp ? spell_lookup(tmp,-1) : skill_lookup(tmp);

                if (sn < 0)
                    log_bug("Fread_char: unknown skill or spell [%s]",tmp);
                else
                    paf->type = sn;
 
                paf->where  		= fread_number(fp);
                paf->level          = fread_number( fp );
				dur = fread_long( fp );
                paf->modifier       = fread_number( fp );
                paf->location       = fread_number( fp );
				paf->duration		= paf->location == APPLY_BLADETURN ? dur : current_time + dur;
				if ( dur == DUR_PERMANENT )
					paf->duration = dur;
                paf->bitvector      = fread_number( fp );
				if ( ch->version >= 8 )
		    		paf->flags	    = fread_number( fp );
			
				if ( ch->version >= 23 )
					paf->misc		= fread_number( fp );
	
				if ( ch->version <= 16 && fSp )
					paf->flags		= 1;

                paf->next           = ch->affected;
                ch->affected        = paf;
                fMatch = TRUE;
                break;
            }

		if ( !str_cmp( word, "AStart" ) )
		{
			int stat;

			for (stat=0;stat<MAX_STATS;stat++)
				ch->pcdata->start_stat[stat] = fread_number(fp);
			fMatch = TRUE;
			break;
		}

	    if ( !str_cmp( word, "AttrMod"  ) || !str_cmp(word,"AMod"))
	    {
		int stat;
		for (stat = 0; stat < MAX_STATS; stat ++)
		   ch->mod_stat[stat] = fread_number(fp);
		fMatch = TRUE;
		break;
	    }

	    if ( !str_cmp( word, "AttrPerm" ) || !str_cmp(word,"Attr"))
	    {
		int stat;

		for (stat = 0; stat < MAX_STATS; stat++)
		    ch->perm_stat[stat] = fread_number(fp);
		fMatch = TRUE;
		break;
	    }
	    break;

	case 'B':
		KEY( "BuildDM",ch->pcdata->build_daymonth,fread_string(fp) );
		KEY( "BuildDead",ch->pcdata->build_deadline, fread_number(fp) );
  	    KEY( "Bounty",	ch->pcdata->bounty,	fread_number( fp ) );
	    KEY( "Bamfin",	ch->pcdata->bamfin,	fread_string( fp ) );
	    KEY( "Bamfout",	ch->pcdata->bamfout,	fread_string( fp ) );
	    KEY( "Bin",		ch->pcdata->bamfin,	fread_string( fp ) );
	    KEY( "Bout",	ch->pcdata->bamfout,	fread_string( fp ) );
	    break;

	case 'C':
		KEY ("CSayC",	ch->pcdata->customSayColor, fread_number( fp ) );
		KEY ("CTellC",	ch->pcdata->customTellColor, fread_number( fp ) );
		KEY ("CGTellC",	ch->pcdata->customGTellColor, fread_number( fp ) );
		KEY ("CRoundTableC",ch->pcdata->customRoundTableColor, fread_number( fp ) );
		KEY ("CRTSubC",	ch->pcdata->customRTSubColor, fread_number( fp ) );
		KEY( "ClanR",	ch->pcdata->guild_rank,	fread_number( fp ) );
	    KEY( "Class",	ch->class,		fread_number( fp ) );
	    KEY( "Cla",		ch->class,		fread_number( fp ) );
	    /*KEY( "Clan",	ch->clan,	clan_lookup(fread_string(fp)));*/
	    KEY( "CFlag",	ch->pcdata->clan_flags, fread_flag( fp ) );
		KEY( "ColorOpt",ch->pcdata->color_options,	fread_flag( fp ) );
		KEY( "CommOpt", ch->pcdata->comm_options,	fread_flag( fp ) );

		if ( !str_cmp(word,"Clan") )
		{
			Clan *clan;

			if ( (clan = clan_lookup( fread_string(fp ) )) == NULL )
			{
				log_bug("no match for clan",0);
				ch->clan = clan_lookup("loner");
				break;
			}
	
			ch->clan = clan;
			fMatch = TRUE;
			break;
		}

	    if ( !str_cmp(word,"CCC"))
	    {
	        int pos;

	 	for ( pos = 0 ; pos < MAX_CHANNELS ; pos++ )
		    ch->pcdata->customChannelColor[pos] = fread_number(fp);
		
		fMatch = TRUE;
		break;
	    }

	    if ( !str_cmp( word, "Condition" ) || !str_cmp(word,"Cond"))
	    {
		ch->pcdata->condition[0] = fread_number( fp );
		ch->pcdata->condition[1] = fread_number( fp );
		ch->pcdata->condition[2] = fread_number( fp );
		fMatch = TRUE;
		break;
	    }
            if (!str_cmp(word,"Cnd"))
            {
                ch->pcdata->condition[0] = fread_number( fp );
                ch->pcdata->condition[1] = fread_number( fp );
                ch->pcdata->condition[2] = fread_number( fp );
		ch->pcdata->condition[3] = fread_number( fp );
                fMatch = TRUE;
                break;
            }

        /* Clear options because of options overhaul (ver 26) */
        if(ch->version >= 26)
	        KEY("Comm",		ch->comm,		fread_flag( fp ) ); 

	    KEY("Creat",	ch->created,		fread_number( fp ) );
          
	    break;

	case 'D':
	    KEY( "Deity",	ch->deity,		deity_lookup( fread_string(fp) ) );

        /* Clear options because of options overhaul (ver 26) */
        if(ch->version >= 26)
	        KEY( "Disp",   	ch->display,		fread_flag( fp ) );

	    KEY( "Damroll",	ch->damroll,		fread_number( fp ) );
	    KEY( "Dam",		ch->damroll,		fread_number( fp ) );
	    KEY( "Description",	ch->description,	fread_string( fp ) );
	    KEY( "Desc",	ch->description,	fread_string( fp ) );

        if ( !str_cmp(word, "Dptg") )
        {
            ch->pcdata->deprac[DEPRACTICE]  = fread_number(fp);
            ch->pcdata->deprac[DETRAIN] = fread_number(fp);
            ch->pcdata->deprac[DEGAIN]  = fread_number(fp);

            fMatch = TRUE;
            break;
        }
	    break;

	case 'E':
        KEY( "EMail", ch->pcdata->email, fread_string(fp) );
		if ( !str_cmp( word, "Elo" ) )
		{
			int i;

			for( i = 0 ; i < MAX_WEAR ; i++ )
				ch->pcdata->eq_list_order[i] = fread_number(fp);

			fMatch = TRUE;
			break;
		}

	    if ( !str_cmp( word, "End" ) )
	    {
		/* REMOVED ***
    		percent = (current_time - lastlogoff) * 25 / ( 2 * 60 * 60);

		percent = UMIN(percent,100);
 
    		if (percent > 0 && !IS_AFFECTED(ch,AFF_POISON)
    		&&  !IS_AFFECTED(ch,AFF_PLAGUE))
    		{
        	    ch->stat_hit	+= (max_stat_hit(ch) - ch->stat_hit) * percent / 100;
        	    ch->mana    += (ch->max_mana - ch->mana) * percent / 100;
        	    ch->move    += (ch->max_move - ch->move)* percent / 100;
    		}
		**/
		return;
	    }
	    KEY( "Exp",		ch->exp,		fread_number( fp ) );

            if (!str_cmp( word, "Elect") && ch->version >= 7  )
            {
                ch->coins[CUR_ELECTRUM]    = fread_number(fp);
                ch->pcdata->coins_bank[CUR_ELECTRUM]       = fread_number(fp);
                fMatch = TRUE;
                break;
            }


	    break;

	case 'F':
		if (!str_cmp( word, "Fact"))
		{
			Faction *f, *master;
			int id;

			id = fread_number(fp);
			if( (master = findFactionByID( factionList, id )) == NULL )
			{
				log_bug("No faction with ID %d found.",id);
				fMatch = FALSE;
				break;
			}

			f = cloneFaction( master );
			f->counter = fread_number(fp);
			addFactionToList( &(ch->factions), f );
			fMatch = TRUE;
			break;
		}

		if (!str_cmp( word, "Friend"))
		{
			if (friends_count >= MAX_FRIENDS)
			{
				fread_to_eol(fp);
				fMatch = TRUE;
				break;
			}
			
			ch->pcdata->friends[friends_count]        = str_dup(fread_word(fp));
			friends_count++;
			fMatch = TRUE;
			break;
		}
		
	case 'G':
			KEY( "GuiF",		ch->gui,			fread_flag(fp));
			KEY( "GuildP",		ch->pcdata->guild_points,	fread_number(fp));

            if (!str_cmp( word, "Gold") && ch->version >= 7  )
            {
                ch->coins[CUR_GOLD]    = fread_number(fp);
                ch->pcdata->coins_bank[CUR_GOLD]       = fread_number(fp);
                fMatch = TRUE;
                break;
            }

            if ( !str_cmp( word, "Group" )  || !str_cmp(word,"Gr"))
            {
                int gn;
                char *temp;
 
                temp = fread_word( fp ) ;
                gn = group_lookup(temp);
                /* gn    = group_lookup( fread_word( fp ) ); */
                if ( gn < 0 )
                {
                    fprintf(stderr,"%s",temp);
                    log_bug( "Fread_char: unknown group. ", 0 );
                }
                else
		    gn_add(ch,gn);
                fMatch = TRUE;
            }
	    break;

	case 'H':
		KEY( "Host",    ch->pcdata->host,	fread_string( fp ) );
	    KEY( "Hitroll",	ch->hitroll,		fread_number( fp ) );
	    KEY( "Hit",		ch->hitroll,		fread_number( fp ) );

        if ( !str_cmp( word, "HpManaMove" ) || !str_cmp(word,"HMV"))
        {
		fread_number(fp);
		fread_number(fp);
        ch->mana    = fread_number( fp );
        ch->max_mana    = fread_number( fp );
        ch->move    = fread_number( fp );
        ch->max_move    = fread_number( fp );
        fMatch = TRUE;
        break;
        }

	    if ( !str_cmp( word, "HpManaMove" ) || !str_cmp(word,"MV"))
	    {
		ch->mana	= fread_number( fp );
		ch->max_mana	= fread_number( fp );
		ch->move	= fread_number( fp );
		ch->max_move	= fread_number( fp );
		fMatch = TRUE;
		break;
	    }

	    break;

	case 'I':
	    KEY( "Id",		ch->id,			fread_number( fp ) );
	    KEY( "InvisLevel",	ch->invis_level,	fread_number( fp ) );
	    KEY( "Inco",	ch->incog_level,	fread_number( fp ) );
	    KEY( "Invi",	ch->invis_level,	fread_number( fp ) );
	    KEY( "IRole",	ch->pcdata->imm_role,	fread_number( fp ) );

        if (!str_cmp( word, "Ignore"))
        {
			Ignore *i;

			i = new_ignore( );
			i->name = fread_string( fp );
			i->next = ch->pcdata->ignore_list;
			ch->pcdata->ignore_list = i;
            fMatch = TRUE;
            break;
        }

	    break;

	case 'J':
		if ( !str_cmp(word,"Journ") )
		{
			ch->pcdata->journal = readJournal( fp );
			fMatch = TRUE;
			break;
		}

	case 'L':
        KEY( "LastSpecEnemy", ch->pcdata->class_info.ranger.last_species_enemy, fread_number(fp) );
     	KEY( "LastBhG",  ch->pcdata->last_basegain, fread_number(fp) );
     	KEY( "LastShG",  ch->pcdata->last_statgain, fread_number(fp) );
     	KEY( "LastMaG",  ch->pcdata->last_managain, fread_number(fp) );
     	KEY( "LastMvG",  ch->pcdata->last_movegain, fread_number(fp) );
     	KEY( "LastStG",  ch->pcdata->last_stamgain, fread_number(fp) );
     	KEY( "LastPrG",  ch->pcdata->last_primegain, fread_number(fp) );
     	KEY( "LastSeG",  ch->pcdata->last_secondgain, fread_number(fp) );
     	KEY( "LastTrG",  ch->pcdata->last_traingain, fread_number(fp) );
     	KEY( "LastSkG",  ch->pcdata->last_skillgain, fread_number(fp) );
		KEY( "LPD",	ch->pcdata->last_pdeath, fread_number( fp ) );
		KEY( "LL",  ch->pcdata->date_last_level,  fread_number( fp ) );
	    KEY( "LastLevel",	ch->pcdata->last_level, fread_number( fp ) );
	    KEY( "LLev",	ch->pcdata->last_level, fread_number( fp ) );
	    KEY( "Level",	ch->level,		fread_number( fp ) );
	    KEY( "Lev",		ch->level,		fread_number( fp ) );
	    KEY( "Levl",	ch->level,		fread_number( fp ) );
	    KEY( "LogO",	lastlogoff,		fread_number( fp ) );
	    KEY( "LongDescr",	ch->long_descr,		fread_string( fp ) );
	    KEY( "LnD",		ch->long_descr,		fread_string( fp ) );
	    break;

	case 'M':
         if ( !str_cmp( word, "MV" ) )
         {
			ch->mana		= fread_number( fp );
			ch->max_mana	= fread_number( fp );
			ch->move		= fread_number( fp );
			ch->max_move	= fread_number( fp );
			fMatch = TRUE;
			break;
		}
		break;

	case 'N':
	    KEYS( "Name",	ch->name,		fread_string( fp ) );
		KEY( "NSig",	ch->pcdata->note_signature, fread_string( fp ) );
	    KEY( "Note",	ch->pcdata->last_note,	fread_number( fp ) );
	    if (!str_cmp(word,"Not"))
	    {
		int spool=0;

		ch->pcdata->last_reads[spool++]	= fread_number(fp); /* note */
		ch->pcdata->last_reads[spool++]	= fread_number(fp); /* idea */
		ch->pcdata->last_reads[spool++]	= fread_number(fp); /* pen */
		ch->pcdata->last_reads[spool++]	= fread_number(fp); /* news */
		ch->pcdata->last_reads[spool++]	= fread_number(fp); /* change */
		if ( ch->version > 5 )
		{
		    ch->pcdata->last_reads[spool++] = fread_number(fp); /* bug */
		    ch->pcdata->last_reads[spool++] = fread_number(fp); /* appeal */
		    ch->pcdata->last_reads[spool++] = fread_number(fp); /* admin */
		    ch->pcdata->last_reads[spool++] = fread_number(fp); /* clan */
 	        }
		if ( ch->version >= 9 )
		    ch->pcdata->last_reads[spool++] = fread_number(fp); /* fix */
		if ( ch->version >= 11 )
			ch->pcdata->last_reads[spool++] = fread_number(fp); /* todo */
		if ( ch->version >= 12 )
			ch->pcdata->last_reads[spool++] = fread_number(fp); /* patch */
		if ( ch->version >= 16 )
			ch->pcdata->last_reads[spool++] = fread_number(fp); /* sys */
		if ( ch->version >= 18 )
			ch->pcdata->last_reads[spool++] = fread_number(fp); /* world */
		if ( ch->version >= 24 )
			ch->pcdata->last_reads[spool++] = fread_number(fp); /* offline */

		fMatch = TRUE;
		break;
	    }
	    break;

	case 'O':
        /* Clear options because of options overhaul (ver 26) */
        if(ch->version >= 26)
		    KEY( "Opt",	ch->pcdata->options,	fread_flag( fp ) );
		break;

	case 'P':
		KEY( "Playing",	ch->playing,		skill_lookup(fread_string( fp )) );
		KEY( "PDth",	ch->pcdata->deaths,		fread_number( fp ) );
		KEY( "PKls",	ch->pcdata->kills,		fread_number( fp ) );
	    KEY( "Pnet",	ch->pcdata->pnet,		fread_flag( fp ) );
		KEY( "Password",	ch->pcdata->pwd,	fread_string( fp ) );
	    KEY( "Pass",	ch->pcdata->pwd,	fread_string( fp ) );
	    KEY( "Played",	ch->played,		fread_number( fp ) );
	    KEY( "Plyd",	ch->played,		fread_number( fp ) );
	    KEY( "Position",	ch->position,		fread_number( fp ) );
	    KEY( "Pos",		ch->position,		fread_number( fp ) );
	    KEY( "Practice",	ch->practice,		fread_number( fp ) );
	    KEY( "Prac",	ch->practice,		fread_number( fp ) );
        KEYS( "Prompt",      ch->prompt,             fread_string( fp ) );
 	    KEY( "Prom",	ch->prompt,		fread_string( fp ) );

		if ( !str_cmp( word, "PST" ) )
		{
			ch->pcdata->perm_base_hit 	= fread_number(fp);
			ch->pcdata->perm_stat_hit	= fread_number(fp);
			ch->pcdata->perm_mana		= fread_number(fp);
			ch->pcdata->perm_move		= fread_number(fp);
			ch->pcdata->perm_stamina	= fread_number(fp);
			fMatch = TRUE;
			break;
		}

            if ( !str_cmp( word, "Prof" ) || !str_cmp(word,"Pr"))
            {
                int sn;
                char *temp;

                temp = fread_word( fp ) ;
                sn = proficiency_lookup(temp);
                if ( sn < 0 )
                {
                    fprintf(stderr,"%s",temp);
                    log_bug( "Fread_char: unknown proficiency. ", 0 );
                }
                else
                    ch->pcdata->profs[sn] = TRUE;
                fMatch = TRUE;
            }


            if (!str_cmp( word, "Plati") && ch->version >= 7  )
            {
                ch->coins[CUR_PLATINUM]    = fread_number(fp);
                ch->pcdata->coins_bank[CUR_PLATINUM]       = fread_number(fp);
                fMatch = TRUE;
                break;
            }


	    break;

	case 'R':
		KEY( "RV",		ch->pcdata->recall_vnum,	fread_number(fp) );
	    KEY( "Race",        ch->race,	
				race_lookup(fread_string( fp )) );

		if ( !str_cmp( word, "RuW" ) )
		{
			Reuse_wait *r;

			r = new_reuse( );
			r->gsn = fread_number( fp );
			r->type = fread_number( fp );
			r->timer = fread_number( fp );
			r->next = ch->reuse_wait;
			ch->reuse_wait = r;

			fMatch = TRUE;
			break;
		}

	    if ( !str_cmp( word, "Rz" ) )
	    {
		int index;

	        ch->resists[(index=fread_number(fp))].value = fread_number(fp);
		ch->resists[index].mod = fread_number(fp);
	 	fMatch = TRUE;
		break;
	    }
	    if ( !str_cmp( word, "Room" ) )
	    {
		ch->in_room = get_room_index( fread_number( fp ) );
		if ( ch->in_room == NULL )
		    ch->in_room = get_room_index( ROOM_VNUM_LIMBO );
		fMatch = TRUE;
		break;
	    }

	    break;

	case 'S':
        KEY("SpecEnemy",    ch->pcdata->class_info.ranger.species_enemy, race_lookup( fread_string(fp) ) );
	    /*KEY( "SkP",		ch->skill_points,	fread_number( fp ) );*/
		KEY ("SpecP",	ch->pcdata->spec_points,	fread_number( fp ) );
		/*KEY ("SubR",	ch->pcdata->subrace,	subrace_lookup( fread_string(fp) ) );*/
		KEY ("SExp",	ch->pcdata->spec_exp,	fread_number( fp ) );
		KEY ("SLvl",	ch->pcdata->spec_level,	fread_number( fp ) );
		KEY ("SSpl",	ch->pcdata->split,		fread_number( fp ) );
	    KEY( "Secu",	ch->pcdata->security,	fread_number( fp ) );
	    KEY( "SavingThrow",	ch->saving_throw,	fread_number( fp ) );
	    KEY( "Save",	ch->saving_throw,	fread_number( fp ) );
	    KEY( "Scro",	ch->lines,		fread_number( fp ) );
	    KEY( "Sex",		ch->sex,		fread_number( fp ) );
	    KEY( "ShortDescr",	ch->short_descr,	fread_string( fp ) );
	    KEY( "ShD",		    ch->short_descr,	fread_string( fp ) );
	    KEY( "Sec",         ch->pcdata->security,	fread_number( fp ) );	/* OLC */

        /* Clear options because of options overhaul (ver 26) */
        if(ch->version >= 26)
    		KEY( "ScoreOpt",	ch->pcdata->score_options,	fread_flag( fp ) );

		if ( !str_cmp(word,"ShapeShift") )
		{
			int skill;
			int vnum;
			Character *shifted;
			Affect af;

			vnum = fread_number( fp );
			skill = get_raw_skill(ch,gsn_shapeshifting);
		
			shifted = createShiftedStats( ch, vnum, skill,
				fread_number( fp ), fread_number( fp ),
				fread_number( fp ), fread_number( fp ),
				fread_number( fp ), fread_number( fp ),
				fread_number( fp ), fread_number( fp ) );

			ch->shapeshifted = shifted;

    		af.where    = TO_AFFECTS;
    		af.type     = gsn_shapeshifting;
    		af.level    = ch->level;
    		af.duration = DUR_PERMANENT;
    		af.location = 0;
    		af.modifier = 0;
    		af.bitvector = 0;
    		af.flags = AFF_SKILL;
    		af.misc = 0;
    		skillAffectToChar( shifted, &af );
			fMatch = TRUE;
			char_from_list( shifted );
			break;
		}

            if (!str_cmp(word, "SSAffc") || !str_cmp(word,"SSAffcSp") )
            {
                Affect *paf;
                int sn;
                bool fSp = !str_cmp(word,"AffcSp");
                char *tmp;
                long dur;

				if ( ch->shapeshifted == NULL )
				{
					fread_to_eol(fp);
					fMatch = TRUE;
					log_bug("%s: no shapeshift data!",word);
					break;
				}

                tmp = fread_word(fp);
                paf = new_affect();

                sn = fSp ? spell_lookup(tmp,-1) : skill_lookup(tmp);

                if (sn < 0)
                    log_bug("Fread_char (shapeshift): unknown skill or spell [%s]",tmp);
                else
                    paf->type = sn;

                paf->where          = fread_number(fp);
                paf->level          = fread_number( fp );
                dur = fread_long( fp );
                paf->modifier       = fread_number( fp );
                paf->location       = fread_number( fp );
                paf->duration       = paf->location == APPLY_BLADETURN ? dur : current_time + dur;
                if ( dur == DUR_PERMANENT )
                    paf->duration = dur;
                paf->bitvector      = fread_number( fp );
                if ( ch->version >= 8 )
                    paf->flags      = fread_number( fp );

                if ( ch->version >= 23 )
                    paf->misc       = fread_number( fp );

                if ( ch->version <= 16 && fSp )
                    paf->flags      = 1;

                paf->next           = ch->shapeshifted->affected;
                ch->shapeshifted->affected        = paf;
                fMatch = TRUE;
                break;
            }

		if ( !str_cmp(word,"SpellSlot") )
		{
			int index;

			index = fread_number( fp );
			ch->pcdata->spell_slots[index] = spell_lookup( fread_string( fp ), -1 );
			fMatch = TRUE;
			break;
		}

		if ( !str_cmp(word,"SubR") )
		{
			int sr;

			if ( (sr = subrace_lookup( fread_string(fp) )) <= 0 ||
				subrace_table[sr].class_mult[ch->class] == FALSE )
				assignSubrace( ch );
			else
				ch->pcdata->subrace = sr;
			
			fMatch = TRUE;
			break;
		}

            if (!str_cmp( word, "Silv") && ch->version >= 7  )
            {
                ch->coins[CUR_SILVER]    = fread_number(fp);
                ch->pcdata->coins_bank[CUR_SILVER]       = fread_number(fp);
                fMatch = TRUE;
                break;
            }


            if ( !str_cmp( word, "SSS" ) )
            {
                ch->base_hit         = fread_number( fp );
                ch->max_base_hit     = fread_number( fp );
                ch->stat_hit        = fread_number( fp );
                ch->max_stat_hit    = fread_number( fp );
                ch->stamina     = fread_number( fp );
                ch->max_stamina    = fread_number( fp );
                fMatch = TRUE;
                break;
            }

            if ( !str_cmp(word,"Sp"))
            {
                int sn;
                int value;
                char *temp;
				bool fDivine = FALSE;

                value = fread_number( fp );
                temp = fread_word( fp ) ;

				if ( class_table[ch->class].group == DIVINE ||
					 !str_cmp(class_table[ch->class].name,"paladin") )
					fDivine = TRUE;

                sn = spell_lookup(temp,fDivine);

                /* sn    = spell_lookup( fread_word( fp ) ); */
                if ( sn < 0 )
                    log_bug( "Fread_char: unknown spell: %s", temp);
                else
                    ch->pcdata->spells[sn] = value;
                fMatch = TRUE;
            }

	    if ( !str_cmp( word, "Skill" ) || !str_cmp(word,"Sk"))
	    {
		int sn;
		int value;
		char *temp;

		value = fread_number( fp );
		temp = fread_word( fp ) ;

        if ( !str_cmp(temp,"legerdemain") )
            temp = "open lock";
        else
        if ( !str_cmp(temp,"skuldugery") )
            temp = "pick pocket";

		sn = skill_lookup(temp);
		/* sn    = skill_lookup( fread_word( fp ) ); */
		if ( sn < 0 )
		    log_bug( "Fread_char: unknown skill: %s", temp);
		else
		    ch->pcdata->learned[sn] = value;
		fMatch = TRUE;
	    }

	    break;

	case 'T':
        KEY( "TZI",     ch->pcdata->tzindex,        fread_number(fp) );
            KEY( "TrueSex",     ch->pcdata->true_sex,  	fread_number( fp ) );
	    KEY( "TSex",	ch->pcdata->true_sex,   fread_number( fp ) );
	    KEY( "Trai",	ch->train,		fread_number( fp ) );
	    KEY( "Trust",	ch->trust,		fread_number( fp ) );
	    KEY( "Tru",		ch->trust,		fread_number( fp ) );

	    if ( !str_cmp( word, "Title" )  || !str_cmp( word, "Titl"))
	    {
		ch->pcdata->title = fread_string( fp );
    		if (ch->pcdata->title[0] != '.' && ch->pcdata->title[0] != ',' 
		&&  ch->pcdata->title[0] != '!' && ch->pcdata->title[0] != '?')
		{
		    sprintf( buf, " %s", ch->pcdata->title );
		    free_string( ch->pcdata->title );
		    ch->pcdata->title = str_dup( buf );
		}
		fMatch = TRUE;
		break;
	    }

	    break;

	case 'V':
	    KEY( "Version",     ch->version,		fread_number ( fp ) );
	    KEY( "Vers",	ch->version,		fread_number ( fp ) );

	    if ( !str_cmp( word, "Vnum" ) )
	    {
		ch->pIndexData = get_mob_index( fread_number( fp ) );
		fMatch = TRUE;
		break;
	    }
	    break;

	case 'W':
	    KEY( "WoCo",	ch->pcdata->worth_columns,	fread_number( fp ) );
	    KEY( "Wimpy",	ch->wimpy,		fread_number( fp ) );
	    KEY( "Wimp",	ch->wimpy,		fread_number( fp ) );
	    KEY( "Wizn",	ch->wiznet,		fread_flag( fp ) );

        if ( !str_cmp( word, "WF" ) )
        {
            int wpn;
            char *tmp;

            if ( (wpn = weapon_lookup((tmp=fread_word(fp)))) < 0 )
                log_bug("No such weapon: %s", tmp );
            else
                ch->pcdata->specialized[wpn] = fread_number(fp);
            fMatch = TRUE;
            break;
        }
        
	    break;

	case 'X':
		KEY( "XPL",		ch->pcdata->lost_xp, fread_number( fp ) );
		break;
	}

	if ( !fMatch )
	{
	    log_bug("Fread_char: no match for %s",word);
	    fread_to_eol( fp );
	}

    }
}

/* load a pet from the forgotten reaches */
void fread_pet( Character *ch, FILE *fp )
{
    char *word;
    Character *pet;
    bool fMatch;
    int lastlogoff = current_time;
    int percent;

    /* first entry had BETTER be the vnum or we barf */
    word = feof(fp) ? "END" : fread_word(fp);
    if (!str_cmp(word,"Vnum"))
    {
    	int vnum;
    	
    	vnum = fread_number(fp);
    	if (get_mob_index(vnum) == NULL)
	    {
    	    log_bug("Fread_pet: bad vnum %d.",vnum);
            return;
	    }
    	else
    	    pet = create_mobile(get_mob_index(vnum));
    }
    else
    {
        log_bug("Fread_pet: no vnum in file.",0);
        return;
    }
    
    for ( ; ; )
    {
    	word 	= feof(fp) ? "END" : fread_word(fp);
    	fMatch = FALSE;

    	switch (UPPER(word[0]))
    	{
    	case '*':
    	    fMatch = TRUE;
    	    fread_to_eol(fp);
    	    break;
    		
    	case 'A':
    	    KEY( "Act",		pet->act,		fread_flag(fp));
    	    KEY( "AfBy",	pet->affected_by,	fread_flag(fp));
    	    
    	    if (!str_cmp(word,"ACs"))
    	    {
    	    	int i;
    	    	
    	    	for (i = 0; i < 4; i++)
    	    	    pet->armor[i] = fread_number(fp);
    	    	fMatch = TRUE;
    	    	break;
    	    }
    	    
    	    if (!str_cmp(word,"AffD"))
    	    {
    	    	Affect *paf;
    	    	int sn;
    	    	
    	    	paf = new_affect();
    	    	
    	    	sn = skill_lookup(fread_word(fp));
    	     	if (sn < 0)
    	     	    log_bug("Fread_char: unknown skill.",0);
    	     	else
    	     	   paf->type = sn;
    	     	   
    	     	paf->level	= fread_number(fp);
    	     	paf->duration	= current_time + fread_long(fp);
    	     	paf->modifier	= fread_number(fp);
    	     	paf->location	= fread_number(fp);
    	     	paf->bitvector	= fread_number(fp);
    	     	paf->next	= pet->affected;
    	     	pet->affected	= paf;
    	     	fMatch		= TRUE;
    	     	break;
    	    }

            if (!str_cmp(word,"Affc"))
            {
                Affect *paf;
                int sn;
 
                paf = new_affect();
 
                sn = skill_lookup(fread_word(fp));
                if (sn < 0)
                    log_bug("Fread_char: unknown skill.",0);
                else
                   paf->type = sn;
 
				paf->where	= fread_number(fp);
                paf->level      = fread_number(fp);
                paf->duration   = current_time + fread_long(fp);
                paf->modifier   = fread_number(fp);
                paf->location   = fread_number(fp);
                paf->bitvector  = fread_number(fp);
                paf->next       = pet->affected;
                pet->affected   = paf;
                fMatch          = TRUE;
                break;
            }
    	     
    	    if (!str_cmp(word,"AMod"))
    	    {
    	     	int stat;
    	     	
    	     	for (stat = 0; stat < MAX_STATS; stat++)
    	     	    pet->mod_stat[stat] = fread_number(fp);
    	     	fMatch = TRUE;
    	     	break;
    	    }
    	     
    	    if (!str_cmp(word,"Attr"))
    	    {
    	         int stat;
    	         
    	         for (stat = 0; stat < MAX_STATS; stat++)
    	             pet->perm_stat[stat] = fread_number(fp);
    	         fMatch = TRUE;
    	         break;
    	    }
    	    break;
    	     
    	 case 'C':
             KEY( "Clan",       pet->clan,       clan_lookup(fread_string(fp)));
    	     KEY( "Comm",	    pet->comm,		fread_flag(fp));

    	     break;
    	     
    	 case 'D':
    	     KEY( "Dam",	pet->damroll,		fread_number(fp));
    	     KEY( "Desc",	pet->description,	fread_string(fp));
    	     break;
    	     
    	 case 'E':
    	     if (!str_cmp(word,"End"))
	     {
		pet->leader = ch;
		pet->master = ch;
		ch->pet = pet;
    		/* adjust hp mana move up  -- here for speed's sake */
    		percent = (current_time - lastlogoff) * 25 / ( 2 * 60 * 60);
 
    		if (percent > 0 && !IS_AFFECTED(ch,AFF_POISON)
    		&&  !IS_AFFECTED(ch,AFF_PLAGUE))
    		{
		    percent = UMIN(percent,100);
    		    pet->stat_hit	+= (max_stat_hit(pet) - pet->stat_hit) * percent / 100;
        	    pet->mana   += (pet->max_mana - pet->mana) * percent / 100;
        	    pet->move   += (pet->max_move - pet->move)* percent / 100;
    		}
    	     	return;
	     }
    	     KEY( "Exp",	pet->exp,		fread_number(fp));
    	     break;
    	     
    	 case 'G':

    	     break;
    	     
    	 case 'H':
    	     KEY( "Hit",	pet->hitroll,		fread_number(fp));
    	    
             if (!str_cmp(word,"HMV"))
             {
				fread_number(fp);
				fread_number(fp);
                pet->mana   = fread_number(fp);
                pet->max_mana   = fread_number(fp);
                pet->move   = fread_number(fp);
                pet->max_move   = fread_number(fp);
                fMatch = TRUE;
                break;
             }

 
    	     if (!str_cmp(word,"MV"))
    	     {
    	     	pet->mana	= fread_number(fp);
    	     	pet->max_mana	= fread_number(fp);
    	     	pet->move	= fread_number(fp);
    	     	pet->max_move	= fread_number(fp);
    	     	fMatch = TRUE;
    	     	break;
    	     }
    	     break;
    	     
     	case 'L':
    	     KEY( "Levl",	pet->level,		fread_number(fp));
    	     KEY( "LnD",	pet->long_descr,	fread_string(fp));
	     KEY( "LogO",	lastlogoff,		fread_number(fp));
    	     break;
    	     
    	case 'N':
    	     KEY( "Name",	pet->name,		fread_string(fp));
    	     break;
    	     
    	case 'P':
    	     KEY( "Pos",	pet->position,		fread_number(fp));
    	     break;
    	     
	case 'R':
    	    KEY( "Race",	pet->race, race_lookup(fread_string(fp)));
    	    break;
 	    
    	case 'S' :
    	    KEY( "Save",	pet->saving_throw,	fread_number(fp));
    	    KEY( "Sex",		pet->sex,		fread_number(fp));
    	    KEY( "ShD",		pet->short_descr,	fread_string(fp));
    	    break;
    	    
    	if ( !fMatch )
    	{
    	    log_bug("Fread_pet: no match.",0);
    	    fread_to_eol(fp);
    	}
    	
    	}
    }
}



void fread_obj( void *vo, FILE *fp, bool fBank, bool fVault )
{
    Character *ch=NULL;
    Room *r=NULL;
    Object *obj;
    char *word;
    int iNest;
    bool fMatch;
    bool fNest;
    bool fVnum;
    bool first;
    bool new_format;  /* to prevent errors */
    bool make_new;    /* update object */
   
    if ( fVault )
		r = (Room *) vo;
    else
		ch = (Character *) vo; 

    fVnum = FALSE;
    obj = NULL;
    first = TRUE;  /* used to counter fp offset */
    new_format = FALSE;
    make_new = FALSE;

    word   = feof( fp ) ? "End" : fread_word( fp );
    if (!str_cmp(word,"Vnum" ))
    {
        int vnum;
	    first = FALSE;  /* fp will be in right place */
 
        vnum = fread_number( fp );
        if (  get_obj_index( vnum )  == NULL )
            log_bug( "Fread_obj: bad vnum %d.", vnum );
        else
	    {
	        obj = create_object(get_obj_index(vnum));
	        new_format = TRUE;
	    }
	    
    }

    if (obj == NULL)  /* either not found or old style */
    {
    	obj = new_obj();
    	obj->name		= str_dup( "" );
    	obj->short_descr	= str_dup( "" );
    	obj->description	= str_dup( "" );
    }

    fNest		= FALSE;
    fVnum		= TRUE;
    iNest		= 0;

    for ( ; ; )
    {
		if (first)
	    	first = FALSE;
		else
	    	word   = feof( fp ) ? "End" : fread_word( fp );

		fMatch = FALSE;

		switch ( UPPER(word[0]) )
		{
		case '*':
	    	fMatch = TRUE;
	    	fread_to_eol( fp );
	    	break;
	
	case 'A':
		KEY( "Absorb",	obj->absorb,	fread_number( fp ) );
	    if (!str_cmp(word,"AffD"))
	    {
			Affect *paf;
			int sn;

			paf = new_affect();

			sn = skill_lookup(fread_word(fp));
			if (sn < 0)
		    	log_bug("Fread_obj: unknown skill.",0);
			else
		    	paf->type = sn;

			paf->level	= fread_number( fp );
			paf->duration	= current_time + fread_long( fp );
			paf->modifier	= fread_number( fp );
			paf->location	= fread_number( fp );
			paf->bitvector	= fread_number( fp );
			paf->next	= obj->affected;
			obj->affected	= paf;
			fMatch		= TRUE;
			break;
	    }

            if (!str_cmp(word, "Affc") || !str_cmp(word,"AffcSp") )
            {
                Affect *paf;
                int sn;
                bool fSp = !str_cmp(word,"AffcSp");
                char *tmp;
                long dur;

                tmp = fread_word(fp);
                paf = new_affect();

                sn = fSp ? spell_lookup(tmp,-1) : skill_lookup(tmp);

                paf->where          = fread_number(fp);
				paf->where			= TO_OBJECT;

                paf->level          = fread_number( fp );
                dur = fread_long( fp );
                paf->modifier       = fread_number( fp );
                paf->location       = fread_number( fp );
                paf->duration       = paf->location == APPLY_BLADETURN ? dur : current_time + dur;
				if ( dur == DUR_PERMANENT )
					paf->duration = dur;

                paf->bitvector      = fread_number( fp );
                paf->flags      = fread_number( fp );
                if ( IS_SET(paf->flags,AFF_OBJ) )
                    paf->type = sn;

				if ( obj->version >= 2 )
					paf->misc		= fread_number( fp );

                if ( fSp )
                    paf->flags      = 1;

                paf->next           = obj->affected;
                obj->affected        = paf;
                fMatch = TRUE;
                break;
            }

	    break;

	case 'C':
        KEY( "Crafter", obj->crafter,       fread_string( fp ) );
	    KEY( "Cond",	obj->condition,		fread_number( fp ) );
	    KEY( "Cost",	obj->cost,		fread_number( fp ) );
		KEY( "Crater",	obj->crafter,	fread_string( fp ) );
	    break;

	case 'D':
	    KEY( "Description",	obj->description,	fread_string( fp ) );
	    KEY( "Desc",	obj->description,	fread_string( fp ) );
		KEY( "Dur",		obj->durability, 	fread_number( fp ) );
	    break;

	case 'E':

	    if ( !str_cmp( word, "Enchanted"))
	    {
		obj->enchanted = TRUE;
	 	fMatch 	= TRUE;
		break;
	    }

	    KEY( "ExtraFlags",	obj->extra_flags,	fread_number( fp ) );
	    KEY( "ExtF",	obj->extra_flags,	fread_number( fp ) );

	    if ( !str_cmp( word, "ExtraDescr" ) || !str_cmp(word,"ExDe"))
	    {
		ExtraDescr *ed;

		ed = new_extra_descr();

		ed->keyword		= fread_string( fp );
		ed->description		= fread_string( fp );
		ed->next		= obj->extra_descr;
		obj->extra_descr	= ed;
		fMatch = TRUE;
	    }

	    if ( !str_cmp( word, "End" ) )
	    {
		extern Object *obj_free;

		if ( !fNest || ( fVnum && obj->pIndexData == NULL ) )
		{
		    log_bug( "Fread_obj: incomplete object.", 0 );
		    free_string( obj->name        );
		    free_string( obj->description );
		    free_string( obj->short_descr );
		    obj->next = obj_free;
		    obj_free  = obj;
		    return;
		}
		else
	        {
		    if ( !fVnum )
		    {
		        free_string( obj->name        );
		        free_string( obj->description );
			free_string( obj->short_descr );
			obj->next = obj_free;
			obj_free  = obj;

			obj = create_object( get_obj_index( OBJ_VNUM_DUMMY ) );
		    }

		    if (!new_format)
		    {
		    	obj->next	= object_list;
		    	object_list	= obj;
		    	obj->pIndexData->count++;
		    }
			else

		    if (!obj->pIndexData->new_format 
		    && obj->item_type == ITEM_ARMOR
		    &&  obj->value[1] == 0)
		    {
			obj->value[1] = obj->value[0];
			obj->value[2] = obj->value[0];
		    }
		    if (make_new)
		    {
			int wear;
			
			wear = obj->wear_loc;
			extract_obj(obj);

			obj = create_object(obj->pIndexData);
			obj->wear_loc = wear;
		    }
		    if ( iNest == 0 || rgObjNest[iNest] == NULL )
		    {
			if ( fVault )
			    obj_to_room( obj, r );
			else
			if ( fBank )
			    obj_to_bank( ch, obj );
			else
			    obj_to_char( obj, ch );
 		    }
		    else
			obj_to_obj( obj, rgObjNest[iNest-1] );

    		/* Set conditions */
    		if ( obj->condition <= 0 )
        		obj->condition = 100;
    		if ( obj->durability <= 0 )
        		obj->durability = 100;   
    		if ( obj->quality <= 0 )     
        		obj->quality = 100;

		    return;
		}

	    }
	    break;

	case 'H':
        if ( !str_cmp( word, "HVal" ) )
        {
        	obj->value[5]   = fread_number( fp );
        	obj->value[6]   = fread_number( fp );
        	obj->value[7]   = fread_number( fp );
        	obj->value[8]   = fread_number( fp );
        	obj->value[9]   = fread_number( fp );
        	fMatch = TRUE;
        	break;
        }

		break;

	case 'I':
	    KEY( "ItemType",	obj->item_type,		fread_number( fp ) );
	    KEY( "Ityp",	obj->item_type,		fread_number( fp ) );
	    break;

	case 'L':
	    KEY( "Level",	obj->level,		fread_number( fp ) );
	    KEY( "Lev",		obj->level,		fread_number( fp ) );
	    break;

	case 'N':
	    KEY( "Name",	obj->name,		fread_string( fp ) );

	    if ( !str_cmp( word, "Nest" ) )
	    {
		iNest = fread_number( fp );
		if ( iNest < 0 || iNest >= MAX_NEST )
		{
		    log_bug( "Fread_obj: bad nest %d.", iNest );
		}
		else
		{
		    rgObjNest[iNest] = obj;
		    fNest = TRUE;
		}
		fMatch = TRUE;
	    }
	    break;

   	case 'O':
	    if ( !str_cmp( word,"Oldstyle" ) )
	    {
		if (obj->pIndexData != NULL && obj->pIndexData->new_format)
		    make_new = TRUE;
		fMatch = TRUE;
	    }
	    break;
		    
	case 'Q':
		KEY( "Qua",	obj->quality,	fread_number( fp ) );
		break;

	case 'S':
	    KEY( "ShortDescr",	obj->short_descr,	fread_string( fp ) );
	    KEY( "ShD",		obj->short_descr,	fread_string( fp ) );


            if ( !str_cmp( word, "SpellB" ) )
            {
                int iValue;
                int sn;

                iValue = fread_number( fp );
                sn     = spell_lookup( fread_word( fp ),0);
                if ( iValue < 0 || iValue > 19 )
                {
                    log_bug( "Fread_obj: bad spellbook iValue %d.", iValue );
                }
                else if ( sn < 0 )
                {
                    log_bug( "Fread_obj: unknown spell.", 0 );
                }
                else
                {
					if ( iValue < 10 )
                    	obj->value[iValue] = set10Bits( obj->value[iValue], sn );
					else
						obj->value[iValue-10] = set20Bits( obj->value[iValue-10], sn );
                }
                fMatch = TRUE;
                break;
            }

	    if ( !str_cmp( word, "Spell" ) )
	    {
		int iValue;
		int sn;

		iValue = fread_number( fp );
		sn     = skill_lookup( fread_word( fp ) );
		if ( iValue < 0 || iValue > 3 )
		{
		    log_bug( "Fread_obj: bad iValue %d.", iValue );
		}
		else if ( sn < 0 )
		{
		    log_bug( "Fread_obj: unknown skill.", 0 );
		}
		else
		{
		    obj->value[iValue] = sn;
		}
		fMatch = TRUE;
		break;
	    }

	    break;

	case 'T':
	    KEY( "Timer",	obj->timer,		fread_number( fp ) );
	    KEY( "Time",	obj->timer,		fread_number( fp ) );
	    break;

	case 'V':
		KEY( "Vers",		obj->version,		fread_number( fp ) );
		KEY( "Version",		obj->version,		fread_number( fp ) );

	    if ( !str_cmp( word, "Values" ) || !str_cmp(word,"Vals"))
	    {
		obj->value[0]	= fread_number( fp );
		obj->value[1]	= fread_number( fp );
		obj->value[2]	= fread_number( fp );
		obj->value[3]	= fread_number( fp );
		if (obj->item_type == ITEM_WEAPON && obj->value[0] == 0)
		   obj->value[0] = obj->pIndexData->value[0];
		fMatch		= TRUE;
		break;
	    }

	    if ( !str_cmp( word, "Val" ) )
	    {
		obj->value[0] 	= fread_number( fp );
	 	obj->value[1]	= fread_number( fp );
	 	obj->value[2] 	= fread_number( fp );
		obj->value[3]	= fread_number( fp );
		obj->value[4]	= fread_number( fp );
		fMatch = TRUE;
		break;
	    }

	    if ( !str_cmp( word, "Vnum" ) )
	    {
		int vnum;

		vnum = fread_number( fp );
		if ( ( obj->pIndexData = get_obj_index( vnum ) ) == NULL )
		    log_bug( "Fread_obj: bad vnum %d.", vnum );
		else
		    fVnum = TRUE;
		fMatch = TRUE;
		break;
	    }

		break;

	case 'W':
	    KEY( "WearFlags",	obj->wear_flags,	fread_number( fp ) );
	    KEY( "WeaF",	obj->wear_flags,	fread_number( fp ) );
	    KEY( "WearLoc",	obj->wear_loc,		fread_number( fp ) );
	    KEY( "Wear",	obj->wear_loc,		fread_number( fp ) );
	    KEY( "Weight",	obj->weight,		fread_number( fp ) );
	    KEY( "Wt",		obj->weight,		fread_number( fp ) );
	    break;

	}

	if ( !fMatch )
	{
	    log_bug( "Fread_obj: no match for %s", word );
	    fread_to_eol( fp );
	}
    }

	/* Set conditions */
	if ( obj->condition <= 0 )
		obj->condition = 100;
	if ( obj->durability <= 0 )
		obj->durability = 100;
	if ( obj->quality <= 0 )
		obj->quality = 100;
}

void writeAffectList( FILE *fp, Affect *paflist )
{
	writeAffectListPrefixed( fp, paflist, "" );
}

void writeAffectListPrefixed( FILE *fp, Affect *paflist, char *prefix )
{
	Affect *paf;

    for ( paf = paflist; paf != NULL; paf = paf->next )     
    {
        if ( paf->type >= 0 && paf->type <= MAX_SKILL && IS_SET(paf->flags,AFF_SKILL) )
            fprintf( fp, "%sAffc '%s' %3d %3d %d %3d %3d %10d %10ld %d\n",
				prefix,
                skill_table[paf->type].name, paf->where, paf->level,
                paf->duration == DUR_PERMANENT ? DUR_PERMANENT : (paf->location == APPLY_BLADETURN ? paf->duration : /* convert to seconds */ UMAX(0,paf->duration - current_time)),
                paf->modifier, paf->location, paf->bitvector, paf->flags, paf->misc );
    }

    for ( paf = paflist; paf != NULL; paf = paf->next )
    {
		if ( paf->type >=0 && paf->type <= top_spell_vnum && IS_SET(paf->flags,AFF_SPELL) )
		{
			SpellIndex* pSpellIndex;

			if( (pSpellIndex = get_spell_index(paf->type)) != NULL )
			{
				fprintf( fp, "%sAffcSp '%s' %3d %3d %d %3d %3d %10d %10ld %d\n",
					prefix,
					pSpellIndex->name, paf->where, paf->level,
					paf->duration == DUR_PERMANENT ? DUR_PERMANENT : (paf->location == APPLY_BLADETURN ? paf->duration : /* convert to seconds */ UMAX(0,paf->duration - current_time)),
					paf->modifier, paf->location, paf->bitvector, paf->flags, paf->misc );
			}
			else
			{
				log_bug("writeAffectListPrefixed: Spell index not found(%d)", paf->type);
			}
		}
    }

	for( paf = paflist; paf != NULL; paf = paf->next )
	{
		if ( paf->type < 0 )
		{
			fprintf( fp, "%sAffcSp '-1' %3d %3d %d %3d %3d %10d %10ld %d\n",
				prefix,
                paf->where, paf->level,
                paf->duration == DUR_PERMANENT ? DUR_PERMANENT : (paf->location == APPLY_BLADETURN ? paf->duration : /* convert to seconds */ UMAX(0,paf->duration - current_time)),
                paf->modifier, paf->location, paf->bitvector, paf->flags, paf->misc );
		}
	}

	return;
}

void save_game_info( void )
{
	FILE *fp;
	extern void fwrite_game_data( FILE *fp );

#if defined(__OLC) || defined(__TEST)
	return;
#endif

	fclose( fpReserve );
	if ( (fp = fopen( ARPENS_FILE, "w" )) == NULL ) 
	{
		log_bug("Could not open %s", ARPENS_FILE );
		return;
	}

	fwrite_game_data( fp );
	fclose( fp );
	fpReserve = fopen( NULL_FILE, "r" );
}

#define CURRENT_VERSION 1
void fwrite_game_data( FILE *fp )
{
	int i;

	fprintf(fp,"Version=%d\n", CURRENT_VERSION );
	fprintf(fp,"MostPlayersEver=%d\n", GameInfo.mostPlayersEver );
	fprintf(fp,"MostPlayersWhen=%d\n", GameInfo.mostPlayersWhen );
	fprintf(fp,"TotalNewbies=%d\n", GameInfo.totalNewbies );
	fprintf(fp,"TotalDeleted=%d\n", GameInfo.totalDeleted );
	fprintf(fp,"TotalCurrent=%d\n", GameInfo.totalCurrent );
	for( i = 1 ; subrace_table[i].name != NULL ; i++ )
		fprintf(fp,"NumberOf%s=%d\n", capitalize(subrace_table[i].name), GameInfo.numberOfSubrace[i] );
	for( i = 0 ; i < MAX_CLASS ; i++ )
		fprintf(fp,"NumberOf%s=%d\n", capitalize(class_table[i].name), GameInfo.numberOfClass[i] );
	/*
	for( i = 0 ; i < MAX_USAGE ; i++ )
		fprintf(fp,"Usage %s %d %d\n", usage_name[i], GameInfo.usage[i].periods, GameInfo.usage[i].logons );
	*/
}

Journal *readJournal( FILE *fp )
{
	Journal *j;

	j = newJournal( );
	j->recipeList = fread_string( fp );
	j->questList  = fread_string( fp );

	if (!strcmp(j->recipeList,"null"))
		j->recipeList = NULL;
	if (!strcmp(j->questList,"null"))	
		j->questList = NULL;

	/* Read until we get a JE */
	while( 1 )
	{
		char *tmp;
		JEvent *je;

		tmp = fread_word(fp);
		if ( !str_cmp(tmp,"EndJ") )
			break;

		je = newJEvent( );
		je->when = fread_number( fp );
		je->description = fread_string( fp );
		eventToJournal( je, j );
	}
	return j;
}

void writeJournal( FILE *fp, Journal *j )
{
	if ( j == NULL )
		return;

	fprintf(fp,"Journ\n");
	fprintf(fp,"%s~\n", j->recipeList == NULL ? "null" : j->recipeList );
	fprintf(fp,"%s~\n", j->questList == NULL ? "null" : j->questList );
	writeJEvents( fp, j->eventList );
	fprintf(fp,"EndJ\n");
}

void writeJEvents( FILE *fp, JEvent *je )
{
	if ( je == NULL )
		return;

	if ( je->next != NULL )
		writeJEvents( fp, je->next );

	fprintf(fp,"JE %d %s~\n", je->when, je->description );
	return;
}

bool room_has_pc_corpse( Room *r )
{
	Object *o;
 
	for( o = r->contents ; o ; o = o->next_content )
		if ( o->item_type == ITEM_CORPSE_PC )
			return TRUE;

	return FALSE;
}

void writeBuildings( FILE *fp, int vnum, Building *bld )
{
	if ( bld->next != NULL )
		writeBuildings(fp,vnum,bld->next);

	fprintf(fp,"%d building '%s' %s %d %d %d %d %d %d '%s'\n",
		vnum, flag_string( building_flags, bld->type ),
		print_flags( bld->flags ), bld->curr_structure, bld->max_structure,
		bld->material, bld->level, bld->entrance_room, bld->available_resources,
		bld->clan_owner->name );
}

void save_race_avail( void )
{
	FILE *fp;
	int i;

	fclose( fpReserve );
	if ( (fp = fopen( RACE_FILE, "w" )) == NULL )
	{
		log_error("Failed to open race file %s", RACE_FILE);
		return;
	}

	for( i=1 ; subrace_table[i].name != NULL; i++ )
	{
        if ( subrace_table[i].next_avail == NULL )
            continue;

        fprintf( fp, "%s %d\n", subrace_table[i].name, *subrace_table[i].next_avail );
	}

	fprintf(fp,"-1\n");
	fclose( fp );
	fpReserve = fopen( NULL_FILE, "r" );
	return;
}

void write_building_file( void )
{
	FILE *fp;
	Room *r;
	int i;

	fclose( fpReserve );
	if ( (fp = fopen( BUILDING_FILE, "w" )) == NULL )
	{
		log_error("Failed to open building file %s", BUILDING_FILE);
		return;
	}

	for( i=0 ; i<100000 ; i++ )
	{
		if ( (r = get_room_index(i)) == NULL )
			continue;

		if ( r->clan != NULL )
			fprintf( fp, "%d claim '%s'\n", r->vnum, r->clan->name );

		if ( r->buildings != NULL )
			writeBuildings( fp, r->vnum, r->buildings );
	}

	fprintf(fp,"-1\n");
	fclose( fp );
	fpReserve = fopen( NULL_FILE, "r" );
	return;
}
	
void write_resource_file( void )
{
	FILE *fp;
	Room *r;
	Resource *rsc;
	int i;

	fclose( fpReserve );
	if ( (fp = fopen( RESOURCE_FILE, "w" )) == NULL )
	{
		log_error("Failed to open resource file %s", RESOURCE_FILE);
		return;
	}

	for( i=0 ; i<50000 ; i++ )
	{
		if ( (r = get_room_index(i)) == NULL )
			continue;

		for( rsc = r->resources ; rsc != NULL ; rsc = rsc->next )
			fprintf(fp,"%d %d %d\n", r->vnum, rsc->resource, rsc->amount );
	}

	fprintf(fp,"-1 0 0\n");
	fclose( fp );
	fpReserve = fopen( NULL_FILE, "r" );
	return;
}
