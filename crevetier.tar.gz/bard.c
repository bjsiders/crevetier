/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.
****************************************************************************/

/******************************************************************
 ArpensMUD 3.2, Server II.  Arcane Spell System "Khav" Release 1.0
 Copyright Benjamin J. Siders, Cross-Check MSDG 2001, 2002 
 
 The Cleric-specific spells from the 'fury' release.  

 All of the "Fury" spells are based on concepts from:
 
 Ultima, EverQuest, Dungeons and Dragons, Advanced Dungeons and Dragons, 
 Earthdawn, Baldur's Gate, Shadows of Amn, Quest for Glory, and untold
 other games we've all played.
 ******************************************************************/

/** System Include Files **/
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/** Custom Header Files **/
#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "tables.h"
#include "recycle.h"

bool spell_bard_haste(int sn,int level,Character *ch,int mod);
bool spell_bard_slow(int sn,int level,Character *ch,void *vo,int mod);
bool spell_bard_fire_ice_buff(int sn,int level,Character *ch,int mod);
bool spell_bard_pois_disease_buff(int sn,int level,Character *ch,int mod);

/** The library of bard songs, arranged alphabetically */
bool spell_accelerando(int sn,int level,Character *ch,void *vo,int target)
{
	spell_bard_haste(sn,level,ch,92);
	return TRUE;
}

bool spell_andante(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_haste(sn,level,ch,84);
	return TRUE;
}

bool spell_allegretto(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_haste(sn,level,ch,76);
	return TRUE;
}

bool spell_allegro(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_haste(sn,level,ch,68);
	return TRUE;
}

bool spell_vivace(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_haste(sn,level,ch,60);
	return TRUE;
}


bool spell_hale_hymn(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_pois_disease_buff(sn,level,ch,4);
    return TRUE;
}

bool spell_robust_rubato(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_pois_disease_buff(sn,level,ch,8);
    return TRUE;
}

bool spell_stout_serenata(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_pois_disease_buff(sn,level,ch,15);
    return TRUE;
}

bool spell_vigorous_volta(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_pois_disease_buff(sn,level,ch,30);
    return TRUE;
}

bool spell_waltz_of_warding(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_fire_ice_buff(sn,level,ch,4); 
    return TRUE;
}

bool spell_reel_of_resistance(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_fire_ice_buff(sn,level,ch,8); 
    return TRUE;
}

bool spell_dumka_of_deterance(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_fire_ice_buff(sn,level,ch,15); 
    return TRUE;
}
bool spell_idyll_of_immunity(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_fire_ice_buff(sn,level,ch,30); 
    return TRUE;
}

bool spell_bard_fire_ice_buff(int sn,int level,Character *ch,int mod)
{
    Character *victim;
	int i;
    Affect af;

	for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
	{
		if ( (victim = ch->pgroup->members[i]) != NULL &&
			victim->in_room == ch->in_room )
		{
    		af.where     = TO_AFFECTS;
			af.caster_id = ch->id;
    		af.type      = sn;
    		af.level     = level;
    		af.duration  = minutes(4);
    		af.location  = APPLY_RES_FIRE;
    		af.modifier  = mod;
    		af.bitvector = 0;
    		af.flags     = AFF_SPELL;
    		spellAffectToChar( victim, &af );

			af.location		= APPLY_RES_ICE;;
			spellAffectToChar( victim, &af );
			act("You are protected from the elements.",victim,NULL,NULL,TO_CHAR);
		}
	}
	return TRUE;
}

bool spell_bard_pois_disease_buff(int sn,int level,Character *ch,int mod)
{
    Character *victim;
	int i;
    Affect af;

	for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
	{
		if ( (victim = ch->pgroup->members[i]) != NULL &&
			victim->in_room == ch->in_room )
		{
    		af.where     = TO_AFFECTS;
			af.caster_id = ch->id;
    		af.type      = sn;
    		af.level     = level;
    		af.duration  = minutes(4);
    		af.location  = APPLY_RES_POISON;
    		af.modifier  = mod;
    		af.bitvector = 0;
    		af.flags     = AFF_SPELL;
    		spellAffectToChar( victim, &af );

			af.location		= APPLY_RES_DISEASE;;
			spellAffectToChar( victim, &af );
			act("You feel hale and healthy.",victim,NULL,NULL,TO_CHAR);
		}
	}
	return TRUE;
}

bool spell_bard_hp_buff(int sn,int level,Character *ch,int base, int stat )
{
    Character *victim;
	int i;
    Affect af;

	for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
	{
		if ( (victim = ch->pgroup->members[i]) != NULL &&
			victim->in_room == ch->in_room )
		{
    		af.where     = TO_AFFECTS;
			af.caster_id = ch->id;
    		af.type      = sn;
    		af.level     = level;
    		af.duration  = minutes(4);
    		af.location  = APPLY_BASE_HITS;
    		af.modifier  = base;
    		af.bitvector = 0;
    		af.flags     = AFF_SPELL;
    		spellAffectToChar( victim, &af );

			af.location		= APPLY_HIT;
			af.modifier		= stat;
			spellAffectToChar( victim, &af );
			act("You feel indominable!",victim,NULL,NULL,TO_CHAR);

			victim->base_hit += base;
		}
	}
	return TRUE;
}

bool spell_rhythm_of_boldness(int sn,int level,Character *ch,void *vo,int target)
{
	return spell_bard_hp_buff(sn,level,ch,5,40);
}

bool spell_rhythm_of_constancy(int sn,int level,Character *ch,void *vo,int target)
{
	return spell_bard_hp_buff(sn,level,ch,10,80);
}

bool spell_rhythm_of_valiency(int sn,int level,Character *ch,void *vo,int target)
{
	return spell_bard_hp_buff(sn,level,ch,20,120);
}

bool spell_rhythm_of_resolve(int sn,int level,Character *ch,void *vo,int target)
{
	return spell_bard_hp_buff(sn,level,ch,30,180);
}

bool spell_dauntless_anthem(int sn,int level,Character *ch,void *vo,int target)
{
	return spell_bard_hp_buff(sn,level,ch,50,250);
}

bool spell_bard_haste(int sn,int level,Character *ch,int mod)
{
    Character *victim;
	int i;
    Affect af;

	for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
	{
		if ( (victim = ch->pgroup->members[i]) != NULL &&
			victim->in_room == ch->in_room )
		{
    		af.where     = TO_AFFECTS;
			af.caster_id = ch->id;
    		af.type      = sn;
    		af.level     = level;
    		af.duration  = minutes(4);
    		af.location  = APPLY_SPEED;
    		af.modifier  = mod;
    		af.bitvector = AFF_HASTE;
    		af.flags     = AFF_SPELL;
    		spellAffectToChar( victim, &af );

			act("You feel your body moving more rapidly!",victim,NULL,NULL,TO_CHAR);
		}
	}
	return TRUE;
}

bool spell_decelerando(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_slow(sn,level,ch,vo,108);
	return TRUE;
}

bool spell_lento(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_slow(sn,level,ch,vo,116);
	return TRUE;
}

bool spell_largo(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_slow(sn,level,ch,vo,124);
	return TRUE;
}

bool spell_morte(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_slow(sn,level,ch,vo,132);
	return TRUE;
}

bool spell_grave(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_slow(sn,level,ch,vo,140);
	return TRUE;
}

bool spell_bard_ac_debuff(int sn,int level,Character *ch,void *vo,int mod)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SOUND, SAVE_FORTITUDE) )
	{
		act("$N appears to be unaffected.",ch,NULL,victim,TO_CHAR);
		return TRUE;
	}

    af.where     = TO_AFFECTS;
	af.caster_id = ch->id;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(2);
    af.location  = APPLY_AC;
    af.modifier  = mod;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

	act("You feel vulnerable and debilitated.",victim,NULL,NULL,TO_CHAR);
	return TRUE;
}

bool spell_dirge_of_debility(int sn,int level,Character *ch,void *vo,int target)  
{
    spell_bard_ac_debuff(sn,level,ch,vo,-20);
    return TRUE;
}

bool spell_dirge_of_deficiency(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_ac_debuff(sn,level,ch,vo,-48);
    return TRUE;
}

bool spell_furiant_of_fragility(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_ac_debuff(sn,level,ch,vo,-80);
    return TRUE;
}

bool spell_furiant_of_frailty(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_ac_debuff(sn,level,ch,vo,-116);
    return TRUE;
}

bool spell_lament_of_languor(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_ac_debuff(sn,level,ch,vo,-156);
    return TRUE;
}

bool spell_lament_of_lacking(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_ac_debuff(sn,level,ch,vo,-200);
    return TRUE;
}

bool spell_bard_slow(int sn,int level,Character *ch,void *vo,int mod)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SOUND, SAVE_FORTITUDE) )
	{
		act("$N appears to be unaffected.",ch,NULL,victim,TO_CHAR);
		return TRUE;
	}

    af.where     = TO_AFFECTS;
	af.caster_id = ch->id;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(2);
    af.location  = APPLY_SPEED;
    af.modifier  = mod;
    af.bitvector = AFF_SLOW;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

	act("You feel your body moving more slowly!",victim,NULL,NULL,TO_CHAR);
    act("$N begins to move more slowly!",victim,NULL,NULL,TO_ROOM);
	return TRUE;
}


bool spell_bard_hit_ac_buff(int sn,int level,Character *ch,int hit_mod,int ac_mod,char *echo)
{
    Character *victim;
	int i;
    Affect af;

	for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
	{
		if ( (victim = ch->pgroup->members[i]) != NULL &&
			victim->in_room == ch->in_room )
		{
    		af.where     = TO_AFFECTS;
			af.caster_id = ch->id;
    		af.type      = sn;
    		af.level     = level;
    		af.duration  = minutes(4);
    		af.location  = APPLY_HITROLL;
    		af.modifier  = hit_mod;
    		af.bitvector = 0;
    		af.flags     = AFF_SPELL;
    		spellAffectToChar( victim, &af );

			af.location		= APPLY_AC;
			af.modifier		= ac_mod;
			spellAffectToChar( victim, &af );

			act(echo,victim,NULL,NULL,TO_CHAR);
		}
	}
	return TRUE;
}

bool spell_call_to_arms(int sn,int level,Character *ch,void *vo,int target)
{
	return spell_bard_hit_ac_buff(sn,level,ch,10,16,"You are inspired by the Call to arms!");
}

bool spell_battle_summons(int sn,int level,Character *ch,void *vo,int target)
{
    return spell_bard_hit_ac_buff(sn,level,ch,48,32,"You are inspired by the Battle Summons!");
}

bool spell_rousing_rhythm(int sn,int level,Character *ch,void *vo,int target)
{
    return spell_bard_hit_ac_buff(sn,level,ch,80,48,"You are inspired by the Rousing Rhythm!");
}

bool spell_war_cry(int sn,int level,Character *ch,void *vo,int target)
{
    return spell_bard_hit_ac_buff(sn,level,ch,125,80,"You are inspired by the War Cry!");
}

bool spell_military_anthem(int sn,int level,Character *ch,void *vo,int target)
{
    return spell_bard_hit_ac_buff(sn,level,ch,175,120,"You are inspired by the Military Anthem!");
}

bool spell_song_of_heroes(int sn,int level,Character *ch,void *vo,int target)
{
    return spell_bard_hit_ac_buff(sn,level,ch,230,200,"You are inspired by the Song of Heroes!");
}

bool spell_bard_int_buff(int sn,int level,Character *ch,int mod)
{
    Character *victim;
    int i;
    Affect af;

    for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
    {
        if ( (victim = ch->pgroup->members[i]) != NULL &&
            victim->in_room == ch->in_room )
        {
            af.where     = TO_AFFECTS;
            af.caster_id = ch->id;
            af.type      = sn;
            af.level     = level;
            af.duration  = minutes(4);
            af.location  = APPLY_WIS;
            af.modifier  = mod;
            af.bitvector = 0;
            af.flags     = AFF_SPELL;
            spellAffectToChar( victim, &af );

			af.location		= APPLY_INT;
			spellAffectToChar( victim, &af );

			act("You feel better protected from harm.",victim,NULL,NULL,TO_CHAR);
        }
    }
    return TRUE;
}

bool spell_song_of_the_academic(int sn,int level,Character *ch,void *vo,int target)
{
	return spell_bard_int_buff(sn,level,ch,15);
}

bool spell_song_of_the_philosopher(int sn,int level,Character *ch,void *vo,int target)
{
	return spell_bard_int_buff(sn,level,ch,30);
}

bool spell_song_of_the_pundit(int sn,int level,Character *ch,void *vo,int target)
{
    return spell_bard_int_buff(sn,level,ch,45);
}

bool spell_song_of_the_illuminati(int sn,int level,Character *ch,void *vo,int target)
{
    return spell_bard_int_buff(sn,level,ch,60);
}

bool spell_bard_charisma_buff(int sn,int level,Character *ch,int mod)
{
    Character *victim;
    int i;
    Affect af;

    for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
    {
        if ( (victim = ch->pgroup->members[i]) != NULL &&
            victim->in_room == ch->in_room )
        {
            af.where     = TO_AFFECTS;
            af.caster_id = ch->id;
            af.type      = sn;
            af.level     = level;
            af.duration  = minutes(12);
            af.location  = APPLY_CHA;
            af.modifier  = mod;
            af.bitvector = 0;
            af.flags     = AFF_SPELL;
            spellAffectToChar( victim, &af );

			act("You radiate with personality.",victim,NULL,NULL,TO_CHAR);
        }
    }
    return TRUE;
}

bool spell_charismatic_ayre(int sn,int level,Character *ch,void *vo,int target)
{
	return spell_bard_charisma_buff(sn,level,ch,20);
}

bool spell_affable_ayre(int sn,int level,Character *ch,void *vo,int target)
{
    return spell_bard_charisma_buff(sn,level,ch,40);
}

bool spell_amiable_ayre(int sn,int level,Character *ch,void *vo,int target)
{
    return spell_bard_charisma_buff(sn,level,ch,60);
}

bool spell_alluring_ayre(int sn,int level,Character *ch,void *vo,int target)
{
    return spell_bard_charisma_buff(sn,level,ch,80);
}

bool spell_bard_absorb(int sn,int level,Character *ch,int mod)
{
    Character *victim;
    int i;
    Affect af;

    for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
    {
        if ( (victim = ch->pgroup->members[i]) != NULL &&
            victim->in_room == ch->in_room )
        {
            af.where     = TO_AFFECTS;
            af.caster_id = ch->id;
            af.type      = sn;
            af.level     = level;
            af.duration  = minutes(4);
            af.location  = APPLY_ABSORB;
            af.modifier  = mod;;
            af.bitvector = 0;
            af.flags     = AFF_SPELL;
            spellAffectToChar( victim, &af );

			act("You feel better protected from harm.",victim,NULL,NULL,TO_CHAR);
        }
    }
    return TRUE;
}

bool spell_march_of_absorbtion(int sn,int level,Character *ch,void *vo,int target)
{
	return spell_bard_absorb(sn,level,ch,5);
}

bool spell_march_of_consumption(int sn,int level,Character *ch,void *vo,int target)
{
	return spell_bard_absorb(sn,level,ch,10);
}

bool spell_march_of_devouring(int sn,int level,Character *ch,void *vo,int target)
{
	return spell_bard_absorb(sn,level,ch,15);
}

bool spell_march_of_dissipation(int sn,int level,Character *ch,void *vo,int target)
{
	return spell_bard_absorb(sn,level,ch,20);
}

bool spell_noise( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(7),highDam(14));

    if ( check_saves_spell(ch, victim, DAM_SOUND, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SOUND , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_clamor( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(16),highDam(35));   

    if ( check_saves_spell(ch, victim, DAM_SOUND, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SOUND , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_resound( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(35),highDam(70));   

    if ( check_saves_spell(ch, victim, DAM_SOUND, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SOUND , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_blast( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(62),highDam(124));   

    if ( check_saves_spell(ch, victim, DAM_SOUND, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SOUND , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_roar( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(101),highDam(203));   

    if ( check_saves_spell(ch, victim, DAM_SOUND, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SOUND , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_deafen( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int   dam;

    dam = calcSpellDamage(ch,sn,lowDam(156),highDam(313));   

    if ( check_saves_spell(ch, victim, DAM_SOUND, SAVE_FORTITUDE) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_SOUND , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_bolstering_ballad( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim;
    int i;
    Affect af;

    for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
    {
        if ( (victim = ch->pgroup->members[i]) != NULL &&
            victim->in_room == ch->in_room )
        {
            af.where     = TO_AFFECTS;
            af.caster_id = ch->id;
            af.type      = sn;
            af.level     = level;
            af.duration  = minutes(4);
            af.location  = APPLY_SAVE_FORTITUDE;
            af.modifier  = 15;
            af.bitvector = 0;
            af.flags     = AFF_SPELL;
            spellAffectToChar( victim, &af );
			af.location		= APPLY_SAVE_WILLPOWER;
			spellAffectToChar( victim, &af );
			af.location		= APPLY_SAVE_REFLEX;
			spellAffectToChar( victim, &af );

            act("You feel bolstered!",victim,NULL,NULL,TO_CHAR);
        }
    }
    return TRUE;
}


bool spell_augmenting_ayre( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim;
    int i;
    Affect af;

    for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
    {
        if ( (victim = ch->pgroup->members[i]) != NULL &&
            victim->in_room == ch->in_room )
        {
            af.where     = TO_AFFECTS;
            af.caster_id = ch->id;
            af.type      = sn;
            af.level     = level;
            af.duration  = minutes(4);
            af.location  = APPLY_SAVE_FORTITUDE;
            af.modifier  = 30;
            af.bitvector = 0;
            af.flags     = AFF_SPELL;
            spellAffectToChar( victim, &af );
            af.location     = APPLY_SAVE_WILLPOWER;
            spellAffectToChar( victim, &af );
            af.location     = APPLY_SAVE_REFLEX;
            spellAffectToChar( victim, &af );

            act("You feel bolstered!",victim,NULL,NULL,TO_CHAR);
        }
    }
    return TRUE;
}

bool spell_song_of_solidarity( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim;
    int i;
    Affect af;

    for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
    {
        if ( (victim = ch->pgroup->members[i]) != NULL &&
            victim->in_room == ch->in_room )
        {
            af.where     = TO_AFFECTS;
            af.caster_id = ch->id;
            af.type      = sn;
            af.level     = level;
            af.duration  = minutes(4);
            af.location  = APPLY_SAVE_FORTITUDE;
            af.modifier  = 45;
            af.bitvector = 0;
            af.flags     = AFF_SPELL;
            spellAffectToChar( victim, &af );
            af.location     = APPLY_SAVE_WILLPOWER;
            spellAffectToChar( victim, &af );
            af.location     = APPLY_SAVE_REFLEX;
            spellAffectToChar( victim, &af );

            act("You feel bolstered!",victim,NULL,NULL,TO_CHAR);
        }
    }
    return TRUE;
}

bool spell_bard_mana_regen(int sn,int level,Character *ch,int mod)
{
    Character *victim;
	int i;
    Affect af;

	for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
	{
		if ( (victim = ch->pgroup->members[i]) != NULL &&
			victim->in_room == ch->in_room )
		{
    		af.where     = TO_AFFECTS;
			af.caster_id = ch->id;
    		af.type      = sn;
    		af.level     = level;
    		af.duration  = minutes(4);
    		af.location  = APPLY_REGEN_MANA;
    		af.modifier  = mod;
    		af.bitvector = 0;
    		af.flags     = AFF_SPELL;
    		spellAffectToChar( victim, &af );

			act("Your mind is cleared of confusion and doubt.",victim,NULL,NULL,TO_CHAR);
		}
	}
	return TRUE;
}

bool spell_chorus_of_the_student(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_mana_regen(sn,level,ch,10);
    return TRUE;
}

bool spell_chorus_of_the_apprentice(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_mana_regen(sn,level,ch,20);
    return TRUE;
}

bool spell_chorus_of_the_acolyte(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_mana_regen(sn,level,ch,30);
    return TRUE;
}
bool spell_chorus_of_the_learned(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_mana_regen(sn,level,ch,50);
    return TRUE;
}

bool spell_bard_saves_debuff(int sn,int level,Character *ch,void *vo,int mod)
{
    Character *victim = (Character *) vo;
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_SOUND, SAVE_FORTITUDE) )
    {
        act("$N appears to be unaffected.",ch,NULL,victim,TO_CHAR);
        return TRUE;
    }

    af.where     = TO_AFFECTS;
    af.caster_id = ch->id;
    af.type      = sn;
    af.level     = level;
    af.duration  = minutes(4);
    af.location  = APPLY_SAVE_FORTITUDE;
    af.modifier  = mod;
    af.bitvector = 0;
    af.flags     = AFF_SPELL;
    spellAffectToChar( victim, &af );

	af.location	= APPLY_SAVE_WILLPOWER;
	spellAffectToChar( victim, &af );

	af.location	= APPLY_SAVE_REFLEX;
	spellAffectToChar( victim, &af );

    act("You feel uncomfortable and transparent.",victim,NULL,NULL,TO_CHAR);
    return TRUE;
}

bool spell_berate(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_saves_debuff(sn,level,ch,vo,-10);
    return TRUE;
}

bool spell_decry(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_saves_debuff(sn,level,ch,vo,-25);
    return TRUE;
}

bool spell_castigate(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_saves_debuff(sn,level,ch,vo,-40);
    return TRUE;
}

bool spell_bard_hero(int sn,int level,Character *ch,int mod)
{
    Character *victim;
    int i;
    Affect af;

    for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
    {
        if ( (victim = ch->pgroup->members[i]) != NULL &&
            victim->in_room == ch->in_room )
        {
            af.where     = TO_AFFECTS;
            af.caster_id = ch->id;
            af.type      = sn;
            af.level     = level;
            af.duration  = minutes(4);
            af.location  = APPLY_STR;
            af.modifier  = mod;
            af.bitvector = 0;
            af.flags     = AFF_SPELL;
            spellAffectToChar( victim, &af );

			af.location	= APPLY_CON;
			spellAffectToChar( victim, &af );

			af.location = APPLY_DEX;
			spellAffectToChar( victim, &af );

            act("Your heart swells with the spirit of the hero.",victim,NULL,NULL,TO_CHAR);
        }
    }
    return TRUE;
}

bool spell_tale_of_the_hero(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_hero(sn,level,ch,15);
    return TRUE;
}

bool spell_song_of_the_hero(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_hero(sn,level,ch,30); 
    return TRUE;
}

bool spell_canticle_of_the_hero(int sn,int level,Character *ch,void *vo,int target)
{
    spell_bard_hero(sn,level,ch,45); 
    return TRUE;
}


