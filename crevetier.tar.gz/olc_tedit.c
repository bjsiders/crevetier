/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include <sys/types.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "thoc.h"
#include "olc.h"
#include "tables.h"
#include "lookup.h"
#include "recycle.h"

TEDIT( tedit_component )
{
	Recipe *pRec;
	int index;
	ObjIndex *obj;
	char arg[MAX_INPUT_LENGTH];

	EDIT_RECIPE(ch,pRec);

	argument = one_argument( argument, arg );
	if ( arg[0] == '\0' || *argument == '\0' )
	{
		cprintf(ch,"Usage: component <#> <vnum>\n\r");
		return FALSE;
	}

	if ( (index=atoi(arg)) < 1 || index > 10 )
	{
		cprintf(ch,"Component # must be between 1 and 10 inclusive.\n\r");
		return FALSE;
	}

	--index; /* C offsets start at 0 */
	if ( atoi(argument) < 0 )
	{
		cprintf(ch,"Component vnum must be positive.\n\r");
		return FALSE;
	}

	obj = get_obj_index( pRec->components[index] = atoi(argument) );

	cprintf(ch,"Component slot #%d set to vnum %d.\n\r",
		index+1, pRec->components[index] );
	if ( obj == NULL)
		cprintf(ch,"Warning: no object has been assigned to this vnum yet.\n\r");
	else
		cprintf(ch,"Component #%d is %s.\n\r", index+1, obj->short_descr );

	return TRUE;
}

TEDIT( tedit_show )
{
	Recipe *pRec;
	ObjIndex *result = NULL;
	ObjIndex *fail = NULL;
	int i;

	EDIT_RECIPE(ch,pRec);

	if ( pRec->result_vnum > 0 )
		result = get_obj_index( pRec->result_vnum );
	if ( pRec->fail_vnum > 0 )
		fail = get_obj_index( pRec->fail_vnum );

	cprintf(ch,"Vnum:          [%d]\n\r", pRec->vnum );
	cprintf(ch,"Name:          [%s]\n\r", pRec->name );
	cprintf(ch,"Skill:         [%s]\n\r", pRec->trade_skill < 1 ? "none" : 
											skill_table[pRec->trade_skill].name );
	cprintf(ch,"Foundation:    [%s]\n\r", flag_string( foundation_flags, pRec->foundation_skills ) );
	cprintf(ch,"Result:        [%d:%s]\n\r", pRec->result_vnum, 
			result != NULL ? result->short_descr : "null object" );
	cprintf(ch,"Fail:          [%d:%s]\n\r", pRec->fail_vnum,
			fail != NULL ? fail->short_descr : "null object" );
	cprintf(ch,"Difficulty:    [%d]\n\r", pRec->difficulty );
	cprintf(ch,"Craft Time:    [%d second%s]\n\r", pRec->trivial, pRec->trivial != 1 ? "s" : "" );

	for( i=0 ; i < MAX_INGREDIENT ; i++ )
	{
		ObjIndex *obj = NULL;

		if ( pRec->components[i] > 0 )
			obj = get_obj_index( pRec->components[i] );

		cprintf(ch,"Component %2d   [%d:%s]\n\r",
			i+1, pRec->components[i], obj !=NULL ? obj->short_descr : "null object" );
	}

	return TRUE;
}

TEDIT( tedit_skill )
{
	Recipe *pRec;
	int sn;

	EDIT_RECIPE(ch,pRec);

	if ( argument[0] == '\0' )
	{
		cprintf(ch,"Usage:   skill <skill_name|none>\n\r");
		return FALSE;
	}

	if( !str_cmp(argument,"none") )
	{
		pRec->trade_skill = 0;
		cprintf(ch,"Tradeskill cleared.\n\r");
		return TRUE;
	}

	if ( (sn = skill_lookup( argument )) < 1 ||
		skill_table[sn].type != SKILL_TRADE )
	{
		cprintf(ch,"Invalid trade skill.\n\r");
		return FALSE;
	}

	pRec->trade_skill = sn;
	cprintf(ch,"Trade Skill set to '%s'.\n\r", skill_table[sn].name);
	return TRUE;
}

TEDIT( tedit_result )
{
	Recipe *pRec;
	ObjIndex *obj;
	int vnum;

	EDIT_RECIPE(ch,pRec);

	if ( (vnum = atoi(argument)) < 0 )
	{
		cprintf(ch,"Vnum must be positive.\n\r");
		return FALSE;
	}

	obj = get_obj_index( vnum );

	cprintf(ch,"Result vnum set to %d.\n\r",vnum);
	if ( obj == NULL )
		cprintf(ch,"Warning: no object has this vnum.\n\r");
	else
		cprintf(ch,"Result object is %s.\n\r", obj->short_descr);

	pRec->result_vnum = vnum;
	return TRUE;
}

TEDIT( tedit_fail )
{
    Recipe *pRec;
    ObjIndex *obj;
    int vnum;

    EDIT_RECIPE(ch,pRec);

    if ( (vnum = atoi(argument)) < 0 )
    {
        cprintf(ch,"Vnum must be positive.\n\r");
        return FALSE;
    }

    obj = get_obj_index( vnum );

    cprintf(ch,"Fail vnum set to %d.\n\r",vnum);
    if ( obj == NULL )
        cprintf(ch,"Warning: no object has this vnum.\n\r");
    else
        cprintf(ch,"Fail object is %s.\n\r", obj->short_descr);

	pRec->fail_vnum = vnum;
    return TRUE;
}


TEDIT( tedit_difficulty )
{
	Recipe *pRec;
	int diff;

	EDIT_RECIPE(ch,pRec);

	if ( (diff = atoi(argument)) < 0 || diff > 1000 )
	{
		cprintf(ch,"Difficulty range must be between 0 and 1000.\n\r");
		return FALSE;
	}

	pRec->difficulty = diff;
	cprintf(ch,"Difficulty set to %d.\n\r", diff );
	return TRUE;
}

TEDIT( tedit_craft_time )
{
	Recipe *pRec;
	int triv;

	EDIT_RECIPE(ch,pRec);

	if ( (triv = atoi(argument)) < 1 || triv >  600 )
	{
		cprintf(ch,"Time must be between 0 and 600.\n\r");
		return FALSE;
	}

	pRec->trivial = triv;
	cprintf(ch,"Craft time set to %d second%s.\n\r", triv, triv != 1 ? "s" : "" );
	return TRUE;
}


TEDIT( tedit_create )
{
    Recipe *pRec;
    Area *pArea;
    int  value;
    int  iHash;

    value = atoi( argument );
    if ( argument[0] == '\0' || value == 0 )
    {
		send_to_char( "Syntax:  tedit create [vnum]\n\r", ch );
		return FALSE;
    }

    pArea = get_vnum_area( value );

    if ( !pArea )
    {
		send_to_char( "TSEdit:  That vnum is not assigned an area.\n\r", ch );
		return FALSE;
    }

    if ( !IS_BUILDER( ch, pArea ) )
    {
		send_to_char( "TSEdit:  Vnum in an area you cannot build in.\n\r", ch );
		return FALSE;
    }

    if ( get_recipe_index( value ) )
    {
		send_to_char( "TSEdit:  Mobile vnum already exists.\n\r", ch );
		return FALSE;
    }

    pRec			= new_recipe_index();
    pRec->vnum			= value;
    pRec->area			= pArea;
        
    if ( value > top_vnum_recipe )
		top_vnum_recipe = value;        

    iHash			= value % MAX_KEY_HASH;
    pRec->next			= recipe_index_hash[iHash];
    recipe_index_hash[iHash]	= pRec;
    ch->desc->pEdit		= (void *)pRec;

    send_to_char( "Recipe Created.\n\r", ch );
    return TRUE;
}

TEDIT( tedit_name )
{
	Recipe *pRec;

	EDIT_RECIPE(ch, pRec);

    if ( argument[0] == '\0' )
    {
		send_to_char( "Syntax:  name [string]\n\r", ch );
		return FALSE;
    }

    free_string( pRec->name );
    pRec->name = str_dup( argument );

    send_to_char( "Name set.\n\r", ch);
    return TRUE;
}


TEDIT( tedit_foundation )          /* Moved out of medit() due to naming conflicts -- Hugin */
{
    Recipe *pRec;
    int value;   

    if ( argument[0] != '\0' )
    {
    	EDIT_RECIPE( ch, pRec );

    	if ( ( value = flag_value( foundation_flags, argument ) ) != NO_FLAG )
    	{
        	pRec->foundation_skills ^= value;
			cprintf(ch,"Foundation skills set to: %s\n\r",
				flag_string( foundation_flags, pRec->foundation_skills ) );
        	return TRUE;
    	}
    }
    
    cprintf( ch, "Syntax: foundation [skills]\n\r"
                 "   valid skills: woodworking metalworking leatherworking stoneworking\n\r" );
    return FALSE;
}
