#ifndef account_h
#define account_h

#define CHARS_PER_ACCOUNT        10

// Accounts
struct account_data
{
    bool            valid;
    Account *       next;
    char *          name;
    char *          password;
    long            flags;
    time_t          create_date;
    char *          characters[CHARS_PER_ACCOUNT][32];
};

#endif /* account_h */
