#ifndef memory_h
#define memory_h

extern void *rgFreeList[MAX_MEM_LIST];
extern const int rgSizeList[MAX_MEM_LIST];
extern int nAllocString;
extern int sAllocString;
extern int nAllocPerm;
extern int sAllocPerm;

#endif /* memory_h */
