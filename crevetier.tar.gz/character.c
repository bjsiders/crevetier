/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include "thoc.h"
#include "options.h"

/* friend stuff -- for NPC's mostly */
bool is_friend(Character *ch,Character *victim)
{
    if (is_same_group(ch,victim))
        return TRUE;
    
    if (!IS_NPC(ch))
        return FALSE;

    if (!IS_NPC(victim))
    {
        if (IS_SET(ch->off_flags,ASSIST_PLAYERS))
            return TRUE;
        else
            return FALSE;
    }

    if (IS_AFFECTED(ch,AFF_CHARM))
        return FALSE;

    if (IS_SET(ch->off_flags,ASSIST_ALL))
        return TRUE;

    if (ch->group && ch->group == victim->group)
        return TRUE;

    if (IS_SET(ch->off_flags,ASSIST_VNUM) &&  ch->pIndexData == victim->pIndexData)
        return TRUE;

    if (IS_SET(ch->off_flags,ASSIST_RACE) && ch->race == victim->race)
        return TRUE;
     
    if (IS_SET(ch->off_flags,ASSIST_ALIGN)
        &&  !IS_SET(ch->act,ACT_NOALIGN) && !IS_SET(victim->act,ACT_NOALIGN)
        &&  ((IS_GOOD(ch) && IS_GOOD(victim))
        ||     (IS_EVIL(ch) && IS_EVIL(victim))
        ||   (IS_NEUTRAL(ch) && IS_NEUTRAL(victim))))
    {
        return TRUE;
    }

    return FALSE;
}

/* for immunity, vulnerabiltiy, and resistant
   the 'globals' (magic and weapons) may be overriden */
int check_immune(Character *ch, int dam_type)
{
    int res;
    extern    int convertDamtypeToResistIndex( int damage_type );

    // Handle melee immunity
    if ( IS_SET(ch->imm_flags,IMM_WEAPON) &&
          ( dam_type == DAM_PIERCE || 
            dam_type == DAM_SLASH  ||
            dam_type == DAM_BASH ) )
        return TRUE;

    if( (res = convertDamtypeToResistIndex( dam_type )) < 0 )
        return FALSE;
    else
    if ( res >= MAX_PC_RESISTS && !IS_NPC(ch) )
        return FALSE;
    else
        return ch->resists[res].immune;
}

bool is_clan(Character *ch)
{
    return (ch->clan != NULL);
}

bool is_same_clan(Character *ch, Character *victim)
{
    return (ch->clan == victim->clan && !clan_is_independent(ch->clan) );
}

int get_raw_skill(Character *ch, int sn)
{
    int skill;
    int minone=FALSE;

    if (sn == -1) /* shorthand for level based skills */
    {
        skill = ch->level * 10 / 2;
    }
    else if (sn < -1 || sn > MAX_SKILL)
    {
        log_bug("Bad sn %d in get_skill.",sn);
        skill = 0;
    }
    else
    {
        if (ch->level < skill_table[sn].skill_level[ch->class])
            return 0;
        else
            skill = IS_NPC(ch) ? (ch->level) : (ch->pcdata->learned[sn] + ch->pcdata->skill_mod[sn]);

        if ( !IS_NPC(ch) && ch->pcdata->learned[sn] <= 0 )
            return 0;
        else
            minone = TRUE;
    }

    if ( IS_NPC(ch) && skill_table[sn].type == SKILL_WEAPON )
    {
        if ( ch->class == csn_barbarian ||
             ch->class == csn_fighter    ||
             ch->class == csn_ranger    ||
             ch->class == csn_paladin    ||
             ch->class == csn_monk    )
                skill = ch->level * 110 / 100; 
        else
        if ( ch->class == csn_thief     ||
             ch->class == csn_bard        ||
             ch->class == csn_crusader )
                skill = ch->level; 
        else
        if ( ch->class == csn_assassin     ||
             ch->class == csn_cleric    ||
             ch->class == csn_shaman )
                skill = ch->level * 4 / 5;
        else
                skill = ch->level * 2 / 3; 
    }
    
    if (ch->daze > 0)
    {
        if (skill_table[sn].type != SKILL_WEAPON)
            skill /= 2;
        else
            skill = 2 * skill / 3;
    }

    if ( !IS_NPC(ch) )
    {
        if ( ch->pcdata->condition[COND_DRUNK]  > 10 )
            skill = 9 * skill / 10;

        if ( skill_table[sn].type == SKILL_WEAPON && ch->pcdata->subrace == gsn_tayana &&
                (     sn == WEAPON_KATANA ||
                      sn == WEAPON_SAI ||
                    sn == WEAPON_WAKIZASHI ||
                    sn == WEAPON_NAGINATA ||
                    sn == WEAPON_DIAKYU ||
                    sn == WEAPON_BO_STICK ||
                    sn == WEAPON_TETSUBO ) )
            skill = 11 * skill / 10;

        /*else - removed kutath stuff
        if ( ch->pcdata->subrace == gsn_kutath )
        {
            if ( IS_NIGHTTIME )
                skill = 105 * skill / 100;
            else
            if ( IS_DAYTIME )
                skill = 95 * skill / 100;
        }*/

    }

    if ( skill_table[sn].type == SKILL_TRADE || skill_table[sn].type == SKILL_FOUNDATION)
        return URANGE(0,skill,255);
    else
    {
        if (minone)
            return URANGE(1,skill,ch->level+(ch->level/10)+1);
        else
            return URANGE(0,skill,ch->level+(ch->level/10)+1);
    }
}

/* for returning skill information */
int get_skill(Character *ch, int sn)
{
    int skill;
    int minone=FALSE;
    bool fNPC;

    if ( IS_NPC(ch) || is_affected(ch,gsn_shapeshifting,AFF_SKILL) )
        fNPC = TRUE;
    else
        fNPC = FALSE;

    if (sn == -1) /* shorthand for level based skills */
    {
        skill = ch->level * 10 / 2;
    }
    else if (sn < -1 || sn > MAX_SKILL)
    {
        log_bug("Bad sn %d in get_skill.",sn);
        skill = 0;
    }
    else
    {
        // If you don't have this skill at all...
        if (skill_table[sn].skill_level[ch->class] == 0)
        {
            // Check for an NPC with an override
            if ( fNPC )
            {
                // Add any flags here that can be overriden
                if ( (sn == gsn_kick && IS_SET(ch->off_flags,OFF_KICK)) ||
                     (sn == gsn_bash && IS_SET(ch->off_flags,OFF_BASH)) ||
                     (sn == gsn_berserk && IS_SET(ch->off_flags,OFF_BERSERK)) ||
                     (sn == gsn_trip && IS_SET(ch->off_flags,OFF_TRIP)))
                {
                    skill = ch->level;
                }
                else // otherwise no override so go ahead and return no skill
                    return 0;
            }
            else // players don't get overrides
                return 0;
        }
        else
            skill = fNPC ? (ch->level) : (ch->pcdata->learned[sn] + ch->pcdata->skill_mod[sn]);

        if ( !fNPC && ch->pcdata->learned[sn] <= 0 )
            return 0;
        else
            minone = TRUE;
    }

    if ( fNPC && skill_table[sn].type == SKILL_WEAPON )
    {
        if ( ch->class == csn_barbarian ||
             ch->class == csn_fighter    ||
             ch->class == csn_ranger    ||
             ch->class == csn_paladin    ||
             ch->class == csn_monk    )
                skill = ch->level * 110 / 100; 
        else
        if ( ch->class == csn_thief     ||
             ch->class == csn_bard        ||
             ch->class == csn_crusader )
                skill = ch->level; 
        else
        if ( ch->class == csn_assassin     ||
             ch->class == csn_cleric    ||
             ch->class == csn_shaman )
                skill = ch->level * 4 / 5;
        else
                skill = ch->level * 2 / 3; 
    }
   
    // Only for NPCs 
    if ( ch->daze > 0 && IS_NPC(ch) )
    {
        if (skill_table[sn].type != SKILL_WEAPON)
            skill /= 2;
        else
            skill = 2 * skill / 3;
    }

    if ( !fNPC )
    {
        if ( ch->pcdata->condition[COND_DRUNK]  > 10 )
            skill = 9 * skill / 10;

        if ( skill_table[sn].type == SKILL_WEAPON && ch->pcdata->subrace == gsn_tayana &&
                (     sn == WEAPON_KATANA ||
                      sn == WEAPON_SAI ||
                    sn == WEAPON_WAKIZASHI ||
                    sn == WEAPON_NAGINATA ||
                    sn == WEAPON_DIAKYU ||
                    sn == WEAPON_BO_STICK ||
                    sn == WEAPON_TETSUBO ) )
            skill = 11 * skill / 10;

        /*else - removed kutath stuff
        if ( ch->pcdata->subrace == gsn_kutath )
        {
            if ( IS_NIGHTTIME )
                skill = 105 * skill / 100;
            else
            if ( IS_DAYTIME )
                skill = 95 * skill / 100;
        }*/

    }

    if ( ch->base_hit > 0 && ch->max_base_hit > 0 )
        skill = ch->base_hit * skill / ch->max_base_hit;

    if ( skill_table[sn].type == SKILL_TRADE || skill_table[sn].type == SKILL_FOUNDATION )
        return UMAX(0,skill);
    else
    {
        if (minone)
            return URANGE(1,skill,ch->level+(ch->level/10)+1);
        else
            return URANGE(0,skill,ch->level+(ch->level/10)+1);
    }
}

int get_weapon_sn(Character *ch, int fType)
{
    Object *wield;
    int i;
    long wear_loc;

    switch( fType )
    {
    case GET_WEAPON_SN:    wear_loc = WEAR_WIELD; break;
    case GET_OFFHAND_SN: wear_loc = WEAR_OFFHAND; break;
    case GET_RANGED_SN: wear_loc = WEAR_RANGED; break;
    default:
        wear_loc = WEAR_WIELD; break;
    }
    
    wield = get_eq_char( ch, wear_loc );
    if (wield == NULL || wield->item_type != ITEM_WEAPON)
        return gsn_hand_to_hand;
    else
        for( i = 0 ; weapon_table[i].name != NULL ; i ++ )
            if ( weapon_table[i].type == wield->value[0] )
                return *(weapon_table[i].gsn);

    return -1;
/**
    else switch (wield->value[0])
    {
        default :               sn = -1;                break;
        case(WEAPON_SWORD):     sn = gsn_sword;         break;
        case(WEAPON_DAGGER):    sn = gsn_dagger;        break;
        case(WEAPON_SPEAR):     sn = gsn_spear;         break;KE
        case(WEAPON_MACE):      sn = gsn_mace;          break;
        case(WEAPON_AXE):       sn = gsn_axe;           break;
        case(WEAPON_FLAIL):     sn = gsn_flail;         break;
        case(WEAPON_WHIP):      sn = gsn_whip;          break;
        case(WEAPON_POLEARM):   sn = gsn_polearm;       break;
    case(WEAPON_STAFF):    sn = gsn_staff;        break;
   }
    return sn;
  **/
}

int get_weapon_skill(Character *ch, int sn )
{
     int skill;

    if ( sn == -1 )
        skill = ch->level / 2;
    else
    if ( sn == gsn_hand_to_hand )
    {
        if (IS_NPC(ch))
            skill = ch->level;
        else
        if ( is_affected(ch,gsn_shapeshifting,AFF_SKILL) ) 
            // HACK!
            skill = ch->pcdata->learned[gsn_shapeshifting];
        else
            skill = get_skill( ch, sn );
    }
    else
        skill = get_skill( ch, sn );
    
    return skill;
} 


/* used to de-screw characters */
void reset_char(Character *ch)
{
     int loc,mod,stat;
     Object *obj;
     Affect *af;
     int i;

     if (IS_NPC(ch))
    return;

    if (ch->pcdata->perm_base_hit == 0
    ||  ch->pcdata->perm_stat_hit == 0
    ||  ch->pcdata->perm_stamina == 0
    ||    ch->pcdata->perm_mana == 0
    ||  ch->pcdata->perm_move == 0
    ||    ch->pcdata->last_level == 0)
    {
    /* do a FULL reset */
    for (loc = 0; loc < MAX_WEAR; loc++)
    {
        obj = get_eq_char(ch,loc);
        if (obj == NULL)
        continue;
        if (!obj->enchanted)
        for ( af = obj->pIndexData->affected; af != NULL; af = af->next )
        {
        mod = af->modifier;
        switch(af->location)
        {
            case APPLY_SEX:    ch->sex        -= mod;
                    if (ch->sex < 0 || ch->sex >2)
                        ch->sex = IS_NPC(ch) ?
                        0 :
                        ch->pcdata->true_sex;
                                    break;
            case APPLY_MANA:    ch->max_mana    -= mod;        break;
            case APPLY_HIT:    ch->max_stat_hit    -= mod;        break;
            case APPLY_MOVE:    ch->max_move    -= mod;        break;
        }
        }

            for ( af = obj->affected; af != NULL; af = af->next )
            {
                mod = af->modifier;
                switch(af->location)
                {
                    case APPLY_SEX:     ch->sex         -= mod;         break;
                    case APPLY_MANA:    ch->max_mana    -= mod;         break;
                    case APPLY_HIT:     ch->max_stat_hit     -= mod;         break;
                    case APPLY_MOVE:    ch->max_move    -= mod;         break;
                }
            }
    }
    /* now reset the permanent stats */
    ch->pcdata->perm_mana     = ch->max_mana;
    ch->pcdata->perm_move    = ch->max_move;
    ch->pcdata->perm_base_hit = ch->max_base_hit;
    ch->pcdata->perm_stat_hit = ch->max_stat_hit;
    ch->pcdata->perm_stamina = ch->max_stamina;
    ch->pcdata->last_level    = ch->played/3600;
    if (ch->pcdata->true_sex < 0 || ch->pcdata->true_sex > 2)
    {
        if (ch->sex > 0 && ch->sex < 3)
                ch->pcdata->true_sex    = ch->sex;
        else
            ch->pcdata->true_sex     = 0;
    }
    }

    for( i = 0; i < MAX_RESIST; i++ )
    {
    ch->resists[i].value = race_table[ch->race].resists[i];
    ch->resists[i].mod = 0;
    }

    /* now restore the character to his/her true condition */
    for (stat = 0; stat < MAX_STATS; stat++)
    ch->mod_stat[stat] = 0;

    if (ch->pcdata->true_sex < 0 || ch->pcdata->true_sex > 2)
    ch->pcdata->true_sex = 0; 
    ch->sex        = ch->pcdata->true_sex;
    ch->max_mana    = ch->pcdata->perm_mana;
    ch->max_move    = ch->pcdata->perm_move;
    ch->max_base_hit    = ch->pcdata->perm_base_hit;
    ch->max_stat_hit    = ch->pcdata->perm_stat_hit;
    ch->max_stamina        = ch->pcdata->perm_stamina;

    for (i = 0; i < 4; i++)
        ch->armor[i]    = 0;

    ch->hitroll        = 0;
    ch->damroll        = 0;
    ch->saving_throw    = 0;

    /* now start adding back the effects */
    for (loc = 0; loc < MAX_WEAR; loc++)
    {
        obj = get_eq_char(ch,loc);
        if (obj == NULL)
            continue;
    for (i = 0; i < 4; i++)
        ch->armor[i] += apply_ac( obj, loc, i );

        if (!obj->enchanted)
    for ( af = obj->pIndexData->affected; af != NULL; af = af->next )
        {
            mod = af->modifier;
            switch(af->location)
            {
        case APPLY_SKILL:
            if (IS_NPC(ch)) break;
            ch->pcdata->skill_mod[af->misc] += mod; break;
        case APPLY_ABSORB:    ch->absorb                += mod; break;
        case APPLY_STAMINA:    ch->max_stamina            += mod; break;
        case APPLY_BASE_HITS:    ch->max_base_hit        += mod; break;
        case APPLY_STR:        ch->mod_stat[STAT_STR]    += mod;    break;
        case APPLY_DEX:        ch->mod_stat[STAT_DEX]    += mod; break;
        case APPLY_INT:        ch->mod_stat[STAT_INT]    += mod; break;
        case APPLY_WIS:        ch->mod_stat[STAT_WIS]    += mod; break;
        case APPLY_CON:        ch->mod_stat[STAT_CON]    += mod; break;
        case APPLY_CHA:        ch->mod_stat[STAT_CHA]  += mod; break;

        case APPLY_SEX:        ch->sex            += mod; break;
        case APPLY_MANA:    ch->max_mana        += mod; break;
        case APPLY_HIT:        ch->max_stat_hit    += mod; break;
        case APPLY_MOVE:    ch->max_move        += mod; break;

        case APPLY_AC:        
            for (i = 0; i < 4; i ++)
            ch->armor[i] += mod; 
            break;
        case APPLY_HITROLL:    ch->hitroll        += mod; break;
        case APPLY_DAMROLL:    ch->damroll        += mod; break;
    
        case APPLY_SAVE_REFLEX:        ch->saves[SAVE_REFLEX] += mod; break;
                case APPLY_SAVE_FORTITUDE:      ch->saves[SAVE_FORTITUDE] += mod; break;
                case APPLY_SAVE_WILLPOWER:      ch->saves[SAVE_WILLPOWER] += mod; break;
    case APPLY_RES_FIRE:        ch->resists[RESIST_FIRE].mod += mod; break;
    case APPLY_RES_ICE:            ch->resists[RESIST_ICE].mod += mod; break;
    case APPLY_RES_EARTH:    ch->resists[RESIST_EARTH].mod += mod; break;
    case APPLY_RES_AIR:        ch->resists[RESIST_AIR].mod += mod; break;
    case APPLY_RES_LIGHT:    ch->resists[RESIST_LIGHT].mod += mod; break;
    case APPLY_RES_DARK:    ch->resists[RESIST_DARK].mod += mod; break;
    case APPLY_RES_WATER:    ch->resists[RESIST_WATER].mod += mod; break;
    case APPLY_RES_BODY:    ch->resists[RESIST_BODY].mod += mod; break;
    case APPLY_RES_POISON:    ch->resists[RESIST_POISON].mod += mod; break;
    case APPLY_RES_DISEASE:    ch->resists[RESIST_DISEASE].mod += mod; break;
    case APPLY_RES_MENTAL:    ch->resists[RESIST_MENTAL].mod += mod; break;
    case APPLY_RES_ACID:    ch->resists[RESIST_ACID].mod += mod ; break;
    case APPLY_RES_ELECTRICITY: ch->resists[RESIST_ELECTRICITY].mod += mod; break;
    case APPLY_RES_SPIRIT:    ch->resists[RESIST_SPIRIT].mod += mod; break;
    case APPLY_RES_SOUND:    ch->resists[RESIST_SOUND].mod += mod; break;
        }
    }
 
        for ( af = obj->affected; af != NULL; af = af->next )
        {
            mod = af->modifier;
            switch(af->location)
            {
                case APPLY_SKILL:
                    if (IS_NPC(ch)) break;
                    ch->pcdata->skill_mod[af->misc] += mod; break;
                case APPLY_ABSORB:        ch->absorb                += mod; break;
                case APPLY_STAMINA:        ch->max_stamina            += mod; break;
                case APPLY_BASE_HITS:    ch->max_base_hit        += mod; break;
                case APPLY_STR:         ch->mod_stat[STAT_STR]  += mod; break;
                case APPLY_DEX:         ch->mod_stat[STAT_DEX]  += mod; break;
                case APPLY_INT:         ch->mod_stat[STAT_INT]  += mod; break;
                case APPLY_WIS:         ch->mod_stat[STAT_WIS]  += mod; break;
                case APPLY_CON:         ch->mod_stat[STAT_CON]  += mod; break;
        case APPLY_CHA:        ch->mod_stat[STAT_CHA]  += mod; break;
 
                case APPLY_SEX:         ch->sex                 += mod; break;
                case APPLY_MANA:        ch->max_mana            += mod; break;
                case APPLY_HIT:         ch->max_stat_hit        += mod; break;
                case APPLY_MOVE:        ch->max_move            += mod; break;
 
                case APPLY_AC:
                    for (i = 0; i < 4; i ++)
                        ch->armor[i] += mod;
                    break;
        case APPLY_HITROLL:     ch->hitroll             += mod; break;
                case APPLY_DAMROLL:     ch->damroll             += mod; break;
 
                case APPLY_SAVE_REFLEX:         ch->saves[SAVE_REFLEX] += mod; break;
                case APPLY_SAVE_FORTITUDE:      ch->saves[SAVE_FORTITUDE] += mod; break;
                case APPLY_SAVE_WILLPOWER:      ch->saves[SAVE_WILLPOWER] += mod; break;
    case APPLY_RES_FIRE:        ch->resists[RESIST_FIRE].mod += mod; break;
    case APPLY_RES_ICE:            ch->resists[RESIST_ICE].mod += mod; break;
    case APPLY_RES_EARTH:    ch->resists[RESIST_EARTH].mod += mod; break;
    case APPLY_RES_AIR:        ch->resists[RESIST_AIR].mod += mod; break;
    case APPLY_RES_LIGHT:    ch->resists[RESIST_LIGHT].mod += mod; break;
    case APPLY_RES_DARK:    ch->resists[RESIST_DARK].mod += mod; break;
    case APPLY_RES_WATER:    ch->resists[RESIST_WATER].mod += mod; break;
    case APPLY_RES_BODY:    ch->resists[RESIST_BODY].mod += mod; break;
    case APPLY_RES_POISON:    ch->resists[RESIST_POISON].mod += mod; break;
    case APPLY_RES_DISEASE:    ch->resists[RESIST_DISEASE].mod += mod; break;
    case APPLY_RES_MENTAL:    ch->resists[RESIST_MENTAL].mod += mod; break;
    case APPLY_RES_ACID:    ch->resists[RESIST_ACID].mod += mod ; break;
    case APPLY_RES_ELECTRICITY: ch->resists[RESIST_ELECTRICITY].mod += mod; break;
    case APPLY_RES_SPIRIT:    ch->resists[RESIST_SPIRIT].mod += mod ; break;
    case APPLY_RES_SOUND:    ch->resists[RESIST_SOUND].mod += mod; break;
            }
    }
    }
  
    /* now add back spell effects */
    for (af = ch->affected; af != NULL; af = af->next)
    {
        mod = af->modifier;
        switch(af->location)
        {
                case APPLY_SKILL:
                    if (IS_NPC(ch)) break;
                    ch->pcdata->skill_mod[af->misc] += mod; break;
                case APPLY_ABSORB:        ch->absorb                += mod; break;
                case APPLY_STAMINA:        ch->max_stamina            += mod; break;
                case APPLY_BASE_HITS:    ch->max_base_hit        += mod; break;
                case APPLY_STR:         ch->mod_stat[STAT_STR]  += mod; break;
                case APPLY_DEX:         ch->mod_stat[STAT_DEX]  += mod; break;
                case APPLY_INT:         ch->mod_stat[STAT_INT]  += mod; break;
                case APPLY_WIS:         ch->mod_stat[STAT_WIS]  += mod; break;
                case APPLY_CON:         ch->mod_stat[STAT_CON]  += mod; break;
        case APPLY_CHA:        ch->mod_stat[STAT_CHA]  += mod; break;
 
                case APPLY_SEX:         ch->sex                 += mod; break;
                case APPLY_MANA:        ch->max_mana            += mod; break;
                case APPLY_HIT:         ch->max_stat_hit        += mod; break;
                case APPLY_MOVE:        ch->max_move            += mod; break;
 
                case APPLY_AC:
                    for (i = 0; i < 4; i ++)
                        ch->armor[i] += mod;
                    break;
                case APPLY_HITROLL:     ch->hitroll             += mod; break;
                case APPLY_DAMROLL:     ch->damroll             += mod; break;
 
                case APPLY_SAVE_REFLEX:         ch->saves[SAVE_REFLEX] += mod; break;
                case APPLY_SAVE_FORTITUDE:      ch->saves[SAVE_FORTITUDE] += mod; break;
                case APPLY_SAVE_WILLPOWER:      ch->saves[SAVE_WILLPOWER] += mod; break;
    case APPLY_RES_FIRE:        ch->resists[RESIST_FIRE].mod += mod; break;
    case APPLY_RES_ICE:            ch->resists[RESIST_ICE].mod += mod; break;
    case APPLY_RES_EARTH:    ch->resists[RESIST_EARTH].mod += mod; break;
    case APPLY_RES_AIR:        ch->resists[RESIST_AIR].mod += mod; break;
    case APPLY_RES_LIGHT:    ch->resists[RESIST_LIGHT].mod += mod; break;
    case APPLY_RES_WATER:    ch->resists[RESIST_WATER].mod += mod; break;
    case APPLY_RES_BODY:    ch->resists[RESIST_BODY].mod += mod; break;
    case APPLY_RES_DARK:    ch->resists[RESIST_DARK].mod += mod; break;
    case APPLY_RES_POISON:    ch->resists[RESIST_POISON].mod += mod; break;
    case APPLY_RES_DISEASE:    ch->resists[RESIST_DISEASE].mod += mod; break;
    case APPLY_RES_MENTAL:    ch->resists[RESIST_MENTAL].mod += mod; break;
    case APPLY_RES_ACID:    ch->resists[RESIST_ACID].mod += mod ; break;
    case APPLY_RES_ELECTRICITY: ch->resists[RESIST_ELECTRICITY].mod += mod; break;
    case APPLY_RES_SPIRIT:    ch->resists[RESIST_SPIRIT].mod += mod; break;
    case APPLY_RES_SOUND:    ch->resists[RESIST_SOUND].mod += mod; break;
        } 
    }

    /* make sure sex is RIGHT!!!! */
    if (ch->sex < 0 || ch->sex > 2)
    ch->sex = ch->pcdata->true_sex;
}


/*
 * Retrieve a character's trusted level for permission checking.
 */
int get_trust( Character *ch )
{
    if ( ch->desc != NULL && ch->desc->original != NULL )
        ch = ch->desc->original;

    if (ch->trust)
        return ch->trust;

    if ( IS_NPC(ch) && ch->level >= LEVEL_HERO )
        return LEVEL_HERO - 1;
    else
        return ch->level;
}


/*
 * Retrieve a character's age.
 */
int get_age( Character *ch )
{
    return 17 + ( ch->played + (int) (current_time - ch->logon) ) / 72000;
}

/* command for retrieving stats */
int get_curr_stat( Character *ch, int stat )
{
    int max = 255;

    if ( !IS_NPC(ch) && !IS_IMMORTAL(ch) && ch->race < MAX_PC_RACE )
    {
        max = pc_race_table[ch->race].max_stats[stat] + 25;
     
        if ( class_table[ch->class].attr_prime == stat )
            max += 25;

        max = URANGE(30,max,255);
    }
 
    return URANGE(30,ch->perm_stat[stat] + ch->mod_stat[stat], max );
}

/* command for returning max training score */
int get_max_train( Character *ch, int stat )
{
    int max;

    // For characters in creation, if no class is set,
    // we ignore part of this

    if (IS_NPC(ch) || ch->level > LEVEL_IMMORTAL)
        return 255;

    max = pc_race_table[ch->race].max_stats[stat];
    if ( ch->gen_data != NULL && ch->gen_data->class < 0 )
        return UMIN(max,255);

    if (class_table[ch->class].attr_prime == stat)
       max += 25;

    if (class_table[ch->class].attr_second == stat)
        max += 10;

    return UMIN(max,255);
}
   
    
/*
 * Retrieve a character's carry capacity.
 */
int can_carry_n( Character *ch )
{
    if ( !IS_NPC(ch) && ch->level >= LEVEL_IMMORTAL )
    return 1000;

    if ( IS_NPC(ch) && IS_SET(ch->act, ACT_PET) )
    return 0;

    return MAX_WEAR +  2 * get_curr_stat(ch,STAT_DEX) + ch->level;
}



/*
 * Retrieve a character's carry capacity.
 */
int can_carry_w( Character *ch )
{
    int max;

    if ( !IS_NPC(ch) && ch->level >= LEVEL_IMMORTAL )
        return 100000;

    if ( IS_NPC(ch) && IS_SET(ch->act, ACT_PET) )
        return 0;

    max = get_curr_stat(ch,STAT_STR);
    max += ch->level;

    if ( HAS_PROF(ch,gpn_pack_mule) )
        max += ch->level;

    return max * 10;
}

/*
 * Move a char out of a room.
 */
void char_from_room( Character *ch )
{
    Object *obj;

    if ( ch->in_room == NULL )
    {
    log_bug( "Char_from_room: NULL.", 0 );
    return;
    }

    if ( !IS_NPC(ch) )
    --ch->in_room->area->nplayer;

    if ( ( obj = get_eq_char( ch, WEAR_LIGHT ) ) != NULL
    &&   obj->item_type == ITEM_LIGHT
    &&   obj->value[2] != 0
    &&   ch->in_room->light > 0 )
    --ch->in_room->light;

    if ( ch == ch->in_room->people )
    {
    ch->in_room->people = ch->next_in_room;
    }
    else
    {
    Character *prev;

    for ( prev = ch->in_room->people; prev; prev = prev->next_in_room )
    {
        if ( prev->next_in_room == ch )
        {
        prev->next_in_room = ch->next_in_room;
        break;
        }
    }

    /*if ( prev == NULL )
        log_bug( "Char_from_room: ch not found.", 0 );*/
    }

    ch->in_room      = NULL;
    ch->next_in_room = NULL;
    ch->on              = NULL;  /* sanity check! */
    if( ch->crafting != NULL && ch->crafting->carried_by == NULL )
        ch->crafting    = NULL; /* more sanity */
    return;
}



/*
 * Move a char into a room.
 */
void char_to_room( Character *ch, Room *pRoomIndex )
{
    Object *obj;

    if ( pRoomIndex == NULL )
    {
    Room *room;

    log_bug( "Char_to_room: NULL.", 0 );
    
    if ((room = get_room_index(ROOM_VNUM_TEMPLE)) != NULL)
        char_to_room(ch,room);
    
    return;
    }

    ch->in_room        = pRoomIndex;
    ch->next_in_room    = pRoomIndex->people;
    pRoomIndex->people    = ch;

    /* Added check so when we reward someone and trans them dont strip their camo */
    if ( !IS_OUTSIDE(ch) && is_affected(ch,vnum_camouflage,AFF_SPELL) 
        && ch->desc && ch->desc->connected == CON_GET_REWARD)
    {
        affect_strip(ch,vnum_camouflage);
        cprintf(ch,"&R\n\rYou are no longer camouflaged.&x\n\r");
        act("$n materializes!",ch,NULL,NULL,TO_ROOM);
    }

    if ( !IS_NPC(ch) )
    {
    if (ch->in_room->area->empty)
    {
        ch->in_room->area->empty = FALSE;
        ch->in_room->area->age = 0;
    }
    ++ch->in_room->area->nplayer;
    }

    if ( ( obj = get_eq_char( ch, WEAR_LIGHT ) ) != NULL
    &&   obj->item_type == ITEM_LIGHT
    &&   obj->value[2] != 0 )
    ++ch->in_room->light;
    
    return;
}

/*
 * Find a piece of eq on a character.
 */
Object *get_eq_char( Character *ch, int iWear )
{
    Object *obj;

    if (ch == NULL)
    return NULL;

    for ( obj = ch->carrying; obj != NULL; obj = obj->next_content )
    {
    if ( obj->wear_loc == iWear )
        return obj;
    }

    return NULL;
}

/*
 * Equip a char with an obj.
 */
void equip_char( Character *ch, Object *obj, int iWear )
{
    Affect *paf;
    int i;

    if ( iWear < 0 )
    {
        log_bug("Equip_char: trying to equip an inventory item (%s on %s) %d",
            obj->short_descr, IS_NPC(ch) ? ch->short_descr : ch->name,
            IS_NPC(ch) ? ch->pIndexData->vnum : 0 );
        return;
    }

    if ( get_eq_char( ch, iWear ) != NULL )
    {
        if ( IS_NPC(ch) )
            log_bug( "Equip_char: %d %s already equipped (%d).", ch->pIndexData->vnum, ch->short_descr, iWear );
        else
            log_bug( "Equip_char: %s already equipped (%d).", ch->name, iWear );
        return;
    }

    if ( ( IS_OBJ_STAT(obj, ITEM_ANTI_EVIL)    && IS_EVIL(ch)    )
    ||   ( IS_OBJ_STAT(obj, ITEM_ANTI_GOOD)    && IS_GOOD(ch)    )
    ||   ( IS_OBJ_STAT(obj, ITEM_ANTI_NEUTRAL) && IS_NEUTRAL(ch) ) )
    {
    /*
     * Thanks to Morgenes for the bug fix here!
     */
    act( "You are zapped by $p and drop it.", ch, obj, NULL, TO_CHAR );
    act( "$n is zapped by $p and drops it.",  ch, obj, NULL, TO_ROOM );
    obj_from_char( obj );
    obj_to_room( obj, ch->in_room );
    return;
    }

    for (i = 0; i < 4; i++)
        ch->armor[i]          += apply_ac( obj, iWear,i );
    obj->wear_loc     = iWear;

    if (!obj->enchanted)
        for ( paf = obj->pIndexData->affected; paf != NULL; paf = paf->next )
            if ( paf->location != APPLY_SPELL_AFFECT )
                affect_modify( ch, paf, TRUE );

    for ( paf = obj->affected; paf != NULL; paf = paf->next )
        if ( paf->location == APPLY_SPELL_AFFECT )
            affect_to_char ( ch, paf );
    else
        affect_modify( ch, paf, TRUE );

    if ( obj->item_type == ITEM_LIGHT
    &&   obj->value[2] != 0
    &&   ch->in_room != NULL )
        ++ch->in_room->light;

    /*ch->absorb += obj->absorb;*/
    return;
}

/*
 * Unequip a char with an obj.
 */
void unequip_char( Character *ch, Object *obj )
{
    Affect *paf = NULL;
    Affect *lpaf = NULL;
    Affect *lpaf_next = NULL;
    int i;

    if ( obj->wear_loc == WEAR_NONE )
    {
    log_bug( "Unequip_char: already unequipped.", 0 );
    return;
    }

    if ( obj->wear_loc == WEAR_WIELD )
        clear_style(ch);

    for (i = 0; i < 4; i++)
        ch->armor[i]    -= apply_ac( obj, obj->wear_loc,i );
    obj->wear_loc     = -1;

    if (!obj->enchanted)
    {
    for ( paf = obj->pIndexData->affected; paf != NULL; paf = paf->next )
    {
        if ( paf->location == APPLY_SPELL_AFFECT )
        {
            for ( lpaf = ch->affected; lpaf != NULL; lpaf = lpaf_next )
            {
            lpaf_next = lpaf->next;
            if ((lpaf->type == paf->type) &&
                (lpaf->level == paf->level) &&
                (lpaf->location == APPLY_SPELL_AFFECT))
            {
                affect_remove( ch, lpaf );
            lpaf_next = NULL;
            }
            }
        }
        else
        {
            affect_modify( ch, paf, FALSE );
        affect_check(ch,paf->where,paf->bitvector);
        }
        }
    }

    for ( paf = obj->affected; paf != NULL; paf = paf->next )
    if ( paf->location == APPLY_SPELL_AFFECT )
    {
        for ( lpaf = ch->affected; lpaf != NULL; lpaf = lpaf_next )
        {
            lpaf_next = lpaf->next;
            if ((lpaf->type == paf->type) &&
                (lpaf->level == paf->level) &&
                (lpaf->location == APPLY_SPELL_AFFECT))
        {
            log_bug( "location = %d", lpaf->location );
            log_bug( "type = %d", lpaf->type );
            affect_remove( ch, lpaf );
            lpaf_next = NULL;
        }
        }
    }
    else
    {
        affect_modify( ch, paf, FALSE );
        affect_check(ch,paf->where,paf->bitvector);    
    }

    if ( obj->item_type == ITEM_LIGHT
    &&   obj->value[2] != 0
    &&   ch->in_room != NULL
    &&   ch->in_room->light > 0 )
    --ch->in_room->light;

    /*ch->absorb -= obj->absorb;*/
    reset_racial_data( ch );
    return;
}

/*
 * Extract a char from the world.
 */
void extract_char( Character *ch, bool fPull )
{
    Character *wch;
    Object *obj;
    Object *obj_next;

    if ( ch->in_room == NULL && ch->shapeshifted == NULL )
    {
        log_bug( "Extract_char: NULL room for %s", ch->name );
        return;
    }
  
    /* If we extract a character who is an NPC, we want to reset his
     * spawn.
     */ 
    if ( IS_NPC(ch) )
    {
        if ( ch->spawn == NULL )
        {
            if ( !IS_SET(ch->act,ACT_PET) )
                log_bug("NPC %d %s has no spawn pointer", ch->pIndexData->vnum, ch->short_descr );
        }
        else
            SET_BIT(ch->spawn->flags,SPAWN_READY);
    }

    nuke_pets(ch);
    ch->pet = NULL; /* just in case */

    if ( fPull )
        die_follower( ch );
    
    stop_fighting( ch, TRUE );

    for ( obj = ch->carrying; obj != NULL; obj = obj_next )
    {
        obj_next = obj->next_content;
        extract_obj( obj );
    }
    
    if (ch->in_room != NULL)
        char_from_room( ch );

    /* Cancel all guards/proteects */
    for( wch = char_list ; wch ; wch = wch->next )
    {
        if ( wch->guarding == ch )
            wch->guarding = NULL;
        if ( wch->intercepting == ch )
            wch->intercepting = NULL;
    }

    /* Death room is set in the clan table now */
    if ( !fPull )
    {
        int room = ROOM_VNUM_ALTAR;

        if ( !IS_NPC(ch) )
            room = ch->pcdata->recall_vnum;

/*
        if ( ch->clan )
            room = ch->clan->hall;
    
        if ( room == 3054 )
            room = ROOM_VNUM_ALTAR;
*/
    
        char_to_room(ch,get_room_index(room));
        return;
    }

    if ( IS_NPC(ch) )
        --ch->pIndexData->count;

    if ( ch->desc != NULL && ch->desc->original != NULL && !is_affected(ch,gsn_shapeshifting,AFF_SKILL) )
    {
        do_function(ch, &do_return, "" );
        ch->desc = NULL;
    }

    for ( wch = char_list; wch != NULL; wch = wch->next )
    {
        if ( wch->reply == ch )
            wch->reply = NULL;
    }

    if ( ch == char_list )
    {
       char_list = ch->next;
    }
    else
    {
        Character *prev;

        for ( prev = char_list; prev != NULL; prev = prev->next )
        {
            if ( prev->next == ch )
            {
                prev->next = ch->next;
                break;
            }
        }
    
        if ( prev == NULL )
        {
            log_bug( "Extract_char: char [%s] not found", ch->name );
            return;
        }
    }

    if ( ch->desc != NULL )
        ch->desc->character = NULL;
    free_char( ch );
    return;
}

Building *get_building_room( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Building *bld;
    int number;
    int count;

    number = number_argument( argument, arg );
    count  = 0;
    for ( bld = ch->in_room->buildings; bld != NULL; bld = bld->next )
    {
        if ( !is_name( arg, flag_string( building_flags, bld->type )) )
            continue;
        if ( ++count == number )
            return bld;
    }

    return NULL;
}

/*
 * Find a char in the room.
 */
Character *get_char_room( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Character *rch;
    int number;
    int count;

    number = number_argument( argument, arg );
    count  = 0;
    if ( !str_cmp( arg, "self" ) )
    return ch;
    for ( rch = ch->in_room->people; rch != NULL; rch = rch->next_in_room )
    {
    if ( !can_see( ch, rch ) || !is_name( arg, rch->name ) )
        continue;
    if ( ++count == number )
        return rch;
    }

    return NULL;
}




/*
 * Find a char in the world.
 */
Character *find_character( Character *ch, char *argument, bool fOOC )
{
    char arg[MAX_INPUT_LENGTH];
    Character *wch;
    int number;
    int count;

    if ( ( wch = get_char_room( ch, argument ) ) != NULL )
    return wch;

    number = number_argument( argument, arg );
    count  = 0;
    for ( wch = char_list; wch != NULL ; wch = wch->next )
    {//if fOOC is true, only being a wizi or incog imm will hide you
    //if fOOC is false, being unable to be seen by the player will hide you
        
        if ( wch->in_room == NULL || /*!can_see( ch, wch ) */
        (fOOC && IS_IMMORTAL(wch) && ((wch->invis_level > ch->level) || (wch->incog_level > ch->level && ch->in_room != wch->in_room)))
        || !is_name( arg, !fOOC ? wch->name: (!is_affected(wch,gsn_shapeshifting,AFF_SKILL) ? wch->name : wch->desc->original->name )) || (!fOOC && !can_see( ch, wch )))
            continue;
        if ( ++count == number )
            return wch;
    }

    return NULL;
}

/*
 * Find an obj in a list.
 */
Object *get_obj_list( Character *ch, char *argument, Object *list )
{
    char arg[MAX_INPUT_LENGTH];
    Object *obj;
    int number;
    int count;

    number = number_argument( argument, arg );
    count  = 0;
    for ( obj = list; obj != NULL; obj = obj->next_content )
    {
    if ( can_see_obj( ch, obj ) && is_name( arg, obj->name ) )
    {
        if ( ++count == number )
        return obj;
    }
    }

    return NULL;
}



/*
 * Find an obj in player's inventory.
 */
Object *get_obj_carry( Character *ch, char *argument, Character *viewer )
{
    char arg[MAX_INPUT_LENGTH];
    Object *obj;
    int number;
    int count;

    number = number_argument( argument, arg );
    count  = 0;
    for ( obj = ch->carrying; obj != NULL; obj = obj->next_content )
    {
    if ( obj->wear_loc == WEAR_NONE
    &&   (can_see_obj( viewer, obj ) ) 
    &&   is_name( arg, obj->name ) )
    {
        if ( ++count == number )
        return obj;
    }
    }

    return NULL;
}



/*
 * Find an obj in player's equipment.
 */
Object *get_obj_wear( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Object *obj;
    int number;
    int count;

    number = number_argument( argument, arg );
    count  = 0;
    for ( obj = ch->carrying; obj != NULL; obj = obj->next_content )
    {
    if ( obj->wear_loc != WEAR_NONE
    &&   can_see_obj( ch, obj )
    &&   is_name( arg, obj->name ) )
    {
        if ( ++count == number )
        return obj;
    }
    }

    return NULL;
}



/*
 * Find an obj in the room or in inventory.
 */
Object *get_obj_here( Character *ch, char *argument )
{
    Object *obj;

    obj = get_obj_list( ch, argument, ch->in_room->contents );
    if ( obj != NULL )
    return obj;

    if ( ( obj = get_obj_carry( ch, argument, ch ) ) != NULL )
    return obj;

    if ( ( obj = get_obj_wear( ch, argument ) ) != NULL )
    return obj;

    return NULL;
}



/*
 * Find an obj in the world.
 */
Object *get_obj_world( Character *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    Object *obj;
    int number;
    int count;

    if ( ( obj = get_obj_here( ch, argument ) ) != NULL )
    return obj;

    number = number_argument( argument, arg );
    count  = 0;
    for ( obj = object_list; obj != NULL; obj = obj->next )
    {
    if ( can_see_obj( ch, obj ) && is_name( arg, obj->name ) )
    {
        if ( ++count == number )
        return obj;
    }
    }

    return NULL;
}

/* deduct cost from a character */

void deduct_cost(Character *ch, long cost)
{
    long silver = 0;
    int i;

    silver = money_total(ch);
    silver -= cost;

    for( i = MAX_CURRENCY - 1 ; i >= 0 ; i-- )
    {
        ch->coins[i] = silver / currency_table[i].silver_value;
        silver -= ch->coins[i] * currency_table[i].silver_value;
    }
    return;
}

bool is_room_owner(Character *ch, Room *room)
{
    if (room->owner == NULL || room->owner[0] == '\0')
    return FALSE;

    return is_name(ch->name,room->owner);
}

/* visibility on a room -- for entering and exits */
bool can_see_room( Character *ch, Room *pRoomIndex )
{
    if (IS_SET(pRoomIndex->room_flags, ROOM_IMP_ONLY) 
    &&  get_trust(ch) < 59 )
    return FALSE;

    if (IS_SET(pRoomIndex->room_flags, ROOM_GODS_ONLY)
    &&  !IS_IMMORTAL(ch))
    return FALSE;

    if (IS_SET(pRoomIndex->room_flags, ROOM_HEROES_ONLY)
    &&  !IS_IMMORTAL(ch))
    return FALSE;

    if (IS_SET(pRoomIndex->room_flags,ROOM_NEWBIES_ONLY)
    &&  ch->level > 5 && !IS_IMMORTAL(ch))
    return FALSE;

    //if (!IS_IMMORTAL(ch) && pRoomIndex->clan > 0 && ch->clan != pRoomIndex->clan)
    //return FALSE;

    if (!IS_IMMORTAL(ch) && !IS_NPC(ch) && 
        pRoomIndex->guild >= 0 && ch->class != pRoomIndex->guild)
    return FALSE;

    return TRUE;
}

/*
 * True if char can see victim.
 */
bool can_see( Character *ch, Character *victim )
{
    /* RT changed so that WIZ_INVIS has levels */
    if ( ch == victim )
        return TRUE;

    if ( get_trust(ch) < victim->invis_level)
        return FALSE;

    if (get_trust(ch) < victim->incog_level && ch->in_room != victim->in_room)
        return FALSE;

    if ( (!IS_NPC(ch) && IS_SET(ch->display, DISP_HOLYLIGHT)) 
    ||   (IS_NPC(ch) && IS_IMMORTAL(ch)))
        return TRUE;

    if ( IS_AFFECTED(ch, AFF_BLIND) )
        return FALSE;

    if ( ch == victim->pet )
        return TRUE;

    if ( room_is_dark( ch->in_room ) && !IS_AFFECTED(ch, AFF_INFRARED) )
        return FALSE;

    /* Monks can sense people who are invis or hidden */
    if ( IS_AFFECTED(victim, AFF_INVISIBLE) )
    {
        if ( get_skill(ch,gsn_mind) > 11 )
        {
            int levelBonus = victim->level + dice(2,4);
            int seeBonus = get_skill(ch,gsn_mind) + dice(2,4);
            
            if ( seeBonus > levelBonus )
                return TRUE;
        }

        if( !IS_AFFECTED(ch, AFF_DETECT_INVIS) )
            return FALSE;
    }

    /* sneaking */
    if ( IS_AFFECTED(victim, AFF_SNEAK) )
    {
        if ( get_skill(ch,gsn_mind) > 11 )
        {
            int levelBonus = get_skill(victim,gsn_stealth) + dice(2,4);
            int seeBonus = get_skill(ch,gsn_mind) + dice(2,4);

            if ( seeBonus > levelBonus )
                return TRUE;
        }

        if ( !IS_AFFECTED(ch,AFF_DETECT_HIDDEN) && victim->fighting == NULL)
        {
            int chance = get_skill(victim, gsn_stealth);
//            chance = get_skill(victim,gsn_stealth);
//            chance += get_curr_stat(victim,STAT_DEX) * 3/2;
//             chance -= get_curr_stat(ch,STAT_INT) * 2;
//            chance -= ch->level - victim->level * 3/2;
            if(chance > ch->level)
                chance = 0;//You can't detect someone who's skill is above your level
            else
            {//7% is the base chance to see someone
//Below level of stealth: Never.
//Equal to level of stealth: 7%
//1 above level of stealth: 14%
//2 above level of stealth: 35%
//3 above level of stealth: 56%
//4 above level of stealth: 91%
//5 and higher above level of stealth: 99%
                chance = ch->level - chance;
                chance = 7 * (1 + (chance * (chance + 2)) / 2);
                chance = UMIN(chance, 99);
            }
            if (number_percent() > chance)
                return FALSE;
        }
    }

    /* NPCs with FORM_VIS_NIGHT - won't go invis in combat if it turns 
     * night.
     */
    if ( IS_NPC(victim) && IS_SET(victim->form,FORM_VIS_NIGHT) &&
        IS_DAYTIME && victim->fighting == NULL )
        return FALSE;

    /* Treeform  - put here cuz almost all the rest of these
       checks are faster, this one involves a lookup */
    if ( is_affected(victim,vnum_treeform,AFF_SPELL) &&
         victim->in_room->sector_type == SECT_FOREST &&
         ch->class != class_lookup("druid") )
        return FALSE;

    return TRUE;
}



/*
 * True if char can see obj.
 */
bool can_see_obj( Character *ch, Object *obj )
{
    if ( !IS_NPC(ch) && IS_SET(ch->display, DISP_HOLYLIGHT) )
        return TRUE;

    if ( IS_SET(obj->extra_flags,ITEM_VIS_DEATH))
        return FALSE;

    if ( IS_AFFECTED( ch, AFF_BLIND ) && obj->item_type != ITEM_POTION)
        return FALSE;

    if ( obj->item_type == ITEM_LIGHT && obj->value[2] != 0 )
        return TRUE;

    if ( IS_SET(obj->extra_flags, ITEM_INVIS)
    &&   !IS_AFFECTED(ch, AFF_DETECT_INVIS) )
        return FALSE;

    if ( room_is_dark( ch->in_room ) && !IS_AFFECTED(ch, AFF_DARK_VISION) &&
            !IS_AFFECTED(ch,AFF_INFRARED) )
        return FALSE;

    return TRUE;
}



/*
 * True if char can drop obj.
 */
bool can_drop_obj( Character *ch, Object *obj )
{
    if ( !IS_SET(obj->extra_flags, ITEM_NODROP) )
        return TRUE;

    if ( !IS_NPC(ch) && ch->level >= LEVEL_IMMORTAL )
        return TRUE;

    return FALSE;
}


bool can_take_class( Character *ch, int index )
{
    if ( ch->gen_data == NULL )
    {
    cprintf(ch,"There is an error with your character.\n\r");
    return FALSE;
    }

    if ( subrace_table[ch->pcdata->subrace].class_mult[index] )
    return TRUE;
    else
    return FALSE;
}

int calc_save(Character *ch,int stat)
{
    int save;

    save = ch->level;

    switch(stat)
    {
    case SAVE_REFLEX:    save += apply_stat(ch,STAT_DEX); break;
    case SAVE_FORTITUDE: save += apply_stat(ch,STAT_CON); break;
    case SAVE_WILLPOWER: save += apply_stat(ch,STAT_WIS); break;
    default:
    log_bug("Unknown save type %d",stat);
    }

    save += ch->saves[stat];

    return save; /* negative saves are ok */
}

char * alt_graph( Character *ch, int size )
{
    static char graph[MAX_STRING_LENGTH];
    int tnl; /* to next level */
    int cur; 
    int percent, x, num_lbs, num_dash;
    int i;

    if ( IS_NPC(ch) )
        return "ERROR:NPC_GRAPH";

    cur = ch->pcdata->spec_exp;
    tnl = exp_to_level[ch->pcdata->spec_level].tnl;

    if ( cur > tnl )
    cur = tnl;

    graph[0] = '\0';
    strcat(graph,"&W[&Y");

    /* Figure out how many #'s we need to print */
    percent = cur*100/tnl;
    x = 100 / size; /* 1 pound represents x % of progress */
    num_lbs = percent * size / 100; /* cross multiply */
    num_dash = size - num_lbs;

    for ( i=0 ; i<num_lbs ; i++ )
     strcat(graph,"#");

    strcat(graph,"&x");

    for ( i=0 ; i<num_dash ; i++ )
    strcat(graph,"-");

    strcat(graph,"&W]&x");

    return graph;
}
/* Print a graph of XP tnl, using size slots to represent progress */
char * exp_graph( Character *ch, int size )
{
    static char graph[MAX_STRING_LENGTH];
    int tnl; /* to next level */
    int cur; 
    int percent, x, num_lbs, num_dash;
    int i;

    cur = ch->exp;
    tnl = exp_to_level[ch->level].tnl;

    if ( cur > tnl )
    cur = tnl;

    graph[0] = '\0';
    strcat(graph,"&W[&Y");

    /* Figure out how many #'s we need to print */
    percent = cur*100/tnl;
    x = 100 / size; /* 1 pound represents x % of progress */
    num_lbs = percent * size / 100; /* cross multiply */
    num_dash = size - num_lbs;

    for ( i=0 ; i<num_lbs ; i++ )
     strcat(graph,"#");

    strcat(graph,"&x");

    for ( i=0 ; i<num_dash ; i++ )
    strcat(graph,"-");

    strcat(graph,"&W]&x");

    return graph;
}

void apply_healing( Character *ch, int amount )
{
    if ( amount <= 0 )
    return;

    if ( IS_AFFECTED(ch,AFF_DISEASE) )
        amount /= 2;

    if ( ch->base_hit < ch->max_base_hit )
    {
        int max_heal = (amount/2);
        int amount_healed = UMIN(max_heal,ch->max_base_hit-ch->base_hit);

        amount -= ( amount_healed * 2 );
        ch->base_hit += amount_healed;
    }

    if ( amount > 0 )
        ch->stat_hit = UMIN(ch->stat_hit+amount,max_stat_hit(ch));

    update_pos( ch );
}

bool can_equip( Character *ch, Object *obj )
{
    int gpn;
    extern int con_diff( int level1, int level2 );

    if ( con_diff(ch->level,obj->level) < -2 )
    {
        cprintf(ch,"This object is too powerful for you to equip.\n\r");
        return FALSE;
    }

    if ( obj->deity && (obj->deity != ch->deity) )
    {
        cprintf(ch,"Only followers of %s may wear this item, and you %s %s.\n\r", 
            deity_table[obj->deity].name,
            ch->deity == 0 ? "are" : "follow",
            deity_table[ch->deity].name );
        return FALSE;
    }

    if ( obj->item_type != ITEM_ARMOR || IS_NPC(ch) )
        return TRUE;

    if ( obj->value[5] == 0 )
        return TRUE;

    if ( obj->value[5] < 0 || obj->value[5] > 10 )
    {
        if( obj->pIndexData == NULL )
        log_string("Bad value 5 on armor vnum %d: %d", obj->pIndexData->vnum, obj->value[5] );
        act("$p has an incorrect armor type setting, and cannot be equipped.",ch,obj,NULL,TO_CHAR);
        return FALSE;
    }
     gpn = *(armor_table[obj->value[5]].pgpn);
    if ( ch->pcdata->profs[gpn] && ch->level >= prof_table[gpn].class_avail[ch->class] &&
            prof_table[gpn].class_avail[ch->class] > 0 )
    return TRUE;
 
    cprintf(ch,"This item requires the %s skill to equip.\n\r",prof_table[gpn].name ); 
    return FALSE;
}

bool has_obj( Character *ch, Object *obj, Object *list )
{
    Object *pObj;

    if ( obj->contains == NULL )
        return ( has_instance(ch,obj,list) );
    else
    {
        for( pObj = obj->contains ; pObj != NULL ; pObj = pObj->next_content )
        {
               if ( IS_SET(pObj->extra_flags,ITEM_UNIQUE) && has_instance(ch,pObj,list) )
                return TRUE;
        }
    }
    return FALSE;
}

bool has_instance( Character *ch, Object *obj, Object *list )
{
    extern bool check_list_for_instance( Character *, Object *, Object * );

    if ( IS_NPC(ch) )
        return FALSE;

    if ( check_list_for_instance(ch, obj, list) )
        return TRUE;
    else
    if ( check_list_for_instance(ch,obj,ch->pcdata->bank) )
        return TRUE;
    else
    return FALSE;
}

bool check_list_for_instance( Character *ch, Object *obj, Object *list )
{
    int vnum;
    Object *pObj;

    vnum = obj->pIndexData->vnum;

    if ( IS_NPC(ch) )
        return FALSE;

    for ( pObj = list ; pObj != NULL ; pObj = pObj->next_content )
    {
        if ( pObj->pIndexData->vnum == vnum && pObj != obj )
            return TRUE;
        if ( pObj->contains != NULL && check_list_for_instance(ch,obj,pObj->contains) )
            return TRUE;
    }

    return FALSE;
}

void resetCustomColorData( Character *ch )
{
    int i;

    if ( IS_NPC(ch) )
    return;

    for ( i = 0 ; i < MAX_CHANNELS ; i++ )
       ch->pcdata->customChannelColor[i] = channel_table[i].defaultColor;
}

int max_mana( Character *ch )
{
    long maxMana;
    int adjust_stat;

    if ( IS_NPC(ch) )
        return ch->max_mana;

    if ( !class_table[ch->class].fMana )
        return 0;

    maxMana = (long) ch->max_mana;
    if ( class_table[ch->class].group == ARCANE )
         adjust_stat = STAT_INT;
    else
    if ( class_table[ch->class].group == DIVINE )
        adjust_stat = STAT_WIS;
    else
    if ( !str_cmp(class_table[ch->class].name,"bard") )
        adjust_stat = STAT_CHA;
    else
        adjust_stat = STAT_WIS;

    maxMana = (long) (100+apply_stat(ch,adjust_stat)) * maxMana / 100;
    return (int) UMIN(maxMana,30000);
}

int max_stamina( Character *ch )
{
    long maxStamina;

    if ( IS_NPC(ch) )
        return ch->max_stamina;

    maxStamina = (long) (100+apply_stat(ch,STAT_STR)) * ch->max_stamina / 100;
    return (int) UMIN(maxStamina,30000);
}

int max_stat_hit( Character *ch )
{
    long maxStatHit;

    if ( IS_NPC(ch) )
        return ch->max_stat_hit;

    maxStatHit = (long) (100+apply_stat(ch,STAT_CON)) * ch->max_stat_hit / 100;
    return (int) UMIN(maxStatHit,30000);
}

void coins_to_merchant(Character *ch, long amount )
{
    int i;
    long tmp;

    for( i = MAX_CURRENCY - 1 ; i >= 0 ; i-- )
    {
        if ( (tmp = amount / currency_table[i].silver_value) > 0 )
        {
            ch->coins[i] += tmp;
            amount -= (tmp * currency_table[i].silver_value );
        }
    }
    return;
}

void reset_racial_data( Character *ch )
{
    ch->affected_by = ch->affected_by|race_table[ch->race].aff;
    ch->imm_flags   = ch->imm_flags | race_table[ch->race].imm;
    ch->form        = race_table[ch->race].form;
    ch->parts       = race_table[ch->race].parts;

    return;
}

int get_hitroll( Character *ch )
{
    int hitroll;
    int    stat;

    /* If their hitroll is negative, leave it alone */
    if ( (hitroll = ch->hitroll) <= 0 )
        return ch->hitroll;

    stat = STAT_STR;
    if ( HAS_PROF(ch,gpn_weapon_finesse) )
        stat = STAT_DEX;

    hitroll = (100+apply_stat(ch,stat))*hitroll/100;
    
    return hitroll;
}

void check_encumbrance( Character *ch )
{
    bool fEncumbered = FALSE;

    if ( IS_NPC(ch) && IS_SET(ch->act, ACT_PET) )
        return;

    if( is_affected(ch,gsn_encumbered,AFF_SKILL) )
    {
        fEncumbered = TRUE;
        skill_affect_strip(ch,gsn_encumbered);
    }

    if( get_carry_weight(ch) > can_carry_w(ch) )
    {
        Affect af;

        af.where        = TO_AFFECTS;
        af.type         = gsn_encumbered;
        af.duration     = -1;
        af.level        = ch->level;
        af.location     = APPLY_DEX;
        af.modifier     = (get_carry_weight(ch) - can_carry_w(ch)) * -2 / 10;
        af.bitvector    = AFF_SLOW;
        af.flags        = AFF_SKILL;
        skillAffectToChar(ch,&af);
        if ( !fEncumbered )
            cprintf(ch,"You are encumbered!\n\r");
    }
    else
    if ( fEncumbered && ch)//Should be a check for preventing finger crashes.
        cprintf(ch,"You are no longer encumbered.\n\r");

    return;
}

Character *get_char_by_id( long id )
{
    Character *ch;

    for ( ch = char_list ; ch != NULL ; ch = ch->next )
        if ( ch->id == id )
                return ch;

    return NULL;
}

int get_saves_bonus( Character *ch, int damage_type )
{
    int res;

    if ( (res = convertDamtypeToResistIndex( damage_type )) < 0 )
        return 0;
    else
        return (ch->resists[res].value + ch->resists[res].mod);
}

int modify_for_resists( Character *ch, int dam, int damage_type )
{
    int res;

    if( (res = convertDamtypeToResistIndex( damage_type )) < 0 )
    {
        return dam;
    }
    else
    if ( res >= MAX_PC_RESISTS && !IS_NPC(ch) )
    {
        return dam;
    }
    else
    {
        return ( dam * ( 100 - (ch->resists[res].value+ch->resists[res].mod)) / 100 );
    }
}
    
int find_snare( Character *ch )
{
    Affect *paf;
    int snare = 0;

    for( paf = ch->affected ; paf != NULL ; paf = paf->next )
        if ( paf->location == APPLY_MOVE_RATE )
            snare = UMAX(snare,paf->modifier);

    return snare;
}

Affect *find_damage_shield( Character *ch )
{
    Affect *paf;

    for ( paf = ch->affected ; paf != NULL ; paf = paf->next )
     if ( paf->where == DAMAGE_SHIELD )
        return paf;

    return NULL;
}

Affect *find_bladeturn( Character *ch )
{
    Affect *paf;
    
    for ( paf = ch->affected ; paf != NULL ; paf = paf->next )
        if ( paf->location == APPLY_BLADETURN  )
            return paf;

    return NULL;
}

Affect *find_affect_type( Character *ch, int type )
{
    Affect *paf;

    for( paf = ch->affected ; paf != NULL ; paf = paf->next )
        if ( paf->location == type )
            return paf;

    return NULL;
}

long _money_total( Character *ch )
{
    int i;
    long total = 0;

    for( i = 0 ; i < MAX_CURRENCY ; i ++ )
        total += ch->coins[i] * currency_table[i].silver_value;

    return total;
}

int    _coin_weight( Character *ch )
{
    int i;
    int total = 0;
 
    for( i = 0; i < MAX_CURRENCY; i++ )
        if ( ch->coins[i] > 0 )
            total += get_coin_weight(i, ch->coins[i]);
        /*total += (ch->coins[i] / currency_table[i].num_per_pound == 0 ? 100 : currency_table[i].num_per_pound );*/

    return total; // in tenth-lbs
}

int _attack_power( Character *ch )
{
    float total;
    
    total = 50 + (class_table[ch->class].thac0 * ch->level) + GET_HITROLL(ch);
    total += get_weapon_skill(ch, get_weapon_sn(ch,GET_WEAPON_SN) );

    if ( total > 50 )
        total = ( total - 50 ) / 2 + 50;
    if ( total > 75 )
        total = ( total - 75 ) / 3 + 75;
    if ( total > 90 )
        total = ( total - 90 ) / 4 + 90;
 
    return (int) total;
}

int guild_point_value( Character *ch )
{
    int val;
    double l;
    int hours = 0;

    if ( IS_NPC(ch) )
        return 0;

    /* No GP if they've been pkilled in the last 15 minutes */
    if ( ((current_time - ch->pcdata->last_pdeath) / 60) < 15 )
        return -1;

    val = ch->level * 2;

    if ( ch->pcdata->guild_points > 0 )
        l = log10( ch->pcdata->guild_points );
    else
        l = 0;

    val +=  (int) (l*l*l*l);
    if ( ch->played / 3600 > 50 && ch->pcdata->last_pdeath > 0 )
        hours = (current_time - ch->pcdata->last_pdeath) / 3600;
    hours = UMAX(hours,0);
    val = ( 100 + hours ) * val / 100;
    return val;
}

char *con_msg( Character *ch, Character *victim )
{
    static char buf[MAX_STRING_LENGTH];
    char col;    
    int diff;
    char *msg;

    col = get_con_color(ch->level,victim->level);
    diff = con_diff(ch->level,victim->level);

    switch( diff )
    {
        case 0: msg = "a fairly even fight"; break;
        case 1: msg = "a likely victory"; break;
        case 2: msg = "an easy kill"; break;
        case -1: msg = "a tough fight"; break;
        case -2: msg = "a serious challenge"; break;
        default:
            if ( diff < -2 )
                msg = "complete suicide"; 
            else
            if ( diff > 2 )
                msg = "a trivial conflict"; 
            else
            {
                log_bug("bad con amount %d",diff);
                msg = " ... who can tell";
            }
    }

    snprintf(buf,sizeof(buf),"&%c%s&x.",col,msg);
    return buf;
}

char *pers_ooc( Character *ch, Character *looker )
{
    static char    buf[MAX_STRING_LENGTH];

    snprintf(buf,sizeof(buf),"%s",
        can_see( looker, ch ) ? ( IS_NPC(ch) ? ch->short_descr : (is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->desc->original->name : ch->name )) :
            (IS_IMMORTAL(ch) ? "an immortal" : ( IS_NPC(ch) ? ch->short_descr : ch->name )) );

    return buf;
}

char *pers( Character *ch, Character *looker )
{
    static char    buf[MAX_STRING_LENGTH];

    snprintf(buf,sizeof(buf),"&%c%s&x",
        HAS_COLOROPT(looker,COLOR_MOB_CON) ? get_con_color( looker->level, ch->level ) : 'x',
        can_see( looker, ch ) ? ( (IS_NPC(ch)||is_affected(ch,gsn_shapeshifting,AFF_SKILL)) ? ch->short_descr : ch->name ) :
            (IS_IMMORTAL(ch) ? "an immortal" : "someone") );

    return buf;
}

void drainStamina( Character *ch, int amount )
{
    /* check for endurance */
    if ( HAS_PROF(ch,gpn_endurance) )
        amount=UMAX(1,(amount*80/100));

    ch->stamina = UMAX(0,ch->stamina - amount);
    return;
}

int get_ac( Character *ch, int type )
{
    int ac;
    int dex;

    ac = ch->armor[type];
    dex = get_curr_stat(ch,STAT_DEX);
    if ( IS_AWAKE(ch) && dex >= 100 )
        ac += apply_stat(ch,STAT_DEX);

    if ( *class_table[ch->class].csn == csn_thief ||
          *class_table[ch->class].csn == csn_assassin )
        ac += apply_stat(ch,STAT_DEX);

    if ( *class_table[ch->class].csn == csn_monk )
    {
        int free_carry = 200;

        if ( HAS_PROF(ch,gpn_pack_mule) )
            free_carry = 300;

        ac += ( ch->level * dex / 25 );
        /* also watch for weight */
        if ( get_carry_weight(ch) > free_carry ) /* 20.0 lbs */
            ac -= ( (get_carry_weight(ch)-free_carry) / 3 );
    }

    return ac;
}

void dazeState( Character *ch, int pulse )
{
    if ( ch->stun_timer > current_time )
        return;
    else
    {
        ch->stun_timer = current_time + 60;
        ch->daze = UMAX( ch->daze, pulse );
    }
    return;
}

int get_damroll( Character *ch )
{
    int damroll;
    int stat;

    if ( HAS_PROF(ch,gpn_weapon_finesse) )
        stat = (get_curr_stat(ch,STAT_STR) + get_curr_stat(ch,STAT_DEX)) / 2;
    else
        stat = get_curr_stat(ch,STAT_STR);

    damroll = ch->damroll;
    damroll += UMAX(0,((stat-100)/5 * class_table[ch->class].thac0));

    return damroll;
}

void setResist( Character *ch, int resist, int amount )
{
    if ( amount == RESIST_IMMUNE )
        ch->resists[resist].immune = TRUE;
    else
    {
        ch->resists[resist].immune = FALSE;
        ch->resists[resist].value  = amount;
    }

    return;
}

void char_from_list( Character *ch )
{
    if ( ch == char_list )
    {
       char_list = ch->next;
    }
    else
    {
        Character *prev;

        for ( prev = char_list; prev != NULL; prev = prev->next )
        {
            if ( prev->next == ch )
            {
            prev->next = ch->next;
            ch->next = NULL;        
            break;
            }
        }
   
        if ( prev == NULL )
        {
            log_bug( "Extract_char: char not found.", 0 );
            return;
        }
    }
}

void drop_obj( Character *ch, Object *obj )
{
    obj_from_char( obj );
    obj_to_room( obj, ch->in_room );
    act( "$n drops $p.", ch, obj, NULL, TO_ROOM );
    act( "You drop $p.", ch, obj, NULL, TO_CHAR );
    if (IS_OBJ_STAT(obj,ITEM_MELT_DROP))
    {
        act("$p dissolves into smoke.",ch,obj,NULL,TO_ROOM);
        act("$p dissolves into smoke.",ch,obj,NULL,TO_CHAR);
        extract_obj(obj);
    }
}

//
// Continue to move character down rooms until either
// a threshold is reached of too many rooms, suggesting
// an infinite fall loop, or there's no more FALL/CLIMB
// exits below.
//
void characterFalls( Character *ch )
{
    Room *r = ch->in_room;
    Exit *pexit;
    int fallCount = 1;
    int dam=0, i;

    act("$n falls!",ch,NULL,NULL,TO_ROOM);
    act("You fall!",ch,NULL,NULL,TO_CHAR);

    while(1)
    {
        // No more exits down
        if ( (pexit = r->exit[DIR_DOWN]) == NULL )
            break;

        // Make sure there's a room there
        if ( (r = pexit->u1.to_room) == NULL )
            break;

        // Make sure it's a climb or fall exit
        if ( !IS_SET(pexit->exit_info,EX_CLIMB) &&
             !IS_SET(pexit->exit_info,EX_SHEER_CLIMB) &&
             !IS_SET(pexit->exit_info,EX_FALL) )
            break;

        char_from_room(ch);
        char_to_room(ch,r);
        do_look(ch,"auto");
        act("$n falls in from above!",ch,NULL,NULL,TO_ROOM);
        ++fallCount;
    }

    if ( HAS_PROF(ch,gsn_safe_fall) )
    {
        act("You recover from your fall, and suffer no damage.",ch,NULL,NULL,TO_CHAR);
        act("$n lands and rolls gracefully to $s feet, apparantly unharmed.",ch,NULL,NULL,TO_ROOM);
        return;
    }

    // Ok, now calculate damage.  1d6 base damage per room of falling.
    for( i=0 ; i < fallCount ; i++ )
        dam += dice(1,6);

    actprintf(ch,NULL,NULL,TO_CHAR,"You slam into the ground and take %d base hits of damage!",dam);
    act("$n slams into the ground and is stunned!",ch,NULL,NULL,TO_ROOM);
    damage(ch,ch,dam,0,DAM_BASH,DF_BASEHITS);

    // set daze but don't reset combat timer
    ch->daze = PULSE_PER_SECOND * 4;
}
