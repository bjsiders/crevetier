/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003, 2011 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
****************************************************************************/

#include <sys/types.h>
#include <sys/time.h>
#include <stdarg.h>    /* va_list, etc */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>

#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include "telnet.h"
#include "thoc.h"
#include "thocerror.h"

extern int clientSocket;

int create_client_socket( int port )
{
    static struct sockaddr_in sa_zero;
    struct sockaddr_in sa;
    int x = 1;
    int fd;

    if ( ( fd = socket( AF_INET, SOCK_STREAM, 0 ) ) < 0 )
    {
		log_error( "create_client_socket: socket" );
		return -1;
    }

    if ( setsockopt( fd, SOL_SOCKET, SO_REUSEADDR, (char *) &x, sizeof(x) ) < 0 )
    {
		log_error( "create_client_socket: SO_REUSEADDR" );
		close(fd);
		return -1;
    }

    sa		    	= sa_zero;
    sa.sin_family   = AF_INET;
    sa.sin_port	    = htons( port );

    if ( bind( fd, (struct sockaddr *) &sa, sizeof(sa) ) < 0 )
    {
		log_error("create_client_socket: bind" );
		close(fd);
		return -1;
    }

    if ( listen( fd, 3 ) < 0 )
    {
		log_error("create_client_socket: listen");
		close(fd);
		return -1;
    }

    return fd;
}

void process_client_connection( int fd )
{
	
}

