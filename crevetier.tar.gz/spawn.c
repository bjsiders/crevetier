/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

#include "thoc.h"
#include "olc.h"

Spawn * spawnTable;
void spawnDoor( Spawn *s, Room *r );

bool readyToPop( Spawn *s )
{
	/* Filter errors */
	if ( SPAWN_FLAG(s,SPAWN_ERROR) )
		return FALSE;
		
	/* 1. See if the thing already exists.
	 */
	if ( !SPAWN_FLAG(s,SPAWN_READY) && !SPAWN_FLAG(s,SPAWN_CONTENT) )
		return FALSE;
		
	/* 2. Check clock times.
	 */
	if ( s->clockStart >= 0 && s->clockEnd >= 0 )
	{
		if ( time_info.hour < s->clockStart && time_info.hour > s->clockEnd )
			return FALSE;
	}
	
	/* 3. Check interval
	 */
	if( --(s->timer) > 0 )
		return FALSE;
	
	/* 4. Interval is expired, time to spawn.
	 */
	s->timer = s->interval;
	if ( SPAWN_FLAG(s,SPAWN_CONTENT) )
	{
		REMOVE_BIT(s->flags,SPAWN_CONTENT);
		return 2;
	}

	REMOVE_BIT(s->flags,SPAWN_READY);
	return TRUE;
}	

Character *spawnMob( MobIndex *m, Room *r, Spawn *s )
{
	Character *ch;
	
	if ( (ch = create_mobile( m )) == NULL )
		return NULL;
		
	char_to_room( ch, r );
	ch->spawn = s;

	if ( ch->pIndexData->spawn_echo != NULL )
		act(ch->pIndexData->spawn_echo,ch,NULL,NULL,TO_ROOM);
	return ch;
}

Object *spawnObj( ObjIndex *o, Room *r, Spawn *s )
{
	Object *obj;
	
	if( (obj = create_object( o )) == NULL )
	{
		log_string("spawnObj: obj %d doesn't exist", o->vnum );
		return NULL;
	}
		
	obj_to_room( obj, r );
	obj->spawn = s;
	return obj;
}		

void spawnContents( void *thing, Spawn *spawn )
{
	Character *ch = NULL;
	Object	  *obj = NULL, *loadObj;
	Quest		*pQuest = NULL;
	Script		*script = NULL;
	ObjIndex		*pObj;
	ScriptIndex			*pScript;
	Spawn 	*s;
	int 	vnum;

	if ( spawn == NULL || spawn->contains == NULL )
		return;
		
	switch( spawn->type )
	{
		case 's': case 'S':
			script = (Script *) thing;
			break;
		case 'q': case 'Q':
			pQuest = (Quest *) thing;
			break;
		case 'm': case 'M':
			ch = (Character *) thing;
			break;
		case 'c': case 'C':
		case 'i': case 'I':
		case 'e': case 'E':
		case 'o': case 'O':
			obj = (Object *) thing;
			spawn->pContent = obj;
			break;
		default:
			log_string("spawnContents: type %c is invalid",spawn->type);
			SET_BIT(spawn->flags,SPAWN_ERROR);
			return;
	}
	
	/* Ok we have the source object type, now process its content spawns */
	for ( s = spawn->contains ; s != NULL ; s = s->next_content )
	{
		if ( IS_SET(s->flags,SPAWN_ERROR))
			continue;
			
		/* Get vnum for source item */
		vnum = s->source;
		if ( s->frequency > 0 && s->frequency < 100 && number_percent() > s->frequency )
			if ( (vnum = s->placeholder) <= 0 )
				continue;
	
		switch( s->type )
		{
			case 'm': case 'M': /* Mobs are root spawns only, never content spawns */
			case 'o': case 'O':						
			case 'd': case 'D':
			
				log_string("spawn #%d: invalid content spawn type %c", s->index, s->type );
				SET_BIT(s->flags,SPAWN_ERROR);
				continue;
				
			case 'q': case 'Q':
				if ( ch == NULL )
				{
					log_string("spawn #%d: Q spawn: expecting valid 'ch' to load to - ch is NULL", s->index );
					continue;
				}
		
				if ( (pQuest = get_quest_index( vnum )) == NULL )
				{
					log_string("spawn #%d: source quest %d doesn't exist", s->index, vnum );
					SET_BIT(s->flags,SPAWN_ERROR);
					continue;
				}
			
				/* Set quest pointers */
				pQuest->next = ch->quests;
				ch->quests = pQuest;
				continue;

			case 's': case 'S':
                if ( ch == NULL )
                {
                    log_string("spawn #%d: S spawn: expecting valid 'ch' to load to - ch is NULL", s->index );
                    continue;
                }

                if ( (pScript = get_script_index( vnum )) == NULL )
                {
                    log_string("spawn #%d: source script %d doesn't exist", s->index, vnum );
                    SET_BIT(s->flags,SPAWN_ERROR);
                    continue;
                }

				script = create_script( pScript );

				script->next = ch->scripts;
				ch->scripts = script;	
                continue;

			case 'e': case 'E':
			case 'i': case 'I':
				if ( ch == NULL )
				{
					log_string("spawn #%d: E/I spawn: expecting valid 'ch' to load to - ch is NULL", s->index );
					continue;
				}
			
				if ( (pObj = get_obj_index( vnum )) == NULL )
				{
					log_string("spawn #%d: source item %d doesn't exist", s->index, vnum );
					SET_BIT(s->flags,SPAWN_ERROR);
					continue;
				}
				
				/* Create item to spawn */
				loadObj = create_object( pObj );
				loadObj->spawn = s;

				/* If the parent mob is a shop keeper, set the inventory flag */
				if ( ch->pIndexData->pShop != NULL )
					SET_BIT( loadObj->extra_flags, ITEM_INVENTORY );

				/* bump up condition for shopkeepers 
				if ( ch->pIndexData->pShop ) {
					pObj->condition = 100;
					pObj->durability = 100;
					pObj->quality = 85;
				}  */

				/* give it to the character */
				obj_to_char( loadObj, ch );

				/* equip it if we need to */
				if ( toupper(s->type) == 'E' )
					equip_char( ch, loadObj, s->misc );

				/* Spawn its contents if it has any */
				spawnContents( (void *) loadObj, s );
				continue;
				
			case 'c': case 'C':
				if ( obj == NULL )
				{
					log_string("spawn #%d: expecting valid 'obj' to load to - obj is NULL", s->index );
					continue;
				}
				
				if ( (pObj = get_obj_index( vnum )) == NULL )
				{
					log_string("spawn #%d: source item %d doesn't exist", s->index, vnum );
					SET_BIT(s->flags,SPAWN_ERROR);
					continue;
				}

				/* Create item to spawn */
				loadObj = create_object( pObj );
				loadObj->spawn = s;

				/* put it in the object */
				obj_to_obj( loadObj, obj );

				/* check the parent object's container flags, if it has any */
				if ( obj->item_type == ITEM_CONTAINER )
					obj->value[1] = obj->pIndexData->value[1];
			
			
				/* Spawn its contents if it has any */
				spawnContents( (void *) loadObj, s );
				continue;				
			
			default:
				log_string("spawn #%d: unknown spawn type %c",s->index,s->type );
				SET_BIT(s->flags,SPAWN_ERROR);
				continue;
		}
	} /* End for */
				
	/* That's everything for this object */
	return;
}
	
void processSpawn( Spawn *s, bool fContent )
{
	int vnum;
	Room *r;
	MobIndex *pMob;
	ObjIndex *pObj;
	bool fSpawnContents = TRUE;

	/* Reset timer */
	s->timer = s->interval;

	/* For fContent, we just find the item and spawn its contents */
	if ( fContent )
	{
		Object *obj;

		if ( (obj = s->pContent) == NULL )
		{
			log_string("spawn #%d: object pointer points to nothing",s->index);
			SET_BIT(s->flags,SPAWN_ERROR);
			return;
		}
		
		spawnContents( (void *) obj, s );
		return;
	}

	/* Get vnum for source item */
	vnum = s->source;
	if ( s->frequency > 0 && s->frequency < 100 && number_percent() > s->frequency )
	{
		if ( (vnum = s->placeholder) <= 0 && toupper(s->type) != 'D' )
		{
			/*log_string("spawn #%d frequency failed, no placeholder", s->index );*/
			if ( SPAWN_FLAG(s,SPAWN_FORCE) )
				REMOVE_BIT(s->flags,SPAWN_FORCE);
			else
				return; /* no placeholder, leave the spawn as READY with a fresh timer */
		}
	}

	/* if vnum != source, this is a replacement spawn, and we shouldn't load the objects */
	if ( vnum != s->source )
		fSpawnContents = FALSE;
	
	/* Make sure room is valid */
	if ( (r = get_room_index( s->target )) == NULL )
	{
		log_string("spawn #%d: no such ROOM with vnum %d",s->index,s->target);
		SET_BIT(s->flags,SPAWN_ERROR);
		return;
	}
	
	/* Ok, we have a vnum, see what it's for, make sure there is such a source object */
	switch( s->type )
	{
		case 'm': case 'M':
			if ( (pMob = get_mob_index(vnum)) == NULL )
			{
				log_string("spawn #%d: no such NPC with vnum %d",s->index,s->source);
				SET_BIT(s->flags,SPAWN_ERROR);
				return;
			}			
			if ( fSpawnContents )
				spawnContents( (void *) spawnMob( pMob, r, s ), s );
			else
				spawnMob( pMob, r, s );
			return;
			
		case 'e': case 'E':
		case 'i': case 'I':
		case 'c': case 'C':
			log_string("spawn #%d: spawn type %c invalid for root", s->index, s->type);
			SET_BIT(s->flags,SPAWN_ERROR);
			return;
			
		case 'o': case 'O':
			if ( (pObj = get_obj_index(vnum)) == NULL )
			{
				log_string("spawn #%d: no such OBJ with vnum %d",s->index,s->source);
				SET_BIT(s->flags,SPAWN_ERROR);
				return;
			}

			if ( fSpawnContents )
				spawnContents( (void *) spawnObj( pObj, r, s ), s );
			else
				spawnObj( pObj, r, s );

			return;
		
		case 'd': case 'D': /* Doors */
			if ( s->source < 0 || s->source > 5 )
			{
				log_string("spawn #%d: door %d is out of door range",s->index,s->source);
				SET_BIT(s->flags,SPAWN_ERROR);
				return;
			}
			spawnDoor( s, r );
			return;
		
		default:
			log_string("spawn #%d: unknown spawn type %c",s->index,s->type );
			SET_BIT(s->flags,SPAWN_ERROR);
			return;
	}
	
	/* All done.  Shoudln't even get to this point */
	return;
}
			
void spawnDoor( Spawn *s, Room *r )
{
	/* Just set the exit flags */
	Exit *pExit;

	if ( (pExit = r->exit[s->source]) == NULL )
	{
		SET_BIT(s->flags,SPAWN_ERROR);
		log_string("spawn #%d: no exit in that direction", s->index );
		return;
	}

	pExit->exit_info |= s->misc;
	pExit->spawn = s;
	return;
}
		
void spawnRoom( Room *r )
{
	Spawn *s;

	for( s = r->spawns ; s != NULL ; s = s->next_in_room )
	{
		bool fContent = 0;

		if ( (fContent = readyToPop(s)) )
			processSpawn(s,(fContent==2));
	}
	
	return;
}

void initSpawn( void )
{
	extern void updateSpawn( void );
	int i;

	for( i=0; i<6; i++ )
		updateSpawn( );
}

/* We update 1/6th of the rooms every 10 seconds */
void updateSpawn( void )
{
    int i;
    static int start;
    Room *r;

    for( i = start ; i < 100000 ; i += 6 )
    {
        if ( (r = get_room_index( i )) != NULL )
            spawnRoom( r );
    }

    if( ++start > 5 )
        start = 0;
}

void resetObjectSpawn( Object *obj )
{
	if ( obj->spawn != NULL )
	{
		REMOVE_BIT(obj->spawn->flags,SPAWN_CONTENT);
		SET_BIT(obj->spawn->flags,SPAWN_READY);
		obj->spawn->pContent = NULL;
		obj->spawn = NULL;
	}
}

void printSpawn( Character *ch, Spawn *s )
{
	MobIndex	*pMob;
	ObjIndex	*pObj;
	Quest			*pQuest;
	ScriptIndex		*pScript;

	switch( s->type )
	{
    case 's': case 'S':  
        if ( (pScript = get_script_index( s->source )) == NULL )
            cprintf(ch,"[%5d] <broken>\n\r", s->source );
        else
        cprintf(ch,"#%5d %c NA [%5d] Script :: %-32s\n\r",
            s->index, IS_SET(s->flags,SPAWN_READY) ? 'R' : 'P',
            pScript->vnum, pScript->name );
        break; 
	case 'q': case 'Q':
		if ( (pQuest = get_quest_index( s->source )) == NULL )
			cprintf(ch,"[%5d] <broken>\n\r", s->source );
		else
		cprintf(ch,"#%5d %c NA [%5d] Quest :: %-32s\n\r",
			s->index, IS_SET(s->flags,SPAWN_READY) ? 'R' : 'P',
			pQuest->vnum, pQuest->name );
		break;
	case 'd': case 'D':
		cprintf(ch,"#%5d %c%3d [%5s] door spawn sets flags (%s)\n\r",
			s->index, IS_SET(s->flags,SPAWN_READY) ? 'R' : 'P',
			s->timer, dir_name[s->source], flag_string( exit_flags, s->misc ) );
		break;
	case 'm': case 'M':
		if ( (pMob = get_mob_index( s->source )) == NULL )
			cprintf(ch,"[%5d] <broken>\n\r", s->source );
		else
			cprintf(ch,"#%5d %c%3d [%5d] %-32s (Int %d Freq %d PH %d DS %d)\n\r",
				s->index, IS_SET(s->flags,SPAWN_READY) ? 'R' : 'P',
				s->timer, pMob->vnum, pMob->short_descr, s->interval, s->frequency,
				s->placeholder, s->despawn );
		break;
	case 'o': case 'O':
	case 'e': case 'E':
	case 'i': case 'I':
	case 'p': case 'P':
	case 'c': case 'C':
		if ( (pObj = get_obj_index( s->source )) == NULL )
			cprintf(ch,"[%5d] <broken>\n\r", s->source );
		else
			cprintf(ch,"#%5d %c%3d [%5d] %-32s (Int %d Freq %d PH %d DS %d)\n\r",
				s->index, IS_SET(s->flags,SPAWN_READY) ? 'R' : 'P',
				s->timer, pObj->vnum, pObj->short_descr, s->interval, s->frequency,
				s->placeholder, s->despawn );
		break;	
	default:
		cprintf(ch,"#%5 <unknown spawn>\n\r");
	}
}

void do_dumpspawn( Character *ch, char *argument )
{
	Area *pArea;
	int vnum;
	extern void dump_spawn_tree( FILE *fp, Room *r );
	FILE *fp;
	char dumpfile[MAX_STRING_LENGTH];
	int  i;

	if ( argument == NULL )
	{
		cprintf(ch,"Syntax:  dumpspawn <area#>\n\r");
		return;
	}

    if (!is_number(argument))
    {
        send_to_char("Area vnum must be numeric.\n\r", ch);
        return;
    }

    vnum = atoi(argument);

    for (pArea = area_first; pArea; pArea = pArea->next )
        if (vnum == pArea->vnum)
            break;

    if(!pArea)
    {
        send_to_char("No such area.\n\r", ch);
        return;
    }

	snprintf(dumpfile,sizeof(dumpfile),"%s/%d-spawn.html",
		WEB_DIR, pArea->vnum );

	if ( (fp = fopen(dumpfile,"w")) == NULL )
	{
		cprintf(ch,"Unable to open %s: %s\n\r", dumpfile, strerror(errno) );
		return;
	}

	fprintf(fp,"<html>");
	for( i = pArea->lvnum ; i <= pArea->uvnum ; i++ )
		dump_spawn_tree( fp, get_room_index(i) );

	fprintf(fp,"</html>");
	fclose(fp);
	cprintf(ch,"Done.\n\r");
	return;
}

void dump_spawn_tree( FILE *fp, Room *r )
{
    Spawn *s;
    extern void dumpSpawnContents( FILE *fp, Spawn *spawn, int depth );
	extern void dumpSpawn( FILE *fp, Spawn *s );
	if ( r == NULL )
		return;

    fprintf(fp,"</pre><hr><h1>#%d</h1><h3>%s</h3><br><pre>", r->vnum, r->name );
    for( s = r->spawns ; s != NULL ; s = s->next_in_room )
    {
        dumpSpawn(fp,s);
        dumpSpawnContents( fp, s->contains, 1 );
    }
    return;
}

void dumpSpawn( FILE *fp, Spawn *s )
{
	MobIndex	*pMob;
	ObjIndex	*pObj;
	Quest			*pQuest;
	ScriptIndex		*pScript;

	switch( s->type )
	{
    case 's': case 'S':  
        if ( (pScript = get_script_index( s->source )) == NULL )
            fprintf(fp,"[%5d] <broken>\n", s->source );
        else
        fprintf(fp,"#%5d %c NA [%5d] Script :: %-32s\n",
            s->index, IS_SET(s->flags,SPAWN_READY) ? 'R' : 'P',
            pScript->vnum, pScript->name );
        break; 
	case 'q': case 'Q':
		if ( (pQuest = get_quest_index( s->source )) == NULL )
			fprintf(fp,"[%5d] <broken>\n", s->source );
		else
		fprintf(fp,"#%5d %c NA [%5d] Quest :: %-32s\n",
			s->index, IS_SET(s->flags,SPAWN_READY) ? 'R' : 'P',
			pQuest->vnum, pQuest->name );
		break;
	case 'd': case 'D':
		fprintf(fp,"#%5d %c%3d [%5s] door spawn sets flags (%s)\n",
			s->index, IS_SET(s->flags,SPAWN_READY) ? 'R' : 'P',
			s->timer, dir_name[s->source], flag_string( exit_flags, s->misc ) );
		break;
	case 'm': case 'M':
		if ( (pMob = get_mob_index( s->source )) == NULL )
			fprintf(fp,"[%5d] <broken>\n", s->source );
		else
			fprintf(fp,"#%5d %c%3d [%5d] %-32s (Int %d Freq %d PH %d DS %d)\n",
				s->index, IS_SET(s->flags,SPAWN_READY) ? 'R' : 'P',
				s->timer, pMob->vnum, pMob->short_descr, s->interval, s->frequency,
				s->placeholder, s->despawn );
		break;
	case 'o': case 'O':
	case 'e': case 'E':
	case 'i': case 'I':
	case 'p': case 'P':
	case 'c': case 'C':
		if ( (pObj = get_obj_index( s->source )) == NULL )
			fprintf(fp,"[%5d] <broken>\n", s->source );
		else
			fprintf(fp,"#%5d %c%3d [%5d] %-32s (Int %d Freq %d PH %d DS %d)\n",
				s->index, IS_SET(s->flags,SPAWN_READY) ? 'R' : 'P',
				s->timer, pObj->vnum, pObj->short_descr, s->interval, s->frequency,
				s->placeholder, s->despawn );
		break;	
	default:
		fprintf(fp,"#%5d <unknown spawn>\n",s->index);
	}
}

void dumpSpawnContents( FILE *fp, Spawn *spawn, int depth )
{
    Spawn *s;
    char spaces[40];

    memset(spaces,' ',sizeof(spaces));

    for( s = spawn ; s != NULL ; s = s->next_content )
    {
		fprintf(fp,"%.*s",depth * 4,spaces);
		dumpSpawn(fp,s);
		dumpSpawnContents(fp,s->contains,depth+1);
    }
    return;
}

void do_showspawns( Character *ch, char *argument )
{
	extern void show_spawn_tree( Character *ch, Room *r );
	show_spawn_tree( ch, ch->in_room );
	return;
}
 
void show_spawn_tree( Character *ch, Room *r )
{
    Spawn *s;
	extern void printSpawnContents( Character *ch, Spawn *spawn, int depth );

    cprintf(ch," == Spawn Data for %d %s ==\n", r->vnum, r->name );
    for( s = r->spawns ; s != NULL ; s = s->next_in_room )
    {
		printSpawn(ch,s);
		printSpawnContents( ch, s->contains, 1 );
    }
    return;
}

void printSpawnContents( Character *ch, Spawn *spawn, int depth )
{
    Spawn *s;
    char spaces[40];

    memset(spaces,' ',sizeof(spaces));

    for( s = spawn ; s != NULL ; s = s->next_content )
    {
		cprintf(ch,"%.*s",depth * 4,spaces);
		printSpawn(ch,s);
		printSpawnContents(ch,s->contains,depth+1);
    }
    return;
}

void reset_spawn_contents( Spawn *spawn, bool fForce )
{
	Spawn *s;

	for( s = spawn ; s != NULL ; s = s->next_content )
	{
		s->timer = 1;
		SET_BIT(s->flags,SPAWN_READY);
		if ( fForce )
			SET_BIT(s->flags,SPAWN_FORCE);
		reset_spawn_contents(s->contains,fForce);
	}
	return;
}

void reset_spawn_tree( Room *r, bool fForce )
{
	Spawn *s;

	for( s = r->spawns ; s != NULL ; s = s->next_in_room )
	{
		s->timer = 1;
		SET_BIT(s->flags,SPAWN_READY);
		if ( fForce )
			SET_BIT(s->flags,SPAWN_FORCE);

		reset_spawn_contents( s->contains, fForce );
	}
	return;
}

void do_reset_room( Character *ch, char *argument )
{
	if ( *argument && tolower(*argument) == 'f' )
	{
		cprintf(ch,"Forcing all respawns.\n");
		reset_spawn_tree( ch->in_room, TRUE );
	}
	else
		reset_spawn_tree( ch->in_room, FALSE ); 

	cprintf(ch,"Done.\n");
}
