/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include <sys/types.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "thoc.h"
#include "olc.h"
#include "tables.h"
#include "lookup.h"
#include "recycle.h"

int mapArmorSlot( int );
void check_twohandedness( ObjIndex *obj );
void check_ranged_weapon( ObjIndex *obj );
void copyObjIndex( ObjIndex *new, ObjIndex *orig );

OEDIT( oedit_show )
{
    ObjIndex *pObj;
    char buf[MAX_STRING_LENGTH];
    Affect *paf;
    int cnt;

    EDIT_OBJ(ch, pObj);

    sprintf( buf, "Name:        [%s]\n\rArea:        [%5d] %s\n\r",
	pObj->name,
	!pObj->area ? -1        : pObj->area->vnum,
	!pObj->area ? "No Area" : pObj->area->name );
    send_to_char( buf, ch );


    cprintf( ch, "Vnum:        [%5d]\n\rType:        [%s]\n\r",
	pObj->vnum, flag_string( type_flags, pObj->item_type ) );

    sprintf( buf, "Level:       [%5d]\n\r", pObj->level );
    send_to_char( buf, ch );

    sprintf( buf, "Wear flags:  [%s]\n\r",
	flag_string( wear_flags, pObj->wear_flags ) );
    send_to_char( buf, ch );

    sprintf( buf, "Extra flags: [%s]\n\r",
	flag_string( extra_flags, pObj->extra_flags ) );
    send_to_char( buf, ch );

    sprintf( buf, "Material:    [%s]\n\r",                /* ROM */
	pObj->material );
    send_to_char( buf, ch );

    cprintf( ch, "Condition:   [%3d]\n\r",  pObj->condition );
	cprintf( ch, "Durability:  [%3d]\n\r",	pObj->durability );
	cprintf( ch, "Quality:     [%3d]\n\r",  pObj->quality );

	cprintf( ch, "Deity:       [%s]\n\r",	pObj->deity <= 0 ? "none" : deity_table[pObj->deity].name );

    sprintf( buf, "Weight:      [%d.%d stones]\n\rCost:        [%s]\n\r",
	pObj->weight/10,pObj->weight%10, money_breakdown(pObj->cost) );
    send_to_char( buf, ch );

    if ( pObj->extra_descr )
    {
	ExtraDescr *ed;

	send_to_char( "Ex desc kwd: ", ch );

	for ( ed = pObj->extra_descr; ed; ed = ed->next )
	{
	    send_to_char( "[", ch );
	    send_to_char( ed->keyword, ch );
	    send_to_char( "]", ch );
	}

	send_to_char( "\n\r", ch );
    }

    sprintf( buf, "Short desc:  %s\n\rLong desc:\n\r     %s\n\r",
	pObj->short_descr, pObj->description );
    send_to_char( buf, ch );

    for ( cnt = 0, paf = pObj->affected; paf; paf = paf->next )
    {
	if ( cnt == 0 )
	{
	    send_to_char( "Number Modifier Affects\n\r", ch );
	    send_to_char( "------ -------- -------\n\r", ch );
	}
	sprintf( buf, "[%4d] %-8d %s\n\r", cnt,
	    paf->modifier,
	    affect_loc_name( paf->location, paf->misc  ) );
	send_to_char( buf, ch );
	cnt++;
    }

    show_obj_values( ch, pObj );

    return FALSE;
}


/*
 * Need to issue warning if flag isn't valid. -- does so now -- Hugin.
 */
OEDIT( oedit_addaffect )
{
    int value;
    ObjIndex *pObj;
    Affect *pAf;
    char loc[MAX_STRING_LENGTH];
    char mod[MAX_STRING_LENGTH];
	int	misc = 0;

    EDIT_OBJ(ch, pObj);

    argument = one_argument( argument, loc );
    one_argument( argument, mod );

    if ( loc[0] == '\0' || mod[0] == '\0' || !is_number( mod ) )
    {
		send_to_char( "Syntax:  addaffect [location] [#mod]\n\r", ch );
		return FALSE;
    }

    if ( ( value = flag_value( apply_flags, loc ) ) == NO_FLAG ) /* Hugin */
    {
		/* Might be a skill */
		if ( (misc = skill_lookup( loc )) <= 0 )
		{
        	send_to_char( "Valid affects are:\n\r", ch );
			show_help( ch, "? apply" );
			return FALSE;
		}
    }

    pAf             =   new_affect();
    pAf->location   =   (misc > 0) ? APPLY_SKILL : value;
    pAf->modifier   =   atoi( mod );
    pAf->type       =   -1;
    pAf->duration   =   -1;
    pAf->bitvector  =   0;
	pAf->misc		= 	misc;
    pAf->next       =   pObj->affected;
    pObj->affected  =   pAf;

	cprintf(ch,"Affect added: %d to %s.\n\r",
		pAf->modifier, affect_loc_name( pAf->location, misc ) );
    return TRUE;
}



/*
 * My thanks to Hans Hvidsten Birkeland and Noam Krendel(Walker)
 * for really teaching me how to manipulate pointers.
 */
OEDIT( oedit_delaffect )
{
    ObjIndex *pObj;
    Affect *pAf;
    Affect *pAf_next;
    char affect[MAX_STRING_LENGTH];
    int  value;
    int  cnt = 0;

    EDIT_OBJ(ch, pObj);

    one_argument( argument, affect );

    if ( !is_number( affect ) || affect[0] == '\0' )
    {
	send_to_char( "Syntax:  delaffect [#affect]\n\r", ch );
	return FALSE;
    }

    value = atoi( affect );

    if ( value < 0 )
    {
	send_to_char( "Only non-negative affect-numbers allowed.\n\r", ch );
	return FALSE;
    }

    if ( !( pAf = pObj->affected ) )
    {
	send_to_char( "OEdit:  Non-existant affect.\n\r", ch );
	return FALSE;
    }

    if( value == 0 )	/* First case: Remove first affect */
    {
	pAf = pObj->affected;
	pObj->affected = pAf->next;
	free_affect( pAf );
    }
    else		/* Affect to remove is not the first */
    {
	while ( ( pAf_next = pAf->next ) && ( ++cnt < value ) )
	     pAf = pAf_next;

	if( pAf_next )		/* See if it's the next affect */
	{
	    pAf->next = pAf_next->next;
	    free_affect( pAf_next );
	}
	else                                 /* Doesn't exist */
	{
	     send_to_char( "No such affect.\n\r", ch );
	     return FALSE;
	}
    }

    send_to_char( "Affect removed.\n\r", ch);
    return TRUE;
}



OEDIT( oedit_name )
{
    ObjIndex *pObj;

    EDIT_OBJ(ch, pObj);

    if ( argument[0] == '\0' )
    {
	send_to_char( "Syntax:  name [string]\n\r", ch );
	return FALSE;
    }

    free_string( pObj->name );
    pObj->name = str_dup( argument );

    send_to_char( "Name set.\n\r", ch);
    return TRUE;
}



OEDIT( oedit_short )
{
    ObjIndex *pObj;

    EDIT_OBJ(ch, pObj);

    if ( argument[0] == '\0' )
    {
	send_to_char( "Syntax:  short [string]\n\r", ch );
	return FALSE;
    }

    free_string( pObj->short_descr );
    pObj->short_descr = str_dup( argument );
    pObj->short_descr[0] = LOWER( pObj->short_descr[0] );

    send_to_char( "Short description set.\n\r", ch);
    return TRUE;
}



OEDIT( oedit_long )
{
    ObjIndex *pObj;

    EDIT_OBJ(ch, pObj);

    if ( argument[0] == '\0' )
    {
	send_to_char( "Syntax:  long [string]\n\r", ch );
	return FALSE;
    }
        
    free_string( pObj->description );
    pObj->description = str_dup( argument );
    pObj->description[0] = UPPER( pObj->description[0] );

    send_to_char( "Long description set.\n\r", ch);
    return TRUE;
}



bool set_value( Character *ch, ObjIndex *pObj, char *argument, int value )
{
    if ( argument[0] == '\0' )
    {
	set_obj_values( ch, pObj, -1, "" );     /* '\0' changed to "" -- Hugin */
	return FALSE;
    }

    if ( set_obj_values( ch, pObj, value, argument ) )
	return TRUE;

    return FALSE;
}



/*****************************************************************************
 Name:		oedit_values
 Purpose:	Finds the object and sets its value.
 Called by:	The four valueX functions below. (now five -- Hugin )
 ****************************************************************************/
bool oedit_values( Character *ch, char *argument, int value )
{
    ObjIndex *pObj;

    EDIT_OBJ(ch, pObj);

    if ( set_value( ch, pObj, argument, value ) )
        return TRUE;

    return FALSE;
}


OEDIT( oedit_value0 )
{
    if ( oedit_values( ch, argument, 0 ) )
        return TRUE;

    return FALSE;
}



OEDIT( oedit_value1 )
{
    if ( oedit_values( ch, argument, 1 ) )
        return TRUE;

    return FALSE;
}



OEDIT( oedit_value2 )
{
    if ( oedit_values( ch, argument, 2 ) )
        return TRUE;

    return FALSE;
}



OEDIT( oedit_value3 )
{
    if ( oedit_values( ch, argument, 3 ) )
        return TRUE;

    return FALSE;
}



OEDIT( oedit_value4 )
{
    if ( oedit_values( ch, argument, 4 ) )
        return TRUE;

    return FALSE;
}

OEDIT( oedit_value5 )
{
    if ( oedit_values( ch, argument, 5 ) )
	return TRUE;

    return FALSE;
}

OEDIT( oedit_value6 )
{
    if ( oedit_values( ch, argument, 6 ) )
        return TRUE;

    return FALSE;
}
OEDIT( oedit_value7 )
{
    if ( oedit_values( ch, argument, 7 ) )
        return TRUE;

    return FALSE;
}
OEDIT( oedit_value8 )
{
    if ( oedit_values( ch, argument, 8 ) )
        return TRUE;

    return FALSE;
}
OEDIT( oedit_value9 )
{
    if ( oedit_values( ch, argument, 9 ) )
        return TRUE;

    return FALSE;
}

/*
OEDIT( oedit_timer )
{
    ObjIndex *pObj;

    EDIT_OBJ(ch, pObj);

    if ( argument[0] == '\0' || !is_number( argument ) )
    {
        send_to_char( "Syntax:  timer [number]\n\r", ch );
        return FALSE;
    }

    pObj->timer = atoi( argument );

    send_to_char( "Timer set.\n\r", ch);
    return TRUE;
}
*/

OEDIT( oedit_weight )
{
    ObjIndex *pObj;

    EDIT_OBJ(ch, pObj);

    if ( argument[0] == '\0' || !is_number( argument ) )
    {
	send_to_char( "Syntax:  weight [number]\n\r", ch );
	return FALSE;
    }

    pObj->weight = atoi( argument );

    send_to_char( "Weight set.\n\r", ch);
    return TRUE;
}



OEDIT( oedit_cost )
{
    ObjIndex *pObj;

    EDIT_OBJ(ch, pObj);

    if ( argument[0] == '\0' || !is_number( argument ) )
    {
	send_to_char( "Syntax:  cost [number]\n\r", ch );
	return FALSE;
    }

    pObj->cost = atoi( argument );

    send_to_char( "Cost set.\n\r", ch);
    return TRUE;
}



OEDIT( oedit_create )
{
    ObjIndex *pObj, *copy_source;
    Area *pArea;
    int  value;
    int  iHash;
	char	arg[MAX_INPUT_LENGTH];

	argument = one_argument( argument, arg );
    value = atoi( arg );
    if ( arg[0] == '\0' || value == 0 )
    {
		send_to_char( "Syntax:  oedit create [vnum]\n\r", ch );
		return FALSE;
    }

    pArea = get_vnum_area( value );
    if ( !pArea )
    {
		send_to_char( "OEdit:  That vnum is not assigned an area.\n\r", ch );
		return FALSE;
    }

    if ( !IS_BUILDER( ch, pArea ) )
    {
		send_to_char( "OEdit:  Vnum in an area you cannot build in.\n\r", ch );
		return FALSE;
    }

    if ( get_obj_index( value ) )
    {
		send_to_char( "OEdit:  Object vnum already exists.\n\r", ch );
		return FALSE;
    }
        
    pObj			= new_obj_index();
    pObj->vnum			= value;
    pObj->area			= pArea;
        
    if ( value > top_vnum_obj )
		top_vnum_obj = value;

    iHash			= value % MAX_KEY_HASH;
    pObj->next			= obj_index_hash[iHash];
    obj_index_hash[iHash]	= pObj;
    ch->desc->pEdit		= (void *)pObj;

	pObj->condition = 100;
	pObj->durability = 90;
	pObj->quality = 85;

    send_to_char( "Object Created.\n\r", ch );

    /* Copy? */
    argument = one_argument( argument, arg );
	if ( *argument == NULL )
		return TRUE;

    if ( str_cmp(arg,"from") )
    {
        cprintf(ch,"Invalid copy syntax.  Ignoring.\n\r");
        return TRUE;
    }

    value = atoi( argument );
    if ( value <= 0 )
    {
        cprintf(ch,"Malformed copy, ignoring.\n\r");
        return TRUE;     
    }

    if ( (copy_source = get_obj_index( value )) == NULL )
    {
        cprintf(ch,"No such OBJ with vnum %d, copy ignored.\n\r", value );
        return TRUE;
    }

    copyObjIndex( pObj, copy_source );
    cprintf(ch,"OBJ %d (%s) copied to %d.\n\r",
        value, copy_source->short_descr, pObj->vnum );
    return TRUE; 
}

OEDIT( oedit_copy )
{
    ObjIndex *pObj, *copy_source;
    int value;     

    EDIT_OBJ( ch, pObj );

    if ( *argument == '\0' )
    {
        cprintf(ch,"Syntax:  copy <obj vnum to copy>\n\r");
        return TRUE;
    }

    value = atoi( argument );
    if ( value <= 0 )
    {
        cprintf(ch,"The obj vnum you want to copy from has to be a positive integer.\n\r");
        return TRUE;
    }

    if ( (copy_source = get_obj_index( value )) == NULL )
    {
        cprintf(ch,"No such OBJ with vnum %d.\n\r", value );
        return TRUE;
    }

    copyObjIndex( pObj, copy_source );
    cprintf(ch,"OBJ %d (%s) copied to %d.\n\r",
        value, copy_source->short_descr, pObj->vnum );
    return TRUE;
}

OEDIT( oedit_ed )
{
    ObjIndex *pObj;
    ExtraDescr *ed;
    char command[MAX_INPUT_LENGTH];
    char keyword[MAX_INPUT_LENGTH];

    EDIT_OBJ(ch, pObj);

    argument = one_argument( argument, command );
    one_argument( argument, keyword );

    if ( command[0] == '\0' )
    {
	send_to_char( "Syntax:  ed add [keyword]\n\r", ch );
	send_to_char( "         ed delete [keyword]\n\r", ch );
	send_to_char( "         ed edit [keyword]\n\r", ch );
	send_to_char( "         ed format [keyword]\n\r", ch );
	return FALSE;
    }

    if ( !str_cmp( command, "add" ) )
    {
	if ( keyword[0] == '\0' )
	{
	    send_to_char( "Syntax:  ed add [keyword]\n\r", ch );
	    return FALSE;
	}

	ed                  =   new_extra_descr();
	ed->keyword         =   str_dup( keyword );
	ed->next            =   pObj->extra_descr;
	pObj->extra_descr   =   ed;

	string_append( ch, &ed->description );

	return TRUE;
    }

    if ( !str_cmp( command, "edit" ) )
    {
	if ( keyword[0] == '\0' )
	{
	    send_to_char( "Syntax:  ed edit [keyword]\n\r", ch );
	    return FALSE;
	}

	for ( ed = pObj->extra_descr; ed; ed = ed->next )
	{
	    if ( is_name( keyword, ed->keyword ) )
		break;
	}

	if ( !ed )
	{
	    send_to_char( "OEdit:  Extra description keyword not found.\n\r", ch );
	    return FALSE;
	}

	string_append( ch, &ed->description );

	return TRUE;
    }

    if ( !str_cmp( command, "delete" ) )
    {
	ExtraDescr *ped = NULL;

	if ( keyword[0] == '\0' )
	{
	    send_to_char( "Syntax:  ed delete [keyword]\n\r", ch );
	    return FALSE;
	}

	for ( ed = pObj->extra_descr; ed; ed = ed->next )
	{
	    if ( is_name( keyword, ed->keyword ) )
		break;
	    ped = ed;
	}

	if ( !ed )
	{
	    send_to_char( "OEdit:  Extra description keyword not found.\n\r", ch );
	    return FALSE;
	}

	if ( !ped )
	    pObj->extra_descr = ed->next;
	else
	    ped->next = ed->next;

	free_extra_descr( ed );

	send_to_char( "Extra description deleted.\n\r", ch );
	return TRUE;
    }


    if ( !str_cmp( command, "format" ) )
    {
	ExtraDescr *ped = NULL;

	if ( keyword[0] == '\0' )
	{
	    send_to_char( "Syntax:  ed format [keyword]\n\r", ch );
	    return FALSE;
	}

	for ( ed = pObj->extra_descr; ed; ed = ed->next )
	{
	    if ( is_name( keyword, ed->keyword ) )
		break;
	    ped = ed;
	}

	if ( !ed )
	{
                send_to_char( "OEdit:  Extra description keyword not found.\n\r", ch );
                return FALSE;
	}

	ed->description = format_string( ed->description );

	send_to_char( "Extra description formatted.\n\r", ch );
	return TRUE;
    }

    oedit_ed( ch, "" );
    return FALSE;
}





/* ROM object functions : */

OEDIT( oedit_extra )      /* Moved out of oedit() due to naming conflicts -- Hugin */
{
    ObjIndex *pObj;
    int value;

    if ( argument[0] != '\0' )
    {
	EDIT_OBJ(ch, pObj);

	if ( ( value = flag_value( extra_flags, argument ) ) != NO_FLAG )
	{
	    TOGGLE_BIT(pObj->extra_flags, value);

	    send_to_char( "Extra flag toggled.\n\r", ch);
	    return TRUE;
	}
    }

    send_to_char( "Syntax:  extra [flag]\n\r"
		  "Type '? extra' for a list of flags.\n\r", ch );
    return FALSE;
}


OEDIT( oedit_wear )      /* Moved out of oedit() due to naming conflicts -- Hugin */
{
    ObjIndex *pObj;
    int value;

     if ( argument[0] != '\0' )
    {
	EDIT_OBJ(ch, pObj);

	if ( ( value = flag_value( wear_flags, argument ) ) != NO_FLAG )
	{
	    TOGGLE_BIT(pObj->wear_flags, value);

	    send_to_char( "Wear flag toggled.\n\r", ch);
	    return TRUE;
	}
    }

    send_to_char( "Syntax:  wear [flag]\n\r"
		  "Type '? wear' for a list of flags.\n\r", ch );
    return FALSE;
}


OEDIT( oedit_type )      /* Moved out of oedit() due to naming conflicts -- Hugin */
{
    ObjIndex *pObj;
    int value;

    if ( argument[0] != '\0' )
    {
	EDIT_OBJ(ch, pObj);

	if ( ( value = flag_value( type_flags, argument ) ) != NO_FLAG )
	{
	    pObj->item_type = value;

	    send_to_char( "Type set.\n\r", ch);

	    /*
	     * Clear the values.
	     */
	    pObj->value[0] = 0;
	    pObj->value[1] = 0;
	    pObj->value[2] = 0;
	    pObj->value[3] = 0;
	    pObj->value[4] = 0;     /* ROM */
		pObj->value[5] = 0;
		pObj->value[6] = 0;
		pObj->value[7] = 0;
		pObj->value[8] = 0;
		pObj->value[9] = 0;

	    return TRUE;
	}
    }

    send_to_char( "Syntax:  type [flag]\n\r"
		  "Type '? type' for a list of flags.\n\r", ch );
    return FALSE;
}



OEDIT( oedit_material )
{
    ObjIndex *pObj;
    int value;

    if ( argument[0] != '\0' )
    {
	EDIT_OBJ(ch, pObj);

	if ( ( value = flag_value( material_type, argument ) ) != NO_FLAG )
	{
	    pObj->material = str_dup( flag_string(material_type,value) );
	    send_to_char( "Material type set.\n\r", ch);
	    return TRUE;
	}
    }

    send_to_char( "Syntax:  material [material-name]\n\r"
		  "Type '? material' for a list of materials.\n\r", ch );
    return FALSE;
}



OEDIT( oedit_level )
{
    ObjIndex *pObj;

    EDIT_OBJ(ch, pObj);

    if ( argument[0] == '\0' || !is_number( argument ) )
    {
	send_to_char( "Syntax:  level [number]\n\r", ch );
	return FALSE;
    }

    pObj->level = atoi( argument );

    send_to_char( "Level set.\n\r", ch);
    return TRUE;
}


OEDIT( oedit_durability )
{
    ObjIndex *pObj;
    int value;

    if ( argument[0] != '\0'
    && ( value = atoi (argument ) ) >= 0
    && ( value <= 100 ) )
    {
	EDIT_OBJ( ch, pObj );

	pObj->durability = value;
	send_to_char( "Durability set.\n\r", ch );

	return TRUE;
    }

    send_to_char( "Syntax:  durability [number]\n\r"
		  "Where number can range from 0 (ruined) to 100 (perfect).\n\r",
		  ch );
    return FALSE;
}

OEDIT( oedit_quality )
{
    ObjIndex *pObj;
    int value;

    if ( argument[0] != '\0'
    && ( value = atoi (argument ) ) >= 0
    && ( value <= 100 ) )
    {
	EDIT_OBJ( ch, pObj );

	pObj->quality = value;
	send_to_char( "Quality set.\n\r", ch );

	return TRUE;
    }

    send_to_char( "Syntax:  quality [number]\n\r"
		  "Where number can range from 0 (ruined) to 100 (perfect).\n\r",
		  ch );
    return FALSE;
}

OEDIT( oedit_deity )
{
    ObjIndex *pObj;

    if ( argument[0] != '\0' )
    {
		EDIT_OBJ( ch, pObj );

		if ( !str_cmp(argument,"none") )
		{
			pObj->deity = 0;
			cprintf(ch,"Deity set to none.\n\r");
			return TRUE;
		}

		if ( deity_lookup( argument ) <= 0 )
		{
			cprintf(ch,"No such deity.\n\r");
			return FALSE;
		}

		pObj->deity = deity_lookup( argument );
		cprintf( ch, "Deity set to %s.\n\r", deity_table[pObj->deity].name );
		return TRUE;
    }

    send_to_char( "Syntax:  deity <deity_name>\n\r", ch );
    return FALSE;
}

OEDIT( oedit_condition )
{
    ObjIndex *pObj;
    int value;

    if ( argument[0] != '\0'
    && ( value = atoi (argument ) ) >= 0
    && ( value <= 100 ) )
    {
	EDIT_OBJ( ch, pObj );

	pObj->condition = value;
	send_to_char( "Condition set.\n\r", ch );

	return TRUE;
    }

    send_to_char( "Syntax:  condition [number]\n\r"
		  "Where number can range from 0 (ruined) to 100 (perfect).\n\r",
		  ch );
    return FALSE;
}


bool set_obj_values( Character *ch, ObjIndex *pObj, int value_num, char *argument)
{
    switch( pObj->item_type )
    {
        default:
        cprintf(ch,"This item has no value slots in use.\n\r");
            break;
  
    case ITEM_SHRINE:
        cprintf(ch,"Just set the deity like normal for a shrine.\n\r");
        return TRUE;    
 
	case ITEM_PORTAL:
	    switch( value_num )
	    {
	    case 0:	
			pObj->value[0] = atoi ( argument );
			cprintf(ch,"Total number of uses set to");
            if ( pObj->value[0] == 0 )
                cprintf(ch," infinite.\n\r");
            else
                cprintf(ch," %d.\n\r", pObj->value[0] );
			break;
	    case 1:	
			if ( flag_value( exit_flags, argument) < 0 )
			{
			    cprintf(ch,"No such exit flag.\n\r");	
			    return FALSE;
			}
			TOGGLE_BIT(pObj->value[1],flag_value( exit_flags, argument ) );
			cprintf(ch,"Exit flags now set to: %s.\n\r", flag_string(exit_flags, pObj->value[1]));
			break;
	    case 2:
            if ( flag_value( portal_flags, argument) < 0 )
            {
                cprintf(ch,"No such gate/portal flag.\n\r");
                return FALSE;
            }
            TOGGLE_BIT(pObj->value[2],flag_value( portal_flags, argument ) );
            cprintf(ch,"Portal flags now set to: %s.\n\r", flag_string(portal_flags,pObj->value[2]));
            break;
	    case 3: {
            Room *room;
			room = get_room_index( pObj->value[3] = atoi( argument ) );
			cprintf(ch,"Destination vnum set to %d (%s).\n\r",
                pObj->value[3], room ? room->name : "room does not exist");
			break;
            }
	    }
	break;

	case ITEM_FURNITURE:
	    switch( value_num )
	    {
	    case 0:
		    pObj->value[0]	= atoi(argument);
		    cprintf(ch,"Maximum simultaneous users set to %d.\n\r", pObj->value[0]);
		    break;
	    case 1:
		    pObj->value[1]	= atoi(argument);
		    cprintf(ch,"Maximum allowed weight set to %d.\n\r", pObj->value[1]);
		    break;
	    case 2:
            if ( flag_value( furniture_flags, argument) < 0 )
            {
                cprintf(ch,"No such furniture flag.\n\r");
                return FALSE;
            }
            TOGGLE_BIT(pObj->value[2],flag_value( furniture_flags, argument ) );
            cprintf(ch,"Furniture flags are now: %s.\n\r",
                                                flag_string(furniture_flags,pObj->value[2]));
            break;
 	    case 3:
		    pObj->value[3] = atoi(argument);
		    cprintf(ch,"Hit point regen rate set to %d%%.\n\r", pObj->value[3]);
		    break;
	    case 4:
		    pObj->value[4] = atoi(argument);
		    cprintf(ch,"Mana regen rate set to %d%%.\n\r", pObj->value[4]);
		    break;
        case 5:
            pObj->value[5] = atoi(argument);
            cprintf(ch,"Stamina regen rate set to %d%%.\n\r", pObj->value[5]);
            break;
	    }
	    break;

	case ITEM_FORGE:
	    switch( value_num )
	    {
	    case 0:
			pObj->value[0] = atoi( argument );
			cprintf(ch,"Players have a %+d %s to craft using this forge.\n\r",
                pObj->value[0], pObj->value[0] < 0 ? "penalty" : "bonus");
			break;
	    case 1:
			pObj->value[1] = atoi( argument );
			if ( pObj->value[1] < 0 )
		    	cprintf(ch,"Item has infinite uses.\n\r");
			else
		    	cprintf(ch,"Item is exhausted after %d uses.\n\r",atoi(argument));
			break;
	    case 2:
	    {
			int sn;

			if ( !str_cmp(argument,"clear") )
			{
				cprintf(ch,"Skill erased.\n\r");
				pObj->value[2] = 0;
				return TRUE;
			}

			if ( ( sn=skill_lookup( argument ) ) < 1 )
			{
		    	cprintf(ch,"No such skill '%s'.\n\r",argument);
		    	return FALSE;
			}
	
			pObj->value[2] = sn;
			cprintf(ch,"This forge can be used for %s recipes.\n\r",skill_table[sn].name);
			break;
	    }

		case 4: // Foundation skills allowed
		{
			int value;

			if ( ( value = flag_value( foundation_flags, argument ) ) != NO_FLAG )
        	{

            	pObj->value[4] ^= value;
            	cprintf(ch,"Foundation skills set to: %s\n\r",
                	flag_string( foundation_flags, pObj->value[4] ) );
            	return TRUE;
        	}

 		}
		}
	    break;

	case ITEM_FOUNTAIN:
	    switch( value_num )
	    {
	    case 0:
            pObj->value[0] = atoi ( argument );
		 	cprintf(ch,"Max fill set to %d.\n\r",pObj->value[0]);
			break;
	    case 1: 
			pObj->value[1] = atoi ( argument );
			cprintf(ch,"Current fill set to %d.\n\r",pObj->value[1]);
			break;
	    case 2: 
	    {
		int liq;

		if ( (liq = liq_lookup(argument) ) < 0 )
		{
		    cprintf(ch,"No such liquid '%s'.\n\r",argument);
		    return FALSE;
		}

		pObj->value[2] = liq;
		cprintf(ch,"Liquid contents set to '%s'.\n\r",liq_table[liq].liq_name);	
		break;
	    }

	    case 3:
		pObj->value[3] = atoi ( argument );
	   	cprintf(ch,"Contents are %spoisoned.\n\r",pObj->value[3] ? "" : "NOT " );
		break;
	    }
  	break;	

	case ITEM_LYRIC_SHEET:
	{
		int sn;
		SpellIndex* pSpellIndex;

        switch( value_num ) 
        {   
        case 0:
        	if ( (sn = spell_lookup( argument, -1 )) < 0 )
        	{
            	cprintf(ch,"No such spell.\n\r");
            	return FALSE;
        	}   
           
        	pObj->value[0] = sn;
        	
			pSpellIndex = get_spell_index(sn);	
			cprintf(ch,"Sheet music will contain the '%s' spell.\n\r", 
				pSpellIndex ? pSpellIndex->full_name : "(null)");
        	return TRUE;
		default:
			return FALSE;
		}
	}
	case ITEM_ARCANE_SCROLL:
	{
		int sn;
		SpellIndex* pSpellIndex;

        switch( value_num ) 
        {   
        case 0:
        	if ( (sn = spell_lookup( argument, ARCANE )) < 0 )
        	{
            	cprintf(ch,"No such arcane spell.\n\r");
            	return FALSE;
        	}   
            
        	pObj->value[0] = sn;

			pSpellIndex = get_spell_index(sn);
        	cprintf(ch,"Arcane scroll will contain the '%s' spell.\n\r",
				pSpellIndex ? pSpellIndex->full_name : "(null)" );
        	return TRUE;
		case 1:
			pObj->value[1] = atoi(argument);
			cprintf(ch,"No-copy bit set to %d.\n\r", pObj->value[1] );
			return TRUE;
		case 2:
			pObj->value[2] = atoi(argument);
			cprintf(ch,"Copying difficulty set to %d.\n\r", pObj->value[2] );
			return TRUE;
		default:
			return FALSE;
		}
	}

  	case ITEM_PRAYER_BOOK:
	{
	    int sn;
		SpellIndex* pSpellIndex;

	    switch( value_num )
	    {
	    case 0: 
		if ( (sn = spell_lookup( argument, 1 )) < 0 )
		{
		    cprintf(ch,"No such divine spell.\n\r");
		    return FALSE;
		}

		pObj->value[0] = sn;

		pSpellIndex = get_spell_index(sn);
		cprintf(ch,"Prayer book will contain the '%s' spell.\n\r",
			pSpellIndex ? pSpellIndex->full_name : "(null)" );
		return TRUE;
	    case 1:
		if ( !is_number(argument) )
		{
		    cprintf(ch,"Experience value must be numeric.\n\r");
		    return FALSE;
		}

		pObj->value[1] = atoi(argument);
		cprintf(ch,"BOOK YIELDS %d EXPERIENCE WHEN READ.\n\r",pObj->value[1]);
		return TRUE;

	   }
 	}

	case ITEM_SPELLBOOK:
	{
	    int sn;

	    if ( is_number(argument) && atoi(argument) == 0 )
	    {
			pObj->value[value_num] = 0;
			cprintf(ch,"SPELL SLOT %d CLEARED.\n\r",value_num);
			return FALSE;
	    }
	
		/* 1 = divine, 0 = arcane, -1 = any */
	    if ( (sn = spell_lookup(argument,0) ) < 0 )
	    {
			cprintf(ch,"That is not a valid spell.\n\r");
			return FALSE;
	    }
	    else
		{
			SpellIndex* pSpellIndex;

			if( (pSpellIndex = get_spell_index(sn) ) != NULL )
			{
				if ( !IS_SET(pSpellIndex->flags,COM_ARCANE) )
				{
					cprintf(ch,"Only ARCANE spells may be placed in spellbooks.\n\r");
					return FALSE;
				}

				pObj->value[value_num] = sn;
				cprintf(ch,"VALUE %d SET TO SPELL '%s'.\n\r",value_num,pSpellIndex->full_name);
			}
			else
			{
				log_bug("set_obj_values(item_spellbook): Spell index not found(%d)",sn);
				return FALSE;
			}
		}

		return TRUE;
	}

        case ITEM_LIGHT:
	    switch ( value_num )
	    {
	        default:
		    do_help( ch, "ITEM_LIGHT" );
	            return FALSE;
	        case 2:
                pObj->value[2] = atoi( argument );
	            cprintf(ch,"Hours of light set to %d.\n\r\n\r",pObj->value[2]);
	            break;
	    }
            break;

        case ITEM_WAND:
        case ITEM_STAFF:
	    switch ( value_num )
	    {
	        default:
		    do_help( ch, "ITEM_STAFF_WAND" );
	            return FALSE;
	        case 0:
	            send_to_char( "SPELL LEVEL SET.\n\r\n\r", ch );
	            pObj->value[0] = atoi( argument );
	            break;
	        case 1:
	            send_to_char( "TOTAL NUMBER OF CHARGES SET.\n\r\n\r", ch );
	            pObj->value[1] = atoi( argument );
	            break;
	        case 2:
	            send_to_char( "CURRENT NUMBER OF CHARGES SET.\n\r\n\r", ch );
	            pObj->value[2] = atoi( argument );
	            break;
	        case 3:
	            send_to_char( "SPELL TYPE SET.\n\r", ch );
	            pObj->value[3] = skill_lookup( argument );
	            break;
	    }
            break;

        case ITEM_SCROLL:
        case ITEM_POTION:
        case ITEM_PILL:
	    switch ( value_num )
	    {
	        default:
		    do_help( ch, "ITEM_SCROLL_POTION_PILL" );
	            return FALSE;
	        case 0:
	            send_to_char( "SPELL LEVEL SET.\n\r\n\r", ch );
	            pObj->value[0] = atoi( argument );
	            break;
	        case 1:
	            send_to_char( "SPELL TYPE 1 SET.\n\r\n\r", ch );
	            pObj->value[1] = skill_lookup( argument );
	            break;
	        case 2:
	            send_to_char( "SPELL TYPE 2 SET.\n\r\n\r", ch );
	            pObj->value[2] = skill_lookup( argument );
	            break;
	        case 3:
	            send_to_char( "SPELL TYPE 3 SET.\n\r\n\r", ch );
	            pObj->value[3] = skill_lookup( argument );
	            break;
 	    }
	    break;

        case ITEM_ARMOR:
	    switch ( value_num )
	    {
	        default:
		    	do_help( ch, "ITEM_ARMOR" );
		    	return FALSE;
	        case 0:
		    	send_to_char( "AC PIERCE SET.\n\r\n\r", ch );
		    	pObj->value[0] = atoi( argument );
		    	break;
	        case 1:
		    	send_to_char( "AC BASH SET.\n\r\n\r", ch );
		    	pObj->value[1] = atoi( argument );
		    	break;
	        case 2:
		    	send_to_char( "AC SLASH SET.\n\r\n\r", ch );
		    	pObj->value[2] = atoi( argument );
		    	break;
	        case 3:
		    	send_to_char( "AC EXOTIC SET.\n\r\n\r", ch );
		    	pObj->value[3] = atoi( argument );
		    	break;
		case 4:
		    	cprintf( ch, "BULK FACTOR SET TO %d.\n\r\n\r", atoi(argument) );
		    	pObj->value[4] = atoi( argument );
		    	break;
		case 5:
		    	if ( !str_cmp(argument,"none") )
		    	{
					cprintf(ch,"ARMOR TYPE SET TO Non-armor.\n\r\n\r");
					pObj->value[0] = pObj->value[1] = pObj->value[2] = pObj->value[3] = pObj->level / 2;
					pObj->value[3] /= 4;
					pObj->value[5] = 0;
					break;
		    	}
		    	else if ( !str_prefix(argument,"cloth") )
                {
                    cprintf(ch,"ARMOR TYPE SET TO Cloth.\n\r\n\r");
             		pObj->value[0] = pObj->value[1] = pObj->value[2] = pObj->value[3] = pObj->level / 2;           
					pObj->value[3] /= 4;
					pObj->value[5] = mapArmorSlot( gpn_cloth_armor );
                    break;
                }
                else if ( !str_prefix(argument,"leather") )
                {
                    cprintf(ch,"ARMOR TYPE SET TO Leather.\n\r\n\r");
                    pObj->value[0] = pObj->value[1] = pObj->value[2] = pObj->value[3] = pObj->level / 2; 
					pObj->value[3] /= 4;
					pObj->value[5] =  mapArmorSlot( gpn_leather_armor );
                    break;
                }
                else if ( !str_prefix(argument,"studded") )
                {
                    cprintf(ch,"ARMOR TYPE SET TO Studded.\n\r\n\r");
					pObj->value[0] = pObj->value[1] = pObj->value[2] = pObj->value[3] = pObj->level / 2;
					pObj->value[3] /= 4;
                    pObj->value[5] = mapArmorSlot( gpn_studded_leather_armor );
                    break;
                }
				else if ( !str_prefix(argument,"scale") )
				{
					cprintf(ch,"ARMOR TYPE SET TO Scale.\n\r\n\r");
                    pObj->value[0] = pObj->value[1] = pObj->value[2] = pObj->value[3] = pObj->level;
					pObj->value[3] /= 4;
					pObj->value[5] = mapArmorSlot( gpn_scale_mail_armor );
					break;
				}
		    	else if ( !str_prefix(argument,"chain") )
		    	{
					cprintf(ch,"ARMOR TYPE SET TO Chain.\n\r\n\r");
					pObj->value[0] = pObj->value[1] = pObj->value[2] = pObj->value[3] = pObj->level;
					pObj->value[3] /= 4;
					pObj->value[5] = mapArmorSlot( gpn_chain_mail_armor );
					break;
		    	}
		    	else if ( !str_prefix(argument,"plate") )
		    	{
					cprintf(ch,"ARMOR TYPE SET TO Plate.\n\r\n\r");
					pObj->value[0] = pObj->value[1] = pObj->value[2] = pObj->value[3] = pObj->level;
					pObj->value[3] /= 4;
					pObj->value[5] = mapArmorSlot( gpn_plate_mail_armor );
					break;
		    	}
		    	else
				if ( !str_prefix(argument,"buckler shield") )
				{
					cprintf(ch,"ARMOR TYPE SET TO Bucklet shields.\n\r");
					pObj->value[0] = pObj->value[1] = pObj->value[2] = pObj->value[3] = pObj->level / 2;
					pObj->value[3] /= 4;
					pObj->value[5] = mapArmorSlot( gpn_buckler_shields );
					break;
				}
				else
				if ( !str_prefix(argument,"small shield") )
				{
					cprintf(ch,"ARMOR TYPE SET TO Small Shield.\n\r");
					pObj->value[0] = pObj->value[1] = pObj->value[2] = pObj->value[3] = pObj->level / 2;
					pObj->value[3] /= 4;
					pObj->value[5] = mapArmorSlot( gpn_small_shields );
					break;
				}
				else
                if ( !str_prefix(argument,"medium shield") )
                {
                    cprintf(ch,"ARMOR TYPE SET TO Medium Shield.\n\r");
                    pObj->value[0] = pObj->value[1] = pObj->value[2] = pObj->value[3] = pObj->level;
                    pObj->value[3] /= 4;
                    pObj->value[5] = mapArmorSlot( gpn_medium_shields );
                    break;
                }
				else
                if ( !str_prefix(argument,"large shield") )
                {
                    cprintf(ch,"ARMOR TYPE SET TO Large Shield.\n\r");
                    pObj->value[0] = pObj->value[1] = pObj->value[2] = pObj->value[3] = pObj->level * 4 / 3;
                    pObj->value[3] /= 4;
                    pObj->value[5] = mapArmorSlot( gpn_large_shields );
                    break;
                }
				else
		    	{
					cprintf(ch,"Valid proficiency types are : none, cloth, leather, studded, scale, chain, plate, small, medium, large.\n\r");
		  			return FALSE;
		    	}
	    }
	    break;

		case ITEM_INSTRUMENT:
		switch( value_num )
		{
      		case 0:
                if( flag_value( instrument_types, argument ) == NO_FLAG )
                {
                    cprintf(ch,"No such instrument type.  Values are: percussion, strings, winds\n\r");
                    return FALSE;
                }

                pObj->value[0] = flag_value( instrument_types, argument );
                cprintf(ch,"Instrument type set to [%s]\n\r", flag_string( instrument_types, pObj->value[0] ) );
                return TRUE;
            default:
                cprintf(ch,"Instruments have only a type and no other properties (yet).\n\r");
                return TRUE;
		}

		case ITEM_PROJECTILE:
		switch ( value_num )
		{
			default:
				do_help( ch, "ITEM_PROJECTILE" );
				return FALSE;
			case 0:
				if ( flag_value(ranged_flags, argument ) != NO_FLAG )
				{
					TOGGLE_BIT(pObj->value[0], flag_value(ranged_flags,argument));
					cprintf(ch,"This project is be fired from: %s\n\r", flag_string(ranged_flags,pObj->value[0]) );
					break;
				}
				else
				{
					cprintf(ch,"Valid flags are: crossbow, shortbow, longbow, composite.\n\r");
					break;
				}
            case 1:
				pObj->value[1] = atoi( argument );
                cprintf( ch, "Number of dice set to %d.\n\r\n\r", pObj->value[1] );
                break;
            case 2:
                pObj->value[2] = atoi( argument );
                cprintf(ch, "Type of dice set to %d.\n\r\n\r", pObj->value[2] );
                break;
            case 3:
                pObj->value[3] = flag_value( weapon_flags, argument );
                cprintf(ch,"Damage type set.\n\r\n\r");
                break;
        	case 7:
        	{
            	int sn;
				SpellIndex* pSpellIndex;

            	if ( (sn = spell_lookup(argument,-1)) < 1 )
            	{
            		cprintf(ch,"No such spell found.\n\r");
            		return FALSE;
            	}
				
				if( (pSpellIndex = get_spell_index(sn) ) != NULL )
				{
            		pObj->value[7] = sn;
            		cprintf(ch,"SPECIAL PROC SET TO '%s' SPELL.\n\r\n\r",pSpellIndex->name);
				}
				else
				{
					log_bug("set_obj_values(item_projectile): Spell index not found(%d)",sn);
					return FALSE;
				}
        	}
            break;
        	case 8:
            	cprintf(ch,"SPECIAL PROC LEVEL SET TO %d.\n\r\n\r",(pObj->value[8] = atoi(argument)) );
            	break;
        	case 9:
            {
                int diff;

                if ( !str_cmp(argument,"always") )
                    diff = PROC_ALWAYS;
                else
                    diff = atoi(argument);

                cprintf(ch,"SPECIAL PROCEDURE DIFFICULT SET TO %d.\n\r\n\r",(pObj->value[9]=diff));
            }
            break;
        }
        break; 

        case ITEM_WEAPON:
	    switch ( value_num )
		{
	        default:
		    do_help( ch, "ITEM_WEAPON" );
	            return FALSE;
	        case 0:
		    	send_to_char( "WEAPON CLASS SET.\n\r\n\r", ch );
		    	pObj->value[0] = flag_value( weapon_class, argument );
				check_twohandedness( pObj );
				check_ranged_weapon( pObj );
				pObj->value[5] = weapon_table[get_weapon_index(pObj->value[0])].speed;
                switch( weapon_table[get_weapon_index(pObj->value[0])].dam_type )
                {
                case DAM_SLASH:  pObj->value[3] = flag_value( weapon_flags, "slash" ); break;
                case DAM_PIERCE: pObj->value[3] = flag_value( weapon_flags, "pierce" ); break;
                case DAM_BASH:   pObj->value[3] = flag_value( weapon_flags, "bash" ); break;
                default: break;
                }

                if ( pObj->value[3] == 0 )
                    cprintf(ch,"Warning: Unable to assign default damage type.\n\r");
                else
                    cprintf(ch,"Damage type set to default: %s\n\r", flag_string( weapon_flags, pObj->value[3] ) );

				cprintf(ch,"Weapon speed set to recommended value of %d.%d.\n\r",
					pObj->value[5] / 10, pObj->value[5] % 10 );

		    	break;
	        case 1:
	            send_to_char( "NUMBER OF DICE SET.\n\r\n\r", ch );
	            pObj->value[1] = atoi( argument );
	            break;
	        case 2:
	            send_to_char( "TYPE OF DICE SET.\n\r\n\r", ch );
	            pObj->value[2] = atoi( argument );
	            break;
	        case 3:
            {
                int tmp = flag_value( weapon_flags, argument );
                int dt  = weapon_table[get_weapon_index(pObj->value[0])].dam_type;
                if ( attack_table[tmp].damage != dt )
                {
                    cprintf(ch,"This weapon class does %s damage, ", flag_string( dam_flags, dt ) );
                    cprintf(ch,"but the type you picked is %s damage.\n\r", flag_string( dam_flags, tmp ) );
                    return FALSE;
                }
            }
	            cprintf( ch, "DAMAGE TYPE SET.\n\r\n\r" );
	            pObj->value[3] = flag_value( weapon_flags, argument );
	            break;
	        case 4:
				if( flag_value(weapon_type_olc,argument) != NO_FLAG )
				{
					TOGGLE_BIT(pObj->value[4], flag_value( weapon_type_olc, argument ) );
					cprintf(ch,"SPECIAL WEAPON TYPE SET.\n\r");
					break;
				}
				else
				{
					cprintf(ch,"No such weapon flag, type ? wtype to see a list.\n\r");
					break;
				}
		case 5:
		    send_to_char( "WEAPON SPEED SET.\n\r\n\r", ch );
		    pObj->value[5] = atoi( argument );
		    break;

		case 7:
		{
		    int sn;
			SpellIndex* pSpellIndex;

            if ( (sn = spell_lookup(argument,-1)) < 1 )
            {
            	cprintf(ch,"No such spell found.\n\r");
            	return FALSE;
            }
				
			if( (pSpellIndex = get_spell_index(sn) ) != NULL )
			{
 				pObj->value[7] = sn; 
				cprintf(ch,"SPECIAL PROC SET TO '%s' SPELL.\n\r\n\r",pSpellIndex->name);				
			}
			else
			{
				log_bug("set_obj_values(item_weapon): Spell index not found(%d)",sn);
				return FALSE;
			}
		}
		    break;
		case 8:	
		    cprintf(ch,"SPECIAL PROC LEVEL SET TO %d.\n\r\n\r",(pObj->value[8] = atoi(argument)) );
		    break;
	  	case 9:
			{
				int diff;

				if ( !str_cmp(argument,"always") )
					diff = PROC_ALWAYS;
				else
					diff = atoi(argument);
		
		    	cprintf(ch,"SPECIAL PROCEDURE DIFFICULT SET TO %d.\n\r\n\r",(pObj->value[9]=diff));
			}
		    break;
	    }
            break;

		case ITEM_MOBILE:
		switch( value_num )
	    {
		default:
		    do_help( ch, "ITEM_MOBILE" );
	            return FALSE;
		case 0:
	            send_to_char( "Weight capacity set.\n\r\n\r", ch );
	            pObj->value[0] = atoi( argument );
	            break;
		case 3:
		    cprintf(ch,"MAXIMUM SIZE PER ITEM SET.\n\r");
		    pObj->value[3] = atoi(argument);
		    break;
		case 4:
		    cprintf(ch,"WEIGHT MULTIPLIER SET.\n\r");
		    pObj->value[4] = atoi(argument);
		    break;
	    }
		break;

        case ITEM_CONTAINER:
	    switch ( value_num )
	    {
		int value;
		
		default:
		    do_help( ch, "ITEM_CONTAINER" );
	            return FALSE;
		case 0:
                pObj->value[0] = atoi( argument );
	            cprintf(ch, "Weight capacity set to %d stones.\n\r\n\r", pObj->value[0] );
	            break;
		case 1:
	            if ( ( value = flag_value( container_flags, argument ) )
	              != NO_FLAG )
	        	TOGGLE_BIT(pObj->value[1], value);
		    else
		    {
			do_help ( ch, "ITEM_CONTAINER" );
			return FALSE;
		    }
	            send_to_char( "CONTAINER TYPE SET.\n\r\n\r", ch );
	            break;
		case 2:
		    if ( atoi(argument) != 0 )
		    {
			if ( !get_obj_index( atoi( argument ) ) )
			{
			    send_to_char( "THERE IS NO SUCH ITEM.\n\r\n\r", ch );
			    return FALSE;
			}

			if ( get_obj_index( atoi( argument ) )->item_type != ITEM_KEY )
			{
			    send_to_char( "THAT ITEM IS NOT A KEY.\n\r\n\r", ch );
			    return FALSE;
			}
		    }
		    send_to_char( "CONTAINER KEY SET.\n\r\n\r", ch );
		    pObj->value[2] = atoi( argument );
		    break;
		case 3:
		    cprintf(ch,"MAXIMUM SIZE PER ITEM SET.\n\r");
		    pObj->value[3] = atoi(argument);
		    break;
		case 4:
		    cprintf(ch,"WEIGHT MULTIPLIER SET.\n\r");
		    pObj->value[4] = atoi(argument);
		    break;
        case 5: { 
            int val = atoi(argument);
            if ( val < 0 )
            {
                cprintf(ch,"Recommended pick difficulty is 1-65, with 1 being easiest.\n\r");
                return FALSE;
            }

            pObj->value[5] = val;
            cprintf(ch,"This lock is an even match for a character with %d lock pick skill.\n\r",
                pObj->value[5] );
            break;
            }
           
	    }
	    break;

	case ITEM_DRINK_CON:
	    switch ( value_num )
	    {
	        default:
		    do_help( ch, "ITEM_DRINK" );
/* OLC		    do_help( ch, "liquids" );    */
	            return FALSE;
	        case 0:
	            send_to_char( "MAXIMUM AMOUT OF LIQUID HOURS SET.\n\r\n\r", ch );
	            pObj->value[0] = atoi( argument );
	            break;
	        case 1:
	            send_to_char( "CURRENT AMOUNT OF LIQUID HOURS SET.\n\r\n\r", ch );
	            pObj->value[1] = atoi( argument );
	            break;
	        case 2:
				if ( liq_lookup( argument ) < 0 )
				{
					cprintf(ch,"No such liquid type.\n\r");
					return FALSE;
				}

	            send_to_char( "LIQUID TYPE SET.\n\r\n\r", ch );
	            pObj->value[2] = liq_lookup( argument );
	            break;
	        case 3:
	            send_to_char( "POISON VALUE TOGGLED.\n\r\n\r", ch );
	            pObj->value[3] = ( pObj->value[3] == 0 ) ? 1 : 0;
	            break;
	    }
            break;

	case ITEM_FOOD:
	    switch ( value_num )
	    {
	        default:
		    do_help( ch, "ITEM_FOOD" );
	            return FALSE;
	        case 0:
	            send_to_char( "HOURS OF FOOD-FULL SET.\n\r\n\r", ch );
	            pObj->value[0] = atoi( argument );
	            break;
		case 1:
		    send_to_char( "HOURS OF FOOD-HUNGRY SET.\n\r\n\r", ch);
		    pObj->value[1] = atoi( argument );
		    break;
	        case 3:
	            send_to_char( "POISON VALUE TOGGLED.\n\r\n\r", ch );
	            pObj->value[3] = ( pObj->value[3] == 0 ) ? 1 : 0;
	            break;
	    }
            break;

	case ITEM_MONEY:
	    switch ( value_num )
	    {
	        default:
		    do_help( ch, "ITEM_MONEY" );
	            return FALSE;
	        case 0:
	            send_to_char( "SILVER AMOUNT SET.\n\r\n\r", ch );
	            pObj->value[0] = atoi( argument );
	            break;
                case 1:
                    send_to_char( "GOLD AMOUNT SET.\n\r\n\r", ch );
                    pObj->value[1] = atoi( argument );
                    break;
                case 2:
                    send_to_char( "ELECTRUM AMOUNT SET.\n\r\n\r", ch );
                    pObj->value[2] = atoi( argument );
                    break;
                case 3:
                    send_to_char( "PLATINUM AMOUNT SET.\n\r\n\r", ch );
                    pObj->value[3] = atoi( argument );
                    break;
                case 4:
                    send_to_char( "MITHRIL AMOUNT SET.\n\r\n\r", ch );
                    pObj->value[4] = atoi( argument );
                    break;
	    }
            break;
    }

    show_obj_values( ch, pObj );

    return TRUE;
}

void show_obj_values_to_file( FILE *fp, ObjIndex *obj )
{
    switch( obj->item_type )
    {
	default:	/* No values. */
	    break;
            
	case ITEM_LIGHT:
            if ( obj->value[2] == -1 || obj->value[2] == 999 ) /* ROM OLC */
		fprintf( fp, "[v2] Light:  Infinite[-1]\n" );
            else
		fprintf( fp, "[v2] Light:  [%d]\n", obj->value[2] );
	    break;

	case ITEM_WAND:
	case ITEM_STAFF:
            fprintf( fp,
		"[v0] Level:          [%d]\n"
		"[v1] Charges Total:  [%d]\n"
		"[v2] Charges Left:   [%d]\n"
		"[v3] Spell:          %s\n",
		obj->value[0],
		obj->value[1],
		obj->value[2],
		obj->value[3] != -1 ? skill_table[obj->value[3]].name
		                    : "none" );
	    break;

	case ITEM_SCROLL:
	case ITEM_POTION:
	case ITEM_PILL:
            fprintf( fp,
		"[v0] Level:  [%d]\n"
		"[v1] Spell:  %s\n"
		"[v2] Spell:  %s\n"
		"[v3] Spell:  %s\n",
		obj->value[0],
		obj->value[1] != -1 ? skill_table[obj->value[1]].name
		                    : "none",
		obj->value[2] != -1 ? skill_table[obj->value[2]].name
                                    : "none",
		obj->value[3] != -1 ? skill_table[obj->value[3]].name
		                    : "none" );
	    break;

	case ITEM_FURNITURE:
	    fprintf(fp,
		"[v0] max # users	[%d]\n"
		"[v1] max weight	[%d]\n"
		"[v2] flags		[%s]\n"
		"[v3] hp regen		[%d]\n"
		"[v4] mana regen	[%d]\n",
		obj->value[0], obj->value[1],
		flag_string( furniture_flags, obj->value[2] ),
		obj->value[3], obj->value[4] );
		break;

	case ITEM_FOUNTAIN:
	    fprintf(fp,
		"[v0] max fill		[%d]\n"
		"[v1] current fill	[%d]\n"
		"[v2] liquid		[%s]\n"
		"[v3] poisoned?		[%s]\n",
		obj->value[0], obj->value[1],
		liq_table[obj->value[2]].liq_name,
		obj->value[3] ? "YES" : "NO" );
	    break;

	case ITEM_PORTAL:
	    fprintf(fp,
		"[v0] #uses              [%d]\n"
		"[v1] exit flags         [%s]\n"
		"[v2] gate flags         [%s]\n"
	 	"[v3] destination vnum   [%d]\n",
		obj->value[0], flag_string( exit_flags, obj->value[1] ),
		flag_string( portal_flags, obj->value[2] ),
		obj->value[3] );
	    break;

        case ITEM_ARMOR:
	    fprintf( fp,
		"[v0] Ac pierce       [%d]\n"
		"[v1] Ac bash         [%d]\n"
		"[v2] Ac slash        [%d]\n"
		"[v3] Ac exotic       [%d]\n"
		/*"[v4] Bulk            [%d]\n"*/
		"[v5] Proficiency     [%s]\n",
		obj->value[0],
		obj->value[1],
		obj->value[2],
		obj->value[3],
		/*obj->value[4],*/
		armor_table[obj->value[5]].name);
	    break;

    case ITEM_PROJECTILE:
	{
		SpellIndex* pSpellIndex;

        fprintf( fp, "[v0] Can be fired from:     [%s]\n\r", flag_string( ranged_flags, obj->value[0] ) );
        fprintf( fp, "[v1] Number of dice:        [%d]\n\r", obj->value[1] );
        fprintf( fp, "[v2] Type of dice:          [%d]\n\r", obj->value[2] );
        
		pSpellIndex = get_spell_index(obj->value[7]);
		fprintf( fp, "[v7] Spell proc:            [%s]\n\r", obj->value[7] <= 0 ? " --none-- " : 
			pSpellIndex ? pSpellIndex->name : "(null)" );

        fprintf( fp, "[v8] Proc level:            [%d]\n\r", obj->value[8] );
        if( obj->value[9] == PROC_ALWAYS )
            fprintf( fp, "[v9] Difficulty:            [ALWAYS]\n\r" );
        else
            fprintf( fp, "[v9] Difficulty:            [%d]\n\r", obj->value[9] );
        break;
	}

/* WEAPON changed in ROM: */
/* I had to split the output here, I have no idea why, but it helped -- Hugin */
/* It somehow fixed a bug in showing scroll/pill/potions too ?! */
	case ITEM_WEAPON:
	{
		SpellIndex* pSpellIndex;

		fprintf(fp,  "Base DPS: %.2f\n", getDPS(obj->value[1],obj->value[2],obj->value[5]) );
        fprintf( fp, "[v0] Weapon type:    %s (%s skill)\n",
				flag_string( weapon_class, obj->value[0] ),
		    	skill_table[ *weapon_table[get_weapon_index(obj->value[0])].gsn ].name );
	    fprintf( fp, "[v1] Number of dice: [%d]\n", obj->value[1] );
	    fprintf( fp, "[v2] Type of dice:   [%d]\n", obj->value[2] );
	    fprintf( fp, "[v3] Damage Noun:    %s", flag_string( weapon_flags, obj->value[3] ));
        fprintf( fp, " (%s)\n", flag_string( dam_flags, attack_table[ obj->value[3] ].damage ));
 	    fprintf( fp, "[v4] Special type:   %s\n", flag_string( weapon_type_olc,  obj->value[4] ) );
	    fprintf( fp,  "[v5] Weapon speed:   %d.%ds\n", obj->value[5]/10, obj->value[5]%10 );
  	    fprintf( fp,  "[v6] Range:          [%d]\n", obj->value[6] ); 
		pSpellIndex = get_spell_index(obj->value[7]);
		fprintf( fp,  "[v7] Spell proc:     [%s]\n", obj->value[7] <= 0 ? " --none-- " : 
			(pSpellIndex ? pSpellIndex->name : "(null)") );

	    fprintf( fp,  "[v8] Proc level:     [%d]\n",
		obj->value[8] );
		if( obj->value[9] == PROC_ALWAYS )
			fprintf( fp, "[v9] Difficulty:     [ALWAYS]\n");
		else
 	    	fprintf( fp, "[v9] Difficulty:     [%d]\n", obj->value[9] );
	    break;
	}

	case ITEM_MOBILE:
        fprintf( fp,
        "[v0] Capacity:      [%d stones]\n"
        "[v3] MaxItem#:      [%d]\n" 
		"[v4] Multiplier:    [%d%% of actual weight used]\n", 
			obj->value[0], obj->value[3], obj->value[4] );
        break;

	case ITEM_CONTAINER:
	    fprintf( fp,
		"[v0] Capacity:      [%d stones]\n"
		"[v1] Flags:         [%s]\n"
		"[v2] Key:           [%d] %s\n"
	    "[v3] MaxItem#:      [%d]\n"
  		"[v4] Multiplier:    [%d%% of actual weight used]\n"
        "[v5] Lock Level:    [%d]\n",
		obj->value[0],
		flag_string( container_flags, obj->value[1] ),
		obj->value[2],
                get_obj_index(obj->value[2])
                    ? get_obj_index(obj->value[2])->short_descr
                    : "none", obj->value[3], obj->value[4], obj->value[5] );
	    break;

	case ITEM_DRINK_CON:
	    fprintf( fp,
	        "[v0] Liquid Total: [%d]\n"
	        "[v1] Liquid Left:  [%d]\n"
	        "[v2] Liquid:       %s\n"
	        "[v3] Poisoned:     %s\n",
	        obj->value[0],
	        obj->value[1],
	        liq_table[obj->value[2]].liq_name,
	        obj->value[3] != 0 ? "Yes" : "No" );
	    break;

	case ITEM_FOOD:
	    fprintf( fp,
		"[v0] 'Full' amount:		[%d]\n"
		"[v1] 'Hunger' amount:   	[%d]\n"
		"[v3] Poisoned:   %s\n",
		obj->value[0],
		obj->value[1],
		obj->value[3] != 0 ? "Yes" : "No" );
	    break;

	case ITEM_FORGE:
	    fprintf(fp,
		"[v0] Bonus/Penalty:            [%d]\n"
 		"[v1] Uses (-1 for infinite):   [%d]\n"
		"[v2] Recipe Type:              [%s]\n"
		"[v3] Forge Type:               [%s]\n",
		    obj->value[0], obj->value[1], 
		    skill_table[obj->value[2]].name,
		    flag_string( forge_flags, obj->value[3] ) );

		fprintf(fp, "[v4] Foundation Skills:		[%s]\n\r",
            flag_string( foundation_flags, obj->value[4] ) );
	    break;

	case ITEM_PRAYER_BOOK:
	{
		SpellIndex* pSpellIndex;

		pSpellIndex = get_spell_index(obj->value[0]);

	    fprintf(fp,
		"[v0] Spell:                    [%s]\n"
		"[v1] Experience for reading:   [%d]\n",
		/*"[v2] Paladin can learn:        [%s&x]\n"
  		"[v3] Crusader can learn:       [%s&x]\n"
		"[v4] Druid can learn:          [%s&x]\n"
		"[v5] Shaman can learn:         [%s&x]\n"
     		"[v6] Cleric can learn:    	[%s&x]\n",*/
		    obj->value[0] < 0 ? "<invalid spell>" : 
			(pSpellIndex ? pSpellIndex->name : "(null)"),
		    obj->value[1] );
		    /*obj->value[2] ? "&GYES" : "&RNO",
		    obj->value[3] ? "&GYES" : "&RNO",
		    obj->value[4] ? "&GYES" : "&RNO",
		    obj->value[5] ? "&GYES" : "&RNO",
		    obj->value[6] ? "&GYES" : "&RNO" );*/
	    break;
	}

	case ITEM_LYRIC_SHEET:
	{
		SpellIndex* pSpellIndex;

		pSpellIndex = get_spell_index(obj->value[0]);

		fprintf(fp,"[v0] Spell:                  [%s]\n", 
			pSpellIndex ? pSpellIndex->name : "(null)" );
		break;
	}

	case ITEM_ARCANE_SCROLL:
	{
		SpellIndex* pSpellIndex;

		pSpellIndex = get_spell_index(obj->value[0]);
		
		fprintf(fp,
			"[v0] Spell:                  [%s]\n"
	        "[v1] Copy status:            [%s]\n"
            "[v2] Copying Difficulty:     [%d]\n",
			obj->value[0] < 0 ? " <none> " : (pSpellIndex ? pSpellIndex->name : "(null)"), 
				obj->value[1] ? "no copying" : "can copy",
 				obj->value[2] );
		break;
	}

	case ITEM_SPELLBOOK:
	{
	    int i;
	    bool found = FALSE;
		SpellIndex* pSpellIndex;

	    for (i=0 ; i<10 ;i++)
		if ( obj->value[i] > 0 )
		{
			int sn = obj->value[i];
			pSpellIndex = get_spell_index(sn);

			fprintf(fp,"[v%d] Spell '%s'\n",i, pSpellIndex ? pSpellIndex->name : "(null)");
		    found = TRUE;
		}

	    if (!found)
			fprintf(fp,"There are no spells in this spellbook.\n");

	    break;
	}

	case ITEM_MONEY:
	
         fprintf( fp, 	"[v0] Silver: 	[%d]\n"
			  			"[v1] Gold:     [%d]\n"
						"[v2] Electrum:	[%d]\n"
						"[v3] Platinum:	[%d]\n"
						"[v4] Mithril:  [%d]\n", 
		obj->value[0],
		obj->value[1],
		obj->value[2],
		obj->value[3],
		obj->value[4]  );
	    break;

	case ITEM_INSTRUMENT:
		fprintf(fp,"[v0] Instrument Type:                   [%s]\n", flag_string( instrument_types, obj->value[0] ) );
		break;
    }

	fflush(fp);
    return;
}

void show_obj_values( Character *ch, ObjIndex *obj )
{
    char buf[MAX_STRING_LENGTH];

    switch( obj->item_type )
    {
	default:	/* No values. */
	    break;
            
	case ITEM_LIGHT:
            if ( obj->value[2] == -1 || obj->value[2] == 999 ) /* ROM OLC */
		sprintf( buf, "[v2] Light:  Infinite[-1]\n\r" );
            else
		sprintf( buf, "[v2] Light:  [%d]\n\r", obj->value[2] );
	    send_to_char( buf, ch );
	    break;

	case ITEM_WAND:
	case ITEM_STAFF:
            sprintf( buf,
		"[v0] Level:          [%d]\n\r"
		"[v1] Charges Total:  [%d]\n\r"
		"[v2] Charges Left:   [%d]\n\r"
		"[v3] Spell:          %s\n\r",
		obj->value[0],
		obj->value[1],
		obj->value[2],
		obj->value[3] != -1 ? skill_table[obj->value[3]].name
		                    : "none" );
	    send_to_char( buf, ch );
	    break;

	case ITEM_SCROLL:
	case ITEM_POTION:
	case ITEM_PILL:
            sprintf( buf,
		"[v0] Level:  [%d]\n\r"
		"[v1] Spell:  %s\n\r"
		"[v2] Spell:  %s\n\r"
		"[v3] Spell:  %s\n\r",
		obj->value[0],
		obj->value[1] != -1 ? skill_table[obj->value[1]].name
		                    : "none",
		obj->value[2] != -1 ? skill_table[obj->value[2]].name
                                    : "none",
		obj->value[3] != -1 ? skill_table[obj->value[3]].name
		                    : "none" );
	    send_to_char( buf, ch );
	    break;

	case ITEM_FURNITURE:
	    cprintf(ch,
		"[v0] max # users	[%d]\n\r"
		"[v1] max weight	[%d]\n\r"
		"[v2] flags         [%s]\n\r"
		"[v3] hp regen		[%d]\n\r"
		"[v4] mana regen	[%d]\n\r",
		obj->value[0], obj->value[1],
		flag_string( furniture_flags, obj->value[2] ),
		obj->value[3], obj->value[4] );
		break;

	case ITEM_FOUNTAIN:
	    cprintf(ch,
		"[v2] liquid		[%s]\n\r"
		"[v3] poisoned?		[%s]\n\r",
		liq_table[obj->value[2]].liq_name,
		obj->value[3] ? "YES" : "NO" );
	    break;

	case ITEM_PORTAL:
	    cprintf(ch,
		"[v0] #uses              [%d]\n\r"
		"[v1] exit flags         [%s]\n\r"
		"[v2] gate flags         [%s]\n\r"
	 	"[v3] destination vnum   [%d]\n\r",
		obj->value[0], flag_string( exit_flags, obj->value[1] ),
		flag_string( portal_flags, obj->value[2] ),
		obj->value[3] );
	    break;

        case ITEM_ARMOR:
	    sprintf( buf,
		"[v0] Ac pierce       [%d]\n\r"
		"[v1] Ac bash         [%d]\n\r"
		"[v2] Ac slash        [%d]\n\r"
		"[v3] Ac exotic       [%d]\n\r"
		/*"[v4] Bulk            [%d]\n\r"*/
		"[v5] Proficiency     [%s]\n\r",
		obj->value[0],
		obj->value[1],
		obj->value[2],
		obj->value[3],
		/*obj->value[4],*/
		armor_table[obj->value[5]].name);
	    send_to_char( buf, ch );
	    break;

	case ITEM_PROJECTILE:
	{
		SpellIndex* pSpellIndex;

		cprintf( ch, "[v0] Can be fired from:     [%s]\n\r", flag_string( ranged_flags, obj->value[0] ) );
		cprintf( ch, "[v1] Number of dice:        [%d]\n\r", obj->value[1] );
        cprintf( ch, "[v2] Type of dice:          [%d]\n\r", obj->value[2] );
        
		pSpellIndex = get_spell_index(obj->value[7]);
		cprintf( ch, "[v7] Spell proc:            [%s]\n\r", obj->value[7] <= 0 ? " --none-- " : 
			pSpellIndex ? pSpellIndex->name : "(null)" );
        
		cprintf( ch, "[v8] Proc level:            [%d]\n\r", obj->value[8] );
        if( obj->value[9] == PROC_ALWAYS )
        	cprintf( ch, "[v9] Difficulty:            [ALWAYS]\n\r" );
        else
		{
        	cprintf( ch, "[v9] Difficulty:            [%d]\n\r", obj->value[9] );
			cprintf( ch, "(Positive difficulty means the proc fires less often)\n\r");
		}
		break;
	}

/* WEAPON changed in ROM: */
/* I had to split the output here, I have no idea why, but it helped -- Hugin */
/* It somehow fixed a bug in showing scroll/pill/potions too ?! */

	case ITEM_WEAPON:
	{
		SpellIndex* pSpellIndex;

        cprintf(ch,  "Base DPS: %.2f\n", getDPS(obj->value[1],obj->value[2],obj->value[5]) );
            cprintf( ch, "[v0] Weapon type:    %s (%s skill)\n\r",
		     flag_string( weapon_class, obj->value[0] ),
		    skill_table[ *weapon_table[get_weapon_index(obj->value[0])].gsn ].name );
	    cprintf( ch, "[v1] Number of dice: [%d]\n\r", obj->value[1] );
	    cprintf( ch, "[v2] Type of dice:   [%d]\n\r", obj->value[2] );
        cprintf( ch, "[v3] Damage Noun:    %s", flag_string( weapon_flags, obj->value[3] ));
        cprintf( ch, " (%s)\n", flag_string( dam_flags, attack_table[ obj->value[3] ].damage ));

 	    cprintf( ch, "[v4] Special type:   %s\n\r",
		     flag_string( weapon_type_olc,  obj->value[4] ) );
	    cprintf( ch,  "[v5] Weapon speed:   %d.%ds\n\r",
			obj->value[5]/10, obj->value[5]%10 );
  	    cprintf( ch,  "[v6] Range:          [%d]\n\r", obj->value[6] );
	    
		pSpellIndex = get_spell_index(obj->value[7]);
		cprintf( ch,  "[v7] Spell proc:     [%s]\n\r", 	obj->value[7] <= 0 ? " --none-- " : 
			pSpellIndex ? pSpellIndex->name : "(null)");
	    
		cprintf( ch,  "[v8] Proc level:     [%d]\n\r",
		obj->value[8] );
		if( obj->value[9] == PROC_ALWAYS )
			cprintf( ch, "[v9] Difficulty:     [ALWAYS]\n\r");
		else
		{
 	    	cprintf( ch, "[v9] Difficulty:     [%d]\n\r", obj->value[9] );
			cprintf( ch, "(Positive difficulty means the proc fires less often)\n\r");
		}
	    break;
	}
	case ITEM_MOBILE:
        cprintf( ch,
        "[v0] Capacity:      [%d stones]\n"
        "[v3] MaxItem#:      [%d]\n" 
		"[v4] Multiplier:    [%d%% of actual weight used]\n", 
			obj->value[0], obj->value[3], obj->value[4] );
        break;

	case ITEM_CONTAINER:
	    cprintf( ch,
		"[v0] Capacity:      [%d stones]\n\r"
		"[v1] Flags:         [%s]\n\r"
		"[v2] Key:           [%d] %s\n\r"
	    "[v3] MaxItem#:      [%d]\n\r"
  		"[v4] Multiplier:    [%d%% of actual weight used]\n\r"
        "[v5] Lock Level:    [%d]\n\r",
		obj->value[0],
		flag_string( container_flags, obj->value[1] ),
		obj->value[2],
                get_obj_index(obj->value[2])
                    ? get_obj_index(obj->value[2])->short_descr
                    : "none", obj->value[3], obj->value[4], obj->value[5] );
	    break;

	case ITEM_DRINK_CON:
	    sprintf( buf,
	        "[v0] Liquid Total: [%d]\n\r"
	        "[v1] Liquid Left:  [%d]\n\r"
	        "[v2] Liquid:       %s\n\r"
	        "[v3] Poisoned:     %s\n\r",
	        obj->value[0],
	        obj->value[1],
	        liq_table[obj->value[2]].liq_name,
	        obj->value[3] != 0 ? "Yes" : "No" );
	    send_to_char( buf, ch );
	    break;

	case ITEM_FOOD:
	    sprintf( buf,
		"[v0] 'Full' amount:		[%d]\n\r"
		"[v1] 'Hunger' amount:   	[%d]\n\r"
		"[v3] Poisoned:   %s\n\r",
		obj->value[0],
		obj->value[1],
		obj->value[3] != 0 ? "Yes" : "No" );
	    send_to_char( buf, ch );
	    break;

	case ITEM_FORGE:
	    cprintf(ch,
		"[v0] Bonus/Penalty:            [%d]\n\r"
 		"[v1] Uses (-1 for infinite):   [%d]\n\r"
		"[v2] Recipe Type:              [%s]\n\r",
		    obj->value[0], obj->value[1], 
		    skill_table[obj->value[2]].name );
		cprintf(ch,
		"[v4] Foundation Skills:		[%s]\n\r",
            flag_string( foundation_flags, obj->value[4] ) );
	    break;

	case ITEM_PRAYER_BOOK:
	{
		SpellIndex* pSpellIndex;

		pSpellIndex = get_spell_index(obj->value[0]);

	    cprintf(ch,
		"[v0] Spell:                    [%s]\n\r"
		"[v1] Experience for reading:   [%d]\n\r",
		/*"[v2] Paladin can learn:        [%s&x]\n\r"
  		"[v3] Crusader can learn:       [%s&x]\n\r"
		"[v4] Druid can learn:          [%s&x]\n\r"
		"[v5] Shaman can learn:         [%s&x]\n\r"
     		"[v6] Cleric can learn:    	[%s&x]\n\r",*/
			obj->value[0] < 0 ? "<invalid spell>" : (pSpellIndex ? pSpellIndex->name : "(null)"),
		    obj->value[1] );
		    /*obj->value[2] ? "&GYES" : "&RNO",
		    obj->value[3] ? "&GYES" : "&RNO",
		    obj->value[4] ? "&GYES" : "&RNO",
		    obj->value[5] ? "&GYES" : "&RNO",
		    obj->value[6] ? "&GYES" : "&RNO" );*/
	    break;
	}

	case ITEM_LYRIC_SHEET:
	{
		SpellIndex* pSpellIndex;

		pSpellIndex = get_spell_index(obj->value[0]);
		cprintf(ch,
			"[v0] Spell:                  [%s]\n\r", pSpellIndex ? pSpellIndex->name : "(null)" );
		break;
	}

	case ITEM_ARCANE_SCROLL:
	{
		SpellIndex* pSpellIndex;

		pSpellIndex = get_spell_index(obj->value[0]);
		cprintf(ch,
			"[v0] Spell:                  [%s]\n\r"
	        "[v1] Copy status:            [%s]\n\r"
            "[v2] Copying Difficulty:     [%d]\n\r",
			pSpellIndex ? pSpellIndex->name : "(null)", 
				obj->value[1] ? "no copying" : "can copy",
 				obj->value[2] );
		break;
	}

	case ITEM_SPELLBOOK:
	{
	    int i;
	    bool found = FALSE;
		SpellIndex* pSpellIndex;
	    
		for (i=0 ; i<10 ;i++)
		if ( obj->value[i] > 0 )
		{
			int sn = obj->value[i];
			pSpellIndex = get_spell_index(sn);
			cprintf(ch,"[v%d] Spell '%s'\n\r",i,pSpellIndex ? pSpellIndex->name : "(null)" );
		    found = TRUE;
		}

	    if (!found)
			cprintf(ch,"There are no spells in this spellbook.\n\r");
	    break;
	}

	case ITEM_MONEY:
	
            sprintf( buf, 	"[v0] Silver: 	[%d]\n\r"
			  	"[v1] Gold:	[%d]\n\r"
				"[v2] Electrum:	[%d]\n\r"
				"[v3] Platinum:	[%d]\n\r"
				"[v4] Mithril:  [%d]\n\r", 
		obj->value[0],
		obj->value[1],
		obj->value[2],
		obj->value[3],
		obj->value[4]  );
	    send_to_char( buf, ch );
	    break;

	case ITEM_INSTRUMENT:
		cprintf(ch,"[v0] Instrument Type:                   [%s]\n\r", flag_string( instrument_types, obj->value[0] ) );
		break;
    }

    return;
}


void copyObj_Extras( ObjIndex *obj, ExtraDescr *ed )
{
	ExtraDescr *new;

	if ( ed == NULL )
		return;

	if ( ed->next )
		copyObj_Extras( obj, ed->next );

	new                  =  new_extra_descr();
	new->keyword         =  str_dup( ed->keyword );
	new->description	 = 	str_dup( ed->description );

	new->next			= 	obj->extra_descr;
	obj->extra_descr	=	new;
}

void copyObj_Affects( ObjIndex *obj, Affect *paf )
{
	Affect *new;

	if ( paf == NULL )
		return;

	if ( paf->next )
		copyObj_Affects( obj, paf->next );

    new             =   new_affect();
    new->location   =   paf->location;
    new->modifier   =   paf->modifier;
    new->type       =   paf->type;
    new->duration   =   paf->duration;
    new->bitvector  =   paf->bitvector;
    new->misc       =   paf->misc;
    new->next       =   obj->affected;
    obj->affected   =   new;

	return;
}

void copyObjIndex( ObjIndex *new, ObjIndex *orig )
{
	int i;

	new->name 			= str_dup( orig->name );
	new->item_type		= orig->item_type;
	new->level			= orig->level;
	new->wear_flags		= orig->wear_flags;
	new->extra_flags	= orig->extra_flags;
	new->material		= str_dup( orig->material );
	new->condition		= orig->condition;
	new->durability		= orig->durability;
	new->quality		= orig->quality;
	new->deity			= orig->deity;
	new->weight			= orig->weight;
	new->cost			= orig->cost;
	new->short_descr	= str_dup( orig->short_descr );
	new->description	= str_dup( orig->description );

	for( i=0 ; i < 10 ; i++ )
		new->value[i] = orig->value[i];

	copyObj_Extras( new, orig->extra_descr );
	copyObj_Affects( new, orig->affected );
}
