/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/
 
/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <stdio.h>
#include <time.h>
#include "thoc.h"
#include "tables.h"

int flag_lookup (const char *name, const struct flag_type *flag_table)
{
    int flag;

    for (flag = 0; flag_table[flag].name != NULL && flag_table[flag].name[0] != '\0'; flag++)
    {
	if (LOWER(name[0]) == LOWER(flag_table[flag].name[0])
	&&  !str_prefix(name,flag_table[flag].name))
	    return flag_table[flag].bit;
    }

    return NO_FLAG;
}

int channel_lookup(const char *name)
{
    int chan;

    for (chan = 0; chan < MAX_CHANNELS; chan++)
    {
        if (LOWER(name[0]) == LOWER(channel_table[chan].name[0])
        &&  !str_prefix(name,channel_table[chan].name))
            return chan;
    }

    return -1;
}

int currency_lookup( const char *name )
{
	int cur;

	for( cur = 0 ; currency_table[cur].name != NULL ; cur++ )
	{
		if (LOWER(name[0]) == LOWER(currency_table[cur].name[0])
		&& !str_prefix(name,currency_table[cur].name))
			return cur;
	}

	return -1;
}

Clan * clan_lookup(const char *name)
{
    Clan * clan;

    for (clan = clan_table ; clan ; clan = clan->next )
    {
		if ( clan->name == NULL )
			return NULL;

		if (LOWER(name[0]) == LOWER(clan->name[0]) 
		&&  !str_prefix(name,clan->name) )
	    	return clan;
    }

    return NULL;
}

int position_lookup (const char *name)
{
   int pos;

   for (pos = 0; position_table[pos].name != NULL; pos++)
   {
	if (LOWER(name[0]) == LOWER(position_table[pos].name[0])
	&&  !str_prefix(name,position_table[pos].name))
	    return pos;
   }
   
   return -1;
}

int sex_lookup (const char *name)
{
   int sex;
   
   for (sex = 0; sex_table[sex].name != NULL; sex++)
   {
	if (LOWER(name[0]) == LOWER(sex_table[sex].name[0])
	&&  !str_prefix(name,sex_table[sex].name))
	    return sex;
   }

   return -1;
}

int size_lookup (const char *name)
{
   int size;
 
   for ( size = 0; size_table[size].name != NULL; size++)
   {
        if (LOWER(name[0]) == LOWER(size_table[size].name[0])
        &&  !str_prefix( name,size_table[size].name))
            return size;
   }
 
   return -1;
}

int proficiency_lookup (const char *name)
{
   int proficiency;

   for ( proficiency = 0; prof_table[proficiency].name != NULL; proficiency++)
   {
        if (LOWER(name[0]) == LOWER(prof_table[proficiency].name[0])
        &&  !str_prefix( name,prof_table[proficiency].name))
            return proficiency;
   }

   return -1;
}

Quest *findQuest( Character *ch, const char *name )
{
    Quest *q;

    for ( q = ch->quests ; q!=NULL ; q=q->next )
    {
        if ( LOWER(q->name[0]) == LOWER(name[0]) && !str_prefix(q->name,name) )
        {
            return q;
        }
    }

    return NULL;
}

/* returns material number */
int material_lookup (const char *name)
{
    int mat;

    for ( mat = 0; material_type[mat].name != NULL && material_type[mat].name[0] != '\0'; mat++)
    {
    if (name[0] == material_type[mat].name[0]
    && !str_prefix(name,material_type[mat].name))
        return mat;
    }

    return -1;
}

int deity_lookup( const char *name)
{
   int deity;

   for ( deity = 0; deity_table[deity].name != NULL; deity++)
   {
        if (LOWER(name[0]) == LOWER(deity_table[deity].name[0])
        &&  !str_prefix( name,deity_table[deity].name))
            return deity;
   }

   return -1;
}

/* returns race number */
int race_lookup (const char *name)
{
   int race;

   for ( race = 0; race_table[race].name != NULL; race++)
   {
    if (LOWER(name[0]) == LOWER(race_table[race].name[0])
    &&  !str_prefix( name,race_table[race].name))
        return race;
   }

   return 0;
}

/* returns subrace number */
int subrace_lookup (const char *name)
{
   int subrace;

   for ( subrace = 1; subrace_table[subrace].name != NULL; subrace++)
   {
        if (LOWER(name[0]) == LOWER(subrace_table[subrace].name[0])
        &&  !str_prefix( name,subrace_table[subrace].name))
        {
            return subrace;
        }
   }

    return -1;
}

int liq_lookup (const char *name)
{
    int liq;

    for ( liq = 0; liq_table[liq].liq_name != NULL; liq++)
    {
    if (LOWER(name[0]) == LOWER(liq_table[liq].liq_name[0])
    && !str_prefix(name,liq_table[liq].liq_name))
        return liq;
    }

    return -1;
}

int weapon_lookup (const char *name)
{
    int type;

    for (type = 0; weapon_table[type].name != NULL; type++)
    {
    if (LOWER(name[0]) == LOWER(weapon_table[type].name[0])
    &&  !str_prefix(name,weapon_table[type].name))
        return type;
    }

    return -1;
}

int item_lookup(const char *name)
{
    int type;

    for (type = 0; item_table[type].name != NULL; type++)
    {
        if (LOWER(name[0]) == LOWER(item_table[type].name[0])
        &&  !str_prefix(name,item_table[type].name))
            return item_table[type].type;
    }

    return -1;
}

int attack_lookup  (const char *name)
{
    int att;

    for ( att = 0; attack_table[att].name != NULL; att++)
    {
    if (LOWER(name[0]) == LOWER(attack_table[att].name[0])
    &&  !str_prefix(name,attack_table[att].name))
        return att;
    }

    return 0;
}

long pnet_lookup(const char *name)
{   
    int flag;
    
    for (flag = 0; pnet_table[flag].name != NULL; flag++)
    {   
    if (LOWER(name[0]) == LOWER(pnet_table[flag].name[0])
    && !str_prefix(name,pnet_table[flag].name))
        return flag;
    }

    return -1;
}

/* returns a flag for wiznet */
long wiznet_lookup (const char *name)
{
    int flag;

    for (flag = 0; wiznet_table[flag].name != NULL; flag++)
    {
    if (LOWER(name[0]) == LOWER(wiznet_table[flag].name[0])
    && !str_prefix(name,wiznet_table[flag].name))
        return flag;
    }

    return -1;
}

/* returns class number */
int class_lookup (const char *name)
{
   int class;

   for ( class = 0; class < MAX_CLASS; class++)
   {
        if (LOWER(name[0]) == LOWER(class_table[class].name[0])
        &&  !str_prefix( name,class_table[class].name))
            return class;
   }

   return -1;
}


