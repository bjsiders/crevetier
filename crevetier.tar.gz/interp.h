/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,	   *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *									   *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael	   *
 *  Chastain, Michael Quan, and Mitchell Tse.				   *
 *									   *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc	   *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.						   *
 *									   *
 *  Much time and thought has gone into this software and you are	   *
 *  benefitting.  We hope that you share your changes too.  What goes	   *
 *  around, comes around.						   *
 ***************************************************************************/
 
/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#ifndef interp_h
#define interp_h

/* this is a listing of all the commands and command related data */

/* wrapper function for safe command execution */
#define DECLARE_DO_FUN( fun )       DoFun       fun

/* for command types */
#define ML 	MAX_LEVEL	/* implementor */
#define L1	MAX_LEVEL - 1  	/* creator */
#define L2	MAX_LEVEL - 2	/* supreme being */
#define L3	MAX_LEVEL - 3	/* deity */
#define L4 	MAX_LEVEL - 4	/* god */
#define L5	MAX_LEVEL - 5	/* immortal */
#define L6	MAX_LEVEL - 6	/* demigod */
#define L7	MAX_LEVEL - 7	/* angel */
#define L8	MAX_LEVEL - 8	/* avatar */
#define IM	LEVEL_IMMORTAL 	/* avatar */
#define HE	LEVEL_HERO	/* hero */

#define COM_INGORE	1


/*
 * Structure for a command in the command lookup table.
 */
struct	cmd_type
{
    char * const	name;
    DoFun *		do_fun;
    sh_int		position;
    sh_int		level;
	long		flags;
	long		cmd_category;
	sh_int *	gsn_skill;
	sh_int		skill_level;
};

struct create_cmd_type
{
    char * const    name;
    DoFun *         func_ptr;
};
    
#define CMD_CHAN_GLOBAL			(A)
#define CMD_CHAN_LOCAL			(B)
#define CMD_CHAN_OPTION 		(C)
#define CMD_SPOOL				(D)
#define CMD_SPOOL_CONTROL 		(E)
#define CMD_SPOOL_VIOLATION 	(F)
#define CMD_SKILL				(G)
#define CMD_COMBAT				(H)
#define CMD_MAGIC				(I)
#define CMD_OPTION				(J)
#define CMD_NPC_INTERACTION		(K)
#define CMD_TRADESKILL			(L)
#define CMD_INFO_INGAME			(M)
#define CMD_INFO_OBJECT			(N)
#define CMD_INFO_HOC			(O)
#define CMD_INFO_CHAR			(P)
#define CMD_WORLD				(Q)
#define CMD_WORLD_OBJECT		(R)
#define CMD_WORLD_DOOR			(S)
#define CMD_WORLD_EQUIP			(T)
#define CMD_WORLD_POS			(U)
#define CMD_CHAR				(V)
#define CMD_ROUNDTABLE			(W)
#define CMD_GROUP				(X)
#define CMD_GUILD				(Y)
#define CMD_MOVEMENT			(Z)
#define CMD_MISC				(aa)

#define WIZCMD_GAME_CONTROL		(A)
#define WIZCMD_GAME_INFO		(B)
#define WIZCMD_PUNISHMENTS		(C)
#define WIZCMD_SITE_PUNISHMENTS	(D)
#define WIZCMD_GUILD    		(E)
#define WIZCMD_SPOOLS   		(F)
#define WIZCMD_CHANNELS 		(G)
#define WIZCMD_CUSTOMER_SERVICE	(H)
#define WIZCMD_VISIBILITY		(I)
#define WIZCMD_SNOOP_COMMANDS	(J)
#define WIZCMD_ECHOS    		(K)
#define WIZCMD_SERVER_SETTINGS	(L)
#define WIZCMD_SERVER_INFO		(M)
#define WIZCMD_SERVER_CONTROL	(N)
#define WIZCMD_FILE_GENERATION  (O)
#define WIZCMD_MISC     		(P)

#define	LOG_ALWAYS		(A)
#define LOG_NORMAL		(B)
#define LOG_NEVER		(C)
#define NOSHOW			(D)
#define NOCHARM			(E)
#define NOHIDE 			(F)
#define NOSPAM			(G)

/* the command table itself */
extern	const	struct	cmd_type	cmd_table	[];
extern  const   struct  create_cmd_type create_cmd_table [];

void do_function (Character *ch, DoFun *do_fun, char *argument);

/*
 * Command functions.
 * Defined in act_*.c (mostly).
 */
DECLARE_DO_FUN(	do_advance	);
DECLARE_DO_FUN( do_affects	);
DECLARE_DO_FUN( do_afk		);
DECLARE_DO_FUN( do_alia		);
DECLARE_DO_FUN( do_alias	);
DECLARE_DO_FUN(	do_allow	);
DECLARE_DO_FUN( do_answer	);
DECLARE_DO_FUN(	do_areas	);
DECLARE_DO_FUN(	do_at		);
DECLARE_DO_FUN(	do_auction	);
DECLARE_DO_FUN(	do_backstab	);
DECLARE_DO_FUN(	do_bamfin	);
DECLARE_DO_FUN(	do_bamfout	);
DECLARE_DO_FUN(	do_ban		);
DECLARE_DO_FUN( do_bash		);
DECLARE_DO_FUN( do_berserk	);
DECLARE_DO_FUN(	do_brandish	);
DECLARE_DO_FUN(	do_buy		);
DECLARE_DO_FUN( do_cancel   );
DECLARE_DO_FUN(	do_cast		);
DECLARE_DO_FUN( do_changes	);
DECLARE_DO_FUN( do_channels	);
DECLARE_DO_FUN( do_clone	);
DECLARE_DO_FUN(	do_close	);
DECLARE_DO_FUN(	do_commands	);
DECLARE_DO_FUN(	do_compare	);
DECLARE_DO_FUN(	do_consider	);
DECLARE_DO_FUN( do_count	);
DECLARE_DO_FUN(	do_credits	);
DECLARE_DO_FUN( do_cstat	);
DECLARE_DO_FUN( do_deaf		);
DECLARE_DO_FUN( do_delet	);
DECLARE_DO_FUN( do_delete	);
DECLARE_DO_FUN(	do_deny		);
DECLARE_DO_FUN(	do_description	);
DECLARE_DO_FUN( do_dirt		);
DECLARE_DO_FUN(	do_disarm	);
DECLARE_DO_FUN(	do_disconnect	);
DECLARE_DO_FUN(	do_down		);
DECLARE_DO_FUN(	do_drink	);
DECLARE_DO_FUN(	do_drop		);
DECLARE_DO_FUN( do_dump		);
DECLARE_DO_FUN(	do_east		);
DECLARE_DO_FUN(	do_eat		);
DECLARE_DO_FUN(	do_echo		);
DECLARE_DO_FUN(	do_emote	);
DECLARE_DO_FUN( do_enter	);
DECLARE_DO_FUN( do_envenom	);
DECLARE_DO_FUN(	do_equipment	);
DECLARE_DO_FUN(	do_examine	);
DECLARE_DO_FUN(	do_exits	);
DECLARE_DO_FUN(	do_fill		);
DECLARE_DO_FUN( do_flag		);
DECLARE_DO_FUN(	do_flee		);
DECLARE_DO_FUN(	do_follow	);
DECLARE_DO_FUN(	do_force	);
DECLARE_DO_FUN(	do_freeze	);
DECLARE_DO_FUN( do_friend	);
DECLARE_DO_FUN( do_gain		);
DECLARE_DO_FUN(	do_get		);
DECLARE_DO_FUN(	do_give		);
DECLARE_DO_FUN( do_gossip	);
DECLARE_DO_FUN(	do_goto		);
DECLARE_DO_FUN( do_grats	);
DECLARE_DO_FUN(	do_group	);
DECLARE_DO_FUN( do_groups	);
DECLARE_DO_FUN(	do_gtell	);
DECLARE_DO_FUN( do_zgui		);
DECLARE_DO_FUN( do_guild    	);
DECLARE_DO_FUN( do_guildcommand	);
DECLARE_DO_FUN( do_heal		);
DECLARE_DO_FUN(	do_help		);
DECLARE_DO_FUN(	do_hide		);
DECLARE_DO_FUN(	do_idea		);
DECLARE_DO_FUN(	do_immtalk	);
DECLARE_DO_FUN( do_incognito	);
DECLARE_DO_FUN( do_initialize_gui	);
DECLARE_DO_FUN( do_clantalk	);
DECLARE_DO_FUN( do_imotd	);
DECLARE_DO_FUN(	do_inventory	);
DECLARE_DO_FUN(	do_invis	);
DECLARE_DO_FUN(	do_kick		);
DECLARE_DO_FUN(	do_kill		);
DECLARE_DO_FUN(	do_list		);
DECLARE_DO_FUN( do_load		);
DECLARE_DO_FUN(	do_lock		);
DECLARE_DO_FUN(	do_log		);
DECLARE_DO_FUN(	do_look		);
DECLARE_DO_FUN(	do_memory	);
DECLARE_DO_FUN(	do_mfind	);
DECLARE_DO_FUN( do_bset		);
DECLARE_DO_FUN( do_gset     );
DECLARE_DO_FUN(	do_mset		);
DECLARE_DO_FUN(	do_mstat	);
DECLARE_DO_FUN(	do_mwhere	);
DECLARE_DO_FUN( do_motd		);
DECLARE_DO_FUN(	do_murde	);
DECLARE_DO_FUN(	do_murder	);
DECLARE_DO_FUN( do_music	);
DECLARE_DO_FUN( do_newlock	);
DECLARE_DO_FUN( do_news		);
DECLARE_DO_FUN( do_nochannels	);
DECLARE_DO_FUN(	do_noemote	);
DECLARE_DO_FUN(	do_north	);
DECLARE_DO_FUN(	do_noshout	);
DECLARE_DO_FUN(	do_note		);
DECLARE_DO_FUN(	do_notell	);
DECLARE_DO_FUN(	do_ofind	);
DECLARE_DO_FUN(	do_open		);
DECLARE_DO_FUN(	do_order	);
DECLARE_DO_FUN(	do_oset		);
DECLARE_DO_FUN(	do_ostat	);
DECLARE_DO_FUN( do_owhere	);
DECLARE_DO_FUN(	do_pardon	);
DECLARE_DO_FUN(	do_password	);
DECLARE_DO_FUN(	do_peace	);
DECLARE_DO_FUN( do_pecho	);
DECLARE_DO_FUN( do_penalty	);
DECLARE_DO_FUN( do_permban	);
DECLARE_DO_FUN(	do_pick		);
DECLARE_DO_FUN( do_play		);
DECLARE_DO_FUN( do_pmote	);
DECLARE_DO_FUN(	do_pose		);
DECLARE_DO_FUN( do_pour		);
DECLARE_DO_FUN(	do_practice	);
DECLARE_DO_FUN( do_prompt	);
DECLARE_DO_FUN( do_protect	);
DECLARE_DO_FUN(	do_purge	);
DECLARE_DO_FUN(	do_put		);
DECLARE_DO_FUN( do_qstat	);
DECLARE_DO_FUN(	do_quaff	);
DECLARE_DO_FUN( do_question	);
DECLARE_DO_FUN(	do_qui		);
DECLARE_DO_FUN( do_quiet	);
DECLARE_DO_FUN(	do_quit		);
DECLARE_DO_FUN( do_read		);
DECLARE_DO_FUN(	do_reboo	);
DECLARE_DO_FUN(	do_reboot	);
DECLARE_DO_FUN(	do_recall	);
DECLARE_DO_FUN(	do_recho	);
DECLARE_DO_FUN(	do_recite	);
DECLARE_DO_FUN(	do_remove	);
DECLARE_DO_FUN(	do_rent		);
DECLARE_DO_FUN( do_replay	);
DECLARE_DO_FUN(	do_reply	);
DECLARE_DO_FUN(	do_report	);
DECLARE_DO_FUN(	do_rescue	);
DECLARE_DO_FUN(	do_rest		);
DECLARE_DO_FUN(	do_restore	);
DECLARE_DO_FUN(	do_return	);
DECLARE_DO_FUN(	do_rset		);
DECLARE_DO_FUN(	do_rstat	);
DECLARE_DO_FUN(	do_rt		);
DECLARE_DO_FUN(	do_rtcommand);
DECLARE_DO_FUN( do_rtlist	);
DECLARE_DO_FUN( do_rules	);
DECLARE_DO_FUN(	do_sacrifice	);
DECLARE_DO_FUN(	do_save		);
DECLARE_DO_FUN(	do_say		);
DECLARE_DO_FUN(	do_scan		);
DECLARE_DO_FUN(	do_score	);
DECLARE_DO_FUN( do_scroll	);
DECLARE_DO_FUN(	do_sell		);
DECLARE_DO_FUN( do_set		);
DECLARE_DO_FUN(	do_shutdow	);
DECLARE_DO_FUN(	do_shutdown	);
DECLARE_DO_FUN( do_signature );
DECLARE_DO_FUN( do_sit		);
DECLARE_DO_FUN( do_skills	);
DECLARE_DO_FUN(	do_sla		);
DECLARE_DO_FUN(	do_slay		);
DECLARE_DO_FUN(	do_sleep	);
DECLARE_DO_FUN(	do_slookup	);
DECLARE_DO_FUN( do_smote	);
DECLARE_DO_FUN(	do_sneak	);
DECLARE_DO_FUN(	do_snoop	);
DECLARE_DO_FUN( do_socials	);
DECLARE_DO_FUN(	do_south	);
DECLARE_DO_FUN( do_sockets	);
DECLARE_DO_FUN( do_spells	);
DECLARE_DO_FUN(	do_split	);
DECLARE_DO_FUN(	do_sset		);
DECLARE_DO_FUN(	do_stand	);
DECLARE_DO_FUN( do_stat		);
DECLARE_DO_FUN(	do_steal	);
DECLARE_DO_FUN( do_story	);
DECLARE_DO_FUN( do_string	);
DECLARE_DO_FUN(	do_sub		); //RT function
DECLARE_DO_FUN(	do_switch	);
DECLARE_DO_FUN(	do_tell		);
DECLARE_DO_FUN(	do_time		);
DECLARE_DO_FUN(	do_title	);
DECLARE_DO_FUN(	do_train	);
DECLARE_DO_FUN(	do_transfer	);
DECLARE_DO_FUN( do_trip		);
DECLARE_DO_FUN(	do_trust	);
DECLARE_DO_FUN(	do_typo		);
DECLARE_DO_FUN( do_unalias	);
DECLARE_DO_FUN(	do_unlock	);
DECLARE_DO_FUN( do_unread	);
DECLARE_DO_FUN(	do_up		);
DECLARE_DO_FUN(	do_value	);
DECLARE_DO_FUN(	do_visible	);
DECLARE_DO_FUN( do_violate	);
DECLARE_DO_FUN( do_vnum		);
DECLARE_DO_FUN( do_version	);
DECLARE_DO_FUN(	do_wake		);
DECLARE_DO_FUN(	do_wear		);
DECLARE_DO_FUN(	do_weather	);
DECLARE_DO_FUN(	do_west		);
DECLARE_DO_FUN(	do_where	);
DECLARE_DO_FUN(	do_who		);
DECLARE_DO_FUN( do_whois	);
DECLARE_DO_FUN(	do_wimpy	);
DECLARE_DO_FUN( do_wizclan	);
DECLARE_DO_FUN(	do_wizhelp	);
DECLARE_DO_FUN(	do_wizlock	);
DECLARE_DO_FUN( do_wizlist	);
DECLARE_DO_FUN( do_wiznet	);
DECLARE_DO_FUN(	do_yell		);
DECLARE_DO_FUN(	do_zap		);
DECLARE_DO_FUN( do_zecho	);

DECLARE_DO_FUN( do_pload	);
DECLARE_DO_FUN( do_punload	);
DECLARE_DO_FUN( do_hedit        );

DECLARE_DO_FUN( do_admin	);
DECLARE_DO_FUN( do_bug		);
DECLARE_DO_FUN( do_cnote	);
DECLARE_DO_FUN( do_anote	);
DECLARE_DO_FUN( do_appeal	);
DECLARE_DO_FUN( do_port		);
DECLARE_DO_FUN( do_showresets	);
DECLARE_DO_FUN( do_spell_lookup	);
DECLARE_DO_FUN( do_openvnum	);
DECLARE_DO_FUN( do_arealist	);
DECLARE_DO_FUN( do_joi	);
DECLARE_DO_FUN( do_join		);
DECLARE_DO_FUN( do_average	);
DECLARE_DO_FUN( do_abilities	);
DECLARE_DO_FUN( do_convert );
DECLARE_DO_FUN( do_rename );
DECLARE_DO_FUN( do_apply	);
DECLARE_DO_FUN( do_craft		);
DECLARE_DO_FUN( do_quest	);
DECLARE_DO_FUN( do_ooctalk	);
DECLARE_DO_FUN( do_invite	);
DECLARE_DO_FUN( do_disband	);
DECLARE_DO_FUN( do_accept	);
DECLARE_DO_FUN( do_custom	);
DECLARE_DO_FUN( do_surname	);
DECLARE_DO_FUN( do_sum );
DECLARE_DO_FUN( do_spellset	);
DECLARE_DO_FUN( do_recruiter	);
DECLARE_DO_FUN( do_worth	);
DECLARE_DO_FUN( do_outfit	);
DECLARE_DO_FUN( do_destro	);
DECLARE_DO_FUN( do_destroy	);
DECLARE_DO_FUN( do_lore );
DECLARE_DO_FUN( do_peek );
DECLARE_DO_FUN( do_release );
DECLARE_DO_FUN( do_fix	);
DECLARE_DO_FUN( do_spool );
DECLARE_DO_FUN( do_resist );
DECLARE_DO_FUN( do_expsplit );
DECLARE_DO_FUN( do_finger );
DECLARE_DO_FUN( do_todo	);
DECLARE_DO_FUN( do_reveal );
DECLARE_DO_FUN( do_patch );
DECLARE_DO_FUN( do_layonhands );
DECLARE_DO_FUN( do_reuse );
DECLARE_DO_FUN( do_pnet );
DECLARE_DO_FUN( do_options );
DECLARE_DO_FUN( do_limits );
DECLARE_DO_FUN( do_passwd );
DECLARE_DO_FUN( do_scribe );
DECLARE_DO_FUN( do_library );
DECLARE_DO_FUN( do_ask );
DECLARE_DO_FUN( do_lastlevel );
DECLARE_DO_FUN( do_lastlogin );
DECLARE_DO_FUN( do_factions );
DECLARE_DO_FUN( do_fedit );
DECLARE_DO_FUN( do_first_aid );
DECLARE_DO_FUN( do_showspawns );
DECLARE_DO_FUN( do_reset );
DECLARE_DO_FUN( do_refres );
DECLARE_DO_FUN( do_refresh );
DECLARE_DO_FUN( do_system );
DECLARE_DO_FUN( do_consent );
DECLARE_DO_FUN( do_reset_room );
DECLARE_DO_FUN( do_erase );
DECLARE_DO_FUN( do_sing );
DECLARE_DO_FUN( do_skin );
DECLARE_DO_FUN( do_journal );
DECLARE_DO_FUN( do_petition );
DECLARE_DO_FUN( do_grename );
DECLARE_DO_FUN( do_copy );
DECLARE_DO_FUN( do_hockey );
DECLARE_DO_FUN( do_repair );
DECLARE_DO_FUN( do_respecialize );
DECLARE_DO_FUN( do_petitio );
DECLARE_DO_FUN( do_worldnotes );
DECLARE_DO_FUN( do_styles );
DECLARE_DO_FUN( do_audit );
DECLARE_DO_FUN( do_away );
DECLARE_DO_FUN( do_legsweep );
DECLARE_DO_FUN( do_intercept );
DECLARE_DO_FUN( do_bind );
DECLARE_DO_FUN( do_quickcast );
DECLARE_DO_FUN( do_walkbuild );
DECLARE_DO_FUN( do_reinforce );
DECLARE_DO_FUN( do_palmattack );
DECLARE_DO_FUN( do_mending );
DECLARE_DO_FUN( do_paralyze );
DECLARE_DO_FUN( do_precognition );
DECLARE_DO_FUN( do_kistrike );
DECLARE_DO_FUN( do_firewithin );
DECLARE_DO_FUN( do_purge );
DECLARE_DO_FUN( do_pall );
DECLARE_DO_FUN( do_reward );
DECLARE_DO_FUN( do_unpractice );
DECLARE_DO_FUN( do_ignore );
DECLARE_DO_FUN( do_concentrate );
DECLARE_DO_FUN( do_tlr );
DECLARE_DO_FUN( do_mapspells );
DECLARE_DO_FUN( do_offlinenotes );
DECLARE_DO_FUN( do_post );
DECLARE_DO_FUN( do_teleport );
DECLARE_DO_FUN( do_shapeshift );
DECLARE_DO_FUN( do_dummy );
DECLARE_DO_FUN( do_aim );
DECLARE_DO_FUN( do_analyze );
DECLARE_DO_FUN( do_dumpspawn );
DECLARE_DO_FUN( do_mine );
DECLARE_DO_FUN( do_cut );
DECLARE_DO_FUN( do_distract );
DECLARE_DO_FUN( do_stockpile );
DECLARE_DO_FUN( do_rmap );
DECLARE_DO_FUN( do_push );
DECLARE_DO_FUN( do_hwhere );
DECLARE_DO_FUN( do_bestiary );
DECLARE_DO_FUN( do_silentcast );
DECLARE_DO_FUN( do_timezone );
DECLARE_DO_FUN( do_pledge );
DECLARE_DO_FUN( do_dload );
DECLARE_DO_FUN( do_focus );
DECLARE_DO_FUN( do_combat );

DECLARE_DO_FUN( do_asave );
DECLARE_DO_FUN( do_alist );
DECLARE_DO_FUN( do_olc );
DECLARE_DO_FUN( do_aedit );
DECLARE_DO_FUN( do_redit );
DECLARE_DO_FUN( do_medit );
DECLARE_DO_FUN( do_fedit );
DECLARE_DO_FUN( do_hedit );
DECLARE_DO_FUN( do_oedit );
DECLARE_DO_FUN( do_reset_room );
DECLARE_DO_FUN( do_alist );
DECLARE_DO_FUN( do_walkbuild );
DECLARE_DO_FUN( do_openvnum );
DECLARE_DO_FUN( do_rmap );

DECLARE_DO_FUN( do_depractice );
DECLARE_DO_FUN( do_detrain );
DECLARE_DO_FUN( do_degain );
DECLARE_DO_FUN( do_enemy );

DECLARE_DO_FUN( do_jump );
DECLARE_DO_FUN( do_climb );

DECLARE_DO_FUN( do_enablepk );
DECLARE_DO_FUN( do_enablelooting );
DECLARE_DO_FUN( do_email );

#if !defined(__ARPENS)
DECLARE_DO_FUN( do_ski );
DECLARE_DO_FUN( do_skip );
#endif

DECLARE_DO_FUN( cr_name );
DECLARE_DO_FUN( cr_gender );
DECLARE_DO_FUN( cr_race );
DECLARE_DO_FUN( cr_class );
DECLARE_DO_FUN( cr_deity );
DECLARE_DO_FUN( cr_weapon );
DECLARE_DO_FUN( cr_password );
DECLARE_DO_FUN( cr_cancel );
DECLARE_DO_FUN( cr_color );
DECLARE_DO_FUN( cr_done );
DECLARE_DO_FUN( cr_help );

#endif /* interp_h */
