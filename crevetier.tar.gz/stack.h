#ifndef stack_h
#define stack_h

#include "thoctype.h"

#define MAX_STACK   32

struct stack_type
{
    int             index;
    int             array[MAX_STACK];
};

void stackPush( Stack *s, int value );
int stackPop( Stack *s );

#endif /* stack_h */
