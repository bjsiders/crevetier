/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,		*
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *																		 *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael		  *
 *  Chastain, Michael Quan, and Mitchell Tse.							  *
 *																		 *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc	   *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.											   *
 *																		 *
 *  Much time and thought has gone into this software and you are		  *
 *  benefitting.  We hope that you share your changes too.  What goes	  *
 *  around, comes around.												  *
 ***************************************************************************/

/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*		Russ Taylor (rtaylor@hypercube.org)				   *
*		Gabrielle Taylor (gtaylor@hypercube.org)			   *
*		Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "thoc.h"
#include "recycle.h"
#include "interp.h"
#include "tables.h"
#include "styles.h"
#include "options.h"
#include "db.h"

#define	THRESHOLD_GROUP_XP	4

/*
 * Local functions.
 */
int 	countAttackers( Character *victim );
void 	check_condition( Character *ch, Object *obj );
bool 	check_phantasmal_defender( Character *ch, Character *victim );
void 	checkForHides( Character *victim, Object *corpse );
void 	checkForVenom( Character *victim, Object *corpse );
Object 	*create_sac( Object *corpse, Character *victim, int vnum );
int		modify_for_resists( Character *ch, int dam, int damage_type );
bool	check_double_attack	( Character *, Character * );
void	drainStamina( Character *ch, int amount );

void	processAttack	( Character *ch  );
void	processDualWield	( Character *ch  );
void	check_assist	( Character *ch, Character *victim  );
bool	check_fade	( Character *ch, Character *victim  );
bool	check_dodge	( Character *ch, Character *victim  );
void	check_killer	( Character *ch, Character *victim  );
bool	check_parry	( Character *ch, Character *victim  );
bool 	check_intercept( Character *ch, Character *victim );
bool	check_shield_block	 ( Character *ch, Character *victim  );
void	dam_message 	( Character *ch, Character *victim, int dam, int dt, bool immune, bool fSpell, bool fDual, bool fRange  );
void	death_cry	( Character *ch  );
void	group_gain	( Character *ch, Character *victim  );
int		xp_compute	( Character *gch, Character *victim, 
				int total_levels  );
bool	is_safe		( Character *ch, Character *victim  );
void	make_corpse	( Character *ch, bool fLootTable  );
void	one_hit		( Character *ch, Character *victim, int dt  );
void	raw_kill	( Character *victim, bool fLootTable  );
void	set_fighting	( Character *ch, Character *victim  );
void	disarm		( Character *ch, Character *victim  );
void	set_NPC_disposition( Character *v );
int 	modifyDamageForSkill( int dam, int ratio );
Object *findAmmo( Character *ch, bool fPull );
void    npc_ai_combat( Character *ch );

int weaponProfAdj( Character *ch, int fDual )
{
    Object *weapon;
    int focus_ranks;

    if ( (weapon = get_eq_char(ch,fDual?WEAR_OFFHAND:WEAR_WIELD)) == NULL ||
        !IS_SET(class_table[ch->class].flags,CLA_CAN_FOCUS) )
        return 100;

    // NPCs are assumed to be well-focused.
    // All melees are maxed, rogues are - 1, divine -2, arcane not at all
    if ( IS_NPC(ch) )
    {
        focus_ranks = ch->level/9;
        if ( class_table[ch->class].group == MELEE )
            focus_ranks = ch->level/9;
        else
        if ( class_table[ch->class].group == STEALTH )
            focus_ranks = ch->level/9 - 1;
        else
        if ( class_table[ch->class].group == DIVINE )
            focus_ranks = ch->level/9 - 2;
        else
            focus_ranks = ch->level/9 - 3;

        focus_ranks = UMAX(0,focus_ranks);
    }
    else
    {
        // For players, if they're NOT specialized in this weapon, we may have to
        // check the weapon group.
        focus_ranks = ch->pcdata->specialized[ get_weapon_index(weapon->value[0]) ];
        if ( focus_ranks == 0 )
        {
            int totalRanks = 0;
            bool fHasGroupFocus = FALSE;
            int i;

            // go through specs and check for ANY focus and same-group focus.
            for(i=0;i<MAX_WEAPONS;i++)
            {
                if ( weapon_table[i].name == NULL )
                    break;
                else
                if ( ch->pcdata->specialized[i] )
                {
                    totalRanks += ch->pcdata->specialized[i];
                    if ( weapon_table[i].gsn == weapon_table[get_weapon_index(weapon->value[0])].gsn )
                        fHasGroupFocus = TRUE;
                }
            }

            // If this one is grouped, it's only -3, otherwise it's -6
            if ( fHasGroupFocus )
                return ( 100 - (totalRanks * 3));
            else
                return ( 100 - (totalRanks * 6));
        }
    }

    return ( 100 + (focus_ranks*6) );
}

/*
 * Control the fights going on.
 * Called periodically by update_handler.
 */
void violence_update( void )
{
	Character *ch;
	Character *ch_next;
	Character *victim;

	/* This is our chance to update NPC stuff */
	for ( ch = char_list; ch != NULL; ch = ch->next )
	{
		ch_next	= ch->next;

		if ( ch->wait > 0 && IS_NPC(ch) )
			--ch->wait;

		if ( ch->daze > 0 && IS_NPC(ch) )
			--ch->daze;

		if ( IS_NPC(ch) && ch->reuse_wait != NULL )
			update_npc_reuse( ch );

        // Check for an NPC chaser
        if ( IS_NPC(ch) && ch->pursuit.index > 0 && number_percent() < 10 && ch->fighting == NULL &&
             !IS_AFFECTED(ch,AFF_MESMERIZE) )
        {
            // We're in hot pursuit of somebody!
            int i;
            int vnum = ch->pursuit.array[--ch->pursuit.index];
            Exit *e;
            Room *r;

            // Find the vnum to move to
            for( i=0 ; i<6 ; i++ )
            {
                if ( ( e = ch->in_room->exit[i] ) != NULL && ( r = e->u1.to_room ) != NULL && r->vnum == vnum )
                {
                    int vnum = ch->in_room->vnum;

                    if ( !move_char( ch, i, TRUE ) )
                    {
                        log_string("Stranded pursuit NPC %d %s in room %d", ch->pIndexData->vnum, ch->short_descr, r->vnum );
                        memset( &(ch->pursuit), 0, sizeof(ch->pursuit) );
                    }
                    else
                        // Add to the return path
                        ch->pathing.array[ch->pathing.index++] = vnum;
                    break;
                }
            }    
        } // End NPC pursuit

		if ( ( victim = ch->fighting ) == NULL ||
                ch->in_room == NULL ||
                ch->wait > 0 || ch->daze > 0 || IS_AFFECTED(ch,AFF_MESMERIZE) )
			continue;

        // Check for bashes and kicks and spellcasting and stuff
        if ( IS_NPC(ch) )
            npc_ai_combat(ch);

		/* PC's attack if they're not casting, not dazed, and not in reuse delay */
		if ( (!IS_NPC(ch) && !IS_SET(ch->act,PLR_IS_CASTING) && ch->daze < 1) || IS_NPC(ch) )
		{
			if ( !REUSE_SKILL(ch,get_weapon_sn(ch,GET_WEAPON_SN)) )
				processAttack(ch);

			/* Check for dual wield */
			if ( (get_eq_char(ch,WEAR_OFFHAND)) && get_skill(ch,gsn_dual_wield) > 0 && !REUSE_SKILL(ch,gsn_dual_wield) )
				processDualWield(ch);
		}

	if ( !IS_AWAKE(ch) || ch->in_room != victim->in_room ) 
		stop_fighting( ch, FALSE );

	if ( ( victim = ch->fighting ) == NULL )
		continue;

	/*
	 * Fun for the whole family!
	 */

	check_assist(ch,victim);
	}

	return;
}

/* for auto assisting */
void check_assist(Character *ch,Character *victim)
{
	Character *rch, *rch_next;

	/* Can't assist if you're not fightin' */
	switch( ch->position )
	{
	case POS_SLEEPING:
	case POS_RESTING:
	case POS_SITTING:
		return;
	}

	/* check everybody else in the room */
	for (rch = ch->in_room->people; rch != NULL; rch = rch_next)
	{
		rch_next = rch->next_in_room;

		/* Mez'd characters won't attack */
		if ( IS_AFFECTED(rch,AFF_MESMERIZE) )
			continue;
	
		if ( !IS_AWAKE(rch) || rch->fighting != NULL)
			continue;

		/* Guards always back each other up */
		/* If they are same-aligned */
		if ( IS_NPC(rch) && IS_SET(rch->act,ACT_GUARD) )
		{
			if ( IS_NPC(ch) && IS_SET(ch->act,ACT_GUARD) && 
                 ch->pIndexData->alignment == rch->pIndexData->alignment )
			{
				if( rch->pIndexData->attack_echo != NULL )
                	act(rch->pIndexData->attack_echo,rch,NULL,victim,TO_ROOM);
            	else
            	{
                	act("$N moves to assist you!",ch,NULL,rch,TO_CHAR);
                	act("You move to assist $n.",ch,NULL,rch,TO_VICT);
                	act("$N moves to assist $n.",ch,NULL,rch,TO_NOTVICT);
            	}
            	one_hit(rch,victim,TYPE_UNDEFINED);
				continue;
			}
			else
			if ( IS_NPC(victim) && IS_SET(victim->act,ACT_GUARD) && 
                 victim->pIndexData->alignment == rch->pIndexData->alignment )
            {
                if( rch->pIndexData->attack_echo != NULL )
                    act(rch->pIndexData->attack_echo,rch,NULL,ch,TO_ROOM);
                else
                {
                    act("$N moves to assist you!",victim,NULL,rch,TO_CHAR);
                    act("You move to assist $N.",victim,NULL,rch,TO_VICT);
                    act("$N moves to assist $n.",victim,NULL,rch,TO_NOTVICT);
                }
                one_hit(rch,ch,TYPE_UNDEFINED);
				continue;
            }
		}


		/* NPCs that assist players */
		if (	!IS_NPC(ch) && IS_NPC(rch) 
		&& IS_SET(rch->off_flags,ASSIST_PLAYERS)
		&&  rch->level + 6 > victim->level)
		{
			/* check for attack message */
			if( rch->pIndexData->attack_echo != NULL )
				act(rch->pIndexData->attack_echo,rch,NULL,victim,TO_ROOM);
			else
			{
				act("$N moves to assist you!",ch,NULL,rch,TO_CHAR);
				act("You move to assist $n.",ch,NULL,rch,TO_VICT);
				act("$N moves to assist $n.",ch,NULL,rch,TO_NOTVICT);
			}
			one_hit(rch,victim,TYPE_UNDEFINED);
			continue;
		}
	
		/* PCs and charmed PCs/NPCs */
		if (!IS_NPC(ch) || IS_AFFECTED(ch,AFF_CHARM))
		{
			if ( !IS_NPC(rch) && (IS_SET(rch->act,PLR_IS_CASTING)||
                                  IS_SET(rch->act,PLR_IS_CRAFTING)) )
				continue;

			/* If they're set to autoassist or this person is charmed */
			if ( ( (!IS_NPC(rch) && HAS_AUTOOPT(rch, AUTO_ASSIST) )
			||	 IS_AFFECTED(rch,AFF_CHARM)) 

			/* and same group or pet */
			&&   ( is_same_group(ch,rch) || ch->pet == rch )

			/* and victim is not safe from me */
			&&   !is_safe(rch, victim)

			/* and this guy is standing */
			&&   rch->position == POS_STANDING )
				one_hit (rch,victim,TYPE_UNDEFINED);

			continue;
		}
	 	 
		/* now check the NPC cases */
 		if ( !IS_NPC(ch) || IS_AFFECTED(ch,AFF_CHARM))
			continue;

		if ( 	
			/* NPC is assist all */
			(IS_NPC(rch) && IS_SET(rch->off_flags,ASSIST_ALL))

			/* or npcs are grouped */
			||  (IS_NPC(rch) && rch->group && rch->group == ch->group)

			/* or races are the same and assist race is set */
			||  (IS_NPC(rch) && rch->race == ch->race 
	   		&&   IS_SET(rch->off_flags,ASSIST_RACE))

			/* or aligns are the same and assist align is set */
			||  (IS_NPC(rch) && IS_SET(rch->off_flags,ASSIST_ALIGN)
	   		&&  ((IS_GOOD(rch)	&& IS_GOOD(ch))
		 	||  (IS_EVIL(rch)	&& IS_EVIL(ch))
		 	||  (IS_NEUTRAL(rch) && IS_NEUTRAL(ch)))) 

			/* or vnums are the same and assist vnum is set */
			||   (rch->pIndexData == ch->pIndexData 
	   		&& IS_SET(rch->off_flags,ASSIST_VNUM))

			/* or they're in allied factions and assis_faction is set */
			|| ( are_allies(rch,ch) && IS_SET(rch->off_flags,ASSIST_FACTION) )
		  )
	   	{
			Character *vch;
			Character *target;
			int number;

			if (number_bits(1) == 0)
				continue;
		
			target = NULL;
			number = 0;
			for (vch = ch->in_room->people; vch; vch = vch->next)
			{
				if (can_see(rch,vch)
					&&  is_same_group(vch,victim)
					&&  number_range(0,number) == 0)
				{
					target = vch;
					number++;
				}
			}

			if (target != NULL)
			{
         		/* check for attack message */  
            	if( rch->pIndexData->attack_echo != NULL )
                	act(rch->pIndexData->attack_echo,rch,NULL,victim,TO_ROOM);
            	else
                	do_function(rch, &do_emote, "screams and attacks!");

				one_hit(rch,target,TYPE_UNDEFINED);
			}
		}	
	} /* big outer for loop */
}


void processAttack( Character *ch )
{
	Character *victim;
	int skill;

	victim = ch->fighting;

	if ( victim == NULL || victim->in_room != ch->in_room )
		return;

	one_hit(ch,victim,TYPE_UNDEFINED);

	/* Check for double attack */
	if (ch->fighting != victim )
		return;

	if ( (skill=get_skill(ch,gsn_double_strike)) > 1 && ch->stamina > 2 )
	{
		int  chance;

		drainStamina( ch, 2 );
		chance = 50;
		applySkillAdjust( &chance, 50, skill, ch->level );
		chance += applyLevelDifference(ch->level,victim->level);

		if ( number_percent() < chance )
			one_hit(ch,victim,TYPE_DOUBLE_STRIKE);
	}
	
	return;
}

void processDualWield( Character *ch )
{
	int chance, skill;
	Object *offhander;
	Character *victim;

	if ( (victim=ch->fighting) == NULL || victim->in_room != ch->in_room || ch->stamina < 1 )
		return;
	
	offhander = get_eq_char(ch,WEAR_OFFHAND);
	chance = 50;
	applySkillAdjust( &chance, 100, (skill = get_skill(ch,gsn_dual_wield)), ch->level );
	chance += applyLevelDifference(ch->level,victim->level);

	if ( number_percent() < chance )
		one_hit(ch,victim,gsn_dual_wield);

	if ( !IS_NPC(ch) )
	{
		float delay;

		/* what a fucking disaster this is */
		delay = 150.0 - ( 25.0* (float) skill / (float) ch->level );
		if ( get_eq_char(ch,WEAR_SHIELD) != NULL )
		{
			delay *= 1.5;
			drainStamina(ch,1);
		}
		delay /= 100;

        if ( isSpeciesEnemy(victim,ch) )
            delay = 4*delay/5; // 20% bonus with offhand for the spec enemy

		setSkillReuseWait( ch, gsn_dual_wield, offhander->value[5] * delay );
	}
	return;
}

/*
 * Hit one guy once.
 */
void one_hit( Character *ch, Character *victim, int dt )
{
	Object *wield;
	int crit_range;
	int victim_ac;
	int dam;
	int tohit;
	int sn,skill;
	int dam_type;
	bool result;
	int fCritical = FALSE;
    int topDiceRange;
	int fDual = FALSE;
	int fDouble = FALSE;
	int delay = 32;
	int style;
	int base_dam;
	int attackers=0;

	if ( dt == TYPE_DOUBLE_STRIKE )
	{
		dt = TYPE_UNDEFINED;
		fDouble = TRUE;
	}

	sn = -1;
	if ( dt == gsn_dual_wield )
	{
		fDual = TRUE;
		dt = TYPE_UNDEFINED;
	}

	/* just in case */
	if (victim == ch || ch == NULL || victim == NULL)
		return;

	/*
	 * Can't beat a dead char!
	 * Guard against weird room-leavings.
	 */
	if ( victim->position == POS_DEAD || ch->in_room != victim->in_room )
		return;

	/* We're committed from here on out.  Handle combat styles. */
	if ( (style=ch->style) > 0 && !fDual && !fDouble )
	{
		ch->style = 0;
		/* Check re-req's */
		if ( !can_use_style(ch,victim,style) )
		{
			clear_style(ch);
			style = STYLE_FAIL;
		}
		else
			set_style(ch,victim,style);
	}
	/* End combat styles */

	/*
	 * Figure out the type of damage message.
	 */
	wield = get_eq_char( ch, fDual ? WEAR_OFFHAND : WEAR_WIELD );

	if ( dt == TYPE_UNDEFINED )
	{
		dt = TYPE_HIT;
		if ( wield != NULL && wield->item_type == ITEM_WEAPON )
			dt += wield->value[3];
		else 
			dt += ch->dam_type;
	}

	if (dt < TYPE_HIT)
	{
		if (wield != NULL)
			dam_type = attack_table[wield->value[3]].damage;
		else
			dam_type = attack_table[ch->dam_type].damage;
	}
	else
		dam_type = attack_table[dt - TYPE_HIT].damage;

	if (dam_type == -1)
		dam_type = DAM_BASH;

	/* Check for a haste affect - doesn't affect dual wield */
	if ( IS_AFFECTED(ch,AFF_HASTE) && !fDual )
	{
		Affect *haf;

		for ( haf = ch->affected ; haf != NULL ; haf = haf->next )
		{
			if ( haf->bitvector == AFF_HASTE && haf->location == APPLY_SPEED )
			{
				ch->wait = ch->wait * haf->modifier / 100;
				break;
			}
		}
	}
	
	/* get the weapon skill */
	sn = get_weapon_sn(ch,fDual ? GET_OFFHAND_SN : GET_WEAPON_SN);
	skill = get_weapon_skill(ch,sn);

	if ( wield == NULL )
	{
		/* replace this with OLC-settable NPC attack speeds */
		if ( IS_NPC(ch) )
		{
			int wait;

			if ( ch->level < 5 )
			    wait = 45;
			else
			if ( ch->level < 20 )
				wait = 35;
			else
			if ( ch->level < 35 )
				wait = 31;
			else
				wait = 28;

			ch->wait = wait;

			/* 150% delay while intercepting */
			if ( ch->intercepting != NULL && ch->intercepting->in_room == ch->in_room )
				ch->wait = ( ch->wait * 3 / 2 );
		
			/* 125% delay while guarding */
            if ( ch->guarding != NULL && ch->guarding->in_room == ch->in_room )
                ch->wait = ( ch->wait * 5 / 4 );

			delay = wait;
		}
		else	/* monks, mostly */
		{
			int ru;

			if ( skill < (ch->level/3) )
				ru = 45;
			else
			if ( skill < (ch->level/2) )
				ru = 38;
			else
			if ( skill < (ch->level*2/3) )
				ru = 32;
			else
			if ( skill < (ch->level*3/4) )
				ru = 26;
			else
				ru = 22;

			/* 150% delay while intercepting */
            if ( ch->intercepting != NULL && ch->intercepting->in_room == ch->in_room )
                ru = ( ru * 3 / 2 );

            /* 125% delay while guarding */
            if ( ch->guarding != NULL && ch->guarding->in_room == ch->in_room )
                ru = ( ru * 5 / 4 );

			setSkillReuseWait(ch,sn,ru);
			delay = ru;
		}
	}
	else if ( !fDual )
	{
		if ( IS_NPC(ch) )
		{
			ch->wait = UMAX(wield->value[5],10);

            /* 150% delay while intercepting */
            if ( ch->intercepting != NULL && ch->intercepting->in_room == ch->in_room )
                ch->wait = ( ch->wait * 3 / 2 );

            /* 125% delay while guarding */
            if ( ch->guarding != NULL && ch->guarding->in_room == ch->in_room )
                ch->wait = ( ch->wait * 5 / 4 );

			delay = ch->wait;
		}
		else
		{
			int ru;
	
			ru = wield->value[5];

            /* 150% delay while intercepting */
            if ( ch->intercepting != NULL && ch->intercepting->in_room == ch->in_room )
                ru = ( ru * 3 / 2 );

            /* 125% delay while guarding */
            if ( ch->guarding != NULL && ch->guarding->in_room == ch->in_room )
                ru = ( ru * 5 / 4 );

			setSkillReuseWait(ch,sn,ru);
			delay = ru;
		}
	}

	/*
	 * 1. Calculate whether or not the attacker missed 
	 *
     * Attack Roll = Level + Weapon Skill + Str/Dex Mod + Random
	 */
	if ( victim->fighting != ch )
	{
		attackers = countAttackers(victim)-1;
		attackers = URANGE(0,attackers,8);
	}

  {
    int rand_num, stat;

    // Level + Skill	
	tohit = ch->level + (skill*4);

    // Stat Bonus
    if( HAS_PROF(ch,gpn_weapon_finesse) )
        tohit += (stat = (get_curr_stat(ch,STAT_DEX)-100)/2);
    else
        tohit += (stat = (get_curr_stat(ch,STAT_STR)-100)/2);

    // Randomness
    if ( ch->level <= 30 )
        topDiceRange = (ch->level*5)+50;
    else
        topDiceRange = (int)(((float)(ch->level-30))*2.5)+200;

    tohit += (rand_num = dice(1,topDiceRange));

    // Weapon Proficiency Adjustment
    tohit = ( tohit * weaponProfAdj(ch,fDual)) / 100;

    // Add hitroll
    tohit += GET_HITROLL(ch);

	// Apply style bonuses
	if ( style > 0 && !fDual  && !fDouble )
		tohit += style_table[style].attack;

    // Additional attackers make it easier to hit the enemy
    // You receive a +5% bonus to your final hitroll per
    // attacker over 1.
    if ( attackers > 1 )
        tohit = ( tohit * ( 100 + (attackers-1)*5 ) ) / 100;

    if (IS_SET(ch->display,DISP_COMBAT_DEBUG))
    {
        cprintf(ch,"Your attack: (Lv%d + Sk%d + At%d + Rn%d) * WS%.2f + HR%d + St%d = %d\n\r",
            ch->level, skill, stat, rand_num, (float)weaponProfAdj(ch,fDual)/100.0,
            GET_HITROLL(ch), ( style > 0 && !fDual  && !fDouble ) ? style_table[style].attack : 0, tohit );
        cprintf(victim,"Getting attacked: (Lv%d + Sk%d + At%d + Rn%d) * WS%.2f + HR%d + St%d = %d\n\r",
            ch->level, skill, stat, rand_num, (float)weaponProfAdj(ch,fDual)/100.0,
            GET_HITROLL(ch), ( style > 0 && !fDual  && !fDouble ) ? style_table[style].attack : 0, tohit );
    }
  }

	switch(dam_type)
	{
		case(DAM_PIERCE): victim_ac = GET_AC(victim,AC_PIERCE);	break;
		case(DAM_BASH):	 victim_ac = GET_AC(victim,AC_BASH);	break;
		case(DAM_SLASH): victim_ac = GET_AC(victim,AC_SLASH);	break;
		default:	     victim_ac = GET_AC(victim,AC_EXOTIC);	break;
	}; 

    // If you can't see your victim
	if ( !can_see( ch, victim ) )
    {
        if (IS_SET(ch->display,DISP_COMBAT_DEBUG))
            cprintf(ch,"AC Adj: you can't see your victim\n\r");
		victim_ac += (victim->level);
    }

    // Your victim can't see you!
    if ( !can_see( victim, ch ) )
    {
        if (IS_SET(ch->display,DISP_COMBAT_DEBUG))
            cprintf(ch,"AC Adj: your victim can't see you\n\r");
        victim_ac -= (ch->level);
    }

    // First strike bonus
    if (IS_SET(ch->display,DISP_COMBAT_DEBUG))
        cprintf(ch,"Position %s\n\r", position_table[victim->position] );

	if ( victim->position != POS_FIGHTING)
    {
        // Blindside penalty
        if ( !can_see(victim,ch) )
        {
            if (IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"AC Adj: blindside attack\n\r");
            victim_ac /= 2;
        }
        else 
        {
            if (IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"AC Adj: victim is not fighting\n\r");
	        victim_ac -= (ch->level + skill);
        }
    }

	if (victim->position < POS_RESTING)
    {
        if (IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"AC Adj: victim is not standing\n\r");
		victim_ac = 0;
    }

    if (IS_SET(ch->display,DISP_COMBAT_DEBUG))
        cprintf(ch,"Victim AC is %d\n\r", victim_ac );

	/*
	 * The moment of excitement!
	 */
	if ( tohit < victim_ac )
	{
		/* Miss. */
		damage( ch, victim, 0, dt, dam_type, DF_SHOW | (fDual ? DF_DUAL : 0 ) );
		if ( !fDual && !fDouble  )
			clear_style( ch );
		if ( style && !fDual && !fDouble )
			cprintf(ch,"&RYou miss your attack, and your style fails.&x\n\r");
		tail_chain( );
		return;
	}

	/*
	 * Hit.
	 */

	/* Determine critical */

	/* 1. Your class must be able to land critical hits
	 * 2. You must roll a percentile within your weapon's crit range
	 */
	if ( wield != NULL )
		crit_range = 100 - weapon_table[get_weapon_index(wield->value[0])].crit_min;
	else
		crit_range = get_skill(ch,gsn_hand_to_hand)/10;

	if ( HAS_PROF(ch,gpn_enhanced_critical))
		crit_range += 3;
	if ( HAS_PROF(ch,gpn_superior_critical))
		crit_range += 3;
	if ( HAS_PROF(ch,gpn_improved_critical))
		crit_range += 3;

    if ( isSpeciesEnemy(victim,ch) )
        crit_range += 3;

    if ( wield && !IS_NPC(ch) )
        crit_range += ch->pcdata->specialized[ get_weapon_index(wield->value[0]) ];

	if ( ch->last_style == STYLE_TRIP ) /* Bonus crit chance of 5% + 1/4 trip skill */
	{
        //Max value for thieves is 20.  17% for having it to level, and 3% for maxxing above that
		if ( ch->fighting == ch->last_style_victim )
		{
			int ratio;
			int skill = get_skill(ch, gsn_trip);
			if(skill > ch->level)
			{
				ratio = 100 * (skill - ch->level) / (ch->level / 10 + 1);
				crit_range += ratio * 3 / 100 + 17;
			}
			else
			{
				ratio = 100 * skill / ch->level;
				crit_range += ratio * 17 / 100;
			}
            //crit_range += ( 5 + get_skill(ch,gsn_trip) / 4 );
		}
		clear_style(ch);
	}

	if ( ch->last_style == STYLE_LEGSWEEP )
	{
        if ( ch->fighting == ch->last_style_victim )
		{//Max for monks is 25, 22 of which is from level skill, 3% of which is for maxxing body
			int ratio;
			int skill = get_skill(ch, gsn_body);
			if(skill > ch->level)
			{
				ratio = 100 * (skill - ch->level) / (ch->level / 10 + 1);
				crit_range += ratio * 3 / 100 + 22;
			}
			else
			{
				ratio = 100 * skill / ch->level;
				crit_range += ratio * 22 / 100;
			}
//			crit_range += ( 5 + (get_skill(ch,gsn_body) / 3 ) );
		}
		clear_style(ch);
	}

	if ( victim->fighting == NULL ) /* Double crit chances */
		crit_range *= 2;

	if ( number_percent() < crit_range )
	{
		if ( ch->class == csn_thief )
			fCritical = TRUE;
		else
		if ( number_range(1,100) < get_curr_stat(ch,STAT_STR) )
			fCritical = TRUE;
	}

	if ( IS_NPC(ch) && (!ch->pIndexData->new_format || wield == NULL))
	{
		if (!ch->pIndexData->new_format)
		{
			base_dam = dam = number_range( ch->level / 2, ch->level * 3 / 2 );
			if ( wield != NULL )
				base_dam = dam += dam / 2;
		}
		else
			base_dam = dam = dice(ch->damage[DICE_NUMBER],ch->damage[DICE_TYPE]);
	}
	else
	{//Shifter dice is a level 1 mob, we'll use monk damage for it for now
//		if ( is_affected(ch,gsn_shapeshifting,AFF_SKILL) )
//			base_dam = dam = dice(ch->damage[DICE_NUMBER],ch->damage[DICE_TYPE]);
//		else
		if ( wield != NULL )
		{
			if (wield->pIndexData->new_format)
			{
				base_dam = dam = dice(wield->value[1],wield->value[2]);
			}
			else
				base_dam = dam = number_range( wield->value[1] * skill/100, wield->value[2] * skill/100);
	
                if( IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"debug: base damage rolled: %d\n\r", base_dam );
	
			/* Enhanced damage doubles weapon base damage */
			if ( HAS_PROF( ch, gpn_enhanced_damage ) )
				dam += base_dam;

			/* Savagery! */
			if ( HAS_PROF( ch, gpn_savagery ) && IS_WEAPON_STAT(wield,WEAPON_TWO_HANDS) )
				dam += (3*base_dam/2);

                if( IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"debug: modified damage rolled: %d\n\r", dam );

			/* sharpness! 
			if (IS_WEAPON_STAT(wield,WEAPON_SHARP))
			{
				int percent;
	
				if ((percent = number_percent()) <= (skill / 8))
					dam = 2 * dam + (dam * 2 * percent / 100);
			}*/
		}
		else
		{
			/* Hand to hand damage */
			int min = 1 + skill/2;
			int max = 8 + skill;

			base_dam = dam = number_range( min, max );

			if ( HAS_PROF( ch, gpn_monk_skill ) || is_affected(ch,gsn_shapeshifting,AFF_SKILL))
				dam += (base_dam/2);
		}
	}

	/*dam = (int) ((float) class_table[ch->class].thac0 * dam / 1.0);*/
	if ( is_affected(victim,gsn_chicanery,AFF_SKILL) )
		dam += (base_dam);

	/* Adjust for level difference */
	dam += URANGE(-100,applyLevelDifference(ch->level,victim->level),100) / 2;

                if( IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"debug: level modified damag: %d\n\r", dam );

	/* Adjust for object condition */
	if ( wield != NULL )
		dam = modForCondition( wield, dam );

                if( IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"debug: condition modified damage: %d\n\r", dam );

	/* Adjust for skill *
	 * 0 = 10%
     * 10% of level = 25%
     * interpolate from 10::25 to 75::100 and from 75::100 to 100:110
	 */
	dam = modifyDamageForSkill( dam, skill*100/ch->level );

                if( IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"debug: skill modified damage: %d\n\r", dam );

	if ( fCritical )
	{
		int mult;
		if ( wield == NULL )
		{
			/* For NPCs, we cap this */
			mult = UMAX(2,get_skill(ch,gsn_hand_to_hand)/10);
			if ( IS_NPC(ch) )
				mult = UMIN(mult,2);

			dam += (base_dam*mult);
			dam = UMAX(dam,(2*ch->level/3*skill/100));
		}
		else
		{
			mult = weapon_table[get_weapon_index(wield->value[0])].crit_mult;
			dam += (base_dam * mult);
			/* Make sure minimal damage is at least max damage for the weapon */
			dam = UMAX(dam,(wield->value[1] *  wield->value[2]));
		}
	}

                if( IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"debug: crit modified damage: %d\n\r", dam );

	/*
	 * Bonuses.
	 */
	if ( !IS_AWAKE(victim) )
		dam += (base_dam*2);
	 else if (victim->position < POS_FIGHTING && !HAS_PROF(victim,gpn_alertness) )
		dam += (base_dam * 3 / 2);

                if( IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"debug: position modified damage: %d\n\r", dam );

	if( ch->level < 1 )
		ch->level = 1;

	/* Damroll is your damage bonus over 5 seconds */
	{
		float damroll = (float) GET_DAMROLL( ch );

        if( IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"debug: damroll %d, delay %d, floater %f\n\r", GET_DAMROLL(ch), delay, damroll  );

		damroll /= 10.0; /* This is how much we add per second */
                if( IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"debug: damroll: %f\n\r", damroll );

		damroll = damroll * ( (float)delay/10 );

                if( IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"debug: damroll: %f\n\r", damroll );

		/* Limit how much damroll NPCs get through level 10 */
		if ( IS_NPC(ch) && ch->level < 10 )
			damroll = (ch->level*10) * damroll / 100;

		dam += (int)damroll;
	}

                if( IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"debug: damroll modfied damage: %d\n\r", dam );

	/* Bonus for no shield */
	{
		Object *shield = get_eq_char(ch,WEAR_SHIELD);

			if ( ch->class == csn_barbarian && get_eq_char(ch,WEAR_OFFHAND) == NULL &&
				( shield == NULL || shield->value[5] == mapArmorSlot( gpn_buckler_shields )) )
				dam += ( 100 + (ch->level/2) ) * base_dam / 100;
	}

                if( IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"debug: shield modified damage: %d\n\r", dam );

	/* Style bonus */
	if ( style > 0 && !fDual && !fDouble  )
		dam += style_table[style].damage;

                if( IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"debug: style modified damage: %d\n\r", dam );

	/* Monk damage bonus */
	if ( get_skill( ch, gsn_mind ) > 10 )
	{
		int bonus = 100 + (get_skill(ch, gsn_mind)/2);

		dam = dam * bonus / 100;
	}

                if( IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"debug: monk modified damage: %d\n\r", dam );

	if ( dam <= 0 )
		dam = 1;

	switch( number_range(1,30) )
	{
	case 1:
		act("The sounds of combat echo from $D.",ch,NULL,NULL,TO_RADIUS); break;
	
		act("You hear the clash of weapons coming from $D.",ch,NULL,NULL,TO_RADIUS); break;
	case 3:
		act("The cold ring of crossing swords drifts to you from $D.",ch,NULL,NULL,TO_RADIUS); break;
	case 4:
		act("From $D you detect the sounds of combat.",ch,NULL,NULL,TO_RADIUS); break;
	case 5:
		act("The sound of fighting is audible from $D.",ch,NULL,NULL,TO_RADIUS); break;
	case 6:
		act("The clang of steel echoes from $D.",ch,NULL,NULL,TO_RADIUS); break;
	case 7:
		act("From $D come the sounds of combat.",ch,NULL,NULL,TO_RADIUS); break;
	default:
		break;
	}

	/* echo style message */
	if ( style > 0 && !fDual && !fDouble  ) 
	{
		char buf[MAX_STRING_LENGTH];
		actprintf(ch,NULL,victim,TO_CHAR,"&C%s&x", style_table[style].msg_1st);
		actprintf(ch,NULL,victim,TO_VICT,"&C%s&x", style_table[style].msg_2nd);
//		actprintf(ch,NULL,victim,TO_ROOM,"&C%s&x", style_table[style].msg_3rd);
		sprintf(buf, "&C%s&x", style_table[style].msg_3rd);
		act( buf, ch, NULL, victim, TO_NOTVICT );

	}
	else
	if ( style == STYLE_FAIL && !fDual && !fDouble  )
		act("&RYou cannot use that style at the moment.&x",ch,NULL,NULL,TO_CHAR);

if(IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"(calling damage): %d\n\r", dam);

	result = damage( ch, victim, dam, dt, dam_type, DF_SHOW | (fDual?DF_DUAL:0) | (fCritical?DF_CRIT:0) );

	/* process special attacks */
	if ( result && style > 0 && style_table[style].fun_ptr != NULL && !fDual && !fDouble  ) 
		(*style_table[style].fun_ptr)( ch, victim, style );

	if ( style > 0 && !fDual && !fDouble  )
	{//Drain stamina regardless
		drainStamina(ch,style_table[style].stamina);
		if(result)
		{
			if ( style_table[style].defense )
				apply_style_defense(ch,style);
		}
		else
		{
			clear_style(ch);
			cprintf(ch,"&RYour attack was avoided, and your well executed style fails.&x\n\r");
		}
	}
	
	tail_chain( );
	return;
}

/*
 * What we need to know to deal damage to a character
 * 1. who is the source
 * 2. what the damage type is (flame, fire, etc)
 * 3. the damage source (weapon, skill, fist, spell)
 */

/*
 * Inflict damage from a hit.
 */
bool damage(Character *ch,Character *victim,int dam,int dt,int dam_type, long flags ) /*bool show, bool fSpell, bool fDual ) */
{
	int	stat_ratio = 0, base_ratio = 0;
	int stat_dam, base_dam;
	Object *corpse;
	bool immune;
	int skill;
	Affect *bt;
	bool show = IS_SET(flags,DF_SHOW) ? TRUE : FALSE;
	bool fSpell = IS_SET(flags,DF_SPELL) ? TRUE : FALSE;
	bool fDual = IS_SET(flags,DF_DUAL) ? TRUE : FALSE;
	bool fCrit = IS_SET(flags,DF_CRIT) ? TRUE : FALSE;
	bool fDot = IS_SET(flags,DF_DOT) ? TRUE : FALSE;	
    bool fRange = IS_SET(flags,DF_RANGED) ? TRUE : FALSE;
    bool fBase = IS_SET(flags,DF_BASEHITS) ? TRUE : FALSE;

    if(IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"(got damage): %d\n\r", dam);

	if ( victim->position == POS_DEAD )
		return FALSE;

	/* Kirijutsu - moves curves back on regular attacks,
	 * Works on regular attacks and backstabs.  Does +5-15%
	 * damage on normal attacks and +25% to +50% on opening attacks.
	 */
	if ( (dt == gsn_backstab || dt >= TYPE_HIT) && (skill=get_skill(ch,gsn_kirijutsu)) > 0 )
	{
		int bonus;

		bonus = (victim->fighting == NULL ) ? 25 : 10;
		applySkillAdjust( &bonus, 50, skill, ch->level );
		
		dam = ( 100 + bonus ) * dam / 100;
	}

    if(IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"(kiri damage): %d\n\r", dam);

	/* Lowbie curve so people can survive to level 5ish */
	if ( IS_NPC(ch) && ch->level < 5 )
		dam = UMIN(dam, ch->level * 2 + 5);

    if(IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"(lowbie curve damage): %d\n\r", dam);

	if ( victim != ch )
	{
	/*
	 * Certain attacks are forbidden.
	 * Most other attacks are returned.
	 */
	if ( !fDot && !fRange && is_safe( ch, victim ) )
		return FALSE;

	if ( victim->position > POS_STUNNED && !fDot && !fRange )
	{
		if ( victim->fighting == NULL ) 
			set_fighting( victim, ch );

		if (victim->timer <= 4)
			victim->position = POS_FIGHTING;
	}

	if ( victim->position > POS_STUNNED && !fDot && !fRange ) 
	{
		if ( ch->fighting == NULL )
			set_fighting( ch, victim );
	}

	/*
	 * More charm stuff.
	 */
	if ( victim->master == ch )
		stop_follower( victim , TRUE );
	}

	/*
	 * Inviso attacks ... not.
	 */
	if ( IS_AFFECTED(ch, AFF_INVISIBLE) && !fDot )
	{
		affect_strip( ch, gsn_invis );
		affect_strip( ch, gsn_mass_invis );
		REMOVE_BIT( ch->affected_by, AFF_INVISIBLE );
		act( "$n fades into existence.", ch, NULL, NULL, TO_ROOM );
		act( "You fade into existence.", ch,NULL,NULL,TO_CHAR);
	}

    // Even ranged people become visible after firing
	if ( !fDot )
	{
		visible( ch, NULL, FALSE );
	}

	visible( victim , NULL, FALSE);

	/*
	 * Damage modifiers.
	 */

    if(IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"(damage): %d\n\r", dam);

	if ( dam > 1 && !IS_NPC(victim) && victim->pcdata->condition[COND_DRUNK]  > 10 )
		dam = 9 * dam / 10;

    if(IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"(damage): drunk modified %d\n\r", dam);

    if(IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"(damage): sanc modified %d\n\r", dam);

	if ( dam > 1 && ((IS_AFFECTED(victim, AFF_PROTECT_EVIL) && IS_EVIL(ch) )
	||			 (IS_AFFECTED(victim, AFF_PROTECT_GOOD) && IS_GOOD(ch) )))
		dam -= dam / 4;

    if(IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"(damage): prot good/evil modified: %d\n\r", dam);

	if ( IS_NPC(ch) )
		dam = dam * ch->base_hit / ch->max_base_hit;

	immune = FALSE;

	/* Stealth timers */
    if ( get_skill(ch,gsn_stealth) > 0 && !fDot )
        setSkillReuseWait(ch,gsn_stealth,PULSE_PER_SECOND * 10);

    /* Reset everybody's recall timer */
    if ( !fDot && !IS_SET(flags,DF_NOTIMERS) )
    {
        if ( IS_NPC(victim) )
            setSkillReuseWait(ch,gsn_recall,PULSE_PER_SECOND *10);
        else
            setSkillReuseWait(ch,gsn_recall,PULSE_PER_SECOND *30);
    }

	/* You can't fight while "on" something */
	if ( !fDot && !fRange )
	{
		ch->on = NULL;
		victim->on = NULL;
	}

    if ( !IS_NPC(ch) && !fDot && !IS_SET(flags,DF_NOTIMERS) )
        ch->pcdata->combat_timer = PULSE_PER_SECOND * 30 / PULSE_REGEN;

	/* Dodge and intercept are checked before bladeturns */
	if ( dt >= TYPE_HIT && ch != victim )
	{
		clear_defend(victim);
		if ( !IS_NPC(victim) && !IS_SET(victim->act,PLR_IS_CASTING) && !fRange )
		{
			if ( check_dodge( ch, victim ) )
				return FALSE;
		}
		else if ( IS_NPC(victim) && !fRange )
		{
			if ( IS_SET(victim->off_flags,OFF_DODGE) )
				if ( check_dodge( ch, victim ) )
					return FALSE;
		}
		
		if ( !fRange && check_intercept(ch,victim) )
			return FALSE;

        if ( IS_NPC(victim) && IS_SET(victim->off_flags,OFF_FADE) )
            if( check_fade(ch,victim) )
                return FALSE;
	}
	
	/* Check bladeturns */
	if ( (dt >= TYPE_HIT || dt == gsn_backstab || IS_SET(flags,DF_TURNABLE)) && dam > 0 && 
         ch != victim && (bt = find_bladeturn(victim)) != NULL )
	{
		act("Your bladeturn absorbs $n's attack!",ch,NULL,victim,TO_VICT);
		act("$N's bladeturn absorbs your attack!",ch,NULL,victim,TO_CHAR);
		act("$N's bladeturn absorbs $n's attack!",ch,NULL,victim,TO_NOTVICT);
		if ( --bt->duration < 1 )
		{
			SpellIndex* pSpellIndex;
			pSpellIndex = get_spell_index( bt->type );

			affect_strip( victim, bt->type );
			actprintf(victim,NULL,NULL,TO_CHAR,"Your %s fades.",
				pSpellIndex ? pSpellIndex->name : "(null)", bt->type);
		}
		return TRUE;
	}

    /* Parry and shield blocking are checked after it */
    if ( dt >= TYPE_HIT && ch != victim )
    {
        clear_defend(victim);
        if ( !IS_NPC(victim) )
        {
			if ( !fRange && check_phantasmal_defender(ch,victim) )
				return FALSE;

			if ( !IS_SET(victim->act,PLR_IS_CASTING) )
			{
            	if ( !fRange && check_parry( ch, victim ) )
                	return FALSE;
            	if ( check_shield_block(ch,victim) )
                	return FALSE;
			}
        }
        else if ( IS_NPC(victim) )
        {
            if ( !fRange && IS_SET(victim->off_flags,OFF_PARRY) )
                if ( check_parry( ch, victim ) )
                    return FALSE;
			if ( get_eq_char(victim,WEAR_SHIELD) )
				if ( check_shield_block(ch,victim))
					return FALSE;
        }
    }

	if ( check_immune(victim,dam_type) )
	{
		immune = TRUE;
		dam = 0;
	}

	/* Resists */
    if ( dam > 0 )
		dam = UMAX(1,modify_for_resists(victim,dam,dam_type));

    if(IS_SET(ch->display,DISP_COMBAT_DEBUG)) cprintf(ch,"(damage): resist modified: %d\n\r", dam);

	if ( ch->pgroup == NULL )
		log_bug("NULL pgroup before addGroupDamage",0);

	/* Reduction for armor type */
	if ( dt >= TYPE_HIT && ch != victim && dam > 0 )
	{
		Object *obj;
		long	hitLoc;

		if ( dt == gsn_backstab )
			hitLoc = WEAR_ABOUT;
		else
			hitLoc = randomHitLocation();


		if ( (obj = get_eq_char(victim,hitLoc)) != NULL &&
			 	obj->item_type == ITEM_ARMOR &&
				 obj->value[5] > 0 && obj->value[5] < 8 )
		{
			int absorb;
		
			absorb = armor_table[obj->value[5]].absorb + victim->absorb + obj->absorb;
			/* Also gain +1% absorb per 2 points of 'body' skill */
			if ( victim->class == csn_monk )
				absorb += (get_skill(victim,gsn_body) / 2);

			/* Monks can bypass this a little bit  */
			if ( get_skill(ch,gsn_mind) > 40 )
				absorb = UMAX(0, absorb - (get_skill(ch,gsn_mind) / 5));

			/* Kirijutsu lets you get through absorbtion  - figure out formula */

			dam = ( dam * ( 100 - absorb ) / 100 );
			dam = UMAX(dam,1);
			check_condition( victim, obj );
		}

	}

    if(IS_SET(ch->display,DISP_COMBAT_DEBUG))
        cprintf(ch,"(damage): armor/absorb modified %d\n\r", dam);

    addGroupDamage( victim, ch->pgroup, dam );

    if(IS_SET(ch->display,DISP_COMBAT_DEBUG))
        cprintf(ch,"(damage): checking backstab and kistrike %d\n\r", dam);

	/*
	 * Hurt the victim.
	 * Inform the victim of his new state.
	 */

	/* 1 damage stat hits until they reach 0 
	** If this is a backstab, damage BASE hits.
	** Check ration - modify by level difference 
	*/
	if ( dt == gsn_backstab || dt == gsn_kistrike )
	{
		base_ratio = 50;
		applySkillAdjust( &base_ratio, 50, get_skill(ch,dt==gsn_backstab?gsn_backstab:gsn_mind), ch->level );
		base_ratio += applyLevelDifference(ch->level,victim->level);
		base_ratio = URANGE(0,base_ratio,100);
	}

	if ( victim->stat_hit < 1 || fBase )
		base_ratio = 100;

	/* If this is not a backstab attack then stat_ratio will always be 100% */
	stat_ratio = 100 - base_ratio;

	stat_dam = dam * stat_ratio / 100;
	base_dam = dam * base_ratio / 100;

	if ( stat_ratio >= 0 )
	{
		if ( victim->stat_hit <= stat_dam )
		{

			stat_dam -= victim->stat_hit;
			base_dam += stat_dam;
			victim->stat_hit = 0;
		}
		else
			victim->stat_hit -= stat_dam;
	}

	if ( victim->stat_hit <= 0 || base_ratio > 0 )
		victim->base_hit -= base_dam;


	if ( IS_IMMORTAL(victim) && victim->base_hit < 1 )
		victim->base_hit = 1; 

	if (show)
	{
		if ( fCrit )
		{
			cprintf(ch,"You land a critical strike!\n\r");
			act("$n lands a critical strike!",ch,NULL,NULL,TO_ROOM);
		}
        dam_message( ch, victim, dam, dt, immune, fSpell, fDual, fRange );
	}

    if(IS_SET(ch->display,DISP_COMBAT_DEBUG))
        cprintf(ch,"(damage): checking if damage equals 0 %d\n\r", dam);

	if (dam == 0)
		return FALSE;

	/* Fizzle spells - 'concentration' ability users skip this check */
	if (  IS_SET(victim->act,PLR_IS_CASTING) && 
          !IS_NPC(victim) && !fDot && 
          !is_affected(victim,gsn_concentration,AFF_SKILL) )
	 {
        int skill = get_skill(victim,gsn_channeling);
        int chance = 0;
        /* Channeling:
              You have a 20% chance of keeping concentration.
          	  This can be modified up to 75% if your channeling is equal to
              your level, and possibly over.
        */
        if( skill > 0 )
        {
            chance = 200;
            chance += ( skill * 40 / ch->level ) * 10;
            chance += applyLevelDifference(ch->level,victim->level) * 10;
            if ( HAS_PROF(ch,gpn_combat_casting) )
                chance += 200;
            chance -= dam;
        }

		if ( number_percent() > chance/10 )
		{
			int manaPercent;

			cprintf(victim,"&RYour concentration is broken and your spell fizzles.&x\n\r");
			act("$n's spell is interrupted!",victim,NULL,NULL,TO_ROOM)	;
			REMOVE_BIT(victim->act,PLR_IS_CASTING);

			/* You get back some of the mana.  50% + 1% per 10 points of INT */
			manaPercent = 50 + get_curr_stat(ch,STAT_INT) / 10;
			victim->mana += (victim->casting->mana * manaPercent / 100);
			free_casting_data( victim->casting );
	        victim->casting = NULL;
	        victim->wait = 0;
		}
		else
		{
			cprintf(victim,"You manage to retain your concentration and continue casting!\n\r");
			act("$n's spell is interrupted but $e regains $s concentration.",victim,NULL,NULL,TO_ROOM);
		}
	 }

	/** Now search for damage shields **/
	if ( dt >= TYPE_HIT && ch != victim && !fRange )
	{
		Affect *sh;

		/* have to be careful with this recursive call to damage
	 	* we only go in here if it's a melee strike, so when we call
	 	* it again we have make sure it's NOT a melee strike
	 	* TYPE_DAMAGE_SHIELD is -3 so it'll be less than TYPE_HIT
	 	* and won't enter in here
	 	*/

		if ( (sh = find_damage_shield(victim)) != NULL )
	   	{
			SpellIndex* pSpellIndex;
			pSpellIndex = get_spell_index( sh->type );

			actprintf(ch,NULL,victim,TO_VICT,"$n is struck by your %s!",
				pSpellIndex ? pSpellIndex->name : "(null)" );
			actprintf(ch,NULL,victim,TO_CHAR,"You are struck by $N's %s!",
				pSpellIndex ? pSpellIndex->name : "(null)" );
			damage(victim,ch,number_range(sh->location,sh->modifier),sh->type,sh->bitvector,DF_SHOW|DF_SPELL);
  		    if ( ch->fighting != victim || ch->in_room != victim->in_room )
        	    return TRUE;
        }
	}

	/** Check for special procedures **/
	if ( (dt >= TYPE_HIT || dt == gsn_backstab) && ch != victim )
	{ 
		Object *wield;

		/* value[8] is the minimum level for the proc to work */
		wield = fDual ? get_eq_char(ch,WEAR_OFFHAND) : get_eq_char(ch,WEAR_WIELD);
       
        if ( fRange )
            wield = findAmmo(ch,TRUE);
 
		if ( wield != NULL && HAS_PROC(wield) && ch->level >= wield->value[8] )
		{
			int procChance;
			/* Procs work on a 1d1000 scale.
		 	* Chance is your level + your charisma - object level, - difficulty.
	 	 	* If a 1d100 * 1d100 is less than that, it procs.
		 	*/

			procChance = ch->level + get_curr_stat(ch,STAT_CHA) - wield->level - wield->value[9];
			if ( number_percent() * number_percent() < procChance )
			{
				processSpecialWeapon( wield, ch, victim );
			}

			if ( ch->fighting != victim || ch->in_room != victim->in_room )
				return TRUE;
		}
	}

	if ( !fDot && !fRange && ( ch->fighting != victim || ch->in_room != victim->in_room ))
		return TRUE;

	/* check NPC drain touch */
	if ( IS_SET(ch->off_flags,OFF_DRAIN_TOUCH) && 
         (number_percent() * number_percent() < (50+ch->level)) )
	{
		int sn;
		SpellIndex* pSpellIndex;

		     if ( ch->level < 2 ) sn = vnum_life_tap;
		else if ( ch->level < 5 ) sn = vnum_life_touch;
		else if ( ch->level < 9 ) sn = vnum_life_hit;
		else if ( ch->level < 14 ) sn = vnum_life_spike;
		else if ( ch->level < 20 ) sn = vnum_life_take;
		else if ( ch->level < 27 ) sn = vnum_life_steal;
		else if ( ch->level < 35 ) sn = vnum_life_siphon;
		else if ( ch->level < 44 ) sn = vnum_life_drain;
		else                       sn = vnum_life_exhaust;
                            
		if( (pSpellIndex = get_spell_index(sn)) != NULL )
		{
			(*(pSpellIndex->spell_fun)) ( sn, ch->level, ch, (void *) victim, TARGET_CHAR );
			
			if ( ch->fighting != victim || ch->in_room != victim->in_room )
        		return TRUE;
		}
		else
		{
			log_bug("damage: Spell index not found(%d)", sn);
			return TRUE;
		}
	}

    /*if ( ch->fighting != victim || ch->in_room != victim->in_room )
        return TRUE;*/

	update_pos( victim );

	switch( victim->position )
	{
	case POS_MORTAL:
    	act( "$n is mortally wounded, and will die soon, if not aided.",
		victim, NULL, NULL, TO_ROOM );
		cprintf( victim, "You are mortally wounded, and will die soon, if not aided.\n\r" );
		break;

	case POS_INCAP:
	    act( "$n is incapacitated and will slowly die, if not aided.", victim, NULL, NULL, TO_ROOM );
	    cprintf( victim, "You are incapacitated and will slowly die, if not aided.\n\r" );
	    break;

	case POS_STUNNED:
	    act( "$n is stunned, but will probably recover.", victim, NULL, NULL, TO_ROOM );
	    cprintf( victim, "You are stunned, but will probably recover.\n\r", victim );
	    break;

	case POS_DEAD:
	/* Check for a special death message */
	if( IS_NPC(victim) && victim->pIndexData != NULL && victim->pIndexData->death_echo != NULL &&
		victim != ch && victim->in_room == ch->in_room )
		act(victim->pIndexData->death_echo,victim,NULL,ch,TO_ROOM);
	else
		act( "$n is DEAD!!", victim, 0, 0, TO_ROOM );

	send_to_char( "You have been KILLED!!\n\r\n\r", victim );
	break;

	default:
	if ( victim->stat_hit < max_stat_hit(victim) / 5 && victim->stat_hit != 0 )
		cprintf(victim,"You are becoming fatigued.\n\r");
	  if ( victim->base_hit <= victim->max_base_hit &&
		 victim->stat_hit <= 0 )
		cprintf(victim,"You are taking severe damage!\n\r");
	break;
	}

	/*
	 * Sleep spells and extremely wounded folks.
	 */
	if ( !IS_AWAKE(victim) )
		stop_fighting( victim, FALSE );

	/*
	 * Payoff for killing things.
	 */
	if ( victim->position == POS_DEAD )
	{
		if(is_affected(victim, gsn_shapeshifting, AFF_SKILL))
		{
			Character *orig = victim->desc->original;
			do_function(victim, &do_shapeshift, "return");
			victim = orig;
			victim->stat_hit = 1;
			victim->base_hit = 1;
		}

		group_gain( ch, victim );

    	if ( !IS_NPC(ch) && !IS_NPC(victim) )
        	victim->pcdata->last_pdeath = current_time;

		if ( !IS_NPC(victim) && IS_SET(victim->act,PLR_IS_CASTING) )
		{
	   		REMOVE_BIT(victim->act,PLR_IS_CASTING);
	   		free_casting_data(victim->casting);
		}

		if ( !IS_NPC(victim) )
		{
			int percent;

			log_string( "%s killed by %s at %s %d",
				victim->name,
				(IS_NPC(ch) ? ch->short_descr : ch->name),
				ch->in_room->name, ch->in_room->vnum );

			/*
			 * Dying penalty:
			 * Depends on level
			 * Can't lose xp for pk
			 */
			if( IS_NPC(ch) )
			{
				if( victim->level <= 5 )
					percent = 0;
				else if ( victim->level <= 10 )
					percent = 5;
				else if ( victim->level <= 15 )
					percent = 8;
				else if ( victim->level <= 20 )
					percent = 11;
				else if ( victim->level <= 25 )
					percent = 14;
				else if ( victim->level <= 30 )
					percent = 17;
				else if ( victim->level <= 35 )
					percent = 20;
				else if ( victim->level <= 40 )
					percent = 24;
				else if ( victim->level <= 45 )
					percent = 28;
				else if ( victim->level <= 50 )
					percent = 32;
				else
					percent = 40;

				/* lost_xp set */
				victim->pcdata->lost_xp = 40 * victim->exp / 100;
				victim->exp -= victim->pcdata->lost_xp;
				cprintf(victim," &R*** You have lost %d experience. ***&x\n\r",
					victim->pcdata->lost_xp );
			}
			victim->pcdata->deaths++;
			if ( !IS_NPC(ch) )
				ch->pcdata->kills++;
		}

		if (IS_NPC(victim))
			wizprintf(NULL,NULL,WIZ_MOBDEATHS,0,0,
                "%s got toasted by %s at %s [room %d]",
                    (IS_NPC(victim) ? victim->short_descr : victim->name),
                    (IS_NPC(ch) ? ch->short_descr : ch->name),
                    ch->in_room->name, ch->in_room->vnum);
		else
		{
            wizprintf(NULL,NULL,WIZ_DEATHS,0,0,
                "%s got toasted by %s at %s [room %d]",
                    (IS_NPC(victim) ? victim->short_descr : victim->name),
                    (IS_NPC(ch) ? ch->short_descr : ch->name),
                    ch->in_room->name, ch->in_room->vnum);
            if( !IS_NPC(ch) )
			    pnetprintf(NULL,NULL,WIZ_DEATHS,0,get_trust(victim),
                    "%s got killed by %s!",
				        victim->name, !IS_NPC(ch) ? ch->name : "an NPC!");
		}
	
		/* Clear NPC dispositions */
		if ( IS_NPC(ch) && !IS_NPC(victim) )	
			clear_melee_disposition( ch, victim );

		raw_kill( victim, xp_value( victim, ch) );

		if ( dt == vnum_death_knell )
		{
			Affect af;

    		af.where        = TO_AFFECTS;
    		af.type         = vnum_death_knell;
    		af.level        = ch->level;
    		af.duration     = minutes(60+UMIN(victim->level,ch->level*11/10));
    		af.location     = APPLY_DAMROLL;
    		af.modifier     = UMIN(victim->level,ch->level*11/10);
    		af.bitvector    = 0;
    		af.flags        = AFF_SPELL;
    		spellAffectToChar( ch, &af );

			af.location		= APPLY_HITROLL;
			spellAffectToChar( ch, &af );

			act("The echo of an massive ethereal bell sounds in the heavens.",ch,NULL,NULL,TO_RADIUS);
			act("The echo of a massive bell sounds the death knell for you.",ch,NULL,victim,TO_VICT);
			act("The echo of a massive bell sounds the death knell for $N.",ch,NULL,victim,TO_CHAR);
			act("The echo of a massive bell sounds the death knell for $N.",ch,NULL,victim,TO_NOTVICT);
		}	

		/* dump the flags */
		if (ch != victim && !IS_NPC(ch) && !is_same_clan(ch,victim))
		{
			if (IS_SET(victim->act,PLR_KILLER))
				REMOVE_BIT(victim->act,PLR_KILLER);
			else
				REMOVE_BIT(victim->act,PLR_THIEF);
		}

		/* RT new auto commands */

	if (   !IS_NPC(ch) && 
           (corpse = get_obj_list(ch,"corpse",ch->in_room->contents)) != NULL && 
           corpse->item_type == ITEM_CORPSE_NPC && can_see_obj(ch,corpse) &&
		   !is_affected(ch,gsn_shapeshifting,AFF_SKILL) )
	{
		Object *coins;

		corpse = get_obj_list( ch, "corpse", ch->in_room->contents ); 

		if ( HAS_AUTOOPT(ch, AUTO_LOOKINCORPSE) && corpse )
		{//Exists, so look in it
			cprintf(ch, "\n\r");//just a bit of spacing
			do_function(ch, &do_look, "in corpse");
			cprintf(ch, "\n\r");//just a bit of spacing
		}

		if ( HAS_AUTOOPT(ch, AUTO_LOOT) &&
		     corpse &&
             corpse->contains &&
             !is_affected(ch,gsn_shapeshifting,AFF_SPELL) ) /* exists and not empty */
		{
			do_function(ch, &do_get, "all corpse");
		}

	 	if (HAS_AUTOOPT(ch, AUTO_GOLD) &&
			corpse && corpse->contains  && /* exists and not empty */
		    !HAS_AUTOOPT(ch, AUTO_LOOT) &&
			!is_affected(ch,gsn_shapeshifting,AFF_SPELL) )
		{
			if ((coins = get_obj_list(ch,"gcash",corpse->contains)) != NULL)
			{
				do_function(ch, &do_get, "all.gcash corpse");
		  	}
		}
			
		if (HAS_AUTOOPT(ch, AUTO_SAC))
		{
	   		if (HAS_AUTOOPT(ch, AUTO_LOOT) && corpse && corpse->contains)
	   		{
				return TRUE;  /* leave if corpse has treasure */
		  	}
			else
			{
				do_function(ch, &do_sacrifice, "corpse");
			}
		}
	}

	return TRUE;
	}

	if ( victim == ch )
	return TRUE;

	/*
	 * Take care of link dead people.
	 */
	if ( !IS_NPC(victim) && victim->desc == NULL )
	{
	if ( number_range( 0, victim->wait ) == 0 )
	{
		do_function(victim, &do_recall, "" );
		return TRUE;
	}
	}

	/*
	 * Wimp out?
	 */
	if ( IS_NPC(victim) && dam > 0 && victim->wait < PULSE_VIOLENCE / 2)
	{
	if ( ( IS_SET(victim->act, ACT_WIMPY) && number_bits( 2 ) == 0
	&&   victim->stat_hit < max_stat_hit(victim) / 5) 
	||   ( IS_AFFECTED(victim, AFF_CHARM) && victim->master != NULL
	&&	 victim->master->in_room != victim->in_room ) )
	{
		do_function(victim, &do_flee, "" );
	}
	}

	if ( !IS_NPC(victim)
		&&   victim->stat_hit <= victim->wimpy
		&&   victim->wait < PULSE_VIOLENCE / 2 )
	{
	do_function (victim, &do_flee, "" );
	}

	tail_chain( );
	return TRUE;
}

bool is_safe(Character *ch, Character *victim)
{
    extern bool pk_enabled;

	if (victim->in_room == NULL || ch->in_room == NULL)
	    return TRUE;

	if (victim->fighting == ch || victim == ch)
	    return FALSE;

    // You cannot pk if pk is disabled and you're not both in a PK ARENA 
    if ( !pk_enabled && !IS_NPC(victim) && !IS_IMMORTAL(ch) && !IS_NPC(ch) &&
         (!IS_SET(ch->in_room->room_flags,ROOM_ARENA) ||
          !IS_SET(victim->in_room->room_flags,ROOM_ARENA)) 
       )
	{
        //player attacking player is banned!
		cprintf(ch,"You can't attack a player.\n\r");
		return TRUE;
	}

	if (IS_IMMORTAL(ch) && ch->level > LEVEL_IMMORTAL)
	    return FALSE;

	if (IS_SET(victim->in_room->room_flags,ROOM_SAFE) && !IS_NPC(ch) && !IS_NPC(victim) )
	{
		send_to_char("Not in this room.\n\r",ch);
		return TRUE;
	}

	/* killing mobiles */
	if (IS_NPC(victim))
	{
		if (victim->pIndexData->pShop != NULL)
		{
			send_to_char("You can't slaughter shopkeepers!\n\r",ch);
			return TRUE;
		}

		/* no killing healers, trainers, etc */
		if (IS_SET(victim->act,ACT_TRAIN)
		||  IS_SET(victim->act,ACT_IS_HEALER)
		||  IS_SET(victim->act,ACT_SMITHY)
		||  IS_SET(victim->act,ACT_BANKER)
		||  IS_SET(victim->act,ACT_REGISTRAR) )
		{
			send_to_char("Killing tagged NPCs isn't permitted.\n\r",ch);
			return TRUE;
		}
	
		if (!IS_NPC(ch))
		{
			/* no charmed creatures unless you can attack the owner */
			if (IS_AFFECTED(victim,AFF_CHARM) && ch != victim->master && victim->master != NULL )
			{
				if ( is_safe( ch, victim->master ) )
				{
					send_to_char("You cannot kill charmies whose owners are safe from you.\n\r",ch);
					return TRUE;
				}
			}
		}
	}
	/* killing players */
	else
	{
	/* NPC doing the killing */
	if (IS_NPC(ch))
	{
		/* safe room check */
		if (IS_SET(victim->in_room->room_flags,ROOM_SAFE))
		{
		send_to_char("Not in this room.\n\r",ch);
		return TRUE;
		}

		/* charmed mobs and pets cannot attack players while owned */
		if (IS_AFFECTED(ch,AFF_CHARM) && ch->master != NULL
		&&  ch->master->fighting != victim)
		{
		send_to_char("Players are your friends!\n\r",ch);
		return TRUE;
		}
	}
	/* player doing the killing */
	else
	{
		if (!is_clan(ch))
		{
		send_to_char("Join a clan if you want to kill players.\n\r",ch);
		return TRUE;
		}

		if (IS_SET(victim->act,PLR_KILLER) || IS_SET(victim->act,PLR_THIEF))
		return FALSE;

		if (!is_clan(victim))
		{
		send_to_char("They aren't in a clan, leave them alone.\n\r",ch);
		return TRUE;
		}

		if (ch->level > victim->level + 8)
		{
		send_to_char("Pick on someone your own size.\n\r",ch);
		return TRUE;
		}
	}
	}
	return FALSE;
}
 
bool is_safe_spell(Character *ch, Character *victim, bool area )
{
    extern bool pk_enabled;

	if (victim->in_room == NULL || ch->in_room == NULL)
		return TRUE;

	if (victim == ch && area)
	    return TRUE;

	if (victim->fighting == ch || victim == ch)
	    return FALSE;

	if( !pk_enabled && !IS_NPC(victim) && !IS_IMMORTAL(ch) && !IS_NPC(ch))
	{
        //player attacking player is banned!
		send_to_char("You can't attack a player.\n\r", ch);
		return TRUE;
	}

	if (IS_IMMORTAL(ch) && ch->level > LEVEL_IMMORTAL && !area)
	    return FALSE;

	if (IS_SET(victim->in_room->room_flags,ROOM_SAFE) && !IS_NPC(ch) && !IS_NPC(victim) )
		return TRUE;

	/* killing mobiles */
	if (IS_NPC(victim))
	{
	if (victim->pIndexData->pShop != NULL)
		return TRUE;

	/* no killing healers, trainers, etc */
	if (IS_SET(victim->act,ACT_TRAIN)
	||  IS_SET(victim->act,ACT_IS_HEALER)
	||  IS_SET(victim->act,ACT_SMITHY))
		return TRUE;

	if (!IS_NPC(ch))
	{
		/* no pets */
		if (IS_SET(victim->act,ACT_PET))
	   	return TRUE;

		/* no charmed creatures unless owner */
		if (IS_AFFECTED(victim,AFF_CHARM) && (area || ch != victim->master))
		return TRUE;

		/* legal kill? -- cannot hit mob fighting non-group member */
		if (victim->fighting != NULL && !is_same_group(ch,victim->fighting))
		return TRUE;
	}
	else
	{
		/* area effect spells do not hit other mobs */
		if (area && !is_same_group(victim,ch->fighting))
		return TRUE;
	}
	}
	/* killing players */
	else
	{
	if (area && IS_IMMORTAL(victim) && victim->level > LEVEL_IMMORTAL)
		return TRUE;

	/* NPC doing the killing */
	if (IS_NPC(ch))
	{
		/* charmed mobs and pets cannot attack players while owned */
		if (IS_AFFECTED(ch,AFF_CHARM) && ch->master != NULL
		&&  ch->master->fighting != victim)
		return TRUE;
	
		/* safe room? */
		if (IS_SET(victim->in_room->room_flags,ROOM_SAFE))
		return TRUE;

		/* legal kill? -- mobs only hit players grouped with opponent*/
		if (ch->fighting != NULL && !is_same_group(ch->fighting,victim))
		return TRUE;
	}

	/* player doing the killing */
	else
	{
		if (!is_clan(ch))
		return TRUE;

		if (IS_SET(victim->act,PLR_KILLER) || IS_SET(victim->act,PLR_THIEF))
		return FALSE;

		if (!is_clan(victim))
		return TRUE;

		if (ch->level > victim->level + 8)
		return TRUE;
	}

	}
	return FALSE;
}
/*
 * See if an attack justifies a KILLER flag.
 */
void check_killer( Character *ch, Character *victim )
{
	return;
}



/*
 * Check for parry.
 *
 * Parry base chance is 10%.
 * Chance increases by a ratio of your parry skill to your level.
 * So, at 1/2 you have 150% of your base, or 15%.
 *
 * For every player attacking you beyond one, your parry chances drop agaisnt
 * the extra attackers.  You get full parry vs the person you're "facing" but
 * reduced against the additional attackers, to a maximum of 4.
 *
 */
bool check_parry( Character *ch, Character *victim )
{
	int chance = 10;
	int skill_bonus;

    if ( get_eq_char( victim, WEAR_WIELD ) == NULL &&
         get_eq_char( victim, WEAR_OFFHAND ) == NULL &&
         get_skill(victim,gsn_unarmed_combat) < 1 )
        return FALSE;

	if ( !IS_AWAKE(victim) )
		return FALSE;

	if ( victim->stamina < 1 )
		return FALSE;

	if ( victim->daze )
		return FALSE;

	if ((skill_bonus = get_skill(victim,gsn_parry)) < 1 )
		return FALSE;
	else
		skill_bonus = ( 100 + (skill_bonus * 100 / victim->level ) );

	chance = skill_bonus * chance / 100;
	chance += victim->level;
	chance -= ch->level;

	/* 
	 * Additional penalty if you're parrying somebody you're not 
	 * "facing" 
	 */
	if ( victim->fighting != ch )
	{
		int attackers;

   		attackers = countAttackers( victim ) - 1;
		attackers = URANGE(0,attackers,4);
    	attackers *= attackers;
    	chance -= attackers;
	}

	/*
	 * If victim doesn't have hand-to-hand practices, and is unarmed, parry chance
	 * is severely reduced.
	 */
	if ( get_eq_char( victim, WEAR_WIELD ) == NULL )
	{
		/* There's normally a 50% penalty to parrying while unarmed */
		/* This is reduced by the skill_bonus ratio for unarmed combat */
		int bonus;

		if ( (bonus = get_skill(victim,gsn_hand_to_hand)) < 1 )
			bonus = 0;
		else
			bonus = bonus * 100 / victim->level;

		chance -= ( chance/2 * bonus / 100 );
	}

    // Check for a species enemy
    if ( isSpeciesEnemy( ch, victim ) ) // ch is victim's species enemy
        chance = 3 * chance / 2;

	if (!can_see(ch,victim))
		chance /= 2;

	/* Victim gets bonus if dual wielding */
	if ( get_eq_char( victim, WEAR_OFFHAND ) != NULL && get_skill(victim,gsn_dual_wield) > 1 )
		chance += 2;

	/* Attacker also gets bonus if dual wieldling */
	if ( get_eq_char( ch, WEAR_OFFHAND) != NULL && get_skill(ch,gsn_dual_wield) > 1 )
		chance -= 2;

	if ( victim->intercepting != NULL && victim->intercepting->in_room == ch->in_room )
		chance /= 2;

	if ( number_percent( ) > chance )
		return FALSE;

	act( "You parry $n's attack.",  ch, NULL, victim, TO_VICT	);
	act( "$N parries your attack.", ch, NULL, victim, TO_CHAR	);
	set_defend(victim,ch,STYLE_PARRY);
	drainStamina(victim,1);
	act("You hear the clash of weapons coming from $D.",ch,NULL,NULL,TO_RADIUS);
	return TRUE;
}

bool check_phantasmal_defender( Character *ch, Character *victim )
{
	int chance = 0;

	if ( is_affected(ch,vnum_phantasmal_protector,AFF_SPELL) )
		chance = 7;
	else
	if ( is_affected(ch,vnum_phantasmal_defender,AFF_SPELL) )
		chance = 14;
	else
	if ( is_affected(ch,vnum_phantasmal_guardian,AFF_SPELL) )
		chance = 21;

	if ( chance == 0 )
		return FALSE;
	
	chance += victim->level;
	chance -= ch->level;

	/* 
	 * Additional penalty if you're parrying somebody you're not 
	 * "facing" 
	 */
	if ( victim->fighting != ch )
	{
		int attackers;

   		attackers = countAttackers( victim ) - 1;
		attackers = URANGE(0,attackers,4);
    	attackers *= attackers;
    	chance -= attackers;
	}

	/* Attacker also gets bonus if dual wieldling */
	if ( get_eq_char( ch, WEAR_OFFHAND) != NULL && get_skill(ch,gsn_dual_wield) > 1 )
		chance -= 2;

	if ( number_percent( ) > chance )
		return FALSE;

	act( "$n's attack is parried by your unseen servant!",  ch, NULL, victim, TO_VICT	);
	act( "Your attack is parried by an unseen servant!", ch, NULL, victim, TO_CHAR	);

	set_defend(victim,ch,STYLE_PARRY);
	drainStamina(victim,1);

	act("You hear the clash of weapons coming from $D.",ch,NULL,NULL,TO_RADIUS);
	return TRUE;
}

/*
 * Check for shield block.
 *
 * Whether you have a shield skill or not you can block while wearing one.
 * Blocks take 3 stamina.  Your base chance to shield block is 10%, modified
 * for level difference and shield size.
 *
 * Small shield:  +2%
 * Medium shield: +5%
 * Large shield:  +10%
 */
bool check_shield_block( Character *ch, Character *victim )
{
	int chance = 5, stam = 3;
	Object *shield;

	if ( !IS_AWAKE(victim) )
		return FALSE;

	if ( (shield=get_eq_char( victim, WEAR_SHIELD )) == NULL )
		return FALSE;

	if ( victim->daze )
		return FALSE;

	if ( shield->value[5] <= 0 || shield->value[5] > 10 )
	{
		log_bug("Bad shield armor value: %d, vnum %d", shield->value[5], shield->pIndexData->vnum );
		return FALSE;
	}

	if ( *armor_table[shield->value[5]].pgpn == gpn_buckler_shields )
	{
		chance -= 2;
		stam = 1;
	}
	else
	if ( *armor_table[shield->value[5]].pgpn == gpn_small_shields )
	{
		chance += 2;
		stam = 3;
	}
	else
	if ( *armor_table[shield->value[5]].pgpn == gpn_medium_shields )
	{
		chance += 5;
		stam = 5;
	}
	else
	if ( *armor_table[shield->value[5]].pgpn == gpn_large_shields )
	{
		chance += 10;
		stam = 7;
	}
	else
	{
		log_bug("bad shield type %d on vnum %d",
            shield->value[5], shield->pIndexData->vnum );
		return FALSE;
	}

	if ( HAS_PROF(victim,gpn_improved_shield))
		chance += 5;

	if ( ch->stamina < stam )
		return FALSE;

	chance += victim->level;
	chance -= ch->level;

	if ( victim->fighting != ch )
	{
		int attackers;

		attackers = countAttackers(victim)-1;
		attackers = URANGE(0,attackers,4);
    	attackers *= attackers;
    	chance -= attackers;
	}

	if ( !can_see(ch,victim) )
		chance /= 2;

	if ( number_percent( ) > chance )
		return FALSE;

	act( "You block $n's attack with your shield.",  ch, NULL, victim, TO_VICT);
	act( "$N blocks your attack with a shield.", ch, NULL, victim, TO_CHAR);
	act("$N blocks $n's attack with $S shield.", ch, NULL, victim, TO_NOTVICT );
	drainStamina(victim,stam);
	set_defend(victim,ch,STYLE_BLOCK);
	act("You heard the clash of a weapon on a shield from $D.",ch,NULL,NULL,TO_RADIUS);
	return TRUE;
}


bool check_intercept( Character *ch, Character *victim )
{
	int chance = 10;
	int skill_bonus;
	Character *save;

    for ( save = victim->in_room->people ; save ; save = save->next_in_room )
        if ( save->intercepting == victim )
            break;

    if ( !save )
        return FALSE;

	if ( save == ch )
		return FALSE;

	/* can't rescue below your level */
	if ( is_safe( ch, save ) )
		return FALSE;

	if ( !IS_AWAKE(save) )
		return FALSE;

	if ( save->stamina < 4 )
		return FALSE;

	if ( save->daze )
		return FALSE;

	if ((skill_bonus = get_skill(save,gsn_intercept)) < 1 )
		return FALSE;
	else
		skill_bonus = ( 100 + (skill_bonus * 100 / save->level ) );

	chance = skill_bonus * chance / 100;
	chance += save->level;
	chance -= ch->level;

	/*
	 * If victim doesn't have hand-to-hand practices, and is unarmed, parry chance
	 * is severely reduced.
	 */
	if ( get_eq_char( save, WEAR_WIELD ) == NULL )
	{
		/* There's normally a 50% penalty to parrying while unarmed */
		/* This is reduced by the skill_bonus ratio for unarmed combat */
		int bonus;

		if ( (bonus = get_skill(save,gsn_hand_to_hand)) < 1 )
			bonus = 0;
		else
			bonus = bonus * 100 / save->level;

		chance -= ( chance/2 * bonus / 100 );
	}

	if (!can_see(ch,save))
		chance /= 2;

	/* Victim gets bonus if dual wielding */
	if ( get_eq_char( save, WEAR_OFFHAND ) != NULL && get_skill(save,gsn_dual_wield) > 1 )
		chance += 2;

	/* Attacker also gets bonus if dual wieldling */
	if ( get_eq_char( ch, WEAR_OFFHAND) != NULL && get_skill(ch,gsn_dual_wield) > 1 )
		chance -= 2;

	if ( number_percent( ) > chance )
		return FALSE;

	act( "You intercept $N's attack!", save, NULL, ch, TO_CHAR );
	act( "$n intercepts your attack!", save, NULL, ch, TO_VICT );
	act( "$n intercepts $N's attack!", save, NULL, ch, TO_NOTVICT );
	drainStamina(save,4);
	return TRUE;
}

/*
 * Fade NPCs can shift planes and attacks can miss then
 */
bool check_fade( Character *ch, Character *victim )
{
	int chance = 10;

	if ( !IS_AWAKE(victim) )
		return FALSE;

	if ( victim->daze )
		return FALSE;

    chance += victim->level;
    chance -= ch->level;

	if ( number_percent( ) > chance )
		return FALSE;

	act( "You fade and $n's attack passes harmlessly through you.",
                                            ch, NULL, victim, TO_VICT	);
	act( "$N fades and your attack passes harmlessly through $M.",
                                            ch, NULL, victim, TO_CHAR	);
	return TRUE;
}

/*
 * Check for dodge.
 *
 * Base chance = 10%.
 * With high evade it can get up to 20%
 */
bool check_dodge( Character *ch, Character *victim )
{
	int chance = 10;
	int skill_bonus;

	if ( !IS_AWAKE(victim) )
		return FALSE;

	if ( victim->stamina < 2 )
		return FALSE;

	if ( victim->daze )
		return FALSE;

    if ((skill_bonus = get_skill(victim,gsn_dodge)) < 1 )
	    return FALSE;
    else
	    skill_bonus = ( 100 + (skill_bonus * 100 / victim->level ) );
 
    chance = skill_bonus * chance / 100;
    chance += victim->level;
    chance -= ch->level;

	if ( victim->fighting != ch )
	{
		int attackers;

		attackers = countAttackers(victim)-1;
    	attackers = URANGE(0,attackers,4);
    	attackers *= attackers;
    	chance -= attackers;
	}

    chance += getAbilitySeries( ch, "elusive" ) * 3;

    // Check for a species enemy
    if ( isSpeciesEnemy( ch, victim ) ) // ch is victim's species enemy
        chance = 3 * chance / 2;

	if (!can_see(victim,ch))
		chance /= 2;
    
	if ( number_percent( ) > chance )
		return FALSE;

	act( "You evade $n's attack.", ch, NULL, victim, TO_VICT	);
	act( "$N evades your attack.", ch, NULL, victim, TO_CHAR	);
	drainStamina(victim,2);
	set_defend(victim,ch,STYLE_EVADE);
	return TRUE;
}

/*
 * Set position of a victim.
 */
void update_pos( Character *victim )
{
	if ( victim->base_hit > 0 )
	{
		if ( victim->position <= POS_STUNNED )
			victim->position = POS_STANDING;
		victim->on = NULL;
		return;
	}

	if ( IS_NPC(victim) && victim->base_hit < 1 )
	{
		victim->position = POS_DEAD;
		return;
	}

	if ( victim->base_hit <= -11 )
	{
		victim->position = POS_DEAD;
		return;
	}

		 if ( victim->base_hit <= -6 ) victim->position = POS_MORTAL;
	else if ( victim->base_hit <= -3 ) victim->position = POS_INCAP;
	else						  victim->position = POS_STUNNED;

 	/* Fizzle spells */
    if ( IS_SET(victim->act,PLR_IS_CASTING) && !IS_NPC(victim) )
    {
    	send_to_char("&RYour concentration is broken and your spell fizzles.&x\n\r",victim);
        act("$n's spell is interrupted!",victim,NULL,NULL,TO_ROOM)  ;
        REMOVE_BIT(victim->act,PLR_IS_CASTING);

        free_casting_data( victim->casting );
        victim->casting = NULL;
        victim->wait = 0;
    }

	return;
}



/*
 * Start fights.
 */
void set_fighting( Character *ch, Character *victim )
{
	if ( ch->fighting != NULL )
	{
		log_bug( "Set_fighting: %s already fighting %s (tried to set %s)", 
			ch->name, ch->fighting->name, victim->name );
		return;
	}

	if ( IS_AFFECTED(ch, AFF_SLEEP) )
		affect_strip( ch, gsn_sleep );

	ch->fighting = victim;
	ch->position = POS_FIGHTING;

	return;
}



/*
 * Stop fights.
 */
void stop_fighting( Character *ch, bool fBoth )
{
	Character *fch;

	for ( fch = char_list; fch != NULL; fch = fch->next )
	{
		if ( fch == ch || ( fBoth && fch->fighting == ch ) )
		{
			fch->fighting	= NULL;
			fch->position	= IS_NPC(fch) ? fch->default_pos : POS_STANDING;
			update_pos( fch );
		}
	}

	/* Check for somebody still fighting this guy 
	for( fch = ch->in_room->people ; fch != NULL ; fch = fch->next_in_room )
	{
		if ( fch->fighting == ch )
			set_fighting( ch, fch );
	}*/

	return;
}

void drop_equipment( Character *ch )
{
	Object *obj;
	Object *obj_next;

	if ( money_total(ch) > 0 ) 
	{
		obj_to_room( create_money( ch->coins ), ch->in_room );
		memset(ch->coins,0,sizeof(ch->coins));
	}
	
	for ( obj = ch->carrying; obj != NULL; obj = obj_next )
	{
		bool floating = FALSE;

        if ( IS_NPC(ch) && !IS_SET(obj->extra_flags,ITEM_KEEP_CONDITION))
        {
            obj->condition = 90 + dice(1,10);
            obj->durability = 90 + dice(1,10);
        }

		obj_next = obj->next_content;
		if (obj->wear_loc == WEAR_FLOAT)
			floating = TRUE;

		obj_from_char( obj );
		if (obj->item_type == ITEM_POTION)
			obj->timer = number_range(500,1000);

		if (obj->item_type == ITEM_SCROLL)
			obj->timer = number_range(1000,2500);

		if (IS_SET(obj->extra_flags,ITEM_ROT_DEATH) && !floating)
		{
			obj->timer = number_range(5,10);
			REMOVE_BIT(obj->extra_flags,ITEM_ROT_DEATH);
		}

		REMOVE_BIT(obj->extra_flags,ITEM_VIS_DEATH);

		if ( IS_SET( obj->extra_flags, ITEM_INVENTORY ) )
			extract_obj( obj );
		else if (floating)
		{
			if (IS_OBJ_STAT(obj,ITEM_ROT_DEATH)) /* get rid of it! */
			{ 
				if (obj->contains != NULL)
				{
					Object *in, *in_next;
	
					act("$p evaporates,scattering its contents.", ch,obj,NULL,TO_ROOM);
					for (in = obj->contains; in != NULL; in = in_next)
					{
						in_next = in->next_content;
						obj_from_obj(in);
						obj_to_room(in,ch->in_room);
					}
		 		}
		 		else
					act("$p evaporates.", ch,obj,NULL,TO_ROOM);

		 		extract_obj(obj);
			}
			else
			{
				act("$p falls to the floor.",ch,obj,NULL,TO_ROOM);
				obj_to_room(obj,ch->in_room);
			}
		}
		else
		{
			obj_to_room( obj, ch->in_room );
		}
	}

	return;
}



/*
 * Make a corpse out of a character.
 */
void make_corpse( Character *ch, bool fLootTable )
{
	char buf[MAX_STRING_LENGTH];
	Object *corpse = NULL;
	Object *obj;
	Object *obj_next;
	char *name;

	if ( IS_SET(ch->form,FORM_INSTANT_DECAY))
	{
		drop_equipment( ch );
		return;
	}

	if ( IS_NPC(ch) )
	{
		name		= ch->short_descr;
		corpse		= create_object(get_obj_index(OBJ_VNUM_CORPSE_NPC));
		corpse->value[2] = ch->race;
		corpse->timer	= number_range( 3, 6 );
	
		if ( money_total(ch) > 0 ) {
			obj_to_obj( create_money( ch->coins ), corpse );
			memset(ch->coins,0,sizeof(ch->coins));
		}
		corpse->cost = 0;
	}
	else
	{
		name		= ch->name;
		corpse		= create_object(get_obj_index(OBJ_VNUM_CORPSE_PC));
		corpse->timer	= 60;
		REMOVE_BIT(ch->pcdata->options,OPT_CANLOOT);
		corpse->owner = str_dup(ch->name);
		if (!is_clan(ch))
			corpse->value[7] = TRUE; /* non-clan corpse */
		if ( money_total(ch) )
		{
			obj_to_obj(create_money( ch->coins ), corpse);
			memset(ch->coins,0,sizeof(ch->coins));
		}
		corpse->cost = 0;
	}

	corpse->level = ch->level;

	sprintf( buf, corpse->short_descr, name );
	free_string( corpse->short_descr );
	corpse->short_descr = str_dup( buf );
	
	sprintf( buf, corpse->description, name );
	free_string( corpse->description );
	corpse->description = str_dup( buf );

    if ( !IS_NPC(ch) )
    {
        strcpy( buf, corpse->name );
        snprintf(buf+strlen(buf),sizeof(buf)-strlen(buf)," %s", ch->name );
        free_string( corpse->name );
        corpse->name = str_dup( buf );
    }

	for ( obj = ch->carrying; obj != NULL; obj = obj_next )
	{
		bool floating = FALSE;
		
        obj_next = obj->next_content;

        if ( !IS_NPC(ch) && IS_SET(obj->extra_flags,ITEM_STICKY) )
            continue;

    	if ( IS_NPC(ch) && !IS_SET(obj->extra_flags,ITEM_KEEP_CONDITION))
    	{
        	obj->condition = 90 + dice(1,10);
        	obj->durability = 90 + dice(1,10);
    	}

		if (obj->wear_loc == WEAR_FLOAT)
			floating = TRUE;
		obj_from_char( obj );
		if (obj->item_type == ITEM_POTION) obj->timer = number_range(500,1000);
		if (obj->item_type == ITEM_SCROLL) obj->timer = number_range(1000,2500);
		if (IS_SET(obj->extra_flags,ITEM_ROT_DEATH) && !floating)
		{
			obj->timer = number_range(5,10);
			REMOVE_BIT(obj->extra_flags,ITEM_ROT_DEATH);
		}
		REMOVE_BIT(obj->extra_flags,ITEM_VIS_DEATH);
		if ( IS_SET( obj->extra_flags, ITEM_INVENTORY ) )
			 extract_obj( obj );
		else if (floating)
		{
			if (IS_OBJ_STAT(obj,ITEM_ROT_DEATH)) /* get rid of it! */
			{ 
				if (obj->contains != NULL)
				{
					Object *in, *in_next;
	
					act("$p evaporates, scattering its contents.",
					ch,obj,NULL,TO_ROOM);
					for (in = obj->contains; in != NULL; in = in_next)
					{
						in_next = in->next_content;
						obj_from_obj(in);
						obj_to_room(in,ch->in_room);
					}
		 		}
		 		else
					act("$p evaporates.", ch,obj,NULL,TO_ROOM);

		 		extract_obj(obj);
			}
			else
			{
				act("$p falls to the floor.",ch,obj,NULL,TO_ROOM);
				obj_to_room(obj,ch->in_room);
			}
		}
		else
		{
			obj_to_obj( obj, corpse );
		}
	}

	/* check for hides */
	if ( fLootTable )
	{
		checkForHides( ch, corpse );
		checkForVenom( ch, corpse );
	}

	obj_to_room( corpse, ch->in_room );
	return;
}



/*
 * Improved Death_cry contributed by Diavolo.
 */
void death_cry( Character *ch )
{
	char *msg;
	int vnum;

	vnum = 0;
	msg = "You hear $n's death cry.";

	switch ( number_bits(4))
	{
	case  0: msg  = "$n hits the ground ... DEAD.";			break;
	case  1: 
	if (ch->material == 0)
	{
		msg  = "$n splatters blood on your armor.";		
		break;
	}
	case  2: 							
	if (IS_SET(ch->parts,PART_GUTS))
	{
		msg = "$n spills $s guts all over the floor.";
		vnum = OBJ_VNUM_GUTS;
	}
	break;
	case  3: 
	if (IS_SET(ch->parts,PART_HEAD))
	{
		msg  = "$n's severed head plops on the ground.";
		vnum = OBJ_VNUM_SEVERED_HEAD;				
	}
	break;
	case  4: 
	if (IS_SET(ch->parts,PART_HEART))
	{
		msg  = "$n's heart is torn from $s chest.";
		vnum = OBJ_VNUM_TORN_HEART;				
	}
	break;
	case  5: 
	if (IS_SET(ch->parts,PART_ARMS))
	{
		msg  = "$n's arm is sliced from $s dead body.";
		vnum = OBJ_VNUM_SLICED_ARM;				
	}
	break;
	case  6: 
	if (IS_SET(ch->parts,PART_LEGS))
	{
		msg  = "$n's leg is sliced from $s dead body.";
		vnum = OBJ_VNUM_SLICED_LEG;				
	}
	break;
	case 7:
	if (IS_SET(ch->parts,PART_BRAINS))
	{
		msg = "$n's head is shattered, and $s brains splash all over you.";
		vnum = OBJ_VNUM_BRAINS;
	}
	}

	act( msg, ch, NULL, NULL, TO_ROOM );

	if ( vnum != 0 )
	{
	char buf[MAX_STRING_LENGTH];
	Object *obj;
	char *name;

	name		= IS_NPC(ch) ? ch->short_descr : ch->name;
	obj		= create_object( get_obj_index( vnum ) );
	obj->timer	= number_range( 4, 7 );

	sprintf( buf, obj->short_descr, name );
	free_string( obj->short_descr );
	obj->short_descr = str_dup( buf );

	sprintf( buf, obj->description, name );
	free_string( obj->description );
	obj->description = str_dup( buf );

	if (obj->item_type == ITEM_FOOD)
	{
		if (IS_SET(ch->form,FORM_POISON))
		    obj->value[3] = 1;
		else if (!IS_SET(ch->form,FORM_EDIBLE))
		    obj->item_type = ITEM_TRASH;
	}

	if ( ch->in_room > 0 )
		obj_to_room( obj, ch->in_room );
	}

	if ( IS_NPC(ch) )
		msg = "You hear something's death cry from $D.";
	else
		msg = "You hear someone's death cry from $D.";

	act(msg,ch,NULL,NULL,TO_RADIUS);

	return;
}



void raw_kill( Character *victim, bool fLootTable )
{
	int i;

	stop_fighting( victim, TRUE );
	death_cry( victim );
	make_corpse( victim, fLootTable );

	if ( IS_NPC(victim) )
	{
		victim->pIndexData->killed++;
		kill_table[URANGE(0, victim->level, MAX_LEVEL-1)].killed++;
		extract_char( victim, TRUE );
		return;
	}

	extract_char( victim, FALSE );
	while ( victim->affected )
	affect_remove( victim, victim->affected );
	victim->affected_by	= race_table[victim->race].aff;
	for (i = 0; i < 4; i++)
		victim->armor[i]= 0;
	victim->position	= POS_RESTING;
	victim->stat_hit		= UMAX( 1, victim->stat_hit  );
	victim->base_hit		= UMAX( 1, victim->base_hit );
	victim->stamina		= UMAX( 1, victim->stamina );
	victim->mana	= UMAX( 1, victim->mana );
	victim->move	= UMAX( 1, victim->move );
/*  save_char_obj( victim ); we're stable enough to not need this :) */
	if ( victim->level < 5 )
	do_outfit(victim,"");
	return;
}



void group_gain( Character *ch, Character *victim )
{
	/*
	 * Monsters don't get kill xp's or alignment changes.
	 * P-killing doesn't help either.
	 * Dying of mortal wounds or poison doesn't give xp to anyone!
	 */
	if ( victim == ch )
		return;
   
	/* XP and alignment changes */
	splitExperience( victim );
	clearMeleeData( victim );

	return;
}

// Modified to include EXP mods
int xp_value( Character *victim, Character *player )
{
	int final;
	double bonus;
	int base_exp, diff;
	extern	int con_diff( int level1, int level2 );

	base_exp = eck[victim->level];

	switch( (diff = con_diff(player->level, victim->level)) )
	{
	case 0:	break;
	case 1:	base_exp = (80 * base_exp / 100); break;
	case 2:	base_exp = (60 * base_exp / 100); break;
	case 3:	base_exp = (40 * base_exp / 100); break;
	case 4:	base_exp = (20 * base_exp / 100); break;
	default:
		if ( diff > 0 ) /* Positive - killer > level than victim */
			return 0;
		else
		{
			int factor;
	
			diff = victim->level - player->level;
			factor = UMIN( 100 + ( diff * 20 ), 300 );
			base_exp = ( factor * base_exp / 100 );
		}
	}

	/* Adjust for wisdom */
	/* Your wisdom bonus is a percentage equal to the natural log of
	 * your wisdom - 2.5 * 20 + 100.
	 */
	bonus = ( log(get_curr_stat(player,STAT_WIS)) - 2.5 ) * 20 + 100;

	final = base_exp * bonus / 100;
	if ( !IS_NPC(player) )
		final = subrace_table[player->pcdata->subrace].exp_adj * final / 100;

	return (base_exp * bonus / 100 );
}

/*
 * Compute xp for a kill.
 * Also adjust alignment of killer.
 * Edit this function to change xp computations.
 */
int xp_compute( Character *gch, Character *victim, int total_levels )
{
	int xp,base_exp;
	int level_range;
	int time_per_level;

	/*  Base XP is level of victim squared divided by 5 */
	base_exp = victim->level * victim->level / 5;

	level_range = victim->level - gch->level;
 
	/* compute the base exp */
	switch (level_range)
	{
	 default : 	base_exp =   0;		break;
	case -9 :	base_exp =   1;		break;
	case -8 :	base_exp =   2;		break;
	case -7 :	base_exp =   5;		break;
	case -6 : 	base_exp =   9;		break;
	case -5 :	base_exp =  11;		break;
	case -4 :	base_exp =  22;		break;
	case -3 :	base_exp =  33;		break;
	case -2 :	base_exp =  50;		break;
	case -1 :	base_exp =  66;		break;
	case  0 :	base_exp =  83;		break;
	case  1 :	base_exp =  99;		break;
	case  2 :	base_exp = 121;		break;
	case  3 :	base_exp = 143;		break;
	case  4 :	base_exp = 165;		break;
	} 
	
	if (level_range > 4)
	base_exp = 160 + 20 * (level_range - 4);

	xp = base_exp;
	/* more exp at the low levels */
	if (gch->level < 6)
		xp = 10 * xp / (gch->level + 4);

	/* less at high */
	if (gch->level > 35 )
	xp =  15 * xp / (gch->level - 25 );

	/* reduce for playing time */
	
	{
	/* compute quarter-hours per level */
	time_per_level = 4 *
			 (gch->played + (int) (current_time - gch->logon))/3600
			 / gch->level;

	time_per_level = URANGE(2,time_per_level,12);
	if (gch->level < 15)  /* make it a curve */
		time_per_level = UMAX(time_per_level,(15 - gch->level));
	xp = xp * time_per_level / 12;
	}
   
	/* randomize the rewards */
	xp = number_range (xp * 3/4, xp * 5/4);

	/* adjust for grouping */
	xp = xp * gch->level/( UMAX(1,total_levels -1) );

	return xp;
}

/*
 * Format: John attacks Joe with his broadsword and <misses> (for d damage).
 */
void dam_message( Character *ch, Character *victim,int dam,int dt,bool immune, bool fSpell, bool fDual, bool fRange )
{
	Object	*weapon;
	char buf1[256], buf2[256], buf3[256];
	char weapon_1st[64], weapon_3rd[64];
	char *attack_1st, *attack_3rd;
	const char *attack;
	bool fShow;
	char cond[25];
	bool vfShow;
	char vcond[25];
	char punct = '.';
        
	if (ch == NULL || victim == NULL)
		return;

	if ( dam > max_stat_hit(victim) / 10 )
		punct = '!';

	sprintf( cond, "(%d%%) ", (UMAX(ch->stat_hit,0) + UMAX(ch->base_hit,0)) * 100 / (max_stat_hit(ch) + ch->max_base_hit) );
	fShow = IS_SET(victim->display, DISP_APPEND_CONDITION) ? TRUE : FALSE;

	sprintf( vcond, "(%d%%) ", (UMAX(victim->stat_hit,0) + UMAX(victim->base_hit,0) ) * 100 / (max_stat_hit(victim) + victim->max_base_hit) );
	vfShow = IS_SET(ch->display, DISP_APPEND_CONDITION) ? TRUE : FALSE;

    weapon_3rd[0] = '\0';
	weapon_1st[0] = '\0';
    if ( (weapon = get_eq_char(ch,fRange ? WEAR_RANGED : (fDual ? WEAR_OFFHAND : WEAR_WIELD) )) != NULL )
	{
		char *weapon_name;

		weapon_name = weapon_table[get_weapon_index(weapon->value[0])].name;
	    snprintf(weapon_3rd,sizeof(weapon_3rd),"with $s %s ",weapon_name);
		snprintf(weapon_1st,sizeof(weapon_1st),"with your %s ",weapon_name);
	}

	/** Melee Hit **/
	if ( dt == TYPE_HIT )
	{
		if (ch  == victim)
		{
			sprintf( buf1, "$n hits $melf.");
			sprintf( buf2, "You hit yourself.");
		}
		else
		{
	    	snprintf( buf1, sizeof(buf1), "$n attacks $N %sand ", weapon_3rd );
	    	snprintf( buf2, sizeof(buf2), "You attack $N %s%sand ", vfShow?vcond:"",weapon_1st );
	    	snprintf( buf3, sizeof(buf3), "$n %s%sattacks you %sand ", fShow?cond:"", fShow?" ":"",weapon_3rd );

			if ( dam > 0 )
			{
				snprintf( buf1 + strlen(buf1), sizeof(buf1) - strlen(buf1), "hits for %d damage%c", dam, punct );
				snprintf( buf2 + strlen(buf2), sizeof(buf2) - strlen(buf2), "hit for &W%d&x damage%c", dam, punct );
				snprintf( buf3 + strlen(buf3), sizeof(buf3) - strlen(buf3), "hits for &R%d&x damage%c", dam, punct );
			}
			else
			{
				snprintf( buf1 + strlen(buf1), sizeof(buf1) - strlen(buf1), "misses.");
				snprintf( buf2 + strlen(buf2), sizeof(buf2) - strlen(buf2), "miss.");
				snprintf( buf3 + strlen(buf3), sizeof(buf3) - strlen(buf3), "misses.");
			}
		}
	}
	else /** Skill or spell **/
	{
		SpellIndex* pSpellIndex;

		/* Set up some defaults so the compiler doesn't bitch at me */
		attack_1st = attack_table[0].noun1st;
		attack_3rd = attack_table[0].noun;
		attack = "empty damage message";

		if ( dt >= 0 && dt <= UMAX(MAX_SKILL,top_spell_vnum) )
		{
			if ( fSpell )
			{
				if( (pSpellIndex = get_spell_index(dt)) != NULL )
				{
					attack  = pSpellIndex->msg_damage;
				}
				else
				{
					log_bug("dam_message: Spell index not found(%d)", dt);
				}
			}
			else
				attack	= skill_table[dt].noun_damage;
		}
		else if ( dt >= TYPE_HIT && dt < TYPE_HIT + MAX_DAMAGE_MESSAGE) 
		{
			attack_1st	= attack_table[dt - TYPE_HIT].noun1st;
			attack_3rd	= attack_table[dt - TYPE_HIT].noun;
			attack		= attack_table[dt - TYPE_HIT].noun1st;
		}
		else
		{
			log_bug( "Dam_message: bad dt %d.", dt );
			dt  = TYPE_HIT;
			attack_1st  = attack_table[0].noun1st;
			attack_3rd  = attack_table[0].noun;
		}

		if (immune)
		{
			if (ch == victim)
			{
			sprintf(buf1,"$n is &Munaffected&x by $s own %s.",attack_1st);
			sprintf(buf2,"Luckily, you are immune to that.");
			} 
			else
			{
				sprintf(buf1,"$N is &Munaffected&x by $n's %s!",attack_1st);
				sprintf(buf2,"$N is &Munaffected&x by your %s!",attack_1st);
				sprintf(buf3,"You are &Munaffected&x by $n's %s.",attack_1st);
			}
		}
		else
		{
			if (ch == victim)
			{
				sprintf( buf1, "$n's %s hits $m.",attack_1st);
				sprintf( buf2, "Your %s hits you.",attack_1st);
			}
			else
			{
				if ( dt >= TYPE_HIT && dt < TYPE_HIT + MAX_DAMAGE_MESSAGE)
				{
		    	    snprintf( buf1, sizeof(buf1), "$n %s $N %sand ",attack_3rd,weapon_3rd );
		    	    snprintf( buf2, sizeof(buf2), "You %s $N %s%sand ",attack_1st,vfShow?vcond:"",weapon_1st );
		    	    snprintf( buf3, sizeof(buf3), "$n %s%s%s you %sand ",fShow?cond:"",fShow?" ":"",attack_3rd,weapon_3rd );
		    	    if ( dam > 0 )
		    	    {
				        snprintf( buf1 + strlen(buf1), sizeof(buf1) - strlen(buf1), "hits for %d damage%c", dam, punct );
				        snprintf( buf2 + strlen(buf2), sizeof(buf2) - strlen(buf2), "hit for &W%d&x damage%c", dam, punct );
				        snprintf( buf3 + strlen(buf3), sizeof(buf3) - strlen(buf3), "hits for &R%d&x damage%c", dam, punct );
		    	        }
		    	    else
		    	    {
				        snprintf( buf1 + strlen(buf1), sizeof(buf1) - strlen(buf1), "misses.");
				        snprintf( buf2 + strlen(buf2), sizeof(buf2) - strlen(buf2), "miss.");
				        snprintf( buf3 + strlen(buf3), sizeof(buf3) - strlen(buf3), "misses.");
		    	    }
				}
				else /* skill or spell */
				{
	 				if ( dam > 0 )
	  				{
						sprintf( buf1, "$n's %s hits $N for %d damage%c",  attack,  dam, punct );
						sprintf( buf2, "Your %s hits $N %sfor &W%d&x damage%c",  attack, vfShow ? vcond : "", dam, punct );
						sprintf( buf3, "$n's %s%s hits you for &R%d&x damage%c", fShow ? cond : "", attack, dam, punct );
	 				}
					else
					{
						sprintf( buf1, "$n's %s misses $N.",  attack );
						sprintf( buf2, "Your %s misses $N. %s",  attack, vfShow ? vcond : "" );
						sprintf( buf3, "$n's %s%s misses you.", fShow ? cond : "", attack );
					}
				}
			}
		}
	}

	if (ch == victim)
	{
		act(buf1,ch,NULL,NULL,TO_ROOM);
		act(buf2,ch,NULL,NULL,TO_CHAR);
	}
	else
	{
		act( buf1, ch, NULL, victim, TO_NOTVICT );
		act( buf2, ch, NULL, victim, TO_CHAR );
		act( buf3, ch, NULL, victim, TO_VICT );
	}

	return;
}



/*
 * Disarm a creature.
 * Caller must check for successful attack.
 */
void disarm( Character *ch, Character *victim )
{
	Object *obj;

	if ( ( obj = get_eq_char( victim, WEAR_WIELD ) ) == NULL && ( obj = get_eq_char( victim, WEAR_OFFHAND ) ) == NULL)
	return;

	act( "$n DISARMS you and sends your weapon flying!", 
	 ch, NULL, victim, TO_VICT	);
	act( "You disarm $N!",  ch, NULL, victim, TO_CHAR	);
	act( "$n disarms $N!",  ch, NULL, victim, TO_NOTVICT );

	obj_from_char( obj );
	if ( IS_OBJ_STAT(obj,ITEM_NODROP) || IS_OBJ_STAT(obj,ITEM_INVENTORY) )
	obj_to_char( obj, victim );
	else
	{
	obj_to_room( obj, victim->in_room );
	if (IS_NPC(victim) && victim->wait == 0 && can_see_obj(victim,obj))
		get_obj(victim,obj,NULL);
	}

	return;
}

/*
 * The berserk abilities restores 25% of lost HP
 * and gives you a +hit/+dam bonus equal to a base
 * 25% of your level.  This value can go up to 50% 
 * of your level depending on how high your berserk
 * ability is.
 */
void do_berserk( Character *ch, char *argument)
{
	int hp_healed;
	int skill;

	if ( ch->level < skill_table[gsn_berserk].skill_level[ch->class] ||
		skill_table[gsn_berserk].skill_level[ch->class] <= 0 )
	{
		cprintf(ch,"You do not have this ability.\n\r");
		return;
	}

	if (IS_AFFECTED(ch,AFF_BERSERK) )
	{
		cprintf(ch,"You are already affected by a berserk/frenzy.\n\r");
		return;
	}

    if ( REUSE_SKILL(ch,gsn_berserk) )
    {
	    cprintf(ch,"You're still recovering from the last one!\n\r");
	    return;
    }

	if (IS_AFFECTED(ch,AFF_CALM))
	{
		cprintf(ch,"You are too mellow to berserk.\n\r");
		return;
	}

	if (ch->stamina < (skill = get_skill(ch,gsn_berserk) ))
	{
		cprintf(ch,"You need %d stamina to berserk, you're short by %d.\n\r",
			skill, skill - ch->stamina );
		return;
	}
	
	if ( ch->position != POS_FIGHTING || ch->fighting == NULL )
	{
		cprintf(ch,"You aren't fighting anybody!\n\r");
		return;
	}

	/* going into berserk mode heals 25% of your current hp */
	hp_healed = ch->stat_hit / 4;

	{
		Affect af;
		int modifier;
		int bonus;

		modifier = UMAX(skill / 2, 5);
		/* Having higher berserk ratio helps */
		bonus = ( 100 + (skill * 100 / ch->level ) );
	    modifier = bonus * modifier / 100;

		/* Stamina drain */
		drainStamina(ch,skill);

		/* Healing */
		ch->stat_hit += hp_healed;

		cprintf(ch,"You are consumed by a berserker rage!\n\r");
		act("$n is consumed by a berserker rage!",ch,NULL,NULL,TO_ROOM);

		af.where	= TO_AFFECTS;
		af.type		= gsn_berserk;
		af.level	= ch->level;
		af.duration	= seconds(30 + (skill/2));
		af.modifier	= modifier;
		af.bitvector= AFF_BERSERK;
		af.flags	= AFF_SKILL;

		af.location	= APPLY_HITROLL;
		skillAffectToChar(ch,&af);

		af.location	= APPLY_DAMROLL;
		skillAffectToChar(ch,&af);

		af.modifier	= (modifier * -2 );
		af.location	= APPLY_AC;
		skillAffectToChar(ch,&af);
	}

	/* Can only berserk once evvery 4 minutes */
	/* Cooldown lowered for skill	 */	
	{
	
		int reuse = PULSE_PER_SECOND * 60 * 4;

		reuse -= (get_skill(ch,gsn_berserk) * PULSE_PER_SECOND);
		setSkillReuseWait(ch,gsn_berserk,reuse);
	}
}

void do_bash( Character *ch, char *argument )
{
	char arg[MAX_INPUT_LENGTH];
	Character *victim;
	int chance, skill;
	int	size_adj;
	int stamina;

	if ( REUSE_SKILL(ch,gsn_bash) )
	{
		cprintf(ch,"Already?  You're still recovering from the last time.\n\r");
		return;
	}

	one_argument(argument,arg);
 
	if ( (skill = get_skill(ch,gsn_bash)) == 0
		||	 (!IS_NPC(ch)
		&&	  ch->level < skill_table[gsn_bash].skill_level[ch->class]))
	{	
		send_to_char("Bashing? What's that?\n\r",ch);
		return;
	}
 
	if (arg[0] == '\0')
	{
		victim = ch->fighting;
		if (victim == NULL)
		{
			send_to_char("But you aren't fighting anyone!\n\r",ch);
			return;
		}
	}
	else if ((victim = get_char_room(ch,arg)) == NULL)
	{
		send_to_char("No such target here.\n\r",ch);
		return;
	}

	if (victim->position < POS_FIGHTING)
	{
		act("You'll have to let $M get back up first.",ch,NULL,victim,TO_CHAR);
		return;
	} 

	if (victim == ch)
	{
		send_to_char("You try to bash your brains out, but fail.\n\r",ch);
		return;
	}

	if (is_safe(ch,victim))
		return;

	if (IS_AFFECTED(ch,AFF_CHARM) && ch->master == victim)
	{
		act("But $N is your friend!",ch,NULL,victim,TO_CHAR);
		return;
	}

	stamina = UMAX(10,20+ch->level-skill);
	if ( ch->stamina < stamina )
	{
		cprintf(ch,"You are short by %d stamina.\n\r",stamina - ch->stamina );
		return;
	}

	/* modifiers */

	/* size  and weight */
	chance = 50;
	applySkillAdjust( &chance, 50, skill, ch->level );

	size_adj = ch->size - victim->size;
	size_adj *= size_adj;
	size_adj += 10;
	if ( victim->size > ch->size )
		size_adj *= -1;

	chance += size_adj;
	chance += applyLevelDifference( ch->level, victim->level );

	/* now the attack */
	if (number_percent() < chance )
	{
        // Check safe fall - bash skill vs level
        if ( !IS_NPC(victim) && HAS_PROF(victim,gsn_safe_fall) &&
            skill + dice(1,10) < victim->level + dice(1,10) )
        {
            act("$n slasm into you, but you quickly roll to your feet!",ch,NULL,victim,TO_VICT);
		    act("You slam into $N, but $E quickly rolls to $S feet!",ch,NULL,victim,TO_CHAR);
		    act("$n slams into $N, who quickly rolls back to $S feet!", ch,NULL,victim,TO_NOTVICT);
        }
        else
        {
		    act("$n slams into you, leaving you stunned!", ch,NULL,victim,TO_VICT);
		    act("You slam into $N, and leave $M stunned!",ch,NULL,victim,TO_CHAR);
		    act("$n slams into $N, leaving $M stunned!", ch,NULL,victim,TO_NOTVICT);

		    DAZE_STATE(victim,4*PULSE_PER_SECOND);
		    victim->position = POS_RESTING;
		    damage(ch,victim,number_range(2,2 + 2 * ch->size + chance/20),gsn_bash, DAM_BASH,0);
        }
	}
	else
	{
		damage(ch,victim,0,gsn_bash,DAM_BASH,0);
		act("You miss $N entirely and stumble to the ground!", ch,NULL,victim,TO_CHAR);
		act("$n tries to body slam $N and stumbles to the ground.", ch,NULL,victim,TO_NOTVICT);
		act("You evade $n's bash, causing $m to fall flat on $s face.", ch,NULL,victim,TO_VICT);
	}

	setSkillReuseWait(ch,gsn_bash,PULSE_PER_SECOND * 20);
	drainStamina(ch,stamina);
	return;
}

void do_dirt( Character *ch, char *argument )
{
	char arg[MAX_INPUT_LENGTH];
	Character *victim;
	int chance;

	one_argument(argument,arg);

	if ( (chance = get_skill(ch,gsn_dirt)) == 0
	||   (!IS_NPC(ch)
	&&	ch->level < skill_table[gsn_dirt].skill_level[ch->class]))
	{
	send_to_char("You get your feet dirty.\n\r",ch);
	return;
	}

	if (arg[0] == '\0')
	{
	victim = ch->fighting;
	if (victim == NULL)
	{
		send_to_char("But you aren't in combat!\n\r",ch);
		return;
	}
	}

	else if ((victim = get_char_room(ch,arg)) == NULL)
	{
	send_to_char("They aren't here.\n\r",ch);
	return;
	}

	if (IS_AFFECTED(victim,AFF_BLIND))
	{
	act("$E's already been blinded.",ch,NULL,victim,TO_CHAR);
	return;
	}

	if (victim == ch)
	{
	send_to_char("Very funny.\n\r",ch);
	return;
	}

	if (is_safe(ch,victim))
	return;

	if (IS_AFFECTED(ch,AFF_CHARM) && ch->master == victim)
	{
	act("But $N is such a good friend!",ch,NULL,victim,TO_CHAR);
	return;
	}

	/* modifiers */

	/* dexterity */
	chance += get_curr_stat(ch,STAT_DEX);
	chance -= 2 * get_curr_stat(victim,STAT_DEX);

	/* speed  */
	if (IS_AFFECTED(ch,AFF_HASTE))
		chance += 10;
	if (IS_AFFECTED(victim,AFF_HASTE))
		chance -= 25;

	/* level */
	chance += (ch->level - victim->level) * 2;

	/* sloppy hack to prevent false zeroes */
	if (chance % 5 == 0)
	chance += 1;

	/* terrain */

	switch(ch->in_room->sector_type)
	{
	case(SECT_INSIDE):		chance -= 20;	break;
	case(SECT_CITY):		chance -= 10;	break;
	case(SECT_FIELD):		chance +=  5;	break;
	case(SECT_FOREST):				break;
	case(SECT_HILLS):				break;
	case(SECT_MOUNTAIN):		chance -= 10;	break;
	case(SECT_WATER_SWIM):		chance  =  0;	break;
	case(SECT_WATER_NOSWIM):	chance  =  0;	break;
	case(SECT_AIR):			chance  =  0;  	break;
	case(SECT_ICE):			chance = 0; break;
	case(SECT_DESERT):		chance += 10;   break;
	}

	if (chance == 0)
	{
	send_to_char("There isn't any dirt to kick.\n\r",ch);
	return;
	}

	/* now the attack */
	if (number_percent() < chance)
	{
	Affect af;
	act("$n is blinded by the dirt in $s eyes!",victim,NULL,NULL,TO_ROOM);
	act("$n kicks dirt in your eyes!",ch,NULL,victim,TO_VICT);
	damage(ch,victim,number_range(2,5),gsn_dirt,DAM_NONE,0);
	send_to_char("You can't see a thing!\n\r",victim);
	check_improve(ch,gsn_dirt,TRUE,2);
	WAIT_STATE(ch,skill_table[gsn_dirt].beats);

	af.where	= TO_AFFECTS;
	af.type 	= gsn_dirt;
	af.level 	= ch->level;
	af.duration	= 0;
	af.location	= APPLY_HITROLL;
	af.modifier	= -4;
	af.bitvector 	= AFF_BLIND;

	skillAffectToChar(victim,&af);
	}
	else
	{
	damage(ch,victim,0,gsn_dirt,DAM_NONE,DF_SHOW);
	check_improve(ch,gsn_dirt,FALSE,2);
	WAIT_STATE(ch,skill_table[gsn_dirt].beats);
	}
	check_killer(ch,victim);
}

void do_mending( Character *ch, char *argument )
{
	int skill;

	if ( REUSE_SKILL(ch, gsn_mending) || REUSE_SKILL( ch, gsn_recall ) )
	{
		cprintf(ch,"You may not mend again so soon.\n\r");
		return;
	}

    if ( (skill = get_raw_skill(ch,gsn_body)) < 38)
    {
        cprintf(ch,"You must have Body trained to 38 to mend.\n\r");
        return;
    }

	ch->base_hit = ch->max_base_hit;
	act("You mend your wounds.",ch,NULL,NULL,TO_CHAR);
	act("$n mends $s wounds.",ch,NULL,NULL,TO_ROOM);
	setSkillReuseWait(ch,gsn_mending,PULSE_PER_SECOND * 300);
	return;
}

void do_pall( Character *ch, char *argument )
{
	char arg[MAX_INPUT_LENGTH];
	Character *victim;
	int chance, skill;
	int stamina;

    if ( REUSE_SKILL(ch,gsn_pall) )
    {
		cprintf(ch,"You are not prepared to use the pall.\n\r");
		return;
    }

	one_argument(argument,arg);

	if ( (skill = get_skill(ch,gsn_spirit)) < 47)
	{
		cprintf(ch,"You must have Spirit trained to 47 to use pall pall.\n\r");
		return;
	}

	if (arg[0] == '\0')
	{
		victim = ch->fighting;
		if (victim == NULL)
		{
			send_to_char("You aren't fighting anyone!\n\r",ch);
			return;
	 	}
	}
	else if ((victim = get_char_room(ch,arg)) == NULL)
	{
		send_to_char("You don't see that victim here.\n\r",ch);
		return;
	}

	if (is_safe(ch,victim))
		return;

	/* Chance = Spirit Skill + Monk Level + Monk Wis - Willpower save + level adj */
	chance = (skill/2) + (get_curr_stat(ch,STAT_WIS)/2) - calc_save(victim,SAVE_WILLPOWER) + applyLevelDifference(ch->level,victim->level);

	if (victim == ch)
	{
		send_to_char("You don't want to use it on yourself!\n\r",ch);
		return;
	}

	if (IS_AFFECTED(ch,AFF_CHARM) && ch->master == victim)
	{
		act("$N is your beloved master.",ch,NULL,victim,TO_CHAR);
		return;
	}

	stamina = UMAX(5,10+ch->level-skill);
	if ( ch->stamina < stamina )
	{
		cprintf(ch,"You are short by %d stamina.\n\r", stamina - ch->stamina );
		return;
	}

	/* now the attack */
	if (number_percent() < chance)
	{
		Affect af;
		act("$n supresses your soul with a storm of negative spiritual energy!",ch,NULL,victim,TO_VICT);
		act("You supress $N's soul with a storm of negative spiritual energy!",ch,NULL,victim,TO_CHAR);

        af.where     = TO_AFFECTS;
        af.caster_id = ch->id;
        af.type      = gsn_pall;
        af.level     = ch->level;
        af.duration  = seconds( skill );
        af.location  = APPLY_SPEED;
        af.modifier  = 100 + skill;
        af.bitvector = AFF_SLOW;
        af.flags     = AFF_SKILL;
		af.misc		 = 0;
        skillAffectToChar( victim, &af );
		damage(ch,victim,0,gsn_paralyze,DAM_SPIRIT,0);
	}
	else
	{
		act("Your pall fails to affect $N.",ch,NULL,victim,TO_CHAR);
		act("$n attempts to supress your soul but fails.",ch,NULL,victim,TO_VICT);
		damage(ch,victim,0,gsn_paralyze,DAM_BASH,0);
	} 

	drainStamina(ch,stamina);
    setSkillReuseWait(ch,gsn_pall,PULSE_PER_SECOND * 150);
	return;
}

void do_paralyze( Character *ch, char *argument )
{
	char arg[MAX_INPUT_LENGTH];
	Character *victim;
	int chance, skill;
	int stamina;

    if ( REUSE_SKILL(ch,gsn_paralyze) )
    {
		cprintf(ch,"You are not prepared to paralyze.\n\r");
		return;
    }

	one_argument(argument,arg);

	if ( (skill = get_skill(ch,gsn_mind)) < 18)
	{
		cprintf(ch,"You must have Mind trained to 18 to palm attack.\n\r");
		return;
	}

	if (arg[0] == '\0')
	{
		victim = ch->fighting;
		if (victim == NULL)
		{
			send_to_char("You aren't fighting anyone!\n\r",ch);
			return;
	 	}
	}
	else if ((victim = get_char_room(ch,arg)) == NULL)
	{
		send_to_char("You don't see that victim here.\n\r",ch);
		return;
	}

	if (is_safe(ch,victim))
		return;

	/* Chance */
	/* Paralyze is a dex-based attack, victim gest a reflex save */
	chance = skill + get_curr_stat(ch,STAT_DEX)/2 + calc_save(victim,SAVE_REFLEX) + applyLevelDifference(ch->level,victim->level);

	if (victim == ch)
	{
		send_to_char("You don't want to paralyze yourself!\n\r",ch);
		return;
	}

	if (IS_AFFECTED(ch,AFF_CHARM) && ch->master == victim)
	{
		act("$N is your beloved master.",ch,NULL,victim,TO_CHAR);
		return;
	}

	stamina = UMAX(5,10+ch->level-skill);
	if ( ch->stamina < stamina )
	{
		cprintf(ch,"You are short by %d stamina.\n\r", stamina - ch->stamina );
		return;
	}

	/* now the attack */
	if (number_percent() < chance)
	{
		Affect af;
		act("$n paralyzes you with an adroit flick of the wrist!",ch,NULL,victim,TO_VICT);
		act	("You paralyze $N with an adroit flick of the wrist!",ch,NULL,victim,TO_CHAR); 
		act("$n paralyzes $N with an adroit flick of the wrist!",ch,NULL,victim,TO_NOTVICT);

        af.where     = TO_AFFECTS;
        af.caster_id = ch->id;
        af.type      = gsn_paralyze;
        af.level     = ch->level;
        af.duration  = seconds( skill );
        af.location  = 0;
        af.modifier  = 0;
        af.bitvector = AFF_MESMERIZE;
        af.flags     = AFF_SKILL;
		af.misc		 = 0;
        skillAffectToChar( victim, &af );
	}
	else
	{
		act("$n attempts to paralyze you but fails.",ch,NULL,victim,TO_CHAR);
		act("You attempt to paralyze $N but fail.",ch,NULL,victim,TO_VICT);
		damage(ch,victim,0,gsn_paralyze,DAM_BASH,DF_SHOW);
	} 

	drainStamina(ch,stamina);
    setSkillReuseWait(ch,gsn_paralyze,PULSE_PER_SECOND * 60);
	return;
}

void do_precognition( Character *ch, char *argument )
{
	Affect af;

	if( is_affected( ch, gsn_precognition, AFF_SKILL ) )
	{
		cprintf(ch,"You already benefit from precognition.\n\r");
		return;
	}

	if ( REUSE_SKILL(ch,gsn_precognition) )
	{
		cprintf(ch,"You are not ready.\n\r");
		return;
	}

	if ( get_skill(ch,gsn_mind) < 29 )
	{
		cprintf(ch,"You must have Mind trained to 29 to use this ability.\n\r");
		return;
	}

    af.where     = TO_AFFECTS;
    af.caster_id = ch->id;
    af.type      = gsn_precognition;
    af.level     = ch->level;
    af.duration  = seconds( get_skill(ch,gsn_mind) * 4 );
    af.location  = APPLY_SKILL;
    af.modifier  = get_skill(ch,gsn_mind)/5;
    af.bitvector = 0;
    af.flags     = AFF_SKILL;
	af.misc		 = gsn_dodge;
    skillAffectToChar( ch, &af );
	
	af.misc      = gsn_parry;
    skillAffectToChar( ch, &af );

	af.misc		 = get_weapon_sn( ch, GET_WEAPON_SN );
	skillAffectToChar( ch, &af );

	act("You ready your mind for combat.",ch,NULL,NULL,TO_CHAR);
	act("$n briefly enters into a meditative trance.",ch,NULL,NULL,TO_ROOM);
	WAIT_STATE(ch,PULSE_PER_SECOND*8);
	setSkillReuseWait(ch,gsn_precognition,PULSE_PER_SECOND*300);
	return;
}

void do_kistrike( Character *ch, char *argument )
{
	char arg[MAX_INPUT_LENGTH];
	Character *victim;
	int skill;
	int stamina;

    if ( REUSE_SKILL(ch,gsn_kistrike) )
    {
		cprintf(ch,"You are not prepared to perform a ki strike.\n\r");
		return;
    }

	one_argument(argument,arg);

	if ( (skill = get_skill(ch,gsn_mind)) < 51)
	{
		cprintf(ch,"You must have Mind trained to 51 to ki strike.\n\r");
		return;
	}

	if (arg[0] == '\0')
	{
		victim = ch->fighting;
		if (victim == NULL)
		{
			send_to_char("You aren't fighting anyone!\n\r",ch);
			return;
	 	}
	}
	else if ((victim = get_char_room(ch,arg)) == NULL)
	{
		send_to_char("You don't see that victim here.\n\r",ch);
		return;
	}

	if (is_safe(ch,victim))
		return;

	if (victim == ch)
	{
		send_to_char("You cannot use ki strike on yourself.\n\r",ch);
		return;
	}

	if (IS_AFFECTED(ch,AFF_CHARM) && ch->master == victim)
	{
		act("$N is your beloved master.",ch,NULL,victim,TO_CHAR);
		return;
	}

	stamina = UMAX(5,10+ch->level-skill);
	if ( ch->stamina < stamina )
	{
		cprintf(ch,"You are short by %d stamina.\n\r", stamina - ch->stamina );
		return;
	}

	damage(ch,victim,skill*2,gsn_kistrike,DAM_BASH,DF_SHOW|DF_TURNABLE);

	drainStamina(ch,stamina);
    setSkillReuseWait(ch,gsn_kistrike,PULSE_PER_SECOND * 300);
	return;
}

void do_firewithin( Character *ch, char *argument )
{
	int skill;
	int stamina;
	Affect af;

    if ( REUSE_SKILL(ch,gsn_firewithin) )
    {
		cprintf(ch,"You are not prepared to rekindle your internal fire.\n\r");
		return;
    }

	if ( (skill = get_skill(ch,gsn_spirit)) < 3)
	{
		cprintf(ch,"You must have Spirit trained to 3 to release the fire within.\n\r");
		return;
	}

	if ( is_affected( ch, gsn_firewithin, AFF_SKILL ) )
	{
		cprintf(ch,"You are already infused with the power of flame.\n\r");
		return;
	}

	stamina = UMAX(5,10+ch->level-skill);
	if ( ch->stamina < stamina )
	{
		cprintf(ch,"You are short by %d stamina.\n\r", stamina - ch->stamina );
		return;
	}

    af.where     = TO_AFFECTS;
    af.caster_id = ch->id;
    af.type      = gsn_firewithin;
    af.level     = ch->level;
    af.duration  = seconds( 30 + get_skill(ch,gsn_spirit) );
    af.location  = APPLY_STR;
    af.modifier  = 100 + get_skill(ch,gsn_spirit);
    af.bitvector = 0;
    af.flags     = AFF_SKILL;
    af.misc      = 0;
	skillAffectToChar( ch, &af );

	act("You are infused with the power of spiritual flame!",ch,NULL,NULL,TO_CHAR);
	act("An aura of fire shimmers around $n!",ch,NULL,NULL,TO_ROOM);
	
	drainStamina(ch,stamina);
    setSkillReuseWait(ch,gsn_firewithin,PULSE_PER_SECOND * 300);
	return;
}

void do_palmattack( Character *ch, char *argument )
{
	char arg[MAX_INPUT_LENGTH];
	Character *victim;
	int attack, defend, skill;
	int stamina;

    if ( REUSE_SKILL(ch,gsn_palmattack) )
    {
		cprintf(ch,"You are not prepared to perform a palm attack.\n\r");
		return;
    }

	one_argument(argument,arg);

	if ( (skill = get_skill(ch,gsn_body)) < 27)
	{
		cprintf(ch,"You must have Body trained to 27 to palm attack.\n\r");
		return;
	}

	if (arg[0] == '\0')
	{
		victim = ch->fighting;
		if (victim == NULL)
		{
			send_to_char("You aren't fighting anyone!\n\r",ch);
			return;
	 	}
	}
	else if ((victim = get_char_room(ch,arg)) == NULL)
	{
		send_to_char("You don't see that victim here.\n\r",ch);
		return;
	}

	if (is_safe(ch,victim))
		return;

	/* Chance */
    /* Level + Body Skill + 1d20 vs Level + Con/5 + 1d20 */
    attack = ch->level + get_skill(ch,gsn_body) + dice(1,20);
    defend = victim->level + get_curr_stat(victim,STAT_CON) + dice(1,20);

	if ( victim->size > ch->size + 1 )
		attack /= 2;

	if (victim == ch)
	{
		send_to_char("You don't want to stun yourself!\n\r",ch);
		return;
	}

	if (IS_AFFECTED(ch,AFF_CHARM) && ch->master == victim)
	{
		act("$N is your beloved master.",ch,NULL,victim,TO_CHAR);
		return;
	}

	stamina = UMAX(5,10+ch->level-skill);
	if ( ch->stamina < stamina )
	{
		cprintf(ch,"You are short by %d stamina.\n\r", stamina - ch->stamina );
		return;
	}

	/* now the attack */
	if ( attack > defend )
	{
		act("$n strikes your chest with a painful palm attack!",ch,NULL,victim,TO_VICT);
		act	("You strike $N's chest with a painful palm attack!",ch,NULL,victim,TO_CHAR); 
		act("$n strikes $N's chest with a painful palm attack!",ch,NULL,victim,TO_NOTVICT);
		DAZE_STATE(victim, skill/6 * PULSE_PER_SECOND );
		damage(ch,victim,skill*2,gsn_palmattack,DAM_BASH,DF_SHOW);
	}
	else
	{
		damage(ch,victim,0,gsn_palmattack,DAM_BASH,DF_SHOW);
	} 

	drainStamina(ch,stamina);
    setSkillReuseWait(ch,gsn_palmattack,PULSE_PER_SECOND * 60);
	return;
}

void do_legsweep( Character *ch, char *argument )
{
	char arg[MAX_INPUT_LENGTH];
	Character *victim;
	int chance, skill;
	int stamina;

    if ( REUSE_SKILL(ch,gsn_legsweep) )
    {
		cprintf(ch,"You are not prepared to perform a leg-sweep.\n\r");
		return;
    }

	one_argument(argument,arg);

	if ( (skill = get_skill(ch,gsn_body)) < 5)
	{
		cprintf(ch,"You must have Body trained to 5 to leg sweep.\n\r");
		return;
	}

	if (arg[0] == '\0')
	{
		victim = ch->fighting;
		if (victim == NULL)
		{
			send_to_char("You aren't fighting anyone!\n\r",ch);
			return;
	 	}
	}
	else if ((victim = get_char_room(ch,arg)) == NULL)
	{
		send_to_char("You don't see that victim here.\n\r",ch);
		return;
	}

	if (is_safe(ch,victim))
		return;

	/* Chance */
	chance = UMAX(1,skill/2) + UMAX(1,get_curr_stat(ch,STAT_DEX)/4) + applyLevelDifference(ch->level,victim->level);

	if ( abs(victim->size - ch->size) > 1 )
		chance /= 2;

	if (IS_AFFECTED(victim,AFF_FLYING))
		chance /= 2;

	if (victim->position < POS_FIGHTING)
	{
		act("$N is already down.",ch,NULL,victim,TO_CHAR);
		return;
	}

	if (victim == ch)
	{
		send_to_char("Not even a monk can leg sweep his own legs.\n\r",ch);
		return;
	}

	if (IS_AFFECTED(ch,AFF_CHARM) && ch->master == victim)
	{
		act("$N is your beloved master.",ch,NULL,victim,TO_CHAR);
		return;
	}

	stamina = UMAX(5,10+ch->level-skill);
	if ( ch->stamina < stamina )
	{
		cprintf(ch,"You are short by %d stamina.\n\r", stamina - ch->stamina );
		return;
	}

	/* now the attack */
	if (number_percent() < chance)
	{
		act("$n drops to a crouch and takes your legs out from beneath you!",ch,NULL,victim,TO_VICT);
		act	("You drop to a crouch and take $N's legs out!",ch,NULL,victim,TO_CHAR);
		act("$n drops to a crouch and sweeps $N's legs out from beneath $M!",ch,NULL,victim,TO_NOTVICT);
		DAZE_STATE(victim, number_range(2,4) * PULSE_PER_SECOND );
		victim->position = POS_RESTING;
		set_style(ch,victim,STYLE_LEGSWEEP);
		damage(ch,victim,1,gsn_trip,DAM_BASH,0);
		one_hit(ch,victim,TYPE_UNDEFINED);
	}
	else
	{
		damage(ch,victim,0,gsn_trip,DAM_BASH,DF_SHOW);
	} 

	drainStamina(ch,stamina);
    setSkillReuseWait(ch,gsn_legsweep,PULSE_PER_SECOND * 20);
	return;
}

void do_trip( Character *ch, char *argument )
{
	char arg[MAX_INPUT_LENGTH];
	Character *victim;
	int chance, skill;
	int stamina;

    if ( REUSE_SKILL(ch,gsn_trip) )
    {
	cprintf(ch,"Already?  You're still recovering from the last time.\n\r");
	return;
    }

	one_argument(argument,arg);

	if ( (skill = get_skill(ch,gsn_trip)) == 0
			||   (!IS_NPC(ch) && ch->level < skill_table[gsn_trip].skill_level[ch->class]))
	{
		send_to_char("You either don't have that skill or are too injured to use it.\n\r",ch);
		return;
	}

	if (arg[0] == '\0')
	{
		victim = ch->fighting;
		if (victim == NULL)
		{
			send_to_char("You aren't fighting anyone!\n\r",ch);
			return;
	 	}
	}
	else if ((victim = get_char_room(ch,arg)) == NULL)
	{
		send_to_char("You don't see that victim here.\n\r",ch);
		return;
	}

	if (is_safe(ch,victim))
		return;

	/* Chance */
	chance = UMAX(1,skill/2) + UMAX(1,get_curr_stat(ch,STAT_DEX)/4) + applyLevelDifference(ch->level,victim->level);

	if (IS_AFFECTED(victim,AFF_FLYING))
		chance /= 2;

	if (victim->position < POS_FIGHTING)
	{
		act("$N is already down.",ch,NULL,victim,TO_CHAR);
		return;
	}

	if (victim == ch)
	{
		send_to_char("Tripping yourself won't accomplish much!\n\r",ch);
		return;
	}

	if (IS_AFFECTED(ch,AFF_CHARM) && ch->master == victim)
	{
		act("$N is your beloved master.",ch,NULL,victim,TO_CHAR);
		return;
	}

	stamina = UMAX(5,10+ch->level-skill);
	if ( ch->stamina < stamina )
	{
		cprintf(ch,"You are short by %d stamina.\n\r", stamina - ch->stamina );
		return;
	}

	/* size */
	if (ch->size < victim->size)
		chance += (ch->size - victim->size) * 10;  /* bigger = harder to trip */

	/* now the attack */
	if (number_percent() < chance)
	{
		act("$n trips you and you go down!",ch,NULL,victim,TO_VICT);
		act	("You trip $N and $N goes down!",ch,NULL,victim,TO_CHAR);
		act("$n trips $N, sending $M to the ground.",ch,NULL,victim,TO_NOTVICT);
		DAZE_STATE(victim, number_range(2,4) * PULSE_PER_SECOND );
		victim->position = POS_RESTING;
		set_style(ch,victim,STYLE_TRIP);
		damage(ch,victim,1,gsn_trip,DAM_BASH,0);
	}
	else
	{
		damage(ch,victim,0,gsn_trip,DAM_BASH,DF_SHOW);
	} 
	drainStamina(ch,stamina);
    setSkillReuseWait(ch,gsn_trip,PULSE_PER_SECOND * 10);
	return;
}



void do_kill( Character *ch, char *argument )
{
	char arg[MAX_INPUT_LENGTH];
	Character *victim;

	one_argument( argument, arg );

	if ( arg[0] == '\0' )
	{
	send_to_char( "Kill whom?\n\r", ch );
	return;
	}

	if ( ( victim = get_char_room( ch, arg ) ) == NULL )
	{
	send_to_char( "They aren't here.\n\r", ch );
	return;
	}

	if ( victim == ch )
	{
	send_to_char( "You hit yourself.  Ouch!\n\r", ch );
	one_hit( ch, ch, TYPE_UNDEFINED );
	return;
	}

	if ( is_safe( ch, victim ) )
	return;

	if ( IS_AFFECTED(ch, AFF_CHARM) && ch->master == victim )
	{
	act( "$N is your beloved master.", ch, NULL, victim, TO_CHAR );
	return;
	}

	if ( ch->position == POS_FIGHTING )
	{
	send_to_char( "You do the best you can!\n\r", ch );
	return;
	}

	set_fighting(ch,victim);

	processAttack( ch );
	return;
}



void do_murde( Character *ch, char *argument )
{
	send_to_char( "If you want to MURDER, spell it out.\n\r", ch );
	return;
}



void do_murder( Character *ch, char *argument )
{
	char buf[MAX_STRING_LENGTH];
	char arg[MAX_INPUT_LENGTH];
	Character *victim;

	one_argument( argument, arg );

	if ( arg[0] == '\0' )
	{
	send_to_char( "Murder whom?\n\r", ch );
	return;
	}

	if (IS_AFFECTED(ch,AFF_CHARM) || (IS_NPC(ch) && IS_SET(ch->act,ACT_PET)))
	return;

	if ( ( victim = get_char_room( ch, arg ) ) == NULL )
	{
	send_to_char( "They aren't here.\n\r", ch );
	return;
	}

	if ( victim == ch )
	{
	send_to_char( "Suicide is a mortal sin.\n\r", ch );
	return;
	}

	if ( is_safe( ch, victim ) )
	return;

	if ( IS_AFFECTED(ch, AFF_CHARM) && ch->master == victim )
	{
	act( "$N is your beloved master.", ch, NULL, victim, TO_CHAR );
	return;
	}

	if ( ch->position == POS_FIGHTING )
	{
	send_to_char( "You do the best you can!\n\r", ch );
	return;
	}

	WAIT_STATE( ch, 1 * PULSE_VIOLENCE );
	if (IS_NPC(ch))
	sprintf(buf, "Help! I am being attacked by %s!",ch->short_descr);
	else
		sprintf( buf, "Help!  I am being attacked by %s!", ch->name );
	do_function(victim, &do_yell, buf );
	one_hit( ch, victim, TYPE_UNDEFINED );
	return;
}



void do_backstab( Character *ch, char *argument )
{
	char arg[MAX_INPUT_LENGTH];
	Character *victim;
	Object *obj;
	int skill;

	one_argument( argument, arg );

	if ( (skill = get_skill(ch,gsn_backstab)) < 1 )
	{
		cprintf(ch,"You just don't seem the type.\n\r");
		return;
	}

	if (arg[0] == '\0')
	{
		send_to_char("Backstab whom?\n\r",ch);
		return;
	}

	if (ch->fighting != NULL)
	{
		send_to_char("You cannot backstab while engaged in melee.\n\r",ch);
		return;
	}
	else if ((victim = get_char_room(ch,arg)) == NULL)
	{
		send_to_char("No such target here.\n\r",ch);
		return;
	}

	if ( victim == ch )
	{
		send_to_char( "You can't backstab yourself.\n\r", ch );
		return;
	}

	if ( is_safe( ch, victim ) )
	  return;

	if ( ( obj = get_eq_char( ch, WEAR_WIELD ) ) == NULL)
	{
		send_to_char( "You are missing a key component: a weapon.\n\r", ch );
		return;
	}

	if ( !is_affected(ch,gsn_stealth,AFF_SKILL) )
	{
		act("You need to be sneaking to launch a sneak attack.",ch,NULL,victim,TO_CHAR);
		return;
	}

	one_hit( ch, victim, gsn_backstab );
	return;
}



void do_flee( Character *ch, char *argument )
{
	Room *was_in;
	Room *now_in;
	Character *victim;
	Exit *pexit;
	int attempt, i;
	int door;

	if ( ( victim = ch->fighting ) == NULL )
	{
		if ( ch->position == POS_FIGHTING )
			ch->position = POS_STANDING;
	send_to_char( "You aren't fighting anyone.\n\r", ch );
	return;
	}

	was_in = ch->in_room;
	for ( attempt = 0; attempt < 6; attempt++ )
	{

		door = number_door( );
		if ( ( pexit = was_in->exit[door] ) == 0
		||   pexit->u1.to_room == NULL
		||   IS_SET(pexit->exit_info, EX_CLOSED)
		||   number_range(0,ch->daze) != 0
		|| ( IS_NPC(ch)
		&&   IS_SET(pexit->u1.to_room->room_flags, ROOM_NO_MOB) ) )
			continue;

		move_char( ch, door, FALSE );
		if ( ( now_in = ch->in_room ) == was_in )
			continue;

		ch->in_room = was_in;
		act( "$n has fled!", ch, NULL, NULL, TO_ROOM );
		ch->in_room = now_in;

		if ( !IS_NPC(ch) )
		{
			cprintf(ch, "You flee %s from combat!\n\r", dir_name[door]);
		}

		stop_fighting( ch, TRUE );
		return;
	}

	for(i = 0; i < 6; i++)
	{
		if((pexit = ch->in_room->exit[i] ) != NULL &&
	 		 pexit->u1.to_room != NULL && !IS_SET(pexit->exit_info, EX_CLOSED))
			break;

	}
	if(i == 6)
		cprintf(ch, "PANIC!! There are no open exits from this room!\n\r");
	else
		send_to_char( "PANIC! You couldn't escape!\n\r", ch );
	return;
}



void do_rescue( Character *ch, char *argument )
{
	char arg[MAX_INPUT_LENGTH];
	Character *victim;
	Character *fch, *vch;
	int chance;

    if ( REUSE_SKILL(ch,gsn_rescue) )
    {
        cprintf(ch,"You can't attempt to rescue again.\n\r");
        return;       
    }

	/* Chance = ratio to level + your level - victim's level */
	if ( (chance = get_skill(ch,gsn_rescue)) < 1 )
	{
		cprintf(ch,"You're not skilled in rescue.\n\r");
		if ( IS_NPC(ch) )
			act("$n doesn't know how to rescue.",ch,NULL,NULL,TO_ROOM);
		return;
	}

    chance = ( chance * 100 ) / ch->level;
    chance += ch->level;

	one_argument( argument, arg );
	if ( arg[0] == '\0' )
	{
		send_to_char( "Rescue whom?\n\r", ch );
		return;
	}

	if ( ( victim = get_char_room( ch, arg ) ) == NULL )
	{
		send_to_char( "They aren't here.\n\r", ch );
		if ( IS_NPC(ch) )
			act("$n can't seem to figure out who to rescue.",ch,NULL,NULL,TO_ROOM);
		return;
	}

	if ( victim == ch )
	{
		send_to_char( "What about fleeing instead?\n\r", ch );
		return;
	}

	if ( !IS_NPC(ch) && IS_NPC(victim) )
	{
		send_to_char( "Doesn't need your help!\n\r", ch );
		return;
	}

	if ( ( fch = victim->fighting ) == NULL )
	{
		send_to_char( "That person is not fighting right now.\n\r", ch );
		return;
	}

	chance -= victim->fighting->level;

	if ( number_percent( ) > chance )
	{
		send_to_char( "You fail the rescue.\n\r", ch );
		act("$n tries to rescue you but is unable to intervene.",ch,NULL,victim,TO_VICT);
    	setSkillReuseWait(ch,gsn_rescue,PULSE_PER_SECOND*6);
		return;
	}

	act( "You rescue $N!",  ch, NULL, victim, TO_CHAR	);
	act( "$n rescues you!", ch, NULL, victim, TO_VICT	);
	act( "$n rescues $N!",  ch, NULL, victim, TO_NOTVICT );

	stop_fighting( victim, FALSE );
	if( !is_safe( ch, fch ) )
		set_fighting( ch, fch );

	for( vch = ch->in_room->people ; vch ; vch = vch->next_in_room )
	{
		if( vch->fighting == victim && !is_safe(ch,vch) )
		{
			stop_fighting( vch, FALSE );
			set_fighting( vch, ch );
		}
	}

    setSkillReuseWait(ch,gsn_rescue,PULSE_PER_SECOND*6);  
	return;
}



void do_kick( Character *ch, char *argument )
{
	Character *victim;
	int chance, skill;
	int stamina;

	if ( (skill=get_skill(ch,gsn_kick)) <= 0
	|| (!IS_NPC(ch)
	&&   ch->level < skill_table[gsn_kick].skill_level[ch->class] ) )
	{
		cprintf(ch,"You're as likely to fall over as hit anything.\n\r");
		return;
	}

	if ( ( victim = ch->fighting ) == NULL )
	{
	send_to_char( "You aren't fighting anyone.\n\r", ch );
	return;
	}
 
	if ( REUSE_SKILL(ch,gsn_kick) )
	{
		cprintf(ch,"Not so soon, you'll pull a muscle.\n\r");
		return;
	}

	/* Kick costs the least stamina if your skill is high */
	stamina = UMAX(5,10 + ch->level - skill);
	if ( ch->stamina < stamina )
	{
		cprintf(ch,"You are short by %d stamina.\n\r",stamina-ch->stamina);
		return;
	}

	chance = 50;
	applySkillAdjust( &chance, 100, skill, ch->level );

	if ( number_percent() < chance )
	{
		int dam;
		int adj_base = 50;

		dam = ch->level;
		if ( class_table[ch->class].csn == &csn_monk )
			adj_base = 100;
		applySkillAdjust( &dam, 100, skill, ch->level );

		damage(ch,victim,number_range( dam/2, dam ), gsn_kick,DAM_BASH,DF_SHOW);
	}
	else
		damage( ch, victim, 0, gsn_kick,DAM_BASH,DF_SHOW);

	drainStamina(ch,stamina);
	setSkillReuseWait(ch,gsn_kick,PULSE_PER_SECOND * 6);
	return;
}

void do_disarm( Character *ch, char *argument )
{
	Character *victim;
	Object *obj;
	int chance, skill;

	if ( REUSE_SKILL(ch,gsn_disarm) )
	{
		cprintf(ch,"Not so soon!\n\r");
		return;
	}

	if ((skill = get_skill(ch,gsn_disarm)) == 0)
	{
		send_to_char( "You don't know how to disarm opponents.\n\r", ch );
		return;
	}

	if ( get_eq_char( ch, WEAR_WIELD ) == NULL && get_skill(ch,gsn_hand_to_hand) == 0 )
	{
		cprintf( ch, "You must wield a weapon to disarm.\n\r" );
		return;
	}

	if ( ( victim = ch->fighting ) == NULL )
	{
		send_to_char( "You aren't fighting anyone.\n\r", ch );
		return;
	}

	if ( ( obj = get_eq_char( victim, WEAR_WIELD ) ) == NULL && ( obj = get_eq_char( victim, WEAR_OFFHAND ) ) == NULL)
	{
		send_to_char( "Your opponent is not wielding a weapon.\n\r", ch );
		return;
	}

	/* find weapon skills */
	/* modifiers */

	/* skill */
	chance = 25;
	applySkillAdjust( &chance, 100, skill, ch->level );
	chance += applyLevelDifference( ch->level, victim->level );
 
	/* and now the attack */
	if (number_percent() < chance)
	{
		setSkillReuseWait(ch,gsn_disarm,PULSE_PER_SECOND * 30);
		disarm( ch, victim );
	}
	else
	{
		act("You fail to disarm $N.",ch,NULL,victim,TO_CHAR);
		act("$n tries to disarm you, but fails.",ch,NULL,victim,TO_VICT);
		act("$n tries to disarm $N, but fails.",ch,NULL,victim,TO_NOTVICT);
	}
	check_killer(ch,victim);
	setSkillReuseWait(ch,gsn_disarm,PULSE_PER_SECOND * 30);

	return;
}



void do_sla( Character *ch, char *argument )
{
	send_to_char( "If you want to SLAY, spell it out.\n\r", ch );
	return;
}



void do_slay( Character *ch, char *argument )
{
	Character *victim;
	char arg[MAX_INPUT_LENGTH];

	one_argument( argument, arg );
	if ( arg[0] == '\0' )
	{
	send_to_char( "Slay whom?\n\r", ch );
	return;
	}

	if ( ( victim = get_char_room( ch, arg ) ) == NULL )
	{
	send_to_char( "They aren't here.\n\r", ch );
	return;
	}

	if ( ch == victim )
	{
	send_to_char( "Suicide is a mortal sin.\n\r", ch );
	return;
	}

	if ( !IS_NPC(victim) && victim->level >= get_trust(ch) )
	{
	send_to_char( "You failed.\n\r", ch );
	return;
	}

	act( "You slay $M in cold blood!",  ch, NULL, victim, TO_CHAR	);
	act( "$n slays you in cold blood!", ch, NULL, victim, TO_VICT	);
	act( "$n slays $N in cold blood!",  ch, NULL, victim, TO_NOTVICT );
	raw_kill( victim, xp_value(victim,ch) );
	return;
}

void addGroupDamage( Character *victim, Group *group, int amount )
{
	Melee *md;

	md = findMeleeData( victim, group );
	md->damage += amount;
	md->disposition = DISPOS_AGGRESSIVE;
	md->timer = 60 * PULSE_PER_SECOND / PULSE_MELEE_UPDATE * 3;
	return;
}

Melee *findMeleeData( Character *victim, Group *group )
{
	Melee *md;

	for ( md = victim->melee_list ; md != NULL ; md= md->next )
	{
	/*log_string("findMeleeData: scanning melee data: %p on victim %s",md, victim->name);*/
	if ( md->group == group )
	{
		/*	log_string("findMeleeData: existing group found");*/
		return md;
	}
	}

	/*log_string("findMeleeData: Adding new MELEE DATA group for victim '%s'",victim->name);*/
	/* This group hasn't done any damage yet */
	if( victim->next_dispos == NULL )
		set_NPC_disposition( victim );

	md = new_melee( );
	md->next = victim->melee_list;
	victim->melee_list = md;
	md->group = group;
	return md;
}

/*
 * XP formula
 */
void splitExperience( Character *victim )
{
	Melee *md, *md_top;
//	int mult=100;
	int total_levels, top_level, avg_level, group_num, level;  
	int i, reward, diff;
	int value_to_group, level_bonus;
    extern  int con_diff( int level1, int level2 );

	level = top_level = avg_level = group_num = total_levels = 0;

	/* Search for most damage */
	for ( md_top = md = victim->melee_list ; md != NULL ; md = md->next )
	{
		if ( md->damage >= md_top->damage )
			md_top = md;
	}

   /* have highest damage now, reward each group member */
	if ( md_top == NULL || md_top->group == NULL )
	{
		log_bug("splitExperience: NULL group pointer for md_top",0);
		return;
	}

	/* Search for most damage */
	for ( md = victim->melee_list ; md != NULL ; md = md->next )
	{
		if ( md != md_top )
		{
			for ( i=0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
			{
				if ( md->group->members[i] == NULL )
					continue;
				if ( md->group->members[i]->in_room == victim->in_room )
				{
					int j;
					for(j = 0; j < MAX_PLAYERS_IN_GROUP; j++)
					{
						if(md_top->group->members[j] == NULL)
							continue;
//						log_string("XPDEBUGCHECK: %s received no xp, target was stolen by %s\n", md->group->members[i]->name, md_top->group->members[j]->name);
//						log_string("Position: %d\n", md_top->group->members[j]->position);
//						cprintf(md->group->members[i], "&GBUG CHECK&x: More damage credited to %s\n\r", md_top->group->members[j]->name);
						break;
					}
//					cprintf(md->group->members[i], "&GDEBUG&x: Another group did more damage than you.\n\r");
				}
			}
		}
	}

	for ( i=0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
	{
		if ( md_top->group->members[i] == NULL )
			continue;

		if ( md_top->group->members[i]->in_room == victim->in_room )
		{
//			mult += 8;
//			if ( IS_NPC( md_top->group->members[i] ) )
//				total_levels += (level = (md_top->group->members[i]->level/4));
//			else
//				total_levels += (level = md_top->group->members[i]->level);
			top_level = UMAX(md_top->group->members[i]->level,top_level);
			//Mobs count, can't have a high level pet tanking a lowbie
		}

	}

	for ( i=0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
	{
		if ( md_top->group->members[i] == NULL )
			continue;
		if ( md_top->group->members[i]->in_room == victim->in_room )
		{
			if(!IS_NPC(md_top->group->members[i]) && md_top->group->members[i]->level + THRESHOLD_GROUP_XP >= top_level)
			{//not a mob, and within 4 levels of the top level
				group_num++;
				total_levels+=md_top->group->members[i]->level;
			}
		}

	}

	if(!group_num)
	{//None of the players for the group were in the room, something else got the kill
		return;
	}

	avg_level = total_levels / group_num;

	if ( total_levels <= 0 )
	{//since there was a count of players, they should have 
		log_bug("total levels is 0",0);
		return;
	}

	/* Base value of enemy is based on level table */
	value_to_group = eck[victim->level];

	/* Pet loss, fixed 10% for now */
	for ( i=0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
	{
		if ( md_top->group->members[i] == NULL )
			continue;

		if ( md_top->group->members[i]->in_room == victim->in_room )
		{
			if(!IS_NPC(md_top->group->members[i]) && md_top->group->members[i]->pet && md_top->group->members[i]->pet->in_room == md_top->group->members[i]->in_room)
			//has a pet
			value_to_group -= eck[victim->level] / 10;	
		}

	}


	/* Mod for area */
	if ( IS_NPC(victim) && victim->pIndexData->area != NULL )
	{
		int tmp = 100 + victim->pIndexData->area->exp_mod;
		value_to_group = value_to_group * tmp / 100;
	}

    switch( (diff = con_diff(avg_level, victim->level)) )
    {
    /*case 0: level_bonus = 100; break;*/
    case 1: level_bonus = 75; break;
    case 2: level_bonus = 50; break;
    case 3: level_bonus = 25; break;
    default:
        if ( diff > 0 ) /* Positive - killer > level than victim */
            level_bonus = 0;
        else
        {
			log_string("victim level %d  top level %d", victim->level, top_level );
            diff = victim->level - top_level;
            level_bonus = 100 + ( UMAX(0,diff) * 20 );
        }
    }


	level_bonus = URANGE(0,level_bonus,300);
	value_to_group = level_bonus * value_to_group / 100;

	/* Get  group bonus */
//	value_to_group = mult * value_to_group / 100;
	if(group_num != 1)//leave it alone if it's 1 person in the room
	{
		if(top_level <= 25)
		{
			value_to_group /= group_num;
		}
		else
		{
			value_to_group = (95 - group_num * 5) * value_to_group / 100;
			if(top_level < 40)
			{//prevent integer division accidents!
				value_to_group *= top_level;
				value_to_group /= 40;
			}
		}
	}
//85, 80, 75, etc.

	/* Now divide value_to_group into your level */
	/* Capped at eck * 2 for your level */

    value_to_group = number_range( value_to_group * 4 / 5, value_to_group * 5 / 4);

    for ( i=0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
    {
		Character *pch;

		if ( (pch = md_top->group->members[i]) == NULL )
			continue;

		if (IS_NPC(victim)) 
		{
			if( IS_SET(victim->act,ACT_NOEXP) && pch->in_room == victim->in_room )
			{
				cprintf(pch," ** This NPC is worth no experience. **\n\r");
				continue;
			}

			level = pch->level;

	 		if ( top_level - level > THRESHOLD_GROUP_XP || pch->in_room != victim->in_room )
				continue;

//			reward = value_to_group * level / total_levels;
			reward = value_to_group * level;
			reward /= top_level;


			if(get_curr_stat(pch,STAT_WIS) > 100)
				reward = reward * (100 + (get_curr_stat(pch,STAT_WIS) - 100) / 3) / 100;
			//Wisdom modifier: Up to 150% normal, for 250 wisdom.
			//Every 3 wisdom over 100 gives	1% more xp
			reward = UMIN( reward, eck[level] * 3 );
	
			/* Faction awards */
			applyFactionFromDeath(md_top->group->members[i],victim, reward );
			gain_exp( pch, reward, TRUE );

			if ( reward > 0 )
				cprintf(pch,"&YYou have gained %d experience!&x\n\r", reward );
		}
		else
		{
			int gp;

			gp = guild_point_value( victim );

			if ( IS_NPC( pch ))
			{
				cprintf(pch,"You're an NPC, you don't get no guild points.\n\r");
				continue;
			}

			if ( gp < 0 )
				act(" * &m$N has been killed recently and is worth no guild points.&x",pch,NULL,victim,TO_CHAR);
			else
            if ( pch != victim )
			{
				gp = gp * pch->level / total_levels;
				pch->pcdata->guild_points += gp;
				if ( pch->clan )
					pch->clan->guild_points += gp;
				cprintf(pch," * &cYou have gained %d guild point%s!&x\n\r", gp, gp == 1 ? "" : "s"  );
			}
		}
	}
	return;
}

void clearMeleeData( Character *victim )
{
	Melee *md, *md_next;

	for ( md = victim->melee_list ; md != NULL ; md = md_next )
	{
		md_next = md->next;
		free_melee( md );
	}

	victim->melee_list = NULL;
}

void do_layonhands( Character *ch, char *argument )
{
	Character *victim;
	int skill, amount;
	
	if ( (skill = get_skill(ch,gsn_lay_on_hands) ) < 1 )
	{
		cprintf(ch,"You're not much of a Paladin, are you?\n\r");
		return;
	}

	if ( REUSE_SKILL(ch,gsn_lay_on_hands))
	{
		cprintf(ch,"Not yet, you're still recovering from the last time!\n\r");
		return;
	}
	
	if ( *argument == '\0' )
	{
		cprintf(ch,"Usage: layonhands <target>\n\r");
		return;
	}

	if ( (victim = get_char_room(ch,argument)) == NULL )	
	{
		cprintf(ch,"No such person here.\n\r");
		return;
	}

	amount = ch->level * 4;
	applySkillAdjust( &amount, 100, skill, ch->level );

	victim->base_hit = victim->max_base_hit;
	victim->stat_hit = UMIN(max_stat_hit(victim), victim->stat_hit + amount);
	victim->stamina  = max_stamina(victim);
	victim->move	 = victim->max_move;
	
	if ( ch == victim )
	{
		act("$n glows with a blue aura he $e heals $mself.",ch,NULL,victim,TO_ROOM);
		act("You glow with a blue aura as you heal yourself.",ch,NULL,victim,TO_CHAR);
	}
	else
	{	
		act("$n glows with a blue aura as $e heals $N.",ch,NULL,victim,TO_NOTVICT);
		act("You glow with a blue aura as you heal $N.",ch,NULL,victim,TO_CHAR);
		act("$n glows with a blue aura as $e heals you.",ch,NULL,victim,TO_VICT);
	}

	setSkillReuseWait(ch,gsn_lay_on_hands,PULSE_PER_SECOND * 60 * 20);
	return;
}

void checkForVenom( Character *victim, Object *corpse )
{
	Object *sac;
	int i;

	if ( !IS_NPC(victim) )
		return;

	if ( /*!IS_SET(race_table[victim->race].form, FORM_POISON) &&*/
		 !IS_SET(victim->form,FORM_POISON) )
		return;

	/* Check for race in sack table */
	for( i = 0 ; venom_table[i].race != NULL ; i++ )
	{
		if ( !strcmp(venom_table[i].race,race_table[victim->race].name))
		{
			corpse->value[3] = TRUE;
			if ( number_percent() < venom_table[i].frequency )
			{
				sac = create_sac( corpse, victim, venom_table[i].vnum );
				SET_BIT(corpse->value[0],CORPSE_SACKED);
				obj_to_obj( sac, corpse );
				return;
			}
		}
	}
}

void checkForHides( Character *victim, Object *corpse )
{
	int vnum;
	Object *hide;

	if ( !IS_NPC(victim) )
		return;

	if ( !IS_SET(race_table[victim->race].form, FORM_HAS_HIDE) )
		return;

	/* 50% chance of a hide */
	if ( number_percent() < 33 )
		return;

	/* 50% chance of a tattered hide */
	if ( number_percent() < 66 )
		vnum = VNUM_TATTERED_HIDE;
	else
	if ( number_percent() < 66 )
		vnum = VNUM_HIDE;
	else
		vnum = VNUM_FINE_HIDE;

	hide = create_hide( corpse, vnum );

	SET_BIT(corpse->value[0],CORPSE_SKINNED);

	obj_to_obj( hide, corpse );
}

Object *create_sac( Object *corpse, Character *victim, int vnum )
{
	Object *sack;

	sack = create_object( get_obj_index( vnum ) );
	sack->level = victim->level;

	return sack;
}

Object *create_hide( Object *corpse, int vnum )
{
	Object *hide;
	char	buf[MAX_STRING_LENGTH];
	int		race = corpse->value[2];

    hide = create_object( get_obj_index( vnum ) );  

    /* OK we've got the hide, now we ahve to change its info */
    snprintf(buf,sizeof(buf),hide->short_descr,race_table[race].name);
    free_string( hide->short_descr );  
    hide->short_descr = str_dup( buf );

    snprintf(buf,sizeof(buf),hide->description,race_table[race].name);
    free_string( hide->description );
    hide->description = str_dup( buf );

	snprintf(buf,sizeof(buf),"%s %s",hide->name,race_table[race].name);
	free_string( hide->name );
	hide->name = str_dup( buf );

	return hide;
}

/* Items that are above your level will decay the most rapidly
 * Items at your level and below decay more slowly
 */
void check_condition( Character *ch, Object *obj )
{
	int wear_loc;
	int level_mod;

	level_mod = (obj->level - ch->level) * 2 + 5;
	level_mod = UMAX(0,level_mod);

	/* Condition check */
	if ( number_percent() > level_mod )
		return;

	/*if ( number_percent() < (obj->condition - level_mod) )
		return;*/
 
	/* Durability check */
	if ( number_percent() < (obj->durability - level_mod) )
		return;

	/* Quality check */
	// Masterpiece items of 105% or better never decay
	if ( number_percent() < (obj->quality - level_mod) )
		return;

	
	/* Ok, it decayed, remove it, re-wear it */
	if ( (wear_loc = obj->wear_loc) != WEAR_NONE )
		unequip_char( ch, obj );

	/* check for object destruction */
	if ( --obj->condition < 50 )
	{
		act("$p takes some damage and crumbles to pieces!",ch,obj,NULL,TO_CHAR);
		extract_obj( obj );
	}
	else
	{
		if ( wear_loc != WEAR_NONE )
			equip_char( ch, obj, wear_loc );
		actprintf(ch,obj,NULL,TO_CHAR,"&M ** $p takes some damage (%d%%).",obj->condition);
	}
}

int calcDurabilityDrop( Object *obj, int skill )
{
	float drop, qual, repair;

	if ( obj->condition >= 100 )
		return 0;

	qual = (float) obj->quality;
	repair = (float) (100 - obj->condition);

	/*
     * Drop = (100 - Quality)/2 + RepairAmount/((Quality/10))
     */
	drop = (100.0 - qual)/2 + repair/(( qual ) / 10.0 );
	drop -= ( (skill-100) / 30 );

	if ( drop < 0 )
		return 0;

	return (int) drop;
}

void do_intercept( Character *ch, char *argument )
{
	Character *victim;

	if ( get_skill(ch,gsn_intercept) < 1 )
	{
		cprintf(ch,"Do what, now?\n\r");
		return;
	}

	if ( *argument == '\0' )
	{
		cprintf(ch,"Syntax: intercept <person for whom you'd like to parry attacks>\n\r"
                   "        intercept clear\n\r");
		return;
	}

	if ( !str_cmp(argument,"self") || !str_cmp(argument,"none") || !str_cmp(argument,"clear") )
	{
		ch->intercepting = NULL;
		cprintf(ch,"You are not intercepting for nobody.\n\r");
		return;
	}

	if ( (victim = get_char_room(ch,argument)) == NULL )
	{
		cprintf(ch,"Nobody in this room matching the description '%s'.\n\r", argument );
		return;
	}

	if ( ch->intercepting )
	{
		act("$n is no longer intercepting attacks for you.",ch,NULL,ch->intercepting,TO_VICT);
		act("You stop intercepting attacks for $N.",ch,NULL,ch->intercepting,TO_CHAR);
	}

	ch->intercepting = victim;
	act("You will try to intercept attacks aimed at $N.",ch,NULL,victim,TO_CHAR);
	act("$n will try to intercept attacks aimed at you.",ch,NULL,victim,TO_VICT);
	act("$n will try to intercept attacks aimed at $N.",ch,NULL,victim,TO_NOTVICT);
	return;
}

int modifyDamageForSkill( int dam, int ratio )
{
	if ( ratio < 1 )
		return dam * 10 / 100;
	else
	if ( ratio <= 75 )
	{
		ratio -= 10;
		ratio = ratio * 75 / 65;
		ratio += 25;
		return dam * ratio / 100;
	}
	else /* up to 140% damage bonus for high skill */
	{
		ratio -= 75;
		ratio = ratio * 40 / 35;
		ratio += 100;
		return dam * ratio / 100;
	}
}

void do_distract( Character *ch, char *argument )
{
	char arg[MAX_INPUT_LENGTH];
	Character *victim;
	int chance, skill;
	int stamina;
	int n;
	Affect af;

    if ( (n=REUSE_SKILL(ch,gsn_chicanery)) )
    {
		cprintf(ch,"You need another %d second%s to prepare.\n\r",
			n/PULSE_PER_SECOND,n/PULSE_PER_SECOND==0?"":"s");
		return;
    }

	one_argument(argument,arg);

	if ( (skill = get_skill(ch,gsn_chicanery)) == 0
			||   (!IS_NPC(ch) && ch->level < skill_table[gsn_chicanery].skill_level[ch->class]))
	{
		cprintf(ch,"You either don't have that skill or are too injured to use it.\n\r"); 
		return;
	}
	
	victim = ch->fighting;
	if (victim == NULL)
	{
		send_to_char("You aren't fighting anyone!\n\r",ch);
		return;
	}

	if (is_safe(ch,victim))
		return;

	/* Works 100% on victims whose level is lower than your skill */
	/* For every level above, chance drops by diff squared */
	chance = 100;
	if ( victim->level > skill )
		chance -= ((victim->level-skill) * (victim->level-skill));

	if (IS_AFFECTED(ch,AFF_CHARM) && ch->master == victim)
	{
		act("$N is your beloved master.",ch,NULL,victim,TO_CHAR);
		return;
	}

	stamina = UMAX(5,10+ch->level-skill);
	if ( ch->stamina < stamina )
	{
		cprintf(ch,"You are short by %d stamina.\n\r", stamina - ch->stamina );
		return;
	}

	/* now the attack */
	if (number_percent() < chance)
	{
		act("$n lures you into an disadvatangeous position!",
				ch,NULL,victim,TO_VICT);
		act	("You lure $N off-balance!",ch,NULL,victim,TO_CHAR);
		act("$n lures $N off-balance.",ch,NULL,victim,TO_NOTVICT);
	
		af.type =	TO_AFFECTS;
        af.type     = gsn_chicanery;
        af.level    = ch->level;
        af.duration = seconds(15 + (skill/5));
        af.modifier = 0;
        af.bitvector= 0;
        af.flags    = AFF_SKILL;
        af.location = APPLY_AC;
		af.modifier = skill * -3;
		af.misc = 0;

        skillAffectToChar(victim,&af);
	}
	else
	{
		act("No luck, $N wasn't fooled by your lure.",ch,NULL,victim,TO_CHAR);
		return;
	} 
	drainStamina(ch,stamina);
    setSkillReuseWait(ch,gsn_chicanery,PULSE_PER_SECOND * 40);
	return;
}

int countAttackers( Character *victim )
{
	int count=0;
	Character *ch;

	if ( victim->in_room == NULL )
	{
		log_bug("countAttackers: %s not in a room", victim->name );
		return 0;
	}

	for( ch = victim->in_room->people ; ch != NULL ; ch = ch->next_in_room )
		if ( ch->fighting == victim )
			++count;

	return count;
}


