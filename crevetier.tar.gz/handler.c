/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/**************************************************************************r
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#include <math.h>
#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "recycle.h"
#include "tables.h"
#include "olc.h"

/*
 * Local functions.
 */
void	affect_modify	( Character *ch, Affect *paf, bool fAdd );

/* returns material name -- ROM OLC temp patch */
char *material_name( sh_int num )
{
	return material_type[num].name;     
}

int weapon_type (const char *name)
{
    int type;
 
    for (type = 0; weapon_table[type].name != NULL; type++)
    {
        if (LOWER(name[0]) == LOWER(weapon_table[type].name[0])
        &&  !str_prefix(name,weapon_table[type].name))
            return weapon_table[type].type;
    }
 
    return WEAPON_EXOTIC;
}


char *item_name(int item_type)
{
    int type;

    for (type = 0; item_table[type].name != NULL; type++)
	if (item_type == item_table[type].type)
	    return item_table[type].name;

    return "none";
}

char *weapon_name( int weapon_type)
{
    int type;
 
    for (type = 0; weapon_table[type].name != NULL; type++)
        if (weapon_type == weapon_table[type].type)
            return weapon_table[type].name;
    return "exotic";
}

/* for returning weapon information */
int get_weapon_index( int type )
{
    int i;

    for( i = 0; weapon_table[i].name != NULL; i++ )
	if ( weapon_table[i].type == type )
	    return i;

     return 0;
}

/*
 * Create a 'money' obj.
 */
Object *create_money( long coins[MAX_CURRENCY] )
{
    Object *obj;
	int i;

	obj = create_object( get_obj_index( OBJ_VNUM_COINS ) );
	obj->cost = obj->weight = 0;
	for( i = 0 ; i < MAX_CURRENCY ; i++ )
	{
		obj->value[i] = coins[i];
		obj->cost += (coins[i] * currency_table[i].silver_value);
		obj->weight += (coins[i] / 10);
	}

    return obj;
}

bool spell_is_in_book( int sn, Object *book )
{
    int i;

    if ( book->item_type != ITEM_SPELLBOOK )
		return FALSE;

    for (i=0 ; i<10 ; i++ )
		if ( get10Bits(book->value[i]) == sn )
	    	return TRUE;

    for (i=0 ; i<10 ; i++ )
		if ( get20Bits(book->value[i]) == sn )
	    	return TRUE;

    return FALSE;
}

char *school_bit_name( int sn )
{
	SpellIndex* pSpellIndex;

	if( (pSpellIndex = get_spell_index( sn )) != NULL )
	{
		if ( pSpellIndex->sgsn == NULL )
			return "unclassified";
		else
			return skill_table[ *(pSpellIndex->sgsn) ].name;
	}
	else
	{
		log_bug("school_bit_name: Spell index not found(%d)",sn);
		return "null";
	}
}

char *web_money_breakdown( int amount )
{
    static char str[MAX_STRING_LENGTH];
    char tmp[MAX_STRING_LENGTH];
	int i;

    str[0] = '\0';

	for( i = MAX_CURRENCY - 1 ; i >= 0 ; i-- )
	{
		int amt;
		if ( (amt = amount / currency_table[i].silver_value) > 0 )
		{
			sprintf(tmp,"%d%c, ", amt, currency_table[i].name[0] );
			strcat(str,tmp);
			amount -= amt * currency_table[i].silver_value;
		}
	}

    /* Chop off trailing ', ' */
    str[strlen(str)-2] = '\0';
    return str;
}

char *money_breakdown( int amount )
{
    static char str[MAX_STRING_LENGTH];
    char tmp[MAX_STRING_LENGTH];
	int i;

    str[0] = '\0';

	for( i = MAX_CURRENCY - 1 ; i >= 0 ; i-- )
	{
		int amt;
		if ( (amt = amount / currency_table[i].silver_value) > 0 )
		{
			sprintf(tmp,"%d&%c%c&x, ", amt, currency_table[i].color, currency_table[i].name[0] );
			strcat(str,tmp);
			amount -= amt * currency_table[i].silver_value;
		}
	}

    /* Chop off trailing ', ' */
    str[strlen(str)-2] = '\0';
    return str;
}

int convertDamtypeToResistIndex( int damage_type )
{
	int i;

	for( i = 1 ; damage_flag_convert[i].dam_type > 0 ; i++ )
		if ( damage_flag_convert[i].dam_type == damage_type )
			return damage_flag_convert[i].resist;

	return -1;
}

// Return weight of coins in tenth-lbs.
int	get_coin_weight( int coin_type, int coin_amount )
{
	if( coin_type < 0 || coin_type >= MAX_CURRENCY )
	{
		log_bug("get_coin_weight(): invalid coin type %d\n\r",coin_type);
		return 0;
	}

	if( coin_amount < 0 )
	{
		log_bug("get_coin_weight(): invalid coin amount %d\n\r",coin_amount);
		return 0;
	}

    // Multiple amount by 10 to get return value in tenth-lbs
	return (coin_amount*10 / (currency_table[coin_type].num_per_pound == 0 ? 100 : currency_table[coin_type].num_per_pound) );
}

int randomHitLocation( )
{
	int i;

	for( i=0 ; hitloc_table[i].chance > 0 ; i++ )
		if ( number_percent() < hitloc_table[i].hitloc )
			return hitloc_table[i].hitloc;

	return hitloc_table[--i].hitloc;
}

char *instrument_name( int sn )
{
	if ( sn == gsn_vocal ) return "vocals";
	if ( sn == gsn_strings ) return "strings";
	if ( sn == gsn_percussion ) return "percussion";
	if ( sn == gsn_winds ) return "winds";
	return "<unknown>";
}

void building_from_room( Building *bld, Building **list )
{
    if ( bld == (*list) )
    {
       	(*list) = bld->next;
    }
    else
    {
        Building *prev;

        for ( prev = (*list); prev != NULL; prev = prev->next )
        {
            if ( prev->next == bld )
            {
            	prev->next = bld->next;
				bld->next = NULL;		
				break;
            }
        }
   
        if ( prev == NULL )
        {
            log_bug( "building_from_room: building not found.", 0 );
            return;
        }
    }

	free_building(bld);
}


void stackPush( Stack *s, int value )
{
	s->array[ s->index++ ] = value;
}

int stackPop( Stack *s )
{
	return s->array[ --(s->index) ];
}

char *symbolize( const char *string )
{
	static char buf[MAX_STRING_LENGTH];
	int i;

	memset( buf, 0, sizeof(buf) );

	strcpy( buf, "_spell_" );
	i = 7;

	while ( *string != '\0' )
	{
		if ( isspace(*string) )
			buf[i] = '_';
		else
		if ( !isalpha(*string) )
			continue;
		else
			buf[i] = *string;

		++i;
		++string;
	}

	return buf;	
}	

bool sameSeries( SpellIndex *s1, SpellIndex *s2 )
{
    return (s1->series == s2->series && s1->series != 0);
}

void set_next_avail( int subrace )
{
    int avail;

    if ( subrace < 0 )
        return;

    if ( subrace_table[subrace].next_avail == NULL )
        return;

    switch( subrace_table[subrace].rarity )
    {
        case SUBRACE_UNCOMMON:      avail = MINTIME_UNCOMMON;  break;
        case SUBRACE_RARE:          avail = MINTIME_RARE;      break;
        case SUBRACE_VERY_RARE:     avail = MINTIME_VERY_RARE; break;
        case SUBRACE_LEGENDARY:     avail = MINTIME_LEGENDARY; break;
        default: return;
    }

    // Add on a random amount
    avail += ( number_range( 0, avail * dice(1,3) ) );

    // Save last one in case this is creation and they change races later
    *subrace_table[subrace].last_avail = *subrace_table[subrace].next_avail;
    *subrace_table[subrace].next_avail = current_time + avail;
}

void unset_next_avail( int subrace )
{
    if ( subrace < 0 )
        return;

    if ( subrace_table[subrace].next_avail == NULL )
        return;

    *subrace_table[subrace].next_avail = *subrace_table[subrace].last_avail;
}

