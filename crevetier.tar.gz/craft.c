/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#include <sys/types.h>
#include <sys/time.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "thoc.h"
#include "olc.h"
#include "interp.h"
#include "tables.h"
#include "journal.h"
#include "options.h"

#define TRIVIAL_CRAFT    85
int calcCraftingChance( Character *ch,  int difficulty, int skill );

/*
 * Check for natural improvement of a skill through practice.
 */
void checkImproveTradeSkill( Character *ch, int skill, double chance, bool fSuccess )
{
    int percent; /* scale 1-1000 */
    bool fDebug = IS_SET(ch->display,DISP_TRADESKILL_DEBUG);
    int    tmp;
    int sk = get_skill(ch,skill);
    int bonus = getAbilitySeries(ch,"craftsmanship");

    if ( calcTotalTradePoints(ch) >= CRAFTING_CAP && ch->pcdata->learned[skill] >= 100 &&
         skill_table[skill].type != SKILL_FOUNDATION &&
         !IS_SET(skill_table[skill].flags,SKILL_SECONDARY) )
    {
        if (fDebug)
            cprintf(ch,"[**] Debug: You have %d trade points, max is %d.",
                calcTotalTradePoints(ch), CRAFTING_CAP );
        return;
    }

    if ( chance < 0 )
        return;

    /* Check for trivial */
    if ( chance >= TRIVIAL_CRAFT + (bonus*3))
    {
        if ( skill_table[skill].type != SKILL_FOUNDATION )
            cprintf(ch," ** This item is trivial for you to create. **\n\r");
        return;
    }

    percent = (int) (log(100+(ch->level*2)) * 100) / 4 - 50;
    percent += (bonus*6);

    if ( !fSuccess )
        percent /= 2;

    /* Speed up lowbie improvement */
    if ( sk < 10 )
        percent *= 2;

    if ( sk < 25 )
        percent *= 2;

    if ( sk < 40 )
        percent *= 2;

    if ( fDebug )
        cprintf(ch,"[**] Debug: %d in 1000 chance of improvement\n\r", percent );

    /* Slow down advancement slightly */
    if ( skill > 100 && number_percent() < 10 )
        return;

    if ( skill > 150 && number_percent() < 20 )
        return;

    if ( skill > 200 && number_percent() < 30 )
        return;

    if ( skill > 225 && number_percent() < 40 )
        return;

    if ( skill > 250 && number_percent() < 50 )
        return;


//    if ( !IS_NPC(ch) && (ch->pcdata->subrace == gsn_brombachol || ch->pcdata->subrace == gsn_gnome) )
//        percent = 150 * percent / 100;
    
    if ( (tmp=number_range( 1, 1000 )) < percent )
    {    
        /* improvement */
        ch->pcdata->learned[skill]++;
        if ( !fSuccess )
            ch->pcdata->learned[skill] += number_range(1,3);

        actprintf(ch,NULL,NULL,TO_CHAR," &G** Your %s skill has improved! (%d) **&x",
            skill_table[skill].name, ch->pcdata->learned[skill] );
    }
    
    return;
}

/* Returns 0 if the object contains nothing that could be a recipe
 * and the recipe's index if it can.
 *
 * Craft contains have the following layout:
 * v0:  modifier to success chance
 * v1:  # uses
 * v2: type of recipe that can be made with this item
 */

Recipe * check_recipe( Object *obj )
{
    int rec;
    Recipe *pRec;
    extern bool check_contents_for_recipe( Object *obj, Recipe * rec );

    for ( rec = 0 ; rec < 100000 ;  rec++ )
    {
        if ( (pRec = get_recipe_index(rec)) == NULL )
            continue;

        if ( pRec->trade_skill >= 1 && pRec->trade_skill != obj->value[2] )
                   continue;
       

        // If there's no trade skill assigned to this recipe, it can only be done in
        // forges that have the right tradeskills set.    
        if ( pRec->trade_skill <= 0 ) // make sure this forge can handle the foundation skills
        {
            if (IS_SET(pRec->trade_skill,TS_WOODWORKING) && !IS_SET(obj->value[4],TS_WOODWORKING))
                continue;

            if (IS_SET(pRec->trade_skill,TS_METALWORKING) && !IS_SET(obj->value[4],TS_METALWORKING))
                continue;
         
            if (IS_SET(pRec->trade_skill,TS_LEATHERWORKING) && !IS_SET(obj->value[4],TS_LEATHERWORKING))
                continue;

            if (IS_SET(pRec->trade_skill,TS_STONEWORKING) && !IS_SET(obj->value[4],TS_STONEWORKING))
                continue;

            if (IS_SET(pRec->trade_skill,TS_CLOTHWORKING) && !IS_SET(obj->value[4],TS_CLOTHWORKING))
                continue;
        }

        /* check contents against recipe */
        if ( check_contents_for_recipe( obj, pRec ) )
            return (pRec);
    }
    return NULL;
}

bool check_contents_for_recipe( Object *obj, Recipe *rec )
{
    bool checkList[MAX_INGREDIENT];
    int i;
    Object *pObj;

    /* initialize data */
    for ( i=0 ; i<MAX_INGREDIENT ; i++ )
    {
        checkList[i] = 0;
        if ( rec->components[i] <= 0 )
            checkList[i] = TRUE;
    }
                    
    for ( pObj = obj->contains ; pObj != NULL ; pObj = pObj->next_content )    
    {
        bool found;

        found = FALSE;
        for ( i =0 ; i < MAX_INGREDIENT ; i++ )
        {
            if ( rec->components[i] == pObj->pIndexData->vnum &&
                 checkList[i] == FALSE )
            {
                checkList[i] = found = TRUE;
                break;
            }
        }

        if ( !found ) /* Extra items in the forge! */
            return FALSE;
    }                    
    
    for ( i=0 ; i<MAX_INGREDIENT ; i++ )
        if ( !checkList[i] )
            return FALSE;
            
    return TRUE;            
}


void clean_forge( Object *forge )
{
    Object *pObj, *pObj_next;

    for ( pObj = forge->contains ; pObj != NULL ; pObj = pObj_next )
    {
        pObj_next = pObj->next_content;
        /*log_bug("Clean_forge: extract_obj",0);*/
        extract_obj(pObj);
    }
    forge->contains = NULL;
}

void do_craft( Character *ch, char *argument )
{
    Object *obj;
    Character *vch;
    char arg[MAX_INPUT_LENGTH];
    bool fRoom=FALSE;
    int skill, wait;
    Recipe *rec;
    int sn, chance;
    ObjIndex    *o;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
        cprintf(ch,"Syntax:   craft <forge>\n\r");
        return;
    }

    /* 1. Acquire target forge */
    /* Try inventory first, then room. */
    if ( (obj = get_obj_carry(ch,arg,ch) ) == NULL )
    {
        if ( (obj = get_obj_here( ch, arg ) ) == NULL ||
              obj->item_type != ITEM_FORGE )
        {
            cprintf(ch,"No such forge here.\n\r");
            return;    
        }
        else
            fRoom = TRUE;
    }
    else
    if ( obj->item_type != ITEM_FORGE )
    {
        act("$p is not a forge.", ch, obj, NULL, TO_CHAR );
        return;
    }
    
    /* 2. See if character has lock on item */
    if ( fRoom )
        for ( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
            if ( vch != ch && vch->crafting == obj )
            {
                cprintf(ch,"Somebody else is using that.\n\r");
                return;
            }
        
    /* 3. See if anything in forge is a recipe */
    if ( obj->contains == NULL )
    {
        cprintf(ch,"It's empty.\n\r");
        return;
    }
   
    if ( (rec=check_recipe(obj)) == NULL )
    {
        act("The contents of $p don't combine to form anything.",ch,obj,NULL,TO_CHAR);
        return;
    }
    
    if ( obj->value[1] == 0 ) 
    {
        act("$p cannot be used to craft any more, it has been exhausted.",ch,obj,NULL,TO_CHAR);
        return;
    }
    
    /* Ok, it's a recipe */
    /* See if character has the right skill. */
    if ( rec->trade_skill > 0 && (skill = get_skill(ch,(sn=rec->trade_skill))) < 1 )
    {
        cprintf(ch,"You lack the skill to create such things.\n\r");
        return;
    }

    o = get_obj_index( rec->result_vnum );
    actprintf(ch,obj,NULL,TO_CHAR,"You begin to craft %s using $p.",o->short_descr);
    actprintf(ch,obj,NULL,TO_ROOM,"$n begins to craft something using $p.");

    wait = UMAX(PULSE_PER_SECOND,rec->trivial*PULSE_PER_SECOND);

    // Reduction for superior skill, up to 90% time reduction.
    // Per 1% of success over 100, you receive a 1% reduction in wait time.
    if (rec->trade_skill <= 0 )
    {
        int tmp = 0;
        chance = 1000;

        // Check each foundation skill.
        if ( IS_SET( rec->foundation_skills, TS_CLOTHWORKING ) )
        {
            tmp = calcCraftingChance(ch,rec->difficulty,get_skill(ch,gsn_clothworking));
            chance = UMIN(chance,tmp);
        }
        if ( IS_SET( rec->foundation_skills, TS_LEATHERWORKING ) )
        {
            tmp = calcCraftingChance(ch,rec->difficulty,get_skill(ch,gsn_leatherworking));
            chance = UMIN(chance,tmp);
        }
        if ( IS_SET( rec->foundation_skills, TS_STONEWORKING ) )
        {
            tmp = calcCraftingChance(ch,rec->difficulty,get_skill(ch,gsn_stoneworking));
            chance = UMIN(chance,tmp);
        }
        if ( IS_SET( rec->foundation_skills, TS_WOODWORKING ) )
        {
            tmp = calcCraftingChance(ch,rec->difficulty,get_skill(ch,gsn_woodworking));
            chance = UMIN(chance,tmp);
        }
        if ( IS_SET( rec->foundation_skills, TS_METALWORKING ) )
        {
            tmp = calcCraftingChance(ch,rec->difficulty,get_skill(ch,gsn_metalworking));
            chance = UMIN(chance,tmp);
        }

        if ( chance == 1000 )
            chance = 0;
    }
    else
        chance = calcCraftingChance(ch,rec->difficulty,get_skill(ch,rec->trade_skill));
   
    if ( chance > 100 ) 
    {
        int redux = UMIN(75,(chance-100)/2);
        wait = (100-redux) * wait / 100;
        cprintf(ch,"Your crafting time is reduced by %d%% due to your high skill level.\n\r",redux);
    }

    cprintf(ch," ** Your crafting will take about %d second%s. **\n\r",
        wait / PULSE_PER_SECOND, wait/PULSE_PER_SECOND == 1 ? "" : "s" );

    ch->recipe_crafting = rec;
    ch->crafting = obj;
    SET_BIT(ch->act,PLR_IS_CRAFTING);
    WAIT_STATE(ch,wait);    /* Trivial is now used as wait state */
    return;
}

void finish_crafting( Character *ch )    
{
    Recipe             *rec;
    double             chance = 0;
    ObjIndex     *o;
    Object         *forge, *obj;
    int             skill = 0;
    bool            fSuccess = TRUE;
    bool            fDebug = IS_SET(ch->display,DISP_TRADESKILL_DEBUG);

    forge     = ch->crafting;
    rec       = ch->recipe_crafting;

    if ( rec->trade_skill > 0 )
        skill = get_skill(ch,rec->trade_skill);

    if ( (o = get_obj_index( rec->result_vnum )) == NULL )
    {
        cprintf(ch,"This recipe is a dud.\n\r");
        return;
    }

    // Check foundation skills!  We always check each skill before reporting a failure
    if ( IS_SET( rec->foundation_skills, TS_WOODWORKING ) )
    {
        bool fWoodworking = TRUE;
        chance = calcCraftingChance( ch, rec->difficulty, get_skill(ch,gsn_woodworking) );
        if (fDebug) cprintf(ch,"[**] Wood: %.2f\n\r", chance );
        if ( number_percent() > chance )
        {
            if (fDebug) cprintf(ch,"[**] Woodworking check failed\n\r");
            fSuccess = FALSE;
            fWoodworking = FALSE;
        }

        checkImproveTradeSkill( ch, gsn_woodworking, chance, fWoodworking );
    }

    if ( IS_SET( rec->foundation_skills, TS_METALWORKING ) )
    {
        bool fMetalworking = TRUE;

        if (fDebug) cprintf(ch,"[**] DEBUG: recipe requires metalworking\n\r");
        chance = calcCraftingChance( ch, rec->difficulty, get_skill(ch,gsn_metalworking) );
        if (fDebug) cprintf(ch,"[**] Metal: %.2f\n\r", chance );
        if ( number_percent() > chance )
        {
             if (fDebug) cprintf(ch,"[**] Metalworking check failed\n\r");
            fSuccess = FALSE;
            fMetalworking = FALSE;
        }

        checkImproveTradeSkill( ch, gsn_metalworking, chance, fMetalworking );
    }

    if ( IS_SET( rec->foundation_skills, TS_LEATHERWORKING ) )
    {
        bool fLeatherworking = TRUE;
       
        if (fDebug) cprintf(ch,"[**] DEBUG: recipe requires leatherworking\n\r"); 
        chance = calcCraftingChance( ch, rec->difficulty, get_skill(ch,gsn_leatherworking) );
        if (fDebug) cprintf(ch,"[**] Leather: %.2f\n\r", chance );
        if ( number_percent() > chance )
        {
            if (fDebug) cprintf(ch,"[**] Leatherworking check failed\n\r");
            fSuccess = FALSE;
            fLeatherworking = FALSE; 
        }

        checkImproveTradeSkill( ch, gsn_leatherworking, chance, fLeatherworking );
    }

    if ( IS_SET( rec->foundation_skills, TS_STONEWORKING ) )
    {
        bool fStoneworking = TRUE;
       
        if (fDebug) cprintf(ch,"[**] DEBUG: recipe requires stoneworking\n\r"); 
        chance = calcCraftingChance( ch, rec->difficulty, get_skill(ch,gsn_stoneworking) );
        if (fDebug) cprintf(ch,"[**] Stone: %.2f\n\r", chance );
        if ( number_percent() > chance )
        {
            if (fDebug) cprintf(ch,"[**] Stoneworking check failed\n\r");
            fSuccess = FALSE;
            fStoneworking = FALSE;
        }

        checkImproveTradeSkill( ch, gsn_stoneworking, chance, fStoneworking );
    }

    if ( IS_SET( rec->foundation_skills, TS_CLOTHWORKING ) )
    {
        bool fClothworking = TRUE;
       
        if (fDebug) cprintf(ch,"[**] DEBUG: recipe requires clothworking\n\r"); 
        chance = calcCraftingChance( ch, rec->difficulty, get_skill(ch,gsn_clothworking) );
        if (fDebug) cprintf(ch,"[**] Cloth: %.2f\n\r", chance );
        if ( number_percent() > chance )
        {
            if (fDebug) cprintf(ch,"[**] Clothworking check failed\n\r");
            fSuccess = FALSE;
            fClothworking = FALSE;
        }

        checkImproveTradeSkill( ch, gsn_clothworking, chance, fClothworking );
    }

    if ( !fSuccess )
    {
        cprintf(ch,"You failed to craft anything, but salvaged your raw materials.\n\r");
        return;
    }

    // check for a specialized skill
    if ( rec->trade_skill > 1 )
    {
        chance = calcCraftingChance( ch, rec->difficulty, skill );
        if(fDebug) cprintf(ch,"[**] Specialized skill chance: %.2f\n\r", chance );
        fSuccess = ( number_percent() < URANGE(2,chance,98) );
    }

    if( fSuccess )
    {
        int bonus=0;
        int i;

        clean_forge(forge);
        obj = create_object(o);
        obj_to_char( obj, ch );        
        act("You have crafted $p!",ch,obj,NULL,TO_CHAR);
        if ( rec->trade_skill > 0 )
            checkImproveTradeSkill( ch, rec->trade_skill, chance, TRUE );
        obj->crafter = str_dup( ch->name );

        /* check journal */
        if ( !knowsRecipe(ch,rec) )    
        {
            recipeToJournal(rec,ch->pcdata->journal);
            cprintf(ch," ** A new recipe has been added to your journal\n\r");
            /* Experience or a new trade skill */
            cprintf(ch,"&YYou have gained %d experience!&x\n\r", rec->difficulty );
            gain_exp( ch, rec->difficulty, TRUE );
        }

        /* Check for quality improvement, for every 15 points of skill, you
         * get a chance for +1% quality. 
         */
        for( i=1 ; i < skill; i += 15 )
        {
            if ( number_percent() < (75+(skill/25)) ) // 75-85% chance
            {
                if ( skill > 250 ) //masterpiece!
                    ++bonus;
                else
                    bonus = UMIN(bonus+1,15);
            }
        }

        if ( bonus > 15 )
            cprintf(ch,"&CYou have created a masterpiece!&x\n\r");
        obj->quality = 85 + bonus;
    }
    else /* Failure */
    {
        cprintf(ch,"You failed to craft anything.\n\r");
        clean_forge(forge);
        if ( rec->fail_vnum > 0 )
        {
            obj = create_object( get_obj_index(rec->fail_vnum) );
            obj_to_char(obj,ch);
        }  
        checkImproveTradeSkill( ch, rec->trade_skill, chance, FALSE );
    }

    /* give up the forge */
    ch->crafting = NULL;
    check_encumbrance( ch );
    return;
}

int calcCraftingChance( Character *ch, int difficulty, int skill )
{
    int diff;    
    int chance;

    /* chance of success is equal to difference times log10 of difference
     * plus 50.
     */
    diff = abs( difficulty - skill );

    chance = (int) (diff == 0) ? 0 : abs( diff ) * log10 ( (double) diff );
    if ( difficulty > skill )  
        chance *= -1;
    chance += 50;
   
    return chance + (getAbilitySeries(ch,"craftsmanship")*3);
}

int spellcraftTowardsCap( int value )
{
    int cap = 0;

    if ( value > 250 )
        cap += (value-250)*7/2;

    if( value > 200 )
        cap += UMIN(value-200,50)*5/2;

    if ( value > 100 )
        cap += UMIN(value-100,100)*3/2;

    cap += UMIN(100,value);
    return cap;
}

int pointsTowardsCap( int value, int sn )
{
    int cap = 0;

    if ( sn == gsn_spellcrafting )
        return spellcraftTowardsCap( value );

    if ( value > 250 )
        cap += (value-250)*4;

    if( value > 200 )
        cap += UMIN(value-200,50)*2;

    if ( value > 100 )
        cap += UMIN(value-100,100);

    //cap += UMIN(100,value);
    return cap;
}

int calcTotalTradePoints( Character *ch )
{
    int sn;
    int total=0;

    if ( IS_NPC(ch) )
        return 0;

    for( sn = 0; skill_table[sn].name != NULL ; sn++ )
    {
        if ( skill_table[sn].type != SKILL_TRADE ||
             IS_SET(skill_table[sn].flags,SKILL_SECONDARY) )
            continue;

        if ( ch->pcdata->learned[sn] < 100 )
            continue;

        total += pointsTowardsCap( ch->pcdata->learned[sn], sn );
    }

    return total;
}
