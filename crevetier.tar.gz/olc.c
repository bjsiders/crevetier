/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  File: olc.c                                                            *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 *                                                                         *
 *  This code was freely distributed with the The Isles 1.1 source code,   *
 *  and has been used here for OLC - OLC would not be what it is without   *
 *  all the previous coders who released their source code.                *
 *                                                                         *
 ***************************************************************************/



#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "thoc.h"
#include "recycle.h"
#include "olc.h"



/*
 * Local functions.
 */
Area *get_area_data	( int vnum );


/* Executed from comm.c.  Minimizes compiling when changes are made. */
bool run_olc_editor( Descriptor *d )
{
    if ( d->incomm[0] == '\\' )
    {
	d->incomm[0] = ' ';
	return FALSE;
    }

    switch ( d->editor )
    {
	case ED_SCRIPT:
		sedit( d->character, d->incomm );
		break;
    case ED_AREA:
		aedit( d->character, d->incomm );
		break;
    case ED_ROOM:
		redit( d->character, d->incomm );
		break;
    case ED_OBJECT:
		oedit( d->character, d->incomm );
		break;
    case ED_MOBILE:
		medit( d->character, d->incomm );
		break;
/*
    case ED_HELP:
        hedit( d->character, d->incomm );
        break;
*/
	case ED_TRADESKILL:
		tedit( d->character, d->incomm );
		break;
	case ED_QUEST:
		qedit( d->character, d->incomm );
		break;
    case ED_SPELL:
        ledit( d->character, d->incomm );
        break;
    default:
	    return FALSE;
    }

    return TRUE;
}



char *olc_ed_name( Character *ch )
{
    static char buf[20];
    
    buf[0] = '\0';
    switch (ch->desc->editor)
    {
	case ED_SCRIPT:
		sprintf(buf," ScriptEdit" );
		break;
	case ED_QUEST:
		sprintf(buf," QuestEdit" );
		break;
    case ED_AREA:
		sprintf( buf, "AreaEdit" );
		break;
    case ED_ROOM:
		sprintf( buf, "RoomEdit" );
		break;
    case ED_OBJECT:
		sprintf( buf, "ObjectEdit" );
		break;
    case ED_MOBILE:
		sprintf( buf, "MobEdit" );
		break;
    case ED_HELP:
        sprintf( buf, "HelpEdit" );
        break;
	case ED_TRADESKILL:
		sprintf( buf, "RecipeEdit" );
		break;
    case ED_SPELL:
        sprintf( buf, "SpellEdit" );
        break;
    default:
	sprintf( buf, " " );
	break;
    }
    return buf;
}



char *olc_ed_vnum( Character *ch )
{
    Area *pArea;
    Room *pRoom;
    ObjIndex *pObj;
    MobIndex *pMob;
	Recipe *pRec;
	Quest *pQuest;
	ScriptIndex *pScriptIndex;
    SpellIndex *pSpl;
    static char buf[10];
	
    buf[0] = '\0';
    switch ( ch->desc->editor )
    {
	case ED_SCRIPT:
		pScriptIndex = (ScriptIndex *) ch->desc->pEdit;
		sprintf( buf, "%d", pScriptIndex ? pScriptIndex->vnum : 0 );
		break;
	case ED_QUEST:
		pQuest = (Quest *) ch->desc->pEdit;
		sprintf( buf, "%d", pQuest ? pQuest->vnum : 0 );
		break;
    case ED_AREA:
		pArea = (Area *)ch->desc->pEdit;
		sprintf( buf, "%d", pArea ? pArea->vnum : 0 );
		break;
    case ED_ROOM:
		pRoom = ch->in_room;
		sprintf( buf, "%d", pRoom ? pRoom->vnum : 0 );
		break;
    case ED_OBJECT:
		pObj = (ObjIndex *)ch->desc->pEdit;
		sprintf( buf, "%d", pObj ? pObj->vnum : 0 );
		break;
    case ED_MOBILE:
		pMob = (MobIndex *)ch->desc->pEdit;
		sprintf( buf, "%d", pMob ? pMob->vnum : 0 );
		break;
	case ED_TRADESKILL:
		pRec = (Recipe *)ch->desc->pEdit;
		sprintf( buf, "%d", pRec ? pRec->vnum : 0 );
        break;
    case ED_SPELL:
        pSpl = (SpellIndex *)ch->desc->pEdit;
        sprintf( buf, "%d", pSpl ? pSpl->vnum : 0 );
        break;
    default:
	sprintf( buf, " " );
	break;
    }

    return buf;
}



/*****************************************************************************
 Name:		show_olc_cmds
 Purpose:	Format up the commands from given table.
 Called by:	show_commands(olc_act.c).
 ****************************************************************************/
void show_olc_cmds( Character *ch, const struct olc_cmd_type *olc_table )
{
    char buf  [ MAX_STRING_LENGTH ];
    char buf1 [ MAX_STRING_LENGTH ];
    int  cmd;
    int  col;
 
    buf1[0] = '\0';
    col = 0;
    for (cmd = 0; olc_table[cmd].name[0] != '\0' ; cmd++)
    {
		sprintf( buf, "%-15.15s", olc_table[cmd].name );
		strcat( buf1, buf );
		if ( ++col % 5 == 0 )
	    	strcat( buf1, "\n\r" );
    }
 
    if ( col % 5 != 0 )
		strcat( buf1, "\n\r" );

    send_to_char( buf1, ch );
    return;
}



/*****************************************************************************
 Name:		show_commands
 Purpose:	Display all olc commands.
 Called by:	olc interpreters.
 ****************************************************************************/
bool show_commands( Character *ch, char *argument )
{
    switch (ch->desc->editor)
    {
	case ED_SCRIPT:
		show_olc_cmds( ch, sedit_table );
		break;
	case ED_QUEST:
		show_olc_cmds( ch, qedit_table );
		break;
	case ED_AREA:
	    show_olc_cmds( ch, aedit_table );
	    break;
	case ED_ROOM:
	    show_olc_cmds( ch, redit_table );
	    break;
	case ED_OBJECT:
	    show_olc_cmds( ch, oedit_table );
	    break;
	case ED_MOBILE:
	    show_olc_cmds( ch, medit_table );
	    break;
    /*case ED_HELP:
        show_olc_cmds( ch, hedit_table );*/
	case ED_TRADESKILL:
		show_olc_cmds( ch, tedit_table );
        break;
    case ED_SPELL:
        show_olc_cmds( ch, ledit_table );
        break;
    }

    return FALSE;
}

/*****************************************************************************
 *                           Interpreter Tables.                             *
 *****************************************************************************/
const struct olc_cmd_type aedit_table[] =
{
/*  {   command		function	}, */

    {   "age",		aedit_age	},
	{	"echo",		aedit_ed	},
	{	"exp",		aedit_exp	},
	{	"flags",	aedit_flags	},
    {   "builder",	aedit_builder	}, /* s removed -- Hugin */
    {   "commands",	show_commands	},
    {   "create",	aedit_create	},
    {   "filename",	aedit_file	},
	{ 	"generate",	aedit_generate },
	{ 	"levels",	aedit_levels },
    {   "name",		aedit_name	},
    {   "security",	aedit_security	},
    {	"show",		aedit_show	},
    {   "vnum",		aedit_vnum	},
    {   "lvnum",	aedit_lvnum	},
    {   "uvnum",	aedit_uvnum	},
	{	"hideinlist", aedit_hideinlist},
    {   "?",		show_help	},
    {   "version",	show_version	},

    {	"",		0,		}
};

const struct olc_cmd_type sedit_table[] =
{
	{	"commands",	show_commands	},
	{	"create",	sedit_create	},
	{	"directobject",	sedit_direct_object },
	{	"edit",		sedit_edit		},
	{	"name",		sedit_name		},
	{	"priority",	sedit_priority	},
	{	"script",	sedit_edit		},
	{	"trigger",	sedit_trigger	},
	{	"?",		show_help		},
	{	"",			0				},
};

const struct olc_cmd_type tedit_table[] =
{
	{	"commands",	show_commands	},
	{	"create",	tedit_create	},
	{	"name",		tedit_name		},
	{	"skill",	tedit_skill		},
	{	"result",	tedit_result	},
	{	"fail",		tedit_fail		},
	{	"difficulty",	tedit_difficulty	},
	{	"time",		tedit_craft_time		},
	{	"component",	tedit_component		},
	{	"foundation",	tedit_foundation	},
	{	"?",		show_help	},
	{	"",	0,	}
};

const struct olc_cmd_type redit_table[] =
{
/*  {   command		function	}, */

    {   "north",	redit_north	},
    {   "south",	redit_south	},
    {   "east",		redit_east	},
    {   "west",		redit_west	},
    {   "up",		redit_up	},
    {   "down",		redit_down	},

    {   "commands",	show_commands	},
    {   "create",	redit_create	},
    {   "desc",		redit_desc	},
    {   "ed",		redit_ed	},
    {   "format",	redit_format	},
    {   "name",		redit_name	},
    {	"show",		redit_show	},
    {   "flag",		redit_flag	},
    {	"sector",	redit_sector	},
    {	"hp",		redit_hp	},
    {	"mana",		redit_mana	},
    {   "class",	redit_class	},
	{	"delspawn",	redit_delspawn	},
    {   "clan",		redit_clan	},

    /* New reset commands. */
    {	"mreset",	redit_mreset	},
    {	"oreset",	redit_oreset	},
	{	"qreset",	redit_qreset	},
	{	"sreset",	redit_sreset	},
    {	"mlist",	redit_mlist	},
    {	"olist",	redit_olist	},
    {	"mshow",	redit_mshow	},
    {	"oshow",	redit_oshow	},

    {   "?",		show_help	},
    {   "version",	show_version	},

    {	"",		0,		}
};



const struct olc_cmd_type oedit_table[] =
{
/*  {   command		function	}, */

    {   "addaffect",	oedit_addaffect	},
    {   "commands",	show_commands	},
    {   "cost",		oedit_cost	},
    {   "create",	oedit_create	},
	{	"copy",		oedit_copy		},
	{	"deity",		oedit_deity	},
    {   "delaffect",	oedit_delaffect	},
    {   "ed",		oedit_ed	},
    {   "long",		oedit_long	},
    {   "name",		oedit_name	},
    {   "short",	oedit_short	},
    {	"show",		oedit_show	},
    {   "v0",		oedit_value0	},
    {   "v1",		oedit_value1	},
    {   "v2",		oedit_value2	},
    {   "v3",		oedit_value3	},
    {   "v4",		oedit_value4	},  /* ROM */
    {   "v5",		oedit_value5	},
    {   "v6",           oedit_value6    },
    {   "v7",           oedit_value7    },
    {   "v8",           oedit_value8    },
    {   "v9",           oedit_value9    },

    {   "weight",	oedit_weight	},
    /*{   "timer",  	oedit_timer	},*/
    {   "extra",        oedit_extra     },  /* ROM */
    {   "wear",         oedit_wear      },  /* ROM */
    {   "type",         oedit_type      },  /* ROM */
    {   "material",     oedit_material  },  /* ROM */
    {   "level",        oedit_level     },  /* ROM */
    {   "condition",    oedit_condition },  /* ROM */
	{	"durability",	oedit_durability },
	{	"quality",		oedit_quality	},

    {   "?",		show_help	},
    {   "version",	show_version	},

    {	"",		0,		}
};



const struct olc_cmd_type medit_table[] =
{
/*  {   command		function	}, */

	{	"deity",		medit_deity },
    {   "alignment",	medit_align	},
    {   "commands",	show_commands	},
	{	"copy",		medit_copy	},
    {   "create",	medit_create	},
    {   "desc",		medit_desc	},
    {   "level",	medit_level	},
    {   "long",		medit_long	},
    {   "name",		medit_name	},
    {   "shop",		medit_shop	},
    {   "short",	medit_short	},
    {	"show",		medit_show	},
    {   "spec",		medit_spec	},
	{	"attackecho",	medit_attackecho 	},
	{	"deathecho",	medit_deathecho		},
	{	"spawnecho",	medit_spawnecho		},

	{	"resists",	medit_resists },
    {   "class",	medit_class	},  /* ARPENS */
    {   "sex",          medit_sex       },  /* ROM */
    {   "act",          medit_act       },  /* ROM */
    {   "affect",       medit_affect    },  /* ROM */
    {   "ac",           medit_ac        },  /* ROM */
    {   "armor",	medit_ac	},
	{	"spellaffects",	medit_spellaffects },		/* ARPENS */
    {   "form",         medit_form      },  /* ROM */
    {   "part",         medit_part      },  /* ROM */
    {   "imm",          medit_imm       },  /* ROM */
    {   "off",          medit_off       },  /* ROM */
    {   "size",         medit_size      },  /* ROM */
    {   "hitdice",      medit_hitdice   },  /* ROM */
    {   "manadice",     medit_manadice  },  /* ROM */
    {   "damdice",      medit_damdice   },  /* ROM */
    {   "damtype",	medit_damtype	},  /* ARPENS */
    {   "race",         medit_race      },  /* ROM */
    {   "position",     medit_position  },  /* ROM */
    {   "gold",          medit_gold      },  /* ROM */
    {   "hitroll",      medit_hitroll   },  /* ROM */
    {   "regen",	medit_regen	}, /* ARPENS */
	{	"faction",	medit_factions }, /* ARPENS */

    {   "?",		show_help	},
    {   "version",	show_version	},

    {	"",		0,		}
};

/*
const struct olc_cmd_type hedit_table[] =
{

    { "commands", show_commands  },
    { "desc",     hedit_desc     },
    { "keywords", hedit_keywords },
    { "level",    hedit_level    },
    { "make",     hedit_make     },
    { "show",     hedit_show     },
    { "delete",   hedit_delete   },
    {   "?",      show_help      },

    {   "", 0, }
};
*/


const struct olc_cmd_type qedit_table[] =
{
	{"commands", 	show_commands 		},
	{"name",		qedit_name			},
	{"keyword",		qedit_keyword		},
	{"short",		qedit_short_descr	},
	{"long",		qedit_long_descr	},
	{"reward",		qedit_reward		},
	{"coins",		qedit_coins			},
	{"experience",	qedit_experience 	},
	{"require",		qedit_require		},
	{"races",		qedit_race			},
	{"classes",		qedit_class 		},
	{"deity",		qedit_deity			},
	{"minlevel",	qedit_minlevel		},
	{"maxlevel",	qedit_maxlevel		},
	{"greeting",	qedit_greeting		},
	{"farewell",	qedit_farewell		},
	{"flags",		qedit_flags			},
	{"faction",		qedit_faction		},
	{ "", 0 }
};


const struct olc_cmd_type   ledit_table[] =
{
    { "short", ledit_short },
    { "desc", ledit_desc },
    { "range", ledit_range },
    { "create", ledit_create },
    { "name", ledit_name },
    { "sourcefile", ledit_sourcefile },
    { "fullname", ledit_fullname },
    { "mana", ledit_mana },
    { "affects", ledit_affects },
    { "classlevel", ledit_classlevel },
    { "type", ledit_type },
    { "school", ledit_school },
    { "castingtime", ledit_casting_time },
    { "recastingtime", ledit_recasting_time },
    { "damnoun", ledit_damage_noun },
    { "incantation", ledit_incantation },
    { "gesture", ledit_gesture },
    { "wearoffmsg", ledit_wearoff_msg },
    { "objectwearoffmsg", ledit_object_wearoff_msg },
    { "flags", ledit_flags },
    { "spelltype", ledit_spelltype },
    { "damtype", ledit_damtype },
    { "damage", ledit_damage },
    { "savingthrow", ledit_savingthrow },
    { "okroomecho", ledit_okroomecho },
    { "okvictimecho", ledit_okvictimecho },
    { "failroomecho", ledit_failroomecho },
    { "failvictimecho", ledit_failvictimecho },
    { "function", ledit_function },

    { "", 0 }
};


/*****************************************************************************
 *                          End Interpreter Tables.                          *
 *****************************************************************************/



/*****************************************************************************
 Name:		get_area_data
 Purpose:	Returns pointer to area with given vnum.
 Called by:	do_aedit(olc.c).
 ****************************************************************************/
Area *get_area_data( int vnum )
{
    Area *pArea;

    for (pArea = area_first; pArea; pArea = pArea->next )
    {
        if (pArea->vnum == vnum)
            return pArea;
    }

    return 0;
}



/*****************************************************************************
 Name:		edit_done
 Purpose:	Resets builder information on completion.
 Called by:	aedit, redit, oedit, medit(olc.c)
 ****************************************************************************/
bool edit_done( Character *ch )
{
    ch->desc->pEdit = NULL;
    ch->desc->editor = 0;
    cprintf(ch,"[OLC] You are now leaving OLC.  Did you remember to save?\n\r");
    return FALSE;
}



/*****************************************************************************
 *                              Interpreters.                                *
 *****************************************************************************/


/* Area Interpreter, called by do_aedit. */
void aedit( Character *ch, char *argument )
{
    Area *pArea;
    char command[MAX_INPUT_LENGTH];
    char arg[MAX_INPUT_LENGTH];
    int  cmd;

    EDIT_AREA(ch, pArea);
    smash_tilde( argument );
    strcpy( arg, argument );
    argument = one_argument( argument, command );

    if ( !IS_BUILDER( ch, pArea ) )
	send_to_char( "AEdit:  Insufficient security to modify area.\n\r", ch );

    if ( command[0] == '\0' )
    {
	aedit_show( ch, argument );
	return;
    }

    if ( !str_cmp(command, "done") )
    {
	edit_done( ch );
	return;
    }

    if ( !IS_BUILDER( ch, pArea ) )
    {
	interpret( ch, arg );
	return;
    }


    /* Search Table and Dispatch Command. */
    for ( cmd = 0; aedit_table[cmd].name[0] != '\0'; cmd++ )
    {
	if ( !str_prefix( command, aedit_table[cmd].name ) )
	{
	    if ( (*aedit_table[cmd].olc_fun) ( ch, argument ) )
	    {
		SET_BIT( pArea->area_flags, AREA_CHANGED );
		return;
	    }
	    else
		return;
	}
    }


    /* Default to Standard Interpreter. */
    interpret( ch, arg );
    return;
}

/* Room Interpreter, called by do_redit. */
void redit( Character *ch, char *argument )
{
    Room *pRoom;
    Area *pArea;
    char arg[MAX_STRING_LENGTH];
    char command[MAX_INPUT_LENGTH];
    int  cmd;

    EDIT_ROOM(ch, pRoom);
    pArea = pRoom->area;

    smash_tilde( argument );
    strcpy( arg, argument );
    argument = one_argument( argument, command );

    if ( !IS_BUILDER( ch, pArea ) )
        send_to_char( "REdit:  Insufficient security to modify room.\n\r", ch );

    if ( command[0] == '\0' )
    {
	redit_show( ch, argument );
	return;
    }

    if ( !str_cmp(command, "done") )
    {
	edit_done( ch );
	return;
    }

    if ( !IS_BUILDER( ch, pArea ) )
    {
        interpret( ch, arg );
        return;
    }


    /* Search Table and Dispatch Command. */
    for ( cmd = 0; redit_table[cmd].name[0] != '\0'; cmd++ )
    {
	if ( !str_prefix( command, redit_table[cmd].name ) )
	{
	    if ( (*redit_table[cmd].olc_fun) ( ch, argument ) )
	    {
		SET_BIT( pArea->area_flags, AREA_CHANGED );
		return;
	    }
	    else
		return;
	}
    }

    /* Default to Standard Interpreter. */
    interpret( ch, arg );
    return;
}



/* Object Interpreter, called by do_oedit. */
void oedit( Character *ch, char *argument )
{
    Area *pArea;
    ObjIndex *pObj;
    char arg[MAX_STRING_LENGTH];
    char command[MAX_INPUT_LENGTH];
    int  cmd;
/*  int  value;   ROM */

    smash_tilde( argument );
    strcpy( arg, argument );
    argument = one_argument( argument, command );

    EDIT_OBJ(ch, pObj);
    pArea = pObj->area;

    if ( !IS_BUILDER( ch, pArea ) )
	send_to_char( "OEdit: Insufficient security to modify area.\n\r", ch );

    if ( command[0] == '\0' )
    {
	oedit_show( ch, argument );
	return;
    }

    if ( !str_cmp(command, "done") )
    {
	edit_done( ch );
	return;
    }

    if ( !IS_BUILDER( ch, pArea ) )
    {
	interpret( ch, arg );
	return;
    }

    /* Search Table and Dispatch Command. */
    for ( cmd = 0; oedit_table[cmd].name[0] != '\0'; cmd++ )
    {
	if ( !str_prefix( command, oedit_table[cmd].name ) )
	{
	    if ( (*oedit_table[cmd].olc_fun) ( ch, argument ) )
	    {
		SET_BIT( pArea->area_flags, AREA_CHANGED );
		return;
	    }
	    else
		return;
	}
    }

    /* Default to Standard Interpreter. */
    interpret( ch, arg );
    return;
}

/*
void do_hedit( Character *ch, char *argument )
{
    Help *pHelp;
    char arg1[MIL];
    char argall[MAX_INPUT_LENGTH],argone[MAX_INPUT_LENGTH];
    bool found = FALSE;

    strcpy(arg1,argument);

    if(argument[0] != '\0')
    {
        argall[0] = '\0';
        while (argument[0] != '\0' )
        {
            argument = one_argument(argument,argone);
            if (argall[0] != '\0')
                strcat(argall," ");
            strcat(argall,argone);
        }

        for ( pHelp = help_first; pHelp != NULL; pHelp = pHelp->next )
        {
            if ( is_name( argall, pHelp->keyword ) )
            {
                ch->desc->pEdit=(void *)pHelp;
                ch->desc->editor= ED_HELP;
                found = TRUE;
                return;
            }
        }
    }

    if(!found)
    {
        argument = one_argument(arg1, arg1);

        if(!str_cmp(arg1,"make"))
        {
            if (argument[0] == '\0')
            {
                send_to_char("Syntax: edit help new [topic]\n\r",ch);
                return;
            }
            if (hedit_make(ch, argument) )
                ch->desc->editor = ED_HELP;
            return;
        }
    }

    send_to_char( "HEdit:  There is no default help to edit.\n\r", ch );
    return;
}
*/


/* Mobile Interpreter, called by do_medit. */
void medit( Character *ch, char *argument )
{
    Area *pArea;
    MobIndex *pMob;
    char command[MAX_INPUT_LENGTH];
    char arg[MAX_STRING_LENGTH];
    int  cmd;
/*  int  value;    ROM */

    smash_tilde( argument );
    strcpy( arg, argument );
    argument = one_argument( argument, command );

    EDIT_MOB(ch, pMob);
    pArea = pMob->area;

    if ( !IS_BUILDER( ch, pArea ) )
	send_to_char( "MEdit: Insufficient security to modify area.\n\r", ch );

    if ( command[0] == '\0' )
    {
        medit_show( ch, argument );
        return;
    }

    if ( !str_cmp(command, "done") )
    {
	edit_done( ch );
	return;
    }

    if ( !IS_BUILDER( ch, pArea ) )
    {
	interpret( ch, arg );
	return;
    }

    /* Search Table and Dispatch Command. */
    for ( cmd = 0; medit_table[cmd].name[0] != '\0'; cmd++ )
    {
	if ( !str_prefix( command, medit_table[cmd].name ) )
	{
	    if ( (*medit_table[cmd].olc_fun) ( ch, argument ) )
	    {
		SET_BIT( pArea->area_flags, AREA_CHANGED );
		return;
	    }
	    else
		return;
	}
    }

    /* Default to Standard Interpreter. */
    interpret( ch, arg );
    return;
}




const struct editor_cmd_type editor_table[] =
{
/*  {   command		function	}, */

    {   "area",		do_aedit	},
    {   "room",		do_redit	},
    {   "object",	do_oedit	},
    {   "mobile",	do_medit	},
    /*{   "help",     do_hedit        },*/
	{	"recipe",	do_tedit	},
	{	"quest",	do_qedit	},
	{ 	"script",	do_sedit	},
    {   "spell",    do_ledit    },
    {	"",		0,		}
};


/* Entry point for all editors. */
void do_olc( Character *ch, char *argument )
{
    char command[MAX_INPUT_LENGTH];
    int  cmd;

    argument = one_argument( argument, command );

    if ( command[0] == '\0' )
    {
        do_help( ch, "olc" );
        return;
    }
 
    /* Search Table and Dispatch Command. */
    for ( cmd = 0; editor_table[cmd].name[0] != '\0'; cmd++ )
    {
	if ( !str_prefix( command, editor_table[cmd].name ) )
	{
	    (*editor_table[cmd].do_fun) ( ch, argument );
	    return;
	}
    }

    /* Invalid command, send help. */
    do_help( ch, "olc" );
    return;
}



/* Entry point for editing area_data. */
void do_aedit( Character *ch, char *argument )
{
    Area *pArea;
    int value;

    pArea = ch->in_room->area;

    if ( is_number( argument ) )
    {
	value = atoi( argument );
	if ( !( pArea = get_area_data( value ) ) )
	{
	    send_to_char( "That area vnum does not exist.\n\r", ch );
	    return;
	}
    }
    else
    {
	if ( !str_cmp( argument, "create" ) )
	{
	    pArea               =   new_area();
	    area_last->next     =   pArea;
	    area_last		=   pArea;	/* Thanks, Walker. */
	    SET_BIT( pArea->area_flags, AREA_ADDED );
	}
    }


    cprintf(ch,"[OLC] You've entered the AREA editor.\n\r");

    ch->desc->pEdit = (void *)pArea;
    ch->desc->editor = ED_AREA;
    return;
}



/* Entry point for editing room_index_data. */
void do_redit( Character *ch, char *argument )
{
    Room *pRoom;
    char arg1[MAX_STRING_LENGTH];

    argument = one_argument( argument, arg1 );

    pRoom = ch->in_room;

    if ( !str_cmp( arg1, "create" ) )
    {
	if ( argument[0] == '\0' || atoi( argument ) == 0 )
	{
	    send_to_char( "Syntax:  edit room create [vnum]\n\r", ch );
	    return;
	}

	if ( redit_create( ch, argument ) )
	{
	    char_from_room( ch );
	    char_to_room( ch, ch->desc->pEdit );
	    SET_BIT( pRoom->area->area_flags, AREA_CHANGED );
	}
    }
    else
	cprintf(ch,"[OLC] You've entered the ROOM editor.\n\r");

    ch->desc->editor = ED_ROOM;
    return;
}

void do_sedit( Character *ch, char *argument )
{
    ScriptIndex *pScriptIndex;
    Area *pArea;
    char arg1[MAX_STRING_LENGTH];
    int value;

    if ( IS_NPC(ch) )
		return;

    argument = one_argument( argument, arg1 );

    if ( is_number( arg1 ) )
    {
		value = atoi( arg1 );
		if ( !( pScriptIndex = get_script_index( value ) ) )
		{
	    	send_to_char( "SEdit:  That script vnum does not exist.\n\r", ch );
	    	return;
		}

        cprintf(ch,"[OLC] You've entered the SCRIPT editor.\n\r");
		ch->desc->pEdit = (void *)pScriptIndex;
		ch->desc->editor = ED_SCRIPT;
		return;
    }
    else
    {
		if ( !str_cmp( arg1, "create" ) )
		{
	    	value = atoi( argument );
	    	if ( argument[0] == '\0' || value == 0 )
	    	{
				send_to_char( "Syntax:  edit script create [vnum]\n\r", ch );
				return;
	    	}

	    	pArea = get_vnum_area( value );

	    	if ( sedit_create( ch, argument ) )
	    	{
				SET_BIT( pArea->area_flags, AREA_CHANGED );
				ch->desc->editor = ED_SCRIPT;
	    	}
            cprintf(ch,"[OLC] You've entered the SCRIPT editor.\n\r");
	    	return;
		}
    }

    send_to_char( "SEdit:  There is no default quest to edit.\n\r", ch );
    return;
}

void sedit( Character *ch, char *argument )
{
    Area *pArea;
    ScriptIndex *pScriptIndex;
    char arg[MAX_STRING_LENGTH];
    char command[MAX_INPUT_LENGTH];
    int  cmd;
/*  int  value;   ROM */

    smash_tilde( argument );
    strcpy( arg, argument );
    argument = one_argument( argument, command );

    EDIT_SCRIPT(ch, pScriptIndex);
    pArea = pScriptIndex->area;

    if ( !IS_BUILDER( ch, pArea ) )
		send_to_char( "SEdit: Insufficient security to modify area.\n\r", ch );

    if ( command[0] == '\0' )
    {
		sedit_show( ch, argument );
		return;
    }

    if ( !str_cmp(command, "done") )
    {
		edit_done( ch );
		return;
    }

    if ( !IS_BUILDER( ch, pArea ) )
    {
		interpret( ch, arg );
		return;
    }

    /* Search Table and Dispatch Command. */
    for ( cmd = 0; sedit_table[cmd].name[0] != '\0'; cmd++ )
    {
		if ( !str_prefix( command, sedit_table[cmd].name ) )
		{
	    	if ( (*sedit_table[cmd].olc_fun) ( ch, argument ) )
	    	{
				SET_BIT( pArea->area_flags, AREA_CHANGED );
				return;
	    	}
	    	else
			return;
		}
    }

    /* Default to Standard Interpreter. */
    interpret( ch, arg );
    return;
}

void do_qedit( Character *ch, char *argument )
{
    Quest *pQuest;
    Area *pArea;
    char arg1[MAX_STRING_LENGTH];
    int value;

    if ( IS_NPC(ch) )
		return;

    argument = one_argument( argument, arg1 );

    if ( is_number( arg1 ) )
    {
		value = atoi( arg1 );
		if ( !( pQuest = get_quest_index( value ) ) )
		{
	    	send_to_char( "QEdit:  That quest vnum does not exist.\n\r", ch );
	    	return;
		}

        cprintf(ch,"[OLC] You've entered the QUEST editor.\n\r");
		ch->desc->pEdit = (void *)pQuest;
		ch->desc->editor = ED_QUEST;
		return;
    }
    else
    {
		if ( !str_cmp( arg1, "create" ) )
		{
	    	value = atoi( argument );
	    	if ( argument[0] == '\0' || value == 0 )
	    	{
				send_to_char( "Syntax:  edit quest create [vnum]\n\r", ch );
				return;
	    	}

	    	pArea = get_vnum_area( value );

	    	if ( qedit_create( ch, argument ) )
	    	{
				SET_BIT( pArea->area_flags, AREA_CHANGED );
				ch->desc->editor = ED_QUEST;
	    	}
            cprintf(ch,"[OLC] You've entered the QUEST editor.\n\r");
	    	return;
		}
    }

    send_to_char( "QEdit:  There is no default quest to edit.\n\r", ch );
    return;
}

void qedit( Character *ch, char *argument )
{
    Area *pArea;
    Quest *pQuest;
    char arg[MAX_STRING_LENGTH];
    char command[MAX_INPUT_LENGTH];
    int  cmd;
/*  int  value;   ROM */

    smash_tilde( argument );
    strcpy( arg, argument );
    argument = one_argument( argument, command );

    EDIT_QUEST(ch, pQuest);
    pArea = pQuest->area;

    if ( !IS_BUILDER( ch, pArea ) )
		send_to_char( "QEdit: Insufficient security to modify area.\n\r", ch );

    if ( command[0] == '\0' )
    {
		qedit_show( ch, argument );
		return;
    }

    if ( !str_cmp(command, "done") )
    {
		edit_done( ch );
		return;
    }

    if ( !IS_BUILDER( ch, pArea ) )
    {
		interpret( ch, arg );
		return;
    }

    /* Search Table and Dispatch Command. */
    for ( cmd = 0; qedit_table[cmd].name[0] != '\0'; cmd++ )
    {
		if ( !str_prefix( command, qedit_table[cmd].name ) )
		{
	    	if ( (*qedit_table[cmd].olc_fun) ( ch, argument ) )
	    	{
				SET_BIT( pArea->area_flags, AREA_CHANGED );
				return;
	    	}
	    	else
			return;
		}
    }

    /* Default to Standard Interpreter. */
    interpret( ch, arg );
    return;
}

void do_tedit( Character *ch, char *argument )
{
    Recipe *pRec;
    Area *pArea;
    char arg1[MAX_STRING_LENGTH];
    int value;

    if ( IS_NPC(ch) )
		return;

    argument = one_argument( argument, arg1 );

    if ( is_number( arg1 ) )
    {
		value = atoi( arg1 );
		if ( !( pRec = get_recipe_index( value ) ) )
		{
	    	send_to_char( "TSEdit:  That recipe vnum does not exist.\n\r", ch );
	    	return;
		}

        cprintf(ch,"[OLC] You've entered the RECIPE editor.\n\r");
		ch->desc->pEdit = (void *)pRec;
		ch->desc->editor = ED_TRADESKILL;
		return;
    }
    else
    {
		if ( !str_cmp( arg1, "create" ) )
		{
	    	value = atoi( argument );
	    	if ( argument[0] == '\0' || value == 0 )
	    	{
				send_to_char( "Syntax:  edit recipe create [vnum]\n\r", ch );
				return;
	    	}

	    	pArea = get_vnum_area( value );

	    	if ( tedit_create( ch, argument ) )
	    	{
				SET_BIT( pArea->area_flags, AREA_CHANGED );
				ch->desc->editor = ED_TRADESKILL;
	    	}
            cprintf(ch,"[OLC] You've entered the RECIPE editor.\n\r");
	    	return;
		}
    }

    send_to_char( "TSEdit:  There is no default recipe to edit.\n\r", ch );
    return;
}

void tedit( Character *ch, char *argument )
{
    Area *pArea;
    Recipe *pRec;
    char arg[MAX_STRING_LENGTH];
    char command[MAX_INPUT_LENGTH];
    int  cmd;
/*  int  value;   ROM */

    smash_tilde( argument );
    strcpy( arg, argument );
    argument = one_argument( argument, command );

    EDIT_RECIPE(ch, pRec);
    pArea = pRec->area;

    if ( !IS_BUILDER( ch, pArea ) )
		send_to_char( "TSEdit: Insufficient security to modify area.\n\r", ch );

    if ( command[0] == '\0' )
    {
		tedit_show( ch, argument );
		return;
    }

    if ( !str_cmp(command, "done") )
    {
		edit_done( ch );
		return;
    }

    if ( !IS_BUILDER( ch, pArea ) )
    {
		interpret( ch, arg );
		return;
    }

    /* Search Table and Dispatch Command. */
    for ( cmd = 0; tedit_table[cmd].name[0] != '\0' ; cmd++ )
    {
		if ( !str_prefix( command, tedit_table[cmd].name ) )
		{
	    	if ( (*tedit_table[cmd].olc_fun) ( ch, argument ) )
	    	{
				SET_BIT( pArea->area_flags, AREA_CHANGED );
				return;
	    	}
	    	else
			return;
		}
    }

    /* Default to Standard Interpreter. */
    interpret( ch, arg );
    return;
}

void do_ledit( Character *ch, char *argument )
{
    SpellIndex *pSpell;
    char arg1[MAX_STRING_LENGTH];
    int value;

    if ( IS_NPC(ch) )
    {
        cprintf(ch,"You're an NPC!\n\r");
		return;
    }

    argument = one_argument( argument, arg1 );

    if ( is_number( arg1 ) )
    {
		value = atoi( arg1 );
		if ( !( pSpell = get_spell_index( value ) ) )
		{
	    	cprintf(ch,"SpellEdit:  That spell vnum does not exist.\n\r" );
	    	return;
		}

        cprintf(ch,"[OLC] You've entered the SPELL editor.\n\r");
		ch->desc->pEdit = (void *)pSpell;
		ch->desc->editor = ED_SPELL;
		return;
    }
    else
    {
        if ( !str_cmp( arg1, "create" ) )
        {
            value = atoi( argument );
            if ( argument[0] == '\0' || value == 0 )
            {
                cprintf(ch,"Syntax:  edit spell create [vnum]\n\r" );
                return;
            }

            if ( ledit_create( ch, argument ) )
            {
                ch->desc->editor = ED_SPELL;
            }
            cprintf(ch,"[OLC] You've entered the SPELL editor.\n\r");
            return;
        }
    }

    cprintf(ch, "SpellEdit:  There is no default spell to edit.\n\r" );
    return;
}

void ledit( Character *ch, char *argument )
{
    SpellIndex *pSpell;
    char arg[MAX_STRING_LENGTH];
    char command[MAX_INPUT_LENGTH];
    int  cmd;

    if ( ch->pcdata->security < 8 )
    {
        cprintf(ch,"OLC security clearance of 8 or more is requird to edit spells.\n\r");
        return;
    }

    smash_tilde( argument );
    strcpy( arg, argument );
    argument = one_argument( argument, command );

    EDIT_SPELL(ch, pSpell);

    if ( command[0] == '\0' )
    {
		ledit_show( ch, argument );
		return;
    }

    if ( !str_cmp(command, "done") )
    {
		edit_done( ch );
		return;
    }

    /* Search Table and Dispatch Command. */
    for ( cmd = 0; ledit_table[cmd].name[0] != '\0' ; cmd++ )
    {
		if ( !str_prefix( command, ledit_table[cmd].name ) )
		{
	    	(*ledit_table[cmd].olc_fun) ( ch, argument );
			return;
		}
    }

    /* Default to Standard Interpreter. */
    interpret( ch, arg );
    return;
}

/* Entry point for editing obj_index_data. */
void do_oedit( Character *ch, char *argument )
{
    ObjIndex *pObj;
    Area *pArea;
    char arg1[MAX_STRING_LENGTH];
    int value;

    if ( IS_NPC(ch) )
	return;

    argument = one_argument( argument, arg1 );

    if ( is_number( arg1 ) )
    {
	value = atoi( arg1 );
	if ( !( pObj = get_obj_index( value ) ) )
	{
	    send_to_char( "OEdit:  That vnum does not exist.\n\r", ch );
	    return;
	}

        cprintf(ch,"[OLC] You've entered the OBJECT editor.\n\r");
	ch->desc->pEdit = (void *)pObj;
	ch->desc->editor = ED_OBJECT;
	return;
    }
    else
    {
	if ( !str_cmp( arg1, "create" ) )
	{
	    value = atoi( argument );
	    if ( argument[0] == '\0' || value == 0 )
	    {
		send_to_char( "Syntax:  edit object create [vnum]\n\r", ch );
		return;
	    }

	    pArea = get_vnum_area( value );

	    if ( oedit_create( ch, argument ) )
	    {
		SET_BIT( pArea->area_flags, AREA_CHANGED );
		ch->desc->editor = ED_OBJECT;
	    }
            cprintf(ch,"[OLC] You've entered the OBJECT editor.\n\r");
	    return;
	}
    }

    send_to_char( "OEdit:  There is no default object to edit.\n\r", ch );
    return;
}



/* Entry point for editing mob_index_data. */
void do_medit( Character *ch, char *argument )
{
    MobIndex *pMob;
    Area *pArea;
    int value;
    char arg1[MAX_STRING_LENGTH];

    argument = one_argument( argument, arg1 );

    if ( is_number( arg1 ) )
    {
	value = atoi( arg1 );
	if ( !( pMob = get_mob_index( value ) ))
	{
	    send_to_char( "MEdit:  That vnum does not exist.\n\r", ch );
	    return;
	}

	cprintf(ch,"[OLC] You've entered the MOB editor.\n\r");
	ch->desc->pEdit = (void *)pMob;
	ch->desc->editor = ED_MOBILE;
	return;
    }
    else
    {
	if ( !str_cmp( arg1, "create" ) )
	{
	    value = atoi( argument );
	    if ( arg1[0] == '\0' || value == 0 )
	    {
		send_to_char( "Syntax:  edit mobile create [vnum]\n\r", ch );
		return;
	    }

	    pArea = get_vnum_area( value );

	    if ( medit_create( ch, argument ) )
	    {
		SET_BIT( pArea->area_flags, AREA_CHANGED );
		ch->desc->editor = ED_MOBILE;
	    }
	    cprintf(ch,"[OLC] You've entered the MOB editor.\n\r");
	    return;
	}
    }

    send_to_char( "MEdit:  There is no default mobile to edit.\n\r", ch );
    return;
}

/*
void hedit( Character *ch, char *argument)
{
    char command[MIL];
    char arg[MIL];
    int cmd;

    smash_tilde(argument);
    strcpy(arg, argument);
    argument = one_argument( argument, command);

    if (ch->pcdata->security < 9)
    {
        send_to_char("HEdit: Insufficient security to modify code\n\r",ch);
       edit_done(ch);
    }

    if ( !str_cmp(command, "done") )
    {
        edit_done( ch );
        return;
    }

    if ( command[0] == '\0' )
    {
        hedit_show( ch, argument );
        return;
    }

    for ( cmd = 0; hedit_table[cmd].name[0] != '\0'; cmd++ )
    {
        if ( !str_prefix( command, hedit_table[cmd].name ) )
        {
            (*hedit_table[cmd].olc_fun) ( ch, argument );
            return;
        }
    }

    interpret( ch, arg );
    return;
}
*/

void do_reset( Character *ch, char *argument )
{
	extern	void spawnRoom( Room * );

	spawnRoom( ch->in_room );
	cprintf( ch, "Room reset.\n\r" );
	return;
}

/*****************************************************************************
 Name:		do_alist
 Purpose:	Normal command to list areas and display area information.
 Called by:	interpreter(interp.c)
 ****************************************************************************/
void do_alist( Character *ch, char *argument )
{
    Area *pArea;
	Buffer *buf;
    int i;

	buf = new_buf();

   	bprintf( buf , "[%3s] [%-27s] (%-5s-%5s) [%-10s] %3s [%-10s]\n\r",
       "Num", "Area Name", "lvnum", "uvnum", "Filename", "Sec", "Builders" );

    for ( i = 0 ; i < 100000 ; i += 100 )
    {
        for ( pArea = area_first; pArea; pArea = pArea->next )
        {
	    if ( pArea->lvnum < i && !pArea->shown )
	    {
		pArea->shown = TRUE;
	        bprintf( buf, "[%3d] %-29.29s (%-5d-%5d) %-12.12s [%d] [%-10.10s]\n\r",
	            pArea->vnum,
	            pArea->name,
	            pArea->lvnum,
	            pArea->uvnum,
	            pArea->filename,
	            pArea->security,
	            pArea->builders );
	    }
	    else
	    if ( pArea->lvnum >= i )
		pArea->shown = FALSE;
        }
    }

	page_to_char( buf_string(buf), ch );
	free_buf( buf );
    return;
}

void do_walkbuild( Character *ch, char *argument )
{
	if ( IS_NPC(ch) )
	{
		cprintf(ch,"NPCs don't build anything.\n\r");
		return;
	}

	TOGGLE_BIT( ch->pcdata->olc_flags, OLC_BUILD_AS_I_WALK );
	cprintf(ch,"You will %s build rooms by walking.\n\r",
		IS_SET(ch->pcdata->olc_flags, OLC_BUILD_AS_I_WALK) ? "now" : "no longer" );
	return;
}

void stripCRLF( char *string )
{
    char *p1, *p2;

    p1 = string;
    p2 = string;

    while( *p2 != '\0' )
    {
        while ( *p2 == '\n' || *p2 == '\r' )
            ++p2;

        *p1 = *p2;
        ++p1;
        ++p2;
    }

    *p1 = '\0';
    return;
}

