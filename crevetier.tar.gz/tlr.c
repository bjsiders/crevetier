/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#include <sys/time.h>
#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include <stdarg.h>
#include <errno.h>
#include <dirent.h>
#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "recycle.h"
#include "tables.h"
#include "lookup.h"

const char *classDir[MAX_CLASS] = 
{	"Mages",
	"Necromancers",
	"Warlocks",
	"Enchanters",
	"Clerics",
	"Druids",
	"Shamans",
	"Crusaders",
	"Thieves",
	"Bards",
	"Assassins",
	"Monks",
	"Fighters",
	"Barbarians",
	"Paladins",
	"Rangers"
};
	
void do_tlr_list(Character *ch,int class);
void do_tlr_read(Character *ch,int class,int number);

void do_tlr( Character *ch, char *argument )
{
	char arg[MAX_INPUT_LENGTH];
	char arg2[MAX_INPUT_LENGTH];
	int class;

	argument = one_argument( argument, arg );
	argument = one_argument( argument, arg2 );

	if ( arg[0] == '\0' || arg2[0] == '\0' )
	{
		cprintf(ch,"Syntax:  tlr list <class>\n\r"
                   "         tlr read <class> #\n\r");
		return;
	}

	if ( (class = class_lookup( arg2 )) < 0 )
	{
		cprintf(ch,"No such class '%s'.\n\r", arg2 );
		return;
	}

	/* Handle list */
	if ( !str_cmp(arg,"list") )
	{
		do_tlr_list(ch,class);
		return;
	}

	if ( !str_cmp(arg,"read") )
	{
		do_tlr_read(ch,class,atoi(argument));
		return;
	}

	do_tlr(ch,"");
	return;
}

void do_tlr_read(Character *ch,int class,int number)
{
	struct stat			myStat;
	struct dirent		*dirp;
	DIR					*dp;
	char				path[MAX_STRING_LENGTH];
	int					count = 0;
	bool				found = FALSE;

	if ( number < 1 )
	{
		cprintf(ch,"You must give a valid report number.\n\r");
		return;
	}

	snprintf(path,sizeof(path),"%s/tlr/%s", GAME_DIR, classDir[class]);
	if ( lstat(path,&myStat) < 0 )
	{
		cprintf(ch,"Error reading TLR directory: %s\n\r",strerror(errno));
		return;
	}

	if ( S_ISDIR(myStat.st_mode) == 0 )
	{
		cprintf(ch,"Error: TLR directory is not a directory.\n\r");
		return;
	}

	if ( (dp = opendir(path)) == NULL )
	{
		cprintf(ch,"Could not open TLR directory: %s\n\r",strerror(errno));
		return;
	}

	while( (dirp = readdir(dp)) != NULL )
	{
		if ( strcmp(dirp->d_name,".") == 0 || strcmp(dirp->d_name,"..") == 0 )
			continue;

		if ( ++count == number )
		{
			char tlr_path[MAX_STRING_LENGTH];
			char buf[MAX_STRING_LENGTH];
			FILE *fp;

			snprintf(tlr_path,sizeof(tlr_path),"%s/%s", path, dirp->d_name);
			if ( ( fp = fopen(tlr_path,"r") ) == NULL )
			{
				cprintf(ch,"Error reading report: %s\n\r",strerror(errno));
				break;
			}
	
			while( fgets(buf,MAX_STRING_LENGTH,fp) )
			{
				cprintf(ch,buf);
				cprintf(ch,"\r");
			}

			fclose( fp );
			found = TRUE;
			break;
		}
	}

	if ( closedir(dp) < 0 )
		perror( path );

	if ( !found )
		cprintf(ch,"There is no report #%d for this class.\n\r",number);

	return;
}


void do_tlr_list(Character *ch,int class)
{
	struct stat			myStat;
	struct dirent		*dirp;
	DIR					*dp;
	char				path[MAX_STRING_LENGTH];
	int					count = 0;

	snprintf(path,sizeof(path),"%s/tlr/%s", GAME_DIR, classDir[class]);

	if ( lstat(path,&myStat) < 0 )
	{
		cprintf(ch,"Error reading TLR directory: %s\n\r",strerror(errno));
		return;
	}

	if ( S_ISDIR(myStat.st_mode) == 0 )
	{
		cprintf(ch,"Error: TLR directory is not a directory.\n\r");
		return;
	}

	if ( (dp = opendir(path)) == NULL )
	{
		cprintf(ch,"Could not open TLR directory: %s\n\r",strerror(errno));
		return;
	}

	cprintf(ch,"TLR#   Report File\n\r");
	while( (dirp = readdir(dp)) != NULL )
	{
		if ( strcmp(dirp->d_name,".") == 0 || strcmp(dirp->d_name,"..") == 0 )
			continue;

		/* Print this report out */
		cprintf(ch,"[%2d]   %-18s\n\r", ++count, dirp->d_name);
	}

	if ( closedir(dp) < 0 )
		perror( path );

	if ( count < 1 )
		cprintf(ch," * No reports filed for this class.\n\r");

	return;
}
