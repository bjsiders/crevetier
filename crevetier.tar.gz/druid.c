/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/** System Include Files **/
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/** Custom Header Files **/
#include "thoc.h"
#include "interp.h"
#include "magic.h"
#include "tables.h"
#include "recycle.h"


/** Druid library */

void druid_skin(int sn,int level,Character *ch,Character *victim,char *word,
				int ac, int hp, int dur)
{
	Affect af;

	af.where	= TO_AFFECTS;
	af.type		= sn;
	af.level	= level;
	af.duration	= minutes(dur);
	af.location	= APPLY_HIT;
	af.modifier = hp;
	af.bitvector = 0;
	af.flags	= 0;
	spellAffectToChar( victim, &af );
	af.location	= APPLY_AC;
	af.modifier = ac;
	spellAffectToChar( victim, &af );

	actprintf(victim,NULL,NULL,TO_CHAR,"Your skin becomes as hard as %s.",word);
	actprintf(victim,NULL,NULL,TO_ROOM,"$n's skin becomes as hard as %s.",word);
	return;
}

bool spell_cedarwood_skin(int sn,int level,Character *ch,void *vo,int target )
{
	Character *victim = (Character *) vo;
	SpellIndex* pSpellIndex;
	int skill, hp;

	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		skill = get_skill(ch,*(pSpellIndex->sgsn));
	}
	else
	{
		log_bug("spell_cedarwood_skin: Spell index not found(%d)",sn);
		return TRUE;
	}

	hp = 20 + UMIN(19,(skill-pSpellIndex->class_level[ch->class])*2);

	druid_skin(sn,level,ch,victim,"cedarwood",20,hp,60);
	return TRUE;
}

bool spell_aspenwood_skin(int sn,int level,Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
	SpellIndex* pSpellIndex;
	int skill, hp;

	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		skill = get_skill(ch,*(pSpellIndex->sgsn));
	}
	else
	{
		log_bug("spell_aspenwood_skin: Spell index not found(%d)",sn);
		return TRUE;
	}

    hp = 40 + UMIN(19,(skill-pSpellIndex->class_level[ch->class])*2);

    druid_skin(sn,level,ch,victim,"aspenwood",45,hp,66);
    return TRUE;
}

bool spell_oakwood_skin(int sn,int level,Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
	SpellIndex* pSpellIndex;
	int skill, hp;

	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		skill = get_skill(ch,*(pSpellIndex->sgsn));
	}
	else
	{
		log_bug("spell_oakwood_skin: Spell index not found(%d)",sn);
		return TRUE;
	}

    hp = 60 + UMIN(19,(skill-pSpellIndex->class_level[ch->class])*2);

    druid_skin(sn,level,ch,victim,"oakwood",95,hp,72);
    return TRUE;
}

bool spell_ashwood_skin(int sn,int level,Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
	SpellIndex* pSpellIndex;
	int skill, hp;

	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		skill = get_skill(ch,*(pSpellIndex->sgsn));
	}
	else
	{
		log_bug("spell_ashwood_skin: Spell index not found(%d)",sn);
		return TRUE;
	}

    hp = 80 + UMIN(19,(skill-pSpellIndex->class_level[ch->class])*2);

    druid_skin(sn,level,ch,victim,"ashwood",145,hp,78);
    return TRUE;
}

bool spell_hickorywood_skin(int sn,int level,Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
	SpellIndex* pSpellIndex;
	int skill, hp;

	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		skill = get_skill(ch,*(pSpellIndex->sgsn));
	}
	else
	{
		log_bug("spell_hickorywood_skin: Spell index not found(%d)",sn);
		return TRUE;
	}

    hp = 100 + UMIN(19,(skill-pSpellIndex->class_level[ch->class])*2);

    druid_skin(sn,level,ch,victim,"hickorywood",195,hp,84);
    return TRUE;
}

bool spell_ironwood_skin(int sn,int level,Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;
	SpellIndex* pSpellIndex;
	int skill, hp;

	if( (pSpellIndex = get_spell_index(sn)) != NULL )
	{
		skill = get_skill(ch,*(pSpellIndex->sgsn));
	}
	else
	{
		log_bug("spell_ironwood_skin: Spell index not found(%d)",sn);
		return TRUE;
	}

    hp = 120 + UMIN(19,(skill-pSpellIndex->class_level[ch->class])*2);

    druid_skin(sn,level,ch,victim,"ironwood",245,hp,90);
    return TRUE;
}

bool spell_circle_of_cedarwood(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim;
    int i;
	int n;
	
	if ( (n = spell_lookup("cedarwood skin",0)) < 0 )
		 n = sn;

    for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
    {
        if ( (victim = ch->pgroup->members[i]) != NULL
             && victim->in_room == ch->in_room )
        {
            spell_cedarwood_skin( n, level, ch, (void *) victim, TARGET_CHAR );
        }
    }

    return TRUE;
}

bool spell_circle_of_aspenwood(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim;
    int i;
    int n;

    if ( (n = spell_lookup("cedarwood skin",0)) < 0 )
         n = sn;

    for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
    {
        if ( (victim = ch->pgroup->members[i]) != NULL
             && victim->in_room == ch->in_room )
        {
            spell_aspenwood_skin( n, level, ch, (void *) victim, TARGET_CHAR );
        }
    }

    return TRUE;
}

bool spell_circle_of_oakwood(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim;
    int i;
    int n;

    if ( (n = spell_lookup("cedarwood skin",0)) < 0 )
         n = sn;


    for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
    {
        if ( (victim = ch->pgroup->members[i]) != NULL
             && victim->in_room == ch->in_room )
        {
            spell_oakwood_skin( n, level, ch, (void *) victim, TARGET_CHAR );
        }
    }

    return TRUE;
}

bool spell_circle_of_ashwood(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim;
    int i;
    int n;

    if ( (n = spell_lookup("cedarwood skin",0)) < 0 )
         n = sn;

    for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
    {
        if ( (victim = ch->pgroup->members[i]) != NULL
             && victim->in_room == ch->in_room )
        {
            spell_ashwood_skin( n, level, ch, (void *) victim, TARGET_CHAR );
        }
    }

    return TRUE;
}

bool spell_circle_of_hickorywood(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim;
    int i;
    int n;

    if ( (n = spell_lookup("cedarwood skin",0)) < 0 )
         n = sn;

    for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
    {
        if ( (victim = ch->pgroup->members[i]) != NULL
             && victim->in_room == ch->in_room )
        {
            spell_hickorywood_skin( n, level, ch, (void *) victim, TARGET_CHAR );
        }
    }

    return TRUE;
}

bool spell_circle_of_ironwood(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim;
    int i;
    int n;

    if ( (n = spell_lookup("cedarwood skin",0)) < 0 )
         n = sn;

    for( i = 0 ; i < MAX_PLAYERS_IN_GROUP ; i++ )
    {
        if ( (victim = ch->pgroup->members[i]) != NULL
             && victim->in_room == ch->in_room )
        {
            spell_ironwood_skin( n, level, ch, (void *) victim, TARGET_CHAR );
        }
    }

    return TRUE;
}

void druid_spirit(int sn,int level,Character *ch,Character *victim,char *word,
                int amount, int damage, int dur)
{
    Affect af;

    af.where    = TO_AFFECTS;
    af.type     = sn;
    af.level    = level;
    af.duration = minutes(dur);
    af.location = APPLY_HITROLL;
    af.modifier = amount;
    af.bitvector = 0;
	af.flags = 0;
    spellAffectToChar( victim, &af );
    af.modifier = damage;
    af.location = APPLY_DAMROLL;
    spellAffectToChar( victim, &af );

    actprintf(victim,NULL,NULL,TO_CHAR,"You are filled with a%s %s spirit.",
		LOWER(*word) == 'a' ? "n" : "", word);
    actprintf(victim,NULL,NULL,TO_ROOM,"A%s %s spirit fills $n's soul.",
		LOWER(*word) == 'a' ? "n" : "", word);
    return;
}

bool spell_canine_spirit(int sn,int level,Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;

    druid_spirit(sn,level,ch,victim,"canine",15,3,30);
    return TRUE;
}

bool spell_accipitrine_spirit(int sn,int level,Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;

    druid_spirit(sn,level,ch,victim,"accipitrine",45,9,40);
    return TRUE;
}

bool spell_vulpine_spirit(int sn,int level,Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;

    druid_spirit(sn,level,ch,victim,"vulpine",80,16,50);
    return TRUE;
}

bool spell_falconine_spirit(int sn,int level,Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;

    druid_spirit(sn,level,ch,victim,"falconine",120,24,60);
    return TRUE;
}

bool spell_lupine_spirit(int sn,int level,Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;

    druid_spirit(sn,level,ch,victim,"lupine",165,33,70);
    return TRUE;
}

bool spell_aquiline_spirit(int sn,int level,Character *ch,void *vo,int target )
{
    Character *victim = (Character *) vo;

    druid_spirit(sn,level,ch,victim,"aquiline",215,43,80);
    return TRUE;
}

void druid_so_damage_shield( int sn, int level, Character *ch, Character *victim,
							int dur, int amt, char *word )
{
    Affect af;

    af.where            = DAMAGE_SHIELD;
    af.level            = level;
    af.type             = sn;
    af.duration         = minutes(dur);
    af.location         = amt;
    af.modifier         = amt;
    af.bitvector        = DAM_PIERCE;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

	af.where			= TO_AFFECTS;
	af.location			= APPLY_AC;
	af.modifier			= amt * 10;
	af.bitvector		= 0;
	spellAffectToChar(victim,&af);

    actprintf(victim,NULL,NULL,TO_ROOM,"$n is covered by a coat of %s.",word);
    actprintf(victim,NULL,NULL,TO_CHAR,"You are covered by a coat of %s.",word);
    return;
}

void druid_damage_shield( int sn, int level, Character *ch, Character *victim,
							int dur, int amt, char *word )
{
    Affect af;

    af.where            = DAMAGE_SHIELD;
    af.level            = level;
    af.type             = sn;
    af.duration         = minutes(dur);
    af.location         = amt;
    af.modifier         = amt;
    af.bitvector        = DAM_PIERCE;
    af.flags            = AFF_SPELL;
    spellAffectToChar(victim,&af);

    actprintf(victim,NULL,NULL,TO_ROOM,"$n is covered by a coat of %s.",word);
    actprintf(victim,NULL,NULL,TO_CHAR,"You are covered by a coat of %s.",word);
    return;
}

bool spell_spur_skin( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

	druid_damage_shield(sn,level,ch,victim,4,2,"spurs");
    return TRUE;
}

bool spell_thorn_skin( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_damage_shield(sn,level,ch,victim,6,4,"thorns");
    return TRUE;
}

bool spell_barb_skin( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_damage_shield(sn,level,ch,victim,8,6,"barbs");
    return TRUE;
}

bool spell_bramble_skin( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_damage_shield(sn,level,ch,victim,11,10,"brambles");
    return TRUE;
}

bool spell_needle_skin( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_damage_shield(sn,level,ch,victim,15,15,"needles");
    return TRUE;
}

bool spell_spine_skin( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_damage_shield(sn,level,ch,victim,20,20,"spines");
    return TRUE;
}

bool spell_spike_skin( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_damage_shield(sn,level,ch,victim,25,30,"spike");
    return TRUE;
}



bool spell_coat_of_spurs( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_so_damage_shield(sn,level,ch,victim,15,1,"spurs");
    return TRUE;
}

bool spell_coat_of_thorns( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_so_damage_shield(sn,level,ch,victim,18,2,"thorns");
    return TRUE;
}

bool spell_coat_of_barbs( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_so_damage_shield(sn,level,ch,victim,22,3,"barbs");
    return TRUE;
}

bool spell_coat_of_brambles( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_so_damage_shield(sn,level,ch,victim,26,5,"brambles");
    return TRUE;
}

bool spell_coat_of_needles( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_so_damage_shield(sn,level,ch,victim,30,7,"needles");
    return TRUE;
}

bool spell_coat_of_spines( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_so_damage_shield(sn,level,ch,victim,35,10,"spines");
    return TRUE;
}

bool spell_coat_of_spikes( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_so_damage_shield(sn,level,ch,victim,40,15,"spikes");
    return TRUE;
}

void druid_str_buff(int sn,int level,Character *ch,Character *victim,int amt,int dur,char *word)
{
	Affect af;

	af.where	= TO_AFFECTS;
	af.type		= sn;
	af.level	= level;
	af.duration	= minutes(dur);
	af.modifier	= amt;
	af.location = APPLY_STR;
	af.bitvector = 0;
	af.flags = 0;
	spellAffectToChar(victim,&af);

	actprintf(victim,NULL,NULL,TO_CHAR,"Your muscles are enhanced by the power of %s.",word);
	actprintf(victim,NULL,NULL,TO_ROOM,"$n's muscles are enhanced by the power of %s.",word);
	return;
}

bool spell_strength_of_air( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_str_buff(sn,level,ch,victim,25,60,"air");
    return TRUE;
}

bool spell_strength_of_water( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_str_buff(sn,level,ch,victim,50,70,"water");
    return TRUE;
}

bool spell_strength_of_fire( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_str_buff(sn,level,ch,victim,75,80,"fire");
    return TRUE;
}

bool spell_strength_of_earth( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_str_buff(sn,level,ch,victim,100,90,"earth");
    return TRUE;
}

void druid_stamina_buff(int sn,int level,Character *ch,Character *victim,int dur,int amt,char *word)
{
	Affect af;

	af.where		= TO_AFFECTS;
	af.type			= sn;
	af.level		= level;
	af.duration		= minutes(dur);
	af.location		= APPLY_STAMINA;
	af.modifier		= max_stamina(victim) * amt / 100;
	af.bitvector	= 0;
	af.flags = 0;
	spellAffectToChar(victim,&af);

	actprintf(victim,NULL,NULL,TO_CHAR,"You hear the wild call of the %s in your soul.",word);
	actprintf(victim,NULL,NULL,TO_ROOM,"$n appears to have more stamina.");
	return;
}

bool spell_hounds_call( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_stamina_buff(sn,level,ch,victim,55,15,"hound");
    return TRUE;
}

bool spell_foxs_call( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_stamina_buff(sn,level,ch,victim,60,20,"fox");
    return TRUE;
}

bool spell_coyotes_call( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_stamina_buff(sn,level,ch,victim,65,25,"coyote");
    return TRUE;
}

bool spell_hyenas_call( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_stamina_buff(sn,level,ch,victim,70,30,"wolf");
    return TRUE;
}

bool spell_wolfs_call( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_stamina_buff(sn,level,ch,victim,75,35,"dire wolf");
    return TRUE;
}

void druid_regen(int sn,int level,Character *ch,Character *victim,int dur,int base,int stat,char *word)
{
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(dur);
    af.location     = APPLY_REGEN_BASE;
    af.modifier     = base;
    af.bitvector    = 0;
	af.flags = 0;
    spellAffectToChar(victim,&af);       
	af.location		= APPLY_REGEN_HP;
	af.modifier		= stat;
	spellAffectToChar(victim,&af);

    actprintf(victim,NULL,NULL,TO_CHAR,"You experience %s with nature.",word);
    actprintf(victim,NULL,NULL,TO_ROOM,"$n appears to be in %s with nature.",word);
    return;
}

bool spell_amity(int sn, int level, Character *ch, void *vo, int target )
{
	Character *victim = (Character *) vo;

	druid_regen(sn,level,ch,victim,9,2,10,"amity");
	return TRUE;
}

bool spell_accord(int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo; 

    druid_regen(sn,level,ch,victim,12,4,25,"accord");
    return TRUE;
}

bool spell_empathy(int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo; 

    druid_regen(sn,level,ch,victim,15,8,40,"empathy");
    return TRUE;
}

bool spell_oneness(int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo; 

    druid_regen(sn,level,ch,victim,18,12,60,"oneness");
    return TRUE;
}

bool spell_unity(int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo; 

    druid_regen(sn,level,ch,victim,21,20,100,"unity");
    return TRUE;
}

void druid_ac_str_debuff(int sn,int level,Character *ch,Character *victim,int dur,int str,int ac)
{
    Affect af;

	if ( check_saves_spell(ch,victim,DAM_SPIRIT,SAVE_FORTITUDE) )
	{
		act("$N appears to be momentarily weakened, but $E recovers.",ch,NULL,victim,TO_CHAR);
		act("You feel momentarily weakened, but you recover quickly.",ch,NULL,victim,TO_VICT);
		return;
	}

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(dur);
    af.location     = APPLY_AC;
    af.modifier     = ac;
    af.bitvector    = 0;
	af.flags = 0;
    spellAffectToChar(victim,&af);
    af.location     = APPLY_STR;
    af.modifier     = str;
    spellAffectToChar(victim,&af);       

    actprintf(victim,NULL,NULL,TO_CHAR,"You feel weak and vulnerable!");
    actprintf(victim,NULL,NULL,TO_ROOM,"$n appears to be weakened!");
    return;
}

bool spell_debility(int sn, int level, Character *ch, void *vo, int target )       
{
    Character *victim = (Character *) vo;

    druid_ac_str_debuff(sn,level,ch,victim,2,-8,-16);
    return TRUE;    
}

bool spell_atony(int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_ac_str_debuff(sn,level,ch,victim,4,-16,-25);
    return TRUE;   
}

bool spell_languor(int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_ac_str_debuff(sn,level,ch,victim,6,-25,-35);
    return TRUE;   
}

bool spell_impotence(int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_ac_str_debuff(sn,level,ch,victim,8,-35,-46);
    return TRUE;   
}

bool spell_infirmiry(int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_ac_str_debuff(sn,level,ch,victim,10,-46,-58);
    return TRUE;   
}

bool spell_fragility(int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;

    druid_ac_str_debuff(sn,level,ch,victim,12,-58,-71);
    return TRUE;   
}

void druid_blind(int sn,int level,Character *ch,Character *victim,int dur,int amt,char *word)
{
	Affect af;

	if ( check_saves_spell(ch,victim,DAM_LIGHT,SAVE_REFLEX))
	{
		actprintf(ch,NULL,victim,TO_VICT,"You manage to avert your eyes as $n unleashes a blinding %s of light.",word);
		actprintf(ch,NULL,victim,TO_CHAR,"$N manages to avert $S eyes as you unleash a blinding %s of light.",word);
		actprintf(ch,NULL,victim,TO_NOTVICT,"$N manages to avert $S eyes as $n unleashes a blinding %s of light.",word);
		return;
	}

	af.where		= TO_AFFECTS;
	af.type			= sn;
	af.level		= level;
	af.duration		= seconds(dur);
	af.modifier		= amt;
	af.location		= APPLY_HITROLL;
	af.bitvector	= AFF_BLIND;
	af.flags = 0;
	spellAffectToChar( victim, &af );

	actprintf(victim,NULL,NULL,TO_CHAR,"You are blinded by a %s of light!",word);
	actprintf(victim,NULL,NULL,TO_ROOM,"$n is blinded by a %s of light!",word);
	return;
}

bool spell_spark_of_light(int sn, int level, Character *ch, void *vo, int target )
{
	Character *vch;
	bool fMessage = FALSE;

	for( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
		if( vch == ch || is_same_group(vch,ch) || is_safe_spell(ch,vch,TRUE ) )
			continue;
		else
		{
			fMessage = TRUE;
			druid_blind(sn,level,ch,vch,8,-28,"spark");
		}

	if ( !fMessage )
	{
		act("There are no valid targets for this spell in this room.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}
		
    return TRUE;
}

bool spell_gleam_of_light(int sn, int level, Character *ch, void *vo, int target )
{
    Character *vch;
	bool fMessage = FALSE;

    for( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
        if( vch == ch || is_same_group(vch,ch) || is_safe_spell(ch,vch,TRUE ) )
            continue;
        else
		{
			fMessage = TRUE;
            druid_blind(sn,level,ch,vch,12,-52,"gleam");
		}

	if ( !fMessage )
	{
		act("There are no valid targets for this spell in this room.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

    return TRUE;
}

bool spell_streak_of_light(int sn, int level, Character *ch, void *vo, int target )
{
    Character *vch;
	bool fMessage = FALSE;

    for( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
        if( vch == ch || is_same_group(vch,ch) || is_safe_spell(ch,vch,TRUE ) )
            continue;
        else
		{
			fMessage = TRUE;
            druid_blind(sn,level,ch,vch,16,-80,"streak");
		}

	if ( !fMessage )
	{
		act("There are no valid targets for this spell in this room.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

    return TRUE;
}

bool spell_flare_of_light(int sn, int level, Character *ch, void *vo, int target )
{
    Character *vch;
	bool fMessage = FALSE;

    for( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
        if( vch == ch || is_same_group(vch,ch) || is_safe_spell(ch,vch,TRUE ) )
            continue;
        else
		{
			fMessage = TRUE;
            druid_blind(sn,level,ch,vch,22,-112,"flare");
		}

	if ( !fMessage )
	{
		act("There are no valid targets for this spell in this room.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

    return TRUE;
}

bool spell_halo_of_light(int sn, int level, Character *ch, void *vo, int target )
{
    Character *vch;
	bool fMessage = FALSE;

    for( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
        if( vch == ch || is_same_group(vch,ch) || is_safe_spell(ch,vch,TRUE ) )
            continue;
        else
		{
			fMessage = TRUE;
            druid_blind(sn,level,ch,vch,30,-148,"halo");
		}

	if ( !fMessage )
	{
		act("There are no valid targets for this spell in this room.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

    return TRUE;
}

bool spell_nimbus_of_light(int sn, int level, Character *ch, void *vo, int target )
{
    Character *vch;
	bool fMessage = FALSE;

    for( vch = ch->in_room->people ; vch != NULL ; vch = vch->next_in_room )
        if( vch == ch || is_same_group(vch,ch) || is_safe_spell(ch,vch,TRUE ) )
            continue;
        else
		{
			fMessage = TRUE;
            druid_blind(sn,level,ch,vch,40,-188,"nimbus");
		}

	if ( !fMessage )
	{
		act("There are no valid targets for this spell in this room.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

    return TRUE;
}

bool spell_fire_tap( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,4,5);

    if ( check_saves_spell(ch,victim,DAM_FIRE,SAVE_REFLEX) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_FIRE , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_fire_touch( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,13,16);

    if ( check_saves_spell(ch,victim,DAM_FIRE,SAVE_REFLEX) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_FIRE , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_fire_shock( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,27,33);

    if ( check_saves_spell(ch,victim,DAM_FIRE,SAVE_REFLEX) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_FIRE , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_fire_circle( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,48,60);

    if ( check_saves_spell(ch,victim,DAM_FIRE,SAVE_REFLEX) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_FIRE , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_fire_halo( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,81,101);

    if ( check_saves_spell(ch,victim,DAM_FIRE,SAVE_REFLEX) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_FIRE , DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_fire_nimbus( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    int dam;

    dam = calcSpellDamage(ch,sn,126,158);

    if ( check_saves_spell(ch,victim,DAM_FIRE,SAVE_REFLEX) )
        dam /= 2;
    damage( ch, victim, dam, sn, DAM_FIRE , DF_SHOW | DF_SPELL );
    return TRUE;
}

void druid_flame_dot( int sn, int level, Character *ch,Character *victim,int dur,int low, int high)
{
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_FIRE, SAVE_FORTITUDE) )
    {
        actprintf(victim,NULL,NULL,TO_CHAR,"You begin to feel hot, but the sensation fades.");
		actprintf(ch,NULL,NULL,TO_CHAR,"Nothing seems to happen.");
        return;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
        af.caster_id    = ch->id;
        af.bitvector    = DAM_FIRE;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(dur);
        af.location     = low;
        af.modifier     = high;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        act("You engulfed in flame!",victim,NULL,NULL,TO_CHAR);
        act("$n is engulfed in flame!",victim,NULL,NULL,TO_ROOM);
    }

    damage( ch, victim, 0, sn, DAM_FIRE , DF_SPELL );
    return;
}

bool spell_tongues_of_flame(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;
	
	druid_flame_dot(sn,level,ch,victim,60,3,7);
	return TRUE;
}

bool spell_aura_of_flame(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_flame_dot(sn,level,ch,victim,60,7,15);
    return TRUE;
}

bool spell_shell_of_flame(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_flame_dot(sn,level,ch,victim,60,13,27);
    return TRUE;
}

bool spell_halo_of_flame(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_flame_dot(sn,level,ch,victim,60,22,45);
    return TRUE;
}

bool spell_blanket_of_flame(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_flame_dot(sn,level,ch,victim,60,32,75);
    return TRUE;
}

bool spell_bonds_of_flame(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_flame_dot(sn,level,ch,victim,60,50,100);
    return TRUE;
}

void druid_stun(int sn,int level,Character *ch,Character *victim,int d,int dur,char *word)
{
	int dam;

    dam = calcSpellDamage(ch,sn,lowDam(d*3/4),highDam(d));

    if ( check_saves_spell(ch, victim, DAM_AIR, SAVE_FORTITUDE) )
        dam /= 2;
    else
    {
        DAZE_STATE(victim,PULSE_PER_SECOND*dur);
        actprintf(victim,NULL,NULL,TO_CHAR,"You are stunned by the %s!",word);
		actprintf(victim,NULL,NULL,TO_ROOM,"$n is stunned by the %s!",word);
    }

    damage( ch, victim, dam, sn, DAM_AIR , DF_SHOW | DF_SPELL );
    return;
}

bool spell_draught(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_stun(sn,level,ch,victim,12,3,"draught");
    return TRUE;
}

bool spell_gust(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_stun(sn,level,ch,victim,22,4,"gust");
    return TRUE;
}

bool spell_breeze(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_stun(sn,level,ch,victim,40,5,"breeze");
    return TRUE;
}

bool spell_wind(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_stun(sn,level,ch,victim,66,6,"wind");
    return TRUE;
}

bool spell_tornado(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_stun(sn,level,ch,victim,102,8,"tornado");
    return TRUE;
}


void druid_pierce_dot( int sn, int level, Character *ch,Character *victim,int dur,int low, int high,char *word)
{
    Affect af;

    if ( check_saves_spell(ch, victim, DAM_PIERCE, SAVE_FORTITUDE) )
    {
        actprintf(victim,NULL,NULL,TO_CHAR,"A cage of %s materializes around you and then falls to pices.",word);
        actprintf(ch,NULL,NULL,TO_CHAR,"Nothing seems to happen.");
        return;
    }
    else
    {
        af.where        = DAMAGE_OVER_TIME;
        af.caster_id    = ch->id;
        af.bitvector    = DAM_PIERCE;
        af.type         = sn;
        af.level        = level;
        af.duration     = seconds(dur);
        af.location     = low;
        af.modifier     = high;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        actprintf(victim,NULL,NULL,TO_CHAR,"You are enclosed by a cage of %s!",word);
        actprintf(victim,NULL,NULL,TO_ROOM,"$n is enclosed by a cage of %s!",word);
    }

    damage( ch, victim, 0, sn, DAM_PIERCE , DF_SPELL );
    return;
}

bool spell_cage_of_spurs(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_pierce_dot(sn,level,ch,victim,60,1,3,"spurs");
    return TRUE;
}

bool spell_cage_of_thorns(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_pierce_dot(sn,level,ch,victim,60,3,7,"throns");
    return TRUE;
}

bool spell_cage_of_barbs(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_pierce_dot(sn,level,ch,victim,60,7,14,"barbs");
    return TRUE;
}

bool spell_cage_of_brambles(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_pierce_dot(sn,level,ch,victim,60,13,26,"brambles");
    return TRUE;
}

bool spell_cage_of_needles(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_pierce_dot(sn,level,ch,victim,60,21,41,"needles");
    return TRUE;
}

bool spell_cage_of_spines(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_pierce_dot(sn,level,ch,victim,60,33,67,"spines");
    return TRUE;
}

bool spell_cage_of_spikes(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_pierce_dot(sn,level,ch,victim,60,47,95,"spikes");
    return TRUE;
}

void druid_slow_dd(int sn,int level,Character *ch,Character *victim,int dur,int slow,int dmg,char *word)
{
    Affect af;
    int dam;
    bool fSave;

    dam = calcSpellDamage(ch,sn,lowDam(dmg*3/4),highDam(dmg));

    if ( (fSave = check_saves_spell(ch, victim, DAM_WATER, SAVE_FORTITUDE)) )
        dam /= 2;
    else
    {
        af.where        = TO_AFFECTS;
        af.bitvector    = AFF_SLOW;
        af.type         = sn;
        af.level        = level;
        af.duration     = minutes(dur);
        af.location     = APPLY_SPEED;
        af.modifier     = slow;
        af.flags        = AFF_SPELL;
        spellAffectToChar( victim, &af );

        actprintf(victim,NULL,NULL,TO_CHAR,"You are drenched and slowed by the %s!",word);
        actprintf(victim,NULL,NULL,TO_ROOM,"$n is drenched and slowed by the %s!",word);
    }

    damage( ch, victim, dam, sn, DAM_WATER , DF_SHOW | DF_SPELL );
}

bool spell_deluge(int sn,int level,Character *ch,void *vo,int target)
{
	Character *victim = (Character *) vo;

	druid_slow_dd(sn,level,ch,victim,2,108,25,"deluge");
	return TRUE;
}

bool spell_downpour(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_slow_dd(sn,level,ch,victim,3,112,42,"downpour");
    return TRUE;
}

bool spell_storm(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_slow_dd(sn,level,ch,victim,4,116,67,"storm");
    return TRUE;
}

bool spell_gale(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_slow_dd(sn,level,ch,victim,6,120,99,"gale");
    return TRUE;
}

bool spell_tempest(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_slow_dd(sn,level,ch,victim,9,124,149,"tempest");
    return TRUE;
}

bool spell_hurricane(int sn,int level,Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;

    druid_slow_dd(sn,level,ch,victim,12,128,224,"hurricane");
    return TRUE;
}

bool spell_ring_of_lok_javek(int sn,int level,Character *ch,void *vo,int target)
{
	return gate( ch, 20047 );
}

bool spell_ring_of_selith(int sn,int level,Character *ch,void *vo,int target)
{
	return gate( ch, 447 );
}

/* Does NOT work on extra-planer, undead, or constructs/summoned */
bool spell_generic_charm_anything( int sn, Character *ch,void *vo,int level)
{
    Character *pet = (Character *) vo;

    if ( !IS_NPC(pet) )
    {
        cprintf(ch,"You cannot charm players.\n\r");
        return FALSE;
    }

    if( ch->pet != NULL )
    {
        cprintf(ch,"Dismiss the one you have!\n\r");
        return FALSE;
    }

	if ( IS_SET( pet->form, FORM_UNDEAD ) )
	{
		act("This spell does not work on the undead.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

    if ( IS_SET( pet->form, FORM_CONSTRUCTED ) )
    {
        act("This spell does not work on constructs.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( IS_SET( pet->form, FORM_SUMMONED ) )
    {
        act("This spell does not work on summoned creatures.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( IS_SET( pet->form, FORM_EXTRAPLANER ) )
    {
        act("This spell does not work on extra-planer creatures.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( pet->level > level )
    {
        act("$N is too powerful for you to control.",ch,NULL,pet,TO_CHAR);
        return FALSE;
    }

    if ( check_saves_spell(ch,pet,DAM_MENTAL,SAVE_WILLPOWER))
    {
        cprintf(ch,"You failed.\n\r");
        return TRUE;
    }

    add_follower( pet, ch );
    pet->leader = ch;
    ch->pet = pet;
    SET_BIT( pet->affected_by, AFF_CHARM );
    SET_BIT( pet->act, ACT_PET );
    REMOVE_BIT( pet->act, ACT_AGGRESSIVE );
    act("$N now follows $n.",ch,NULL,pet,TO_NOTVICT);
    pet_to_group( ch, pet );
    return TRUE;
}

bool spell_generic_charm_animal( int sn, Character *ch,void *vo,int level)
{
    Character *pet = (Character *) vo;

    if ( !IS_NPC(pet) )
    {
        cprintf(ch,"You cannot charm players.\n\r");
        return FALSE;
    }

    if( ch->pet != NULL )
    {
        cprintf(ch,"Dismiss the one you have!\n\r");
        return FALSE;
    }

	if ( !IS_SET( pet->form,FORM_ANIMAL ) )
	{
		act("$N is not an animal.",ch,NULL,pet,TO_CHAR);
		return FALSE;
	}

    if ( IS_SET( pet->form, FORM_UNDEAD ) )
    {
        act("This spell does not work on the undead.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( IS_SET( pet->form, FORM_CONSTRUCTED ) )
    {
        act("This spell does not work on constructs.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( IS_SET( pet->form, FORM_SUMMONED ) )
    {
        act("This spell does not work on summoned creatures.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( IS_SET( pet->form, FORM_EXTRAPLANER ) )
    {
        act("This spell does not work on extra-planer creatures.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( pet->level > level )
    {
        act("$N is too powerful for you to control.",ch,NULL,pet,TO_CHAR);
        return FALSE;
    }

    if ( check_saves_spell(ch,pet,DAM_MENTAL,SAVE_WILLPOWER))
    {
        cprintf(ch,"You failed.\n\r");
        return TRUE;
    }

    add_follower( pet, ch );
    pet->leader = ch;
    ch->pet = pet;
    SET_BIT( pet->affected_by, AFF_CHARM );
    SET_BIT( pet->act, ACT_PET );
    REMOVE_BIT( pet->act, ACT_AGGRESSIVE );

    act("$N now follows $n.",ch,NULL,pet,TO_NOTVICT);
    pet_to_group( ch, pet );
    return TRUE;
}

bool spell_generic_charm_plant( int sn, Character *ch,void *vo,int level)
{ 
    Character *pet = (Character *) vo;

    if ( !IS_NPC(pet) )
    {
        cprintf(ch,"You cannot charm players.\n\r");
        return FALSE;
    }

    if( ch->pet != NULL )
    {
        cprintf(ch,"Dismiss the one you have!\n\r");
        return FALSE;
    }

    if ( !IS_SET( pet->form,FORM_PLANT ) )
    {
        act("$N is not a plant.",ch,NULL,pet,TO_CHAR);
        return FALSE;
    }

    if ( IS_SET( pet->form, FORM_UNDEAD ) )
    {
        act("This spell does not work on the undead.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( IS_SET( pet->form, FORM_CONSTRUCTED ) )
    {
        act("This spell does not work on constructs.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( IS_SET( pet->form, FORM_SUMMONED ) )
    {
        act("This spell does not work on summoned creatures.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( IS_SET( pet->form, FORM_EXTRAPLANER ) )
    {
        act("This spell does not work on extra-planer creatures.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( pet->level > level )
    {
        act("$N is too powerful for you to control.",ch,NULL,pet,TO_CHAR);   
        return FALSE;
    }

    if ( check_saves_spell(ch,pet,DAM_MENTAL,SAVE_WILLPOWER))
    {
        cprintf(ch,"You failed.\n\r");
        return TRUE;
    }

    add_follower( pet, ch );
    pet->leader = ch;
    ch->pet = pet;
    SET_BIT( pet->affected_by, AFF_CHARM );
    SET_BIT( pet->act, ACT_PET );
    REMOVE_BIT( pet->act, ACT_AGGRESSIVE );

    act("$N now follows $n.",ch,NULL,pet,TO_NOTVICT);
    pet_to_group( ch, pet );
    return TRUE;
}

bool spell_generic_charm_creature( int sn, Character *ch,void *vo,int level)
{ 
    Character *pet = (Character *) vo;

    if ( !IS_NPC(pet) )
    {
        cprintf(ch,"You cannot charm players.\n\r");
        return FALSE;
    }

    if( ch->pet != NULL )
    {
        cprintf(ch,"Dismiss the one you have!\n\r");
        return FALSE;
    }

    if ( !IS_SET( pet->form,FORM_HUMANOID ) )
    {
        act("$N is not a humanoid.",ch,NULL,pet,TO_CHAR);
        return FALSE;
    }

    if ( IS_SET( pet->form, FORM_UNDEAD ) )
    {
        act("This spell does not work on the undead.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( IS_SET( pet->form, FORM_CONSTRUCTED ) )
    {
        act("This spell does not work on constructs.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( IS_SET( pet->form, FORM_SUMMONED ) )
    {
        act("This spell does not work on summoned creatures.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( IS_SET( pet->form, FORM_EXTRAPLANER ) )
    {
        act("This spell does not work on extra-planer creatures.",ch,NULL,NULL,TO_CHAR);
        return FALSE;
    }

    if ( pet->level > level )
    {
        act("$N is too powerful for you to control.",ch,NULL,pet,TO_CHAR);   
        return FALSE;
    }

    if ( check_saves_spell(ch,pet,DAM_MENTAL,SAVE_WILLPOWER))
    {
        cprintf(ch,"You failed.\n\r");
        return TRUE;
    }

    add_follower( pet, ch );
    pet->leader = ch;
    ch->pet = pet;
    SET_BIT( pet->affected_by, AFF_CHARM );
    SET_BIT( pet->act, ACT_PET );
    REMOVE_BIT( pet->act, ACT_AGGRESSIVE );

    act("$N now follows $n.",ch,NULL,pet,TO_NOTVICT);
    pet_to_group( ch, pet );
    return TRUE;
}

/*
 * Druid charms
 * lull = 75% of level
 * control = 85% of level
 * command = 95% of level
 */

bool spell_lull_animal(int sn,int level,Character *ch,void *vo,int target)
{
	return spell_generic_charm_animal( sn, ch, vo, get_skill(ch,gsn_nature)*75/100 );
}

bool spell_control_animal(int sn,int level,Character *ch,void *vo,int target)
{
    return spell_generic_charm_animal( sn, ch, vo, get_skill(ch,gsn_nature)*85/100 );
}

bool spell_command_animal(int sn,int level,Character *ch,void *vo,int target)
{
    return spell_generic_charm_animal( sn, ch, vo, get_skill(ch,gsn_nature)*95/100 );
}

bool spell_lull_plant(int sn,int level,Character *ch,void *vo,int target)
{
    return spell_generic_charm_plant( sn, ch, vo, get_skill(ch,gsn_nature)*75/100 );
}

bool spell_control_plant(int sn,int level,Character *ch,void *vo,int target)
{
    return spell_generic_charm_plant( sn, ch, vo, get_skill(ch,gsn_nature)*85/100 );
}

bool spell_command_plant(int sn,int level,Character *ch,void *vo,int target)
{
    return spell_generic_charm_plant( sn, ch, vo, get_skill(ch,gsn_nature)*95/100 );
}

bool spell_lull_creature(int sn,int level,Character *ch,void *vo,int target)
{
    return spell_generic_charm_creature( sn, ch, vo, get_skill(ch,gsn_nature)*75/100 );
}

bool spell_control_creature(int sn,int level,Character *ch,void *vo,int target)
{
    return spell_generic_charm_creature( sn, ch, vo, get_skill(ch,gsn_nature)*85/100 );
}

bool spell_command_creature(int sn,int level,Character *ch,void *vo,int target)
{
    return spell_generic_charm_creature( sn, ch, vo, get_skill(ch,gsn_nature)*95/100 );
}

bool spell_strengthen_companion( int sn, int level, Character *ch,void *vo,int target)
{
    Character *pet = (Character *) vo;      
    Affect af;

    af.where        = TO_AFFECTS;
    af.caster_id    = ch->id;
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = -1;
    af.location     = APPLY_HIT;
    af.modifier     = max_stat_hit( pet ) / 10;
    af.flags        = AFF_SPELL;
    spellAffectToChar( pet, &af );

    act("$N is augmented by $y.",ch,NULL,pet,TO_CHAR);
    return TRUE;
}

bool spell_augment_companion( int sn, int level, Character *ch,void *vo,int target)  
{
    Character *pet = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS; 
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = -1;
    af.location     = APPLY_HIT;
    af.modifier     = max_stat_hit( pet ) * 15 / 100;
    af.flags        = AFF_SPELL;
    spellAffectToChar( pet, &af );

    af.location     = APPLY_AC;
    af.modifier     = 40;
    spellAffectToChar( pet, &af );

    af.location     = APPLY_SPEED;
    af.modifier     = 82;
    spellAffectToChar( pet, &af );

    act("$N is augmented by $y.",ch,NULL,pet,TO_CHAR);
    return TRUE;
}

bool spell_empower_companion( int sn, int level, Character *ch,void *vo,int target)   
{
    Character *pet = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS; 
    af.bitvector    = 0;
    af.type         = sn;
    af.level        = level;
    af.duration     = -1;
    af.location     = APPLY_HIT;
    af.modifier     = max_stat_hit( pet ) * 20 / 100;
    af.flags        = AFF_SPELL;
    spellAffectToChar( pet, &af );

    af.location     = APPLY_AC;
    af.modifier     = 80;
    spellAffectToChar( pet, &af );

    af.location     = APPLY_SPEED;
    af.modifier     = 76;
    spellAffectToChar( pet, &af );

	act("$N is augmented by $y.",ch,NULL,pet,TO_CHAR);
    return TRUE;
}

bool spell_camouflage( int sn, int level, Character *ch, void *vo, int target )
{
	Affect af;

	if ( is_affected(ch,sn,AFF_SPELL) )
	{
		act("You are already in camouflage.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

	switch( ch->in_room->sector_type )
	{
		case SECT_INSIDE:
		case SECT_CITY:
			act("You must be out in nature to use this spell.",ch,NULL,NULL,TO_CHAR);
			return FALSE;
	}

	af.where		= TO_AFFECTS;
	af.bitvector	= AFF_INVISIBLE;
	af.type			= sn;
	af.level		= level;
	af.duration		= minutes(20);
	af.location		= 0;
	af.modifier		= 0;
	af.flags		= AFF_SPELL;
	spellAffectToChar( ch, &af );

	act("You blend into your surroundings.",ch,NULL,NULL,TO_CHAR);
	act("$n blends into the surroundings.",ch,NULL,NULL,TO_ROOM);
	return TRUE;
}

bool spell_treeform( int sn, int level, Character *ch, void *vo, int target )
{
	Affect af;

	if ( is_affected(ch,sn,AFF_SPELL) )
	{
		act("You are in treeform.",ch,NULL,NULL,TO_CHAR);
		return FALSE;
	}

	switch( ch->in_room->sector_type )
	{
		case SECT_FOREST:
			break;
		default:
			act("You must be in a forest to use treeform.",ch,NULL,NULL,TO_CHAR);
			return FALSE;
	}

	af.where		= TO_AFFECTS;
	af.bitvector	= 0;
	af.type			= sn;
	af.level		= level;
	af.duration		= minutes(20);
	af.location		= 0;
	af.modifier		= 0;
	af.misc			= 0;
	af.flags		= AFF_SPELL;
	spellAffectToChar( ch, &af );

	act("You turn into a massive oak tree.",ch,NULL,NULL,TO_CHAR);
	act("$n vanishes from your sight!",ch,NULL,NULL,TO_ROOM);
	return TRUE;
}

bool spell_heat_metal( int sn, int level, Character *ch, void *vo, int target )
{
	Character *victim = (Character *) vo;
	Object *obj;
	int		total = 0;

	for( obj = victim->carrying ; obj ; obj = obj->next_content )
	{
		if ( obj->wear_loc == -1 )
		{
			/* Check for metal materials */
			if ( !str_cmp( obj->material, "steel" ) ||
				 !str_cmp( obj->material, "iron") ||
				 !str_cmp( obj->material, "pewter") ||
				 !str_cmp( obj->material, "lead") ||
				 !str_cmp( obj->material, "silver") ||
				 !str_cmp( obj->material, "bronze") ||
				 !str_cmp( obj->material, "gold") ||
				 !str_cmp( obj->material, "platinum") ||
				 !str_cmp( obj->material, "copper") ||
				 !str_cmp( obj->material, "mithril") ||
				 !str_cmp( obj->material, "brass") )
			{
				total += number_range( 1, obj->level / 2 );
			}
		}
	}

	if ( total == 0 )
	{
		act("$N is not wearing any metal armor.",ch,NULL,victim,TO_CHAR);
		return FALSE;
	}

	damage( ch, victim, total, sn, DAM_FIRE , DF_SHOW | DF_SPELL );
	return TRUE;
}

/*
 * Does damage per piece of armor that the victim is wearing
 */
bool spell_chill_metal( int sn, int level, Character *ch, void *vo, int target )
{
	Character *victim = (Character *) vo;
	Object *obj;
	int		total = 0;

	for( obj = victim->carrying ; obj ; obj = obj->next_content )
	{
		if ( obj->wear_loc == -1 )
		{
			/* Check for metal materials */
			if ( !str_cmp( obj->material, "steel" ) ||
				 !str_cmp( obj->material, "iron") ||
				 !str_cmp( obj->material, "pewter") ||
				 !str_cmp( obj->material, "lead") ||
				 !str_cmp( obj->material, "silver") ||
				 !str_cmp( obj->material, "bronze") ||
				 !str_cmp( obj->material, "gold") ||
				 !str_cmp( obj->material, "platinum") ||
				 !str_cmp( obj->material, "copper") ||
				 !str_cmp( obj->material, "mithril") ||
				 !str_cmp( obj->material, "brass") )
			{
				total += number_range( 1, obj->level / 2 );
			}
		}
	}

	if ( total == 0 )
	{
		act("$N is not wearing any metal armor.",ch,NULL,victim,TO_CHAR);
		return FALSE;
	}

	damage( ch, victim, total, sn, DAM_COLD , DF_SHOW | DF_SPELL );
	return TRUE;
}

/*
 * Does damage per piece of armor that the victim is wearing
 */
bool spell_heat_armor( int sn, int level, Character *ch, void *vo, int target )
{
	Character *victim = (Character *) vo;
	Object *obj;
	int		total = 0;

	for( obj = victim->carrying ; obj ; obj = obj->next_content )
	{
		if ( obj->wear_loc == -1 )
		{
			/* Check for metal materials */
			if ( !str_cmp( obj->material, "steel" ) ||
				 !str_cmp( obj->material, "iron") ||
				 !str_cmp( obj->material, "pewter") ||
				 !str_cmp( obj->material, "lead") ||
				 !str_cmp( obj->material, "silver") ||
				 !str_cmp( obj->material, "bronze") ||
				 !str_cmp( obj->material, "gold") ||
				 !str_cmp( obj->material, "platinum") ||
				 !str_cmp( obj->material, "copper") ||
				 !str_cmp( obj->material, "mithril") ||
				 !str_cmp( obj->material, "brass") )
			{
				total += number_range( 1, obj->level / 2 );
			}
		}
	}

	if ( total == 0 )
	{
		act("$N is not wearing any metal armor.",ch,NULL,victim,TO_CHAR);
		return FALSE;
	}

	damage( ch, victim, total, sn, DAM_FIRE , DF_SHOW | DF_SPELL );
	return TRUE;
}

bool spell_natures_defender( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(24);
    af.location     = APPLY_ABSORB;
    af.modifier     = 10;
    af.bitvector    = 0;    
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );

    cprintf(victim,"You are annointed as Nature's Defender.\n\r");
    act("A dark green aura radiates around $N.",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_natures_guardian( int sn, int level, Character *ch,void *vo,int target)
{
    Character *victim = (Character *) vo;
    Affect af;

    af.where        = TO_AFFECTS;
    af.type         = sn;
    af.level        = level;
    af.duration     = minutes(24);
    af.location     = APPLY_ABSORB;
    af.modifier     = 20;
    af.bitvector    = 0;    
    af.flags        = AFF_SPELL;

    spellAffectToChar( victim, &af );

    cprintf(victim,"You are annointed as Nature's Guardian.\n\r");
    act("A brilliant green aura radiates around $n!",victim,NULL,NULL,TO_ROOM);
    return TRUE;
}

bool spell_detach_summoned( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    int   dam;     

    if ( !IS_SET( victim->form, FORM_SUMMONED )  && !IS_SET( victim->form, FORM_CONSTRUCTED))
    {
        act("$N is not a summoned creature.",ch,NULL,victim,TO_CHAR);
        return FALSE;     
    }

    dam = calcSpellDamage(ch,sn,lowDam(28),highDam(34));

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;

    damage( ch, victim, dam, sn, DAM_SPIRIT, DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_disjoin_summoned( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    int   dam;

    if ( !IS_SET( victim->form, FORM_SUMMONED ) && !IS_SET( victim->form, FORM_CONSTRUCTED))
    {
        act("$N is not a summoned creature.",ch,NULL,victim,TO_CHAR);
        return FALSE;   
    }

    dam = calcSpellDamage(ch,sn,lowDam(62),highDam(76));  

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;

    damage( ch, victim, dam, sn, DAM_SPIRIT, DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_release_summoned( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    int   dam;

    if ( !IS_SET( victim->form, FORM_SUMMONED ) && !IS_SET( victim->form, FORM_CONSTRUCTED))
    {
        act("$N is not a summoned creature.",ch,NULL,victim,TO_CHAR);
        return FALSE;   
    }

    dam = calcSpellDamage(ch,sn,lowDam(116),highDam(142));  

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;

    damage( ch, victim, dam, sn, DAM_SPIRIT, DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_unbind_summoned( int sn, int level, Character *ch, void *vo, int target )
{
    Character *victim = (Character *) vo;
    int   dam;

    if ( !IS_SET( victim->form, FORM_SUMMONED ) && !IS_SET( victim->form, FORM_CONSTRUCTED))
    {
        act("$N is not a summoned creature.",ch,NULL,victim,TO_CHAR);
        return FALSE;   
    }

    dam = calcSpellDamage(ch,sn,lowDam(202),highDam(246));  

    if ( check_saves_spell(ch, victim, DAM_SPIRIT, SAVE_WILLPOWER) )
        dam /= 2;

    damage( ch, victim, dam, sn, DAM_SPIRIT, DF_SHOW | DF_SPELL );
    return TRUE;
}

bool spell_regrowth( int sn, int level, Character *ch, void *vo, int target )
{
    int   amount;
	extern void regenResource( Room *room, int type, int amount );

	if ( ch->in_room->sector_type != SECT_FOREST )
	{
		cprintf(ch,"This spell only works in the forest.\n\r");
		return FALSE;
	}

	amount = number_range( get_skill(ch,gsn_nature)*10, get_skill(ch,gsn_nature)*20 );
	regenResource( ch->in_room, NR_FOREST, amount );

	act("The ground surges as new trees break forth from the earth to tower overhead!",ch,NULL,NULL,TO_CHAR);
	act("The ground surges as new trees break forth from the earth to tower overhead!",ch,NULL,NULL,TO_ROOM);
	return TRUE;
}

