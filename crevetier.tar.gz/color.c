/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/*
 * This code is an independant module written by Jerry Gilyeat.  
 * It's design is meant to be compatible with ROM and other DIKU MUD 
 * derivatives.  However, it's intent is to remain as seperate a module as
 * possible.  All code written by Jerry Gilyeat is Copyright to him, 1999
 *
 * Handful of modifications since then by Jerry and the rest of us.
 */
#include <cstdio>
#include <cstdlib>
#include <ctype>
#include <cstring.h>
#include <sys/types.h>
#include <sys/time.h>

#include "color.h"

/*
 * The following procedure is base dependant.
 */
bool has_color( Descriptor *d )
{
    if ( d->character == NULL )
        return d->color;
    else
		return HAS_COLOROPT(d->character, COLOR_TOGGLE);
}

/*
 * Strips out color codes from a string.
 * Assume that we've already determined whether or not a character wants
 * color.
 * There's one nasty hack in here, but the rest is VERY sweet :)
 */
void stripcolor( const char * arg, char *ret )
{
    char * ptr;
    int i, len;	/* so I KNOW we put the damn thing in the right place */

    ret[0] = '\0';
    ptr = ret;
    len = strlen( arg );
    for( i = 0; i<len; i++ )
    {
	while( *arg != '\0' && *arg != '&' && i<len )
	{
	    *ptr++ = *arg++;
	    i++;
	}
	if( i == len )
	{
	    *ptr = '\0';
	    continue;
	}

	arg++; i++;
	if( *arg == '&' )
	{
	    *ptr++ = *arg++;
	} else arg++;
	*(ptr+1) = '\0';
    }
    
    *ptr = '\0';
    ret[i] = '\0';
    ptr = NULL;
}


/* 
 * Now for a minor change on the whole subject of the string parser.
 * Rather than REMOVING codes, we'll be stripping the color code out, and
 * inserting the proper escape sequence.  Let's keep it to 150 or so lines,
 * shall we?
 */
void addcolor( const char * arg, char * ret )
{
    char * ptr;
    int i, len, len2;	/* so I KNOW we put the damn thing in the right place */
    int k;

    ret[0] = '\0';
    ptr = ret;
    len = strlen( arg );
    for( i = 0; i<len; i++ )
    {
	/* 
	 * loop until we either hit the end of the road, OR we hit an '&'
	 */
	while( *arg != '\0' && *arg != '&' && i < len )
	{
	    *ptr++ = *arg++;
	    i++;
	}
	/* if we had NO codes in the thing, just break out. */
	if( i == len )
	{
	    *ptr = '\0';
	    continue;
	}

	/* Ok, we found it, drop it */
	arg++; i++;
	switch( *arg )
	{
    	    case '&': *ptr++ = *arg++;	break;	// no need to inc i again.
	    /* NOW we get into the dicey stuff */
	    case 'D': strcat( ptr, GRAY );
		    len2 = strlen( GRAY );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;  
	    case 'R': strcat( ptr, RED );
		    len2 = strlen( RED );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;  
	    case 'G': strcat( ptr, GREEN );
		    len2 = strlen( GREEN );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;  
	    case 'Y': strcat( ptr, YELLOW );
		    len2 = strlen( YELLOW );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;  
	    case 'B': strcat( ptr, BLUE );
		    len2 = strlen( BLUE );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;  
	    case 'M': strcat( ptr, MAGENTA );
		    len2 = strlen( MAGENTA );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;  
	    case 'C': strcat( ptr, CYAN );
		    len2 = strlen( CYAN );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;  
	    case 'W': strcat( ptr, WHITE );
		    len2 = strlen( WHITE );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;  
	    case '0': strcat( ptr, BBLACK );
		    len2 = strlen( BBLACK );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;  
	    case '1': strcat( ptr, BRED );
		    len2 = strlen( BRED );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;  
	    case '2': strcat( ptr, BGREEN );
		    len2 = strlen( BGREEN );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;  
	    case '3': strcat( ptr, BORANGE );
		    len2 = strlen( BORANGE );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;  
	    case '4': strcat( ptr, BBLUE );
		    len2 = strlen( BBLUE );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;  
	    case '5': strcat( ptr, BMAGENTA );
		    len2 = strlen( BMAGENTA );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;  
	    case '6': strcat( ptr, BCYAN );
		    len2 = strlen( BCYAN );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;
	    case '7': strcat( ptr, BWHITE );
		    len2 = strlen( BWHITE );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;
	    case 'k': strcat( ptr, BLACK );
		    len2 = strlen( BLACK );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;
	    case 'r': strcat( ptr, LRED );
		    len2 = strlen( LRED );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;
	    case 'g': strcat( ptr, LGREEN );
		    len2 = strlen( LGREEN );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;
	    case 'y': strcat( ptr, BROWN );
		    len2 = strlen( BROWN );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;
	    case 'b': strcat( ptr, LBLUE );
		    len2 = strlen( LBLUE );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;
		case 'u': strcat( ptr, UNDERLINE_ON );
		    len2 = strlen( UNDERLINE_ON );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;
		case 'U': strcat( ptr, UNDERLINE_OFF );
		    len2 = strlen( UNDERLINE_OFF );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;
	    case 's': strcat( ptr, SILVER );
		    len2 = strlen( SILVER );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;
	    case 'c': strcat( ptr, LCYAN );
		    len2 = strlen( LCYAN );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;
	    case 'm': strcat( ptr, LMAGENTA );
		    len2 = strlen( LMAGENTA );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;
	    case 'x':
	    case 'n': strcat( ptr, NORM );
		    len2 = strlen( NORM );
		    i += len2;
		    len += len2;
		    for( k=0; k < len2; k++, ptr++ );
		    arg++;
		    break;  
	}
    }
    *ptr = '\0';
    ret[i] = '\0';
    strcat( ret, NORM );    
    ptr = NULL;
}

// Added by Benjamin J. Siders
void stripColorInline( char * arg )
{
	char *ptr, *scan;

	ptr = scan = arg;

	while ( *scan != '\0' )
	{
		/*while ( *scan == '&' )
			++scan;*/
		if ( *scan == '&' )
		{
			++scan;
			if( *scan == '&' )
			{//two in a row, leave them both
				scan--;
				*ptr++ = *scan;
				++scan;
			}
			else
				++scan;
		}
		*ptr++ = *scan++;
	}
	*ptr = *scan;
}

struct translate_ANSI_tag
{
    char        ind;
    char        *ANSI;
};

const struct translate_ANSI_tag translate_ANSI [] =
{
    /* Foreground */
    { 'x',  "[0m"         },  /* Reset */
    { 'a',  "[0;30m"      },  /* Gray */
    { 'r',  "[0;31m"      },  /* Dark red */
    { 'g',  "[0;32m"      },  /* Dark green */
    { 'y',  "[0;33m"      },  /* Dark yellow/orange/brown */
    { 'b',  "[0;34m"      },  /* Dark blue */
    { 'm',  "[0;35m"      },  /* Dark magenta/purple */
    { 'c',  "[0;36m"      },  /* Dark cyan/teal */
    { 'w',  "[0;37m"      },  /* White */

    /* Bold foreground */
    { 'A',  "[1;30m"      },  /* Dark Grey/Black */
    { 'D',  "[1;30m"      },  /* backwards-compatability */
    { 'R',  "[1;31m"      },  /* Red */
    { 'G',  "[1;32m"      },  /* Green */
    { 'Y',  "[1;33m"      },  /* Yellow */
    { 'B',  "[1;34m"      },  /* Blue */
    { 'M',  "[1;35m"      },  /* Magenta/Pink/Purple */
    { 'C',  "[1;36m"      },  /* Cyan/Teal */
    { 'W',  "[1;37m"      },  /* Bright White */

    /* Background colors */
    { '1',  "[1;40m"      },  /* Background black */
    { '2',  "[1;41m"      },  /* Background red */
    { '3',  "[1;42m"      },  /* Background green */
    { '4',  "[1;43m"      },  /* Background yellow */
    { '5',  "[1;44m"      },  /* Background blue */
    { '6',  "[1;45m"      },  /* Background magenta */
    { '7',  "[1;46m"      },  /* Background cyan */
    { '8',  "[1;47m"      },  /* Background white */

    /* Blinking color s*/
    { '!',  "[5;30m"      },  /* Blinking grey    */
    { '@',  "[5;31m"      },  /* Blinking red     */
    { '#',  "[5;32m"      },  /* Blinking green   */
    { '$',  "[5;33m"      },  /* Blinking yellow  */
    { '%',  "[5;34m"      },  /* Blinking blue    */
    { '^',  "[5;35m"      },  /* Blinking magenta */
    { '&',  "[5;36m"      },  /* Blinking cyan    */
    { '*',  "[5;37m"      },  /* Blinking white   */

    { 0,    NULL            }
};

char *translate( char n )
{
    int i;

    for( i = 0 ; translate_ANSI[i].ANSI != NULL ; i++ )
        if ( translate_ANSI[i].ind == n )
            return translate_ANSI[i].ANSI;

    return "";
}

/* Allocate 35K for this - the output buffer won't expand any past
 * that so this should always be enough space */
static char color_buffer[(2<<16)];

char *replaceANSI( const char *txt, int fStrip )
{
    char *n;
	const char *p;

    memset(color_buffer,0,sizeof(color_buffer));

    p = txt;
    n = color_buffer;
    do
    {
        if ( *p == ESC_CHAR )
        {
            if ( *(++p) == ESC_CHAR )
            {
                *n++ = ESC_CHAR;
				++p;
                continue;
            }
            else
            {   /* Look up replace code */
                char    *replace;

                if( !fStrip )
                    replace = translate( *p );
                else
                    replace = "";

                strcpy(n,replace);
                n += strlen(replace);
                ++p;
                continue;
            }
        }

        *n++ = *p++;
    } while( *p != '\0');

    return color_buffer;
}

