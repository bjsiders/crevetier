/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

/***************************************************************************
*	ROM 2.4 is copyright 1993-1998 Russ Taylor			   *
*	ROM has been brought to you by the ROM consortium		   *
*	    Russ Taylor (rtaylor@hypercube.org)				   *
*	    Gabrielle Taylor (gtaylor@hypercube.org)			   *
*	    Brian Moore (zump@rom.org)					   *
*	By using this code, you have agreed to follow the terms of the	   *
*	ROM license, in the file Rom24/doc/rom.license			   *
***************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <stdio.h>
#include <time.h>
#include "thoc.h"
#include "magic.h"
#include "interp.h"

/* item type list */
const struct item_type		item_table	[]	=
{
    {	ITEM_LIGHT,	"light"		},
    {	ITEM_SCROLL,	"scroll"	},
    {	ITEM_WAND,	"wand"		},
    {   ITEM_STAFF,	"staff"		},
    {   ITEM_WEAPON,	"weapon"	},
    {   ITEM_TREASURE,	"treasure"	},
    {   ITEM_ARMOR,	"armor"		},
    {	ITEM_POTION,	"potion"	},
    {	ITEM_CLOTHING,	"clothing"	},
    {   ITEM_FURNITURE,	"furniture"	},
    {	ITEM_TRASH,	"trash"		},
    {	ITEM_CONTAINER,	"container"	},
    {	ITEM_DRINK_CON, "drink"		},
    {	ITEM_KEY,	"key"		},
    {	ITEM_FOOD,	"food"		},
    {	ITEM_MONEY,	"money"		},
    {	ITEM_BOAT,	"boat"		},
    {	ITEM_CORPSE_NPC,"npc_corpse"	},
    {	ITEM_CORPSE_PC,	"pc_corpse"	},
    {   ITEM_FOUNTAIN,	"fountain"	},
    {	ITEM_PILL,	"pill"		},
    {	ITEM_PROTECT,	"protect"	},
    {	ITEM_MAP,	"map"		},
    {	ITEM_PORTAL,	"portal"	},
    {	ITEM_WARP_STONE,"warp_stone"	},
    {	ITEM_ROOM_KEY,	"room_key"	},
    {	ITEM_GEM,	"gem"		},
    {	ITEM_JEWELRY,	"jewelry"	},
    {   ITEM_SPELLBOOK, "spellbook"     },
    {   ITEM_COMP_POUCH,"component-pouch" },
    {   ITEM_COMPONENT, "material-component" },
    {   ITEM_FORGE,	"forge"		},
    {   ITEM_PRAYER_BOOK, "prayer-book"	},
    {   ITEM_ARCANE_SCROLL, "arcane-scroll" },
	{	ITEM_INSTRUMENT,	"instrument"	},
	{	ITEM_HIDE,		"hide"			},
	{   ITEM_LYRIC_SHEET,	"sheet-music"	},
	{	ITEM_VENOM_SAC,		"venom-sac"		},
	{	ITEM_BINDSTONE,		"bindstone"		},
	{	ITEM_PROJECTILE,	"projectile"	},
	{	ITEM_MOBILE,		"mobile"		},
    {   ITEM_SHRINE,        "shrine"        },
    {   0,		NULL		}
};


/* weapon selection table */
const	struct	weapon_type	weapon_table	[MAX_WEAPONS]	=
{
   { "exotic weapon", WEAPON_EXOTIC, &gsn_thrusting_shortblades,	99, 2, 35 , DAM_PIERCE },
   { "dirk",		WEAPON_DIRK,	&gsn_thrusting_shortblades, 	99, 2, 22 , DAM_PIERCE },
   { "fang",        WEAPON_FANG,    &gsn_thrusting_shortblades,     99, 2, 22 , DAM_PIERCE },
   { "dagger",  	WEAPON_DAGGER,	&gsn_thrusting_shortblades,	98, 2, 24 , DAM_PIERCE },
   { "stilleto",	WEAPON_STILLETO,&gsn_thrusting_shortblades,	97, 2, 26 , DAM_PIERCE },
   { "main-gauche",	WEAPON_MAIN_GAUCHE,&gsn_thrusting_shortblades,  99, 2, 24 , DAM_PIERCE },
   { "knife",		WEAPON_KNIFE,	&gsn_thrusting_shortblades,	99, 2, 22 , DAM_PIERCE },
   { "hook",		WEAPON_HOOK,	&gsn_thrusting_shortblades, 99, 3, 26 , DAM_PIERCE },
   { "sai",			WEAPON_SAI,		&gsn_thrusting_shortblades, 99, 2, 24 , DAM_PIERCE },

   { "wakizashi",	WEAPON_WAKIZASHI,&gsn_thrusting_longblades, 95, 2, 28 , DAM_PIERCE },
   { "rapier",		WEAPON_RAPIER,	&gsn_thrusting_longblades,	98, 2, 28 , DAM_PIERCE },
   { "shortsword",	WEAPON_SHORTSWORD,&gsn_thrusting_longblades,	98, 2, 30 , DAM_PIERCE },
   { "gladius",		WEAPON_GLADIUS,	&gsn_thrusting_longblades,	99, 2, 30 , DAM_PIERCE },
   { "drusus",		WEAPON_DRUSUS,	&gsn_thrusting_longblades,	97, 2, 32 , DAM_PIERCE }, 
   { "claw",		WEAPON_CLAW,	&gsn_thrusting_longblades,	99, 3, 32 , DAM_PIERCE },

   { "katana",		WEAPON_KATANA,&gsn_slashing_shortblades,	90, 2, 34 , DAM_SLASH },
   { "scimitar",	WEAPON_SCIMITAR,&gsn_slashing_shortblades,	98, 3, 36 , DAM_SLASH },
   { "cutlass",		WEAPON_CUTLASS,	&gsn_slashing_shortblades,	98, 2, 36 , DAM_SLASH },
   { "falchion",	WEAPON_FALCHION,&gsn_slashing_shortblades,	99, 3, 38 , DAM_SLASH },
   { "broadsword",	WEAPON_BROADSWORD,&gsn_slashing_shortblades,	96, 2, 36 , DAM_SLASH },	
   { "machete",		WEAPON_MACHETE,&gsn_slashing_shortblades, 99, 2, 34 , DAM_SLASH },
   { "sickle",		WEAPON_SICKLE,&gsn_slashing_shortblades, 99, 2, 38 , DAM_SLASH },

   { "scythe",		WEAPON_SCYTHE,&gsn_slashing_longblades, 99, 2, 40 , DAM_SLASH },
   { "sabre",		WEAPON_SABRE,&gsn_slashing_longblades, 98, 2, 40 , DAM_SLASH },
   { "longsword",	WEAPON_LONGSWORD,&gsn_slashing_longblades,	98, 2, 42 , DAM_SLASH },
   { "bastard sword",	WEAPON_BASTARD_SWORD,&gsn_slashing_longblades, 96, 2, 42 , DAM_SLASH },
   { "claymore",	WEAPON_CLAYMORE, &gsn_slashing_longblades,	97, 2, 44 , DAM_SLASH },
   { "two-handed sword",WEAPON_2H_SWORD, &gsn_slashing_longblades,	95, 2, 44 , DAM_SLASH },

   { "mace",		WEAPON_MACE,	&gsn_1h_concussion,		98, 2, 30 , DAM_BASH },
   { "flail",		WEAPON_FLAIL,	&gsn_1h_concussion,		97, 2, 32 , DAM_BASH },
   { "warhammer",	WEAPON_WARHAMMER,&gsn_1h_concussion,		98, 3, 34 , DAM_BASH },
   { "club",		WEAPON_CLUB,	&gsn_1h_concussion,			99, 2, 28 , DAM_BASH },
   { "mallet",	WEAPON_MALLET,	&gsn_1h_concussion, 98, 2, 36 , DAM_BASH },

   { "morningstar",	WEAPON_MORNINGSTAR,&gsn_2h_concussion,		96, 2, 38 , DAM_BASH },
   { "two-handed hammer",WEAPON_2H_WARHAMMER,&gsn_2h_concussion,	98, 3, 42 , DAM_BASH },
   { "maul",		WEAPON_MAUL,	&gsn_2h_concussion,			95, 2, 44 , DAM_BASH },
   { "tetsubo",		WEAPON_TETSUBO, &gsn_2h_concussion,			90, 2, 40 , DAM_BASH },

   { "bardiche",	WEAPON_BARDICHE, &gsn_axe,	92, 2, 45 , DAM_SLASH },
   { "hatchet",	WEAPON_HATCHET, &gsn_axe, 98, 2, 30 , DAM_SLASH },
   { "hand axe",	WEAPON_THROWING_AXE,&gsn_axe,	99, 2, 33 , DAM_SLASH },
   { "battle axe",	WEAPON_BATTLE_AXE, &gsn_axe,	96, 2, 39 , DAM_SLASH },
   { "two-handed axe",WEAPON_2H_WARAXE, &gsn_axe,	97, 3, 42 , DAM_SLASH },
   { "pickaxe",	WEAPON_PICK, &gsn_axe,			98, 3, 36 , DAM_SLASH },

   { "spear",		WEAPON_SPEAR,	&gsn_spear,			94, 2, 32 , DAM_PIERCE },
   { "javelin",		WEAPON_JAVELIN, &gsn_spear,			99, 4, 35 , DAM_PIERCE },
   { "harpoon",		WEAPON_HARPOON,	&gsn_spear,			99, 4, 42 , DAM_PIERCE },

   { "crossbow",	WEAPON_CROSSBOW,&gsn_crossbow,			99, 2, 35 , DAM_PIERCE },
   { "shortbow",	WEAPON_SHORTBOW,&gsn_shortbow,			98, 2, 32 , DAM_PIERCE },
   { "longbow",		WEAPON_LONGBOW, &gsn_longbow,			97, 2, 40 , DAM_PIERCE },
   { "diakyu",		WEAPON_DIAKYU, &gsn_longbow,		    90, 2, 40 , DAM_PIERCE },
   { "composite bow",   WEAPON_COMPOSITE_LONGBOW,&gsn_composite_longbow, 97, 3, 45 , DAM_PIERCE },

   { "bo stick",	WEAPON_BO_STICK,	&gsn_staff,		90, 2, 32 , DAM_BASH },
   { "staff",		WEAPON_STAFF,	&gsn_staff,			99, 2, 42 , DAM_BASH },
   { "quarterstaff",WEAPON_QUARTERSTAFF, &gsn_staff,	98, 2, 38 , DAM_BASH },

   { "naginata",	WEAPON_NAGINATA,&gsn_polearm,			90, 3, 38 , DAM_SLASH },
   { "lance",		WEAPON_LANCE,	&gsn_polearm,			98, 3, 46 , DAM_PIERCE },
   { "trident",		WEAPON_TRIDENT, &gsn_spear,				98, 3, 38 , DAM_PIERCE },
   { "halberd",		WEAPON_HALBERD,	&gsn_polearm,			99, 5, 48 , DAM_SLASH },
   { "voulge",		WEAPON_VOULGE,  &gsn_polearm,			94, 2, 50 , DAM_SLASH },
   { "pike",		WEAPON_PIKE,	&gsn_polearm,			98, 3, 52 , DAM_PIERCE },
   { "glaive",		WEAPON_GLAIVE,	&gsn_polearm,			96, 3, 42 , DAM_SLASH },
   { "ranseur",		WEAPON_RANSEUR,	&gsn_polearm,			96, 3, 44 , DAM_PIERCE },
  
   { "whip",		WEAPON_WHIP,	&gsn_whip,				99, 2, 40 , DAM_SLASH }, 
   { "chain",       WEAPON_CHAIN,   &gsn_whip,              99, 2, 42 , DAM_SLASH },
   { "tail",        WEAPON_TAIL,    &gsn_whip,              99, 2, 38 , DAM_SLASH },

   { NULL,			0,	NULL,	0,	0		, 0 }
};


 
/* wiznet table and prototype for future flag setting */
const   struct wiznet_type      wiznet_table    []              =
{
   {    "on",           WIZ_ON,         IM },
   {    "prefix",	WIZ_PREFIX,	IM },
   {    "ticks",        WIZ_TICKS,      IM },
   {    "logins",       WIZ_LOGINS,     IM },
   {    "sites",        WIZ_SITES,      L4 },
   {    "links",        WIZ_LINKS,      L7 },
   {	"newbies",	WIZ_NEWBIE,	IM },
   {	"spam",		WIZ_SPAM,	L5 },
   {	"notes",	WIZ_NOTES,	IM },
   {    "deaths",       WIZ_DEATHS,     IM },
   {    "resets",       WIZ_RESETS,     L4 },
   {    "mobdeaths",    WIZ_MOBDEATHS,  L4 },
   {    "flags",	WIZ_FLAGS,	L5 },
   {	"penalties",	WIZ_PENALTIES,	L5 },
   {	"saccing",	WIZ_SACCING,	L5 },
   {	"levels",	WIZ_LEVELS,	IM },
   {	"load",		WIZ_LOAD,	L2 },
   {	"restore",	WIZ_RESTORE,	L2 },
   {	"snoops",	WIZ_SNOOPS,	L2 },
   {	"switches",	WIZ_SWITCHES,	L2 },
   {	"secure",	WIZ_SECURE,	L1 },
   {    "notrans",	WIZ_NOTRANS,	IM },
   {    "dispvnum",	WIZ_DISPVNUM,	IM },
   {    "debug",	WIZ_DEBUG,	L3 },
	{	"guilds",	WIZ_GUILDS,	L7	},
   {	NULL,		0,		0  }
};

const struct wiznet_type		pnet_table	[]	=
{
	{	"on",			WIZ_ON,		0 },
	{	"logins",		WIZ_LOGINS,	0 },
	{	"links",		WIZ_LINKS,	0 },
	{	"newbies",		WIZ_NEWBIE,	0 },
	{	"notes",		WIZ_NOTES,	0 },
	{	"deaths",		WIZ_DEATHS,	0 },
	{	"levels",		WIZ_LEVELS,	0 },
	{	"guilds",		WIZ_GUILDS,	0 },
	{	NULL,			0,			0 }
};

/* attack table  -- not very organized :( */
const 	struct attack_type	attack_table	[MAX_DAMAGE_MESSAGE]	=
{
	/* name */		/* 1st */	/* 3rd */
    { 	"none",		"hit",		"hits",		-1		},  /*  0 */
    {	"slice",	"slice",	"slices", 	DAM_SLASH	},	
    {   "stab",		"stab",		"stabs",		DAM_PIERCE	},
    {	"slash",	"slash",	"slashes",	DAM_SLASH	},
    {	"whip",		"whip",		"whips",		DAM_SLASH	},
    {   "claw",		"claw",		"claws",		DAM_SLASH	},  /*  5 */
    {	"blast",	"blast",	"blasts",	DAM_BASH	},
    {   "pound",	"pound",	"pounds",	DAM_BASH	},
    {	"crush",	"crush",	"crushes",	DAM_BASH	},
    {   "grep",		"grep",		"greps",		DAM_SLASH	},
    {	"bite",		"bite",		"bites",		DAM_PIERCE	},  /* 10 */
    {   "pierce",	"pierce",	"pierces",	DAM_PIERCE	},
    {   "suction",	"suction", 	"suctions",	DAM_BASH	},
    {	"beating",	"beat",		"beats",	DAM_BASH	},
    {   "digestion","digest",	"digests",	DAM_ACID	},
    {	"charge",	"charge",	"charges",	DAM_BASH	},  /* 15 */
    { 	"slap",		"slap",		"slaps",		DAM_BASH	},
    {	"punch",	"punch",	"punches",	DAM_BASH	},
    {	"wrath",	"wrath",	"wraths",	DAM_LIGHTNING	},
    {	"magic",	"magick",	"magicks",	DAM_LIGHTNING	},
    {   "divine",	"power",	"powers",	DAM_SPIRIT	},  /* 20 */
    {	"cleave",	"cleave",	"cleaves",	DAM_SLASH	},
    {	"scratch",	"scratch",	"scratches",	DAM_PIERCE	},
    {   "peck",		"peck",		"pecks",		DAM_PIERCE	},
    {   "peckb",	"peck",		"pecks",		DAM_BASH	},
    {   "chop",		"chop",		"chops",		DAM_SLASH	},  /* 25 */
    {   "sting",	"sting",	"stings",	DAM_PIERCE	},
    {   "smash",	"smash",	"smashes",	DAM_BASH	},
    {   "shbite",	"bite",		"bites",DAM_LIGHTNING	},
    {	"flbite",	"bite",		"bites", DAM_FIRE	},
    {	"frbite",	"bite",		"bites", DAM_COLD	},  /* 30 */
    {	"acbite",	"bite",		"bites", 	DAM_ACID	},
    {	"chomp",	"chomp",	"chomps",	DAM_PIERCE	},
    {  	"drain",	"drain",	"drains",	DAM_SPIRIT	},
    {   "thrust",	"thrust",	"thrusts",	DAM_PIERCE	},
    {   "slime",	"slime",	"slimes",	DAM_ACID	},
    {	"shock",	"shock",	"shocks",	DAM_LIGHTNING	},
    {   "thwack",	"thwack",	"thwacks",	DAM_BASH	},
    {   "flame",	"flame",	"flames",	DAM_FIRE	},
	{	"burn",		"burn",		"burns",	DAM_FIRE	},
	{	"scorch",	"scorch",	"scorches",	DAM_FIRE	},
    {   "chill",	"chill",	"chills",	DAM_COLD	},
	{	"freeze",	"freeze",	"freezes",	DAM_COLD	},
	{	"quake",	"quake",	"quakes",	DAM_EARTH	},
	{	"trample",	"trample",	"tramples",	DAM_EARTH	},
	{	"torrent",	"torrent",	"torrents",	DAM_WATER	},
	{	"drown",	"drown",	"drowns",	DAM_WATER	},
	{	"suffocate","suffocate","suffocates", DAM_AIR	},
	{	"gore",		"gore",		"gores",	DAM_PIERCE },
    {   "cut",      "cut",      "cuts",     DAM_SLASH },
    {   "lash",     "lash",     "lashes",   DAM_SLASH },
    {   "bash",     "bash",     "bashes",   DAM_BASH },
    {   "carve",    "carve",    "carves",   DAM_SLASH },
    {   "gash",     "gash",     "gashes",   DAM_SLASH },
    {   "hack",     "hack",     "hacks",    DAM_SLASH },
    {   "jab",      "jab",      "jabs",     DAM_PIERCE },
    {   "spear",    "spear",    "spears",   DAM_PIERCE },
    {   "flay",     "flay",     "flays",    DAM_SLASH },
    {   "scourge",  "scourge",  "scourges", DAM_SLASH },
    {   "thrash",   "thrash",   "thrashes", DAM_SLASH },
    {   NULL,		NULL,		0		}
};

/* race table */
const 	struct	race_type	race_table	[]		=
{
/*
    {
	name,		pc_race?,
	act bits,	aff_by bits,	off bits,
	imm,		res,		vuln,
	form,		parts 
    },
*/
    { "unique",		FALSE, 0, 0, 0, 0, 0, 0, 0, 0 },

    { 
		"human",		TRUE, 
		0,		0, 		0,
		0, 		0,		0,
		A|L,	A|B|C|D|E|F|G|H|I|J|K,
		{ 0,0,0,0,  0,0, 0,0,  0,0,  0,0,  0,0,  0,0,0,0 }
    },

    {
		"elf",			TRUE,
		0,		AFF_INFRARED,	0,
		0,		0, 0,
		A|L,	A|B|C|D|E|F|G|H|I|J|K,
		{ 0,0,0,0,   10,-10,  0,0,  33,0,  0,0,  0,0,  0,0,0,0 }
    },

    {
		"dwarf",		TRUE,
		0,		AFF_INFRARED,	0,
		0,		0, 0,
		A|L,	A|B|C|D|E|F|G|H|I|J|K,
		{ 0,0,0,0,  0,0,  25,25,  0,0,  0,0,  0,-25,10,  0,0,10 }
    },

    {
		"gnome",		TRUE,
		0,		AFF_INFRARED,		0,
		0,		0,		0,
		A|L,	A|B|C|D|E|F|G|H|I|J|K,
		{ 0,0,10,0,  0,0,  10,10,   10,0,  0,0,  -10,-10,0,  0,0,-10 }
    },

    {
		"half-elf",		TRUE,
		0,		AFF_INFRARED,		0,
		0,		0,		0,
		A|L,	A|B|C|D|E|F|G|H|I|J|K,
		{ 0,0,0,0,  0,0,  0,0,  10,0,  0,0,  0,0,0,  0,0,0 }
    },

    {
		"half-orc",		TRUE,
		0,		AFF_INFRARED,		0,
		0,		0,		0,
		A|L,	A|B|C|D|E|F|G|H|I|J|K,
		{ 0,0,0,0,  -10,10,  10,10,  -10,0,  0,0,  0,0,0,  0,0,10 }
    },

	{
		"halfling",	TRUE,
		0,	AFF_INFRARED,		0,
		0,	0, 0,
		A|L,	A|B|C|D|E|F|G|H||I|J|K,
		{ 0,0,10,0,  0,0,  0,0,  10,0,  0,0,  0,0,0, 0,0,10 }
	},

	{
		"generic undead", FALSE,
		0, AFF_DARK_VISION, 0,
		0, 0, 0,
		I|P,	0,
		{ -25,25,0,0,  -10,33,  33,33,  100,0,  0,-33,  33,0,100, 0,0,0 }
	},

	{
		"skeleton",	FALSE,
		0,	AFF_DARK_VISION, 0,
		0, 0, 0,
		I|D|P,	0,
		{ -25,25,0,0,  -10,33,  33,33,  100,0,  0,-33,  33,0,100,  0,33,-33 }
	},

	{
		"zombie", FALSE,
		0,	AFF_DARK_VISION, 0,
		0, 0, 0,
		A|B|I|P,	A|B|C|D|E|F|G|H|I|J|K,
		{ -25,25,0,0,  -10,33,  33,33,  100,0,  0,-33,  33,0,50, 0,-25,0 }
	},

	{
		"ghost", FALSE,
		0, AFF_DARK_VISION, 0,
		0, 0, 0,
		D|I|J|P, 0,
		{ -25,25,0,0,  -10,100,  100,100,  100,0,  0,-33,  40,0,100, 40,40,25 }
	},

    {
		"bat",			FALSE,
		0,		AFF_FLYING|AFF_DARK_VISION,	OFF_DODGE,
		0,		0,		0,
		A|K,		A|C|D|E|F|H|J|K|P,
		{ -10,0,0,25, -25,25, 0,0,  0,0,  0,0,  0,0,0,  0,25,-25 }
    },

    {
		"bear",			FALSE,
		0,		0,		OFF_DISARM|OFF_BERSERK,
		0,		0,	0,
		A|E|K,		A|B|C|D|E|F|H|J|K|U|V,
		{ -25,40,0,0,  0,0,  25,25,  0,0,  0,0,  0,10,0,  -25,0,10 }
    },

	{
		"crustacean",	FALSE,
		0,	0,	0,
		0,	0,  0,
		A|K|P,	A|C|D|E|F|K|N,
		{ 0,-25,0,0,  0,0,  0,0,  0,0,  -33,0,  0,40,25,  10,-10,10 }
	},

	{
		"fish",	FALSE,
		0,	0, OFF_DODGE,
		0,	0, 0,
		A|K|P, A|D|E|F|K|O|Q|X,
		{ 40,-25,0,0,  0,0,  0,0,  0,0,  -40,0,  0,100,0,  0,-25,10 }
	},

	{
		"amphibian",	FALSE,
		0,	0,	OFF_DODGE,
		0,	0, 0,
		A|E|K|P, A|C|D|E|F|H|K,
		{ 0,-33,0,0,  0,0,  0,0, 0,0,  -10,0,  0,40,0,  0,-10,-10 }
	},

	{
		"plant",	FALSE,
		0,	AFF_DARK_VISION,	0,
		0,	0, 0,
		A|M|P,	A|D|F,
		{ -25,25,33,0,  0,0,  0,0,  0,0,  0,0,  0,0,25,  -25,10,25 }
	},

	{
		"treant", 	FALSE,
		0,	AFF_DARK_VISION,	0,
		0,	0, 0,
		A|M|P,	A|D|F,
		{ -25,25,33,0,  0,0,  0,0,  0,0,  0,0,  0,0,25,  -25,10,25 }
	},

	{
		"slime",	FALSE,
		0,	0,	0,
		0,	0, 0,
		A|B|D|P,	0,
		{ -40,0,40,0,  0,0,  40,40,  0,0,  0,0,  0,40,50,  33,40,25 }
	},

    {
		"big cat",			FALSE,
		0,		AFF_DARK_VISION,	OFF_DODGE,
		0,		0,		0,
		A|E|K,		A|C|D|E|F|H|J|K|Q|U|V,
		{ -10,0,0,0,  0,10,  0,0,  0,0,  0,0,  0,-10,0,  -25,0,10 }
    },

    {
		"insect",		FALSE,
		0,		AFF_DARK_VISION,	0,
		0,	0, 0,
 		A|B,		A|C|K	,
		{ -10,0,0,25,  0,0,  0,0,  0,0,  0,0,  0,-25,25,  25,33,-25 }
    },

	{
		"giant insect",	FALSE,
		0,	AFF_DARK_VISION,	0,
		0,	0, 0,	
		A|B,	A|C|K,
		{ -10,0,0,10, 0,0,  0,0,  0,0,  0,0,  0,0,25,  33,-25,0 }
	},

	{
		"spider",	FALSE,
		0,		AFF_DARK_VISION,	0,
		0,		0, 0,
		A|B,		A|C,
		{ -10,-10,0,0,  0,0,  33,0,  0,0,  0,0,  0,-25,10,  10,0,-25 }
	},

	{
		"giant spider",	FALSE,
		0, AFF_DARK_VISION, 0,
		0, 0, 0,
		A|B, A|C,
		{ -10,-10,0,0, 0,0,  33,0,  0,0,  0,0,  0,0,10,  0,-10,10 }
	},

	{
		"generic humanoid",	FALSE,
		0,		0,	OFF_DODGE,
		0,		0,	0,
		A|L,	A|B|C|D|E|F|G|H|I|J|K,
		{ 0,0,0,0,  0,0,  0,0,  0,0,  0,0,  0,0,0,  0,0,0 }
	},

    {
		"dog",			FALSE,
		0,		0,		0,
		0,		0,		0,
		A|E|K,		A|C|D|E|F|H|J|K|U|V,
		{ -10,25,0,0,  0,0,  0,10,  0,0,  0,0,  0,0,0,  -25,0,10 },
    },

	{
		"furry mammal",		FALSE,
		0,		0,		0,		
		0,		0,		0,	
		A|E|K,		A|C|D|E|F|H|J|K|U|V,
		{ -10,10,0,0,  0,0,  0,0,  0,0,  0,0,  0,0,0,  -25,0,10 },
	},

    { 	
		"dragon", 		FALSE, 
		0, 			AFF_INFRARED|AFF_FLYING,	0,
		0,	0, 0,
		A|C|E,		A|C|D|E|F|G|H|I|J|K|P|Q|U|V|X,
		{ 33,-33,0,25,  0,0,  25,25,  40,0,  0,0,  0,25,25,  40,10,40 },
    },

	{
		"cervine",		FALSE,
		0, 0, 0,
		0, 0, 0,
		A|E|K,	A|C|D|E|F|J|K|Q,
		{ 0,0,0,0,  0,0,  10,10,  0,0,  0,0,  0,10,0,  -25,0,10 },
	},

	{	
		"horse",		FALSE,
		0,	0,	0,
		0,	0,	0,
		A|E|K,	A|C|D|E|F|J|K|Q,
		{ 0,0,0,0,  0,0,  10,10,  0,0,  0,0,  0,10,0,  -25,0,10 },
	},

    {
		"goblin",		FALSE,
		0,		AFF_INFRARED,	0,
		0,	0,	0,
		A|B|E|L,	A|B|C|D|E|F|G|H|I|J|K,
		{ 0,0,0,0, -33,33,  10,10,  0,0,  0,0,  0,0,0,  0,0,0 },
    },
    
    {
		"reptile",		FALSE,
		0,		0,		0,
		0,		0,0,
		A|E|K,	A|C|D|E|F|H|K|Q|V,
		{ 25,-33,0,0,  0,0,  25,0,  0,0,  0,0,  0,0,0, 10,-25,10 }
    },

    {
		"orc",			FALSE,
		0,		AFF_INFRARED,	0,
		0,		0,	0,
		A|E|L,	A|B|C|D|E|F|G|H|I|J|K,
		{ 0,0,0,0,  -25,25,  0,25,  0,0,  0,0,  0,0,0,  0,0,0 },
	
    },

    {
		"pig",			FALSE,
		0,		0,		0,
		0,		0,		0,
		A|E|K,	 	A|C|D|E|F|H|J|K,
		{ 0,0,0,0,  0,0,  0,25, -10,0,  0,0,  0,0,0,  -25,0,10 },
    },	

    {
		"rodent",		FALSE,
		0,		0,		OFF_DODGE,
		0,		0,		0,
		A|E|K,		A|C|D|E|F|H|J|K,
		{ -25,0,0,0,  -10,25,  0,25,  0,0,  0,0,  0,-25,0,  -25,25,0 }
    },
    
    {
		"bird",		FALSE,
		0,		AFF_FLYING,		OFF_DODGE,
		0,		0,		0,
		A|K,		A|C|D|E|F|H|K|P,
		{ 0,-25,0,25,  0,0,  0,0, 0,0,  0,0, 0,10,0,  0,0,0 }
    },

    {
		"troll",		FALSE,
		0,		AFF_REGENERATION|AFF_INFRARED,OFF_BERSERK,
 		0,	0,	0,
		A|B|E|L,		A|B|C|D|E|F|G|H|I|J|K|U|V,
		{ -33,25,25,25,  -25,0,  33,33,  0,-33, 0,0,  0,25,0,  25,33,40 }
		
    },

    {
		"wolf",			FALSE,
		0,		AFF_DARK_VISION,	OFF_DODGE,
		0,		0,		0,	
		A|E|K,		A|C|D|E|F|J|K|Q|V,
		{ -25,33,0,0,  0,0,  0,0,  0,0,  0,0,  0,0,0,  -25,0,10 }
    },

	{
		"gnoll", FALSE,
		0, AFF_DARK_VISION, OFF_DODGE,
		0, 0, 0,
		A|E|L,    A|B|C|D|E|F|G|H|I|J|K,
		{ -10,0,0,0,  -10,10,  25,25,  -25,0,  0,0,  0,0,0,  -25,0,10 }
	},

	{
		"kobold", FALSE,
		0,	AFF_DARK_VISION,	OFF_DODGE,
		0,	0,	0,
		A|B|L,	A|B|C|D|E|F|G|H|I|J|K,
		{ 0,0,0,0, -25,25, 33,33, 0,0,  0,0,  0,0,0,  0,-25,0 }
	},

	{
		"minotaur", FALSE,
		0, 0, OFF_DODGE|OFF_BASH,
		0, 0, 0,
		A|L,  A|C|D|E|F|G|H|I|J|K,
		{ 0,0,25,0,  0,0,  25,25,  0,0,  0,0,  0,0,0,  0,0,0 }
	},

	{
		"snake", FALSE,
		0, 0, 0,
		0, 0, 0,
		A|B|E|K, A|D|E|F|K|L|Q|V|X,
		{ 0,-25,25,0,  0,0,  25,0,  0,-25,  0,0,0,  0,0,0 }
	},

	{
		"lizard",	FALSE,
		0,0,0,
		0,0,0,
		A|E|K,  A|B|C|D|E|F|G|H|K|L|Q|U|V|X,
		{ 0,-25,0,0,  0,0,  0,0,  0,0,  0,0,  0,0,0,0 }
	},

	{
		"scorpion",	FALSE,
		0,0,0,
		0,0,0,
		A|B|K,  A|B|C|D|E|F|H|K|L|Q|U,
		{ 33,-33,0,0,  0,0,  25,0,  0,-33,  0,0,0,  0,-25,0 }
	},

	{
		"otterman", FALSE,
		0,0,0,
		0,0,0,
		A|E|L,  A|B|C|D|E|F|G|H|I|J|H|K|L,
		{ -25,0,0,0,  0,0,  0,0,  0,0,  0,0,  0,33,0,  -25,0,25 }
	},

	{
		"celestial",	FALSE,
		0,0,0,
		0,0,0,
		F|O|P,  A|B|C|D|E|F|G|H|I|J|K,
		{ -25,25,0,0,  33,-33,  0,0,  0,0,  0,-25,  0,0,0,  0,0,0 }
	},

	{
		"demonic",	FALSE,
		0,0,0,
		0,0,0,
		G|O|P,  A|B|C|D|E|F|G|H|I|J|K,
		{ 25,-25,0,0,  -33,33,  0,0,  0,0,  0,-25,  0,0,0,  0,0,0 }
	},

	{
		"golem", FALSE,
		0,0,0,
		0,0,0,
		C|H,  A|B|C|G|H|I,
		{ 10,10,10,10,  10,10,  100,100,  100,-50, 0,-25, 0,0,0,  0,0,0 }
	},

    {   
        "elemental", FALSE,
        0,0,0,
        0,0,0,
        C|N|O, 0,
        { 0,0,0,0,  0,0,  25,25, 0,0,  0,0,  0,0,0,  0,0,0 }
    },

    {
        "primate",  FALSE,
        0,0,0,0,0,0,
		A|L,	A|B|C|D|E|F|G|H|I|J|K,
        { -10,10,0,0,  0,0,  0,0,  0,0,  0,0,  0,0,0,  -25,0,10 },
    },

    {
		"unique",		FALSE,
		0,		0,		0,
		0,		0,		0,		
		0,		0
    },

    {
	NULL, 0, 0, 0, 0, 0, 0
    }
};

#define TIER(x)		x

const	struct	pc_race_type	pc_race_table	[]	=
{
    { "null race", "",  { 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0 },
      { "" }, { 13, 13, 13, 13, 13 }, { 18, 18, 18, 18, 18 }, 0, NULL  },
 
/*
    {
	"race name", 	short name, 	points,	{ class multipliers },
	{ bonus skills },
	{ base stats },		{ max stats },		size 
    },
*/
    {
		"human",	" Human  ",	
 		{ 1,1,1,1,  1,1,0,1,  1,1,1,1,  1,0,1,1 },
		{ "" },
		{  80, 80, 80, 80, 80, 80 },
		{ 180,180,180,180,180,180 },	SIZE_MEDIUM, &grn_human, TIER(1)
    },

    { 	
		"elf",		"  Elf   ",
 		{ 1,1,1,1,  1,1,0,0,   1,1,0,0,  1,0,0,1 },
		{ "" },
		{  70,100, 60, 90, 80, 80 },
        { 180,190,170,180,180,180 },  SIZE_MEDIUM, &grn_elf, TIER(1)
    },

    {
		"dwarf",	" Dwarf  ",
 		{ 0,0,0,0,  1,0,0,1,   1,0,0,0,  1,1,0,0 },
		{ "" },
		{  90, 70,100, 80, 80, 60 },
        { 180,180,190,180,180,170 },
		SIZE_MEDIUM, &grn_dwarf, TIER(1)
    },

    {
		"gnome",	" Gnome  ",
  		{ 0,0,0,1,  1,1,1,0,  1,0,0,0,  1,0,0,0 },
		{ "" },
		{  65, 85, 90, 80, 80, 80 },
       	{ 180,180,180,180,180,180 },
 		SIZE_SMALL, &grn_gnome, TIER(1)
    },

    {
		"half-elf",	"Half-Elf",
 		{ 1,1,1,1,  1,1,0,1,  1,1,1,0,  1,0,1,1 },
		{ "" },
		{  75, 90, 70, 85, 80, 80 },
		{ 180,180,180,180,180,180 },
		SIZE_MEDIUM, &grn_half_orc, TIER(1)
    },

    {
		"half-orc",	"Half-Orc",
		{ 0,0,0,0,  0,0,1,1,  1,0,1,0,  1,1,0,0 },
		{ "" },
		{ 100, 80,100, 60, 80, 60 },
        { 190,180,190,170,180,170 },
		SIZE_LARGE,&grn_half_orc , TIER(1)
    },

	{
		"halfling", "Halfling",	
		{ 0,0,0,0,  1,1,0,0,  1,1,0,0,  1,0,0,0 },
		{ "" },
    	{  65,100, 80, 80, 75, 80 },
        { 160,190,180,180,180,180 },
		SIZE_SMALL, &grn_halfling, TIER(1)
	}
};

/* MaSoWaAr ClDrShCr ThBaAsMo FiBaPaRa */
const struct pc_subrace_type subrace_table [] =
{
	{ "Unkown",	"Unknown", 0,				{ 0, 0, 0, 0, 0, 0 }, },

	{ "Ancois", "  Ancois  ", 	&grn_human, 	{ 80,80,80,80,80,80 },
		{ 1,1,1,1,  1,1,0,1,  1,1,1,0,  1,0,1,1 }, 
		110, &gsn_ancois, NULL, NULL, SUBRACE_COMMON, "taihr", { "" },
	},

	{ "Kevjordhur", "Kevjordhur", &grn_human,		{ 85,80,90,75,80,70 },
		{ 0,0,0,0,  0,1,1,0,  1,1,1,0,  1,1,0,1 }, 
		100, &gsn_kevjordhur, &na_kevjordhur, &la_kevjordhur,
        SUBRACE_UNCOMMON, "kajeda", { "" },
	},

	{ "Tayana", "  Tayana  ",		&grn_human,		{ 80,90,85,80,85,80 },
		{ 0,0,0,0,  1,0,0,1,  1,0,1,1,  1,0,0,1 }, 
		90, &gsn_tayana, &na_tayana, &la_tayana, 
        SUBRACE_RARE, "hijanisha", { "" },
	},

	{ "Ashinth", " Ashinth  ",	&grn_elf,		{ 70,90,70,90,80,80 },
		{ 1,0,1,1,  1,1,0,0,  1,1,0,0,  0,0,0,0 },
		85, &gsn_ashinth, &na_ashinth, &la_ashinth, 
        SUBRACE_UNCOMMON, "danaes", { "" },
	},

	{ "Elashod", " Elashod  ",	&grn_elf,		{ 80,90,70,80,80,80 },
		{ 1,0,1,1,  1,1,0,0,  1,1,0,0,  1,0,0,1 }, 
		90, &gsn_elashod, NULL, NULL, 
        SUBRACE_COMMON, "jaboc", { "" },
	},
/* MaSoWaAr ClDrShCr ThBaAsMo FiBaPaRa */
	{
		"Ku-tath", " Ku-tath  ",	&grn_elf,		{ 85,85,85,85,80,60 },
		{ 0,1,1,0,  0,0,1,0,  1,0,1,0,  1,1,0,0 }, 
		80, &gsn_kutath, &na_kutath, &la_kutath,
        SUBRACE_RARE, "chaslith", { "regeneration 1" }
	},

	{ 
		"Abrainon", " Abrainon ",	&grn_dwarf, { 90,80,100,70,80,60 },
		{ 0,0,0,0,  0,0,1,0,  1,0,1,0,  0,1,0,0 },
		90, &gsn_abrainon, NULL, NULL,
        SUBRACE_COMMON, "druim cett", { "" },
	},

	{ 
		"Brombachol", "Brombachol",	&grn_dwarf, { 85,80,95,80,80,70 },
		{ 0,0,0,0,  1,0,0,1,  1,1,0,0,  1,0,0,0 },
		90, &gsn_brombachol, &na_brombachol, &la_brombachol,
        SUBRACE_UNCOMMON, "druim cett", { "craftsmanship 1" }
	},

	{ 
		"Gnome", "  Gnome   ",	NULL, { 60,90,80,80,90,80 },
		{ 0,0,0,1,  0,1,0,0,  1,1,0,0,  1,0,0,0 },
		105, &gsn_gnome, &na_gnome, &la_gnome,
        SUBRACE_UNCOMMON, "sedlashek", { "meditation 1" }
	},
/* MaSoWaAr ClDrShCr ThBaAsMo FiBaPaRa */
	{
		"Halfling", " Halfling ",	NULL, { 60,100,80,80,80,80 },
		{ 0,0,0,0,  0,1,0,0,  1,1,0,0,  1,0,0,0 },
		110, &gsn_halfling, &na_halfling, &la_halfling,
        SUBRACE_UNCOMMON, "taihr", { "elusive 1" }
	},

	{
		"Half-Elf", " Half-Elf ", NULL, { 80,85,75,80,80,80 },
		{ 1,1,1,1,  1,1,0,1,  1,1,1,0,  1,0,1,1 },
		100, &gsn_halfelf, NULL, NULL,
        SUBRACE_COMMON, "jaboc", { "" }
	},

	{ 
		"Half-Orc",	" Half-Orc ", NULL, { 100,80,100,60,80,60 },
		{ 0,0,0,0,  0,0,1,1,  1,0,1,0,  0,1,0,0 },
		80, &gsn_halforc, &na_halforc, &la_halforc,
        SUBRACE_RARE, "noxulitul", { "" }
	},

	{
		NULL, NULL, NULL, { 0,0,0,0,0,0 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
		0, NULL, NULL, NULL
	}
};


/*
 * Class table.
 */
#define THACO(x)	x
#define HITADJ(x)	x

const	struct	class_type	class_table	[MAX_CLASS]	=
{
    {
		"mage", "Mage",  STAT_INT, STAT_INT,  
		7, 10, 100,
		"wizard basics", "arcane default", 2, ARCANE,
		{ VNUM_MAGE_SPELLBOOK, VNUM_NEWBIE_ROBES, 14803, 14802, 14801, 14800 }, 
		&csn_mage, 0, HITADJ(1.0), 2,
		"Standard spellcasting class, variety of spells", CHALLENGING, 36
    },

    {
        "necromancer", "Necr",  STAT_INT, STAT_DEX,  
        7, 10, 100,
        "sorcerer basics", "arcane default", 2, ARCANE,
        { VNUM_SORCERER_SPELLBOOK, VNUM_NEWBIE_ROBES, 15108, 15106, 15103, 15102 }, 
		&csn_specialist, 0, HITADJ(1.0), 2,
		"Relies on damage-over-time and undead followers", CHALLENGING, 36
    },

    {
        "warlock", "Warl",  STAT_INT, STAT_CON,  
        9, 12, 100,
        "warlock basics", "arcane default", 3, ARCANE,
		{ VNUM_WARLOCK_SPELLBOOK, VNUM_NEWBIE_ROBES, 15003, 15002, 15001, 15000 }, 
		&csn_warlock, B, HITADJ(1.2), 2,
		"War mage, offense-oriented, can wear some armor", CHALLENGING, 36
    },

    {
        "enchanter", "Ench",  STAT_INT, STAT_WIS,  
        5,  9, 100,
        "arcanist basics", "arcane default", 2, ARCANE,
        { VNUM_ARCANIST_SPELLBOOK, VNUM_NEWBIE_ROBES, 14903, 14902, 14901, 14900 }, 
		&csn_arcanist, 0, HITADJ(0.8), 2,
		"Defensive mage, focus on enhancement and enchantment spells", CHALLENGING, 36
    },

    {
		"cleric", "Cler",  STAT_WIS, STAT_WIS,  
		10, 14, 100,
		"cleric basics", "divine default",  3, DIVINE,
		{ 1211, 15200, 15201, 15202, 15203 },
		&csn_cleric, B|C, HITADJ(1.4), 2,
		"Generic healer, variety of divine spells, fair combat skills", MODERATE, 33
    },

    {
        "druid", "Drui",  STAT_WIS, STAT_INT,
        8, 10, 100,
        "druid basics", "divine default",  2, DIVINE,
		{ 1211, 320, 321, 322, 323 },
		&csn_druid, B|C, HITADJ(1.3), 2,
		"Nature-oriented healer, access to transportation spells", MODERATE, 27
    },

    {
        "shaman", "Sham",  STAT_WIS, STAT_CON,
        11, 15, 100,
        "shaman basics", "divine default",  3, DIVINE,
		{ 1211, 340, 341, 342, 343 },
		&csn_shaman, B|C, HITADJ(1.4), 2,
		"Tribal healer, relies on damage-over-time, good enhancements", MODERATE, 32
    },

    {
        "crusader", "Crus", STAT_WIS, STAT_STR,
        15, 17, 90,
        "crusader basics", "divine default", 4, DIVINE,
        { 1211, 15301, 15302, 15303, 15304 },
		&csn_crusader, B|C, HITADJ(1.6), 2 ,
		"Offensive healer, narrow spell range but good in melee", MODERATE, 34
		
    },

    {
		"thief", "Thie",  STAT_DEX, STAT_DEX,  
        13, 19, FALSE,
		"thief basics", "rogue default",  3, STEALTH,
        { VNUM_NEWBIE_JERKIN_LEATHER, VNUM_NEWBIE_BOOTS_LEATHER }, 
		&csn_thief, B, HITADJ(1.6), 2,
		"Basic thief, variety of skills, can backstab", CHALLENGING, 26
    },

    {
        "bard", "Bard",   STAT_DEX, STAT_CHA,  
        10, 18, 100,
        "bard basics", "rogue default",  3, STEALTH,
        { VNUM_NEWBIE_JERKIN_LEATHER, VNUM_NEWBIE_BOOTS_LEATHER }, 
		&csn_bard, B, HITADJ(1.6), 2 ,
		"Roguish class uses music for magic affects, group-oriented", CHALLENGING, 28
    },


    {
        "assassin", "Assa",  STAT_DEX, STAT_STR,  
        10, 16, FALSE,
        "assassin basics", "rogue default", 3, STEALTH,
        { VNUM_NEWBIE_JERKIN_LEATHER, VNUM_NEWBIE_BOOTS_LEATHER }, 
		&csn_assassin, B, HITADJ(1.8), 2,
		"Deadly class, combines backstab with lethal damage enhancement", CHALLENGING, 26
    },


    {
        "monk",  "Monk",  STAT_DEX, STAT_WIS,  
        15, 20, FALSE,
        "monk basics", "rogue default", 4, STEALTH,
        { VNUM_NEWBIE_JERKIN_LEATHER, VNUM_NEWBIE_BOOTS_LEATHER }, 
		&csn_monk, A|B, HITADJ(2.0), 2,
		"Weaponless, armorless, martial artist, deadly one-man army", MODERATE, 36
    },


    {
		"fighter", "Figh",  STAT_STR, STAT_STR,  
		18, 25, FALSE,
		"fighter basics", "melee default",  4, MELEE,
		{ VNUM_NEWBIE_JERKIN_CHAIN, VNUM_NEWBIE_BOOTS_LEATHER }, 
		&csn_fighter, A|B, HITADJ(2.1), 2,
		"Basic foot soldier, great weapon and armor selection", EASY, 29
    },

    {
        "barbarian", "Barb",  STAT_STR, STAT_CON,
        20, 30, FALSE,
        "barbarian basics", "melee default", 5, MELEE,
		{ VNUM_NEWBIE_JERKIN_CHAIN, VNUM_NEWBIE_BOOTS_LEATHER }, 
		&csn_barbarian, A|B, HITADJ(2.4), 2,
		"Savage warrior, uses berserker frenzy to break heads", EASY, 30
    },

    {
        "paladin", "Pala",  STAT_STR,STAT_WIS,  
        15, 22, 50,
        "paladin basics", "melee default",  4, MELEE,
		{ VNUM_NEWBIE_JERKIN_CHAIN, VNUM_NEWBIE_BOOTS_LEATHER }, 
		&csn_paladin, A|B|C, HITADJ(2.0), 2,
		"Holy warrior, has special powers and limited spellcasting", EASY, 29
	 },

    {
        "ranger", "Rang",  STAT_STR, STAT_DEX,  
        17, 24, FALSE,
        "ranger basics", "melee default",  4, MELEE,
		{ VNUM_NEWBIE_JERKIN_CHAIN, VNUM_NEWBIE_BOOTS_LEATHER }, 
		&csn_ranger, A|B, HITADJ(2.1), 2,
		"Light infantry, good with bows, has some thief skills", EASY, 29
    }
};




/*
 * Liquid properties.
 * Used in world.obj.
 */
const	struct	liq_type	liq_table	[]	=
{
/*    name			color	proof, full, thirst, food, ssize */
    { "water",			"clear",	{   0, 1, 10, 0, 16 }	},
    { "beer",			"amber",	{  12, 1,  8, 1, 12 }	},
    { "red wine",		"burgundy",	{  30, 1,  8, 1,  5 }	},
    { "ale",			"brown",	{  15, 1,  8, 1, 12 }	},
    { "dark ale",		"dark",		{  16, 1,  8, 1, 12 }	},

    { "whisky",			"golden",	{ 120, 1,  5, 0,  2 }	},
    { "lemonade",		"pink",		{   0, 1,  9, 2, 12 }	},
    { "firebreather",		"boiling",	{ 190, 0,  4, 0,  2 }	},
    { "local specialty",	"clear",	{ 151, 1,  3, 0,  2 }	},
    { "slime mold juice",	"green",	{   0, 2, -8, 1,  2 }	},

    { "milk",			"white",	{   0, 2,  9, 3, 12 }	},
    { "tea",			"tan",		{   0, 1,  8, 0,  6 }	},
    { "coffee",			"black",	{   0, 1,  8, 0,  6 }	},
    { "blood",			"red",		{   0, 2, -1, 2,  6 }	},
    { "salt water",		"clear",	{   0, 1, -2, 0,  1 }	},

    { "coke",			"brown",	{   0, 2,  9, 2, 12 }	}, 
    { "root beer",		"brown",	{   0, 2,  9, 2, 12 }   },
    { "elvish wine",		"green",	{  35, 2,  8, 1,  5 }   },
    { "white wine",		"golden",	{  28, 1,  8, 1,  5 }   },
    { "champagne",		"golden",	{  32, 1,  8, 1,  5 }   },

    { "mead",			"honey-colored",{  34, 2,  8, 2, 12 }   },
    { "rose wine",		"pink",		{  26, 1,  8, 1,  5 }	},
    { "benedictine wine",	"burgundy",	{  40, 1,  8, 1,  5 }   },
    { "vodka",			"clear",	{ 130, 1,  5, 0,  2 }   },
    { "cranberry juice",	"red",		{   0, 1,  9, 2, 12 }	},

    { "orange juice",		"orange",	{   0, 2,  9, 3, 12 }   }, 
    { "absinthe",		"green",	{ 200, 1,  4, 0,  2 }	},
    { "brandy",			"golden",	{  80, 1,  5, 0,  4 }	},
    { "aquavit",		"clear",	{ 140, 1,  5, 0,  2 }	},
    { "schnapps",		"clear",	{  90, 1,  5, 0,  2 }   },

    { "icewine",		"purple",	{  50, 2,  6, 1,  5 }	},
    { "amontillado",		"burgundy",	{  35, 2,  8, 1,  5 }	},
    { "sherry",			"red",		{  38, 2,  7, 1,  5 }   },	
    { "framboise",		"red",		{  50, 1,  7, 1,  5 }   },
    { "rum",			"amber",	{ 151, 1,  4, 0,  2 }	},

    { "cordial",		"clear",	{ 100, 1,  5, 0,  2 }   },
    { NULL,			NULL,		{   0, 0,  0, 0,  0 }	}
};

const	struct	prof_type	prof_table	[MAX_PROFICIENCY]	=
{
    {
		"alertness",
		{  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
		{  6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6 }, 
		&gpn_alertness, NULL, 75 
	},

	{
		"bestiary",
		{	1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
		{   2,2,2,2,  2,2,2,2,  2,2,2,2,  2,2,2,2 },
		&gpn_bestiary, NULL, 75
	},

    {
        "safe fall",
        { 0,0,0,0,  0,0,0,0,  14,0,0,14,  0,0,0,0 },
        { 0,0,0,0,  0,0,0,0,  1,0,0,1,    0,0,0,0 },
        &gsn_safe_fall, NULL, 75
    },

    {
        "climb",
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        { 4,4,4,4,  3,3,3,3,  2,2,2,2,  3,3,3,3 },
        &gsn_climb, NULL, 75
    },

    {
		"combat casting",
		{  1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0 },
		{  4, 4, 4, 4, 5, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0 },
		&gpn_combat_casting, NULL, 75
    },

	{
		"endurance",
		{ 0,0,0,0,  0,0,0,0,  20,20,20,20,  20,20,20,20 },
		{ 0,0,0,0,  0,0,0,0,   6, 6, 6, 6,   4, 4, 4, 4 },
		&gpn_endurance, NULL, 75
	},

	{
		"quick casting",
		{ 1,1,1,1,  0,0,0,0,   0,0,0,0,   0,0,0,0 },
		{ 5,5,5,5,  0,0,0,0,   0,0,0,0,   0,0,0,0 },
		NULL, NULL, 75
	},

	{
		"silent casting",
		{ 1,1,1,1,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
		{ 6,6,6,6,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
		&gpn_silent_casting, NULL, 75
	},

	{
		"critical casting",
		{ 20,20,20,20,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
		{ 5,5,5,5,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
		&gpn_critical_casting, NULL, 75
	},

	{
		"concentration",
		{ 20,20,20,20,  20,20,20,20,  0,20,0,0,  0,0,20,0 },
		{  6, 6, 6, 6,   6, 6, 6, 6,  0, 6,0,0,  0,0, 6,0 },
		&gpn_concentration, NULL, 75
	},

/*
  	{
		"guard",
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  5,5,5,5 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  5,5,5,5 },
		&gpn_guard, NULL, 100
	},
*/

	{
		"enhanced damage",
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,   5, 0, 5, 5 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,   4, 0, 4, 4 },
		&gpn_enhanced_damage, NULL, 150
	},

	{
		"enhanced critical",
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  10,0,0,0, },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,   5,0,0,0 },
		&gpn_enhanced_critical, NULL, 150
	},

    {
        "superior critical",
        { 0,0,0,0,  0,0,0,0,  0,0,0,0,  15,0,0,0 },
        { 0,0,0,0,  0,0,0,0,  0,0,0,0,   5,0,0,0 },
        &gpn_superior_critical, NULL, 150
    },

    {
        "savagery",
        { 0,0,0,0,  0,0,0,0,  0,0,0,0,  0,5,0,0 },
        { 0,0,0,0,  0,0,0,0,  0,0,0,0,  0,5,0,0 },
        &gpn_savagery, NULL, 150
    },
	
    {
		"improved critical",
		{  0, 0, 0, 0,  30,30,30,30,   1,25,25,25,  20,20,20,20 },
		{  0, 0, 0, 0,   7, 7, 7, 7,   6, 6, 6, 6,   5, 5, 5, 5 },
		&gpn_improved_critical, NULL, 150
    },

    {
        "appraise",
        { 15,15,15,15,  15,15,15,15,  7,15,15,15,  15,15,15,15 },
        { 2,2,2,2,  2,2,2,2,  1,1,1,2,  2,2,2,2 },
        &gsn_appraise, NULL, 150
    },

    {
        "case",
        { 0,0,0,0,  0,0,0,0,  10,0,0,0,  0,0,0,0 },
        { 0,0,0,0,  0,0,0,0,   0,0,0,0,  0,0,0,0 },
        &gsn_case, NULL, 150
    },

	{
		"kihap",
		{ 0,0,0,0,  0,0,0,0,  0,0,0,5,  0,0,0,0 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,6,  0,0,0,0 },
		&gpn_monk_skill, NULL, 100
	},

	{
		"tracking",
		{ 0,0,0,0,  0,0,0,0,  0,0,1,0,  0,0,0,1 },
		{ 0,0,0,0,  0,0,0,0,  0,0,2,0,  0,0,0,2 },
		&gpn_tracking, NULL, 150
	},

    {
	"cloth armor",
	{  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
	{  8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8 },
	&gpn_cloth_armor, NULL,	50
    },

    {
	"leather armor",
	{  0, 0,10, 0,   5,5,5,5,  5,5,5,0,  1,1,1,5, },
	{  0, 0, 8, 0,   8,8,8,8,  8,8,8,0,  8,8,8,8, },
	&gpn_leather_armor, &gpn_leather_armor, 100
    },

    {
	"studded leather armor",
	{ 0,0,20,0,   10,10,10,10,  10,10,10,0,   1,5,1,10 },
	{ 0,0,8,0,     8, 8, 8, 8,   8, 8, 8,0,   8,8,8, 8 },
	&gpn_studded_leather_armor, NULL, 100
    },

    {
	"chain mail armor",
	{ 0, 0, 0, 0,   23,0,23,23,   0,23,0,0,   10,16,10,23 },
	{ 0, 0, 0, 0,    8,0, 8, 8,   0,8,0,0,     8, 8, 8, 8 },
	&gpn_chain_mail_armor, NULL, 100
    },

	{
	"scale mail armor",
	{ 0,0,0,0,  16,0,16,16,		23,16,0,0,	5,10,5,16 },
	{ 0,0,0,0,   8,0, 8, 8,		8,8,0,0,	8,8,8,8 },
	&gpn_scale_mail_armor, NULL, 100
	},

    {
	"plate mail armor",
	{ 0, 0, 0, 0,     0,0,0,31,   0,0,0,0,   16, 0,16,0 },
	{ 0, 0, 0, 0,     0,0,0, 8,   0,0,0,0,    8, 0, 8,0 },
	&gpn_plate_mail_armor, NULL, 100
    },

    {
		"buckler shields",
		{ 0,0,0,0, 1,1,1,1,  1,1,1,0,  1,1,1,1 },
        { 0,0,0,0, 4,4,4,4,  4,4,4,0,  4,4,4,4 },
		&gpn_buckler_shields, NULL, 100
    },

    {
		"small shields",
		{ 0,0,0,0, 1,1,1,1,  1,1,1,0,  1,1,1,1 },
		{ 0,0,0,0, 4,4,4,4,  4,4,4,0,  4,4,4,4 },
		&gpn_small_shields, NULL, 100
    },

    {
		"medium shields",
		{ 0,0,0,0,  10,0,10,10,  0,0,0,0,  10,10,10,10 },
		{ 0,0,0,0,   4,0, 4, 4,  0,0,0,0,   4, 4, 4, 4 },
		&gpn_medium_shields, NULL, 100
    },

    {
		"large shields",
		{ 0,0,0,0,  0,0,0,20,  0,0,0,0,  20,20,20,0 },
		{ 0,0,0,0,  0,0,0, 4,  0,0,0,0,   4, 4, 4,0 },
		&gpn_large_shields, NULL, 100
    },

	{
		"aegis",
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  1,0,0,0 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  4,0,0,0 },
		&gpn_improved_shield, NULL, 100
	},


    {
	"mounted combat",
	{ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
	{ 8, 8, 8, 8, 5, 5, 5, 5, 6, 6, 6, 6, 3, 3, 3, 3 },
	&gpn_mounted_combat, NULL, 100
    },

	{
	"weapon finesse",
	{ 30,30,30,30,  30,30,30,30,  1,1,1,1,  30,30,30,30 },
	{ 8,8,8,8,      6,6,6,6,      2,2,2,2,  4,4,4,4 },
	&gpn_weapon_finesse, NULL, 100
	},
   
    {
        "craftsmanship 1",
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        &gpn_craftsmanship_1, NULL, 100
    },

    {
        "craftsmanship 2",
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        { 3,3,3,3,  3,3,3,3,  3,3,3,3,  3,3,3,3 },
        &gpn_craftsmanship_2, &gpn_craftsmanship_1, 100
    },

    {
        "craftsmanship 3",
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        { 6,6,6,6,  6,6,6,6,  6,6,6,6,  6,6,6,6 },
        &gpn_craftsmanship_3, &gpn_craftsmanship_2, 100
    },

    {
        "craftsmanship 4",
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        { 10,10,10,10,  10,10,10,10,  10,10,10,10,  10,10,10,10 },
        &gpn_craftsmanship_4, &gpn_craftsmanship_3, 100
    },

    {
        "craftsmanship 5",
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        { 15,15,15,15,  15,15,15,15,  15,15,15,15,  15,15,15,15 },
        &gpn_craftsmanship_5, &gpn_craftsmanship_4, 100
    },

    {
        "meditation 1",
        { 1,1,1,1,  1,1,1,1,  0,1,0,0,  0,0,0,1 },
        { 1,1,1,1,  1,1,1,1,  0,1,0,0,  0,0,0,1 },
        &gpn_meditation_1, NULL, 100
    },

    {
        "meditation 2",
        { 1,1,1,1,  1,1,1,1,  0,1,0,0,  0,0,0,1 },
        { 3,3,3,3,  3,3,3,3,  0,3,0,0,  0,0,0,3 },
        &gpn_meditation_2, &gpn_meditation_1, 100
    },

    {
        "meditation 3",
        { 1,1,1,1,  1,1,1,1,  0,1,0,0,  0,0,0,1 },
        { 6,6,6,6,  6,6,6,6,  0,6,0,0,  0,0,0,6 },
        &gpn_meditation_3, &gpn_meditation_2, 100
    },

    {
        "meditation 4",
        { 1,1,1,1,  1,1,1,1,  0,1,0,0,  0,0,0,1 },
        { 10,10,10,10,  10,10,10,10,  0,10,0,0,  0,0,0,10 },
        &gpn_meditation_4, &gpn_meditation_3, 100
    },

    {
        "meditation 5",
        { 1,1,1,1,  1,1,1,1,  0,1,0,0,  0,0,0,1 },
        { 15,15,15,15,  15,15,15,15,  0,15,0,0,  0,0,0,15 },
        &gpn_meditation_5, &gpn_meditation_4, 100
    },

    {
        "regeneration 1",
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        &gpn_regeneration_1, NULL, 100
    },

    {
        "regeneration 2",
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        { 3,3,3,3,  3,3,3,3,  3,3,3,3,  3,3,3,3 },
        &gpn_regeneration_2, &gpn_regeneration_1, 100
    },

    {
        "regeneration 3",
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        { 6,6,6,6,  6,6,6,6,  6,6,6,6,  6,6,6,6 },
        &gpn_regeneration_3, &gpn_regeneration_2, 100
    },

    {
        "regeneration 4",
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        { 10,10,10,10,  10,10,10,10,  10,10,10,10,  10,10,10,10 },
        &gpn_regeneration_4, &gpn_regeneration_3, 100
    },

    {
        "regeneration 5",
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        { 15,15,15,15,  15,15,15,15,  15,15,15,15,  15,15,15,15 },
        &gpn_regeneration_5, &gpn_regeneration_4, 100
    },

    {
        "pack mule",
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        { 3,3,3,3,  3,3,3,3,  3,3,3,3,  2,2,2,2 },
        &gpn_pack_mule, NULL, 100
    },

    {
        "tireless 1",
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        &gpn_tireless_1, NULL, 100
    },

    {
        "tireless 2",
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        { 3,3,3,3,  3,3,3,3,  3,3,3,3,  3,3,3,3 },
        &gpn_tireless_2, &gpn_tireless_1, 100
    },

    {
        "tireless 3",
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        { 6,6,6,6,  6,6,6,6,  6,6,6,6,  6,6,6,6 },
        &gpn_tireless_3, &gpn_tireless_2, 100
    },

    {
        "tireless 4",
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        { 10,10,10,10,  10,10,10,10,  10,10,10,10,  10,10,10,10 },
        &gpn_tireless_4, &gpn_tireless_3, 100
    },

    {
        "tireless 5",
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        { 15,15,15,15,  15,15,15,15,  15,15,15,15,  15,15,15,15 },
        &gpn_tireless_5, &gpn_tireless_4, 100
    },

    {
        "elusive 1",
        { 0,0,0,0,  0,0,0,0,  1,1,1,1,  0,0,0,1 },
        { 0,0,0,0,  0,0,0,0,  1,1,1,1,  0,0,0,1 },
        &gpn_elusive_1, NULL, 100
    },  
    
    {
        "elusive 2",
        { 0,0,0,0,  0,0,0,0,  1,1,1,1,  0,0,0,1 },
        { 0,0,0,0,  0,0,0,0,  3,3,3,3,  0,0,0,3 },
        &gpn_elusive_2, &gpn_elusive_1, 100
    },  
    
    {
        "elusive 3",
        { 0,0,0,0,  0,0,0,0,  1,1,1,1,  0,0,0,1 },
        { 0,0,0,0,  0,0,0,0,  6,6,6,6,  0,0,0,6 },
        &gpn_elusive_3, &gpn_elusive_2, 100
    },  
    
    {
        "elusive 4",
        { 0,0,0,0,  0,0,0,0,  1,1,1,1,  0,0,0,1 },
        { 0,0,0,0,  0,0,0,0,  10,10,10,10,  0,0,0,10 },
        &gpn_elusive_4, &gpn_elusive_3, 100
    },  
    
    {
        "elusive 5",
        { 0,0,0,0,  0,0,0,0,  1,1,1,1,  0,0,0,1 },
        { 0,0,0,0,  0,0,0,0,  15,15,15,15,  0,0,0,15 },
        &gpn_elusive_5, &gpn_elusive_4, 100
    },

    {
        "marksmanship 1",
        { 0,0,0,0,  0,0,0,0,  1,1,1,0,  1,1,1,1 },
        { 0,0,0,0,  0,0,0,0,  1,1,1,0,  1,1,1,1 },
        &gpn_marksmanship_1, NULL, 100
    },

    {
        "marksmanship 2",
        { 0,0,0,0,  0,0,0,0,  1,1,1,0,  1,1,1,1 },
        { 0,0,0,0,  0,0,0,0,  3,3,3,3,  3,3,3,3 },
        &gpn_marksmanship_2, &gpn_marksmanship_1, 100
    },

    {
        "marksmanship 3",
        { 0,0,0,0,  0,0,0,0,  1,1,1,0,  1,1,1,1 },
        { 0,0,0,0,  0,0,0,0,  6,6,6,6,  6,6,6,6 },
        &gpn_marksmanship_3, &gpn_marksmanship_2, 100
    },

    {
        "marksmanship 4",
        { 0,0,0,0,  0,0,0,0,  1,1,1,0,  1,1,1,1 },
        { 0,0,0,0,  0,0,0,0,  10,10,10,0,  10,10,10,10 },
        &gpn_marksmanship_4, &gpn_marksmanship_3, 100
    },

    {
        "marksmanship 5",
        { 0,0,0,0,  0,0,0,0,  1,1,1,0,  1,1,1,1 },
        { 0,0,0,0,  0,0,0,0,  15,15,15,0,  15,15,15,15 },
        &gpn_marksmanship_5, &gpn_marksmanship_4, 100
    },

	{
	NULL,
	{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
	NULL, NULL
    }
};
	
const	struct	skill_type	skill_table	[MAX_SKILL]	=
{
    {
		"reserved",		
        { 99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99 },	
		{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		0,			TAR_IGNORE,		POS_STANDING,
		NULL,				 0,	 0,
		"",			"",		"", SKILL_FALSE, NULL
    },

    /** FAlse skills **/
	{
		"mining",
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
		NULL, 0, 0,
		&gsn_mining, 0, 0, "", "", "", SKILL_FALSE, NULL
	},

    {
		"encumbered",
		{ 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0 },
		{ 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0 },
        NULL, 0, 0,
		&gsn_encumbered,  0, 0, "", "", "", SKILL_FALSE, NULL
    },

	{
		"recall",
		{  0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,  0, 0, 0, 0 },
		{ 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0 },
		NULL, 0, 0,
		&gsn_recall, 0, 0, "", "", "", SKILL_FALSE, NULL
	},

    /** Trade skills **/
    {
		"apothecary",
		{   1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1 },
		{   1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1 },
		NULL,	TAR_IGNORE,	POS_STANDING,
		&gsn_apothecary,		0,	0,
		"",	"",  "", SKILL_TRADE, NULL
    },

    {
    "armorsmithing",
        {   1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1 },
        {   1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1 },
        NULL,   TAR_IGNORE,        POS_STANDING,
        &gsn_armorsmithing,              0,      0,
        "",     "",  "", SKILL_TRADE, NULL
    },

    {
        "brewing",
        {   1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1 },
		{   1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1 },
        NULL,   TAR_IGNORE,        POS_STANDING,
        &gsn_brewing,              0,      0,
        "",     "",  "", SKILL_TRADE, NULL, SKILL_SECONDARY
    },

    {
        "cooking",
        {   1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1 },
		{   1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1 },
        NULL,   TAR_IGNORE,        POS_STANDING,
        &gsn_cooking,              0,      0,
        "",     "",  "", SKILL_TRADE, NULL, SKILL_SECONDARY
    },

    {
        "fletching",
        {   1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1 },
		{   1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1 },
        NULL,   TAR_IGNORE,        POS_STANDING,
        &gsn_fletching,              0,      0,
        "",     "",  "", SKILL_TRADE, NULL
    },

    {
        "jewelcraft",
        {   1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1 },
		{   1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1 },
        NULL,   TAR_IGNORE,        POS_STANDING,
        &gsn_jewelcraft,              0,      0,
        "",     "",  "", SKILL_TRADE, NULL
    },

    {
        "pottery",
        {   1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1 },
		{   1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1 },
        NULL,   TAR_IGNORE,        POS_STANDING,
        &gsn_pottery,              0,      0,
        "",     "",  "", SKILL_TRADE, NULL, SKILL_SECONDARY
    },

    {
        "tailoring",
        {   1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1 },
		{   1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1 },
        NULL,   TAR_IGNORE,        POS_STANDING,
        &gsn_tailoring,              0,      0,
        "",     "",  "", SKILL_TRADE, NULL
    },

    {
    "weaponsmithing",
        {   1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1 },
        {   1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1 },
        NULL,   TAR_IGNORE,        POS_STANDING,
        &gsn_weaponsmithing,              0,      0,
        "",     "",  "", SKILL_TRADE, NULL
    },

	{
		"spellcrafting",
		{ 15,15,15,15,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
		{ 1,1,1,1,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
		NULL, TAR_IGNORE, POS_STANDING,
		&gsn_spellcrafting, 0, 0,
		"", "", "", SKILL_TRADE, NULL
	},

	{
	"woodworking",
		{ 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
		{ 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
		NULL, TAR_IGNORE, POS_STANDING,
		&gsn_woodworking, 0,0,
		"", "", "", SKILL_FOUNDATION, NULL
	},

	{
	"metalworking",
		{ 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
		{ 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
		NULL, TAR_IGNORE, POS_STANDING,
		&gsn_metalworking, 0,0,
		"", "", "", SKILL_FOUNDATION, NULL
	},

	{
	"stoneworking",
		{ 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
		{ 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
		NULL, TAR_IGNORE, POS_STANDING,
		&gsn_stoneworking, 0,0,
		"", "", "", SKILL_FOUNDATION, NULL
	},

    {   
    "clothworking",
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        { 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
        NULL, TAR_IGNORE, POS_STANDING,
        &gsn_clothworking, 0,0,
        "", "", "", SKILL_FOUNDATION, NULL  
    },

	{
	"leatherworking",
		{ 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
		{ 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
		NULL, TAR_IGNORE, POS_STANDING,
		&gsn_leatherworking, 0,0,
		"", "", "", SKILL_FOUNDATION, NULL
	},

    {
	"channeling",
	{ 6,6,6,6,6,6,6,6,0,0,0,0,0,0,0,0 },
	{ 1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0 },
        NULL,	TAR_IGNORE,	 POS_STANDING,
	&gsn_channeling,	 0, 0,
	"", "", "", SKILL_GENERAL, NULL
    },

	{
	"chicanery",
	{ 0,0,0,0,  0,0,0,0,  5,5,0,0,  0,0,0,0 },
	{ 0,0,0,0,  0,0,0,0,  1,1,0,0,  0,0,0,0 },
	NULL, TAR_IGNORE, POS_STANDING,
	&gsn_chicanery, 0, 0,
	"", "You recover your balance.", "", SKILL_GENERAL, NULL
	},

	{
		"body",
		{ 0,0,0,0,  0,0,0,0,  0,0,0,1,  0,0,0,0 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,1,  0,0,0,0 },
		NULL,	TAR_IGNORE, POS_STANDING,
		&gsn_body,	0,	0,
		"", "", "", SKILL_GENERAL, NULL
	},

	{
		"mind",
		{ 0,0,0,0,  0,0,0,0,  0,0,0,1,  0,0,0,0 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,1,  0,0,0,0 },
		NULL, TAR_IGNORE, POS_STANDING,
		&gsn_mind, 0, 0,
		"", "", "", SKILL_GENERAL, NULL
	},

	{
		"spirit",
		{ 0,0,0,0,  0,0,0,0,  0,0,0,1,  0,0,0,0 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,1,  0,0,0,0 },
		NULL, TAR_IGNORE, POS_STANDING,
		&gsn_spirit, 0, 0,
		"", "", "", SKILL_GENERAL, NULL
	},

	/*** WEAPON SKILL GROUPS ***/
    {
		"axe",			
        { 0,0,0,0,   0,0,1,1,   0,0,0,0,   1,1,1,1 },	
		{ 0,0,0,0,   0,0,4,4,   0,0,0,0,   4,3,3,3 },
        NULL,             TAR_IGNORE,             POS_FIGHTING,
        &gsn_axe,            	       0,      0,
        "",                     "!Axe!",		"", SKILL_WEAPON, NULL
    },


    {
    	"one-handed concussion",
        { 0,0,0,0,   1,1,1,1,   0,0,0,0,   1,1,1,1 },
		{ 0,0,0,0,   2,2,2,2,   0,0,0,0,   3,3,3,3 },
        NULL,             TAR_IGNORE,             POS_FIGHTING,
        &gsn_1h_concussion,                    0,      0,
        "",                     "!Flail!",      "", SKILL_WEAPON, NULL
    },

    {
    	"polearm",
        { 0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0 },
		{ 0,0,0,0,0,0,0,0,0,0,0,0,2,4,3,0 },
        NULL,             TAR_IGNORE,             POS_FIGHTING,
        &gsn_polearm,                  0,      0,
        "",                     "!Polearm!",        "", SKILL_WEAPON, NULL
    },

    {
        "slashing longblades",
        { 0,0,0,0, 0,1,0,0, 1,1,1,0, 1,1,1,1 },
		{ 0,0,0,0, 0,3,0,0, 3,3,3,0, 2,2,2,2 },
        NULL,             TAR_IGNORE,             POS_FIGHTING,
        &gsn_slashing_longblades,                      0,      0,
        "",                     "!Whip!",   "", SKILL_WEAPON, NULL
    },

    {
        "slashing shortblades",
        { 0,0,1,0, 0,1,0,0, 1,1,1,0, 1,1,1,1 },
		{ 0,0,8,0, 0,3,0,0, 3,3,3,0, 2,2,2,2 },
        NULL,             TAR_IGNORE,             POS_FIGHTING,
        &gsn_slashing_shortblades,                    0,      0,
        "",                     "!sword!",      "", SKILL_WEAPON, NULL
    },

    {
        "spear",
        { 0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1 },
		{ 0,0,0,0,0,0,2,0,0,0,0,0,3,2,3,3 },
        NULL,             TAR_IGNORE,             POS_FIGHTING,
        &gsn_spear,                    0,      0,
        "",                     "!Spear!",      "", SKILL_WEAPON, NULL
    },

    {
    	"staff",
    	{ 1,1,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1 },
		{ 6,6,6,6,  4,4,4,4,  4,4,4,2,  3,3,3,3 },
        NULL,       TAR_IGNORE,     POS_FIGHTING,
    	&gsn_staff,        0,  0,
    	"",         "!staff!",      "", SKILL_WEAPON, NULL
    },

    {
    	"thrusting longblades",
        { 0,0,1,0,0,0,0,0,1,1,1,0,1,1,1,1 },
		{ 0,0,6,0,0,0,0,0,4,4,4,0,3,3,3,3 },
        NULL,             TAR_IGNORE,             POS_FIGHTING,
        &gsn_thrusting_longblades,                     0,      0,
        "",    "!longblades thrusting!",   "", SKILL_WEAPON, NULL
    },

    {
        "thrusting shortblades",               
        { 1,1,1,1,0,0,0,0,1,1,1,0,1,1,1,1 },     
		{ 3,3,3,3,0,0,0,0,2,2,2,0,3,3,3,3 },
        NULL,             TAR_IGNORE,             POS_FIGHTING,
        &gsn_thrusting_shortblades,                   0,      0,
        "",                     "!Dagger!",		"", SKILL_WEAPON, NULL
    },
 
    {
		"two-handed concussion",			
        { 0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1 },	
		{ 0,0,0,0,3,3,3,3,0,0,0,0,4,4,4,4 },
        NULL,             TAR_IGNORE,             POS_FIGHTING,
        &gsn_2h_concussion,            	       0,      0,
        "",                     "!Mace!",		"", SKILL_WEAPON, NULL
    },

    {
		"whip",
		{ 0,0,0,0,  0,0,0,0,  1,1,1,0,  1,1,1,1 },
		{ 0,0,0,0,  0,0,0,0,  5,5,5,0,  4,4,4,4 },
		NULL,		TAR_IGNORE,		POS_FIGHTING,
		&gsn_whip,					0,	0,
		"",					"!Whip!",		"", SKILL_WEAPON, NULL
	}, 

	{
		"first aid",
        {35,35,35,25,  20,20,20,20,   30,30,30,30,  20,20,20,20 },
        { 6, 6, 6, 4,   3, 3, 3, 3,    5, 5, 5, 5,   4, 4, 4, 4 },
		NULL, TAR_IGNORE, POS_FIGHTING,
		&gsn_first_aid, 0, 0,
		"", "", "", SKILL_GENERAL, NULL
	},

	/* Divine Spell groups */
	{
		"benedictions",
		{ 0,0,0,0,  1,1,1,1,  0,0,0,0,  0,0,0,0 },
		{ 0,0,0,0,  2,2,2,2,  0,0,0,0,  0,0,0,0 },
		NULL, TAR_IGNORE, POS_FIGHTING,
		&gsn_benediction, 0, 0,
		"", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
	},

    {   
        "destruction",
        { 0,0,0,0,  1,1,1,1,  0,0,0,0,  0,0,0,0 },
        { 0,0,0,0,  0,0,0,2,  0,0,0,0,  0,0,0,0 },
        NULL, TAR_IGNORE, POS_FIGHTING,
        &gsn_destruction, 0, 0,
        "", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
    },

    {   
        "detection",
        { 0,0,0,0,  1,1,1,1,  0,0,0,0,  0,0,0,0 },
        { 0,0,0,0,  2,2,2,2,  0,0,0,0,  0,0,0,0 },
        NULL, TAR_IGNORE, POS_FIGHTING,
        &gsn_detection, 0, 0,
        "", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
    },

    {   
        "maladiction",
        { 0,0,0,0,  1,1,1,1,  0,0,0,0,  0,0,0,0 },
        { 0,0,0,0,  2,0,0,0,  0,0,0,0,  0,0,0,0 },
        NULL, TAR_IGNORE, POS_FIGHTING,
        &gsn_maladiction, 0, 0,
        "", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
    },

    {   
        "nature",
        { 0,0,0,0,  1,1,1,1,  0,0,0,0,  0,0,0,0 },
        { 0,0,0,0,  0,2,0,0,  0,0,0,0,  0,0,0,0 },
        NULL, TAR_IGNORE, POS_FIGHTING,
        &gsn_nature, 0, 0,
        "", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
    },

    {   
        "protection",
        { 0,0,0,0,  1,1,1,1,  0,0,0,0,  0,0,0,0 },
        { 0,0,0,0,  2,2,2,2,  0,0,0,0,  0,0,0,0 },
        NULL, TAR_IGNORE, POS_FIGHTING,
        &gsn_protection, 0, 0,
        "", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
    },

	{
		"paeans",
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  0,0,9,0 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  0,0,2,0 },
		NULL, TAR_IGNORE, POS_FIGHTING,
		&gsn_paeans, 0, 0,
		"", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
	},

    {   
        "rejuvenation",
        { 0,0,0,0,  1,1,1,1,  0,0,0,0,  0,0,0,0 },
        { 0,0,0,0,  2,2,2,2,  0,0,0,0,  0,0,0,0 },
        NULL, TAR_IGNORE, POS_FIGHTING,
        &gsn_rejuvenation, 0, 0,
        "", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
    },

	/* Bard skills */
	{
		"percussion",
		{ 0,0,0,0,  0,0,0,0,  0,1,0,0,  0,0,0,0 },
		{ 0,0,0,0,  0,0,0,0,  0,1,0,0,  0,0,0,0 },
		NULL, TAR_IGNORE, POS_STANDING,
		&gsn_percussion, 0, 0,
		"", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
	},

	{
		"strings",
		{ 0,0,0,0,  0,0,0,0,  0,1,0,0,  0,0,0,0 },
		{ 0,0,0,0,  0,0,0,0,  0,1,0,0,  0,0,0,0 },
		NULL, TAR_IGNORE, POS_STANDING,
		&gsn_strings, 0, 0,
		"", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
	},

	{
		"winds",
	    { 0,0,0,0,  0,0,0,0,  0,1,0,0,  0,0,0,0 }, 
        { 0,0,0,0,  0,0,0,0,  0,1,0,0,  0,0,0,0 },
        NULL, TAR_IGNORE, POS_STANDING,
        &gsn_winds, 0, 0,
        "", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
    },	

	{
		"vocals",
        { 0,0,0,0,  0,0,0,0,  0,1,0,0,  0,0,0,0 }, 
        { 0,0,0,0,  0,0,0,0,  0,1,0,0,  0,0,0,0 },
        NULL, TAR_IGNORE, POS_STANDING,
        &gsn_vocal, 0, 0,
        "", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
    },

	/* Arcane Spell Groups s*/
	{
		"abjuration",
		{ 5,5,1,1,   0,0,0,0,  0,0,0,0,  0,0,0,0 },
		{ 2,2,2,2,   0,0,0,0,  0,0,0,0,  0,0,0,0 },
		NULL,	TAR_IGNORE, POS_FIGHTING,
		&gsn_abjuration,		0,	0,
		"",	"", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
	},

    {
        "alteration",
        { 1,1,1,1,   0,0,0,0,  0,0,0,0,  0,0,0,0 },
		{ 2,2,2,2,   0,0,0,0,  0,0,0,0,  0,0,0,0 },
        NULL, TAR_IGNORE, POS_FIGHTING,
        &gsn_alteration,        0,  0,
        "", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
    },

    {
        "conjuration",
        { 1,1,1,5,   0,0,0,0,  0,0,0,0,  0,0,0,0 },
		{ 2,2,2,2,   0,0,0,0,  0,0,0,0,  0,0,0,0 },
        NULL, TAR_IGNORE, POS_FIGHTING,
        &gsn_conjuration,        0,  0,
        "", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
    },

    {
        "divination",
        { 5,1,5,5,   0,0,0,0,  0,0,0,0,  0,0,0,0 },
		{ 2,2,2,2,   0,0,0,0,  0,0,0,0,  0,0,0,0 },
        NULL, TAR_IGNORE, POS_FIGHTING,
        &gsn_divination,        0,  0,
        "", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
    },

    {
        "enchantment",
        { 5,5,5,1,   0,0,0,0,  0,0,0,0,  0,0,0,0 },
		{ 2,2,2,2,   0,0,0,0,  0,0,0,0,  0,0,0,0 },
        NULL, TAR_IGNORE, POS_FIGHTING,
        &gsn_enchantment,        0,  0,
        "", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
    },

    {
        "evocation",
        { 1,5,1,1,   0,0,0,0,  0,0,0,0,  0,0,0,0 },
		{ 2,2,2,2,   0,0,0,0,  0,0,0,0,  0,0,0,0 },
        NULL, TAR_IGNORE, POS_FIGHTING,
        &gsn_evocation,        0,  0,
        "", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
    },

    {
        "illusion",
        { 1,5,5,5,   0,0,0,0,  0,0,0,0,  0,0,0,0 },
		{ 2,2,2,2,   0,0,0,0,  0,0,0,0,  0,0,0,0 },
        NULL, TAR_IGNORE, POS_FIGHTING,
        &gsn_illusion,        0,  0,
        "", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
    },

    {
        "necromancy",
        { 5,1,5,5,   0,0,0,0,  0,0,0,0,  0,0,0,0 },
		{ 2,2,2,2,   0,0,0,0,  0,0,0,0,  0,0,0,0 },
        NULL, TAR_IGNORE, POS_FIGHTING,
        &gsn_necromancy,        0,  0,
        "", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
    },

    {
        "nethermancy",
        { 15,15,15,15,   0,0,0,0,  0,0,0,0,  0,0,0,0 },
		{ 2,2,2,2,   0,0,0,0,  0,0,0,0,  0,0,0,0 },
        NULL, TAR_IGNORE, POS_FIGHTING,
        &gsn_nethermancy,        0,  0,
        "", "", "", SKILL_GENERAL, NULL, SKILL_SPELL_GROUP
    },

	{
		"double strike",
		{ 0,0,0,0, 	0,0,0,0,	25,25,30,10,	15,15,18,30 },
		{ 0,0,0,0,  0,0,0,0,     6, 6, 7, 4,     4, 4, 5, 8 },
		NULL,	TAR_IGNORE, POS_FIGHTING,
		&gsn_double_strike,	0,	0,
		"",	"!Double strike!",	"", SKILL_GENERAL, NULL
	},

    {
		"shield",
        { 0,0,0,0,    10,0,10,10,  0,0,0,0,    1,1,1,1 },
		{ 0,0,0,0,    6,0,7,5,     0,0,0,0,    2,3,2,4 },
		NULL,		TAR_IGNORE,		POS_FIGHTING,
		&gsn_shield_block,		0,	0,
		"",			"!Shield!",		"", SKILL_GENERAL, NULL
    },
 

    {
		"crossbow",			
        { 0,0,0,0,0,0,0,0,1,1,1,0,1,1,1,1 },	
		{ 0,0,0,0,0,0,0,0,3,3,3,0,4,6,5,5 },
        NULL,             TAR_IGNORE,             POS_FIGHTING,
        &gsn_crossbow,           	       0,      0,
        "",                     "!Whip!",	"", SKILL_WEAPON, NULL
    },

    {
		"shortbow",
		{ 0,0,0,0,  0,0,0,0,  1,1,1,0,  1,1,1,1 },
		{ 0,0,0,0,  0,0,0,0,  4,4,4,0,  4,4,5,3 },
        NULL,             TAR_IGNORE,             POS_FIGHTING,
        &gsn_shortbow,            	       0,      0,
        "",                     "!Whip!",	"", SKILL_WEAPON, NULL
    },

    {
        "longbow",
        { 0,0,0,0,  0,0,0,0,  0,0,0,0,  1,1,1,1 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  5,7,7,3 },
        NULL,             TAR_IGNORE,             POS_FIGHTING,
        &gsn_longbow,                     0,      0,
        "",                     "!Whip!",       "", SKILL_WEAPON, &gsn_shortbow
    },

    {
        "composite longbow",
        { 0,0,0,0,  0,0,0,0,  0,0,0,0,  1,1,1,1 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  8,9,9,3 }, 
        NULL,             TAR_IGNORE,             POS_FIGHTING,
        &gsn_composite_longbow,                     0,      0,
        "",                     "!Whip!",       "", SKILL_WEAPON, &gsn_longbow
    },

    {
        "backstab",             
        {   0,0,0,0,  0,0,0,0,  1,0,1,0,  0,0,0,0 },
		{   0,0,0,0,  0,0,0,0,  2,0,2,0,  0,0,0,0 },
        NULL,             TAR_IGNORE,             POS_STANDING,
        &gsn_backstab,                  0,     24,
        "backstab",             "!Backstab!",		"", SKILL_GENERAL, NULL
    },

	{
		"alchemy",
		{  0,0,0,0,    0, 0,20, 0,  0,0,0,0,  0,0,0,0 },
		{  0,0,0,0,    0, 0, 5, 0,  0,0,0,0,  0,0,0,0 },
		NULL,	TAR_IGNORE,	POS_STANDING,
		NULL,		0,	0,
		"",	"",	"",	SKILL_GENERAL, NULL
	},

    {
		"bash",			
        {  0,0,0,0,  0,0,0,0,  0,0,0,0,  5,1,0,0 },
		{  0,0,0,0,  0,0,0,0,  0,0,0,0,  2,1,0,0 },
        NULL,             TAR_IGNORE,             POS_FIGHTING,
        &gsn_bash,            	       0,      24,
        "bash",                 "!Bash!",		"", SKILL_GENERAL, NULL
    },

    {
		"berserk",		
        {  0,0,0,0,  0,0,0,0,  0,0,0,0,  0,12,0,0 },
		{  0,0,0,0,  0,0,0,0,  0,0,0,0,  0, 4,0,0 },
        NULL,             TAR_IGNORE,             POS_FIGHTING,
        &gsn_berserk,        	       0,      24,
        "",                     "You feel your pulse slow down.",	"", SKILL_GENERAL, NULL
    },

    {
        "disarm",               
        {  0,0,0,0,  0,0,0,0,  0,0,0,23,  11,0,17,29 },
		{  0,0,0,0,  0,0,0,0,  0,0,0, 4,   2,0, 3, 4 },
        NULL,             TAR_IGNORE,             POS_FIGHTING,
        &gsn_disarm,                    0,     24,
        "",                     "!Disarm!",		"", SKILL_GENERAL, NULL
    },

	{
		"dual wield",
		{  0,0,0,0,   0,0,0,0,  0,0,20,0,   0,30,0,10 },
		{  0,0,0,0,   0,0,0,0,  0,0,4,0,    0,8,0, 2 },
		NULL,			TAR_IGNORE,		POS_FIGHTING,
		&gsn_dual_wield,			0,		0,
		"",		"!Dual wield!",		"", SKILL_GENERAL, NULL, SKILL_NO_REUSE_ALERT
	},
 
    {
        "evade",                
        {  0,0,0,0,  0,0,0,0,  1,1,1,1,  0,0,0,6 },
		{  0,0,0,0,  0,0,0,0,  2,2,2,2,  0,0,0,4 },
        NULL,             TAR_IGNORE,             POS_FIGHTING,
        &gsn_dodge,                     0,     0, 
        "",                     "!Dodge!",		"", SKILL_GENERAL, NULL
    },

    {
		"venoms",
        {  0,0,0,0,  0,0,0,0,  0,0,10,0,  0,0,0,0 },
		{  0,0,0,0,  0,0,0,0,  0,0, 5,0,  0,0,0,0 },
		NULL,		TAR_IGNORE,	  	POS_RESTING,
		&gsn_envenom,			0,	36,
		"",			"!Envenom!",		"", SKILL_GENERAL, NULL
    },

	{
		"kirijutsu",
		{  0, 0, 0, 0,   0, 0, 0, 0,   0, 0,20,5,   0, 0, 0, 0 },
		{  0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 5,1,   0, 0, 0, 0 },
		NULL,	TAR_IGNORE, POS_FIGHTING,
		&gsn_kirijutsu, 	0,	0,	
		"",	"Kirijutsu!",	"", SKILL_GENERAL, NULL
	},

    {
		"unarmed combat",
        {  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0 },
		{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0 },
		NULL,		TAR_IGNORE,		POS_FIGHTING,
		&gsn_hand_to_hand,		0,	0,
		"",			"!Hand to Hand!",	"", SKILL_GENERAL, NULL, SKILL_NO_REUSE_ALERT
    },

    {
        "kick",                 
        {  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 7, 4,14,15 },     
		{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 2, 4, 5 },
        NULL,             TAR_CHAR_OFFENSIVE,     POS_FIGHTING,
        &gsn_kick,                      0,     12,
        "kick",                 "!Kick!",		"", SKILL_GENERAL, NULL
    },

    {
        "parry",                
        {  0, 0, 0, 0,   0, 0, 0, 0,  14,14,14,14,  10,22,15,15 },
		{  0, 0, 0, 0,   0, 0, 0, 0,   2, 2, 2, 2,   2, 2, 2, 2 },
        NULL,             TAR_IGNORE,             POS_FIGHTING,
        &gsn_parry,                     0,     0,
        "",                     "!Parry!",		"", SKILL_GENERAL, NULL
    },

	{
		"leg sweep",
		{  0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0,5,   0, 0, 0, 0 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
		NULL, TAR_IGNORE, POS_FIGHTING, &gsn_legsweep, 0, 0,
		"leg sweep", "!Leg Sweep!", "", SKILL_FALSE, NULL
	},

	{
		"palm attack",
		{  0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0,27,   0, 0, 0, 0 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
		NULL, TAR_IGNORE, POS_FIGHTING, &gsn_palmattack, 0, 0,
		"palm attack", "!Palm Attack!", "", SKILL_FALSE, NULL
	},

	{
		"mending",
		{  0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
		NULL, TAR_IGNORE, POS_FIGHTING, &gsn_mending, 0, 0,
		"", "!Mending!", "", SKILL_FALSE, NULL
	},

	{
		"precognition",
		{  0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
		NULL, TAR_IGNORE, POS_FIGHTING, &gsn_precognition, 0, 0,
		"", "Your precognative abilities are gone.", "", SKILL_FALSE, NULL
	},

	{
		"ki strike",
		{  0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
		NULL, TAR_IGNORE, POS_FIGHTING, &gsn_kistrike, 0, 0,
		"ki strike", "!Ki Strike!", "", SKILL_FALSE, NULL
	},

	{
		"fire within",
		{  0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
		NULL, TAR_IGNORE, POS_FIGHTING, &gsn_firewithin, 0, 0,
		"", "The fire within is extinguished.", "", SKILL_FALSE, NULL
	},

	{
		"purge",
		{  0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
		NULL, TAR_IGNORE, POS_FIGHTING, &gsn_purge, 0, 0,
		"", "!Purge!", "", SKILL_FALSE, NULL
	},

    {
        "paralyze",
        { 0,0,0,0,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
        { 0,0,0,0,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
        NULL, TAR_IGNORE, POS_FIGHTING, &gsn_paralyze, 0, 0,
        "", "!Paralyze!", "", SKILL_FALSE, NULL
    },

	{
		"pall",
		{  0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0 },
		{ 0,0,0,0,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
		NULL, TAR_IGNORE, POS_FIGHTING, &gsn_pall, 0, 0,
		"", "!Pall!", "", SKILL_FALSE, NULL
	},

    {
		"trip",			
        {  0, 0, 0, 0,  0, 0, 0, 0, 5, 0,5, 0,   0, 0, 0, 0 },	
		{ 0, 0, 0, 0,  0, 0, 0, 0,  1, 0,1,0,   0, 0, 0,0   },
		NULL,		TAR_IGNORE,		POS_FIGHTING,
		&gsn_trip,			0,	0,
		"trip",			"!Trip!",		"", SKILL_GENERAL, NULL
    },

    {
        "open lock",      
        {  0, 0, 0, 0,   0, 0, 0, 0,   5,10, 0, 0,   0, 0, 0, 0 },
		{  0, 0, 0, 0,   0, 0, 0, 0,   4, 5, 0, 0,   0, 0, 0, 0 },
        NULL,     TAR_IGNORE,     POS_STANDING,
        &gsn_open_lock,           0, 12,
        "",         "!Pick!",       "", SKILL_GENERAL, NULL
    },

	{
		"lay on hands",
		{  0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,   0, 0,10, 0 },
		{ 0, 0, 0, 0,    0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 2, 0 },
		NULL,		TAR_IGNORE,		POS_STANDING,
		&gsn_lay_on_hands,		0,	0,
		"",	"!Lay on Hands!",	"",	SKILL_GENERAL, NULL
	},

    /*{
		"scribe"	,
		{   5,5,5,7,    0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0 },
		{   2,2,2,3,    0, 0, 0, 0,  0, 0, 0, 0,    0, 0, 0, 0 },
		NULL,	TAR_IGNORE,	POS_STANDING,
		NULL,		0,	0,	
		"",	"",	"", SKILL_GENERAL, NULL
    },*/

	{
		"shapeshifting",
		{  0, 0, 0, 0,   0,10, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0 },
		{ 0, 0, 0, 0,   0, 1, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0  },
		NULL,	TAR_IGNORE,	POS_STANDING,
		&gsn_shapeshifting,		0,	0,
		"",	"",	"",	SKILL_GENERAL, NULL
	},

	{
		"shapeshift sickness",
		{  0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0 },
		{  0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0 },
		NULL, TAR_IGNORE, POS_STANDING,
		NULL, 0, 0,
		"", "The shapeshifting sickness wears off.", "", SKILL_FALSE, NULL
	},

    {
		"pick pocket",		
        {  0, 0, 0, 0,   0, 0, 0, 0, 10, 0, 0, 0,   0, 0, 0, 0 },	
		{  0, 0, 0, 0,  0, 0, 0, 0,   1, 0, 0, 0,  0, 0, 0, 0 },
		NULL,		TAR_IGNORE,		POS_STANDING,
		&gsn_pick_pocket,			 0,	24,
		"",			"!Steal!",		"", SKILL_GENERAL, NULL
    },

    {
        "stealth",
        {  0, 0, 0, 0, 0, 0, 0, 0,1, 0,1, 0,   0, 0, 0,35 },
		{ 0, 0, 0, 0, 0, 0, 0, 0, 1, 0,1, 0, 0, 0, 0, 6 },
        NULL,     TAR_IGNORE,     POS_RESTING,
        &gsn_stealth,           0, 12,
        "",         "Your stealthiness fades.",       "", SKILL_GENERAL, NULL
    },

	{
		"thaumaturgy",
		{ 1,1,1,1,   0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0 },
		{ 1,1,1,1,  0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0  },
		NULL,	TAR_IGNORE,	POS_STANDING,
		&gsn_thaumaturgy,  0, 0,
		"", "", "", SKILL_GENERAL, NULL
	},

	{
		"theology",
		{  0, 0, 0, 0,  1,1,1,1,   0, 0, 0, 0,   0, 0, 0, 0 },
		{ 0, 0, 0, 0,   1,1,1,1,   0, 0, 0, 0,   0, 0, 0, 0 },
		NULL,	TAR_IGNORE, POS_STANDING,
		&gsn_theology,  0,0,
		"","","", SKILL_GENERAL, NULL
	},

	{
		"guard",
		{  0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,  5,5,5,5 },
		{ 0,0,0,0,       0,0,0,0,     0,0,0,0,      1,1,1,1 },
		NULL, TAR_IGNORE, POS_STANDING,
		&gsn_guard, 0, 0,
		"", "", "", SKILL_GENERAL, NULL
	},

    {
        "rescue",
        {  0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,  8,8,8,8 },
        { 0,0,0,0,       0,0,0,0,     0,0,0,0,      1,1,1,1 },
        NULL, TAR_IGNORE, POS_STANDING,
        &gsn_rescue, 0, 0,
        "", "", "", SKILL_GENERAL, NULL
    },

    {
        "intercept",
        {  0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,  12,12,12,12 },
        { 0,0,0,0,       0,0,0,0,     0,0,0,0,      1,1,1,1 },
        NULL, TAR_IGNORE, POS_STANDING,
        &gsn_intercept, 0, 0,
        "", "", "", SKILL_GENERAL, NULL
    },

	{
		"concentration",
		{  0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0 },
		{  0,0,0,0,      0,0,0,0,      0,0,0,0,      0,0,0,0 },
		NULL, TAR_IGNORE, POS_STANDING,
		&gsn_concentration, 0, 0,
		"", "You lose your concentration and focus.", "", SKILL_FALSE, NULL
	},

    {
        "quick cast",
        { 0,0,0,0,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
        { 0,0,0,0,  0,0,0,0,  0,0,0,0,  0,0,0,0 },
        NULL, TAR_IGNORE, POS_STANDING, 
        &gsn_quick_cast, 0, 0, "", "", "", SKILL_FALSE, NULL
    },

        
/*
    {
		"scrolls",		
        { 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1 },	
		{ 1,1,1,1,3,3,3,3,3,3,3,3,7,7,7,7 },
		NULL,		TAR_IGNORE,		POS_STANDING,
		&gsn_scrolls,			0,	24,
		"",			"!Scrolls!",		"", SKILL_GENERAL, NULL
    },

    {
		"staves",		
        { 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1 },	
		{ 1,1,1,1,3,3,3,3,6,6,6,6,9,9,9,9 },
		NULL,		TAR_IGNORE,		POS_STANDING,
		&gsn_staves,			0,	12,
		"",			"!Staves!",		"", SKILL_GENERAL, NULL
    },
    
    {
		"wands",		
        { 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1 },	
		{ 1,1,1,1,3,3,3,3,6,6,6,6,9,9,9,9 },
		NULL,		TAR_IGNORE,		POS_STANDING,
		&gsn_wands,			0,	12,
		"",			"!Wands!",		"", SKILL_GENERAL, NULL
    },
*/
    {
		NULL,
		{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
		{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
		NULL, 0,0,
		NULL,0,0,
		"","","", SKILL_GENERAL, NULL
    }
};

const   struct  group_type      group_table     [MAX_GROUP]     =
{

    {
		"rom basics",		
		{ "trade skills", "cloth armor", "staff", "bestiary" }
    },

    {
		"trade skills",
		{ "apothecary", "brewing", "cooking", "fishing", "fletching",
	  	"jewelcraft", "pottery", "armorsmithing", "weaponsmithing", "tailoring",
		"woodworking", "metalworking", "leatherworking", "stoneworking", "clothworking" }
    },

	{
		"spheres",
		{ "benediction", "rejuvenation", "protection", "maladiction",
		  "destruction", "nature", "detection" }
	},

	{
		"schools",
		{ "abjuration", "alteration", "conjuration", "divination",
		  "enchantment", "evocation", "illusion", "necromancy",
		  "nethermancy"
		}
	},

    {
		"wizard basics",
		{ "scribing", "channeling", "thaumaturgy", "schools", "thrusting shortblades" }
    },

    {
		"sorcerer basics",
		{ "scribing", "channeling" , "thaumaturgy", "schools", "thrusting shortblades"}
    },

    {
		"arcanist basics",
		{ "scribing", "channeling", "alchemy" , "thaumaturgy", "schools", "thrusting shortblades"}
    },

    {
		"warlock basics",
		{ "thrusting shortblades", "leather armor", 
		  "channeling" , "thaumaturgy", "schools" }
    },

    {
		"cleric basics",
		{ "cloth armor", "leather armor", "studded leather armor",
		  "chain mail armor", "medium shields", "one-handed concussion",
		  "small shields", "theology", "spheres", "channeling", "buckler shields",
			"scale mail armor"  }
    },

    {
		"crusader basics",
		{ "two-handed concussion","chain mail armor", "plate mail armor", "medium shields" 
		  "cloth armor", "leather armor", "studded leather armor", "small shields",
		  "one-handed concussion", "theology", "spheres", "channeling", "buckler shields",
			"scale mail armor" }
    },

    {
		"shaman basics",
		{ "chain mail armor", "medium shields", "spear", "small shields", "cloth armor",
		  "leather armor", "studded leather armor", "one-handed concussion" , "alchemy", "theology",
			"spheres", "channeling", "buckler shields",
			"scale mail armor" }
    },

    {
		"druid basics",
		{
			"cloth armor", "leather armor", "studded leather armor", "small shields",
			"one-handed concussion", "slashing shortblades", "shapeshifting", "theology",
			"spheres", "channeling", "buckler shields" }
    },
 
    {
		"thief basics",
		{ 
			"leather armor", "studded leather armor", "backstab", "safe fall",
			"small shields", "short bow", "thrusting shortblades",
	  		"thrusting longblades", "open lock", "pick pocket", "case",
	  		"stealth", "evade", "parry", "cloth armor", "weapon finesse",
			"trip", "buckler shields", "scale mail armor", "improved critical",
			"chicanery", "elusive 1", "elusive 2", "climb", "appraise"
		}
    },

    {
		"bard basics",
		{ 
			"leather armor", "studded leather armor", "appraise",
	  		"thrusting shortblades", "thrusting longblades", "short bow",
			"evade", "parry", "instruments", "open lock",
			"cloth armor", "weapon finesse", "percussion", "strings", "winds",
			"vocals", "scale mail armor", "chicanery", "slashing shortblades"
		}
    },

    {
		"assassin basics",
		{ 
			"leather armor", "studded leather armor", "cloth armor",
	  		"thrusting shortblades", "thrusting longblades", "short bow" ,
			"evade", "parry", "stealth", "venoms", "kirijutsu",
			"backstab", "weapon finesse", "trip", "elusive 1", "elusive 2"
		}
    },
 
    {
		"monk basics",
		{ 
			"staff", "cloth armor", "evade", "parry", "kirijutsu", "safe fall",
		 	"unarmed combat", "kick", "body", "spirit", "mind", "kihap" }
    },

    {
		"fighter basics",
		{ 
			"cloth armor", "leather armor", "studded leather armor",
			"chain mail armor", "plate mail armor", "small shields",
			"medium shields", "large shields", "parry", "shield", "disarm",
			"bash", "rescue", "guard", "intercept", "slashing shortblades",
			"slashing longblades", "short bow", "kick", "buckler shields",
			"scale mail armor", "aegis", "enhanced damage", "enhanced critical",
			"superior critical", "polearm",
		}
    },

    {
		"barbarian basics",
		{ 
			"cloth armor", "leather armor", "studded leather armor",
			"chain mail armor", "small shields", "enhanced critical",
			"medium shields", "parry", "shield", "berserk", "bash", 
			"rescue", "guard", "intercept", "axe", "short bow", 
			"slashing shortblades", "slashing longblades", "kick", "buckler shields",
			"scale mail armor", "savagery"
		}
    },

    {
		"paladin basics",
		{ 
			"cloth armor", "leather armor", "studded leather armor", "chain mail armor",
			"plate mail armor", "small shields", "medium shields", "shield", "parry",
			"disarm", "slashing shortblades", "slashing longblades", "short bow",
			"two-handed concussion", "lay on hands", "rescue", "guard", "intercept", "kick", "buckler shields",
			"scale mail armor", "paeans", "theology", "enhanced damage", "polearm",
		}
    },

    {
		"ranger basics",
		{ 
			"cloth armor", "leather armor", "studded leather armor", "scale mail armor",
			"small shields", "slashing shortblades", "slashing longblades", "short bow",
			"long bow", "evade", "parry", "dual wield", "tracking", "riposte", "stealth",
			"rescue", "guard", "intercept", "kick", "buckler shields", "enhanced damage",
            "marksmanship 1", "marksmanship 2", "shortbow", "longbow", "composite longbow",
            "climb"
		}
    },
};


const	struct	channel_type	channel_table	[]	=
{
	{ &CHANNEL_GOSSIP,    
	  "gossip",    "gossip",    	"gossips",    
          0,     	1,	COMM_NOGOSSIP, 'W' },

 	{ &CHANNEL_GRATS,
	  "grats",	"grat",		"grats",
	  0,		1,	COMM_NOGRATS, 'Y' },

   	{ &CHANNEL_QUESTION,
	  "advice",	"advise",	"advises",
	  0,		1,	COMM_NOQUESTION, 'C' },

	{ &CHANNEL_AUCTION,
	  "auction",	"auction",	"auctions",
	  0,		1,	COMM_NOAUCTION, 'R' },

 	{ &CHANNEL_QUEST,
	  "quest",	"quest",	"quests",
	  0,		1,	COMM_NOQUEST,  'y'	},

	{ &CHANNEL_IMMTALK,
	  "immortal",	"immtalk",	"imms",
	  0,		52,	COMM_NOWIZ,    'W'	},

	{ &CHANNEL_ADMINTALK,	
	  "admin",	"admintalk",	"admintalks",
	  0,		59,	COMM_NOADMIN,	'g'	},

	{ &CHANNEL_CLANTALK,
	  "clan talk",	"clan",		"clans",
	  CHAN_SAME_CLAN,	1,	COMM_NOCLAN, 'G' },

	{ &CHANNEL_MUSIC,
	  "music",	"MUSIC",	"MUSIC",
	   0,		1,		COMM_NOMUSIC, 'W' },

 	{ &CHANNEL_OOCTALK,	
	  "ooc",	"ooc",		"ooc's",
	   0,		1,		COMM_NOOOC, 'c' },

	{ &CHANNEL_HOCKEY,
		"hockey",	"hockey",	"hockeys",
		0,	1,	COMM_NOHOCKEY,	'W' },

	{ &CHANNEL_RT,
		"rt",	"rt",	"rts",
		0,	1,	COMM_NORT,	'W' },

	{ &CHANNEL_RTSUB,
		"(rt) sub",	"(rt) sub",	"(rt) subs",
		0,	1,	COMM_NORTSUB,	'W' },

  	{ NULL,
		NULL,NULL,NULL,0,0,0 }
};

const struct currency_tag	currency_table [] =
{
	{ "silver",	'x',	1,			50	},
	{ "gold",	'y',	100,		50	},
	{ "electrum",'c',	10000,		25	},
	{ "platinum",'W',	1000000,	10  },
	{ "mithril",'r',	100000000,	100	},
	{ NULL, 0, 0, 100					}
};

const struct hitloc		hitloc_table [] =
{
	{ WEAR_BODY,			20	},
	{ WEAR_SHOULDERS,		15  },
	{ WEAR_LEGS,			15  },
	{ WEAR_ARMS,			10  },
	{ WEAR_HEAD,			10	},
	{ WEAR_HANDS,			5	},
	{ WEAR_WRIST_L,			3	},
	{ WEAR_WRIST_R,			3	},
	{ WEAR_WAIST,			5	},
	{ WEAR_FEET,			5 	},
	{ WEAR_FACE,			5	},
	{ WEAR_ABOUT,			4 	},
	{ -1,					0 	}
};

const pick_difficulty_type pick_diff_table[]=
{
	{ 0,					0 		},
	{ EX_SIMPLE,			15		},
	{ EX_EASY,				30		},
 	{ EX_AVERAGE,			45		},
 	{ EX_DIFFICULT,			60		},
 	{ EX_HARD,				75		},
 	{ EX_INFURIATING,		90		}
};

const struct config_type param_config_table [] =
{
    { "null",       0,          NULL                },
    { "MostPlayersEver",      INTEGER,    &GameInfo.mostPlayersEver },
    { "MostPlayersWhen",      INTEGER,    &GameInfo.mostPlayersWhen },
	{ "Version",		      INTEGER,    &GameInfo.version },
/*
	{ "NumberOfAncois",		INTEGER,	&GameInfo
	{ "NumberOfNorthman",	INTEGER,	
	{ "NumberOfAeshoth",	INTEGER,	
	{ "NumberOfSylvan",		INTEGER,	
	{ "NumberOfAbrainon",	INTEGER,	
	{ "NumberOfBrombachol",	INTEGER,	
	{ "NumberOfKveslan",	INTEGER,	
	{ "NumberOfShjon",		INTEGER,	
	{ "NumberOfGalli",		INTEGER,	
	{ "NumberOfThalla",		INTEGER,	
	{ "NumberOfHalf-elf",	INTEGER,	
	{ "NumberOfHalf-orc",	INTEGER,	
	{ "NumberOfMage",		INTEGER,	
	{ "NumberOfSorcerer",	INTEGER,	
	{ "NumberOfWarlock",	INTEGER,	
	{ "NumberOfArcanist",	INTEGER,	
	{ "NumberOfCleric",		INTEGER,	
	{ "NumberOfDruid",		INTEGER,	
	{ "NumberOfShaman",		INTEGER,	
	{ "NumberOfCrusader",	INTEGER,	
	{ "NumberOfThief",		INTEGER,	
	{ "NumberOfBard",		INTEGER,	
	{ "NumberOfAssassin",	INTEGER,	
	{ "NumberOfMonk",		INTEGER,	
	{ "NumberOfFighter",	INTEGER,	
	{ "NumberOfBarbarian",	INTEGER,	
	{ "NumberOfPaladin",	INTEGER,	
	{ "NumberOfRanger",		INTEGER,	
*/
    { NULL,         0,          NULL                }
};

const char * dam_type_name [] = 
{
	"none",		/* 0 */
	"concussion",
	"pierce",
	"slash",
	"fire",
	"ice",		/* 5 */
	"lightning",
	"acid",
	"poison",
	"earth",
	"air",			/* 10 */
	"mental",
	"disease",
	"water",
	"light",
	"sound",		/* 15 */
	"spirit",
	"dark",
	"unknown"
};

const struct venom_type venom_table [] =
{
	{ 	"snake",		1260, 25	},
	{	"amphibian",	1261, 15	},
	{	"spider",		1262, 25	},
	{	"insect",		1263, 15	},
	{	"lizard",		1264, 10	},
	{	"plant",		1265, 10	},
	{	"scorpion",		1266, 50 	},
	{	"giant insect",	1263, 15	},
	{	"giant spider",	1262, 25	},
	{	NULL,0,0 },
};


const char* randomDescriptions[2][10] = {
	// forest
	{ 
// 0
"The echo of howls and screeches bounce from the boles and boughs of the trees,\
masking their direction of origin.  The dark forest obscures all sense of\
orientation and direction, reducing the traveller to navigate by intuition\
across the rocky floor.\
",
// 1
"The forest is dark and forbidding, filled with distant screeches and howls.\
The forest floor is rocky with a thin layer of soil from which patches of tiny\
plants struggle to grow.  A canopy of trees overhead blocks much of the sun and\
moon light.\
",
// 2
"The rocky floor of the forest is covered with a thin layer of soil, form which\
struggle forth sickly looking shrubs and grasses.  The ceiling of intertwining\
tree branches overhead blocks out almost all light, leaving the process of\
moving through the forest a dark undertaking.\
" ,
// 3
"Patches of grass and shrubs struggle to survive in the rocky soil of the forest\
floor, as the thick latticework of tree branches overhead eliminte most of the\
light from getting into the dark wood.  The sound of screeching and howling\
creatures can be heard echoing through the boughs.\
",
// 4
"The massive trunks of ancient trees tower overhead, undisturbed by the elements.\
The air is dusty and limits what little visibility there is among the boles and\
boughs of the trees.  The forest floor is a mixture of rocky soil and moss-\
covered rocks.\
",
// 5
"The air of the forest is close and dusty, and difficult to see through.  The\
moss-covered trunks of trees aged beyond memory blend together into a wall of\
greenish-brown textures thrusting out of the forest floor, itself a mixture\
of mossy soil and stone.\
",
// 6
"Something resembling a path, perhaps created by wild game, penetrates portions\
of the forest.  Otherwise, this wood is a veritable wall of earthy textures and\
mossy tree trunks, which seem to float in the dusty air over the rocky forest\
floor.\
",
// 7
"The canopy of leaves and branches overhead permits little light from\
penetrating to the forest floor, which is a mixture of sandy soil and moss-\
covered rocks.  The trees themselves are old beyond memory, reaching skyward\
from thick peat-covered boles.\
",
// 8
"The trees hem a tight path for travel, but not so much as to make this forest\
impassable.  The forest underbrush creeps up against the sides of the ancient\
trees, hiding the rocky floor of the timberlands.\
",
// 9
"A cobweb of intertwined branches and various leaves create a sort of false\
ceiling overhead, hiding light and distorting shadow.  The rocky floor is\
treacherous but navigable, though the dusty air of the forest makes it\
difficult to determine direction.\
"
	},

	// plains
	{
// 0
"A vast expanse of fields and meadows rolls over gentle slopes.  Sparse plant\
life dots the landscape along with copses of flowering trees and patches of\
swaying weeds and grasses.\
",
// 1
"Rolling patches of flowers and weeds dot the landscape, waving and swaying\
when there's a breeze.  Infrequent copses of shrubbery and trees fill into\
empty patches of the ground, providing habitat and shade.\
",
// 2
"Various game-made trails and paths wind their way through the tall waving\
grains and grasses of the plains.  The ground is a mixture of soil, sand, and\
rock.\
",
// 3
"Wild herbs and grains grow through the sandy soil of the fields as small trees\
and low shrubs dot the landscape.  Plains of wild grasses and flowers sway\
gently in the breeze.\
",
// 4
"Meadows of wildflowers and wide plains of close-growing grains and herbs cover\
the sandy soil of the plains as a spiderweb of of wild game trails winds and\
wends through the grass.\
",
// 5
"Untamed cospes of trees and shrubs are mixed in among the patches of grass,\
grains, and wildflowers.  V-shaped paths through the swaying plants were \
probably made by wild game feeding on the grains.\
",
// 6
"Growths of flowers jut out form the sandy soil between deposits of stones and\
rocks, split here and there by wild game trails.  Copses of trees and small\
shrubs dot the landscape.\
",
// 7
"Dusty air and clouds of buzzing insects can be seen in the distance hovering\
over the fields and plains.  Scattered in the view are copses of small trees\
and shrubs.\
",
// 8
"Scattered patches of flowers and grains dot the rolling landscape as clouds of\
buzzing insects dart through the dusty air.  The grasses blow gently when the\
breeze picks up.\
",
// 9
"Swaying fields of brown grains and green grasses cover the sandy floor of the\
fields among patches of wildflowers and herbs.  Cospes of short trees and rough\
shrubs mingle in the sea of folliage.\
"
	},	
};

const char* hallDescriptions[MAX_BUILDING][8] = {
	{ },
	{ // BARRACKS
// FOYER
"A doorway to the north leads out of the barracks and into the wilderness.  The.\
foyer is sparsely decorated with various items of modest historical interest,\
and tributes to the triumphs and accomplishments of <%s>.\
",
// HP REGEN
"The medical ward of the barracks is stuffed with supplies to augment the\
healing process.  This comfortable room has an exit west to the foyer, and\
south to the Common Room.\
",
// MANA REGEN
"The meditation chamber is quiet and comfortable, well-insulated from the other,\
more noisy parts of the barracks.  The mind can be at ease here.  A door to the\
north leads to the foyer, and east of here is the Common Room.\
",
// COMMON ROOM
"A gathering space in the hall, the common room is a general lounge where clan\
members can relax and regale each other with tales of their exploits across the\
land.  To the north is the medical ward, and to the west is the meditation\
chamber.\
",
	},
};

