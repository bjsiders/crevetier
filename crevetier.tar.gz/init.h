/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#ifndef init_h
#define init_h

#include <stdio.h>
#include <stdlib.h>

#define INTEGER 1
#define STRING  2
#define PATH_SIZE       256
#define CONFIG_LINE_LEN 80
#define ARPENS_LINE_LEN 80
#define DEFAULT_INI		"arpens.ini"

typedef struct config_tag
{
    int     port;
    char    log_dir[PATH_SIZE];
    char    area_dir[PATH_SIZE];
    char    player_dir[PATH_SIZE];
    char    bin_dir[PATH_SIZE];
    char    board_dir[PATH_SIZE];
    char    data_dir[PATH_SIZE];
} config;

config  Config;

typedef struct config_type
{
    char    *param;
    int     type;
    void    *ptr;
} config_t;

extern	struct config_tag		Config;
extern	const struct config_type		param_config_table [];

#endif /* init_h */
