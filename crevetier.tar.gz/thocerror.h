#ifndef thocerror_h
#define thocerror_h

#include <stdarg.h>

#define THOCLOG_STRING 0
#define THOCLOG_BUG    1
#define THOCLOG_ERROR  2

void thoc_log( const char *fmt, va_list ap, int msg_type );
void log_string( const char *fmt, ... );
void log_bug( const char *fmt, ... );
void log_error( const char *fmt, ... );

#endif /* thocerror_h */
