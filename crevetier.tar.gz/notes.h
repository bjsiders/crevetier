#ifndef notes_h
#define notes_h

#define NOTE_NOTE       0
#define NOTE_IDEA       1
#define NOTE_PENALTY    2
#define NOTE_NEWS       3
#define NOTE_CHANGES    4
#define NOTE_BUG        5
#define NOTE_APPEAL     6
#define NOTE_ADMIN      7
#define NOTE_CLAN       8
#define NOTE_FIX        9
#define NOTE_TODO      10
#define NOTE_PATCH     11
#define NOTE_SYSTEM    12
#define NOTE_WORLD     13
#define NOTE_OFFLINE   14
#define MAX_NOTES      15

struct    note_data
{
    Note *      next;
    bool        valid;
    int         id;
    sh_int      type;
    char *      sender;
    char *      date;
    char *      to_list;
    char *      subject;
    char *      text;
    time_t      date_stamp;
};

#endif /* notes_h */
