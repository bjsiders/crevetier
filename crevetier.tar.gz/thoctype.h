/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

#ifndef thoctype_h
#define thoctype_h

typedef int                         sh_int;
typedef int                         bool;
typedef long long                   aflag_t;

typedef struct area_data            Area;
typedef struct account_data         Account;
typedef struct affect_data          Affect;
typedef struct alliance_data        Alliance;
typedef struct artifact_data        Artifact;
typedef struct buf_type             Buffer;
typedef struct building_data        Building;
typedef struct casting_data         Casting;
typedef struct char_data            Character;
typedef struct clan_data            Clan;
typedef struct descriptor_data      Descriptor;
typedef void   DoFun               (Character *ch,char *argument);
typedef struct exit_data            Exit;
typedef struct extra_descr_data     ExtraDescr;
typedef struct faction_type         Faction;
typedef struct faction_amount       FactionAmount;
typedef struct firing_data          Firing;
typedef struct help_data            Help;
typedef struct ignore_tag           Ignore;
typedef struct gen_data             NewbieData;
typedef struct pgroup_type          Group;
typedef struct journal_event        JEvent;
typedef struct journal              Journal;
typedef struct kill_data            KillInfo;
typedef struct melee_type           Melee;
typedef struct mem_data             NPCMemory;
typedef struct mob_index_data       MobIndex;
typedef struct note_data            Note;
typedef struct obj_data             Object;
typedef struct obj_index_data       ObjIndex;
typedef struct pc_data              PCData;
typedef struct quest_data           Quest;
typedef struct ranger_data          RangerData;
typedef struct rank_data            Rank;
typedef struct recipe_type          Recipe;
typedef struct resist_tag           Resist;
typedef struct natural_resources    Resource;
typedef struct _reuse_wait          Reuse_wait;
typedef struct room_index_data      Room;
typedef struct round_table_handler  Roundtable;
typedef struct round_table_pointers RtPointers;
typedef struct script_type          Script;
typedef struct script_index_type    ScriptIndex;
typedef struct shop_data            Shop;
typedef struct spawn_data           Spawn;
typedef bool   SPEC_FUN             (Character *ch);
typedef union  spell_action_union   SpellAction;
typedef bool   SpellFun            (int sn,int level,Character *ch,void *vo,int target);
typedef struct spell_aff_type       SpellAff;
typedef struct spell_index_data     SpellIndex;
typedef struct stack_type           Stack;
typedef bool   StyleFun             (Character *ch,Character *victim,int style);
typedef struct time_info_data       TimeInfo;
typedef struct track_data           Track;
typedef struct weather_data         Weather;

#endif /* __thoctype_h */
