/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

// Round table code by Andaron

#include <sys/types.h>
#include <sys/time.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <time.h>
#include "thoc.h"
#include "interp.h"
#include "recycle.h"
#include "tables.h"
#include "color.h"
#include "communicate.h"
#include "options.h"

const struct rt_type rt_command_table [];

void visible(Character *ch, char *argument, bool fEcho );
void quit( Character *ch, char *argument,bool fDelete );
void log_channel( Character *ch, int channel, char *argument );

/*Begin round table functions, there's a lot of them*/
bool can_see_imm(Character *ch, Character *imm)
{
    if( IS_IMMORTAL(imm) && ((imm->invis_level > ch->level) || 
       (imm->incog_level > ch->level && ch->in_room != imm->in_room)))
        return FALSE;
    else
        return TRUE;
}

/*(RT INFO) is used when someone else does something, and it's telling you*/
/*Removes someone from the round table list and closes it after them*/
/*Properly handles if they're active, in the list to speak, or just in the channel*/
/*This function does get pretty silly if they're the only person in the list, but it should still work*/
/*Add the class, level, race show when enabled*/
void rt_listRemove(Character *ch)
{
    //complete I believe
    Roundtable *handler = ch->pcdata->rtptrs.handler;
    if(handler->currentInLine == ch)
        handler->currentInLine = ch->pcdata->rtptrs.nextChar;
    if(handler->lastInLine == ch)
        handler->lastInLine = ch->pcdata->rtptrs.prevChar;
    ch->pcdata->rtptrs.prevChar->pcdata->rtptrs.nextChar = ch->pcdata->rtptrs.nextChar;
    ch->pcdata->rtptrs.nextChar->pcdata->rtptrs.prevChar = ch->pcdata->rtptrs.prevChar;
    ch->pcdata->rtptrs.nextChar = NULL;
    ch->pcdata->rtptrs.prevChar = NULL;
}

/*Adds people into the round table list*/
/*Handles inserting as current speaker, at an index inside the to speak list,
  at the beginning/end of the list, and just somewhere after all the people in the list*/

void rt_listAdd(Character *ch, int loc, int index)
{
    int i;
    Character *walker;
    Roundtable *handler = ch->pcdata->rtptrs.handler;

    if(loc==RTINDEXCURRENT)
    {
        //Insert instead of the current speaker, bump them back
        handler->currentInLine->pcdata->rtptrs.prevChar->pcdata->rtptrs.nextChar = ch;
        ch->pcdata->rtptrs.prevChar = handler->currentInLine->pcdata->rtptrs.prevChar;
        handler->currentInLine->pcdata->rtptrs.prevChar = ch;
        ch->pcdata->rtptrs.nextChar = handler->currentInLine;
        handler->currentInLine = ch;
        return;
    }

    if(loc==RTINDEXLAST)    //Insert at the end of the list to speak
    {
        handler->lastInLine->pcdata->rtptrs.nextChar->pcdata->rtptrs.prevChar = ch;
        ch->pcdata->rtptrs.nextChar = handler->lastInLine->pcdata->rtptrs.nextChar;
        handler->lastInLine->pcdata->rtptrs.nextChar = ch;
        ch->pcdata->rtptrs.prevChar = handler->lastInLine;
        handler->lastInLine = ch;
    }

    if(loc==RTINDEXMIDDLE)    //Insert at index people along the list to speak, or end if not enough
    {
        for(i = 1, walker = handler->currentInLine; i<index; walker = walker->pcdata->rtptrs.nextChar, i++ )
        {
            if(walker== handler->lastInLine)
            {
                rt_listAdd(ch, RTINDEXLAST, 0);
                return;
            }
        }
        if(walker == handler->currentInLine)
            rt_listAdd(ch, RTINDEXCURRENT, 0);
        else
        {
            walker->pcdata->rtptrs.prevChar->pcdata->rtptrs.nextChar = ch;
            ch->pcdata->rtptrs.prevChar = walker->pcdata->rtptrs.prevChar;
            walker->pcdata->rtptrs.prevChar = ch;
            ch->pcdata->rtptrs.nextChar = walker;
        }
    }

    if(loc==RTINDEXAFTER)    //Insert into the list after the last in line
    {
        handler->lastInLine->pcdata->rtptrs.nextChar->pcdata->rtptrs.prevChar = ch;
        ch->pcdata->rtptrs.nextChar = handler->lastInLine->pcdata->rtptrs.nextChar;
        handler->lastInLine->pcdata->rtptrs.nextChar = ch;
        ch->pcdata->rtptrs.prevChar = handler->lastInLine;
    }
}

void rt_messageAll(Character *ch, char *message, bool fMain)
{
    //Messages everyone in the round table except ch
    char buf[MAX_STRING_LENGTH], race_string[128], buf2[MAX_STRING_LENGTH];
    const char *class;
    Character *victim;

    for(victim = ch->pcdata->rtptrs.nextChar; victim != ch; victim = victim->pcdata->rtptrs.nextChar)
    {
        if(fMain)
        {
            if(ch->pcdata->rtptrs.handler->whoShown && can_see_imm(victim, ch))
            {
                class = class_table[ch->class].who_name;
                if ( IS_SET(victim->display,DISP_SHOW_SUBRACES) )
                    sprintf(race_string, "%s", ch->pcdata->subrace <= 0 ? "" : subrace_table[ch->pcdata->subrace].who_name);
                else
                    sprintf(race_string, "%s", pc_race_table[ch->race].who_name);

                sprintf(buf,"[%2d %s %s]",ch->level, race_string, class );

                if ( IS_IMMORTAL(ch) )
                {
                    switch ( ch->pcdata->imm_role )
                       {
                        default: break;
                        {
                            case IMM_ROLE_CODER:     sprintf(buf,"[     Coder     ]"); break;
                            case IMM_ROLE_ADMIN:     sprintf(buf,"[     Admin     ]"); break;
                            case IMM_ROLE_BUILDER:   sprintf(buf,"[    Builder    ]"); break;
                            case IMM_ROLE_AMBIENCE:  sprintf(buf,"[   Ambience    ]"); break;
                            case IMM_ROLE_DEVELOPER: sprintf(buf,"[   Developer   ]"); break;
                        }
                    }
                }
                sprintf(buf2, " $n rts '&%c%s&x'\n\r", IS_NPC(ch) ? 'x' : victim->pcdata->customRoundTableColor, message);
                strcat(buf, buf2);
            }
            else
                sprintf(buf, "$n rts '&%c%s&x'\n\r", IS_NPC(ch) ? 'x' : victim->pcdata->customRoundTableColor, message);
            act_ooc(buf, ch, NULL, victim, TO_VICT, POS_SLEEPING, TRUE);
        }
        else if(!(victim->pcdata->rtptrs.rtvalue & RTSUBOFF))//sub channel can be disabled
        {
            if(ch->pcdata->rtptrs.handler->whoShown)
            {
                class = class_table[ch->class].who_name;
                if ( IS_SET(victim->display,DISP_SHOW_SUBRACES) )
                    sprintf(race_string, "%s", ch->pcdata->subrace <= 0 ? "" : subrace_table[ch->pcdata->subrace].who_name);
                else
                    sprintf(race_string, "%s", pc_race_table[ch->race].who_name);

                sprintf(buf,"[%2d %s %s]",ch->level, race_string, class );

                if ( IS_IMMORTAL(ch)  && can_see_imm(victim, ch))
                {
                    switch ( ch->pcdata->imm_role )
                       {
                        default: break;
                        {
                            case IMM_ROLE_CODER:     sprintf(buf,"[     Coder     ]"); break;
                            case IMM_ROLE_ADMIN:     sprintf(buf,"[     Admin     ]"); break;
                            case IMM_ROLE_BUILDER:   sprintf(buf,"[    Builder    ]"); break;
                            case IMM_ROLE_AMBIENCE:  sprintf(buf,"[   Ambience    ]"); break;
                            case IMM_ROLE_DEVELOPER: sprintf(buf,"[   Developer   ]"); break;
                        }
                    }
                }
                sprintf(buf2, " $n subs '&%c%s&x'\n\r", IS_NPC(ch) ? 'x' : victim->pcdata->customRTSubColor, message);
                strcat(buf, buf2);
            }
            else
                sprintf(buf, "$n subs '&%c%s&x'\n\r", IS_NPC(ch) ? 'x' : victim->pcdata->customRTSubColor, message);
            act_ooc(buf, ch, NULL, victim, TO_VICT, POS_SLEEPING, TRUE);
        }
    }
}

Character* rt_checkInTable(Character *ch, char *victimName)
{
    Character *victim, *walker;
    if ( victimName[0] == '\0' )
    {
        //message for this will remain with the originating function
        return NULL;
    }

    //If the player isn't on, or you're trying to invite a mob
    if ( (victim =get_char_ooc(ch,victimName)) == NULL || IS_NPC(victim))
    {
        cprintf(ch,"(RT INFO) That character is not online.\n\r");
        return NULL;
    }

    for(walker = ch->pcdata->rtptrs.nextChar; walker != ch; walker = walker->pcdata->rtptrs.nextChar)
    {
        if(walker == victim)
            break;
    }

    if(walker != victim)
    {
        cprintf(ch,"(RT INFO) That character is not in this round table channel.\n\r");
        return NULL;
    }

    return walker;
}

void rtc_create(Character *ch, char *input, char *second, bool fOverRidden)
{
    //Complete, I believe
    char buf[MAX_STRING_LENGTH];
    if(ch->pcdata->rtptrs.handler)
    {
        /*assuming it's an error to have gotten here now, returning*/
        log_bug("rt_create called with a handler already created.", 0);
        return;
    }
    ch->pcdata->rtptrs.handler = (Roundtable*)GC_MALLOC(sizeof(Roundtable));
    ch->pcdata->rtptrs.nextChar = ch;
    ch->pcdata->rtptrs.prevChar = ch;
    ch->pcdata->rtptrs.rtvalue = RTLEADER;
    ch->pcdata->rtptrs.handler->allSquelched = 0;
    ch->pcdata->rtptrs.handler->rtSubPresent = 1;
    ch->pcdata->rtptrs.handler->whoShown = 0;
    ch->pcdata->rtptrs.handler->autoAccept = 0;
    ch->pcdata->rtptrs.handler->logged = 0;
    // Not currently implemented
    // ch->pcdata->rtptrs.handler->secret;
    ch->pcdata->rtptrs.handler->leader = ch;
    ch->pcdata->rtptrs.handler->currentInLine = ch;
    ch->pcdata->rtptrs.handler->lastInLine = ch;
    // Not implemented
    // Need way to get current time here
    ch->pcdata->rtptrs.handler->timeStarted = 1;
    ch->pcdata->rtptrs.handler->currentInLine = ch;
    ch->pcdata->rtptrs.handler->lastInLine = ch;
    ch->pcdata->rtptrs.handler->currentTalkTime = 0;
    ch->pcdata->rtptrs.rtvalue = 0;
    ch->pcdata->rtptrs.rtvalue |= RTINLINE;
    cprintf(ch, "(RT INFO) A round table has been created for you.\n\r");
    sprintf(buf, "%s has created a round table.",ch->name);
    wiznet(buf,NULL,NULL,WIZ_SECURE,0,0);
    return;
}

/*Logs exits, entrances, and main and sub channel conversation*/
void rtc_logging(Character *ch, char *input, char *second, bool fOverRidden)
{
    char buf[MAX_STRING_LENGTH], buf2[MAX_STRING_LENGTH];
    Character *walker;
    if(!IS_IMMORTAL(ch))
    {
        cprintf(ch, "Only imms may access this command.\n\r");
        return;
    }
    
    if(ch->pcdata->rtptrs.handler->logged)
    {
        cprintf(ch, "(RT INFO) Logging deactivated for the table.\n\r");
        ch->pcdata->rtptrs.handler->logged = 0;
        fprintf(ch->pcdata->rtptrs.handler->fp,
                        "\nLogging ended at %s.\n",
                        format_date( current_time, "%H:%M %d_%b_%y" ));
        fclose(ch->pcdata->rtptrs.handler->fp);
        ch->pcdata->rtptrs.handler->fp = NULL;
        if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
            cprintf(ch->pcdata->rtptrs.handler->leader,
                "(RT INFO) %s has deactivated logging of this channel.\n\r", ch->name);
        return;
    }
    else
    {
        snprintf(buf,sizeof(buf),"%s/%s_%s.log", 
            getDirectory(LOG_DIR), 
            ch->pcdata->rtptrs.handler->leader->name,
            format_date( current_time, "%H_%M_%d_%b_%y" ) );

        ch->pcdata->rtptrs.handler->fp = fopen(buf, "w");
        if(!ch->pcdata->rtptrs.handler->fp)
        {
            cprintf(ch, "(RT INFO) Logging has failed to create the log file for the round table.\n\r");
            return;
        }
        else
            cprintf(ch, "(RT INFO) Logging activated for the round table.\n\r");
        if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
            cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) %s has activated logging of this channel.\n\r", ch->name);
        snprintf(buf,sizeof(buf), "Logging began at %s.\n", format_date( current_time, "%H:%M %d_%b_%y" ));
        snprintf(buf2,sizeof(buf2), "Leader of this table is: %s\nOther members of this table:\n", ch->pcdata->rtptrs.handler->leader->name);
        strcat(buf, buf2);
        for(walker = ch->pcdata->rtptrs.nextChar; walker != ch; walker = walker->pcdata->rtptrs.nextChar)
        {
            snprintf(buf2,sizeof(buf2), "%s\n", walker->name);
            strcat(buf, buf2);
        }    
        strcat(buf, "\nBegin log of conversation.\n");
        fprintf(ch->pcdata->rtptrs.handler->fp, "%s", buf);
        ch->pcdata->rtptrs.handler->logged = 1;
        return;
    }
}

/*Passes leadership to someone else*/
void rtc_passcontrol(Character *ch, char *input, char *second, bool fOverRidden)
{
    //complete I believe
    Character *victim;
    if ( input == NULL || input[0] == '\0' )
    {
        //Pass it to the next person in the list
        ch->pcdata->rtptrs.handler->leader = ch->pcdata->rtptrs.nextChar;
        cprintf(ch->pcdata->rtptrs.nextChar, "(RT INFO) You are now the leader of the round table.\n\r");
        act_ooc("(RT INFO) You pass control of the round table off to $n.",
                ch->pcdata->rtptrs.nextChar, NULL,
                ch->pcdata->rtptrs.handler->leader, TO_VICT, POS_SLEEPING, TRUE);
        return;
    }

    if((victim = rt_checkInTable(ch, input)) == NULL)
        return;
    cprintf(victim, "(RT INFO) You are now the leader of the round table.\n\r");
    act_ooc("(RT INFO) You pass control of the round table off to $n.", 
                victim, NULL,
                ch->pcdata->rtptrs.handler->leader,
                TO_VICT, POS_SLEEPING, TRUE);

    if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
        cprintf(ch->pcdata->rtptrs.handler->leader, 
                "(RT INFO) $n has overridden you and passed control of the round table to %s.\n\r", victim->name);
    //wizi imm took control
    else if(fOverRidden)
        cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) Leadership of the table has been removed from you.\n\r");
    ch->pcdata->rtptrs.handler->leader = victim;
}

/*Adds someone to the list to speak*/
void rtc_add(Character *ch, char *input, char *second, bool fOverRidden)
{
    //Complete, I believe
    if(ch->pcdata->rtptrs.rtvalue & RTINLINE)
    {
        cprintf(ch, "(RT INFO) You're already in line to speak.\n\r");
        return;
    }
    if(ch->pcdata->rtptrs.rtvalue & RTBANNED)
    {
        cprintf(ch, "(RT INFO) You're banned from speaking on rt, you can't join the line.\n\r");
        return;
    }

    rt_listRemove(ch);
    ch->pcdata->rtptrs.rtvalue |= RTINLINE;
    rt_listAdd(ch, RTINDEXLAST, 0);
    cprintf(ch, "(RT INFO) You have been added to the line to speak.\n\r");
    /*Don't echo this if the leader adds themselves, they already know*/
    if(!(ch->pcdata->rtptrs.rtvalue & RTLEADER))
        act_ooc("(RT INFO) $n has added $mself to the list to speak.", ch, NULL, ch->pcdata->rtptrs.handler->leader, TO_VICT, POS_SLEEPING, TRUE);
}

void rtc_invite(Character *ch, char *input, char *second, bool fOverRidden)
{
    //complete, I believe
    Character *victim;

    if ( IS_SET(ch->comm, COMM_QUIET) )
    {
        cprintf(ch, "(RT INFO) You must turn off quiet mode first.\n\r");
        return;
    }

    if ( input[0] == '\0' )
    {
        cprintf(ch,"(RT INFO) Usage: rtc invite <character>\n\r");
        return;
    }

    //If the player isn't on, or you're trying to invite a mob
    if ( (victim =get_char_ooc(ch,input)) == NULL || IS_NPC(victim))
    {
        cprintf(ch,"(RT INFO) That character is not on-line.\n\r");
        return;
    }

    if (IS_SET(victim->comm,COMM_QUIET) && !IS_IMMORTAL(ch))
    {
        act( "(RT INFO) $E is quiet.", ch, 0, victim, TO_CHAR );
        return;
    }
    else if (IS_SET(victim->comm,COMM_QUIET) && IS_IMMORTAL(ch))
    {
        cprintf(ch, "(RT INFO) You have overridden a quiet setting for this character.\n\r");
    }

    if(victim->pcdata->rtptrs.handler)
    {
        /*If they have a handler, they're in a round tablee*/
        cprintf(ch, "(RT INFO) They're already in a round table channel.\n\r");
        return;
    }

    if(victim->pcdata->rtptrs.nextChar)
    {
        cprintf(ch, "(RT INFO) They're already invited to a round table channel.\n\r");
        return;
    }

    if ( isIgnoring( victim, !is_affected(ch,gsn_shapeshifting,AFF_SKILL) ? ch->name : ch->desc->original->name ) )
    {
        if ( !IS_IMMORTAL(ch) )
        {
            //Don't let 'em know they've been ignored
            act_ooc("(RT INFO) You invite $N to join your round table channel.", ch, NULL, victim, TO_CHAR, POS_SLEEPING, TRUE);
            return;
        }
        else
        {
            act("You bypassed an ignore setting for $N.",ch,NULL,victim,TO_CHAR);
        }
    }

    act_ooc("(RT INFO) $n invites you to join $s round table channel. (rtc accept to join)", ch, NULL, victim, TO_VICT, POS_SLEEPING, TRUE);
    act_ooc("(RT INFO) You invite $N to join your round table channel.", ch, NULL, victim, TO_CHAR, POS_SLEEPING, TRUE);
    if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
        cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) %s has invited %s to join your round table channel.", ch->name, victim->name);
    //victim->pcdata->rtptrs.rtvalue = RTINVITED;//Mark them as invited

    //Mark who invited them
    victim->pcdata->rtptrs.nextChar = ch->pcdata->rtptrs.handler->leader;
    return;
}

void rtc_accept(Character *ch, char *input, char *second, bool fOverRidden)
{
    //Finished, I think
    Character *victim = NULL;

    fOverRidden = FALSE;

    if(ch->pcdata->rtptrs.nextChar)
    {
        /* Find the character who invited this one */
        for( victim = char_list ; victim != NULL ; victim = victim->next )
            if ( victim == ch->pcdata->rtptrs.nextChar )
                break;
    }

    if(victim == NULL)
    {
        //Nobody invited you, or they have since logged off
        if ( input[0] == '\0' && ch->pcdata->rtptrs.nextChar == NULL)
        {
            cprintf(ch,"(RT INFO) Usage: rtc accept <character>\n\r");
            return;
        }

        /*If it's not NULL before, it has to be now for safety*/
        ch->pcdata->rtptrs.nextChar = NULL;
    
        //If the player isn't on, or you're trying to accept from a mob
        if ( (victim =get_char_ooc(ch,input)) == NULL || IS_NPC(victim))
        {
            cprintf(ch,"(RT INFO) That character is not on-line.\n\r");
            return;
        }

        /*You can accept channels with quiet on.  You just can't be invited to them*/
        /*This means auto-accept channels can be joined, or you get invited, go quiet, then accept*/

        if (!victim->pcdata->rtptrs.handler || victim->pcdata->rtptrs.handler->leader != victim)
        {
            /*victim doesn't have a round table they're the leader of*/
            act_ooc("(RT INFO) You haven't been invited to join $N's round table.", ch, NULL, victim, TO_CHAR, POS_SLEEPING, TRUE);
            return;
        }

        /*If it gets here, victim is leading a round table.  Check if they were invited or it's an auto-accept*/
        if(ch->pcdata->rtptrs.nextChar != victim && !victim->pcdata->rtptrs.handler->autoAccept)
        {
            if(IS_IMMORTAL(ch) && ch->level > victim->level)
                fOverRidden = TRUE;
            else
            {
                act_ooc("(RT INFO) You haven't been invited to join $N's round table.", ch, NULL, victim, TO_CHAR, POS_SLEEPING, TRUE);
                return;
            }
        }
    }

    /*They were invited, or it's auto accept*/
    ch->pcdata->rtptrs.handler = victim->pcdata->rtptrs.handler;
    rt_listAdd(ch, RTINDEXAFTER, 0);

    if(fOverRidden)
    {
        cprintf(ch, "(RT INFO) You have overridden %s.\n\r", victim->name);
        if(can_see_imm(victim, ch))
            cprintf(victim, "(RT INFO) %s overrode you and joined your table.\n\r", ch->name);
    }
    act_ooc("(RT INFO) You join $N's round table channel.", ch, NULL, victim, TO_CHAR, POS_SLEEPING, TRUE);
    if(can_see_imm(victim, ch))
        act_ooc("(RT INFO) $n has joined your round table channel.", ch, NULL, victim, TO_VICT, POS_SLEEPING, TRUE);
    if(ch->pcdata->rtptrs.handler->logged)
        fprintf(ch->pcdata->rtptrs.handler->fp, "(RT JOIN) %s joined the round table at %s.\n", ch->name, format_date( current_time, "%H:%M" ));
    return;
}

void rtc_decline(Character *ch, char *input, char *second, bool fOverRidden)
{
    Character *victim = NULL;

    if(ch->pcdata->rtptrs.nextChar)
    {
        /* Find the character who invited this one */
        for( victim = char_list ; victim != NULL ; victim = victim->next )
            if ( victim == ch->pcdata->rtptrs.nextChar )
                break;
    }
    if(victim)
    {
        cprintf(victim, "(RT INFO) %s declined your offer to join your round table.\n\r", ch->name);
        act_ooc("(RT INFO) You decline the offer from $N to join the round table.", ch, NULL, victim, TO_CHAR, POS_SLEEPING, TRUE);
    }
    else if(ch->pcdata->rtptrs.nextChar)
        cprintf(ch, "(RT INFO) Whoever invited you is no longer on.\n\r");
    else
        cprintf(ch, "(RT INFO) You can't decline an invitation to a round table you never received.\n\r");
    ch->pcdata->rtptrs.nextChar = NULL;
}

/*Removes a character (Themselves) from the line to speak*/
void rtc_remove(Character *ch, char *input, char *second, bool fOverRidden)
{
        //Complete, I believe
        if(!(ch->pcdata->rtptrs.rtvalue & RTINLINE))
        {
            cprintf(ch, "(RT INFO) You're already not in line to speak.\n\r");
            return;
        }

        if(ch->pcdata->rtptrs.handler->currentInLine == ch)
        {
            /*This person is currently active, they shouldn't remove themselves*/
            cprintf(ch, "(RT INFO) You're currently allowed to talk, use done to finish instead of remove.\n\r");
            return;
        }
        rt_listRemove(ch);
        ch->pcdata->rtptrs.rtvalue &= (RTMASK - RTINLINE);

        /*Add it in at the end of the list*/
        rt_listAdd(ch, RTINDEXAFTER, 0);

        /*Don't echo this if the leader adds themselves, they already know*/
        if(!(ch->pcdata->rtptrs.rtvalue & RTLEADER) || !can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
            act_ooc("(RT INFO) $n has removed $mself from the list to speak.", ch, NULL,
                        ch->pcdata->rtptrs.handler->leader, TO_VICT, POS_SLEEPING, TRUE);
}


void rtc_done(Character *ch, char *input, char *second, bool fOverRidden)
{
    Roundtable *handler = ch->pcdata->rtptrs.handler;
    if(handler->currentInLine != ch)
    {
        if(ch->pcdata->rtptrs.rtvalue & RTINLINE)
            cprintf(ch, "(RT INFO) You are not currently talking, use rtc remove to unlist yourself.\n\r");
        else
            cprintf(ch, "(RT INFO) You're not in the list to speak, you can't stop doing nothing.\n\r");
        return;
    }
    ch->pcdata->rtptrs.rtvalue &= (RTMASK - RTINLINE);
    cprintf(ch, "(RT INFO) You are now done speaking in the round table.\n\r");

    //why tell them if they know?
    if(handler->currentInLine != ch)
        act_ooc("(RT INFO) $n has finished speaking.", ch, NULL, handler->leader, TO_VICT, POS_SLEEPING, TRUE);
    handler->currentInLine = ch->pcdata->rtptrs.nextChar;
    if(ch == handler->lastInLine)
    {
        handler->currentInLine = handler->lastInLine = handler->leader;
        cprintf(handler->leader, "(RT INFO) None left in list to speak, you are now the list.\n\r");
        handler->leader->pcdata->rtptrs.rtvalue |= RTINLINE;
        return;
    }
    cprintf(handler->currentInLine, "(RT INFO) It is now your turn to speak in the round table. (rtc done to end)\n\r");

    //why tell them if they know?
    if(handler->currentInLine != handler->leader)
        act_ooc("(RT INFO) $n is now speaking.", handler->currentInLine, NULL, handler->leader, TO_VICT, POS_SLEEPING, TRUE);
}

void rtc_current(Character *ch, char *input, char *second, bool fOverRidden)
{
    //Complete I think
    cprintf(ch, "(RT INFO) %s is currently speaking.\n\r", ch->pcdata->rtptrs.handler->currentInLine->name);
}

/*Lists those who are in line to speak*/
void rtc_list(Character *ch, char *input, char *second, bool fOverRidden)
{
    //Complete, I think
    Character *victim;
    if(ch->pcdata->rtptrs.handler->leader == ch)
        cprintf(ch, "(RT INFO) Leader of this table is: %s\n\r", ch->name);
    else
        act_ooc("(RT INFO) Leader of this table is: $n.", ch->pcdata->rtptrs.handler->leader, NULL, ch, TO_VICT, POS_SLEEPING, TRUE);
    cprintf(ch, "First in the list is the current speaker.\n\r");
    for(victim = ch->pcdata->rtptrs.handler->currentInLine; victim != ch->pcdata->rtptrs.handler->lastInLine; victim = victim->pcdata->rtptrs.nextChar)
    {
        if(victim == ch)
            cprintf(ch, "%s\n\r", ch->name);
        else
            act_ooc("$n", victim, NULL, ch, TO_VICT, POS_SLEEPING, TRUE);
    }
    if(ch->pcdata->rtptrs.handler->lastInLine == ch)
        cprintf(ch, "%s\n\r\n\r", ch->name);
    else
        act_ooc("$n\n\r", ch->pcdata->rtptrs.handler->lastInLine, NULL, ch, TO_VICT, POS_SLEEPING, TRUE);
}

void rtc_listall(Character *ch, char *input, char *second, bool fOverRidden)
{
    //complete, I think
    Character *victim;
    if(ch->pcdata->rtptrs.handler->leader == ch)
        cprintf(ch, "(RT INFO) Leader of this table is: %s\n\rMembers:\n\r", ch->name);
    else
        act_ooc("(RT INFO) Leader of this table is: $n\n\rMembers:", ch->pcdata->rtptrs.handler->leader, NULL, ch, TO_VICT, POS_SLEEPING, TRUE);
    for(victim = ch->pcdata->rtptrs.nextChar; victim != ch; victim = victim->pcdata->rtptrs.nextChar)
    {
        if(can_see_imm(ch, victim))
            cprintf(ch, "%s\n\r", victim->name);
    }
    cprintf(ch, "%s\n\r\n\r", ch->name);
}

void rtc_exit(Character *ch, char *input, char *second, bool fOverRidden)
{
    //Complete, I think
    if(ch->pcdata->rtptrs.nextChar == ch)
    {
        //This is the only person left, destroy the rt
        if(ch->pcdata->rtptrs.handler->logged)
        {
            fprintf(ch->pcdata->rtptrs.handler->fp, "(RT EXIT) %s left the round table at %s.\n", ch->name, format_date( current_time, "%H:%M" ));
            rtc_logging(ch, input, second, fOverRidden);
        }
        ch->pcdata->rtptrs.nextChar = NULL;
        ch->pcdata->rtptrs.prevChar = NULL;
        ch->pcdata->rtptrs.rtvalue = 0;
        GC_FREE(ch->pcdata->rtptrs.handler);
        ch->pcdata->rtptrs.handler = NULL;
        cprintf(ch, "(RT INFO) You leave the round table.\n\r");
        return;
    }
    if(ch->pcdata->rtptrs.handler->logged)
        fprintf(ch->pcdata->rtptrs.handler->fp, "(RT EXIT) %s left the round table at %s.\n", ch->name, format_date( current_time, "%H:%M" ));
    if(ch->pcdata->rtptrs.handler->leader == ch)
        rtc_passcontrol(ch, NULL, NULL, FALSE);
    if(ch->pcdata->rtptrs.handler->currentInLine == ch)
        rtc_done(ch, NULL, NULL, FALSE);
    if(can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
        cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) %s leaves the round table.\n\r", ch->name);
    rt_listRemove(ch);
    ch->pcdata->rtptrs.rtvalue = 0;
    ch->pcdata->rtptrs.handler = NULL;
    cprintf(ch, "(RT INFO) You leave the round table.\n\r");
}

/*ADD REMOVES THEM FROM SPEAKING!!!!*/
void rtc_squelch(Character *ch, char *input, char *second, bool fOverRidden)
{
    Character *victim;

    if ( input[0] == '\0' )
    {
        cprintf(ch,"(RT INFO) Usage: rtc squelch <character>\n\r");
        return;
    }
    if((victim = rt_checkInTable(ch, input)) == NULL)
        return;

    //they are banned
    if(victim->pcdata->rtptrs.rtvalue & RTBANNED)
    {
        //unban them
        victim->pcdata->rtptrs.rtvalue &= (RTMASK - RTBANNED);
        cprintf(ch, "(RT INFO) You unsquelch %s from talking.\n\r", victim->name);
        cprintf(victim, "(RT INFO) You have been unsquelched on the rt channel, you may participate again.\n\r");
        if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
            cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) %s overrode you and unsquelched %s.\n\r", ch->name, victim->name);
    }
    else
    {
        //ban them
        victim->pcdata->rtptrs.rtvalue |= RTBANNED;
        cprintf(ch, "(RT INFO) You squelch %s from talking.\n\r", victim->name);
        cprintf(victim, "(RT INFO) You have been squelched on the rt channel, you may no longer participate.\n\r");
        if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
            cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) %s overrode you and squelched %s.\n\r", ch->name, victim->name);
        if(victim->pcdata->rtptrs.rtvalue & RTINLINE)
        {
            if(victim->pcdata->rtptrs.handler->currentInLine == victim)
                rtc_done(victim, NULL, NULL, FALSE);
            else
                rtc_remove(victim, NULL, NULL, FALSE);
        }
    }
}

void rtc_squelchsub(Character *ch, char *input, char *second, bool fOverRidden)
{
    Character *victim;

    if ( input[0] == '\0' )
    {
        cprintf(ch,"(RT INFO) Usage: rtc squelch <character>\n\r");
        return;
    }
    if((victim = rt_checkInTable(ch, input)) == NULL)
        return;

    //they are banned
    if(victim->pcdata->rtptrs.rtvalue & RTSUBBANNED)
    {
        //unban them
        victim->pcdata->rtptrs.rtvalue &= (RTMASK - RTSUBBANNED);
        cprintf(ch, "(RT INFO) You unsquelch %s from talking.\n\r", victim->name);
        cprintf(victim, "(RT INFO) You have been unsquelched on the rt sub channel, you may participate again.\n\r");
        if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
            cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) %s overrode you and unsquelched %s on rt sub.\n\r", ch->name, victim->name);
    }
    else
    {
        //ban them
        victim->pcdata->rtptrs.rtvalue |= RTSUBBANNED;
        cprintf(ch, "(RT INFO) You squelch %s from talking.\n\r", victim->name);
        cprintf(victim, "(RT INFO) You have been squelched on the rt sub channel, you may no longer participate.\n\r");
        if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
            cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) %s overrode you and squelched %s on rt sub.\n\r", ch->name, victim->name);
    }
}


/*Moves someone in the list.*/
void rtc_ordername(Character *ch, char *input, char *second, bool fOverRidden)
{
    int count;    
    Character *victim, *replace, *walker;

    if ( input[0] == '\0' || second[0] == '\0')
    {
        cprintf(ch,"(RT INFO) Usage: rtc orderame <character> <character to place ahead of>\n\r");
        return;
    }
    if((victim = rt_checkInTable(ch, input)) == NULL)
        return;
    if((replace = rt_checkInTable(ch, second)) == NULL)
        return;

    if(victim == replace)
    {
        cprintf(ch, "(RT INFO) You can't move someone ahead of themselves.\n\r");
        return;
    }
    rt_listRemove(victim);
    count = 1;
    for(walker = ch->pcdata->rtptrs.handler->currentInLine; walker != ch->pcdata->rtptrs.handler->lastInLine; walker=walker->pcdata->rtptrs.nextChar)
    {
        if(walker == replace)
            break;
        count++;
    }
    if(replace == ch->pcdata->rtptrs.handler->currentInLine)
        act_ooc("(RT INFO) $n is now speaking, you are behind $m now.", victim, NULL, replace, TO_VICT, POS_SLEEPING, TRUE);
    rt_listAdd(victim, RTINDEXMIDDLE, count);
    victim->pcdata->rtptrs.rtvalue |= RTINLINE;
    cprintf(ch, "(RT INFO) %s has been moved in the list.\n\r", victim->name);
    cprintf(victim, "(RT INFO) You have been moved in the list.\n\r");
    if(victim == ch->pcdata->rtptrs.handler->currentInLine)
        cprintf(victim, "(RT INFO) It is now your turn to speak. (rtc done to end)\n\r");

    if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
        cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) %s overrode you and moved %s in the list.\n\r", ch->name, victim->name);
}

void rtc_ordernumber(Character *ch, char *input, char *second, bool fOverRidden)
{
    Character *victim;

    if ( input[0] == '\0' || second[0] == '\0'  || !is_number(second))
    {
        cprintf(ch,"(RT INFO) Usage: rtc ordernumber <character> <new number in list>\n\r");
        return;
    }
    if((victim = rt_checkInTable(ch, input)) == NULL)
        return;

    rt_listRemove(victim);
    rt_listAdd(victim, RTINDEXMIDDLE, atoi(second));
    victim->pcdata->rtptrs.rtvalue |= RTINLINE;
    cprintf(ch, "(RT INFO) %s has been moved in the list.\n\r", victim->name);
    cprintf(victim, "(RT INFO) You have been moved in the list.\n\r");
    if(victim == ch->pcdata->rtptrs.handler->currentInLine)
    {
        cprintf(victim, "(RT INFO) It is now your turn to speak. (rtc done to end)\n\r");
        act_ooc("(RT INFO) $n is now speaking, you are behind $m now.", victim, NULL, victim->pcdata->rtptrs.nextChar, TO_VICT, POS_SLEEPING, TRUE);
    }

    if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
        cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) %s overrode you and moved %s in the list.\n\r", ch->name, victim->name);
}

/*Forcibly removes someone from the round table*/
void rtc_kick(Character *ch, char *input, char *second, bool fOverRidden)
{
    Character *victim;

    if ( input[0] == '\0')
    {
        cprintf(ch,"(RT INFO) Usage: rtc kick <character>\n\r");
        return;
    }
    if((victim = rt_checkInTable(ch, input)) == NULL)
        return;

    if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
        cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) %s has overridden you and kicked %s out of the round table.\n\r", ch->name, victim->name);

    cprintf(ch, "(RT INFO) %s has been kicked out of the round table.\n\r", victim->name);
    cprintf(victim, "(RT INFO) You have been kicked out of the round table.\n\r");
    rtc_exit(victim, NULL, NULL, FALSE);
}

void rtc_allsquelched(Character *ch, char *input, char *second, bool fOverRidden)
{
    //complete I believe
    Character *walker;
    if(ch->pcdata->rtptrs.handler->allSquelched)
    {
        cprintf(ch, "(RT INFO) People will now be able to always talk on rtable.\n\r");
        if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
            cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) %s has overridden you and turned allsquelched off.\n\r", ch->name);
        ch->pcdata->rtptrs.handler->allSquelched = 0;
        for(walker = ch->pcdata->rtptrs.nextChar; walker != ch; walker = walker->pcdata->rtptrs.nextChar)
        {
            cprintf(walker, "(RT INFO) You do not have to add yourself to the list to be able to speak now.\n\r");
        }
    }
    else
    {
        cprintf(ch, "(RT INFO) People will now need to be in the list to talk on rtable.\n\r");
        if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
            cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) %s has overridden you and turned allsquelched on.\n\r", ch->name);
        ch->pcdata->rtptrs.handler->allSquelched = 1;
        for(walker = ch->pcdata->rtptrs.nextChar; walker != ch; walker = walker->pcdata->rtptrs.nextChar)
        {
            cprintf(walker, "(RT INFO) You must now add yourself to the list to be able to speak.\n\r");
        }
    }

}

void rtc_subpresent(Character *ch, char *input, char *second, bool fOverRidden)
{
    //complete I believe
    if(ch->pcdata->rtptrs.handler->rtSubPresent == 0)
    {
        cprintf(ch, "(RT INFO) The rtsub channel has been enabled.\n\r");
        if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
            cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) %s has overridden you and turned rtsub on.\n\r", ch->name);
        ch->pcdata->rtptrs.handler->rtSubPresent = 1;
    }
    else
    {
        cprintf(ch, "(RT INFO) The rtsub channel has been disabled.\n\r");
        if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
            cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) %s has overridden you and turned rtsub off.\n\r", ch->name);
        ch->pcdata->rtptrs.handler->rtSubPresent = 0;
    }
}

void rtc_whoshown(Character *ch, char *input, char *second, bool fOverRidden)
{
    //complete I believe
    if(ch->pcdata->rtptrs.handler->whoShown == 0)
    {
        cprintf(ch, "(RT INFO) A char's who info will be shown when they talk now.\n\r");
        if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
            cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) %s has overridden you and turned whoshown on.\n\r", ch->name);
        ch->pcdata->rtptrs.handler->whoShown = 1;
    }
    else
    {
        cprintf(ch, "(RT INFO) A char's who info will not be shown when they talk now.\n\r");
        if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
            cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) %s has overridden you and turned whoshown off.\n\r", ch->name);
        ch->pcdata->rtptrs.handler->whoShown = 0;
    }
}

void rtc_autoaccept(Character *ch, char *input, char *second, bool fOverRidden)
{
    //complete I believe
    if(ch->pcdata->rtptrs.handler->autoAccept == 0)
    {
        cprintf(ch, "(RT INFO) People will be automatically accepted to the table now.\n\r");
        if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
            cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) %s has overridden you and turned autoaccept on.\n\r", ch->name);
        ch->pcdata->rtptrs.handler->autoAccept = 1;
    }
    else
    {
        cprintf(ch, "(RT INFO) People will not be automatically accepted to the table now.\n\r");
        if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
            cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) %s has overridden you and turned autoaccept off.\n\r", ch->name);
        ch->pcdata->rtptrs.handler->autoAccept = 0;
    }
}


/*Displays the settings the round table has*/
void rtc_showsettings(Character *ch, char *input, char *second, bool fOverRidden)
{
    Roundtable *handler = ch->pcdata->rtptrs.handler;

    if(fOverRidden && can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
        cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) %s has checked the settings of the table.\n\r", ch->name);

    cprintf(ch, "(RT INFO) These are the settings for this round table:\n\r");

    if(handler->autoAccept)
        cprintf(ch, "(autoaccept) Characters may automatically join your round table.\n\r");
    else
        cprintf(ch, "(autoaccept) Characters must be invited to join your round table.\n\r");
    
    if(handler->rtSubPresent)
        cprintf(ch, "(subpresent) The sub channel is currently enabled.\n\r");
    else
        cprintf(ch, "(subpresent) The sub channel is currently disabled.\n\r");

    if(handler->allSquelched)
        cprintf(ch, "(allsquelched) It must be your turn to speak before you can.\n\r");
    else
        cprintf(ch, "(allsquelched) Anyone may speak at any time.\n\r");

    if(handler->whoShown)
        cprintf(ch, "(whoshown) Who data will be shown for speakers.\n\r");
    else
        cprintf(ch, "(whoshown) Who data will not be shown for speakers.\n\r");

    if(IS_IMMORTAL(ch))
    {
        if(handler->logged)
            cprintf(ch, "(logging) Logging is active.\n\r");
        else
            cprintf(ch, "(logging) Logging is not active.\n\r");
    }
}


int rt_lookup( const char *verb )
{
    //Complete, I believe
    int i;

    for( i = 0 ; rt_command_table[i].name != NULL ; i++ )
    {
        if ( rt_command_table[i].name[0] == verb[0] &&
             !str_prefix(verb,rt_command_table[i].name) )
            return i;
    }

    return -1;
}

void do_rtcommand(Character *ch, char *argument)
{
    /*Process setup commands*/
    //Complete, I believe
    char    verb[MAX_INPUT_LENGTH];
    char    subj[MAX_INPUT_LENGTH];
    int        rtc;
    bool fOverRide = FALSE;

    argument = one_argument_cs( argument, verb );
    argument = one_argument_cs( argument, subj );

    if ( verb[0] == '\0' || (rtc = rt_lookup(verb)) < 0 )    
    {
        //Listed here as a comment for the code
        cprintf(ch, "(RT INFO) Commands for the round table channel:\n\r");
        cprintf(ch, "  Message Syntax: &Wrt&x <message> (or &Wroundtable&x)\n\r  Sub Message Syntax: &Wsub&x <message> (If enabled)\n\r  Command Syntax: &Wrtcommand&x &R<command>&x\n\r\n\r");
        cprintf(ch, "  &R<command>&x consists of the following options:\n\r");
        cprintf(ch, "&R<command>&xs for outside of the round table:\n\r");
        cprintf(ch, "  &Rcreate&x: Create a round table channel for yourself.\n\r");
        cprintf(ch, "  &Raccept&x: Accept an invite to a round table, or use to join an autoaccept one.\n\r");
        cprintf(ch, "  &Rdecline&x: Turn down an invitation to join a round table.\n\r");
        cprintf(ch, "\n\r&R<command>&xs for use while in the round table:\n\r");
        cprintf(ch, "  &Radd&x: Add yourself to the list to speak.\n\r");
        cprintf(ch, "  &Rremove&x: Remove yourself from the list to speak.\n\r");
        cprintf(ch, "  &Rdone&x: Finish speaking, if you were the current speaker.\n\r");
        cprintf(ch, "  &Rlist&x: Show the list of people in line to speak.\n\r");
        cprintf(ch, "  &Rlistall&x: Show the list of people in the channel.\n\r");
        cprintf(ch, "  &Rcurrent&x: Show who's currently speaking.\n\r");
        cprintf(ch, "  &Rexit&x: Leave this round table channel.\n\r");
        cprintf(ch, "\n\rLeader only &R<command>&xs:\n\r");
        cprintf(ch, "  &Rinvite&x: Invite a character to your round table.\n\r");
        cprintf(ch, "  &Rsquelch&x: Force a character to be silent on the rt channel.\n\r");
        cprintf(ch, "  &Rsquelchsub&x: Force a character to be silent on the rtextra channel.\n\r");
        cprintf(ch, "  &Rordernumber&x <name> <number>: Move <name> in the list above character of <number>.\n\r");
        cprintf(ch, "  &Rordername&x <name> <name2>: Move <name> in the list above character of <name2>.\n\r");
        cprintf(ch, "  &Rkick&x <name>: Kick a character out of your round table.\n\r");
        cprintf(ch, "  &Rallsquelched&x: Toggle whether people can all talk on rt or must use the list.\n\r");
        cprintf(ch, "  &Rsubpresent&x: Toggle the sub channel on or off.\n\r");
        cprintf(ch, "  &Rautoaccept&x: Toggle autoaccept. If on, players can invite themselves to join.\n\r");
        cprintf(ch, "  &Rshowsettings&x: Shows how the toggles are currently set.\n\r");
        cprintf(ch, "  &Rpasscontrol&x <name>: Passes leadership of the round table to <name>.\n\r");
        cprintf(ch, "  &Rwhoshown&x: Toggle whether who information is put in front of character name in rt.\n\r");
        if(IS_IMMORTAL(ch))
            cprintf(ch, "  &Rlogging&x: Toggles logging of this channel to a log file. (Imm only)\n\r");
    }
    // do_help(ch,"rtcommand");
    else            
    {
        if (rt_command_table[rtc].status == RT_CREATE && ch->pcdata->rtptrs.handler)
        {
            cprintf(ch, "(RT INFO) Leave your current round table with 'rtc exit' before doing that.\n\r");
            return;
        }
        else if(rt_command_table[rtc].status == RT_ANYONE && ch->pcdata->rtptrs.handler == NULL)
        {
            cprintf(ch, "(RT INFO) You must be in a round table channel to do that.\n\r");
            return;
        }
        else if(rt_command_table[rtc].status == RT_LEADER && (ch->pcdata->rtptrs.handler == NULL || ch->pcdata->rtptrs.handler->leader != ch))
        {
            //RT_LEADER
            if(IS_IMMORTAL(ch) && ch->pcdata->rtptrs.handler && ch->level > ch->pcdata->rtptrs.handler->leader->level)
            {
                //An immortal has overridden a command here
                fOverRide = TRUE;
                cprintf(ch, "(RT INFO) You are issuing a command over the leader's head.\n\r");
                if(can_see_imm(ch->pcdata->rtptrs.handler->leader, ch))
                    cprintf(ch->pcdata->rtptrs.handler->leader, "(RT INFO) An immortal has issued a command.\n\r");
            }
            else
            {
                cprintf(ch, "(RT INFO) Only the leader of a round table channel can do that.\n\r");
                return;
            }
        }
        (*rt_command_table[rtc].rt_fun)(ch,subj,argument,fOverRide);
    }

    return;

/*    if( argument[0] == '\0' || !_stricmp(argument, "list"))
    {
        if(!ch->pcdata->rtptrs.handler)
        {
            cprintf("ch, You must be in a round table channel to use rtcommand.\n\r");
            return;
        }
        cprintf(ch, "Commands for the round table channel:\n\r");
        cprintf(ch, "Syntax: rt <message>\n\rSyntax: rtcommand <command>\n\rSyntax: rtextra <message> (If enabled)\n\r\n\r");
        cprintf(ch, "<command> consists of the following options:\n\r");
        cprintf(ch, "  add: Add yourself to the list to speak.\n\r");
        cprintf(ch, "  remove: Remove yourself from the list to speak.\n\r");
        cprintf(ch, "  list: Show the list of people in line to speak.\n\r");
        cprintf(ch, "  current: Show who's currently speaking, and how much time they have left.\n\r");
        cprintf(ch, "  exit: Leave this round table channel.\n\r");
        if(ch->pcdata->rtptrs.handler->leader == ch || ch->level > 51) //They're the leader
        {
            cprintf(ch, "\n\rLeader commands:\n\r");
            cprintf(ch, "  invite: Invite a character to your round table.\n\r");
            cprintf(ch, "  squelch: Force a character to be silent on the rt channel.\n\r");
            cprintf(ch, "  squelchsub: Force a character to be silent on the rtextra channel.\n\r");
            cprintf(ch, "  order <name> <number>: Move <name> in the list above character of <number>.\n\r");
            cprintf(ch, "  order <name> <name2>: Move <name> in the list above character of <name2>.\n\r");
            cprintf(ch, "  kick <name>: Kick a character out of your round table.\n\r");
            cprintf(ch, "  allsquelched: Toggle whether people can all talk on rt or must use the list.\n\r");
            cprintf(ch, "  rtextrapresent: Toggle rtextra on or off.\n\r");
//          cprintf(ch, "  secret: Player name doesn't show when talking on rt.\n\r"); *** Not currently enabled*/
/*            cprintf(ch, "  autoaccept: If autoaccept is on, players can invite themselves to join.\n\r");
            cprintf(ch, "  showsettings: Shows how the toggles are currently set.\n\r");
        }
        return;
    }*///This will go in a helpfile, not in rt command
}

//This is the actual channel
void do_rt(Character *ch, char *argument)
{
    Roundtable *handler = ch->pcdata->rtptrs.handler;
    if(handler == NULL)
    {
        cprintf(ch, "You must be in a round table to talk on the channel.\n\r");
        return;
    }

    if(ch->pcdata->rtptrs.rtvalue & RTBANNED)
    {
        cprintf(ch, "You have been banned from talking on the rt channel.\n\r");
        return;
    }

    if(handler->allSquelched && ch != handler->leader && !(ch->pcdata->rtptrs.rtvalue & RTINLINE))
    {
        cprintf(ch, "You're not even in line to talk, use rtc add to join the line.\n\r");
        return;
    }

    if(handler->allSquelched && ch != handler->leader && ch != handler->currentInLine)
    {
        cprintf(ch, "It's not your turn to talk yet.\n\r");
        return;
    }

    if(argument[0] == '\0')
    {
        cprintf(ch, "rt what?\n\r");
        return;
    }

    if(ch->level < 55)
        stripColorInline(argument);
    cprintf(ch, "You rt '&%c%s&x'\n\r",IS_NPC(ch) ? 'x' : ch->pcdata->customRoundTableColor, argument);

    rt_messageAll(ch, argument, TRUE);

    if(ch->pcdata->rtptrs.handler->logged)
        fprintf(ch->pcdata->rtptrs.handler->fp, "(RT MESSAGE) [%s] %s rts %s\n", format_date( current_time, "%H:%M" ), ch->name, argument);
}

void do_sub(Character *ch, char *argument)
{
    Roundtable *handler = ch->pcdata->rtptrs.handler;
    if(handler == NULL)
    {
        cprintf(ch, "You must be in a round table to talk on the sub channel.\n\r");
        return;
    }

    if(!handler->rtSubPresent)
    {
        cprintf(ch, "The rt sub channel is disabled currently.\n\r");
        return;
    }

    if(ch->pcdata->rtptrs.rtvalue & RTSUBBANNED)
    {
        cprintf(ch, "You have been banned from talking on the rt sub channel.\n\r");
        return;
    }

    if(argument[0] == '\0')
    {
        //disable the sub channel
        if(ch->pcdata->rtptrs.rtvalue & RTSUBOFF)
        {
            cprintf(ch, "You enable your sub channel.\n\r");
            ch->pcdata->rtptrs.rtvalue &= (RTMASK - RTSUBOFF);
            return;
        }
        else
        {
            cprintf(ch, "You disable your sub channel.\n\r");
            ch->pcdata->rtptrs.rtvalue |= RTSUBOFF;
            return;
        }
    }

    ch->pcdata->rtptrs.rtvalue &= (RTMASK - RTSUBOFF);
    
    if(ch->level < 55)
        stripColorInline(argument);
    cprintf(ch, "You sub '&%c%s&x'\n\r",IS_NPC(ch) ? 'x' : ch->pcdata->customRTSubColor, argument);

    rt_messageAll(ch, argument, FALSE);

    if(ch->pcdata->rtptrs.handler->logged)
        fprintf(ch->pcdata->rtptrs.handler->fp, "(SUB MESSAGE) [%s] %s rts %s\n", format_date( current_time, "%H:%M" ), ch->name, argument);
}

