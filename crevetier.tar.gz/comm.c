/***************************************************************************
 The Heirs of Crevetier
 Copyright 2002-2003 Benjamin J. Siders
 $Name: crev-1-11-414 $

 Distributed without warranty or promises.  This code is highly customized 
 for one specific implementation, and it is not generic nor compatible with 
 standard ROM area files.  It also uses Boehm's garbage collector (not 
 included).

 This is the 1.10 version of THOC, an ever-improving code base for the MUD of
 the same name.  The various systems are based loosely on ArpensMUD 4.0, one
 of several iterations of improvements on top of ROM.  You are free to use 
 this code to your heart's content under the limitations laid out in the file
 Thoc.license, included in this distribution.

 Benjamin J. Siders (James)
 Todd D. Degani (Shadowlord)
 Charles J. Royalty (Andaron)
 Jerry Gilyeat
****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Thanks to abaddon for proof-reading our comm.c and pointing out bugs.  *
 *  Any remaining bugs are, of course, our work, not his.  :)              *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

/***************************************************************************
*    ROM 2.4 is copyright 1993-1998 Russ Taylor                            *
*    ROM has been brought to you by the ROM consortium                     *
*        Russ Taylor (rtaylor@hypercube.org)                               *
*        Gabrielle Taylor (gtaylor@hypercube.org)                          *
*        Brian Moore (zump@rom.org)                                        *
*    By using this code, you have agreed to follow the terms of the        *
*    ROM license, in the file Rom24/doc/rom.license                        *
***************************************************************************/

#include <sys/types.h>
#include <sys/time.h>
#include <stdarg.h>    /* va_list, etc */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>

#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include "telnet.h"
#include "thoc.h"
#include "interp.h"
#include "recycle.h"
#include "color.h"
#include "tables.h"
#include "olc.h"
#include "init.h"
#include "journal.h"
#include "magic.h"
#include "options.h"

struct game_info    GameInfo;
struct config_tag   Config;
Character           *ArpensMUD;
bool                fCrashing = FALSE;

/*
 * Global variables.
 */
const char echo_off_str [] = { IAC, WILL, TELOPT_ECHO, '\0' };
const char echo_on_str  [] = { IAC, WONT, TELOPT_ECHO, '\0' };
const char go_ahead_str [] = { IAC, GA, '\0' };

Descriptor *descriptor_list;    /* All open descriptors            */
Descriptor *d_next;             /* Next descriptor in loop         */
FILE *      fpReserve;          /* Reserved file handle            */
FILE *      fpChannel;          /* Channel logs to cover our ass   */
bool        god;                /* All new chars are gods!         */
bool        merc_down;          /* Shutdown                        */
FILE *      SpawnFile;          /* Spawn logging                   */
bool        wizlock;            /* Game is wizlocked               */
bool        pk_enabled;         
bool        loot_enabled;
int         global_port;        /* Port we're on                   */
int         global_control;     /* listen socket                   */
int         webSocket = -1;
int			clientSocket = -1;  /* used by java client peers	*/
bool        cycle = FALSE;
bool        newlock;            /* Game is newlocked               */
char        str_boot_time[MAX_INPUT_LENGTH];
time_t      boot_time;
time_t      current_time;       /* time of this pulse              */    
int         refresh_pulse=-1;

int     create_cmd_lookup       ( const char *arg );
void    process_creation        ( Descriptor *d, char *argument );
void    creation_screen         ( Character *ch );
void    creation_menu           ( Character *ch );
void    print_race_list         ( Descriptor *d );
void    save_race_avail         ( void );
void    load_building_file      ( void );
void    load_resource_file      ( void );
void    load_race_avail         ( void );
int     loadRefreshFile         ( void );
void    write_to_buffer_noexp   ( Descriptor *d, const char *arg, int length );
void    game_loop               ( int control );
int     init_socket             ( int port );
void    init_descriptor         ( int control );
bool    read_from_descriptor    ( Descriptor *d );
bool    write_to_descriptor     ( int desc, char *txt, int length );
char*   translateVersion        ( void );
void    read_configuration      ( const char *filename );
void    menu                    ( Descriptor * );
void    install_signal_handlers ( void );
void    arpens_sig_handler      ( int i );
bool    check_parse_name        ( char *name );
bool    check_being_created_name( char *name );
bool    check_reconnect         ( Descriptor *d, char *name, bool fConn );
bool    check_playing           ( Descriptor *d, char *name );
void    nanny                   ( Descriptor *d, char *argument );
bool    process_output          ( Descriptor *d, bool fPrompt );
void    read_from_buffer        ( Descriptor *d );
void    stop_idling             ( Character *ch );
void    bust_a_prompt           ( Character *ch );
void    finish_crafting         ( Character *ch );
void    display_group_monitor   ( Character *ch );
void    initiate_refresh        ( void );

/* MXP functions */
int count_mxp_tags (const int bMXP, const char *txt, int length);
void convert_mxp_tags (const int bMXP, char * dest, const char *src, int length);
void turn_on_mxp (Descriptor *d);

#define CRASH_MSG "The Heirs of Crevetier has crashed.  Your pfile is being saved.\n\r"

/* MXP */
#define  TELOPT_MXP        '\x5B'

const unsigned char will_mxp_str  [] = { IAC, WILL, TELOPT_MXP, '\0' };
const unsigned char start_mxp_str [] = { IAC, SB, TELOPT_MXP, IAC, SE, '\0' };
const unsigned char do_mxp_str    [] = { IAC, DO, TELOPT_MXP, '\0' };
const unsigned char dont_mxp_str  [] = { IAC, DONT, TELOPT_MXP, '\0' };

void alarm_handler( int signo )
{
    return;
}

void sig_hdl( int signo )
{
    extern    char *last_char, *last_cmd;   
    extern    bool fCrashing;
    static int go_count;
    Descriptor *d;

    fCrashing = TRUE;

    /* Save us from infinite handler calls. */
    if ( ++go_count > 10 )
        abort();

    for( d = descriptor_list ; d ; d = d->next )
    {
        write(d->descriptor,CRASH_MSG,strlen(CRASH_MSG));
        if ( d->character && d->character->level >= 53 )
        {
            char buf[1024];

            snprintf(buf,sizeof(buf),"Last command: %s by %s\n\r", last_cmd, last_char );
            log_string(buf);
            write(d->descriptor,buf,strlen(buf));
        }

        if ( d->connected == CON_PLAYING && d->character != NULL && !IS_NPC(d->character))
        {
            if(d->character->pcdata->rtptrs.handler && d->character->pcdata->rtptrs.handler->logged)
                rtc_logging(d->character, NULL, NULL, FALSE);
            save_char_obj( d->character );
        }
    }
    log_string("THOC has crashed with signal %d.  Aborting gracefully.\n\r",signo);
    save_clans();
    save_vaults( );
    write_building_file( );
    abort();
}
    
int main( int argc, char **argv )
{
    struct timeval now_time;
    int port;
    int control = 0;
    bool fRefresh = FALSE;

    print_version = translateVersion( );
#if !defined(WITHPK)
    pk_enabled = FALSE;
#else
    pk_enabled = TRUE;
#endif
#if !defined(WITHLOOT)
    loot_enabled = FALSE;
#else
    loot_enabled = TRUE;
#endif
    /* Set up some rudimentary signal handling */
#if !defined(NOSIGHANDLE)
    /*signal( SIGBUS, sig_hdl );
    signal( SIGSEGV, sig_hdl );
    signal( SIGFPE, sig_hdl );*/
#endif
    /* Set up our loglabel */
#if defined(__ARPENS)
    setenv("THOC_LOGLABEL","arpens",0);
#elif defined(__OLC)
    setenv("THOC_LOGLABEL","olc",0);
#elif defined(__TEST)
    setenv("THOC_LOGLABEL","test",0);
#else
    setenv("THOC_LOGLABEL","thoc",0);
    log_string("No valid game type!");
#endif
    /* Create the 'ArpensMUD' character to post notes with */
    initFalseCharacter( );
    /*
     * Load configuration file
     * Disabled currently.
     */

    /*
    if ( argc < 3 )
        read_configuration( DEFAULT_INI );
    */
    /* Set up data for the 'lastlogin' command */
    initLastLogin( );
    read_configuration( ARPENS_FILE );
    /*
     * Init time.
     */
    gettimeofday( &now_time, NULL );
    current_time     = (time_t) now_time.tv_sec;
    strcpy( str_boot_time, ctime( &current_time ) );
    boot_time        = current_time;
    /*
     * Reserve one channel for our use.
     */
    if ( ( fpReserve = fopen( NULL_FILE, "r" ) ) == NULL )
    {
        log_error( NULL_FILE );
        exit( 1 );
    }
    if ( ( fpChannel = fopen( CHANNEL_FILE, "a" ) ) == NULL )
    {
        log_error( CHANNEL_FILE );
        exit( 1 );
    }
    /*
     * Get the port number.
     * Default depends on service name.
     */
    {
        struct servent *sptr;
    
        sptr = getservbyname( SERVICE_NAME, "tcp" );
        port = ntohs( sptr->s_port );
    }
    if ( argc > 1 )
    {
        if ( !is_number( argv[1] ) )
        {
            fprintf( stderr, "Usage: %s [port #]\n", argv[0] );
            exit( 1 );
        }
        else if ( ( port = atoi( argv[1] ) ) <= 1024 )
        {
            fprintf( stderr, "Port number must be above 1024.\n" );
            exit( 1 );
        }
    }

    global_port = port;
    if ( argc > 2 )
    {
        if ( !str_cmp( argv[2], "refresh" ))
        {
            fRefresh = TRUE;
        }
    }
    /*
     * Run the game.
     * We don't need to init control if we have one
     */
    if ( !fRefresh )
        global_control = control = init_socket( port );
#if defined (__ARPENS)
    if ( (webSocket = create_web_socket( port + 1 )) < 0 )
        log_bug("Unable to create web socket on port %d",port+1);
#endif

#if defined(__WITH_GUI_CLIENT)
	if ( (clientSocket = create_client_socket( port + 10 )) < 0 )
		log_bug("Unable to create client socket on port %d",port+10);
#endif

    /* Create world */
    boot_db( fRefresh );
    /* Load natural resources */
    load_resource_file( );
    /* Load clan buildings */
    load_building_file( );
    /* Load faction table */
    loadDefaultFactions( );
    /* Loads subraces */
    load_race_avail( );
    log_string("THOC initialization finished.  Running on port %d.", port );
    log_string("Writing PID %d to %s", getpid(), PID_FILE );

    /* Create PID file */
    writePIDFile( getpid() );
    /* Populate the world */
    initSpawn( );
    /* Run the game */
    system("rm -f /mud/crevetier/scripts/.pause");
    if ( fRefresh )
        global_control = control = loadRefreshFile( );
    game_loop( control );
    /* Close the passive listener */
    close (control);

    /*
     * That's all, folks.
     */
    log_string("Saving clans." );
    save_clans( );
    save_game_info( );
    save_race_avail( );
    log_string( "Normal termination of game." );
    exit( 0 );

    /* This is redundant but it makes the compiler shut up */
    return 0;
}

int init_socket( int port )
{
    static struct sockaddr_in sa_zero;
    struct sockaddr_in sa;
    int x = 1;
    int fd;

    if ( ( fd = socket( AF_INET, SOCK_STREAM, 0 ) ) < 0 )
    {
        log_error( "Init_socket: socket" );
        exit( 1 );
    }

    if ( setsockopt( fd, SOL_SOCKET, SO_REUSEADDR, (char *) &x, sizeof(x) ) < 0 )
    {
        log_error( "Init_socket: SO_REUSEADDR" );
        close(fd);
        exit( 1 );
    }

#if defined(SO_DONTLINGER)
    {
        struct    linger    ld;

        ld.l_onoff  = 1;
        ld.l_linger = 1000;

        if ( setsockopt( fd, SOL_SOCKET, SO_DONTLINGER, (char *) &ld, sizeof(ld) ) < 0 )
        {
            log_error( "Init_socket: SO_DONTLINGER" );
            close(fd);
            exit( 1 );
        }
    }
#endif

    sa                = sa_zero;
    sa.sin_family   = AF_INET;
    sa.sin_port        = htons( port );

    if ( bind( fd, (struct sockaddr *) &sa, sizeof(sa) ) < 0 )
    {
        log_error("Init socket: bind" );
        close(fd);
        exit(1);
    }

    
    if ( listen( fd, 3 ) < 0 )
    {
        log_error("Init socket: listen");
        close(fd);
        exit(1);
    }

    return fd;
}

void game_loop( int control )
{
    static struct timeval null_time;
    struct timeval last_time;

    signal( SIGPIPE, SIG_IGN );
    gettimeofday( &last_time, NULL );
    current_time = (time_t) last_time.tv_sec;

    cycle = TRUE;
    /* Main loop */
    while ( !merc_down )
    {
        fd_set in_set;
        fd_set out_set;
        fd_set exc_set;
        Descriptor *d;
        int maxdesc;

        /* Check for a refresh */
        if ( refresh_pulse > 0 )
        {
            char msg[MAX_STRING_LENGTH];
            char buf[MAX_STRING_LENGTH];

            msg[0] = '\0';

            --refresh_pulse;
            if ( refresh_pulse == 0 )
                initiate_refresh( );
            else
            if ( refresh_pulse == PULSE_PER_SECOND * 5 )
                strcpy(msg,"5 seconds");
            else
            if ( refresh_pulse == PULSE_PER_SECOND * 10 )
                strcpy(msg,"10 seconds");
            else
            if ( refresh_pulse == PULSE_PER_SECOND * 20 )
                strcpy(msg,"20 seconds");
            else
            if ( refresh_pulse == PULSE_PER_SECOND * 30 )
                strcpy(msg,"30 seconds");
            else
            if ( refresh_pulse == PULSE_PER_SECOND * 45 )
                strcpy(msg,"45 seconds");
            else
            /* If timer is above 5 mins, only pulse message every 5 mins */
            if ( refresh_pulse >= PULSE_PER_SECOND * 300 &&
                 refresh_pulse % (PULSE_PER_SECOND*300) == 0 )
            {
                snprintf(msg,sizeof(msg),"%d minute%s",
                    refresh_pulse / (PULSE_PER_SECOND*60),
                    refresh_pulse / (PULSE_PER_SECOND*60) == 1 ? "" : "s" );
            }
            else
            /* If timer is between 1 and 5 minutes pulse message every minute */
            if ( refresh_pulse >= PULSE_PER_SECOND * 60 &&
                 refresh_pulse <  PULSE_PER_SECOND * 300 &&
                 refresh_pulse % (PULSE_PER_SECOND*60) == 0 )
            {
                snprintf(msg,sizeof(msg),"%d minute%s",
                    refresh_pulse / (PULSE_PER_SECOND*60),
                    refresh_pulse / (PULSE_PER_SECOND*60) == 1 ? "" : "s" );
            }

            if ( msg[0] != '\0' )
            {
                snprintf(buf,sizeof(buf),"&G[&WREFRESH&G]&x Game refresh in %s\n\r", msg );
                do_echo(ArpensMUD,buf);
            }
        }

        /*
         * Poll all active descriptors.
         */

        /* To reduce procss usage, we only do MUX polling every other pulse
        */
        FD_ZERO( &in_set  );
        FD_ZERO( &out_set );
        FD_ZERO( &exc_set );
        FD_SET( control, &in_set );
		maxdesc = control;

#if defined(__ARPENS)
        if ( webSocket > 0 )
            FD_SET( webSocket, &in_set );
        maxdesc    = UMAX(maxdesc,webSocket);
#endif
#if defined(__WITH_GUI_CLIENT)
		if ( clientSocket > 0 )
			FD_SET( clientSocket, &in_set );
		maxdesc	= UMAX(maxdesc,clientSocket);
#endif

        for ( d = descriptor_list; d; d = d->next )
        {
            maxdesc = UMAX( maxdesc, d->descriptor );
            FD_SET( d->descriptor, &in_set  );
            FD_SET( d->descriptor, &out_set );
            FD_SET( d->descriptor, &exc_set );
        }

        if ( select( maxdesc+1, &in_set, &out_set, &exc_set, &null_time ) < 0 )
        {
            log_error( "Game_loop: select: poll" );
            exit( 1 );
        }
    
        /*
         * New connection?
         */
        if ( FD_ISSET( control, &in_set ) )
            init_descriptor( control );

#if defined(__ARPENS)
        if ( FD_ISSET( webSocket, &in_set ) )
            process_webwho_request( webSocket );
#endif    

#if defined(__WITH_GUI_CLIENT)
		if ( FD_ISSET( clientSocket, &in_set ) )
			init_client_descriptor( clientSocket );
#endif
    
        /*
         * Kick out the freaky folks.
         */
        for ( d = descriptor_list; d != NULL; d = d_next )
        {
            d_next = d->next;   
            if ( FD_ISSET( d->descriptor, &exc_set ) )
            {
                FD_CLR( d->descriptor, &in_set  );
                FD_CLR( d->descriptor, &out_set );
                if ( d->character && d->connected == CON_PLAYING)
                    save_char_obj( d->character );
                d->outtop    = 0;
                close_socket( d );
            }
        }
        
        /*
         * Process input.
         */
        for ( d = descriptor_list; d != NULL; d = d_next )
        {
            d_next    = d->next;
            d->fcommand    = FALSE;
    
            if ( FD_ISSET( d->descriptor, &in_set ) )
            {
                if ( d->character != NULL )
                    d->character->timer = 0;

                if ( !read_from_descriptor( d ) )
                {
                    FD_CLR( d->descriptor, &out_set );
                    if ( d->character != NULL && d->connected == CON_PLAYING)
                        save_char_obj( d->character );
                    d->outtop    = 0;
                    close_socket( d );
                    continue;
                }
            }
    
            /* Now update stuff */
            if ( d->connected == CON_PLAYING && d->character != NULL && 
                !IS_NPC(d->character) && d->character->reuse_wait )
            {
                Character *ch = d->character;
                Reuse_wait    *r, *r_next;

                for( r = ch->reuse_wait ; r ; r = r_next )
                {
                    SpellIndex* pSpellIndex = NULL;

                    r_next = r->next;

                    if ( (r->timer = UMAX(0,r->timer-1)) == 0 )
                    {
                        if( IS_SET(ch->display,DISP_ALERT_REUSE) 
             && ( r->type != AFF_SKILL || ( r->type == AFF_SKILL && !IS_SET(skill_table[r->gsn].flags,SKILL_NO_REUSE_ALERT) ) ) 
             && ( (r->type == AFF_SKILL && skill_table[r->gsn].type != SKILL_WEAPON ) || r->type == AFF_SPELL) )
                        {
                            if(r->type == AFF_SPELL)
                            {
                                pSpellIndex = get_spell_index( r->gsn );
                            }

                            cprintf(ch,"&gYou may %s %s again.&x\n\r",
                                r->type == AFF_SPELL ? "cast" : "use",
                                r->type == AFF_SPELL ? (pSpellIndex ? pSpellIndex->name : "(null)") :
                                    (r->type == AFF_SKILL ? skill_table[r->gsn].name : prof_table[r->gsn].name ) );

                            if ( r->gsn == gsn_recall )
                            {
                                clear_style( ch );
                                clear_defend( ch );
                            }
                        }
                        reuseListRemove(ch,r);
                    }
                }
            }

            if (d->character != NULL && d->character->daze > 0)
                --d->character->daze;

            if ( d->character != NULL && d->character->wait > 0 )
            {
                --d->character->wait;
                if ( IS_SET(d->character->act,PLR_IS_CRAFTING) )
                {
                    Character *ch = d->character;
    
                    if ( ch->recipe_crafting == NULL )
                        log_bug("player has crafting bit set with no recipe pointer",0);
                    else
                    if ( ch->wait <= 0 )
                    {
                        finish_crafting(ch);
                        REMOVE_BIT(ch->act,PLR_IS_CRAFTING);
                    }
                }
            
                if ( IS_SET(d->character->act,PLR_IS_FIRING) )
                {
                    Character *ch = d->character;
    
                    if ( ch->firing == NULL )
                    {
                        REMOVE_BIT(ch->act,PLR_IS_FIRING);
                        log_bug("player has firing bit set with no firing data");
                    }
                    else
                    if( ch->wait <= 0 )
                    {
                        fireWeapon(ch);
                        REMOVE_BIT(ch->act,PLR_IS_FIRING);
                        free_firing_data( ch->firing );
                        ch->firing = NULL;
                    }
                }
    
                if ( IS_SET(d->character->act,PLR_IS_CASTING) ) 
                {
                    Character *ch;

                      ch = d->character;

                      if ( ch->wait == 0 )
                      {
                        int sn, level, target;
                        void *vo;

                        ch = d->character;
                        sn = ch->casting->spell_sn;
                        level = ch->casting->level;
                        vo = ch->casting->vo;
                        target = ch->casting->target;
                        REMOVE_BIT(d->character->act,PLR_IS_CASTING);
                        if ( verify_target(ch) )
                        {
                            int res;
                            SpellIndex* pSpellIndex;

                            if( (pSpellIndex = get_spell_index(sn)) != NULL )
                            {
                                res = (*(pSpellIndex->spell_fun)) ( sn, level, ch, vo, target );
                                if ( pSpellIndex->recast > 0 && res )
                                    setSpellReuseWait(ch,sn,pSpellIndex->recast);
                            }
                            else
                            {
                                log_bug("game_loop(wait == 0): Spell Index not found(%d)",sn);
                            }
                        }
                        check_spell_aggro(ch);
                        if( IS_SET(ch->casting->flags,QUICKCAST) )
                            setSkillReuseWait(ch,gsn_quick_cast,PULSE_PER_SECOND*30);

                        free_casting_data( ch->casting );
                        ch->casting = NULL;
                        /* Far bards, set a new 'playing' song */
                        ch->playing = sn;
                    }
                      else
                    {
                        SpellIndex* pSpellIndex;

                        if( (pSpellIndex = get_spell_index(ch->casting->spell_sn)) != NULL )
                        {
                            if ( ch->wait == (pSpellIndex->beats / 2 ) )
                              {
                                int sn;

                                sn = ch->casting->spell_sn;
                                if (IS_SET(pSpellIndex->flags,COM_SOM))
                                {
                                    char buf[MAX_STRING_LENGTH];
                                    act(pSpellIndex->gesture,ch,NULL,NULL,TO_ROOM);
                                    sprintf(buf,"You perform the gestures of the %s spell.",pSpellIndex->full_name);
                                    act(buf,ch,NULL,NULL,TO_CHAR);
                                }
                            }
                        }
                        else
                        {
                            log_bug("game_loop(wait != 0): Spell Index not found(%d)",ch->casting->spell_sn);
                        }
                      }
                }
                continue;
            }

            read_from_buffer( d );
            if ( d->incomm[0] != '\0' )
            {
                d->fcommand    = TRUE;
                stop_idling( d->character );

                /* OLC */
                if ( d->showstr_point )
                    show_string( d, d->incomm );
                else
                if ( d->pString )
                    string_add( d->character, d->incomm );
                else
                {
                    switch( d->connected )
                    {
                        case CON_PLAYING:
    #if defined(__OLC)      /* Siders July 13 01 */
                            if ( !run_olc_editor( d ) )
    #endif
                            substitute_alias( d, d->incomm );
                                break;

                        default:
                            nanny( d, d->incomm );
                            break;
                    }
                }
                d->incomm[0]    = '\0';
            }

              /* Here we update the timeout counter for checking for plugins.
             We do this here instead of in update because char_update doesn't happen often
             enough and I don't see the need to run through all the descriptors if I have the
             one I need right here.  -Todd */
            if ( d->connected == CON_GUI_CHECK && d->character != NULL && !IS_NPC(d->character))
              {
                gui_check_update(d->character);
            
                if(!IS_SET(d->character->gui, GUI_CHECK))
                {
                      d->connected = CON_PUT_CHAR_IN_WORLD;
              
                        /* Say we are done initializing the gui */
                        send_to_char("Done. [Hit Return to continue]\n\r",d->character);
                }
              }
        }

    /*
     * Autonomous game motion.
     */
    update_handler( );

    /*
     * Output.
     */
    for ( d = descriptor_list; d != NULL; d = d_next )
    {
        d_next = d->next;

        if ( ( d->fcommand || d->outtop > 0 ) &&   FD_ISSET(d->descriptor, &out_set) )
        {
            if ( !process_output( d, TRUE ) )
            {
                if ( d->character != NULL && d->connected == CON_PLAYING)
                    save_char_obj( d->character );

                d->outtop    = 0;
                close_socket( d );
            }
        }

        /* Handle kickouts for laggers */
        if ( d->connected != CON_PLAYING && current_time - d->state > (60 * 15) )
        {
            deprintf(d,"\n\r\n\rYou have been inactive for 15 minutes, and are being disconnected.\n\r");
            close_socket(d);
        }
    }

    /*
     * Synchronize to a clock.
     * Sleep( last_time + 1/PULSE_PER_SECOND - now ).
     * Careful here of signed versus unsigned arithmetic.
     */
    {
        struct timeval now_time;
        long secDelta;
        long usecDelta;

        gettimeofday( &now_time, NULL );
        usecDelta    = ((int) last_time.tv_usec) - ((int) now_time.tv_usec)
            + 1000000 / PULSE_PER_SECOND;
        secDelta    = ((int) last_time.tv_sec ) - ((int) now_time.tv_sec );
        while ( usecDelta < 0 )
        {
            usecDelta += 1000000;
            secDelta  -= 1;
        }

        while ( usecDelta >= 1000000 )
        {
            usecDelta -= 1000000;
            secDelta  += 1;
        }

        if ( secDelta > 0 || ( secDelta == 0 && usecDelta > 0 ) )
        {
            struct timeval stall_time;

            stall_time.tv_usec = usecDelta;
            stall_time.tv_sec  = secDelta;
            if ( select( 0, NULL, NULL, NULL, &stall_time ) < 0 )
            {
                log_error( "Game_loop: select: stall" );
                exit( 1 );
            }
        }
    }

        gettimeofday( &last_time, NULL );
        current_time = (time_t) last_time.tv_sec;
    }

    return;
}

void setDescriptorDefaults( Descriptor *d, int desc )
{
     d->descriptor    = desc;
    d->connected = CON_LOGIN_MENU;
    d->showstr_head  = NULL;
    d->showstr_point = NULL;
    d->outsize   = 2000;
    d->pEdit     = NULL;         /* OLC */
    d->pString   = NULL;         /* OLC */
    d->editor    = 0;            /* OLC */
    d->outbuf    = alloc_mem( d->outsize );
    d->color     = FALSE;
    d->mxp = FALSE;   /* Initially MXP is off */
}

void init_client_descriptor( int fd )
{
    char buf[MAX_STRING_LENGTH];
    Descriptor *dnew;
    struct sockaddr_in sock;
    struct hostent *from;
    int desc;
    int size;

    size = sizeof(sock);
    getsockname( control, (struct sockaddr *) &sock, &size );
    if ( ( desc = accept( control, (struct sockaddr *) &sock, &size) ) < 0 )
    {
        log_error( "New client descriptor: accept" );
        return;
    }

#if !defined(FNDELAY)
#define FNDELAY O_NDELAY
#endif

    if ( fcntl( desc, F_SETFL, FNDELAY ) == -1 )
    {
        log_error( "New client descriptor: fcntl: FNDELAY" );
        return;
    }

    /* Before we get too deep, let's make sure this is a client connection. */
    {
		char tmp[8];
		char key[8] = { '\0', 'A', 'R', 'P', 'E', 'N', 'S', '\0' };
		int n = 0;

		memset(tmp,0,sizeof(tmp));
		while ( (n += read(desc,tmp,8)) < 8 )
			;

		if ( !memcmp(tmp,key,8) ) { /* ok */

		}
	}
		

    /*
     * Cons a new descriptor.
     */
    dnew = new_descriptor();
    setDescriptorDefaults( dnew, desc );

    size = sizeof(sock);
    if ( getpeername( desc, (struct sockaddr *) &sock, &size ) < 0 )
    {
        log_error( "New client descriptor: getpeername" );
        dnew->host = str_dup( "(unknown)" );
    }
    else
    {
        /*
         * Would be nice to use inet_ntoa here but it takes a struct arg,
         * which ain't very compatible between gcc and system libraries.
         *
         * Not to mention that inet_ntoa is non-reentrant.
        *
        * This isn't so true these days.
         */
        int addr;

        addr = ntohl( sock.sin_addr.s_addr );
        sprintf( buf, "%d.%d.%d.%d",
                ( addr >> 24 ) & 0xFF, ( addr >> 16 ) & 0xFF,
                ( addr >>  8 ) & 0xFF, ( addr       ) & 0xFF );
        log_string( "Sock.sinaddr:  %s", buf );

        /* 
         * This has enormous lag potential if the DNS hangs.
         * We really ought to set a timer here so this can't take more than
		 * a second or, even better, do it in a thread.
         */
        from = gethostbyaddr( (char *) &sock.sin_addr, sizeof(sock.sin_addr), AF_INET );
        if ( from == NULL )
            log_string("Host lookup failure: %s", hstrerror( h_errno ) );
        
        dnew->host = str_dup( from ? from->h_name : buf );

    }
    
    /*
     * Swiftest: I added the following to ban sites.  I don't
     * endorse banning of sites, but Copper has few descriptors now
     * and some people from certain sites keep abusing access by
     * using automated 'autodialers' and leaving connections hanging.
     *
     * Furey: added suffix check by request of Nickel of HiddenWorlds.
     */
    if ( check_ban(dnew->host,BAN_ALL))
    {
    write_to_descriptor( desc,
        "Your site has been banned from this mud.\n\r", 0 );
    close( desc );
    free_descriptor(dnew);
    return;
    }
    /*
     * Init descriptor data.
     */
    dnew->next            = descriptor_list;
    descriptor_list        = dnew;

    dnew->state = current_time;
    deprintf(dnew,"You have connected to port %d.\n\r\n\r", global_port );

    {
    extern char * help_greeting;
    if ( help_greeting[0] == '.' )
        write_to_buffer( dnew, help_greeting+1, 0 );
    else
        write_to_buffer( dnew, help_greeting  , 0 );
    }

    menu(dnew);

    return;
}

void init_descriptor( int control )
{
    char buf[MAX_STRING_LENGTH];
    Descriptor *dnew;
    struct sockaddr_in sock;
    struct hostent *from;
    int desc;
    int size;

    size = sizeof(sock);
    getsockname( control, (struct sockaddr *) &sock, &size );
    if ( ( desc = accept( control, (struct sockaddr *) &sock, &size) ) < 0 )
    {
        log_error( "New_descriptor: accept" );
        return;
    }

#if !defined(FNDELAY)
#define FNDELAY O_NDELAY
#endif

    if ( fcntl( desc, F_SETFL, FNDELAY ) == -1 )
    {
        log_error( "New_descriptor: fcntl: FNDELAY" );
        return;
    }

    /*
     * Cons a new descriptor.
     */
    dnew = new_descriptor();
    setDescriptorDefaults( dnew, desc );

    size = sizeof(sock);
    if ( getpeername( desc, (struct sockaddr *) &sock, &size ) < 0 )
    {
        log_error( "New_descriptor: getpeername" );
        dnew->host = str_dup( "(unknown)" );
    }
    else
    {
        /*
         * Would be nice to use inet_ntoa here but it takes a struct arg,
         * which ain't very compatible between gcc and system libraries.
         *
         * Not to mention that inet_ntoa is non-reentrant.
        *
        * This isn't so true these days.
         */
        int addr;

        addr = ntohl( sock.sin_addr.s_addr );
        sprintf( buf, "%d.%d.%d.%d",
                ( addr >> 24 ) & 0xFF, ( addr >> 16 ) & 0xFF,
                ( addr >>  8 ) & 0xFF, ( addr       ) & 0xFF );
        log_string( "Sock.sinaddr:  %s", buf );

        /* This has enormous lag potential if the DNS hangs.
         */
        from = gethostbyaddr( (char *) &sock.sin_addr, sizeof(sock.sin_addr), AF_INET );
        if ( from == NULL )
            log_string("Host lookup failure: %s", hstrerror( h_errno ) );
        
        dnew->host = str_dup( from ? from->h_name : buf );

    }
    
    /*
     * Swiftest: I added the following to ban sites.  I don't
     * endorse banning of sites, but Copper has few descriptors now
     * and some people from certain sites keep abusing access by
     * using automated 'autodialers' and leaving connections hanging.
     *
     * Furey: added suffix check by request of Nickel of HiddenWorlds.
     */
    if ( check_ban(dnew->host,BAN_ALL))
    {
    write_to_descriptor( desc,
        "Your site has been banned from this mud.\n\r", 0 );
    close( desc );
    free_descriptor(dnew);
    return;
    }
    /*
     * Init descriptor data.
     */
    dnew->next            = descriptor_list;
    descriptor_list        = dnew;

    dnew->state = current_time;
    deprintf(dnew,"You have connected to port %d.\n\r\n\r", global_port );

    {
    extern char * help_greeting;
    if ( help_greeting[0] == '.' )
        write_to_buffer( dnew, help_greeting+1, 0 );
    else
        write_to_buffer( dnew, help_greeting  , 0 );
    }

    menu(dnew);

    return;
}



void close_socket( Descriptor *dclose )
{
    Character *ch;
    Descriptor *d;

    if ( dclose->outtop > 0 )
        process_output( dclose, FALSE );

    if ( dclose->snoop_by != NULL )
        write_to_buffer_noexp( dclose->snoop_by, "Your victim has left the game.\n\r", 0 );

    for ( d = descriptor_list; d != NULL; d = d->next )
        if ( d->snoop_by == dclose )
            d->snoop_by = NULL;

    if ( ( ch = dclose->character ) != NULL )
    {
        log_string("Closing link to %s.", ch->name );
        /* cut down on wiznet spam when rebooting */
        if ( dclose->connected == CON_PLAYING && !merc_down)
        {
            act( "$n has lost $s link.", ch, NULL, NULL, TO_ROOM );
            wiznet("Net death has claimed $N.",ch,NULL,WIZ_LINKS,0,0);
            pnet("Net death has claimed $N.",ch,NULL,WIZ_LINKS,0,get_trust(ch));
            ch->desc = NULL;
        }
        else
        {
            free_char(dclose->original ? dclose->original : dclose->character );
        }
    }
    
    if ( d_next == dclose )
    d_next = d_next->next;   

    if ( dclose == descriptor_list )
    {
    descriptor_list = descriptor_list->next;
    }
    else
    {
    Descriptor *d;

    for ( d = descriptor_list; d && d->next != dclose; d = d->next )
        ;

    if ( d != NULL )
        d->next = dclose->next;
    else
        log_bug( "Close_socket: dclose not found.", 0 );
    }

    close( dclose->descriptor );
    free_descriptor(dclose);
    return;
}



bool read_from_descriptor( Descriptor *d )
{
    int iStart;

    /* Hold horses if pending command already. */
    if ( d->incomm[0] != '\0' )
    return TRUE;

    /* Check for overflow. */
    iStart = strlen(d->inbuf);
    if ( iStart >= sizeof(d->inbuf) - 10 )
    {
        log_string( "%s input overflow!", d->host );
        write_to_descriptor( d->descriptor,
            "\n\r*** PUT A LID ON IT!!! ***\n\r", 0 );
        return FALSE;
    }

    /* Snarf input. */
    for ( ; ; )
    {
    int nRead;

    nRead = read( d->descriptor, d->inbuf + iStart,
        sizeof(d->inbuf) - 10 - iStart );
    if ( nRead > 0 )
    {
        iStart += nRead;
        if ( d->inbuf[iStart-1] == '\n' || d->inbuf[iStart-1] == '\r' )
        break;
    }
    else if ( nRead == 0 )
    {
        log_string( "EOF encountered on read." );
        return FALSE;
    }
    else if ( errno == EWOULDBLOCK )
        break;
    else
    {
        log_error( "Read_from_descriptor" );
        return FALSE;
    }
    }

    d->inbuf[iStart] = '\0';
    return TRUE;
}



/*
 * Transfer one line from input buffer to input line.
 */
void read_from_buffer( Descriptor *d )
{
    int i, j, k, t;
    unsigned char * p;
    bool is_blank_line = FALSE;

    /*
     * Hold horses if pending command already.
     */
    if ( d->incomm[0] != '\0' )
    {
    return;
    }

    /* 
      MXP - Look for incoming telnet negotiation
    */
    for (p = d->inbuf; *p; p++)
    {
      if (*p == IAC)
      {
        if (memcmp (p, do_mxp_str, strlen (do_mxp_str)) == 0)
        {
          turn_on_mxp (d);
          /* remove string from input buffer */
          memmove (p, &p [strlen (do_mxp_str)], strlen (&p [strlen (do_mxp_str)]) + 1);
          p--; /* adjust to allow for discarded bytes */
        } /* end of turning on MXP */
        else  if (memcmp (p, dont_mxp_str, strlen (dont_mxp_str)) == 0)
        {
          d->mxp = FALSE;
          /* remove string from input buffer */
          memmove (p, &p [strlen (dont_mxp_str)], strlen (&p [strlen (dont_mxp_str)]) + 1);
          p--; /* adjust to allow for discarded bytes */
        } /* end of turning off MXP */
      } /* end of finding an IAC */
    }

    /* Tildah! Smash tildah good! */
    for ( i = 0; d->inbuf[i] != '\0'; i++ ) {
      if (d->inbuf[i] == '~' ) {
        d->inbuf[0] = '\r';
        for (t = 1; d->inbuf[t] != '\0'; t++)
          d->inbuf[t] = d->inbuf[t+i];
        d->inbuf[1] = '\0';
        d->incomm[0] = '\0';
        return;
      }
    }

    /*
     * Look for at least one new line.
     */
    for ( i = 0; d->inbuf[i] != '\n' && d->inbuf[i] != '\r'; i++ )
    {
    if ( d->inbuf[i] == '\0' )
        return;
    }

    /*
     * Canonical input processing.
     */
    for ( i = 0, k = 0; d->inbuf[i] != '\n' && d->inbuf[i] != '\r'; i++ )
    {
    if ( k >= MAX_INPUT_LENGTH - 2 )
    {
        write_to_descriptor( d->descriptor, "Line too long.\n\r", 0 );

        /* skip the rest of the line */
        for ( ; d->inbuf[i] != '\0'; i++ )
        {
        if ( d->inbuf[i] == '\n' || d->inbuf[i] == '\r' )
            break;
        }
        d->inbuf[i]   = '\n';
        d->inbuf[i+1] = '\0';
        break;
    }

    if ( d->inbuf[i] == '\b' && k > 0 )
        --k;
    else if ( isascii(d->inbuf[i]) && isprint(d->inbuf[i]) )
        d->incomm[k++] = d->inbuf[i];
    }

    /*
     * Finish off the line.
     */
    if ( k == 0 )
    {
        is_blank_line = TRUE;
        d->incomm[k++] = ' ';
    }
    d->incomm[k] = '\0';

    /*
     * Deal with bozos with #repeat 1000 ...
     */

    if ( (k >= 1 && !is_blank_line) || d->incomm[0] == '!' )
    {
        if ( d->incomm[0] != '!' && strcmp( d->incomm, d->inlast ) )
    {
        d->repeat = 0;
    }
    else
    {
        if (++d->repeat >= 25 && d->character
        &&  d->connected == CON_PLAYING)
        {
            log_string( "%s input spamming!", d->host );
        wiznet("Spam spam spam $N spam spam spam spam spam!",
               d->character,NULL,WIZ_SPAM,0,get_trust(d->character));
        if (d->incomm[0] == '!')
            wiznet(d->inlast,d->character,NULL,WIZ_SPAM,0,
            get_trust(d->character));
        else
            wiznet(d->incomm,d->character,NULL,WIZ_SPAM,0,
            get_trust(d->character));

        d->repeat = 0;
        }
    }
    }


    /*
     * Do '!' substitution.
     */
    if ( d->incomm[0] == '!' )
    strcpy( d->incomm, d->inlast );
    else
    strcpy( d->inlast, d->incomm );

    /*
     * Shift the input buffer.
     */
    while ( d->inbuf[i] == '\n' || d->inbuf[i] == '\r' )
    i++;
    for ( j = 0; ( d->inbuf[j] = d->inbuf[i+j] ) != '\0'; j++ )
    ;
    return;
}



/*
 * Low level output function.
 */
bool process_output( Descriptor *d, bool fPrompt )
{
    extern bool merc_down;

    /*
     * Bust a prompt.
     * OLC changed
     */
    if ( !merc_down )
    {
        if ( d->showstr_point )
            write_to_buffer( d, "[Hit Return to continue]\n\r", 0 );
        else if ( fPrompt && d->pString && d->connected == CON_PLAYING )
            write_to_buffer( d, "> ", 2 );
        else if ( fPrompt && d->connected == CON_PLAYING )
        {
               Character *ch;
            Character *victim;

            ch = d->character;

            /* battle prompt */
            if ( (victim = ch->fighting) != NULL && can_see(ch,victim) 
                   && !IS_SET(ch->display,DISP_NO_BATTLE_PROMPT) )
            {
                int percent;
                char wound[100];
                char buf[MAX_STRING_LENGTH];
                 int hitPoints,hitPointBase;
      
                hitPoints = victim->base_hit + victim->stat_hit;
                hitPointBase = victim->max_base_hit + max_stat_hit(victim);

                if (hitPointBase > 0)
                    percent = hitPoints * 100 / hitPointBase;
                else
                    percent = -1;
 
                if (percent >= 100)
                    sprintf(wound,"is in excellent condition.");
                else if (percent >= 90)
                    sprintf(wound,"has a few scratches.");
                else if (percent >= 75)
                    sprintf(wound,"has some small wounds and bruises.");
                else if (percent >= 50)
                    sprintf(wound,"has quite a few wounds.");
                else if (percent >= 30)
                    sprintf(wound,"has some big nasty wounds and scratches.");
                else if (percent >= 15)
                    sprintf(wound,"looks pretty hurt.");
                else if (percent >= 0)
                    sprintf(wound,"is in awful condition.");
                else
                    sprintf(wound,"is bleeding to death.");
     
                sprintf(buf,"%s %s (%d%%)\n\r", 
                    IS_NPC(victim) ? victim->short_descr : victim->name,wound,percent);
                buf[0] = UPPER(buf[0]);
                write_to_buffer( d, buf, 0);
            }

            ch = d->original ? d->original : d->character;
            if (!HAS_COMMOPT(ch, COMM_OPT_COMPACT))
                write_to_buffer( d, "\n\r", 2 );

            if ( IS_SET(ch->display, DISP_MONITOR_GROUP) )
                display_group_monitor(ch);

            if ( HAS_COMMOPT(ch, COMM_OPT_PROMPT) )
                bust_a_prompt( d->character );

            if (IS_SET(ch->comm,COMM_TELNET_GA))
                write_to_buffer(d,go_ahead_str,0);
        }
    } /* End if !merc_down */

    /*
     * Short-circuit if nothing to write.
     */
    if ( d->outtop == 0 )
        return TRUE;

    /*
     * Snoop feature
     */
    if ( d->snoop_by != NULL )
    {
        /* have to do this more carefully, since the string is
           getting modified */
        char *txt;
        int length;
        char *point;
        int count = 0;

        txt = GC_MALLOC( (MAX_STRING_LENGTH+1) * sizeof(char) );
        length = d->outtop;

        if ( length > MAX_STRING_LENGTH )
        {
            GC_FREE( txt );
            txt = GC_MALLOC( (length + ((int)(length/2))) * sizeof( char ) );
        }

        point = txt;
        while ( count < d->outtop )
            *point++ = d->outbuf[count++];

        txt[count] = '\0';

        if (d->character != NULL)
            deprintf(d->snoop_by,"%s>\n\r", d->character->name);
        write_to_buffer_noexp( d->snoop_by, txt, strlen( txt ) );
        GC_FREE( txt );
    }

    /*
     * OS-dependent output.
     */

    if ( !write_to_descriptor( d->descriptor, d->outbuf, d->outtop ) )
    {
        d->outtop = 0;
        return FALSE;
    }
    else
    {
        d->outtop = 0;
        return TRUE;
    }
}


void bust_a_prompt( Character *ch )
{
    char buf[MAX_STRING_LENGTH];
    char buf2[MAX_STRING_LENGTH];
    const char *str;

    const char *i;
    char *point;

    point = buf;
    str = ch->prompt;
    if (str == NULL || str[0] == '\0')
    {
        sprintf( buf, "<%d(%d)h %dm %dmv> ",
            ch->base_hit,ch->stat_hit,ch->mana,ch->move);
        send_to_char(buf,ch);
        return;
    }

   if (IS_SET(ch->comm,COMM_AFK))
   {
        send_to_char("<&CAFK&x> ",ch);
        return;
   }

/* moved to end
   if ( IS_SET(ch->act,PLR_IS_CASTING) )
    cprintf(ch,"(&YCasting&x) ");
 */

   while( *str != '\0' )
   {
      if( *str != '%' )
      {
         *point++ = *str++;
         continue;
      }
      ++str;
      switch( *str )
      {
         default :
            i = " "; break;
        case 'A': // terrain
            sprintf( buf2,"%s", flag_string(sector_flags,ch->in_room->sector_type) );
            i = buf2; break;
        case '1' :
            sprintf( buf2, "&%c%d&x",
                 ch->stat_hit < max_stat_hit(ch) /2 ? 'R' :
                 ch->stat_hit < max_stat_hit(ch) * 3 / 4 ? 'Y' : 'W', 
                 max_stat_hit(ch) == 0 ? 0 : ch->stat_hit * 100 / max_stat_hit(ch) );
                i = buf2; break;
         case '2' :
            sprintf( buf2, "&%c%d&x",
                ch->mana < max_mana(ch) / 2 ? 'R' :
                ch->mana < max_mana(ch) * 3 / 4 ? 'Y' : 'W', 
                max_mana(ch) == 0 ? 0 : ch->mana * 100 / max_mana(ch) );
            i = buf2; break;
         case '3' :
            sprintf( buf2, "&%c%d&x",
                ch->move < ch->max_move / 2 ? 'R' :
                ch->move < ch->max_move * 3 / 4 ? 'Y' : 'W',
                ch->max_move == 0 ? 0 : ch->move * 100 / ch->max_move );
            i = buf2; break;
        case '4' :
            sprintf( buf2, "&%c%d&x",
                 ch->base_hit < ch->max_base_hit /2 ? 'R' :
                 ch->base_hit < ch->max_base_hit ? 'Y' : 'W', 
                 ch->max_base_hit == 0 ? 0 : ch->base_hit * 100 / ch->max_base_hit );
            i = buf2; break;
         case '5' :
            sprintf( buf2, "&%c%d&x",
                ch->stamina < max_stamina(ch) / 2 ? 'R' :
                ch->stamina < max_stamina(ch) * 3 / 4 ? 'Y' : 'W',
                max_stamina(ch) == 0 ? 0 : ch->stamina * 100 / max_stamina(ch) );
            i = buf2; break;
        case 'N' : case 'S':
            sprintf( buf2, "&W%d&x", max_stamina(ch) );
            i = buf2; break;
         case 'n' : case 's':
            sprintf( buf2, "&%c%d&x",
                 ch->stamina < max_stamina(ch) /2 ? 'R' :
                 ch->stamina < max_stamina(ch) * 3 / 4 ? 'Y' : 'W', ch->stamina );
            i = buf2; break;  
        case 'e':
            /*found = FALSE;
            doors[0] = '\0';
            for (door = 0; door < MAX_DIR; door++)
            {
                if ((pexit = ch->in_room->exit[door]) != NULL
                &&  pexit ->u1.to_room != NULL
                &&  (can_see_room(ch,pexit->u1.to_room)
                ||   (IS_AFFECTED(ch,AFF_INFRARED)
                &&    !IS_AFFECTED(ch,AFF_BLIND)))
                &&  !IS_SET(pexit->exit_info,EX_CLOSED))
                {
                    found = TRUE;
                    strcat(doors,dir_name[door]);
                }
            }
            if (!found)
                strcat(buf,"none");
            sprintf(buf2,"%s",doors);
            i = buf2; break;*/
        {
            char exit_string[MAX_STRING_LENGTH];
            create_exit_string(ch, EX_SHOW_PROMPT, exit_string);
            i = exit_string;
            break;
        }
         case 'c' :
            sprintf(buf2,"%s","\n\r");
            i = buf2; break;
        case 'b' :
            sprintf( buf2, "&%c%d&x",
                 ch->base_hit < ch->max_base_hit /2 ? 'R' :
                 ch->base_hit < ch->max_base_hit ? 'Y' : 'W', ch->base_hit );
            i = buf2; break;
         case 'B' :
            sprintf( buf2, "&W%d&x", ch->max_base_hit );
            i = buf2; break;
         case 'h' :
            sprintf( buf2, "&%c%d&x",
                 ch->stat_hit < max_stat_hit(ch) /2 ? 'R' :
                 ch->stat_hit < max_stat_hit(ch) * 3 / 4 ? 'Y' : 'W', ch->stat_hit );
            i = buf2; break;
         case 'H' :
            sprintf( buf2, "&W%d&x", max_stat_hit(ch) );
            i = buf2; break;
         case 'm' :
            sprintf( buf2, "&%c%d&x",
                ch->mana < max_mana(ch) / 2 ? 'R' :
                ch->mana < max_mana(ch) * 3 / 4 ? 'Y' : 'W', ch->mana );
            i = buf2; break;
         case 'M' :
            sprintf( buf2, "&W%d&x", max_mana(ch) );
            i = buf2; break;
        case 't' :
            sprintf( buf2, "%d:%02d", time_info.hour, time_info.quarterhour * 15);
            i = buf2 ; break;
        case 'T' :
        { 
            int hour;

            hour = time_info.hour - 12;
            if ( hour == 0 )
                hour = 12;
            else
            {
                if ( hour < 0 )
                    hour = time_info.hour;
            }

            sprintf( buf2, "%d:%02d%cM", hour, time_info.quarterhour * 15, 
                time_info.hour >= 12 ? 'P' : 'A' );
            i = buf2; break;
        }
         case 'v' :
            sprintf( buf2, "&%c%d&x",
                ch->move < ch->max_move / 2 ? 'R' :
                ch->move < ch->max_move *3/4 ? 'Y' : 'W', ch->move );
            i = buf2; break;
         case 'V' :
            sprintf( buf2, "&W%d&x", ch->max_move );
            i = buf2; break;
         case 'x':
        sprintf( buf2, "%ld%%", ch->exp * 100 / exp_to_level[ch->level].tnl );
        i = buf2; break;
        case 'X':
        if( !IS_NPC(ch) )
        {
            sprintf( buf2, "%ld%%", ch->pcdata->spec_exp * 100 / exp_to_level[ch->pcdata->spec_level].tnl );
            i = buf2; 
        }
        else
            i = " ";
        break;
         case 'r' :
        {
            Room *room;
            bool fRandom;
            /* Hallucination into account */
            fRandom = (is_affected(ch,vnum_minor_hallucination,AFF_SPELL) || is_affected(ch,vnum_major_hallucination,AFF_SPELL) || is_affected(ch,vnum_scorpion_venom,AFF_SPELL));
            room = fRandom ? get_random_room(ch) : ch->in_room;

            if( room != NULL )
               sprintf( buf2, "%s", ((!IS_NPC(ch) && IS_SET(ch->display,DISP_HOLYLIGHT)) ||
                                    (!IS_AFFECTED(ch,AFF_BLIND) && !room_is_dark( room )))
                                    ? room->name : "darkness");
            else
               sprintf( buf2, " " );
            i = buf2; break;
        }
         case 'R' :
            if( IS_IMMORTAL( ch ) && ch->in_room != NULL )
               sprintf( buf2, "%d", ch->in_room->vnum );
            else
               sprintf( buf2, " " );
            i = buf2; break;
         case 'z' :
            if( IS_IMMORTAL( ch ) && ch->in_room != NULL )
               sprintf( buf2, "%s", ch->in_room->area->name );
            else
               sprintf( buf2, " " );
            i = buf2; break;
         case 'w' :
            if( IS_IMMORTAL( ch ) && ch->invis_level > 0)
                sprintf(buf2," (Wizi@%d)", ch->invis_level);
            else
                buf2[0] = '\0';
            i = buf2; break;
         case 'W' :
            if( IS_IMMORTAL( ch ) && ch->invis_level > 0)
                sprintf(buf2,"%d", ch->invis_level);
            else
                buf2[0] = '\0';
            i = buf2; break;
         case 'i' :
            if( IS_IMMORTAL( ch ) && ch->incog_level > 0)
                sprintf(buf2," (Incog@%d)", ch->incog_level);
            else
                buf2[0] = '\0';
            i = buf2; break;
         case 'I' :
            if( IS_IMMORTAL( ch ) && ch->incog_level > 0)
                sprintf(buf2,"%d", ch->incog_level);
            else
                buf2[0] = '\0';
            i = buf2; break;
         case '%' :
            sprintf( buf2, "%%" );
            i = buf2; break;
        case 'P' :
            if ( ch->class == csn_bard && ch->playing > 0 )
            {
                SpellIndex* pSpellIndex;

                pSpellIndex = get_spell_index( ch->playing );
                snprintf( buf2, sizeof(buf2), "%s", pSpellIndex ? pSpellIndex->name : "(null)" );
            }
            else
                snprintf( buf2, sizeof(buf2), "(none)" );
            i = buf2; 
            break;
        case 'g' :
            i = "*";
            if ( ch->fighting )
                if(ch->fighting->fighting && ch->fighting->fighting != ch)
                {
                    sprintf( buf2, "&%c%s:&%c%d&x%% ",get_con_color(ch->level, ch->fighting->fighting->level), ch->fighting->fighting->name,
                        ch->fighting->fighting->stat_hit < max_stat_hit(ch->fighting->fighting) /2 ? 'R' :
                        ch->fighting->fighting->stat_hit < max_stat_hit(ch->fighting->fighting) * 3 / 4 ? 'Y' : 'W', 
                        max_stat_hit(ch->fighting->fighting) == 0 ? 0 : ch->fighting->fighting->stat_hit * 100 / max_stat_hit(ch->fighting->fighting) );
                    i = buf2;
                }
            break;
        case 'G' :
            i = "*";
            if ( ch->fighting )
                if(ch->fighting->fighting && ch->fighting->fighting != ch)
                {
                    sprintf( buf2, "&%c%s:&%c%d&x.&%c%d&x%% ",get_con_color(ch->level, ch->fighting->fighting->level), ch->fighting->fighting->name,
                        ch->fighting->fighting->base_hit < ch->fighting->fighting->max_base_hit /2 ? 'R' :
                        ch->fighting->fighting->base_hit < ch->fighting->fighting->max_base_hit ? 'Y' : 'W', 
                        ch->fighting->fighting->max_base_hit == 0 ? 0 : ch->fighting->fighting->base_hit * 100 / ch->fighting->fighting->max_base_hit,
                        ch->fighting->fighting->stat_hit < max_stat_hit(ch->fighting->fighting) /2 ? 'R' :
                        ch->fighting->fighting->stat_hit < max_stat_hit(ch->fighting->fighting) * 3 / 4 ? 'Y' : 'W', 
                        max_stat_hit(ch->fighting->fighting) == 0 ? 0 : ch->fighting->fighting->stat_hit * 100 / max_stat_hit(ch->fighting->fighting) );
                    i = buf2;
                }
            break;
        case 'd' : 
                sprintf(buf2, "%s", format_date( current_time, "%I:%M%p")) ;
                i = buf2;
                break;
        case 'D' : 
                sprintf(buf2, "%s", format_date( current_time, "%H:%M")) ;
                i = buf2;
                break;
      }
      ++str;
      while( (*point = *i) != '\0' )
         ++point, ++i;
}
   buf2[0] = '\0';
   i = buf2;
      while( (*point = *i) != '\0' )
         ++point, ++i;

   point = &buf[0];

       write_to_buffer( ch->desc, point, 0 );
    write_to_buffer( ch->desc, "&x", 0 );

   if ( IS_SET(ch->act,PLR_IS_CASTING) )
        cprintf(ch,"(&YCasting&x) ");

    if( IS_SET(ch->act,PLR_IS_CRAFTING) )
        cprintf(ch,"(&MCrafting&x) "); 

    if ( IS_SET(ch->act,PLR_IS_FIRING) )
        cprintf(ch,"(&GAiming&x) ");

   return;
}

void display_group_monitor(Character *ch)
{
    int i;
    char buf[MAX_STRING_LENGTH], buf2[MAX_STRING_LENGTH];
    bool found = FALSE;
    for(i = 0; i<MAX_PLAYERS_IN_GROUP; i++)
    {
        if(ch->pgroup->members[i] && ch->pgroup->members[i] != ch)
        {
            if(!found)
                sprintf(buf, "(");
            else
                strcat(buf, " ");//adds a space during the middle by putting it in front of all but the first
            found=TRUE;
            sprintf( buf2, "&%c%.5s:&%c%d&x",get_con_color(ch->level, ch->pgroup->members[i]->level), ch->pgroup->members[i]->name,
                 ch->pgroup->members[i]->base_hit < ch->pgroup->members[i]->max_base_hit ? 'M' :
                 ch->pgroup->members[i]->stat_hit < max_stat_hit(ch->pgroup->members[i]) /2 ? 'R' :
                 ch->pgroup->members[i]->stat_hit < max_stat_hit(ch->pgroup->members[i]) * 3 / 4 ? 'Y' : 'W', 
                 max_stat_hit(ch->pgroup->members[i]) == 0 ? 0 : ch->pgroup->members[i]->stat_hit * 100 / max_stat_hit(ch->pgroup->members[i]) );
            strcat(buf, buf2);
        }
        else if(ch->pgroup->members[i] == NULL)
            break;
    }
    if(found)
    {    
        strcat(buf, ")\n\r");
        cprintf(ch, "%s", buf);
    }
}

/*
 * Append onto an output buffer without expanding MXP tags
 */
void write_to_buffer_noexp( Descriptor *d, const char *arg, int length )
{
    char    *txt;

    /* txt will be pointing to a static buffer so we don't have to worry
     * about mallocing and what not 
     */
    if( has_color(d) )
        txt = colorize( arg );
    else
        txt = decolorize( arg );

    /*
     * Find length in case caller didn't.
     */
    length = strlen(txt);

    /*
     * Initial \n\r if needed.
     */
    if ( d->outtop == 0 && !d->fcommand)
    {
        if(d->character != NULL && IS_SET(d->character->gui, GUI_RECEIVING_TELL))
        {
              REMOVE_BIT(d->character->gui, GUI_RECEIVING_TELL);
        }
        else
        {
            d->outbuf[0]    = '\n';
            d->outbuf[1]    = '\r';
            d->outtop    = 2;
        }
    }

    /*
     * Expand the buffer as needed.
     */
    while ( d->outtop + length >= d->outsize )
    {
        char *outbuf;

        if (d->outsize >= MAX_BUFFER_SIZE)
        {
            log_bug("Buffer overflow. Closing.\n\r",0);
            close_socket(d);
            return;
         }
        outbuf      = alloc_mem( 2 * d->outsize );
        strncpy( outbuf, d->outbuf, d->outtop );
        free_mem( d->outbuf, d->outsize );
        d->outbuf   = outbuf;
        d->outsize *= 2;
    }

    /*
     * Copy.
     */
    strncpy( d->outbuf + d->outtop, txt, length );

    d->outtop += length;
    return;
}

/*
 * Append onto an output buffer.
 */
void write_to_buffer( Descriptor *d, const char *arg, int length )
{
    char    *txt;
    int origlength;

    /* txt will be pointing to a static buffer so we don't have to worry
     * about mallocing and what not 
     */
    if( has_color(d) )
        txt = colorize( arg );
    else
        txt = decolorize( arg );

    /*
     * Find length in case caller didn't.
     */
    length = strlen(txt);

    /* MXP */
    origlength = length;
    /* work out how much we need to expand/contract it */
    length += count_mxp_tags (d->mxp, txt, length);
 
    /*
     * Initial \n\r if needed.
     */
    if ( d->outtop == 0 && !d->fcommand)
    {
        if(d->character != NULL && IS_SET(d->character->gui, GUI_RECEIVING_TELL))
        {
              REMOVE_BIT(d->character->gui, GUI_RECEIVING_TELL);
        }
        else
        {
            d->outbuf[0]    = '\n';
            d->outbuf[1]    = '\r';
            d->outtop    = 2;
        }
    }

    /*
     * Expand the buffer as needed.
     */
    while ( d->outtop + length >= d->outsize )
    {
        char *outbuf;

        if (d->outsize >= MAX_BUFFER_SIZE)
        {
            log_bug("Buffer overflow. Closing.\n\r",0);
            close_socket(d);
            return;
         }
        outbuf      = alloc_mem( 2 * d->outsize );
        strncpy( outbuf, d->outbuf, d->outtop );
        free_mem( d->outbuf, d->outsize );
        d->outbuf   = outbuf;
        d->outsize *= 2;
    }

    /*
     * Copy.
     */
    /* MXP */
    /*strncpy( d->outbuf + d->outtop, txt, length );*/
    convert_mxp_tags (d->mxp, d->outbuf + d->outtop, txt, origlength );

    d->outtop += length;
    return;
}

/*
 * Lowest level output function.
 * Write a block of text to the file descriptor.
 * If this gives errors on very long blocks (like 'ofind all'),
 *   try lowering the max block size.
 */
bool write_to_descriptor( int desc, char *txt, int length )
{
    int iStart;
    int nWrite;
    int nBlock;

    if ( length <= 0 )
        length = strlen(txt);

    for ( iStart = 0; iStart < length; iStart += nWrite )
    {
    nBlock = UMIN( length - iStart, 4096 );
    if ( ( nWrite = write( desc, txt + iStart, nBlock ) ) < 0 )
        { log_error( "Write_to_descriptor" ); return FALSE; }
    } 

    return TRUE;
}

/*
 * Deal with sockets that haven't logged in yet.
 */
void nanny( Descriptor *d, char *argument )
{
    int i;
    Descriptor *d_old, *d_next;
    char arg[MAX_INPUT_LENGTH];
    Character *ch;
    bool fOld;

    while ( isspace(*argument) )
    argument++;

    ch = d->character;
    d->state = current_time;

    switch ( d->connected )
    {

    case CON_LOGIN_MENU:
    if ( argument[0] == '\0' )
    {
        deprintf(d,"Please select a menu option.  You may use the numbers or\n\r"
                    "type in the words surrounded by *stars* to navigate.\n\r\n\r"
                   "Type 'help' any any time for more information.\n\r\n\r");
        menu( d );
        break;
    }

    switch(*argument)
    {
    default:
        menu(d);
        break;
    case 'h': case 'H':
        deprintf(d,
"\n\r MENU HELP \n\r"
"  Our menu system is fairly primitive, as we're not sure yet\n\r"
"how much we want to use it.  For now, use the 'play' option to\n\r"
"play your old characters, and use 'new' to make a new one.\n\r\n\r");
        menu(d);
        break;
    case '1': case 'p': case 'P':
        deprintf(d,"\n\rYour character's name: ");
        d->connected = CON_GET_NAME;
        break;
    case '2': case 'n': case 'N':
        if ( newlock )
        {
            deprintf(d,
"The game is newlocked.  This means new characters may not be created right\n\r"
"now.  Newlocking is usually a temporary measure, and often only lasts for a\n\r"
"few minutes.  If the game remains newlocked for more than an hour (and you're\n\r"
"getting impatient!), email admin@www.crevetier.com to get details about what's\n\r"
"going on.\n\r");
            menu(d);
            d->connected = CON_LOGIN_MENU;
            break;
        }

        deprintf(d,
"\n\r&GTHOC&W New Character Creation&x\n\r"
"\n\rA new character!  Our character creation system has recently changed.  If\n\r"
"you need assistance, you may use the 'advice' channel from anywhere in these\n\r"
"creation menus to solicit input from other players.\n\r");
        deprintf(d,
"\n\rThe basics of creation are that you pick a name, gender, race/subrace, class,\n\r"
    "deity, and then you're ready to go.  You may optionally pick a starting weapon\n\r"
    "as well, if you don't like the default selection.  Type 'help' or 'advice' at\n\r"
    "any point for more information.\n\r");
        deprintf(d,"\n\r<Hit enter to begin creation>\n\r");
        d->connected = CON_CREATION;
        break;
    case '3': case 'q': case 'Q':
        deprintf(d, "Thank you for playing!\n\r");
        close_socket( d );
        return;
    }
    break;          

    case CON_CREATION:
        // Print creation menu, requires blank character data
        if ( d->character == NULL )
        {
            if ( load_char_obj(d,"A THOC Newbie") )
            {
                deprintf(d,
"An internal error has occured, and creation must be disabled until it is fixed.\n\r"
"Contact James (james@www.crevetier.com) for more information.\n\r\n\r"
"<Hit enter to continue>\n\r");
                d->connected = CON_LOGIN_MENU;
                newlock = TRUE;
                log_bug("Error!  blank.character was FOUND!");
                break;
            }
        }

        process_creation( d, argument );
        break;

    case CON_GET_REWARD:
        deprintf(d,
        "Your character is currently getting a reward, please try again in a few seconds.\n\r");
        break;
    
    case CON_GET_NAME:
    if ( argument[0] == '\0' )
    {
        menu(d);
        d->connected = CON_LOGIN_MENU;
        break;
    }

    argument[0] = UPPER(argument[0]);

    if ( !(fOld = load_char_obj( d, argument )) )
    {
        free_char(d->character);
        d->character = NULL;
        deprintf(d,
        "THOC was unable to locate a character file for '%s'.  If you are trying\n\r"
        "to create a new character, use the New option at the main menu.  If you're sure\n\r",argument);
        deprintf(d,
        "you spelled your name right but you're still getting this message, contact\n\r"
        "admin@rp.arpens.net with your name and when the last time you logged in was.\n\r");
        deprintf(d,"\n\rTry again (hit enter to go to the menu) -> ");
        break;
    }

    ch = d->character;
    if ( current_time < ch->pcdata->build_deadline )
    {
        int remain=ch->pcdata->build_deadline - current_time;
        cprintf(ch,"This character is busy with a construction project.\n\r");
        cprintf(ch,"You can play again in %d hour%s and %d minute%s.\n\r",
            remain/3600,remain/3600==1?"":"s",
            remain%3600/60,remain%3600/60==1?"":"s");
        close_socket(d);
        return;
    }

    if (IS_SET(ch->act, PLR_DENY))
    {
        log_string( "Denying access to %s@%s.", argument, d->host );
        deprintf( d,
            "This character is denied access.  A denial is a permanent refusal of\n\r"
            "service.  This generally only happens when you are so repeatedly disruptive\n\r");
        deprintf( d,
            "that the staff determines that no amount or severity of disciplinary\n\r"
            "action will get you to follow the rules.  You may appeal denials by\n\r");
        deprintf( d,
            "emailing admin@rp.arpens.net and explaining why you should get your\n\r"
            "character back.\n\r\n\r");
        close_socket( d );
        return;
    }

    if (check_ban(d->host,BAN_PERMIT) && !IS_SET(ch->act,PLR_PERMIT))
    {
        write_to_buffer(d,"Your site has been banned from this mud.\n\r",0);
        close_socket(d);
        return;
    }

  /* telnet negotiation to see if they support MXP */
  write_to_buffer( d, will_mxp_str, 0 );

    if ( check_reconnect( d, argument, FALSE ) )
    {
        fOld = TRUE;
    }
    else
    {
        if ( wizlock && !IS_IMMORTAL(ch)) 
        {
        write_to_buffer( d, "The game is wizlocked.\n\r", 0 );
        close_socket( d );
        return;
        }
    }

        write_to_buffer( d, "Password: ", 0 );
        write_to_buffer( d, echo_off_str, 0 );
        d->connected = CON_GET_OLD_PASSWORD;

    break;

    case CON_GET_OLD_PASSWORD:
#if defined(unix)
    write_to_buffer( d, "\n\r", 2 );
#endif

    if ( strcmp( crypt( argument, ch->pcdata->pwd ), ch->pcdata->pwd ))
    {
        write_to_buffer( d, "That password does match the server file.\n\r", 0 );
        close_socket( d );
        return;
    }

    write_to_buffer( d, echo_on_str, 0 );

    if (check_playing(d,ch->name))
        return;

    if ( check_reconnect( d, ch->name, TRUE ) )
        return;

    if ( ch->version < 20 && !IS_IMMORTAL(ch) )
    {
        Object *obj;

        reset_char( ch );

        for( i =0 ; i < MAX_WEAR ; i++ )
            if ( (obj = get_eq_char(ch,i)) != NULL )
                unequip_char( ch, obj );

        while ( ch->affected )
            affect_remove( ch, ch->affected );

        deprintf(d,
        " * * * * * * * * * * * * * * * * * * * * * * *\n\r"
        " Welcome to The Heirs of Crevetier Beta!\n\r"
        "   We have moved the game from alpha development into beta, and as part of that\n\r"
        " transition, we need to clean up the player-files.  Everybody is being asked to\n\r"
        " recreate their character.  You may use this opportunity to make a totally \n\r");
        deprintf(d,
        "different character, or be who you were before.  Regardless of how you decide\n\r"
        "to use this opportunity, you will keep your old equipment, old trade skills,\n\r"
        "old level, and if you had any AA levels, you'll get your spec points back.\n\r"
        "Basically, you're just getting re-created and re-advanced to your old level.\n\r");
        deprintf(d,
        "If you have any questions that you want answered before you procede, you can\n\r"
        "email james@www.crevetier.com and I'll try to get back to you ASAP.  Don't worry!\n\r"
        "Even if something goes disasterously wrong here, I can restore your old pfile and\n\r"
        "let you try it again.  Have fun!\n\r");
        deprintf(d,"\n\r");
        print_race_list(d);
        d->connected = CON_GET_NEW_RACE;

        break;
    }

    log_string( "%s@%s has connected.", ch->name, d->host );
    wizprintf(NULL,NULL,WIZ_SITES,0,get_trust(ch),
                "%s@%s has connected.", ch->name, d->host);

    if ( IS_IMMORTAL(ch) )
    {
        do_function(ch, &do_help, "imotd" );
        cprintf(ch,"[Push Enter to Continue]");
        d->connected = CON_READ_IMOTD;
     }
    else
    {
        do_function(ch, &do_help, "motd" );
        cprintf(ch,"[Push Enter to Continue]");
        d->connected = CON_READ_MOTD;
    }
    break;

/* RT code for breaking link */
 
    case CON_BREAK_CONNECT:
    switch( *argument )
    {
    case 'y' : case 'Y':
        for ( d_old = descriptor_list; d_old != NULL; d_old = d_next )
        {
            d_next = d_old->next;
            if (d_old == d || d_old->character == NULL)
                continue;

            if (str_cmp(ch->name,d_old->original ?  d_old->original->name : d_old->character->name))
                continue;

            close_socket(d_old);
        }

        if (check_reconnect(d,ch->name,TRUE))
            return;

        write_to_buffer(d,"Reconnect attempt failed.\n\rName: ",0);
        if ( d->character != NULL )
        {
            free_char( d->character );
            d->character = NULL;
        }
        d->connected = CON_GET_NAME;
        break;

    case 'n' : case 'N':
        write_to_buffer(d,"Name: ",0);
            if ( d->character != NULL )
            {
                free_char( d->character );
                d->character = NULL;
            }
        d->connected = CON_GET_NAME;
        break;

    default:
        write_to_buffer(d,"Please type Y or N? ",0);
        break;
    }
    break;

    case CON_READ_IMOTD:
    write_to_buffer(d,"\n\r",2);
        do_function(ch, &do_help, "motd");
        cprintf(ch,"[Push Enter to Continue]");
        d->connected = CON_READ_MOTD;
    break;

    case CON_READ_MOTD:
        if ( ch->pcdata == NULL || ch->pcdata->pwd[0] == '\0')
        {
            write_to_buffer( d, "Warning! Null password!\n\r",0 );
            write_to_buffer( d, "Please report old password with bug.\n\r",0);
            write_to_buffer( d,
                "Type 'password null <new password>' to fix.\n\r",0);
        }

  /* Setup GUI check */
    if ( IS_SET(ch->gui, GUI_USE ) )
    {
          d->connected = CON_GUI_CHECK;
          SET_BIT(ch->gui, GUI_CHECK);
        send_to_char("Initializing GUI...\n\r",ch);
        break;
    }
    else
    {
        d->connected = CON_PUT_CHAR_IN_WORLD;
        nanny(d,"");
        break;
    }

    case CON_GUI_CHECK:
      one_argument(argument,arg);
      
      if (!strcmp(arg,"guiinit"))
      {
        argument = one_argument(argument,arg);
        do_function(ch, &do_initialize_gui, argument);
      }
      
      break;

    case CON_PUT_CHAR_IN_WORLD:
        ch->next         = char_list;
        char_list        = ch;
        d->connected     = CON_PLAYING;
        ch->pcdata->host = str_dup( d->host );
        reset_char(ch);
     
        addToLastLogin( ch );
        log_string("%s has entered the world.",ch->name);
      
      if ( ch->level == 0 )
      {
        for(i = 0;i< MAX_STATS;i++ )
            ch->pcdata->start_stat[i] = ch->perm_stat[i];

        ch->created    = current_time;
        ch->level    = 1;
        ch->exp    = 0;
        ch->max_base_hit = 5;
        ch->max_stat_hit = ch->max_base_hit * 4;
        ch->max_stamina  = ch->perm_stat[STAT_CON];
        ch->base_hit     = ch->max_base_hit;
        ch->stat_hit     = max_stat_hit( ch );
        ch->stamina      = max_stamina( ch );
        ch->mana         =  max_mana(ch);
        ch->move         = ch->max_move;
        ch->practice     = 10;
        ch->train        = 10;
        
        set_title( ch, "" );
       
        applyDefaultFactions( ch ); 
        char_to_room( ch, get_room_index( ROOM_VNUM_SCHOOL ) );
        send_to_char("\n\r",ch);
        do_function(ch, &do_help, "newbie info");
        do_function(ch, &do_outfit, "" );
        send_to_char("\n\r",ch);
       
        GameInfo.totalNewbies++;
        GameInfo.totalCurrent++;   
        save_game_info();
        addEventToJournal( ch->pcdata->journal, "Struck out on my own..." );

        // Hobbit Hack
        if (HAS_PROF(ch,gpn_elusive_2) && ch->pcdata->subrace == subrace_lookup("halfling"))
            group_add(ch,"elusive 3",FALSE);

        save_char_obj( ch );
        log_string( "%s@%s new player.", ch->name, d->host );
        wiznet("Newbie alert!  $N sighted.",ch,NULL,WIZ_NEWBIE,0,0);
        wizprintf(NULL,NULL,WIZ_SITES,0,get_trust(ch), 
            "%s@%s new player.", ch->name, d->host);

        pnet("Newbie alert!  $N sighted.",ch,NULL,WIZ_NEWBIE,0,0);

      }
    else
          if ( ch->in_room != NULL )
          {
            char_to_room( ch, ch->in_room );
          }
          else if ( IS_IMMORTAL(ch) )
          {
            char_to_room( ch, get_room_index( ROOM_VNUM_CHAT ) );
          }
          else
          {
            char_to_room( ch, get_room_index( ROOM_VNUM_TEMPLE ) );
          }
    
        if( ch->level < 5 )
            do_function(ch,&do_help,"mailing list");
 
        /* Check for shapeshifting */
        if ( ch->shapeshifted != NULL )
        {
            Room *r = ch->in_room;
            Character *shift = ch->shapeshifted;

            char_from_room( ch );
            char_to_room( shift, r );

            ch->desc->original = ch;    
            ch->desc->character = shift;
            ch = shift;

            /* Add shapeshifter to char list too! */
            shift->next = char_list;
            char_list   = shift;
        }
 
          act( "$n has entered the game.", ch, NULL, NULL, TO_ROOM );
          do_function(ch, &do_look, "auto" );
      
          wiznet("$N has left real life behind.",ch,NULL, WIZ_LOGINS,WIZ_SITES,get_trust(ch));
          pnet("$N has left real life behind.",ch,NULL,WIZ_LOGINS,0,get_trust(ch));
          
        /* Check for possible multiplay */
        {
        Descriptor *d_test;

        for( d_test = descriptor_list; d_test != NULL; d_test = d_test->next )
        {
            if( d_test->character == NULL || d->character == NULL || IS_IMMORTAL(d_test->character) )
                continue;

            if(d_test != d && d->host != NULL && !strcmp(d_test->host,d->host))
            {
                char buffer[MAX_STRING_LENGTH];
                sprintf(buffer,"Possible multiplayer alert: %s and %s have the same host (%s)", 
                    d->character->name, d_test->character->name, d->host);    
                wiznet(buffer,d->character, NULL, WIZ_LOGINS, WIZ_SITES, get_trust(d->character) );
            }
        }
        }

          if (ch->pet != NULL)
          {
            char_to_room(ch->pet,ch->in_room);
            act("$n has entered the game.",ch->pet,NULL,NULL,TO_ROOM);
          }
        
        cprintf(ch,"\n\r"); 
          do_function(ch, &do_unread, "");
        cprintf(ch,"\n\r");
          do_function(ch, &do_count, "");
        cprintf(ch,"\n\r");
        do_function(ch, &do_version, "");


#if defined(__OLC)
    if ( IS_SET(ch->act,PLR_BUILDER) && ch->level < 56 )
    {
        cprintf(ch,"&R* * * * *&x Builder flag enabled. &R* * * * *&x\n\r");
        ch->level = 56;
        cprintf(ch,"See: &Mhttp://www.crevetier.com/olc&x for builder documentation.\n\r");
    }
#endif

    cprintf(ch,"\n\r[&R**&x] If you love THOC, and we know you do, go to http://www.crevetier.com/\n\r"
               "[&R**&x] and click on \"Support THOC\".  By voting for and advocating our game,\n\r"
               "[&R**&x] you give new people incentive to come at least give us a try.  Thanks!\n\r\n\r");

      break;

      default:
        log_bug( "Nanny: bad d->connected %d.", d->connected );
        close_socket( d );
        return;
    }

    return;
}

char *check_parse_name_errstring( char *name )
{
    /*
     * Reserved words.
     */
    if (is_exact_name(name,
    "all auto immortal self someone something the you loner"))
    {
        return "it's a reserved word";
    }

    /*
     * Length restrictions.
     */
     
    if ( strlen(name) <  3 )
        return "it's too short (minimum of 3 letters)";

    if ( strlen(name) > 12 )
        return "it's too long (maximum of 12 letters)";

    /*
     * Alphanumerics only.  Also allow single quotes.
     * Lock out IllIll twits.
     */
    {
    bool    quote = FALSE;
    char *pc;
    bool fIll,adjcaps = FALSE,cleancaps = FALSE;
     int total_caps = 0;

    fIll = TRUE;
    for ( pc = name; *pc != '\0'; pc++ )
    {
        if ( !isalpha(*pc) && *pc != '\'' )
            return "it contains invalid characters (only letters and ' permitted)";

        /* One quote allowed per name */
        if ( *pc == '\'' )
        {
            if ( quote )
                return "it contains more than one quote";
            else
                quote = TRUE;
        }

        if ( isupper(*pc)) /* ugly anti-caps hack */
        {
        if (adjcaps)
            cleancaps = TRUE;
        total_caps++;
        adjcaps = TRUE;
        }
        else
        adjcaps = FALSE;

        if ( LOWER(*pc) != 'i' && LOWER(*pc) != 'l' )
        fIll = FALSE;
    }

    if ( fIll )
        return "it contains an illegal combination of I and l";

    if (cleancaps || (total_caps > (strlen(name)) / 2 && strlen(name) < 3))
        return "it contains funky capitalization";
    }

    /*
     * Prevent players from naming themselves after mobs.
     */
    {
    extern MobIndex *mob_index_hash[MAX_KEY_HASH];
    MobIndex *pMobIndex;
    int iHash;

    for ( iHash = 0; iHash < MAX_KEY_HASH; iHash++ )
    {
        for ( pMobIndex  = mob_index_hash[iHash];
          pMobIndex != NULL;
          pMobIndex  = pMobIndex->next )
        {
        if ( is_name( name, pMobIndex->player_name ) )
            return "there is an NPC with that name";
        }
    }
    }

    /* First and last cannot be single quotes */
    if ( name[0] == '\'' || name[strlen(name)-1] == '\'' )
        return "the first and last characters must be letters";

    return NULL;
}

/*
 * Parse a name for acceptability.
 */
bool check_parse_name( char *name )
{
    /*
     * Reserved words.
     */
    if (is_exact_name(name,
    "all auto immortal self someone something the you loner"))
    {
    return FALSE;
    }

    /*
     * Length restrictions.
     */
     
    if ( strlen(name) <  2 )
        return FALSE;

    if ( strlen(name) > 12 )
        return FALSE;

    /*
     * Alphanumerics only.  Also allow single quotes.
     * Lock out IllIll twits.
     */
    {
    bool    quote = FALSE;
    char *pc;
    bool fIll,adjcaps = FALSE,cleancaps = FALSE;
     int total_caps = 0;

    fIll = TRUE;
    for ( pc = name; *pc != '\0'; pc++ )
    {
        if ( !isalpha(*pc) && *pc != '\'' )
        return FALSE;

        /* One quote allowed per name */
        if ( *pc == '\'' )
        {
            if ( quote )
                return FALSE;
            else
                quote = TRUE;
        }

        if ( isupper(*pc)) /* ugly anti-caps hack */
        {
        if (adjcaps)
            cleancaps = TRUE;
        total_caps++;
        adjcaps = TRUE;
        }
        else
        adjcaps = FALSE;

        if ( LOWER(*pc) != 'i' && LOWER(*pc) != 'l' )
        fIll = FALSE;
    }

    if ( fIll )
        return FALSE;

    if (cleancaps || (total_caps > (strlen(name)) / 2 && strlen(name) < 3))
        return FALSE;
    }

    /*
     * Prevent players from naming themselves after mobs.
     */
    {
    extern MobIndex *mob_index_hash[MAX_KEY_HASH];
    MobIndex *pMobIndex;
    int iHash;

    for ( iHash = 0; iHash < MAX_KEY_HASH; iHash++ )
    {
        for ( pMobIndex  = mob_index_hash[iHash];
          pMobIndex != NULL;
          pMobIndex  = pMobIndex->next )
        {
        if ( is_name( name, pMobIndex->player_name ) )
            return FALSE;
        }
    }
    }


    /* First and last cannot be single quotes */
    if ( name[0] == '\'' || name[strlen(name)-1] == '\'' )
        return FALSE;

    return TRUE;
}

/*
 * Prevent players from naming themselves after a character
 * that is currently being created
 */
bool check_being_created_name( char *name )
{
    Descriptor *d, *d_next;

    for ( d = descriptor_list; d != NULL; d = d_next )
    {
        d_next = d->next;   
        if ( d->character && !str_cmp(d->character->name,name) )
        {
            return FALSE;
        }
    }

    return TRUE;
}

/*
 * Look for link-dead player to reconnect.
 */
bool check_reconnect( Descriptor *d, char *name, bool fConn )
{
    Character *ch;
    bool fShapeshift;

    for ( ch = char_list; ch != NULL; ch = ch->next )
    {
        if ( IS_NPC(ch) )
            continue;

        fShapeshift = ch->shapeshifted ? ch->shapeshifted->desc == NULL : FALSE;

        if ( (!fConn || ch->desc == NULL || fShapeshift) && !str_cmp( d->character->name, ch->name ) )
        {
            if ( fConn == FALSE )
            {
                free_string( d->character->pcdata->pwd );
                d->character->pcdata->pwd = str_dup( ch->pcdata->pwd );
            }
            else
            {
                free_char( d->character );
                d->character = ch;
                ch->desc     = d;
                ch->timer     = 0;
                
                if(buf_string(ch->pcdata->buffer)[0] == '\0')
                    cprintf(ch, "Reconnecting. You have not missed any tells.\n\r");
                else
                    cprintf(ch, "Reconnecting. Type 'replay' to see missed tells.\n\r");

                act( "$n has reconnected.", ch, NULL, NULL, TO_ROOM );
                log_string("%s@%s reconnected.", ch->name, d->host );
                wiznet("$N groks the fullness of $S link.", ch,NULL,WIZ_LINKS,0,0);
                pnet("$N groks the fullness of $S link.", ch,NULL,WIZ_LINKS,0,get_trust(ch));
                d->connected = CON_PLAYING;

                /* Shapeshifting */
                if ( ch->shapeshifted )
                {
                    ch->desc->original = ch;
                    ch->desc->character = ch->shapeshifted;
                    ch->shapeshifted->desc = d;
                }
            }
            return TRUE;
        }
    }
    return FALSE;
}

/*
 * Check if already playing.
 */
bool check_playing( Descriptor *d, char *name )
{
    Descriptor *dold;

    for ( dold = descriptor_list; dold; dold = dold->next )
    {
        if ( dold != d
        &&   dold->character != NULL
        &&   dold->connected != CON_GET_NAME
        &&   dold->connected != CON_GET_OLD_PASSWORD
        &&     dold->connected != CON_GET_REWARD
        &&   !str_cmp( name, dold->original ? dold->original->name : dold->character->name ) )
        {
            write_to_buffer( d, "That character is already playing.\n\r",0);
            write_to_buffer( d, "Do you wish to connect anyway (y/n)?",0);
            d->connected = CON_BREAK_CONNECT;
            return TRUE;
        }
    }

    return FALSE;
}

void stop_idling( Character *ch )
{
    if ( ch == NULL
    ||   ch->desc == NULL
    ||   ch->desc->connected != CON_PLAYING
    ||   ch->was_in_room == NULL 
    ||   ch->in_room != get_room_index(ROOM_VNUM_LIMBO))
    return;

    ch->timer = 0;
    char_from_room( ch );
    char_to_room( ch, ch->was_in_room );
    ch->was_in_room    = NULL;
    act( "$n has returned from the void.", ch, NULL, NULL, TO_ROOM );
    return;
}

int  cprintf( Character *ch, const char *fmt, ... )
{
    va_list ap;
    char    buffer[MAX_STRING_LENGTH*2];

    va_start( ap, fmt );

    vsnprintf(buffer,sizeof(buffer),fmt,ap);

    va_end( ap );

    send_to_char( buffer, ch );
    return strlen_nocol(buffer);
}

/*
 * Write to one char.
 */
void send_to_char( const char *txt, Character *ch )
{
    if ( txt != NULL && ch->desc != NULL )
        write_to_buffer( ch->desc, txt, strlen(txt) );
    return;
}

/*
 * Send a page to one char.
 */
void page_to_char( const char *txt, Character *ch )
{
    if ( txt == NULL || ch->desc == NULL)
    return;

    if (ch->lines == 0 )
    {
    send_to_char(txt,ch);
    return;
    }
    
    ch->desc->showstr_head = alloc_mem(strlen(txt) + 1);
    strcpy(ch->desc->showstr_head,txt);
    ch->desc->showstr_point = ch->desc->showstr_head;
    show_string(ch->desc,"");
}


/* string pager */
void show_string(struct descriptor_data *d, char *input)
{
    char buffer[4*MAX_STRING_LENGTH];
    char buf[MAX_INPUT_LENGTH];
    register char *scan, *chk;
    int lines = 0, toggle = 1;
    int show_lines;

    one_argument(input,buf);
    if (buf[0] != '\0')
    {
    if (d->showstr_head)
    {
        free_mem(d->showstr_head,strlen(d->showstr_head));
        d->showstr_head = 0;
    }
        d->showstr_point  = 0;
    return;
    }

    if (d->character)
    show_lines = d->character->lines;
    else
    show_lines = 0;

    for (scan = buffer; ; scan++, d->showstr_point++)
    {
    if (((*scan = *d->showstr_point) == '\n' || *scan == '\r')
        && (toggle = -toggle) < 0)
        lines++;

    else if (!*scan || (show_lines > 0 && lines >= show_lines))
    {
        *scan = '\0';
        write_to_buffer(d,buffer,strlen(buffer));
        for (chk = d->showstr_point; isspace(*chk); chk++);
        {
        if (!*chk)
        {
            if (d->showstr_head)
                {
                    free_mem(d->showstr_head,strlen(d->showstr_head));
                    d->showstr_head = 0;
                }
                d->showstr_point  = 0;
            }
        }
        return;
    }
    }
    return;
}
    
/* quick sex fixer */
void fix_sex(Character *ch)
{
    if (ch->sex < 0 || ch->sex > 2)
        ch->sex = IS_NPC(ch) ? 0 : ch->pcdata->true_sex;
}

int actprintf( Character *ch, const void *arg1, const void *arg2, int type,
                const char *fmt , ... )
{
    va_list ap;
    char    buffer[MAX_STRING_LENGTH*2];

    va_start( ap, fmt );

    vsnprintf(buffer,sizeof(buffer),fmt,ap);

    va_end( ap );

    act(buffer,ch,arg1,arg2,type);
    return strlen_nocol(buffer);
}

int actnprintf( Character *ch, const void *arg1, const void *arg2, int type, 
                int min_pos, bool fOOC, const char *fmt, ... )
{
    va_list ap;
    char buffer[MAX_STRING_LENGTH*2];

    va_start( ap, fmt );

    vsnprintf(buffer,sizeof(buffer),fmt,ap);

    va_end( ap );
    act_new(buffer,ch,arg1,arg2,type,min_pos,fOOC);
    return strlen_nocol(buffer);
}

void act_ooc( const char *format, Character *ch, const void *arg1, 
          const void *arg2, int type, int min_pos, bool fOOC )
{
    static char * const he_she  [] = { "it",  "he",  "she" };
    static char * const him_her [] = { "it",  "him", "her" };
    static char * const his_her [] = { "its", "his", "her" };

    char buf[MAX_STRING_LENGTH];
    char fname[MAX_INPUT_LENGTH];
    Character *to;
    Character *vch = (Character *) arg2;
    Object *obj1 = (Object  *) arg1;
    Object *obj2 = (Object  *) arg2;
    const char *str;
    const char *i;
    char *point;

    /*
     * Discard null and zero-length messages.
     */
    if ( format == NULL || format[0] == '\0' )
        return;

    /* discard null rooms and chars */
    if (ch == NULL || ch->in_room == NULL)
        return;

    to = ch->in_room->people;
    if ( type == TO_VICT )
    {
        if ( vch == NULL )
        {
            log_bug( "Act: null vch with TO_VICT.", 0 );
            return;
        }

    if (vch->in_room == NULL)
        return;

        to = vch->in_room->people;
    }

    if( type == TO_RADIUS )
    {
        Exit *pexit, *pback;
        int door;
        Room *save, *r;

        save = ch->in_room;
        for ( door = 0; door <= 5; door++ )
        {
            /* Conditions.
             * 1. there's an exit in that direction
             * 2. it goes somewhere
             * 3. it has an exit back the opposite direciton
             * 4. that exit goes to THIS room
             * 5. That room isn't the same as this room
             */
            if ( ( pexit = save->exit[door] ) != NULL && 
                 (r=pexit->u1.to_room) != NULL &&
                 (pback = r->exit[rev_dir[door]]) != NULL && 
                 pback->u1.to_room == save &&
                 r != save )
            {
                char tmp[4];
                snprintf(tmp,sizeof(tmp),"%d",door);
                ch->in_room = pexit->u1.to_room;
                act(format,ch,NULL,(void *)tmp,TO_ROOM);
            }
        }

        ch->in_room = save;
        return;
    }
    for ( ; to != NULL; to = to->next_in_room )
    {
        if ( to->desc == NULL || to->position < min_pos )
            continue;
 
        if ( (type == TO_CHAR) && to != ch )
            continue;
        if ( type == TO_VICT && ( to != vch || to == ch ) )
            continue;
        if ( type == TO_ROOM && to == ch )
            continue;
        if ( type == TO_NOTVICT && (to == ch || to == vch) )
            continue;
 
        point   = buf;
        str     = format;
        while ( *str != '\0' )
        {
            if ( *str != '$' )
            {
                *point++ = *str++;
                continue;
            }
            ++str;
 
            if ( arg2 == NULL && *str >= 'A' && *str <= 'Z' )
            {
                log_bug( "Act: missing arg2 for code %d.", *str );
                i = " <@@@> ";
            }
            else
            {
                switch ( *str )
                {
                default:  log_bug( "Act: bad code %d.", *str );
                          i = " <@@@> ";                                break;
                /* Thx alex for 't' idea */
                case 't': i = (char *) arg1;                            break;
                case 'T': i = (char *) arg2;                            break;
                case 'n': i = PERS_OOC( ch,  to  );                         break;
                case 'N': i = PERS_OOC( vch, to  );                         break;
                case 'e': i = he_she  [URANGE(0, ch  ->sex, 2)];        break;
                case 'E': i = he_she  [URANGE(0, vch ->sex, 2)];        break;
                case 'm': i = him_her [URANGE(0, ch  ->sex, 2)];        break;
                case 'c': i = class_table[ch->class].name;                break;
                case 'C': i = class_table[vch->class].name;                break;
                case 'r': i = race_table[ch->race].name;                break;
                case 'R': i = race_table[vch->race].name;                break;
                case 'M': i = him_her [URANGE(0, vch ->sex, 2)];        break;
                case 's': i = his_her [URANGE(0, ch  ->sex, 2)];        break;
                case 'S': i = his_her [URANGE(0, vch ->sex, 2)];        break;
                case 'D': 
                    if ( arg2 != NULL )
                        i = extended_dir_name [ rev_dir [ atoi( (char*) arg2) ] ];
                    else
                    {
                        log_bug("$D in act_new: no arg1 !",0);
                        i = "somewhere";
                    }
                    break;

                case 'y':
                    i = ch->deity > 0 ? deity_table[ch->deity].name : "a higher power";
                    break;
                case 'Y': 
                    i = vch->deity > 0 ? deity_table[ch->deity].name : "a higher power"; 
                    break;
                case 'p':
                    i = can_see_obj( to, obj1 )
                            ? obj1->short_descr
                            : "something";
                    break;
 
                case 'P':
                    i = can_see_obj( to, obj2 )
                            ? obj2->short_descr
                            : "something";
                    break;
 
                case 'd':
                    if ( arg2 == NULL || ((char *) arg2)[0] == '\0' )
                    {
                        i = "door";
                    }
                    else
                    {
                        one_argument( (char *) arg2, fname );
                        i = fname;
                    }
                    break;
                }
            }
 
            ++str;
            while ( ( *point = *i ) != '\0' )
                ++point, ++i;
        }
 
        *point++ = '\n';
        *point++ = '\r';
        *point   = '\0';

        /* Find start of string to capitalize it */
        {
            char *p;

            p = buf;
            if ( *p == '&' )
                p += 2;

            *p = UPPER(*p);
        }
        write_to_buffer( to->desc, buf, point - buf );
    }
 
    return;
}

void act_new( const char *format, Character *ch, const void *arg1, 
          const void *arg2, int type, int min_pos, bool fOOC )
{
    static char * const he_she  [] = { "it",  "he",  "she" };
    static char * const him_her [] = { "it",  "him", "her" };
    static char * const his_her [] = { "its", "his", "her" };

    char buf[MAX_STRING_LENGTH];
    char fname[MAX_INPUT_LENGTH];
    Character *to;
    Character *vch = (Character *) arg2;
    Object *obj1 = (Object  *) arg1;
    Object *obj2 = (Object  *) arg2;
    const char *str;
    const char *i;
    char *point;

    /*
     * Discard null and zero-length messages.
     */
    if ( format == NULL || format[0] == '\0' )
        return;

    /* discard null rooms and chars */
    if (ch == NULL || ch->in_room == NULL)
        return;

    to = ch->in_room->people;
    if ( type == TO_VICT )
    {
        if ( vch == NULL )
        {
            log_bug( "Act: null vch with TO_VICT.", 0 );
            return;
        }

    if (vch->in_room == NULL)
        return;

        to = vch->in_room->people;
    }

    if( type == TO_RADIUS )
    {
        Exit *pexit, *pback;
        int door;
        Room *save, *r;

        save = ch->in_room;
        for ( door = 0; door <= 5; door++ )
        {
            /* Conditions.
             * 1. there's an exit in that direction
             * 2. it goes somewhere
             * 3. it has an exit back the opposite direciton
             * 4. that exit goes to THIS room
             */
            if ( ( pexit = save->exit[door] ) != NULL && (r=pexit->u1.to_room) != NULL &&
                    (pback = r->exit[rev_dir[door]]) != NULL && pback->u1.to_room == save )
            {
                char tmp[4];
                snprintf(tmp,sizeof(tmp),"%d",door);
                ch->in_room = pexit->u1.to_room;
                act(format,ch,NULL,(void *)tmp,TO_ROOM);
            }
        }

        ch->in_room = save;
        return;
    }
    for ( ; to != NULL; to = to->next_in_room )
    {
        if ( to->desc == NULL || to->position < min_pos )
            continue;
 
        if ( (type == TO_CHAR) && to != ch )
            continue;
        if ( type == TO_VICT && ( to != vch || to == ch ) )
            continue;
        if ( type == TO_ROOM && to == ch )
            continue;
        if ( type == TO_NOTVICT && (to == ch || to == vch) )
            continue;
 
        point   = buf;
        str     = format;
        while ( *str != '\0' )
        {
            if ( *str != '$' )
            {
                *point++ = *str++;
                continue;
            }
            ++str;
 
            if ( arg2 == NULL && *str >= 'A' && *str <= 'Z' )
            {
                log_bug( "Act: missing arg2 for code %d.", *str );
                i = " <@@@> ";
            }
            else
            {
                switch ( *str )
                {
                default:  log_bug( "Act: bad code %d.", *str );
                          i = " <@@@> ";                                break;
                /* Thx alex for 't' idea */
                case 't': i = (char *) arg1;                            break;
                case 'T': i = (char *) arg2;                            break;
                case 'n': i = PERS( ch,  to  );                         break;
                case 'N': i = PERS( vch, to  );                         break;
                case 'e': i = he_she  [URANGE(0, ch  ->sex, 2)];        break;
                case 'E': i = he_she  [URANGE(0, vch ->sex, 2)];        break;
                case 'm': i = him_her [URANGE(0, ch  ->sex, 2)];        break;
                case 'c': i = class_table[ch->class].name;                break;
                case 'C': i = class_table[vch->class].name;                break;
                case 'r': i = race_table[ch->race].name;                break;
                case 'R': i = race_table[vch->race].name;                break;
                case 'M': i = him_her [URANGE(0, vch ->sex, 2)];        break;
                case 's': i = his_her [URANGE(0, ch  ->sex, 2)];        break;
                case 'S': i = his_her [URANGE(0, vch ->sex, 2)];        break;
                case 'D': 
                    if ( arg2 != NULL )
                        i = extended_dir_name [ rev_dir [ atoi( (char*) arg2) ] ];
                    else
                    {
                        log_bug("$D in act_new: no arg1 !",0);
                        i = "somewhere";
                    }
                    break;

                case 'y':
                    i = ch->deity > 0 ? deity_table[ch->deity].name : "a higher power";
                    break;
                case 'Y': 
                    i = vch->deity > 0 ? deity_table[ch->deity].name : "a higher power"; 
                    break;
                case 'p':
                    i = can_see_obj( to, obj1 )
                            ? obj1->short_descr
                            : "something";
                    break;
 
                case 'P':
                    i = can_see_obj( to, obj2 )
                            ? obj2->short_descr
                            : "something";
                    break;
 
                case 'd':
                    if ( arg2 == NULL || ((char *) arg2)[0] == '\0' )
                    {
                        i = "door";
                    }
                    else
                    {
                        one_argument( (char *) arg2, fname );
                        i = fname;
                    }
                    break;
                }
            }
 
            ++str;
            while ( ( *point = *i ) != '\0' )
                ++point, ++i;
        }
 
        *point++ = '\n';
        *point++ = '\r';
        *point   = '\0';

        /* Find start of string to capitalize it */
        {
            char *p;

            p = buf;
            if ( *p == '&' )
                p += 2;

            *p = UPPER(*p);
        }
        write_to_buffer( to->desc, buf, point - buf );
    }
 
    return;
}

void sock_printf( int fd, const char *fmt, ... )
{
    va_list ap;
    char    buffer[MAX_STRING_LENGTH*2];
    
    va_start( ap, fmt );
    vsnprintf(buffer,sizeof(buffer),fmt,ap);
    va_end( ap );

    write_to_descriptor( fd, buffer, strlen(buffer) );
    return;
}

void deprintf( Descriptor *d, const char *fmt, ... )
{
    va_list    ap;
    char    buffer[MAX_STRING_LENGTH*2];

    va_start( ap, fmt );

    vsnprintf(buffer,sizeof(buffer),fmt,ap);

    va_end( ap );

    write_to_buffer( d, buffer, strlen(buffer) );
}

void menu( Descriptor *d )
{
    deprintf(d," -= The Heirs of Crevetier :: Login Menu =-\n\r");
    deprintf(d," [1] *Play* Existing Character\n\r");
    deprintf(d," [2] Create *New* Character\n\r");
    deprintf(d," [3] *Quit*\n\r");
    deprintf(d,"\n\rYour choice? -> ");
    return;
}

int config_lookup( const char *name )
{
    int i;

    for( i = 1 ; param_config_table[i].param != NULL ; i++ )
    {
        if ( !strcmp( param_config_table[i].param, name ) )
            return i;
    }

    return 0;
}


void conf_integer_conv( char *value, int index )
{
    int *lptr = (int *) param_config_table[index].ptr;

    *lptr = atoi(value);
    return;
}

void conf_string_conv( char *value, int index )
{
    char *lptr = (char *) param_config_table[index].ptr;

    strcpy(lptr,value);
    return;
}

void read_configuration( const char *filename )
{
    FILE *fp;
    char    buffer[CONFIG_LINE_LEN];

    if ( (fp = fopen( filename, "r" )) == NULL )
    {
        log_error(filename);
        return;
    }

    memset(buffer,0,sizeof(buffer));
    while( fgets( buffer, ARPENS_LINE_LEN, fp ) != NULL )
    {
        char *p1, *b1;
        int conf_ind;

        buffer[strlen(buffer)-1] = '\0';
        b1 = buffer;
        while ( isspace(*b1) )
            ++b1;

        /* Allow comments */
        if ( *b1 == '#' )
            continue;

        if ( (p1 = strchr( b1, '=' )) == NULL )
        {
            fprintf(stderr,"read_config: line %s contains no = sign\n",b1);
            continue;
        }

        *p1++ = '\0';
        if ( !(conf_ind = config_lookup( b1 )) )
        {
            fprintf(stderr,"read_config: option %s not found in table\n",b1);
            continue;
        }

        switch( param_config_table[conf_ind].type )
        {
        case INTEGER:    conf_integer_conv( p1, conf_ind ); break;    
        case STRING:    conf_string_conv ( p1, conf_ind ); break;
        default:
            fprintf(stderr,"read_config: invalid parameter type in config table\n");
            break;
        }
        memset(buffer,0,sizeof(buffer));
    }

    fclose( fp );
    return;
}

void room_printf( Room *r, const char *string )
{
    Character *ch;

    for( ch = r->people ; ch != NULL ; ch = ch->next_in_room )
        cprintf(ch,string);

    return;
}

void radius_printf( Room *location, const char *fmt, ... )
{
    va_list    ap;
    char    buf[MAX_STRING_LENGTH];
    int        door;

    va_start( ap, fmt );
    vsnprintf(buf,sizeof(buf),fmt,ap);
    
    va_end( ap );

    for ( door = 0; door <= 5; door++ )
    {
        Exit *pexit;

        if ( ( pexit = location->exit[door] ) != NULL && pexit->u1.to_room != NULL )
            room_printf( pexit->u1.to_room, buf );
    }

    return;
}

void initFalseCharacter( void )
{
    ArpensMUD = new_char( );
    ArpensMUD->name = str_dup("ArpensMUD Server 4.0");
    ArpensMUD->level    = 60;
    ArpensMUD->act          = 0;
    ArpensMUD->desc        = NULL;
    ArpensMUD->pnote    = NULL;

    return;
}

char *translateVersion( void )
{
    static char tmp[MAX_STRING_LENGTH];
    char *p;

    if ( (p = strchr( game_version, ' ' ) ) == NULL )
        return "bad version string";

    while( isspace( *p ) )
             ++p;

    strcpy(tmp,p);
    if ( (p = strchr( tmp, ' ' )) == NULL )
        return "bad version string";

    *p = '\0';
    for( p = tmp; *p != 0 ; p++ )
            if ( *p == '-' )
                    *p = '.';
    return tmp;
}

/* MXP */

/*
 * Count number of mxp tags need converting
 *    ie. < becomes &lt;
 *        > becomes &gt;
 *        & becomes &amp;
 */

int count_mxp_tags (const int bMXP, const char *txt, int length)
{
  char c;
  const char * p;
  int count;
  int bInTag = FALSE;
  int bInEntity = FALSE;

  for (p = txt, count = 0; length > 0; p++, length--)
  {
    c = *p;

    if (bInTag)  /* in a tag, eg. <send> */
    {
      if (!bMXP)
        count--;     /* not output if not MXP */   
      if (c == MXP_ENDc)
        bInTag = FALSE;
    } /* end of being inside a tag */
    else if (bInEntity)  /* in a tag, eg. <send> */
    {
      if (!bMXP)
        count--;     /* not output if not MXP */   
      if (c == ';')
        bInEntity = FALSE;
    } /* end of being inside a tag */
    else switch (c)
    {
      case MXP_BEGc:
        bInTag = TRUE;
        if (!bMXP)
          count--;     /* not output if not MXP */   
        break;

      case MXP_ENDc:   /* shouldn't get this case */
        if (!bMXP)
          count--;     /* not output if not MXP */   
        break;

      case MXP_AMPc:
        bInEntity = TRUE;
        if (!bMXP)
          count--;     /* not output if not MXP */   
        break;

      default:
        if (bMXP)
        {
          switch (c)
          {
            case '<':       /* < becomes &lt; */
            case '>':       /* > becomes &gt; */
              count += 3;    
              break;

            case '&':
              count += 4;    /* & becomes &amp; */
              break;

            case '"':        /* " becomes &quot; */
              count += 5;    
              break;

          } /* end of inner switch */
        }   /* end of MXP enabled */
    } /* end of switch on character */

   }   /* end of counting special characters */

  return count;
} /* end of count_mxp_tags */

void convert_mxp_tags (const int bMXP, char * dest, const char *src, int length)
{
  char c;
  const char * ps;
  char * pd;
  int bInTag = FALSE;
  int bInEntity = FALSE;

  for (ps = src, pd = dest; length > 0; ps++, length--)
  {
    c = *ps;
    if (bInTag)  /* in a tag, eg. <send> */
    {
      if (c == MXP_ENDc)
      {
        bInTag = FALSE;
        if (bMXP)
          *pd++ = '>';
      }
      else if (bMXP)
        *pd++ = c;  /* copy tag only in MXP mode */
    } /* end of being inside a tag */
    else if (bInEntity)  /* in a tag, eg. <send> */
    {
      if (bMXP)
        *pd++ = c;  /* copy tag only in MXP mode */
      if (c == ';')
        bInEntity = FALSE;
    } /* end of being inside a tag */
    else switch (c)
    {
      case MXP_BEGc:
        bInTag = TRUE;
        if (bMXP)
          *pd++ = '<';
        break;

      case MXP_ENDc:    /* shouldn't get this case */
        if (bMXP)
          *pd++ = '>';
        break;

      case MXP_AMPc:
        bInEntity = TRUE;
        if (bMXP)
          *pd++ = '&';
        break;

      default:
        if (bMXP)
        {
          switch (c)
          {
            case '<':
              memcpy (pd, "&lt;", 4);
              pd += 4;    
              break;

            case '>':
              memcpy (pd, "&gt;", 4);
              pd += 4;    
              break;

            case '&':
              memcpy (pd, "&amp;", 5);
              pd += 5;    
              break;

            case '"':
              memcpy (pd, "&quot;", 6);
              pd += 6;    
              break;

            default:
              *pd++ = c;
              break;  /* end of default */

          } /* end of inner switch */
        }
        else
        {
          *pd++ = c;  /* not MXP - just copy character */
        }
        break;  

    } /* end of switch on character */

  }   /* end of converting special characters */
} /* end of convert_mxp_tags */

/* set up MXP */
void turn_on_mxp (Descriptor *d)
{
  d->mxp = TRUE;  /* turn it on now */
     write_to_buffer( d, start_mxp_str, 0 );
    write_to_buffer( d, MXPMODE (6), 0 );   /* permanent secure mode */
} /* end of turn_on_mxp */

// Modified and taken from copyover
int loadRefreshFile( void )
{
    Descriptor *d;
    FILE *fp;
    char name [100];
    char host[MAX_STRING_LENGTH];
    int desc;
    int mxp_status = -1;
    bool fOld;
    int control = 0;
    
    log_string("Refresh recovery starting");
    
    if ( (fp = fopen (REFRESH_FILE, "r")) == NULL )
    {
        log_string("Failed to open %s: %s", REFRESH_FILE, strerror(errno));
        exit(1);
    }
    
    /* In case something crashes - doesn't prevent reading */
    unlink(REFRESH_FILE);
    
    for (;;)
    {
        log_string("Reading from refresh file...");

        fscanf (fp, "%d %s %s %d\n", &desc, name, host, &mxp_status);
        if (desc == -1)
            break;

        if ( !str_cmp(name,"control") )
        {
            control = desc;
            continue;
        }

        /* Write something, and check if it goes error-free */        
        if ( !write_to_descriptor(desc,"\n\rTesting your game link...\n\r",0) )
        {
            close(desc); /* nope */
            continue;
        }
        
        d = alloc_perm(sizeof(Descriptor));
        setDescriptorDefaults(d,desc); /* set up various stuff */
        
        d->host = str_dup(host);
        d->next = descriptor_list;
        descriptor_list = d;
        d->connected = CON_REFRESH; /* Cheap hack for close_socket */
        d->mxp = mxp_status == 0 ? FALSE : TRUE;
        
        /* Now, find the pfile */
        fOld = load_char_obj (d, name);
        
        if (!fOld) /* Player file not found?! */
        {
            write_to_descriptor(desc,"\n\rYour character was lost in the refresh.\n\r", 0);
            close_socket(d);            
        }
        else /* ok! */
        {
            Character *ch = d->character;

            reset_char(ch);
            addToLastLogin( ch );
            write_to_descriptor(desc,"\n\rRefresh successful.  Game on!\n\r\n\r",0);

            /* Just In Case */
            if (!d->character->in_room)
                d->character->in_room = get_room_index(ROOM_VNUM_TEMPLE);

            /* Insert in the char_list */
            d->character->next = char_list;
            char_list = d->character;

            char_to_room(d->character, d->character->in_room);
            act("$n survived the refresh.", d->character, NULL, NULL, TO_ROOM);
            d->connected = CON_PLAYING;

            // Check for shapeshifting
            if ( ch->shapeshifted != NULL )
            {
                Room *r = ch->in_room;
                Character *shift = ch->shapeshifted;
    
                char_from_room( ch );
                char_to_room( shift, r );
    
                ch->desc->original = ch;
                ch->desc->character = shift;
                ch = shift;
    
                /* Add shapeshifter to char list too! */
                shift->next = char_list;
                char_list   = shift;
            }
            do_look(ch,"");
        }
    }

    if ( control == 0 )
    {
        log_string("Unable to find control!");
        exit(1);
    }    

    fclose (fp);
    return control;
}

void print_race_list( Descriptor *d )
{
    int race;
    char tmp[25];

    write_to_buffer(d,"THOC has the following races currently available for play:\n\r",0);
    write_to_buffer(d,"\n\rNote: &RRaces with a ! next to their name are uncommon or rare races,\n\r" 
                      "and may not be available the next time you create.  In fact, they\n\r"
                      "may not be available by the time you pick your race!  The race list\n\r"
                      "is dynamic and a ! race may get snatched up by somebody else.\n\r&x",0);

    for ( race = 1; subrace_table[race].name != NULL; race++ )
    {
        if ( subrace_table[race].next_avail != NULL &&
             *subrace_table[race].next_avail > current_time )
            continue;

        if ( subrace_table[race].race_index != NULL )
            snprintf(tmp,sizeof(tmp),"%s (%s)",
                subrace_table[race].name,
                race_table[*subrace_table[race].race_index].name );
        else
            snprintf(tmp,sizeof(tmp),"%s", subrace_table[race].name );

        deprintf(d,"%s * %-24s", 
            subrace_table[race].next_avail == NULL ? "  " : "!!",
            tmp );
        deprintf(d," STR &g%3d&x DEX &g%3d&x CON &g%3d&x INT &g%3d&x WIS &g%3d&x CHA &g%3d&x\n\r",
            subrace_table[race].stat_adj[STAT_STR], subrace_table[race].stat_adj[STAT_DEX],
            subrace_table[race].stat_adj[STAT_CON], subrace_table[race].stat_adj[STAT_INT],
            subrace_table[race].stat_adj[STAT_WIS], subrace_table[race].stat_adj[STAT_CHA] );
    }
    deprintf(d,"\n\r",0);
    deprintf(d,"Please select a race.  "
               "Type 'help' for details to aid in your selection.\n\rYour race will be: ");
    return;
}

